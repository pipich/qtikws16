#include <gsl/gsl_blas.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_integration.h>

//*******************************************
//IQ
//*******************************************
double IQ(double Q, void * ParaM)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	double A=gsl_vector_get(Para,0);
	double B=gsl_vector_get(Para,1);
	
	return A+B*Q;
}

int derIQ(double Q, void * ParaM, gsl_vector * der)
{
	
	gsl_vector_set(der,0, 1);
	gsl_vector_set(der,1, Q);
	
	return GSL_SUCCESS;
}
//*******************************************
//Guinier
//*******************************************
double Guinier(double Q, void * ParaM)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	
	double I0=gsl_vector_get(Para,0);
	double Rg=gsl_vector_get(Para,1);
	double Back=gsl_vector_get(Para,2);
	
	if (I0==0) I0=1e-10;
	
	double res;
	
	if (Back==0) 
		res=log(I0)-Rg*Rg/3*Q;
	else 
		res= log(I0*exp(-Rg*Rg/3*Q)+Back);
	
	return res;
}

int derGuinier(double Q, void * ParaM, gsl_vector * der)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	double I0=gsl_vector_get(Para,0);
	double Rg=gsl_vector_get(Para,1);
	double Back=gsl_vector_get(Para,2);
	
	if (I0==0) I0=1e-10;
	
	double fun=Guinier(Q,ParaM);
	gsl_vector_set(der,2, 1/fun);
	
	if (Back==0) 
	{
		gsl_vector_set(der,0, 1/I0);
		gsl_vector_set(der,1, -2/3*Rg*Q);
	}
	else
	{
		gsl_vector_set(der,0, 1/fun*exp(-Rg*Rg*Q/3));
		gsl_vector_set(der,1, 1/fun*(-I0*2/3*Rg*Q*exp(-Rg*Rg*Q/3)));
	}
	
	return GSL_SUCCESS;
}
//*******************************************
//GuinierRod
//*******************************************
double GuinierRod(double Q, void * ParaM)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	
	double P1=gsl_vector_get(Para,0);
	double a=gsl_vector_get(Para,1);
	double Back=gsl_vector_get(Para,2);
	
	if (P1==0) P1=1e-11;
	
	double res;
	
	if (Back==0) 
		res=log(P1)-a*a/4*Q;
	else 
		res= log(P1*exp(-a*a/4*Q)+Back*sqrt(Q));
	
	return res;
}

int derGuinierRod(double Q, void * ParaM, gsl_vector * der)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	double P1=gsl_vector_get(Para,0);
	double a=gsl_vector_get(Para,1);
	double Back=gsl_vector_get(Para,2);
	
	double fun=GuinierRod(Q,ParaM);
	gsl_vector_set(der,2, sqrt(Q)/fun);
	
	if (P1==0) P1=1e-11;
	
	if (Back==0) 
	{
		gsl_vector_set(der,0, 1/P1);
		gsl_vector_set(der,1, -1/2*a*Q);
	}
	else
	{
		gsl_vector_set(der,0, 1/fun*exp(-a*a*Q/4));
		gsl_vector_set(der,1, 1/fun*(-P1/2*a*Q*exp(-a*a*Q/4)));
	}
	
	return GSL_SUCCESS;
}

//*******************************************
//GuinierPlate
//*******************************************
double GuinierPlate(double Q, void * ParaM)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	double P2=gsl_vector_get(Para,0);
	double d=gsl_vector_get(Para,1);
	double Back=gsl_vector_get(Para,2);
	
	if (P2==0) P2=1e-11;
	
	double res;
	
	if (Back==0) 
		res=log(P2)-d*d/12*Q;
	else 
		res= log(P2*exp(-d*d/12*Q)+Back*Q);
	
	return res; 
}

int derGuinierPlate(double Q, void * ParaM, gsl_vector * der)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	double P2=gsl_vector_get(Para,0);
	double d=gsl_vector_get(Para,1);
	double Back=gsl_vector_get(Para,2); 
	
	double fun=GuinierPlate(Q,ParaM);
	gsl_vector_set(der,2, Q/fun);
	
	if (P2==0) P2=1e-11;
	
	if (Back==0) 
	{
		gsl_vector_set(der,0, 1/P2);
		gsl_vector_set(der,1, -1/6*d*Q);
	}
	else
	{
		gsl_vector_set(der,0, 1/fun*exp(-d*d*Q/12));
		gsl_vector_set(der,1, 1/fun*(-P2/6*d*Q*exp(-d*d*Q/12)));
	}
	
	return GSL_SUCCESS;
}

//*******************************************
//Zimm
//*******************************************
double Zimm(double Q, void * ParaM)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	double I0=gsl_vector_get(Para,0);
	double xi=gsl_vector_get(Para,1);
	double Back=gsl_vector_get(Para,2); 
	
	if (I0==0) I0=1e-10;
	
	double res;
	
	if (Back==0) 
		res=1/I0*(1+xi*xi*Q);
	else 
		res= 1/ ( I0 / (1+xi*xi*Q) + Back);
	
	return res; 
}

int derZimm(double Q, void * ParaM, gsl_vector * der)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	double I0=gsl_vector_get(Para,0);
	double xi=gsl_vector_get(Para,1);
	double Back=gsl_vector_get(Para,2);    
	
	double fun=Zimm(Q,ParaM);
	gsl_vector_set(der,2, -1/fun/fun);
	
	if (I0==0) I0=1e-10;
	
	if (Back==0) 
	{
		gsl_vector_set(der,0, -1/I0/I0 );
		gsl_vector_set(der,1, 2*xi*Q);
	}
	else
	{
		gsl_vector_set(der,0, -1/fun/fun/ (1+xi*xi*Q));
		gsl_vector_set(der,1, 2*xi*Q*I0/fun/fun/ (1+xi*xi*Q)/ (1+xi*xi*Q));
	}
	
	return GSL_SUCCESS;
}

//*******************************************
//Porod
//*******************************************
double Porod(double Q, void * ParaM)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	double P=gsl_vector_get(Para,0);
	double exp=gsl_vector_get(Para,1);
	double Back=gsl_vector_get(Para,2);       
	
	if (P==0) P=1e-16;
	
	double res;
	
	if (Back==0) 
		res=log10(P)-exp*Q;
	else 
		res= log10( P / pow(10,exp*Q) + Back);
	
	return res; 
}

int derPorod(double Q, void * ParaM, gsl_vector * der)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	double P=gsl_vector_get(Para,0);
	double exp=gsl_vector_get(Para,1);
	double Back=gsl_vector_get(Para,2);    
	
	double fun=Porod(Q,ParaM);
	gsl_vector_set(der,2, 1/fun/log(10.0));
	
	if (P==0) P=1e-16;
	
	if (Back==0) 
	{
		gsl_vector_set(der,0, 1/P/log(10.0));
		gsl_vector_set(der,1, -Q);
	}
	else
	{
		gsl_vector_set(der,0, 1/fun/log(10.0)/pow(10,exp*Q) );
		gsl_vector_set(der,1, -P*Q/fun/pow(10.0,exp*Q));
	}
	
	return GSL_SUCCESS;
}

//*******************************************
//Porod2
//*******************************************
double Porod2(double Q, void * ParaM)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	double P=gsl_vector_get(Para,0);
	double B=gsl_vector_get(Para,1);
	
	return P+B*B*Q;
}

int derPorod2(double Q, void * ParaM, gsl_vector * der)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	double B=gsl_vector_get(Para,1);
	
	gsl_vector_set(der,0, 1);
	gsl_vector_set(der,1, 2*B*Q);
	
	return GSL_SUCCESS;
}

//*******************************************
//* Function Power P*Q^exp+Back
//*******************************************
double Power(double Q, void * ParaM)
{
	double res;
	if (Q==0) 
		res=0;
	else
	{
		gsl_vector  *Para=(gsl_vector *) ParaM;
		double P=gsl_vector_get(Para,0);
		double exp=gsl_vector_get(Para,1);
		double Back=gsl_vector_get(Para,2);
		res= P*pow(fabs(Q),exp)+Back;
	}
	return res;
}
//* Deriv. of Function Power P*Q^exp+Back
int derPower(double Q, void * ParaM, gsl_vector * der)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	double P=gsl_vector_get(Para,0);
	double exp=gsl_vector_get(Para,1);
	
	gsl_vector_set(der,0, pow(fabs(Q),exp));
	gsl_vector_set(der,1, exp*P*pow(fabs(Q),exp-1));
	gsl_vector_set(der,2, 1);
	
	return GSL_SUCCESS;
}

//*******************************************
//*Sphere-Function
//*******************************************
double Sphere(double Q, void * ParaM)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	
	double	R       	=fabs(gsl_vector_get(Para,0));		// [A]      Radius
	double	RhoS    =gsl_vector_get(Para,1)*1e10;		// [cm^-2]  SLD of Sphere
	double	RhoE    =gsl_vector_get(Para,2)*1e10;		// [cm^-2]  SLD of Solution
	double	Phi     	=fabs(gsl_vector_get(Para,3));		// [1]      Volume Fraction
	double	Vo	=fabs(gsl_vector_get(Para,4));		// [cm^3]   Volume
	int		choice	=int(gsl_vector_get(Para,5));		// Choise: 0--> R and V  are  adjustable  
	// Choise: 1--> V=V(R) ==> V=4/3*PI*R^3        (V-fixed)
	// Choise: 2--> R=R(V) ==> R=(3/4*V/PI)^0.33   (R-fixed)
	double Back     =gsl_vector_get(Para,6);			// [cm^-1] Back
	
	if (choice==1) {Vo=4*M_PI/3*pow(R,3)*1E-24;};
	if (choice==2) {R=sqrt(3/4*Vo/M_PI*1e24);};
	
	const   double RQ       =R*Q;
	const   double RQ2      =RQ *RQ;
	const   double RQ3      =RQ2*RQ;
	const   double dRho2    =(RhoS-RhoE)*(RhoS-RhoE);   		// [cm^-4]  Scattering Contrast     
	const	double I0=dRho2*Vo*Phi;                       			// [cm^-1]  Forward Intensity I(0)
	
	// FS:   Form Factor of Sphere
	double FS;
	
	if (RQ>0) 
	{ FS=3*(sin(RQ)-RQ*cos(RQ))/RQ3;}
	else
	{ FS=1;};
	
	// Function    
	return I0*FS*FS+Back;
}

//*Sphere-Parameter-Derivative
int derSphere(double Q, void * ParaM, gsl_vector * der)
{
	gsl_vector  *Para=(gsl_vector *) ParaM;
	
	double	R       	=fabs(gsl_vector_get(Para,0));		// [A]      Radius
	double	RhoS    =gsl_vector_get(Para,1)*1e10;		// [cm^-2]  SLD of Sphere
	double	RhoE    =gsl_vector_get(Para,2)*1e10;		// [cm^-2]  SLD of Solution
	double	Phi     	=fabs(gsl_vector_get(Para,3));		// [1]      Volume Fraction
	double	Vo	=fabs(gsl_vector_get(Para,4));			// [cm^3]   Volume
	int		choice	=int(gsl_vector_get(Para,5));			// Choise: 0--> R and V  are  adjustable  
	// Choise: 1--> V=V(R) ==> V=4/3*PI*R^3        (V-fixed)
	// Choise: 2--> R=R(V) ==> R=(3/4*V/PI)^0.33   (R-fixed)
	
	const   double RQ       =R*Q;
	const   double RQ3       =RQ*RQ*RQ;
	const   double dRho2    =(RhoS-RhoE)*(RhoS-RhoE);   		// [cm^-4]  Scattering Contrast     
	const	double I0=dRho2*Vo*Phi;                       			// [cm^-1]  Forward Intensity I(0)
	
	double spheres=Sphere(Q,ParaM);
	
	if (choice==2) 
		gsl_vector_set(der,0,0);
	else
	{
		
		if (RQ>0) 
		{
			double FS=3*(sin(RQ)-RQ*cos(RQ))/RQ3;
			FS=I0*FS*FS*6/R*(sin(RQ)/RQ/FS-1);
			gsl_vector_set(der,0,FS);
		}
		else
		{ 
			gsl_vector_set(der,0,0);
		}	
		
	}
	
	gsl_vector_set(der,1,2/fabs(RhoS-RhoE)*spheres);
	gsl_vector_set(der,2,2/fabs(RhoS-RhoE)*spheres);
	gsl_vector_set(der,3,spheres/Phi);
	
	if (choice==1) 
		gsl_vector_set(der,4,0);
	else
		gsl_vector_set(der,4,spheres/Vo);
	
	gsl_vector_set(der,5,0);
	gsl_vector_set(der,6,1);
	
	return GSL_SUCCESS;
}
