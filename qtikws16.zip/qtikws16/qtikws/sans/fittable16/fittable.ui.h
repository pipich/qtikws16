/***************************************************************************
 File                 : fitTable10.ui.h
 Project             : QtiKWS
 --------------------------------------------------------------------
 Copyright            : (C) 2006-2016-... by Vitaliy Pipich
 Email (use @ for *)  : v.pipich*gmail.com
 Description          : Table(s) Fitting Interface
 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *  This program is free software; you can redistribute it and/or modify   *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation; either version 2 of the License, or      *
 *  (at your option) any later version.                                    *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the Free Software           *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor,                    *
 *   Boston, MA  02110-1301  USA                                           *
 *                                                                         *
 ***************************************************************************/

#include <gsl/gsl_blas.h>
#include <gsl/gsl_math.h> 
#include <gsl/gsl_vector.h>
#include <gsl/gsl_integration.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_multifit_nlin.h>
#include <gsl/gsl_multimin.h>
#include <gsl/gsl_errno.h>
#include <gsl/gsl_statistics.h> 
#include <gsl/gsl_spline.h>
#include <qdatetime.h> 
#include <qprocess.h> 
#include <qwidgetlist.h>
#include <qaction.h>
#include <qworkspace.h>
#include <qregexp.h>
#include <qinputdialog.h> 
#include <qaccel.h> 
#include <qprogressdialog.h>
#include <qfile.h>
#include <qmessagebox.h>
#include <qapplication.h>
#include <qlibrary.h>
#include <qfiledialog.h> 
#include <qtextstream.h> 
#include <qapplication.h>
#include <qprocess.h> 
#include <problem.h>
#include <genmin.h>
#include <get_options.h>
// +++
#include "../../src/application.h"
#include "../../src/note.h"
#include "../../src/folder.h"
#include "../../src/graph.h"
#include "../../src/plot.h"
#include "../../src/multilayer.h"
#include "../../src/FunctionCurve.h"
#include "../../src/colorBox.h"
#include "../compile10/compile10.h"
#include "../standart-functions/standartFunctions.h"
#include "fitting.h"

bool eFitWeight=false;

class TableItemC : public QTableItem
{
public:
    TableItemC(QTable *table, EditType et, const QString & text );
    int alignment() const { return Qt::AlignCenter;}
};

TableItemC::TableItemC(QTable *table, EditType et, const QString &text) : QTableItem(table, et, text){}

class TableItemL : public QTableItem
{
public:
    TableItemL(QTable *table, EditType et, const QString & text );
    int alignment() const { return Qt::AlignLeft;};
};

TableItemL::TableItemL(QTable *table, EditType et, const QString &text) : QTableItem(table, et, text){}


//*******************************************
//*** Log-output *** !OB
//*******************************************
void fittable::toResLog( QString text)
{    
    QDateTime dt = QDateTime::currentDateTime();
    QString info	=dt.toString("dd.MM | hh:mm ->>FIT::FIT>> ") ;
    info+=text;
    info+="\n";
    
    app(this)->logInfo+=info;
    app(this)->actionShowLog->setOn(true);
    app(this)->results->setText(app(this)->logInfo);	
    app(this)->results->scrollToBottom();	
}

//*******************************************
//*  Connect Slot
//*******************************************
void fittable::connectSlot()
{
    connect(tablePara->horizontalHeader(), SIGNAL(clicked(int)), this, SLOT(headerPressedTablePara(int)));
    connect(tablePara->verticalHeader(), SIGNAL(clicked(int)), this, SLOT(vertHeaderPressedTablePara(int)));
    connect(tableCurves->verticalHeader(), SIGNAL(clicked(int)), this, SLOT(vertHeaderTableCurves(int)));
    connect(tableCurves->horizontalHeader(), SIGNAL(clicked(int)), this, SLOT(horizHeaderCurves(int)));
    connect(tableMultiFit->horizontalHeader(), SIGNAL(clicked(int)), this, SLOT(headerTableMultiFit(int)));
    connect(tableMultiFit, SIGNAL(selectionChanged()), this, SLOT(selectRowsTableMultiFit()));
    connect( pushButtonFitPrev, SIGNAL( clicked() ), this, SLOT( slotStackFitPrev() ) );
    connect( pushButtonFitNext, SIGNAL( clicked() ), this, SLOT( slotStackFitNext() ) );
    connect( spinBoxPara, SIGNAL( valueChanged(int) ), tablePara, SLOT( setNumRows(int) ) );
    connect( checkBoxMultiData, SIGNAL( clicked() ), this, SLOT( initMultiParaTable() ) );
    connect( spinBoxNumberCurvesToFit, SIGNAL( valueChanged(int) ), this, SLOT( initMultiParaTable() ) );    
    connect( pushButtonChiSqr, SIGNAL( clicked() ), this, SLOT( plotSwitcher() ) );
    connect( tableCurves, SIGNAL(valueChanged(int,int) ), this, SLOT( tableCurvechanged(int,int) ) );
    connect( pushButtonMultiFit, SIGNAL( clicked() ), this, SLOT( fitSwitcher() ) );
    connect( lineEditAbsErr, SIGNAL( lostFocus() ), this, SLOT( lineValidator() ) );
    connect( lineEditRelErr, SIGNAL( lostFocus() ), this, SLOT( lineValidator() ) );
    connect( lineEditTolerance, SIGNAL( lostFocus() ), this, SLOT( lineValidator() ) );
    connect( spinBoxPara, SIGNAL( valueChanged(int) ), tableParaComments, SLOT( setNumRows(int) ) );
    connect( pushButtonresToLogWindow, SIGNAL( clicked() ), this, SLOT( resToLogWindow() ) );
    connect( pushButtonNewTabRes, SIGNAL( clicked() ), this, SLOT( newTabRes() ) );
    connect( pushButtonNewTabResCol, SIGNAL( clicked() ), this, SLOT( newTabResCol() ) );
    
    connect( comboBoxPolyFunction, SIGNAL( activated(int) ), this, SLOT( SDchanged(int) ) );
    connect( comboBoxPolyFunction_2, SIGNAL( activated(int) ), this, SLOT( SDchanged(int) ) );
    
    connect( comboBoxWeightingMethod, SIGNAL( activated(int) ), this, SLOT( weightChanged() ) );
    connect( checkBoxSANSsupport, SIGNAL( clicked() ), this, SLOT( SANSsupportYN() ) );
    connect( comboBoxInstrument, SIGNAL( activated(const QString&) ), this, SLOT( SANSsupportYN() ) );
    connect( checkBoxSuperpositionalFit, SIGNAL( clicked() ), this, SLOT( SuperpositialFitYN() ) );    
    
    
    connect( spinBoxPara, SIGNAL( valueChanged(int) ), tableParaSimulate, SLOT( setNumRows(int) ) );    
    connect( listBoxGroup, SIGNAL( highlighted(const QString&) ), this, SLOT( groupFunctions(const QString&) ) );
    
    connect( checkBoxShowEFIT, SIGNAL( clicked() ), this, SLOT( updateEFunctions() ) );
    
    connect( listBoxFunctions, SIGNAL( highlighted(const QString&) ), this, SLOT( openDLL(const QString&) ) );
    connect( pushButtonSimulate, SIGNAL( clicked() ), this, SLOT( simulateSwitcher() ) );
    connect( pushButtonPattern, SIGNAL( clicked() ), this, SLOT( selectPattern() ) );
    connect( pushButtonSetBySetFit, SIGNAL( clicked() ), this, SLOT( setBySetFit() ) );
    connect( tableMultiFit, SIGNAL( valueChanged(int,int) ), this, SLOT( changedSetToSet(int,int) ) );
    connect( pushButtonSimulateMulti, SIGNAL( clicked() ), this, SLOT( simulateMultifitTables() ) );
    connect( pushButtonSimulateDelete, SIGNAL( clicked() ), this, SLOT( removeSimulatedDatasets() ) );
    connect( radioButtonUniform_Q, SIGNAL( toggled(bool) ), this, SLOT( uniformSimulChanged(bool) ) );
    connect(radioButtonSameQrange, SIGNAL( toggled(bool) ), this, SLOT( theSameSimulChanged(bool) ) );
    connect( comboBoxDatasetSim, SIGNAL( highlighted(int) ), this, SLOT( datasetChangedSim(int) ) );
    
    connect( comboBoxSimQN, SIGNAL( highlighted(int) ), this, SLOT( dataLimitsSimulation(int) ) );
    
    connect( pushButtonresToActiveGraph, SIGNAL( clicked() ), this, SLOT( addFitResultToActiveGraph() ) );
    connect( pushButtonresToLogWindowOne, SIGNAL( clicked() ), this, SLOT( resToLogWindowOne() ) );
    connect( pushButtonSaveSession, SIGNAL( clicked() ), this, SLOT( saveFittingSession() ) );
    connect( pushButtonUndo, SIGNAL( clicked() ), this, SLOT( undo() ) );
    connect( pushButtonRedo, SIGNAL( clicked() ), this, SLOT( redo() ) );
    connect( lineEditSetBySetFit, SIGNAL( returnPressed() ), this, SLOT( setBySetFit() ) );
    connect( tablePara, SIGNAL( verticalSliderReleased() ), this, SLOT( tableParaRepaint() ) );
    connect( pushButtonHelp, SIGNAL( clicked() ), this, SLOT( openHelpOnline() ) );
    connect( pushButtonDeleteCurves, SIGNAL( clicked() ), this, SLOT( removeSimulatedDatasets() ) );
    connect( pushButtonSelectFromTable, SIGNAL( clicked() ), this, SLOT( selectMultyFromTable() ) );
    connect( tablePara, SIGNAL( valueChanged(int,int) ), this, SLOT( checkGlobalParameters(int,int) ) );
    connect( comboBoxSpeedControlReso, SIGNAL( activated(const QString&) ), this, SLOT( speedControlReso() ) );
    connect( comboBoxSpeedControlPoly, SIGNAL( activated(const QString&) ), this, SLOT( speedControlPoly() ) );
    connect( comboBoxPolyFunction, SIGNAL( activated(const QString&) ), this, SLOT( speedControlPoly() ) );
    connect( comboBoxResoFunction, SIGNAL( activated(const QString&) ), this, SLOT( speedControlReso() ) );
    connect( pushButtonLoadFittingSession, SIGNAL( clicked() ), this, SLOT( readSettingsTable() ) );    
    connect( comboBoxFitMethod , SIGNAL( activated(const QString&) ), this, SLOT( algorithmSelected() ) );     
    
    connect( toolButtonResetLimits, SIGNAL( clicked() ), this, SLOT( initLimits() ) );
    connect( toolButtonApplyLimits, SIGNAL( clicked() ), this, SLOT( setScaledLimits() ) );  
    connect( pushButtonINITbefore, SIGNAL( clicked() ), this, SLOT( initParametersBeforeFit() ) );
    connect( pushButtonINITafter, SIGNAL( clicked() ), this, SLOT( initParametersAfterFit() ) );
    
    connect( pushButtonIFIT, SIGNAL( clicked() ), this, SLOT( iFit() ) );
    connect( pushButtonIFITadv, SIGNAL( clicked() ), this, SLOT( iFitAdv() ) );	
    
    
    connect( pushButtonSimulateSuperpositional, SIGNAL( clicked() ), this, SLOT( simulateSuperpositional() ) );	
    connect( pushButtonSimulateSuperpositionalRes, SIGNAL( clicked() ), this, SLOT( simulateSuperpositional() ) );	
        
    connect( comboBoxFunction, SIGNAL( activated(const QString&) ), this, SLOT( changeFunctionLocal(const QString&) ) );   
    //+++ cleanning 
    connect( pushButtonFitCurveDelete, SIGNAL( clicked() ), this, SLOT( removeFitCurve() ) );
    connect( pushButtonSimulatedCurveDelete, SIGNAL( clicked() ), this, SLOT( removeSimulatedCurve() ) );
    connect( pushButtonGlobalDelete, SIGNAL( clicked() ), this, SLOT( removeGlobal() ) );
    
    connect( textLabelRangeFirst, SIGNAL( lostFocus() ), this, SLOT( rangeFirstCheck() ) );
    connect( textLabelRangeLast, SIGNAL( lostFocus() ), this, SLOT( rangeLastCheck() ) );
}

//*******************************************
//*Initiation-of-Fitting-Dialog
//*******************************************
void fittable::init()
{    
    //+++
    libName="";
    //+++
    XQ="x";
    //+++
    QDir dd;
    
    dd.cd(QDir::homeDirPath());
    dd.cd("./qtiKWS/FitFunctions");  
    libPath=dd.path();
    scanGroup(); 
    
    //+++ Interface of first page
    textLabelFfunc->hide();                          
    comboBoxPolyFunction_2->hide();
    comboBoxFunction->hide();
    
    textLabelLeft->setEnabled(false);
    pushButtonFitPrev->setEnabled(false);
    spinBoxPara->hide();
    
    //+++ initial options
    pF=0;
    int p=0;
    pSANS=0;
    
    //+++ Para-Table******************
    tablePara->setColumnWidth(0,1);
    tablePara->setColumnWidth(1,45);
    tablePara->setColumnWidth(2,95);
    tablePara->setColumnWidth(3,95);
    
    //+++ Para-Comment******************
    tableParaComments->setLeftMargin(100);
    tableParaComments->setColumnStretchable (0, TRUE);
    tableParaComments00->setLeftMargin(100);
    tableParaComments00->setColumnStretchable (0, TRUE);
    
    // +++ color boxes
    initColorBox();
        
    weightChanged();    
    pushButtonLoadFittingSession->setGeometry(10, 3, 490, 30);
    setToSetProgressControl=false;
    algorithmSelected();
    
    //+++ Connections
    connectSlot();
    
    //+++ Control-Table******************
    tableControl->setColumnWidth(0,95);
    tableControl->setColumnWidth(1,60);
    tableControl->setColumnWidth(2,115);
    tableControl->setColumnWidth(3,60);    
    tableControl->setColumnWidth(4,95);    
    tableControl->setTopMargin(0);
    tableControl->setLeftMargin(0);
    tableControl->setRowHeight(1,50);    
    tableControl->setColumnStretchable(2,true);
    
    spinBoxNumberCurvesToFit->setEnabled(false); 
    pushButtonSaveSession->hide(); 
    comboBoxInstrument->setEnabled(false);	
    SuperpositialFitYN();    
}

//*******************************************
//*Init Fitting Page
//*******************************************
void fittable::initLimits()
{
    //+++
    int PP=spinBoxPara->value();
    
    //+++
    tableControl->setNumRows(0);	
    tableControl->setNumRows(PP);    
    
    //+++
    int digits=spinBoxSignDigits->value();
    
    //+++
    QStringList ccc;
    ccc<<"=<";
    
    double leftLimit, rightLimit;
    QString s;
    
    for(int pp=0; pp<PP; pp++)	
    {
	//***
	TableItemL *lefted = new TableItemL(tableControl, QTableItem::OnTyping, "-1.0E308");
	tableControl->setItem(pp,0,lefted);
	
	QComboTableItem *cL = new QComboTableItem(tableControl, QString::null );
	tableControl->setItem(pp,1, cL);	
	
	cL->setStringList(ccc);		
	//***
	QComboTableItem *cR = new QComboTableItem(tableControl, QString::null );
	tableControl->setItem(pp,3, cR);
	tableControl->setText(pp,4, "1.0E308");	
	cR->setStringList(ccc);	
	
	TableItemC *centred = new TableItemC(tableControl, QTableItem::OnTyping, F_paraList[pp]);
	tableControl->setItem(pp,2, centred);
	
	s=F_initValues[pp];
	
	if (s.contains('[') && s.contains("..") && s.contains(']'))	    
	{
	    leftLimit=s.mid(s.find("[")+1,s.find("..")-s.find("[") - 1 ).toDouble();
	    rightLimit=s.mid(s.find("..")+2,s.find("]")-s.find("..") - 2 ).toDouble();
	    
	    tableControl->setText(pp,0,QString::number(leftLimit));
	    tableControl->setText(pp,4,QString::number(rightLimit));	    
	}
    }
    if (checkBoxSANSsupport->isChecked() && comboBoxInstrument->currentItem()==0)
    {
	tableControl->setText(PP-4,0,"0");
	tableControl->setText(PP-3,0,"0");
	tableControl->setText(PP-2,0,"0");
	tableControl->setText(PP-1,0,"0");
    }
}

//*******************************************
//*Init Fitting Page !OB
//*******************************************
void fittable::chekLimits()
{
    //+++
    int PP=spinBoxPara->value();
    
    double leftV;
    double rightV;
    
    for(int pp=0; pp<PP; pp++)	
    {
	leftV=	-1.0E308;
	rightV=	1.0E308;
	
	if (tableControl->text(pp,1).contains("<")) leftV=tableControl->text(pp,0).toDouble();
	if (tableControl->text(pp,3).contains("<")) rightV=tableControl->text(pp,4).toDouble();
	if (rightV<leftV)
	{
	    leftV=	-1.0E308;
	    rightV=1.0E308;
	}
	
	tableControl->setText(pp,0,QString::number(leftV));
	tableControl->setText(pp,4,QString::number(rightV));	
    }
}

//*******************************************
//*Init Fitting Page 
//*******************************************
void fittable::chekLimitsAndFittedParameters()
{
    int M=spinBoxNumberCurvesToFit->value();		// Number of Curves
    int p=spinBoxPara->value();				//Number of Parameters per Curve
    
    double leftV;
    double rightV;
    double currentValue;
    
    //+++ Parameters && Sharing && Varying 
    for (int pp=0; pp<p;pp++) 
    {
	leftV=-1.0E308;
	rightV=1.0E308;
	if (tableControl->text(pp,1).contains("<")) leftV=tableControl->text(pp,0).toDouble();
	if (tableControl->text(pp,3).contains("<")) rightV=tableControl->text(pp,4).toDouble();
	
	for (int mm=0; mm<M;mm++)
	{
	    QCheckTableItem *itA0 = (QCheckTableItem *)tablePara->item(pp,3*mm+1); // Vary?	
	    
	    if (itA0->isChecked()) 
	    {		
		currentValue=tablePara->text(pp,3*mm+2).toDouble();
		if (currentValue<leftV) currentValue=leftV;
		if (currentValue>rightV) currentValue=rightV;
	    }
	}
	
    }
    
}

//*******************************************
//* Init Fitting Page
//*******************************************
void fittable::setScaledLimits()
{
    int p=spinBoxPara->value();				//Number of Parameters per Curve
    
    double leftFactor=lineEditLeftMargin->text().toDouble();
    leftFactor=fabs(leftFactor);
    
    double rightFactor=lineEditRightMargin->text().toDouble();
    rightFactor=fabs(rightFactor);
    
    double currentParameter;
    
    for(int i=0;i<p;i++)
    {
	currentParameter=tablePara->text(i,2).toDouble();
	//+++
	if (leftFactor<=1) leftFactor=2;
	
	if (currentParameter>0)
	{	
	    tableControl->setText(i,0,QString::number(currentParameter/leftFactor));
	}
	else if  (currentParameter<0)
	{
	    tableControl->setText(i,0,QString::number(currentParameter*leftFactor));
	}
	else
	{
	    tableControl->setText(i,0,QString::number(-leftFactor));
	}
	
	if (rightFactor<=1) rightFactor=2;
	
	if (currentParameter>0)
	{
	    tableControl->setText(i,4,QString::number(currentParameter*rightFactor));
	}
	else if  (currentParameter<0)
	{
	    tableControl->setText(i,4,QString::number(currentParameter/rightFactor));
	} 
	else
	{
	    tableControl->setText(i,4,QString::number(rightFactor));
	}
    }    
}

//*******************************************
//* init Multi-Table
//*******************************************
void fittable::initMultiParaTable()
{
    int i,j;
    
    int p=spinBoxPara->value();
    
    if (!checkBoxMultiData->isChecked())
    {
	
	
	//	spinBoxNumberCurvesToFit->hide();
	spinBoxNumberCurvesToFit->setEnabled(false);
	tablePara->setNumCols(4);
	tablePara->setColumnWidth(0,1);
	tablePara->setColumnWidth(1,46);
	tablePara->setColumnWidth(2,135);
	tablePara->setColumnWidth(3,135);
	spinBoxNumberCurvesToFit->setValue(1);
	
	tablePara->setColumnStretchable (2, TRUE);
    }
    else
    {
	
	spinBoxNumberCurvesToFit->show();
	spinBoxNumberCurvesToFit->setEnabled(true);	
	tablePara->setColumnStretchable (2, FALSE);
	tablePara->setColumnWidth(2,135);
	
	tablePara->setNumCols(4);
	tablePara->setColumnWidth(0,52);
	QStringList colNames;
	colNames<<"Share?"<<"Vary?"<<"Value-01"<<"Error-01";
	for (j=0;j<p;j++)
	{
	    QCheckTableItem *cb = new QCheckTableItem(tablePara, QString::null );
	    tablePara->setItem(j,0, cb); 
	}		
	for (i=0;i<(spinBoxNumberCurvesToFit->value()-1); i++ )
	{	    
	    if ((i+2)>=10) colNames<<"Vary?"<<"Value-"+QString::number(i+2)<<"Error-"+QString::number(i+2);
	    else colNames<<"Vary?"<<"Value-0"+QString::number(i+2)<<"Error-0"+QString::number(i+2);
	    tablePara->insertColumns(4+3*i,3);
	    tablePara->setColumnWidth(3*(i+1)+1,48);
	    tablePara->setColumnWidth(3*(i+1)+2,90);
	    tablePara->setColumnWidth(3*(i+1)+3,90);
	    for (j=0;j<p;j++)
	    {
		QCheckTableItem *cb = new QCheckTableItem(tablePara, QString::null );
		tablePara->setItem(j,3*(i+1)+1, cb);
	    }		
	}
	tablePara->setColumnLabels(colNames);
    }
}

//*******************************************
//*Init Fitting Page !OB
//*******************************************
void fittable::initFitPage()
{
    int id=widgetStackFit->id(widgetStackFit->visibleWidget ());
    int M=spinBoxNumberCurvesToFit->value(); 
    
    int mm,pp;
    QStringList colNames, iQlist;
    iQlist<<"N"<<XQ;
    
    textLabelfromQsim->setText(XQ+"[min]=");
    textLabelToQsim->setText(XQ+"[max]=");
    radioButtonUniform_Q->setTitle("Uniform "+XQ+":: Range");
    
    textLabelfromQ->setText(XQ+"[min]=");
    textLabelToQ->setText(XQ+"[max]=");
    radioButtonSameQrange->setTitle("Same "+XQ+" as Fitting Data");
    
    QString s;
    double temp;
    
    //+++ Initiation of multi-Set Tables
    initMultiParaTable();
    
    
    if (id==0)
    {
	//+++ tableCurves  SANS supportf
	QStringList tableCurvesNames;
	QStringList tableCurvesNamesSimulate;
	
	//+++
	tableCurvesNames<<"Data Set(s)"<<"N"<<"First Point"<<"Last Point"<<"Weighting";
	tableCurvesNamesSimulate<<"Begin"<<"End"<<"# points"<<"Data Set(s)";
	
	if (checkBoxSANSsupport->isChecked()) 
	{
	    QString currentInstrument=comboBoxInstrument->currentText();
	    if ( currentInstrument.contains("SANS") )
	    {
		//+++
		tableCurvesNames<<"Resolution"<<"Polydispersity";
		tableCurvesNamesSimulate<<"Resolution"<<"Polydispersity";
		tableCurves->setNumRows(7);
		tableCurves->setLeftMargin(90);
	    }
	    else if ( currentInstrument.contains("Back-Scattering") )
	    {
		//+++
		tableCurvesNames<<"Resolution";
		tableCurvesNamesSimulate<<"Resolution";
		tableCurves->setNumRows(6);
		tableCurves->setLeftMargin(90);
	    }
	}
	else
	{
	    //+++
	    tableCurves->setNumRows(5);
	    tableCurves->setLeftMargin(70);
	}
	
	//+++
	tableCurves->setRowLabels(tableCurvesNames);
	tableCurves->setNumCols(2*M); 
	
	
	//+++ Set Data-Sets List
	for(mm=0;mm<M;mm++)		
	{
	    tableCurves->setColumnWidth(2*mm,46);	
	    
	    if (M==1) 
	    {
		tableCurves->setColumnStretchable (1, TRUE);
	    }
	    else  if (M==2) 
	    {
		tableCurves->setColumnStretchable (2*mm+1, TRUE);	  
	    }
	    else
	    {
		tableCurves->setColumnStretchable (1, FALSE);
		tableCurves->setColumnStretchable (3, FALSE);
		tableCurves->setColumnWidth(2*mm+1,135);
	    }
	    
	    colNames<<"Use?"<<"Curve-"+QString::number(mm+1);
	    
	    //++ tableCurves: 2*mm   
	    
	    //+++ Q or N select
	    QComboTableItem *iQ = new QComboTableItem(tableCurves, QString::null );
	    tableCurves->setItem(1,2*mm, iQ);
	    iQ->setStringList(iQlist);
	    
	    //+++ CheckTableItem: N/Qmin fix?
	    QCheckTableItem *cbImin = new QCheckTableItem(tableCurves, QString::null );
	    tableCurves->setItem(2,2*mm, cbImin);
	    
	    //+++ CheckTableItem: N/Qmax Fix?
	    QCheckTableItem *cbImax = new QCheckTableItem(tableCurves, QString::null );
	    tableCurves->setItem(3,2*mm, cbImax);
	    
	    //+++ CheckTableItem: Weighting
	    QCheckTableItem *cbW = new QCheckTableItem(tableCurves, QString::null );
	    tableCurves->setItem(4,2*mm, cbW);
	    
	    if (eFitWeight) cbW->setChecked(true);
	    
	    //+++ If with SANS support
	    if (checkBoxSANSsupport->isChecked()) 
	    {
		//+++ CheckTableItem: IncludeResolution
		QCheckTableItem *cbR = new QCheckTableItem(tableCurves, QString::null );
		tableCurves->setItem(5,2*mm, cbR);
		
		QString currentInstrument=comboBoxInstrument->currentText();
		if ( currentInstrument.contains("SANS") )
		{
		    //+++ CheckTableItem: Include polydispersity
		    QCheckTableItem *cbP = new QCheckTableItem(tableCurves, QString::null );
		    tableCurves->setItem(6,2*mm, cbP);
		}
	    }
	    
	    //+++ tableCurves: 2*mm+1
	    
	    //+++ Data sets selection ComboBox
	    QString oldYcol="";
	    if ((QComboTableItem*)tableCurves->item (0, 2*mm+1))
	    {QComboTableItem *xxx =(QComboTableItem*)tableCurves->item (0, 2*mm+1);
		oldYcol=xxx->currentText();}
	    QComboTableItem *curve = new QComboTableItem(tableCurves, QString::null );
	    tableCurves->setItem(0,2*mm+1, curve);
	    curve->setStringList(app(this)->columnsList(Table::Y));
	    if (oldYcol!="") curve->setCurrentItem(oldYcol);
	    
	    //+++ Weight Set selection CimboBox 
	    QComboTableItem *weight = new QComboTableItem(tableCurves, QString::null );
	    tableCurves->setItem(4,2*mm+1, weight);
	    
	    //+++ If with  SANS support 
	    if (checkBoxSANSsupport->isChecked()) 
	    {
		//+++ select resolution data-set
		QComboTableItem *reso = new QComboTableItem(tableCurves, QString::null );
		tableCurves->setItem(5,2*mm+1, reso);
		
		QString currentInstrument=comboBoxInstrument->currentText();	    
		if ( currentInstrument.contains("SANS") )
		{
		    //+++ Select polydispersity data-set
		    QComboTableItem *poly = new QComboTableItem(tableCurves, QString::null );
		    poly->setStringList(F_paraListF);
		    tableCurves->setItem(6,2*mm+1, poly);
		}
	    }
	    
	    QString table=curve->currentText();
	    table=table.left(table.find("_",0));
	    
	    //+++ Fill weight, reso, poly , data sets combo-boxes
	    colList(table,2*mm+1);
	}			
	
	//+++ Set Column Labels 
	tableCurves->setColumnLabels(colNames);	    
    }
    else
    {
	
	//+++ Set Data-Sets List
	for(mm=0;mm<M;mm++)		
	{
	    //+++ Q or N select
	    QComboTableItem *iQ =(QComboTableItem*)tableCurves->item (1, 2*mm);
	    int currentItem=iQ->currentItem();
	    iQ->setStringList(iQlist);	
	    iQ->setCurrentItem(currentItem);
	    
	    //+++ If with  SANS support 
	    if (checkBoxSANSsupport->isChecked()) 
	    {
		QString currentInstrument=comboBoxInstrument->currentText();	    
		if ( currentInstrument.contains("SANS") )
		{
		    //+++ Select polydispersity data-set
		    QComboTableItem *poly = new QComboTableItem(tableCurves, QString::null );
		    poly->setStringList(F_paraListF);
		    tableCurves->setItem(6,2*mm+1, poly);
		}
	    }
	    
	}
    }
    
    //+++ Set Table Labels 
    tablePara->setRowLabels(F_paraList);
    tablePara->verticalHeader()->adjustHeaderSize(); 
    //+++ Set Table Labels Simulate
    tableParaSimulate->setRowLabels(F_paraList);
    tableParaSimulate->setLeftMargin (130);
    tableParaSimulate->setColumnStretchable (0, TRUE);
    //+++ Comment table
    tableParaComments->setRowLabels(F_paraList);
    
    //+++ Function description 
    if (F_paraListComments.count() ==0) 
	textBrowserFunctionDescription->setText("<center>...sorry, but no description of Function is available...</center>"); 
    else 
	textBrowserFunctionDescription->setText(F_paraListComments[0]); 
    
    //
    int PP=spinBoxPara->value();
    
    //    
    int digits=spinBoxSignDigits->value()-1;
    for(pp=0; pp<PP; pp++)	
    {
	s=F_initValues[pp];
	
	if (s.contains('[') && s.contains("..") && s.contains(']'))	    
	{
	    temp=s.left(s.find("[")).toDouble();
	}
	else
	    temp=s.toDouble();
	
	for (mm=0; mm<M;mm++)
	{
	    tablePara->setText(pp,3*mm+2,QString::number(temp, 'G', digits+1));
	    tablePara->setText(pp,3*mm+3,"---");
	    
	    QCheckTableItem *cb = new QCheckTableItem(tablePara, QString::null );
	    tablePara->setItem(pp,3*mm+1, cb);
	    
	    if (F_adjustPara[pp]=="1") cb->setChecked(true); else cb->setChecked(false);
	}
	gsl_vector_set(F_para,pp,s.toDouble());
	
	//Comment table
	if (F_paraListComments.count() <= 1) tableParaComments->setText(pp,0,"sorry, but no description available"); 
	else tableParaComments->setText(pp,0,F_paraListComments[pp+1]); 
    }
    
    
    //+++ 
    bool polyYN=false;
    int polyFunction=comboBoxPolyFunction->currentItem();
    //+++ 
    bool beforeFit=false;
    bool afterFit=false;
    bool beforeIter=false;
    bool afterIter=false;
    
    double *Qq=new double[1]; Qq[0]=0.0;
    double *Ii=new double[1]; Ii[0]=0.0;
    double *SIGMAsigma=new double[1];SIGMAsigma[0]=-1.0;
    
    int currentFirstPoint=0;
    int currentLastPoint=0;
    int currentPoint=0;
    
    int prec=spinBoxSignDigits->value();
    
    //+++ ,tableName,tableColNames,tableColDestinations,mTable
    std::string tableName="no-matrix";
    std::string *tableColNames; 
    int *tableColDestinations; 
    gsl_matrix * mTable;
    
    functionT paraT={F_para, Qq, Ii, SIGMAsigma, currentFirstPoint, currentLastPoint, currentPoint, polyYN, polyFunction, beforeFit, afterFit, beforeIter, afterIter, 1.0, 1.0, 1.0, 0, prec,tableName,tableColNames,tableColDestinations,mTable};
    
    
    F.params=&paraT;     
    delete[] Qq; 
    delete[] Ii; 
    delete[] SIGMAsigma;
}

//*******************************************
// +++ init Color Boxes !OB
//*******************************************
void fittable::initColorBox()
{   
    QPixmap icon = QPixmap(28, 14);
    
    icon.fill (QColor (Qt::red) );
    comboBoxColor->insertItem(icon, tr( "red" ) );
    icon.fill (QColor (Qt::green) );
    comboBoxColor->insertItem(icon, tr( "green" ) );
    icon.fill (QColor (Qt::blue) );
    comboBoxColor->insertItem(icon, tr( "blue" ) );
    icon.fill (QColor (Qt::cyan) );
    comboBoxColor->insertItem(icon, tr( "cyan" ) );
    icon.fill (QColor (Qt::magenta) );
    comboBoxColor->insertItem(icon, tr( "magenta" ) );
    icon.fill (QColor (Qt::yellow) );
    comboBoxColor->insertItem(icon, tr( "yellow" ) );
    icon.fill (QColor (Qt::darkYellow) );
    comboBoxColor->insertItem(icon, tr( "dark yellow" ) );
    icon.fill (QColor (Qt::darkBlue) );
    comboBoxColor->insertItem(icon, tr( "navy" ) );
    icon.fill (QColor (Qt::darkMagenta) );
    comboBoxColor->insertItem(icon, tr( "purple" ) );  
    icon.fill (QColor (Qt::darkRed) );
    comboBoxColor->insertItem(icon, tr( "wine" ) ); 
    icon.fill (QColor (Qt::darkGreen) );
    comboBoxColor->insertItem(icon, tr( "olive" ) );
    icon.fill (QColor (Qt::darkCyan) );
    comboBoxColor->insertItem(icon, tr( "dark cyan" ) );
    icon.fill (QColor (Qt::white) );
    comboBoxColor->insertItem(icon,tr( "white" ) );
    icon.fill (QColor (Qt::lightGray) );
    comboBoxColor->insertItem(icon, tr( "light gray" ) );
    icon.fill (QColor (Qt::darkGray) );
    comboBoxColor->insertItem(icon, tr( "dark gray" ) ); 
    icon.fill ( QColor (Qt::black) );
    comboBoxColor->insertItem(icon, tr( "black" ) );
    
}

//*******************************************
// +++ init Multi Table  !OB
//*******************************************
void fittable::initMultiTable()
{
    if (spinBoxNumberCurvesToFit->value()==1)
    {
	int cols=spinBoxPara->value()+3;
	
	if (checkBoxSANSsupport->isChecked()) 
	{
	    cols++;
	}
	
	tableMultiFit->setNumCols(cols);
	tableMultiFit->setNumRows(1);
	
	
	tableMultiFit->setColumnWidth(0,30);
	
	int i;
	
	for (i=1;i<cols;i++)
	{
	    tableMultiFit->setColumnWidth(i,60);
	    // +++
	    QCheckTableItem *yn = new QCheckTableItem(tableMultiFit, QString::null );
	    tableMultiFit->setItem(0,i, yn);
	}
	
	// +++ mke Buttoms active
	pushButtonPattern->setEnabled(true);
	pushButtonSetBySetFit->setEnabled(true);
	pushButtonSimulateMulti->setEnabled(true);
	pushButtonSelectFromTable->setEnabled(true);
	
    }
    else
    {
	tableMultiFit->setNumCols(0);
	tableMultiFit->setNumRows(1);
	// +++ mke Buttoms active
	pushButtonPattern->setEnabled(false);
	pushButtonSetBySetFit->setEnabled(false);
	pushButtonSimulateMulti->setEnabled(false);
	pushButtonSelectFromTable->setEnabled(false);
    }
}

//*******************************************
//*Page-to-Page !OB
//*******************************************
void fittable::slotStackFitPrev()
{
    int id=widgetStackFit->id(widgetStackFit->visibleWidget ());
    
    widgetStackFit->raiseWidget(id-1);
    
    if (id==1)
    {
	
	widgetStackFit->setMinimumHeight(300);
	
	textLabelLeft->setText("...");
	textLabelCenter->setText("Select Function");
	textLabelRight->setText("Fitting Session");
	textLabelFfunc->hide();
	comboBoxPolyFunction_2->hide();
	comboBoxFunction->hide();
	
	textLabelLeft->setEnabled(false);
	pushButtonFitPrev->setEnabled(false);
	spinBoxPara->hide();
	//+++
	pushButtonUndo->setEnabled(FALSE);
	pushButtonRedo->setEnabled(FALSE);
	undoRedo.clear();
	undoRedoActive=0;
	pushButtonLoadFittingSession->show();
	textLabelInfoSAS->show();
	textLabelInfo_2_2->show();
	textLabelInfo_2->show();
	pushButtonHelp->show();
	
	//+++	listBoxGroup->setCurrentItem(0);
	
	pushButtonSaveSession->hide();
	
	
	if(comboBoxFunction->currentItem()!=listBoxFunctions->currentItem()) listBoxFunctions->setCurrentItem(comboBoxFunction->currentItem());
	
    }
    else if (id==2)
    {	
	textLabelLeft->setText("Select Function");
	textLabelCenter->setText("Fitting Session");	
	textLabelRight->setText("Generate Results");
	textLabelLeft->setEnabled(TRUE);
	pushButtonFitPrev->setEnabled(true);
	textLabelRight->setEnabled(true);
	pushButtonFitNext->setEnabled(true);
	pushButtonLoadFittingSession->hide();
	textLabelInfoSAS->hide();
	textLabelInfo_2_2->hide();
	textLabelInfo_2->hide();
	pushButtonHelp->hide();	
	comboBoxDatasetSim->clear();
	
	updateDatasets();
    }
}

//*******************************************
//*Page-to-Page 
//*******************************************
bool fittable::slotStackFitNext()
{
    int id=widgetStackFit->id(widgetStackFit->visibleWidget ()); 
    
    int p=spinBoxPara->value();
    
    if (id==0) 
    {
	
	if (checkBoxSuperpositionalFit->isChecked()) 
	{
	    pushButtonSimulateSuperpositional->show(); 
	    pushButtonSimulateSuperpositionalRes->show(); 
	}
	else 
	{
	    pushButtonSimulateSuperpositional->hide();
	    pushButtonSimulateSuperpositionalRes->hide();
	}
	
	if (checkBoxSANSsupport->isChecked()) widgetStackFit->setMinimumHeight(400);
	else widgetStackFit->setMinimumHeight(300);
	//+++
	initLimits();
	
	
	QString currentInstrument=comboBoxInstrument->currentText();	    
	if (checkBoxSANSsupport->isChecked() && currentInstrument.contains("SANS") )
	{
	    toolBoxResoPoly->show();
	    comboBoxPolyFunction_2->show();
	}
	else if (checkBoxSANSsupport->isChecked() && currentInstrument.contains("Back") )
	{    
	    toolBoxResoPoly->show();
	    comboBoxPolyFunction_2->hide();
	}
	else
	{
	    toolBoxResoPoly->hide();
	    comboBoxPolyFunction_2->hide();
	}
	
	
	if (p==0) 
	{
	    QMessageBox::warning(this ,tr("QtiKWS "),
				 tr("Select Function!"));
	    return false;
	}
	initFitPage();
	textLabelLeft->setText("Select Function");
	textLabelCenter->setText("Fitting Session");
	textLabelRight->setText("Generate Results");
	
	textLabelFfunc->show();
	comboBoxFunction->clear();
	
	QStringList lst;
	for(int i=0;i<listBoxFunctions->count();i++) lst<<listBoxFunctions->text(i);
	comboBoxFunction->insertStringList(lst);
	
	comboBoxFunction->setCurrentItem(listBoxFunctions->currentItem());
	comboBoxFunction->show();	
	
	if (checkBoxSANSsupport->isChecked() && currentInstrument.contains("SANS") )
	{
	    comboBoxPolyFunction_2->show();
	}
	
	textLabelLeft->setEnabled(TRUE);
	pushButtonFitPrev->setEnabled(true);	
	
	textLabelRight->setEnabled(true);	
	pushButtonFitNext->setEnabled(true);	
	spinBoxPara->show();
	// +++
	initMultiTable();
	// +++
	if (checkBoxSANSsupport->isChecked() && currentInstrument.contains("SANS") )
	{
	    checkBoxResoSim->show();
	    checkBoxPolySim->show();
	}
	else if (checkBoxSANSsupport->isChecked() && currentInstrument.contains("Back") )
	{
	    checkBoxResoSim->show();
	    checkBoxPolySim->hide();
	}
	else
	{	    
	    checkBoxResoSim->hide();
	    checkBoxPolySim->hide();
	}
	
	//+++
	checkBoxResoSim->setChecked(false);
	checkBoxPolySim->setChecked(false);
	radioButtonUniform_Q->setChecked(false);
	radioButtonSameQrange->setChecked(true);
	//~~~
	saveUndo();
	//+++
	pushButtonLoadFittingSession->hide();
	textLabelInfoSAS->hide();
	textLabelInfo_2_2->hide();
	textLabelInfo_2->hide();
	pushButtonHelp->hide();
	
	pushButtonSaveSession->show();
	spinBoxFnumber->setValue(spinBoxNumberCurvesToFit->value());
	
	buttonGroupNavigator->show();	
	algorithmSelected();
    }
    else if (id==1)
    {
	//+++  maneger
	textLabelLeft->setText("Fitting Session");
	textLabelCenter->setText("Generate Results");
	textLabelRight->setText("...");
	textLabelLeft->setEnabled(TRUE);
	pushButtonFitPrev->setEnabled(true);	
	textLabelRight->setEnabled(FALSE);	
	pushButtonFitNext->setEnabled(FALSE);	
	
	//+++ Simulate
	datasetChangedSim(0);	
	
	// +++ multifit
	int cols=spinBoxPara->value()+3;
	
	QStringList colNames;
	colNames<<"fit?"<<"[Y::Set]"<<"[Weight]";
	if (checkBoxSANSsupport->isChecked()) 
	{
	    cols+=1;		
	    colNames<<"[Reso]";
	}
	colNames+=F_paraList;
	
	tableMultiFit->setColumnLabels(colNames);
	pushButtonLoadFittingSession->hide();
	textLabelInfoSAS->hide();
	textLabelInfo_2_2->hide();
	textLabelInfo_2->hide();
	pushButtonHelp->hide();
    }
    widgetStackFit->raiseWidget(id+1); 
    return true;
}

//*******************************************
//*Curve-is-selected 
//*******************************************
void fittable::slotCurveList(Graph *g)
{
    slotSetCurveList(g->curvesList(), app(this)->columnsList(Table::Y) );
}

//*******************************************
//*Set-Curve-List
//*******************************************
void fittable::slotSetCurveList( QStringList lst, QStringList list22)
{
    int mm;
    int M=spinBoxNumberCurvesToFit->value();
    for(mm=0;mm<M;mm++)	
    {
	QComboTableItem *curve =(QComboTableItem*)tableCurves->item (0, 2*mm+1);
	QString old=curve->currentText();
	curve->setStringList(list22);	
	int active=0;
	int i;
	for (i=0;i<curve->count();i++)
	{
	    if (curve->text(i) == old) active=i;
	}
	curve->setCurrentItem(active);
	
	QString table=curve->currentText();
	table=table.left(table.find("_",0));
	
	// +++
	colList(table,2*mm+1);
    }
}


//*******************************************
//*Set-Sigma-and-Weight-Columns 
//*******************************************
void fittable::setSigmaAndWeightCols(QStringList lst,QStringList lstDI, QStringList lstSigma, int col,int Raws)
{
    //sen number of Raws
    tableCurves->setText(1,col,QString::number(Raws));
    //
    QCheckTableItem *cbImin = (QCheckTableItem*)tableCurves->item (2,col-1);
    QCheckTableItem *cbImax = (QCheckTableItem*)tableCurves->item (3,col-1);
    
    int temp=tableCurves->text(2,col).toInt();
    if ( (!cbImin->isChecked()) || ( (tableCurves->text(1,col-1)=="N") && ( (temp<=0) || (temp >= Raws))))  tableCurves->setText(2,col,QString::number(1));  
    
    temp=tableCurves->text(3,col).toInt();
    if ( (!cbImax->isChecked()) || ( (tableCurves->text(1,col-1)=="N") &&((temp<=2) || (temp > Raws) || (temp<tableCurves->text(2,col).toInt()))))  tableCurves->setText(3,col,QString::number(Raws));
    
    //weight
    QComboTableItem *weight =(QComboTableItem*)tableCurves->item (4,col);
    weight->setStringList(lstDI);
    
    //reso
    QString currentInstrument=comboBoxInstrument->currentText();	    
    if (checkBoxSANSsupport->isChecked() && currentInstrument.contains("SANS") )
    {
	QComboTableItem *reso =(QComboTableItem*)tableCurves->item (5,col);
	//-NEW-
	lstSigma<<"from DANP";
	reso->setStringList(lstSigma);
    }
    else if (checkBoxSANSsupport->isChecked() && currentInstrument.contains("Back") )
    {
	QComboTableItem *reso =(QComboTableItem*)tableCurves->item (5,col);
	lstSigma<<"from SPHERES";
	reso->setStringList(lstSigma);
    }    
}


//*******************************************
//fit function:External DLL !OB
//*******************************************
void fittable::openDLL()
{
    // +++ WIN    
#if defined( Q_OS_WIN ) //MSVC Compiler
    QString filter="DLL (*.dll)";
    
    // +++  MAC
#elif defined(Q_OS_MAC)
    QString filter="DLL (*.dylib)";
    
    // +++ Unix    
#else
    QString filter="DLL (*.so)";
#endif
    
    QString pluginName = QFileDialog::getOpenFileName(libPath, filter, this, 0, "QtiKWS - Fit - Function", 0, TRUE);
    openDLLgeneral(pluginName);
    scanGroup();
}

//*******************************************
//*open DLL  !OB
//*******************************************
void fittable::openDLL( const QString &file )
{
    
    // +++ WIN    
#if defined( Q_OS_WIN)
    QString filter=".dll";
    
    // +++  MAC
#elif defined(Q_OS_MAC)
    QString filter=".dylib";    
    
    // +++ UNIX     
#else
    QString filter=".so";
    
#endif
    
    QString pluginName = libPath+"/"+file+filter;
    
    openDLLgeneral(pluginName);
    
    readFIFheader(libPath+"/"+file+".fif");	
    
    SANSsupportYN();
}		
//*******************************************
//* open DLL !OB
//*******************************************
void fittable::openDLLgeneral(QString file)		
{
    // Lists 
    F_paraList.clear(); 
    F_initValues.clear();
    F_adjustPara.clear();
    F_paraListComments.clear();
    //*F
    F_paraListF.clear();
    F_initValuesF.clear();
    F_adjustParaF.clear();
    F_paraListCommentsF.clear();
    //
    int p=0;
    pF=0;
    pSANS=0;
    
    QString pluginName = file;
    
    if (pluginName.isEmpty())
    {
	QMessageBox::warning(this,tr("QtiKWS"), tr("Error: <p> DLL or LIB"));
	return;
	p=0; pF=0;
	spinBoxPara->setValue(0);
    }
    
    if (!QFile::exists (pluginName))
    {
	QMessageBox::warning(this,tr("QtiKWS"), tr("Error: <p>*.dll OR *.so OR *.dylib"));
	return;
	p=0; pF=0;
	spinBoxPara->setValue(0);
    }
    
    
    if (libName!="")
    {
	lib->unload();
	p=0; pF=0;
	spinBoxPara->setValue(0);
	lib->setAutoUnload(true);
	lib->~QLibrary ();
    }
    
    //    if (lib && lib->isLoaded()) lib->unload();
    
    setName(pluginName);	
    
    
    libName=pluginName;
    lib = new QLibrary(pluginName);	
    
    //   QLibrary lib(pluginName);
    
    
    typedef char* (*fitFuncChar)();
    
    QString F_name;
    //Resolve Name of Function
    fitFuncChar fitFunctionChar = (fitFuncChar) lib->resolve("name");
    if (fitFunctionChar)
    {
	F_name=QString(fitFunctionChar());
	//+++ Set Function Name
	textLabelFfunc->setText(F_name);
	
	//tablePara->setRowLabels(F_paraList);
    } 
    else
    {
	p=0; pF=0;
	spinBoxPara->setValue(0);
	QMessageBox::warning(this,tr("QtiKWS"), tr("Error: <p>check function 1"));
	return;
    }
    
    //****Parameter`s Number
    fitFunctionChar=(fitFuncChar) lib->resolve("paraNumber");
    pF=QString(fitFunctionChar()).toInt();
    if (pF<1)
    {
	p=0; pF=0;
	spinBoxPara->setValue(0);
	QMessageBox::warning(this,tr("QtiKWS"), tr("Error: <p>check function 3"));
    }
    
    
    //****Parameter`s Names
    fitFunctionChar = (fitFuncChar)  lib->resolve("parameters");
    if (fitFunctionChar)
    {	
	F_paraListF = QStringList::split(",", QString(fitFunctionChar()), false);
	if (F_paraListF.count()==(pF+1) && F_paraListF[pF]!="")
	{
	    XQ=F_paraListF[pF];
	    F_paraListF.remove(F_paraListF.at(pF));
	}
	else XQ="x";
    }
    else
    {
	p=0; pF=0;
	spinBoxPara->setValue(0);
	QMessageBox::warning(this,tr("QtiKWS"), tr("Error: <p>check function 2"));
	return;
    }
    
    //****Parameter`s Init Values
    fitFunctionChar = (fitFuncChar)  lib->resolve("init_parameters");
    if (fitFunctionChar)
    {	
	F_initValuesF = QStringList::split(",", QString(fitFunctionChar()), false);
    }
    
    //****Parameter`s Adjust Parameters
    fitFunctionChar = (fitFuncChar)  lib->resolve("adjust_parameters");
    if (fitFunctionChar)
    {	
	F_adjustParaF = QStringList::split(",", QString(fitFunctionChar()), false);
    }
    
    
    
    //****listComments
    fitFunctionChar=(fitFuncChar) lib->resolve("listComments");
    if (fitFunctionChar)
    {	
	F_paraListCommentsF = QStringList::split(",,", QString(fitFunctionChar()), false);	
    }
    
    //****Function
    typedef double (*fitFuncD)(double, void* );
    fitFuncD f_fit;
    f_fit = (fitFuncD) lib->resolve("functionSANS");
    
    if (!f_fit)
    {
	p=0; pF=0;
	spinBoxPara->setValue(0);
	QMessageBox::warning(this,tr("QtiKWS"), tr("Error: <p>check function 4"));
	return;
    }
    
    F.function=f_fit;
    
    F_paraList=F_paraListF;
    F_initValues=F_initValuesF;
    F_adjustPara=F_adjustParaF;
    F_paraListComments=F_paraListCommentsF;   
    
    if (pF!=0) 
    {	
	QString currentInstrument=comboBoxInstrument->currentText();	    
	if (checkBoxSANSsupport->isChecked() && currentInstrument.contains("SANS") )
	{
	    p=pF+pSANS;//+SANS support
	    F_paraList+=SANS_param_names;
	    F_initValues+=SANS_initValues;
	    F_adjustPara+=SANS_adjustPara;
	    F_paraListComments+=SANS_paraListComments;
	}
	else
	{
	    p=pF;
	}
    }
    if (p)
    {
	spinBoxPara->setValue(p);//
    }
    else
    {
	p=0;
	return;
    }
    
    //****Function Parameters Allocation
    F_para= gsl_vector_alloc(p);
    
    //+++
    tableParaComments00->setNumRows(0);	
    tableParaComments00->setNumRows(pF);    
    tableParaComments00->setRowLabels(F_paraList);
    tableParaComments00->setLeftMargin(130);
    tableParaComments00->setColumnStretchable (0, TRUE);
    
    int i;
    for(i=0;i<p;i++) tableParaComments00->setText(i,0,F_paraListComments[i+1]);
    
    textBrowserFunctionDescription00->setText(F_paraListComments[0]);
    
}

//*******************************************
//  check new values in tableCurve !OB
//*******************************************
void fittable::tableCurvechanged( int raw, int col )
{
    
    if( ((col/2)*2)!=col ) 
    {
	// +++
	if (raw==0)
	{
	    // Selected data to Fit
	    QString table=tableCurves->text(raw,col);
	    table=table.left(table.find("_",0));
	    // then set lists for dI and sigmaReso ; and Number of points
	    colList(table,col);
	    
	}
	
	if (raw==2)
	{
	    QString NQ=tableCurves->text(raw-1,col-1);
	    if ((NQ=="N") && (((tableCurves->text(2,col).toInt()) < 1) || ((tableCurves->text(2,col).toInt()) > (tableCurves->text(3,col).toInt())))) tableCurves->setText(2,col,"1");
	}
	if (raw==3)
	{
	    QString NQ=tableCurves->text(raw-2,col-1);
	    if ((NQ=="N") && (((tableCurves->text(3,col).toInt()) > (tableCurves->text(1,col).toInt()) || (tableCurves->text(3,col).toInt()) < (tableCurves->text(2,col).toInt())) )) tableCurves->setText(raw,col,tableCurves->text(1,col));
	    
	}
    }
    else
    {
	
	if (raw==0) 
	{
	    QComboTableItem *comboList = (QComboTableItem*)tableCurves->item (0,col+1);
	    QString pattern=tableCurves->text(0,col);
	    int iNumber=comboList->count();
	    int oldNumber=comboList->currentItem();
	    if (!comboList->currentText().contains(pattern))
	    {
		int i=0;
		while ( i<iNumber) { if (comboList->text(i).contains(pattern) ) break; i++;};
		if (i>=iNumber) comboList->setCurrentItem(oldNumber); else comboList->setCurrentItem(i);
	    }
	}
	if (raw==1) 
	{
	    
	    QCheckTableItem *iQmin = (QCheckTableItem*)tableCurves->item (2,col);
	    iQmin->setChecked(FALSE);
	    QCheckTableItem *iQmax = (QCheckTableItem*)tableCurves->item (3,col);
	    iQmax->setChecked(FALSE);
	    
	    QvsN();
	}
    }
    
}

//*******************************************
// slot: fit results to "res" winwow !OB
//*******************************************
void fittable::resToLogWindow()
{
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value();
    QString F_name=textLabelFfunc->text();
    
    QDateTime dt = QDateTime::currentDateTime ();
    QString info = "[ " + dt.toString(Qt::LocalDate)+ " ]\n";
    info += tr("Fit Method") + ": " +comboBoxFitMethod->currentText() +"\n";
    info += tr("Using Function") + ": " + F_name + "\n";
    for (int mm=0;mm<M;mm++) 
    {
	info+=tableCurves->text(0,2*mm+1)+ " : \n";
	for (int pp=0;pp<p;pp++) 
	{
	    info+= F_paraList[pp]+" = "+tablePara->text(pp,3*mm+2);
	    
	    if (tablePara->text(pp,3*mm+3)!="---")
	    {
		info+=" ";
		info+=QChar(177);
		info+=" "+tablePara->text(pp,3*mm+3);
	    }
	    info+="\n";
	}
    }
    info+="chi^2 = "+textLabelChi->text()+"\n";
    info+="R^2 = "+textLabelR2->text()+"\n";
    info+="time = "+textLabelTime->text()+"\n";
    info=info+"-------------------------------------------------------------"+"\n";
    
    app(this)->logInfo+=info;
    app(this)->actionShowLog->setOn(true);
    app(this)->results->setText(app(this)->logInfo);   
    app(this)->results->scrollToBottom();	
}

//*******************************************
// slot: fit results to "res" window (one line) !OB
//*******************************************
void fittable::resToLogWindowOne()
{
    int p=spinBoxPara->value();
    int M=spinBoxNumberCurvesToFit->value();
    QString F_name=textLabelFfunc->text();
    
    QDateTime dt = QDateTime::currentDateTime ();
    QString info = "[ " + dt.toString(Qt::LocalDate)+ " ]\n";
    info += tr("Fit Method") + ": " +comboBoxFitMethod->currentText() +"\n";
    info += tr("Using Function") + ": " + F_name + "\n";
    int pp,mm;
    for (pp=0;pp<p;pp++) 
    {
	info+= F_paraList[pp]+"\t"+F_paraList[pp]+"-error\t";
    }	
    info+="\n";
    for (mm=0;mm<M;mm++) 
    {
	for (pp=0;pp<p;pp++) 
	{
	    info+= tablePara->text(pp,3*mm+2)+"\t "+tablePara->text(pp,3*mm+3)+"\t";
	}
	info+="\n";
	info+="("+tableCurves->text(0,2*mm+1)+ ")  \n";
    }
    info+="chi^2 = "+textLabelChi->text()+"\n";
    info+="R^2 = "+textLabelR2->text()+"\n";
    info+="time = "+textLabelTime->text()+"\n";
    info=info+"-------------------------------------------------------------"+"\n";
    
    app(this)->logInfo+=info;
    app(this)->results->setText(app(this)->logInfo);
    app(this)->results->scrollToBottom();	
}
//*******************************************
// validator: Fit-conditions
//*******************************************
void fittable::lineValidator()
{
    QString s;
    double num;
    // AbsErr
    num=lineEditAbsErr->text().toDouble();
    if (num<0) 	num=0;
    lineEditAbsErr->setText(QString::number(num));
    //RelErr
    num=lineEditRelErr->text().toDouble();
    if (num<1e-20 &&num>0 ) num=1e-20;
    lineEditRelErr->setText(QString::number(num));
    //fit tolerance
    num=lineEditTolerance->text().toDouble();
    if (num<0) 	num=0;
    lineEditTolerance->setText(QString::number(num));
}


//*******************************************
// slot: make NEW table with fit results !OB
//*******************************************
void fittable::newTabRes()
{
    //app(this)->changeFolder("FIT :: 1D");
    
    QStringList RES;
    QString F_name=textLabelFfunc->text();
    
    RES<<F_name<<QString::number(spinBoxPara->value())<<QString::number(spinBoxNumberCurvesToFit->value());
    //	RES<<comboBoxHorV->currentText ();
    RES+=d_param_names;
    RES<<"chi^2="+textLabelChi->text()<<"time="+textLabelTime->text();
    int mm=0, pp=0;
    for (mm=0;mm<spinBoxNumberCurvesToFit->value();mm++)
	for (pp=0;pp<spinBoxPara->value();pp++)
	{
	RES<< tablePara->text(pp, 3*mm+2)<<tablePara->text(pp, 3*mm+2);
    }
    
    // +++ NewTabRes(RES)
    
    int p=spinBoxPara->value();
    int M=spinBoxNumberCurvesToFit->value();
    Table* w;
    
    QString temp=app(this)->generateUniqueName(tr("newFitTableRow"+F_name));
    
    w=app(this)->newTable(temp, GSL_MAX(p, 6), 3+2*M);
    w->setTextFormat(TRUE);
    
    // First Col
    w->setText(0,0,"Fitting Function"); 
    w->setText(0,1,"->   "+F_name);
    //
    w->setText(1,0,"Number of Parameters");
    w->setText(1,1, "->   "+QString::number(p) ); 
    //
    w->setText(2,0,"Number of data sets M");
    w->setText(2,1,"->   "+QString::number(M));
    //
    w->setText(3,0,"chi^2");
    w->setText(3,1,"->   "+textLabelChi->text());
    //
    w->setText(4,0,"R^2");
    w->setText(4,1,"->   "+textLabelR2->text());
    //
    w->setText(5,0,"Time of Fit");
    w->setText(5,1,"->   "+textLabelTime->text());
    //
    w->setColName(0,"Characteristics");
    w->setColName(1,"Conditions");
    w->setColName(2,"Parameters");
    
    
    QString yn0="";
    
    for (pp=0;pp<p;pp++){w->setText(pp,2,F_paraList[pp]);};
    
    for (mm=0;mm<M;mm++)
    {
	if (mm>=9) yn0=""; else yn0="0";
	w->setColName(2*mm+3,"Value"+yn0+QString::number(mm+1));
	w->setColName(2*mm+4,"Error"+yn0+QString::number(mm+1));
	for (pp=0;pp<p;pp++)
	{
	    w->setText(pp, 3+2*mm, tablePara->text(pp, 3*mm+2));
	    w->setText(pp, 4+2*mm, tablePara->text(pp, 3*mm+3));
	}
    }
    
    for (int tt=0; tt<w->numCols(); tt++) 
    {
	w->table()->adjustColumn (tt);
	w->table()->setColumnWidth(tt, w->table()->columnWidth(tt)+10); 
    }
}

//*******************************************
// slot: make NEW table with fit results (Col) 20.02.12
//*******************************************
void fittable::newTabResCol()
{
    //app(this)->changeFolder("FIT :: 1D");
    
    QStringList RES;
    QString F_name=textLabelFfunc->text();
    
    RES<<F_name<<QString::number(spinBoxPara->value())<<QString::number(spinBoxNumberCurvesToFit->value());
    //	RES<<comboBoxHorV->currentText ();
    RES+=d_param_names;
    RES<<"chi^2="+textLabelChi->text()<<"time="+textLabelTime->text();
    int mm=0, pp=0;
    for (mm=0;mm<spinBoxNumberCurvesToFit->value();mm++)
	for (pp=0;pp<spinBoxPara->value();pp++)
	{
	RES<< tablePara->text(pp, 3*mm+2)<<tablePara->text(pp, 3*mm+2);
    }
    
    // +++ NewTabRes(RES)
    
    int p=spinBoxPara->value();
    int M=spinBoxNumberCurvesToFit->value();
    Table* w;
    
    QString temp=app(this)->generateUniqueName(tr("newFitTableCol"+F_name));
    
    
    w=app(this)->newTable(temp, GSL_MAX(M, 6), 2+1+2*p);
    w->setTextFormat(TRUE);
    
    // First Col
    w->setText(0,0,"Fitting Function"); 
    w->setText(0,1,"->   "+F_name);
    //
    w->setText(1,0,"Number of Parameters");
    w->setText(1,1, "->   "+QString::number(p) ); 
    //
    w->setText(2,0,"Number of data sets M");
    w->setText(2,1,"->   "+QString::number(M));
    //
    w->setText(3,0,"chi^2");
    w->setText(3,1,"->   "+textLabelChi->text());
    //
    w->setText(4,0,"R^2");
    w->setText(4,1,"->   "+textLabelR2->text());
    //
    w->setText(5,0,"Time of Fit");
    w->setText(5,1,"->   "+textLabelTime->text());
    //
    w->setColName(0,"Characteristics"); 
    w->setColPlotDesignation(0,Table::None);
    
    w->setColName(1,"Conditions");
    w->setColPlotDesignation(1,Table::None);
    
    w->setColName(2,"Nr");
    w->setColPlotDesignation(2,Table::X);
    w->setColNumericFormat(0, 6, 2);
    
    for (pp=0;pp<p;pp++)
    {
	w->setColName(3+2*pp,F_paraList[pp]);
	w->setColPlotDesignation(3+2*pp,Table::Y);
	w->setColNumericFormat(0, 6, 3+2*pp);
	
	w->setColName(3+2*pp+1,F_paraList[pp]+"Error");
	w->setColPlotDesignation(3+2*pp+1,Table::yErr);
	w->setColNumericFormat(0, 6, 3+2*pp+1);
	
	for (mm=0;mm<M;mm++)
	{
	    w->setText(mm, 3+2*pp, tablePara->text(pp, 3*mm+2));
	    w->setText(mm, 3+2*pp+1, tablePara->text(pp, 3*mm+3));	
	}
    }    
    for (mm=0;mm<M;mm++) w->setText(mm, 2,QString::number(mm+1));
    
    for (int tt=0; tt<w->numCols(); tt++) 
    {
	w->table()->adjustColumn (tt);
	w->table()->setColumnWidth(tt, w->table()->columnWidth(tt)+10); 
    }
    
}

//*******************************************
// slot: make NEW table with fit results 
//*******************************************
void fittable::saveFittingSession()
{
    
    bool ok;
    QString table = QInputDialog::getText("Input ", "Enter table name to save fitting session:", QLineEdit::Normal,
					  QString::null, &ok, this );
    if ( ok && !table.isEmpty() ) 
    {
	// user entered something and pressed OK
    } else 
    {
	return;
    }

    saveFittingSession(table);
    
}  

//*******************************************
// slot: make NEW table with fit results 
//*******************************************
void fittable::saveFittingSession(QString table)
{
    
    int p=spinBoxPara->value();
    int M=spinBoxNumberCurvesToFit->value();
    QString F_name=textLabelFfunc->text();
    
        
    Table* w;
    
    if (checkTableExistence(table, w) )
    {
	if (w->windowLabel()!="FIT1D::Settings::Table")
	{
	    QMessageBox::critical( 0, "QtiKWS", "Table "+table+" is not fitting-settings table");
	    return;
	}	
	w->setNumRows(0);
	w->setNumCols(2);
    }
    else 
    {
	//app(this)->changeFolder("FIT :: 1D");
	w=app(this)->newHiddenTable(table,"FIT1D::Settings::Table", 0, 2);
	//+++ new
	w->setWindowLabel("FIT1D::Settings::Table");
	app(this)->setListViewLabel(w->name(), "FIT1D::Settings::Table");
	app(this)->updateWindowLists(w);
    }
    
    
    
    //Col-Names
    QStringList colType;
    w->setColName(0,"Parameter"); w->setColPlotDesignation(0,Table::None);colType<<"1";
    w->setColName(1,"Parameter-Value"); w->setColPlotDesignation(1,Table::None);colType<<"1";
    w->setColumnTypes(colType);
    
    
    
    int currentRow=0;
    QString s;
    
    //----- Function::Folder
    w->setNumRows(currentRow+1);
    s=libPath+" <";
    w->setText(currentRow, 0, "Function::Folder");
    w->setText(currentRow, 1, s);
    currentRow++;
    
    //----- Function::Name
    w->setNumRows(currentRow+1);
    s=textLabelFfunc->text()+" <";
    w->setText(currentRow, 0, "Function::Name");
    w->setText(currentRow, 1, s);
    currentRow++;
    
    //+++ Function::Parameters::Number
    w->setNumRows(currentRow+1);            
    s=QString::number(p)+" ";
    w->setText(currentRow,0,"Function::Parameters::Number");
    w->setText(currentRow,1,s+" <");
    currentRow++;
    
    
    //+++ Function::SANS::Support
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Function::SANS::Support");
    if (checkBoxSANSsupport->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");       
    currentRow++;
    
    //+++ Function::Global::Fit
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Function::Global::Fit");
    if (checkBoxMultiData->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");       
    currentRow++;
    
    //+++ Function::Global::Fit::Number
    w->setNumRows(currentRow+1);            
    s=QString::number(M)+" ";
    w->setText(currentRow,0,"Function::Global::Fit::Number");
    w->setText(currentRow,1,s+"<");
    currentRow++;
    
    //+++ Session::Data::Datasets   0
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++) 
	s+=tableCurves->text(0,2*i+1)+" ";
    w->setText(currentRow,0,"Session::Data::Datasets");
    w->setText(currentRow,1,s+"<");
    currentRow++;    
    
    //+++ Session::Data::N 1a
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++) 
	s+=tableCurves->text(1,2*i)+" ";
    w->setText(currentRow,0,"Session::Data::N");
    w->setText(currentRow,1,s+"<");
    currentRow++;    
    
    //+++ Session::Data::NN 1b
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++) 
	s+=tableCurves->text(1,2*i+1)+" ";
    w->setText(currentRow,0,"Session::Data::NN");
    w->setText(currentRow,1,s+"<");
    currentRow++;    
    
    //+++ Session::Data::From::Use
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++)
    {
	QCheckTableItem *active = (QCheckTableItem *)tableCurves->item(2,2*i);	
	if (active->isChecked()) s+="1 "; else s+="0 ";
    }
    w->setText(currentRow,0,"Session::Data::From::Use");
    w->setText(currentRow,1,s+"<");
    currentRow++; 
    
    
    //+++ Session::Data::From::Number
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++) 
	s+=tableCurves->text(2,2*i+1)+" ";
    w->setText(currentRow,0,"Session::Data::From::Number");
    w->setText(currentRow,1,s+"<");
    currentRow++;        
    
    //+++ Session::Data::To::Use
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++)
    {
	QCheckTableItem *active = (QCheckTableItem *)tableCurves->item(3,2*i);	
	if (active->isChecked()) s+="1 "; else s+="0 ";
    }
    
    w->setText(currentRow,0,"Session::Data::To::Use");
    w->setText(currentRow,1,s+"<");
    currentRow++; 
    
    
    //+++ Session::Data::To::Number
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++) 
	s+=tableCurves->text(3,2*i+1)+" ";
    w->setText(currentRow,0,"Session::Data::To::Number");
    w->setText(currentRow,1,s+"<");
    currentRow++;        
    
    //+++ Session::Weighting::Use
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++)
    {
	QCheckTableItem *active = (QCheckTableItem *)tableCurves->item(4,2*i);	
	if (active->isChecked()) s+="1 "; else s+="0 ";
    }
    
    w->setText(currentRow,0,"Session::Weighting::Use");
    w->setText(currentRow,1,s+"<");
    currentRow++; 
    
    
    //+++ Session::Weighting::Dataset
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++) 
	s+=tableCurves->text(4,2*i+1)+" ";
    w->setText(currentRow,0,"Session::Weighting::Dataset");
    w->setText(currentRow,1,s+"<");
    currentRow++;        
    
    //+++ Session::Limits::Left
    w->setNumRows(currentRow+1);            
    s="";
    for (int pp=0; pp<p;pp++)
	s+=tableControl->text(pp,0)+" ";
    w->setText(currentRow,0,"Session::Limits::Left");
    w->setText(currentRow,1,s+"<");
    currentRow++;  
    
    //+++ Session::Limits::Right
    w->setNumRows(currentRow+1);            
    s="";
    for (int pp=0; pp<p;pp++)
	s+=tableControl->text(pp,4)+" ";
    w->setText(currentRow,0,"Session::Limits::Right");
    w->setText(currentRow,1,s+"<");
    currentRow++;  
    
    //+++ Session::Limits::Scale::Left
    w->setNumRows(currentRow+1);            
    s=lineEditLeftMargin->text();
    w->setText(currentRow,0,"Session::Limits::Scale::Left");
    w->setText(currentRow,1,s+"<");
    currentRow++; 
    
    //+++ Session::Limits::Scale::Right
    w->setNumRows(currentRow+1);            
    s=lineEditRightMargin->text();
    w->setText(currentRow,0,"Session::Limits::Scale::Right");
    w->setText(currentRow,1,s+"<");
    currentRow++; 
    
    if (checkBoxSANSsupport->isChecked())
    {
	//+++ Session::Resolution::Use
	w->setNumRows(currentRow+1);            
	s="";
	for (int i=0; i<M;i++)
	{
	    QCheckTableItem *active = (QCheckTableItem *)tableCurves->item(5,2*i);	
	    if (active->isChecked()) s+="1 "; else s+="0 ";
	}
	
	w->setText(currentRow,0,"Session::Resolution::Use");
	w->setText(currentRow,1,s+"<");
	currentRow++; 
	
	//+++ Session::Resolution::Datasets
	w->setNumRows(currentRow+1);            
	s="";
	for (int i=0; i<M;i++) 
	    s+=tableCurves->text(5,2*i+1)+" ";
	w->setText(currentRow,0,"Session::Resolution::Datasets");
	w->setText(currentRow,1,s+"<");
	currentRow++;        
	
	//+++ Session::Polydispersity::Use
	w->setNumRows(currentRow+1);            
	s="";
	for (int i=0; i<M;i++)
	{
	    QCheckTableItem *active = (QCheckTableItem *)tableCurves->item(6,2*i);	
	    if (active->isChecked()) s+="1 "; else s+="0 ";
	}
	
	w->setText(currentRow,0,"Session::Polydispersity::Use");
	w->setText(currentRow,1,s+"<");
	currentRow++; 
	
	//+++ Session::Polydispersity::Datasets
	w->setNumRows(currentRow+1);            
	s="";
	for (int i=0; i<M;i++) 
	    s+=tableCurves->text(6,2*i+1)+" ";
	w->setText(currentRow,0,"Session::Polydispersity::Datasets");
	w->setText(currentRow,1,s+"<");
	currentRow++;
	
	//+++ Session::Options::Reso
	w->setNumRows(currentRow+1);            
	s=QString::number(comboBoxResoFunction->currentItem())+" ";
	s+=QString::number(comboBoxSpeedControlReso->currentItem())+" ";	
	s+=lineEditAbsErr->text()+" ";
	s+=lineEditRelErr->text()+" ";
	s+=QString::number(spinBoxIntWorkspase->value())+" ";
	s+=QString::number(spinBoxIntLimits->value());
	w->setText(currentRow,0,"Session::Options::Reso");
	w->setText(currentRow,1,s+" <");
	currentRow++;
	
	//+++ Session::Options::Poly
	w->setNumRows(currentRow+1);            
	s=QString::number(comboBoxPolyFunction->currentItem())+" ";
	s+=QString::number(comboBoxSpeedControlPoly->currentItem())+" ";	
	s+=lineEditAbsErrPoly->text()+" ";
	s+=lineEditRelErrPoly->text()+" ";
	s+=QString::number(spinBoxIntWorkspasePoly->value())+" ";
	s+=QString::number(spinBoxIntLimitsPoly->value());
	w->setText(currentRow,0,"Session::Options::Poly");
	w->setText(currentRow,1,s+" <");
	currentRow++;
    }
    
    //+++ Session::Options::Fit::Control
    w->setNumRows(currentRow+1);            
    s=QString::number(comboBoxFitMethod->currentItem())+" ";
    s+=QString::number(spinBoxMaxIter->value())+" ";
    s+=lineEditTolerance->text()+" ";
    s+=lineEditToleranceAbs->text()+" ";
    s+=QString::number(spinBoxSignDigits->value())+" ";
    s+=QString::number(comboBoxWeightingMethod->currentItem())+" ";	
    if (checkBoxCovar->isChecked()) s+="1 "; else s+="0 ";
    
    s+=lineEditWA->text()+" ";
    s+=lineEditWB->text()+" ";
    s+=lineEditWC->text()+" ";
    s+=lineEditWXMAX->text()+" ";
    
    s+=QString::number(spinBoxGenomeCount->value())+" ";
    s+=QString::number(spinBoxMaxNumberGenerations->value())+" ";
    s+=lineEditSelectionRate->text()+" ";
    s+=lineEditMutationRate->text()+" ";
    s+=QString::number(spinBoxRandomSeed->value())+" ";
    
    w->setText(currentRow,0,"Session::Options::Fit::Control");
    w->setText(currentRow,1,s+"<");
    currentRow++;
    
    //+++ Session::Options::Instrument::Reso
    w->setNumRows(currentRow+1); 
    s=QString::number(comboBoxResoFunction->currentItem())+" ";
    s+=QString::number(comboBoxSpeedControlReso->currentItem())+" ";
    s+=lineEditAbsErr->text()+" ";
    s+=lineEditRelErr->text()+" ";    
    s+=QString::number(spinBoxIntWorkspase->value())+" ";
    s+=QString::number(spinBoxIntLimits->value())+" ";   
    w->setText(currentRow,0,"Session::Options::Instrument::Reso");
    w->setText(currentRow,1,s+"<");
    currentRow++;
    
    //+++ Session::Options::Instrument::Poly
    w->setNumRows(currentRow+1); 
    s=QString::number(comboBoxPolyFunction->currentItem())+" ";
    s+=QString::number(comboBoxSpeedControlPoly->currentItem())+" ";
    s+=lineEditAbsErrPoly->text()+" ";
    s+=lineEditRelErrPoly->text()+" ";    
    s+=QString::number(spinBoxIntWorkspasePoly->value())+" ";
    s+=QString::number(spinBoxIntLimitsPoly->value())+" ";   
    w->setText(currentRow,0,"Session::Options::Instrument::Poly");
    w->setText(currentRow,1,s+"<");
    currentRow++;    
    
    //+++
    if (checkBoxMultiData->isChecked())
    {
	//+++ Session::Parameters::Shared
	w->setNumRows(currentRow+1);            
	s="";
	for (int pp=0; pp<p;pp++)
	{
	    QCheckTableItem *active = (QCheckTableItem *)tablePara->item(pp,0);	
	    if (active->isChecked()) s+="1 "; else s+="0 ";
	}
	
	w->setText(currentRow,0,"Session::Parameters::Shared");
	w->setText(currentRow,1,s+" <");
	currentRow++;
	
	
    }
    
    //+++
    for (int pp=0;pp<p;pp++)
    {
	QString uselName="Session::Parameters::Use::"+QString::number(pp+1);
	
	//+++ Session::Parameters::Use::pp+1
	w->setNumRows(currentRow+1);            
	s="";
	for (int i=0; i<M;i++)
	{
	    QCheckTableItem *active = (QCheckTableItem *)tablePara->item(pp,3*i+1);	
	    if (active->isChecked()) s+="1 "; else s+="0 ";
	}
	
	w->setText(currentRow,0,uselName);
	w->setText(currentRow,1,s+" <");
	currentRow++;
	
	QString cellName="Session::Parameters::Values::"+QString::number(pp+1);
	
	//+++Session::Parameters::Values::pp+1
	w->setNumRows(currentRow+1);            
	s="";
	for (int i=0; i<M;i++) 
	    s+=tablePara->text(pp,3*i+2)+" ";
	w->setText(currentRow,0,cellName);
	w->setText(currentRow,1,s+"<");
	currentRow++;
    }
    
    QString cellName="Session::Parameters::Limit::Left";
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<p;i++) 
	s+=tableControl->text(i,0)+" ";
    s+=lineEditLeftMargin->text()+" ";
    w->setText(currentRow,0,cellName);
    w->setText(currentRow,1,s+"<");
    currentRow++;
    
    
    cellName="Session::Parameters::Limit::Right";
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<p;i++) 
	s+=tableControl->text(i,4)+" ";
    s+=lineEditRightMargin->text()+" ";
    w->setText(currentRow,0,cellName);
    w->setText(currentRow,1,s+"<");
    currentRow++;
    
    //+++Session::Parameters::Errors
    w->setNumRows(currentRow+1);   
    w->setText(currentRow, 0, "Session::Parameters::Errors");
    s="";
    for (int i=0; i<M;i++) for (int pp=0;pp<p;pp++) s+=tablePara->text(pp,3*i+3)+" ";
    w->setText(currentRow,1,s+" <");
    currentRow++;
    
    //----- Session::Chi2
    w->setNumRows(currentRow+1);
    s=textLabelChi->text()+" <";
    w->setText(currentRow, 0, "Session::Chi2");
    w->setText(currentRow, 1, s);
    currentRow++;    
    
    //----- Session::R2
    w->setNumRows(currentRow+1);
    s=textLabelR2->text()+" <";
    w->setText(currentRow, 0, "Session::R2");
    w->setText(currentRow, 1, s);
    currentRow++;    
    
    //----- Session::Time
    w->setNumRows(currentRow+1);
    s=textLabelTime->text()+" <";
    w->setText(currentRow, 0, "Session::Time");
    w->setText(currentRow, 1, s);
    currentRow++;    
    
    //----- Simulate::Color
    w->setNumRows(currentRow+1);
    s=QString::number(comboBoxColor->currentItem())+" <";
    w->setText(currentRow, 0, "Simulate::Color");
    w->setText(currentRow, 1, s);
    currentRow++;    
    
    //+++ Simulate::Statistics
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Simulate::Statistics");
    if (checkBoxCovar->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");       
    currentRow++;
    
    //+++ Simulate::SaveSession
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Simulate::SaveSession");
    if (checkBoxSaveSession->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");       
    currentRow++;
    
    //+++ Simulate::Indexing
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Simulate::Indexing");
    if (checkBoxSimIndexing->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");       
    currentRow++;
    
    //+++ Simulate::Uniform
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Simulate::Uniform");
    if (radioButtonUniform_Q->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");       
    currentRow++;    
    
    //+++ Simulate::Uniform::Parameters
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Simulate::Uniform::Parameters");
    s="";
    s+=lineEditFromQsim->text()+" ";
    s+=lineEditToQsim->text()+" ";
    s+=lineEditNumPointsSim->text()+" ";
    
    if (checkBoxLogStep->isChecked()) s+="1 ";
    else s+="0 ";
    
    w->setText(currentRow,1,s+"<");       
    currentRow++;    
    
    
    
    for (int tt=0; tt<w->numCols(); tt++) 
    {
	w->table()->adjustColumn (tt);
	w->table()->setColumnWidth(tt, w->table()->columnWidth(tt)+10); 
    }
    
}

//*******************************************
// slot: make NEW table with fit results 
//*******************************************
bool fittable::saveFittingSessionSimulation(int m, QString table)
{    
    bool ok;
    int p=spinBoxPara->value();
    int M=1;  //+++ single dataset
    QString F_name=textLabelFfunc->text();    
    
    Table* w;
    
    if (checkTableExistence(table, w) )
    {
	if (w->windowLabel()!="FIT1D::Settings::Table") return false;
	w->setNumRows(0);
	w->setNumCols(2);
    }
    else 
    {
	w=app(this)->newHiddenTable(table,"FIT1D::Settings::Table", 0, 2);
	//+++ new
	w->setWindowLabel("FIT1D::Settings::Table");
	app(this)->setListViewLabel(w->name(), "FIT1D::Settings::Table");
	app(this)->updateWindowLists(w);
    }
    
    //Col-Names
    QStringList colType;
    w->setColName(0,"Parameter"); w->setColPlotDesignation(0,Table::None);colType<<"1";
    w->setColName(1,"Parameter-Value"); w->setColPlotDesignation(1,Table::None);colType<<"1";
    w->setColumnTypes(colType);
    
        
    int currentRow=0;
    QString s;
    
    //----- Function::Folder
    w->setNumRows(currentRow+1);
    s=libPath+" <";
    w->setText(currentRow, 0, "Function::Folder");
    w->setText(currentRow, 1, s);
    currentRow++;
    
    //----- Function::Name
    w->setNumRows(currentRow+1);
    s=textLabelFfunc->text()+" <";
    w->setText(currentRow, 0, "Function::Name");
    w->setText(currentRow, 1, s);
    currentRow++;
    
    //+++ Function::Parameters::Number
    w->setNumRows(currentRow+1);            
    s=QString::number(p)+" ";
    w->setText(currentRow,0,"Function::Parameters::Number");
    w->setText(currentRow,1,s+" <");
    currentRow++;
    
    
    //+++ Function::SANS::Support
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Function::SANS::Support");
    if (checkBoxSANSsupport->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");       
    currentRow++;
    
    //+++ Function::Global::Fit
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Function::Global::Fit");
    w->setText(currentRow,1,"no <");  // non-global 2016      
    currentRow++;
    
    //+++ Function::Global::Fit::Number
    w->setNumRows(currentRow+1);            
    s=QString::number(M)+" ";
    w->setText(currentRow,0,"Function::Global::Fit::Number");
    w->setText(currentRow,1,s+"<");
    currentRow++;
    
    //+++ Session::Data::Datasets   0
    w->setNumRows(currentRow+1);            
    s=tableCurves->text(0,2*m+1)+" "; // 2016
    w->setText(currentRow,0,"Session::Data::Datasets");
    w->setText(currentRow,1,s+"<");
    currentRow++;    
    
    //+++ Session::Data::N 1a
    w->setNumRows(currentRow+1);            
    s= tableCurves->text(1,2*m)+" "; // 2016
    w->setText(currentRow,0,"Session::Data::N");
    w->setText(currentRow,1,s+"<");
    currentRow++;    
    
    //+++ Session::Data::NN 1b
    w->setNumRows(currentRow+1);            
    s=tableCurves->text(1,2*m+1)+" ";
    w->setText(currentRow,0,"Session::Data::NN");
    w->setText(currentRow,1,s+"<");
    currentRow++;    
    
    //+++ Session::Data::From::Use
    w->setNumRows(currentRow+1);            
    s="";
    QCheckTableItem *active = (QCheckTableItem *)tableCurves->item(2,2*m);	
    if (active->isChecked()) s+="1 "; else s+="0 ";
    w->setText(currentRow,0,"Session::Data::From::Use");
    w->setText(currentRow,1,s+"<");
    currentRow++; 
    
    
    //+++ Session::Data::From::Number
    w->setNumRows(currentRow+1);            
    s=tableCurves->text(2,2*m+1)+" ";
    w->setText(currentRow,0,"Session::Data::From::Number");
    w->setText(currentRow,1,s+"<");
    currentRow++;        
    
    //+++ Session::Data::To::Use
    w->setNumRows(currentRow+1);            
    s="";
    active = (QCheckTableItem *)tableCurves->item(3,2*m);	
    if (active->isChecked()) s+="1 "; else s+="0 ";
    
    w->setText(currentRow,0,"Session::Data::To::Use");
    w->setText(currentRow,1,s+"<");
    currentRow++; 
    
    
    //+++ Session::Data::To::Number
    w->setNumRows(currentRow+1);            
    s=tableCurves->text(3,2*m+1)+" ";
    w->setText(currentRow,0,"Session::Data::To::Number");
    w->setText(currentRow,1,s+"<");
    currentRow++;        
    
    //+++ Session::Weighting::Use
    w->setNumRows(currentRow+1);            
    s="";
    active = (QCheckTableItem *)tableCurves->item(4,2*m);	
    if (active->isChecked()) s+="1 "; else s+="0 ";
   
    
    w->setText(currentRow,0,"Session::Weighting::Use");
    w->setText(currentRow,1,s+"<");
    currentRow++; 
    
    
    //+++ Session::Weighting::Dataset
    w->setNumRows(currentRow+1);            
    s=tableCurves->text(4,2*m+1)+" ";
    w->setText(currentRow,0,"Session::Weighting::Dataset");
    w->setText(currentRow,1,s+"<");
    currentRow++;        
    
    //+++ Session::Limits::Left
    w->setNumRows(currentRow+1);            
    s="";
    for (int pp=0; pp<p;pp++)
	s+=tableControl->text(pp,0)+" ";
    w->setText(currentRow,0,"Session::Limits::Left");
    w->setText(currentRow,1,s+"<");
    currentRow++;  
    
    //+++ Session::Limits::Right
    w->setNumRows(currentRow+1);            
    s="";
    for (int pp=0; pp<p;pp++)
	s+=tableControl->text(pp,4)+" ";
    w->setText(currentRow,0,"Session::Limits::Right");
    w->setText(currentRow,1,s+"<");
    currentRow++;  
    
    //+++ Session::Limits::Scale::Left
    w->setNumRows(currentRow+1);            
    s=lineEditLeftMargin->text();
    w->setText(currentRow,0,"Session::Limits::Scale::Left");
    w->setText(currentRow,1,s+"<");
    currentRow++; 
    
    //+++ Session::Limits::Scale::Right
    w->setNumRows(currentRow+1);            
    s=lineEditRightMargin->text();
    w->setText(currentRow,0,"Session::Limits::Scale::Right");
    w->setText(currentRow,1,s+"<");
    currentRow++; 
    
    if (checkBoxSANSsupport->isChecked())
    {
	//+++ Session::Resolution::Use
	w->setNumRows(currentRow+1);            
	s="";
	if (checkBoxResoSim->isChecked()) s+="1 "; else s+="0 ";	
	w->setText(currentRow,0,"Session::Resolution::Use");
	w->setText(currentRow,1,s+"<");
	currentRow++; 
	
	//+++ Session::Resolution::Datasets
	w->setNumRows(currentRow+1);            
	s=comboBoxResoSim->currentText()+" ";
	w->setText(currentRow,0,"Session::Resolution::Datasets");
	w->setText(currentRow,1,s+"<");
	currentRow++;        
	
	//+++ Session::Polydispersity::Use
	w->setNumRows(currentRow+1);            
	s="";
	if (checkBoxPolySim->isChecked()) s+="1 "; else s+="0 ";
	w->setText(currentRow,0,"Session::Polydispersity::Use");
	w->setText(currentRow,1,s+"<");
	currentRow++; 
	
	//+++ Session::Polydispersity::Datasets
	w->setNumRows(currentRow+1);            
	s=comboBoxPolySim->currentText()+" ";
	w->setText(currentRow,0,"Session::Polydispersity::Datasets");
	w->setText(currentRow,1,s+"<");
	currentRow++;
	
	//+++ Session::Options::Reso
	w->setNumRows(currentRow+1);            
	s=QString::number(comboBoxResoFunction->currentItem())+" ";
	s+=QString::number(comboBoxSpeedControlReso->currentItem())+" ";	
	s+=lineEditAbsErr->text()+" ";
	s+=lineEditRelErr->text()+" ";
	s+=QString::number(spinBoxIntWorkspase->value())+" ";
	s+=QString::number(spinBoxIntLimits->value());
	w->setText(currentRow,0,"Session::Options::Reso");
	w->setText(currentRow,1,s+" <");
	currentRow++;
	
	//+++ Session::Options::Poly
	w->setNumRows(currentRow+1);            
	s=QString::number(comboBoxPolyFunction->currentItem())+" ";
	s+=QString::number(comboBoxSpeedControlPoly->currentItem())+" ";	
	s+=lineEditAbsErrPoly->text()+" ";
	s+=lineEditRelErrPoly->text()+" ";
	s+=QString::number(spinBoxIntWorkspasePoly->value())+" ";
	s+=QString::number(spinBoxIntLimitsPoly->value());
	w->setText(currentRow,0,"Session::Options::Poly");
	w->setText(currentRow,1,s+" <");
	currentRow++;
    }
    
    //+++ Session::Options::Fit::Control
    w->setNumRows(currentRow+1);            
    s=QString::number(comboBoxFitMethod->currentItem())+" ";
    s+=QString::number(spinBoxMaxIter->value())+" ";
    s+=lineEditTolerance->text()+" ";
    s+=lineEditToleranceAbs->text()+" ";
    s+=QString::number(spinBoxSignDigits->value())+" ";
    s+=QString::number(comboBoxWeightingMethod->currentItem())+" ";	
    if (checkBoxCovar->isChecked()) s+="1 "; else s+="0 ";
    
    s+=lineEditWA->text()+" ";
    s+=lineEditWB->text()+" ";
    s+=lineEditWC->text()+" ";
    s+=lineEditWXMAX->text()+" ";
    
    s+=QString::number(spinBoxGenomeCount->value())+" ";
    s+=QString::number(spinBoxMaxNumberGenerations->value())+" ";
    s+=lineEditSelectionRate->text()+" ";
    s+=lineEditMutationRate->text()+" ";
    s+=QString::number(spinBoxRandomSeed->value())+" ";
    
    w->setText(currentRow,0,"Session::Options::Fit::Control");
    w->setText(currentRow,1,s+"<");
    currentRow++;
    
    //+++ Session::Options::Instrument::Reso
    w->setNumRows(currentRow+1); 
    s=QString::number(comboBoxResoFunction->currentItem())+" ";
    s+=QString::number(comboBoxSpeedControlReso->currentItem())+" ";
    s+=lineEditAbsErr->text()+" ";
    s+=lineEditRelErr->text()+" ";    
    s+=QString::number(spinBoxIntWorkspase->value())+" ";
    s+=QString::number(spinBoxIntLimits->value())+" ";   
    w->setText(currentRow,0,"Session::Options::Instrument::Reso");
    w->setText(currentRow,1,s+"<");
    currentRow++;
    
    //+++ Session::Options::Instrument::Poly
    w->setNumRows(currentRow+1); 
    s=QString::number(comboBoxPolyFunction->currentItem())+" ";
    s+=QString::number(comboBoxSpeedControlPoly->currentItem())+" ";
    s+=lineEditAbsErrPoly->text()+" ";
    s+=lineEditRelErrPoly->text()+" ";    
    s+=QString::number(spinBoxIntWorkspasePoly->value())+" ";
    s+=QString::number(spinBoxIntLimitsPoly->value())+" ";   
    w->setText(currentRow,0,"Session::Options::Instrument::Poly");
    w->setText(currentRow,1,s+"<");
    currentRow++;    
    

    //+++
    for (int pp=0;pp<p;pp++)
    {
	QString uselName="Session::Parameters::Use::"+QString::number(pp+1);
	
	//+++ Session::Parameters::Use::pp+1
	w->setNumRows(currentRow+1);            
	s="";
	QCheckTableItem *active = (QCheckTableItem *)tablePara->item(pp,3*m+1);	
	if (active->isChecked()) s+="1 "; else s+="0 ";
	
	w->setText(currentRow,0,uselName);
	w->setText(currentRow,1,s+" <");
	currentRow++;
	
	QString cellName="Session::Parameters::Values::"+QString::number(pp+1);
	
	//+++Session::Parameters::Values::pp+1
	w->setNumRows(currentRow+1);            
	s=tableParaSimulate->text(pp,0)+" ";
	
	w->setText(currentRow,0,cellName);
	w->setText(currentRow,1,s+"<");
	currentRow++;
    }
    
    QString cellName="Session::Parameters::Limit::Left";
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<p;i++) 
	s+=tableControl->text(i,0)+" ";
    s+=lineEditLeftMargin->text()+" ";
    w->setText(currentRow,0,cellName);
    w->setText(currentRow,1,s+"<");
    currentRow++;
    
    
    cellName="Session::Parameters::Limit::Right";
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<p;i++) 
	s+=tableControl->text(i,4)+" ";
    s+=lineEditRightMargin->text()+" ";
    w->setText(currentRow,0,cellName);
    w->setText(currentRow,1,s+"<");
    currentRow++;
    
    //+++Session::Parameters::Errors
    w->setNumRows(currentRow+1);   
    w->setText(currentRow, 0, "Session::Parameters::Errors");
    s="";
    for (int pp=0;pp<p;pp++) s+=tablePara->text(pp,3*m+3)+" ";
    w->setText(currentRow,1,s+" <");
    currentRow++;
    
    //----- Session::Chi2
    w->setNumRows(currentRow+1);
    s=textLabelChi2dofSim->text()+" <";
    w->setText(currentRow, 0, "Session::Chi2");
    w->setText(currentRow, 1, s);
    currentRow++;    
    
    //----- Session::R2
    w->setNumRows(currentRow+1);
    s=textLabelR2sim->text()+" <";
    w->setText(currentRow, 0, "Session::R2");
    w->setText(currentRow, 1, s);
    currentRow++;    
    
    //----- Session::Time
    w->setNumRows(currentRow+1);
    s=textLabelTimeSim->text()+" <";
    w->setText(currentRow, 0, "Session::Time");
    w->setText(currentRow, 1, s);
    currentRow++;    
    
    //----- Simulate::Color
    w->setNumRows(currentRow+1);
    s=QString::number(comboBoxColor->currentItem())+" <";
    w->setText(currentRow, 0, "Simulate::Color");
    w->setText(currentRow, 1, s);
    currentRow++;    
    
    //+++ Simulate::Statistics
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Simulate::Statistics");
    if (checkBoxCovar->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");       
    currentRow++;
    
    //+++ Simulate::SaveSession
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Simulate::SaveSession");
    if (checkBoxSaveSession->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");       
    currentRow++;
    
    //+++ Simulate::Indexing
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Simulate::Indexing");
    if (checkBoxSimIndexing->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");       
    currentRow++;
    
    //+++ Simulate::Uniform
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Simulate::Uniform");
    if (radioButtonUniform_Q->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");       
    currentRow++;    
    
    //+++ Simulate::Uniform::Parameters
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Simulate::Uniform::Parameters");
    s="";
    s+=lineEditFromQsim->text()+" ";
    s+=lineEditToQsim->text()+" ";
    s+=lineEditNumPointsSim->text()+" ";
    
    if (checkBoxLogStep->isChecked()) s+="1 ";
    else s+="0 ";
    
    w->setText(currentRow,1,s+"<");       
    currentRow++;    
    
    
    
    for (int tt=0; tt<w->numCols(); tt++) 
    {
	w->table()->adjustColumn (tt);
	w->table()->setColumnWidth(tt, w->table()->columnWidth(tt)+10); 
    }
    
}

//*******************************************
// slot: Polydispersity function changed !OB
//*******************************************
void fittable::SDchanged(int poly)
{
    int oldPoly=poly;
    
    if (oldPoly!=comboBoxPolyFunction->currentItem()) oldPoly=comboBoxPolyFunction->currentItem();
    else if (oldPoly!=comboBoxPolyFunction_2->currentItem()) oldPoly=comboBoxPolyFunction_2->currentItem();
    
    
    comboBoxPolyFunction->setCurrentItem(poly);
    comboBoxPolyFunction_2->setCurrentItem(poly);
    
    int p=spinBoxPara->value();
    QString F_name=textLabelFfunc->text();
    
    //
    SANS_param_names.clear();
    SANS_param_names<<"Background"<<"Scale";
    //
    SANS_initValues.clear();
    SANS_initValues<<"0"<<"1";
    //
    SANS_adjustPara.clear();
    SANS_adjustPara<<"0"<<"0"<<"0"<<"0";
    //
    SANS_paraListComments.clear();
    QString temp="In:  Scale * ( " + F_name+"( Q,  ["+F_paraListF[0]+"..."+F_paraListF[pF-1]+"]  )  +  Background ) ";
    SANS_paraListComments<<temp<<temp;
    //
    
    pSANS= 4;
    
    if (p!=(pF+pSANS))
    {
	p=pF+pSANS;
	spinBoxPara->setValue(p);
    }  
    
    switch (poly)
    {
    case 0:  
	//"Gauss"
	SANS_param_names<<"Sigma_Gauss_SD"<<"---";
	SANS_initValues<<"0.0"<<"-1";
	SANS_paraListComments<<"Standard Deviation [1]"<<"---";
	break;   
    case 1:  
	//"Schultz-Zimm"
	SANS_param_names<<"Sigma_Schultz_SD"<<"---";
	SANS_initValues<<"0.0"<<"-1";
	SANS_paraListComments<<"Standard Deviation [1]"<<"---";
	break;   
    case 2:  
	//"Gamma" ?OB
	SANS_param_names<<"Sigma_Gamma_SD"<<"---";
	SANS_initValues<<"0.0"<<"-1";
	SANS_paraListComments<<"Sigma [1]"<<"---";
	break;	   
    case 3:  
	//"Log-Normal" ?OB
	SANS_param_names<<"Sigma_LogNormal_SD"<<"---";
	SANS_initValues<<"0.0"<<"-1";
	SANS_paraListComments<<"Standard Deviation [1]"<<"---";
	break;
    case 4: 
	//"Uniform"
	SANS_param_names<<"Sigma_uniform_SD"<<"---";
	SANS_initValues<<"0.0"<<"-1";
	SANS_paraListComments<<"Relative width of uniform SD [1]"<<"---";
	break;
    case 5: 
	//"Triangular"
	SANS_param_names<<"Sigma_A_SD"<<"Sigma_B_SD";
	SANS_initValues<<"1"<<"1";
	SANS_paraListComments<<"Relative left-width of triangular SD [.]"<<"Relative right-width of triangular SD [.]";
	break;
    default :  break;
}
    
    
    
    F_paraList=F_paraListF;
    F_paraList+=SANS_param_names; 
    tablePara->setRowLabels(F_paraList);
    tableParaSimulate->setRowLabels(F_paraList);
    
    
    //
    F_initValues=F_initValuesF;
    F_initValues+=SANS_initValues;
    //
    F_adjustPara=F_adjustParaF;
    F_adjustPara+=SANS_adjustPara;
    //
    F_paraListComments=F_paraListCommentsF;
    F_paraListComments+=SANS_paraListComments;
    
    
    tableParaComments->setText(p-4, 0, SANS_paraListComments[0]);
    tableParaComments->setText(p-3, 0, SANS_paraListComments[1]);
    tableParaComments->setText(p-2, 0, SANS_paraListComments[2]);
    tableParaComments->setText(p-1, 0, SANS_paraListComments[3]);
    tableParaComments->setRowLabels(F_paraList);
    
    
    int mm;
    int M=spinBoxNumberCurvesToFit->value();
    
    
    
    for (mm=0; mm<M;mm++)
    {
	if (tablePara->text(p-4, 3*mm+2)=="")  tablePara->setText(p-4, 3*mm+2, SANS_initValues[0]);
	if (tablePara->text(p-3, 3*mm+2)=="") tablePara->setText(p-3, 3*mm+2, SANS_initValues[1]);
	if (tablePara->text(p-2, 3*mm+2)=="" || oldPoly==5) tablePara->setText(p-2, 3*mm+2, SANS_initValues[2]);
	if (tablePara->text(p-1, 3*mm+2)==""|| oldPoly==5) tablePara->setText(p-1, 3*mm+2, SANS_initValues[3]);
    }
    
}

//*******************************************
// slot: SuperpositialFitYN support Y / N  2013
//*******************************************
void fittable::SuperpositialFitYN()
{
    if (checkBoxSuperpositionalFit->isChecked())
    {
	spinBoxSubFitNumber->setEnabled(true);
	spinBoxSubFitCurrent->setEnabled(true);
    }
    else
    {
	spinBoxSubFitNumber->setEnabled(false);
	spinBoxSubFitCurrent->setEnabled(false);
    }
    
}

//*******************************************
// slot: SANS support Y / N !OB
//*******************************************
void fittable::SANSsupportYN()
{
    bool YN=checkBoxSANSsupport->isChecked();
    int p=spinBoxPara->value();
    
    
    //+++
    if (YN && pF==0 )
    {
	QMessageBox::warning(this ,tr("QtiKWS "),
			     tr("Select Function !"));
	checkBoxSANSsupport->setChecked(FALSE);
	//	comboBoxInstrument->hide();
	comboBoxInstrument->setEnabled(false);
	return;
    }	
    
    //    if (YN) comboBoxInstrument->show();
    //    else comboBoxInstrument->hide();
    
    if (YN) comboBoxInstrument->setEnabled(true);
    else comboBoxInstrument->setEnabled(false);
    
    
    comboBoxPolyFunction->setCurrentItem(0);
    //
    
    //
    F_paraList=F_paraListF;
    
    //
    QString currentInstrument=comboBoxInstrument->currentText();	    
    QStringList resoMethods;
    
    if (YN && currentInstrument.contains("SANS") )
    {
	SDchanged(0);
	
	p=pF+pSANS;
	F_paraList+=SANS_param_names; 
	comboBoxPolyFunction->setEnabled(TRUE);
	comboBoxResoFunction->setEnabled(TRUE);
	
	resoMethods<<"Gauss-SANS"<<"Triangular"<<"Bessel-SANS"<<"Gauss";	
	
	//groupBoxResoInt->setEnabled(TRUE);
	comboBoxResoFunction->clear();
	comboBoxResoFunction->insertStringList(resoMethods);
	comboBoxResoFunction->setEnabled(TRUE);
	comboBoxSpeedControlReso->setEnabled(TRUE);
	comboBoxSpeedControlReso->setCurrentItem(3);
	speedControlReso();
	
	//groupBoxPolyInt->setEnabled(TRUE);
	comboBoxPolyFunction->setEnabled(TRUE);
	comboBoxSpeedControlPoly->setEnabled(TRUE);
	comboBoxSpeedControlPoly->setCurrentItem(3);
	speedControlPoly();
	
	F_para= gsl_vector_alloc(p);
	
	
    }
    else     if (YN && currentInstrument.contains("Back") )
    {
	p=pF;
	comboBoxPolyFunction->setEnabled(FALSE);
	comboBoxResoFunction->setEnabled(TRUE);
	
	resoMethods<<"In Function";
	
	//groupBoxResoInt->setEnabled(TRUE);	
	comboBoxResoFunction->clear();
	comboBoxResoFunction->insertStringList(resoMethods);	
	comboBoxResoFunction->setEnabled(TRUE);
	comboBoxSpeedControlReso->setEnabled(TRUE);
	comboBoxSpeedControlReso->setCurrentItem(3);
	speedControlReso();
	
	//groupBoxPolyInt->setEnabled(FALSE);
	comboBoxPolyFunction->setCurrentItem(0);
	comboBoxPolyFunction->setEnabled(false);
	comboBoxSpeedControlPoly->setEnabled(false);
	comboBoxSpeedControlPoly->setCurrentItem(3);
	speedControlPoly();
    }
    else
    {
	p=pF;
	comboBoxPolyFunction->setEnabled(FALSE);
	comboBoxResoFunction->setEnabled(FALSE);
	
	//groupBoxResoInt->setEnabled(FALSE);
	comboBoxResoFunction->setCurrentItem(0);
	comboBoxResoFunction->setEnabled(false);
	comboBoxSpeedControlReso->setEnabled(false);
	comboBoxSpeedControlReso->setCurrentItem(3);
	speedControlReso();
	
	
	//groupBoxPolyInt->setEnabled(FALSE);
	comboBoxPolyFunction->setCurrentItem(0);
	comboBoxPolyFunction->setEnabled(false);
	comboBoxSpeedControlPoly->setEnabled(false);
	comboBoxSpeedControlPoly->setCurrentItem(3);
	speedControlPoly();
    }
    spinBoxPara->setValue(p);
    
}

//***************************************************
// slot: is used when function is changed !OB
//***************************************************
void fittable::functionChangedToSD()
{
    checkBoxSANSsupport->setChecked(FALSE);
}

void fittable::fitSwitcher()
{
	fitOrCalculate(false);
}

//***************************************************
//  Switcher:  fit with SANS support or not !OB
//***************************************************
void fittable::fitOrCalculate(bool calculateYN)
{
    fitOrCalculate(calculateYN, -1);  
}

void fittable::fitOrCalculate(bool calculateYN, int mmm)
{   
    
    //+++    
    bool fitOK=true;
    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++
    if (!calculateYN) 
    {
	if ( checkBoxSANSsupport->isChecked() )  fitOK = sansFit();
	else fitOK = simplyFit();
	
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    // mmm=-1 all sets

    if (!fitOK) return; 
    
    // +++ Plot Fitting Curves via Simulate Interface
    
    //+++ to plot or not to plot
    Graph *g;
    bool graphExist=findActiveGraph(g);
    //+++ active widget
    myWidget *w;
    
    //+++ mazimaized plot?
    bool maximaizedYN=false;
    //+++
    if ( graphExist ) 
    {
	w= ( myWidget * ) app(this)->ws->activeWindow();
	if (w->status() == myWidget::Maximized) maximaizedYN=true;
    }
    
    //+++ curves to generate/plot:
    //+++ mmm==-1  all [1..M]  (fitting interface)
    //
    int mmStart, mmFinish;
	
    if (mmm>-1)
    {
	mmStart=mmm;
	mmFinish=mmm+1;
    }
    else
    {
	mmStart=0;
	mmFinish=spinBoxNumberCurvesToFit->value();
    }
    
    //+++  currrent table namr	
    QString tableName;
    //np,chi2,TSS
    int npAll=0; double chi2All=0; double TSSAll=0;
    
    //+++ finally actions
    for (int mm=mmStart; mm<mmFinish; mm++)
    {	    
	Table *ttt;
	int np=0; double chi2=0; double TSS=0;

	    
	if (widgetStackFit->id(widgetStackFit->visibleWidget())==1) 		
	{
	    generateSimulatedTable(true,1,mm, false, tableName,ttt,np,chi2,TSS);
	}
	else 
	{
	    generateSimulatedTable(true,2,mm, false, tableName,ttt,np,chi2,TSS);
	}
	
	npAll+=np;
	chi2All+=chi2;
	TSSAll+=TSS;
	
	checkConstrains(mm);
	   
	 if ( graphExist )	
	{
	     if ( tableCurves->text(0, 2*mm+1)!= "" ) AddCurve(g, tableCurves->text(0, 2*mm+1));    
	     addGeneralGurve(g, tableName, comboBoxColor->currentItem()+mm,ttt);
	 }	
     } 

    
	if ( graphExist)
	{
	    w->setActiveWindow();
//	    app(this)->updateWindowLists ( w );
	}
	
	if ( maximaizedYN)  
	{
//	    app(this)->updateWindowLists ( w );
	    w->showMaximized();
	}	
		
	//+++ chi2 
	chi2();
	
	//+++save Undo
	saveUndo();
	
	//+++ save session
	if (checkBoxSaveSession->isChecked()) saveFittingSession("fitCurve-"+textLabelFfunc->text()+"-session");
    
}


//*******************************************
//+++ fit: without SANS support
//*******************************************
bool fittable::simplyFit()
{
   return simplyFit(false);    
}


//*******************************************
//+++ fit: without SANS support
//*******************************************
bool fittable::simplyFit(bool extractData)
{
    
    //+++ Limits check    
    chekLimits();
    chekLimitsAndFittedParameters();
    
    //+++ Algorithm
    QString algorithm=comboBoxFitMethod->currentText();
        
    //+++
    int mm, np, i, ii, pp;
    int nn=0, nnn=0, nnnn=0;
    size_t pFit;
    
    //+++
    int M=spinBoxNumberCurvesToFit->value();	// Number of Curves
    int p=spinBoxPara->value();			//Number of Parameters per Curve
    int pM=p*M;					//Total Number of Parameters
    
    //+++Number of Adjustible parameters && initial paramerers
    gsl_vector_int *paramsControl= gsl_vector_int_alloc(pM);
    gsl_vector       *params= gsl_vector_alloc(pM);
    
    //+++chech Funcktion Selection: dll
    if (p==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Select Function"));
	return false;
    }
    
    //+++Read data sets to Qtotal && Itotal && Sigmatotal && dItotal && usePoint
    int Ntotal;
    double *Qtotal;
    double *Itotal; 
    double *dItotal;
    double *Sigmatotal;
    
   
    if ( !SetQandI(Ntotal, Qtotal, Itotal, dItotal, Sigmatotal) )
    {
	QMessageBox::warning(this,tr("QtiKws"),
			     tr("Fit stopped :: problem to read data!"));
	return false;
    }
    
    //+++
    if (Ntotal==0) 
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Check X-column. There is no data!"));
	return false;
    }
    
    //+++used Points
    int *usePoint=new int[Ntotal];
    int *controlM=new int[M];
    
    bool emptyLine=false;    
    
    int prec=spinBoxSignDigits->value();
    
    //+++N-Q control
    for (mm=0; mm<M; mm++)
    {
	// Q or N control
	if (tableCurves->text(1,2*mm)=="N") 
	{
	    for (ii=0; ii<tableCurves->text(1, 2*mm+1).toInt(); ii++)
	    {
		emptyLine=false;
		
		if ( fabs(Qtotal [nn]+911119.119911) < EPSDIFF || fabs(Itotal [nn]+911119.119911) < EPSDIFF  || fabs(dItotal [nn] +911119.119911) < EPSDIFF ) 	
		{
		    emptyLine=true;
		}
				
		//+++
		if (  !emptyLine && ((ii+1)>=tableCurves->text(2, 2*mm+1).toInt()) && ((ii+1)<=tableCurves->text(3, 2*mm+1).toInt())  )
		{
		    usePoint[nn]=mm+1;
		    nnn++;
		    nnnn++;
		}
		else
		{
		    usePoint[nn]=0;		    
		}
		nn++;
	    }
	    //+++
	    controlM[mm]=nnnn;
	    //+++
	    if (nnnn<2) 
	    {
		QMessageBox::warning(this,tr("QtiKWS"),
				     tr("Select Right N-Range"));
		return false;
	    }
	    nnnn=0;
	}
	else
	{
	    for (ii=0; ii<tableCurves->text(1, 2*mm+1).toInt();ii++)
	    {
		
		emptyLine=false;
		if ( fabs(Qtotal [nn]+911119.119911) < EPSDIFF || fabs(Itotal [nn]+911119.119911) < EPSDIFF  || fabs(dItotal [nn] +911119.119911) < EPSDIFF ) 	
		{
		    emptyLine=true;
		}
		//+++
		if ( !emptyLine && Qtotal[nn] >=tableCurves->text(2, 2*mm+1).toDouble() && Qtotal[nn]<=tableCurves->text(3, 2*mm+1).toDouble() )
		{
		    usePoint[nn]=mm+1;
		    nnn++;
		    nnnn++;
		}
		else
		{
		    usePoint[nn]=0;
		}
		nn++;
	    }
	    //+++
	    controlM[mm]=nnnn;
	    if (nnnn<2) 
	    {
		QMessageBox::warning(this,tr("QtiKWS"),
				     tr("Select Right Q-Range"));
		return false;
	    }
	    nnnn=0;
	}
    }
    
    //+++ N
    int N=nnn;  
       
    //+++ Parameters && Sharing && Varying 
    np=0;
    QStringList activeParaNames;
    for (pp=0; pp<p;pp++)
    {
	QCheckTableItem *itS = (QCheckTableItem *)tablePara->item(pp,0); // Share?
	QCheckTableItem *itA0 = (QCheckTableItem *)tablePara->item(pp,1); // Vary?
	
	if (itA0->isChecked()) 
	{
	    gsl_vector_int_set(paramsControl, M*pp, 0);
	    activeParaNames<<tablePara->verticalHeader()->label(pp)+ ( M > 1 ? "1" : "" ) ; // 2014-10---active para names
	    np++;
	}
	else
	{
	    gsl_vector_int_set(paramsControl, M*pp, 1);
	}
	
	gsl_vector_set(params,M*pp, tablePara->text(pp,2).toDouble());
	
	for (mm=1; mm<M;mm++)
	{
	    QCheckTableItem *itA = (QCheckTableItem *)tablePara->item(pp,3*mm+1); // Vary?
	    if (itS->isChecked())
	    {
		itA->setChecked(false);
		gsl_vector_int_set(paramsControl, M*pp+mm, 2);
		tablePara->setText(pp,3*mm+2,tablePara->text(pp,2));
	    }
	    else
	    {
		if (itA->isChecked()) 
		{
		    gsl_vector_int_set(paramsControl, M*pp+mm, 0);
		    activeParaNames<<tablePara->verticalHeader()->label(pp)+QString::number( ( mm > 0 ? mm+1 : 1 ) ); // 2014-10---active para names
		    np++;
		}
		else
		{
		    gsl_vector_int_set(paramsControl, M*pp+mm, 1);
		}
	    }
	    gsl_vector_set(params,M*pp+mm, tablePara->text(pp,3*mm+2).toDouble());
	}
    }   
    
    //+++
    if (np==0) 
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("No adjustible parameters"));
	return false;
    }
    
    //+++ Adjustible vector...
    gsl_vector *paraAdjust=gsl_vector_alloc(np);
    
    //+++Fill Adjustible vector...
    pFit=0;    
    for (i=0; i<pM; i++)
    {
	if (gsl_vector_int_get(paramsControl,i)==0) 
	{
	    gsl_vector_set(paraAdjust,pFit,gsl_vector_get(params,i));
	    pFit++;
	}
    }
    
    //+++ Adjustible vector Limits...
    gsl_vector *limitLeft=gsl_vector_alloc(np);
    gsl_vector *limitRight=gsl_vector_alloc(np);  
    
    pFit=0;    
    //+++ 
    for (pp=0; pp<p;pp++) 
    {
	for (mm=0; mm<M;mm++)
	{
	    QCheckTableItem *itA0 = (QCheckTableItem *)tablePara->item(pp,3*mm+1); // Vary?	
	    
	    if (itA0->isChecked()) 
	    {
		gsl_vector_set(limitLeft,pFit, tableControl->text(pp,0).toDouble() );
		gsl_vector_set(limitRight,pFit, tableControl->text(pp,4).toDouble() );
		
		pFit++;
	    }
	}
    }
    
    
    //+++Skippihg points... 
    double *Q, *I, *dI, *Sigma;
    
    Q 		=new double[N];
    I 		=new double[N];
    dI 		=new double[N];
    Sigma 	=new double[N];
    
    //+++ transfer "used" points
    ii=0;
    for(i=0; i<Ntotal; i++)
    {
	if (usePoint[i]>0)
	{
	    Q[ii]=Qtotal[i];
	    I[ii]=Itotal[i];
	    dI[ii]=dItotal[i];
	    Sigma[ii]=-1.0;
	    ii++;
	}
    }
    
    //+++ 
    bool polyYN=false;
    int polyFunction=-1;
    //+++ 
    bool beforeFit=false;
    bool afterFit=false;
    bool beforeIter=false;
    bool afterIter=false;
    
    
    int currentFirstPoint=0;
    int currentLastPoint=0;
    int currentPoint=0;
    
    //+++ ,tableName,tableColNames,tableColDestinations,mTable
    std::string tableName="no-matrix";
    std::string *tableColNames; 
    int *tableColDestinations; 
    gsl_matrix * mTable;

    functionT paraT={F_para, Q, I, Sigma, currentFirstPoint, currentLastPoint, currentPoint, polyYN, polyFunction, beforeFit, afterFit, beforeIter, afterIter, 1.0, 1.0, 1.0, 0, prec,tableName,tableColNames,tableColDestinations,mTable};
    
    
    //+++ init parameters of F
    F.params= &paraT;
    
    //+++
    gsl_function FF;
    FF.function = F.function;
    FF.params= &paraT;
    //+++
    simplyFitP paraSimple = {N,M,p,np,Q,I,dI, controlM, params, paramsControl, &FF,limitLeft,limitRight};	
        
    //+++ Fit control parameters
    int d_max_iterations=spinBoxMaxIter->value();
    double d_tolerance=lineEditTolerance->text().toDouble();
    double absError=lineEditToleranceAbs->text().toDouble();
    if (d_tolerance<0) 	d_tolerance=0;
    if (absError<0) 		absError=0;
    

    
    size_t iter = 0;
    int status;
    
    //+++Time of Fit Run
    QTime dt = QTime::currentTime ();
    
    double dof = N - np;
    
    //+++ switch off gsl-error handler
    gsl_set_error_handler_off();
  
    
    int progressIter=0;
    bool showProgress=true;
    
    if (extractData) goto extractDataLabel;  //+++ NO FITTING
  
    
    //+++ Progress dialog    
    if (algorithm.contains("[GenMin]") || setToSetProgressControl ) showProgress=false;
    

    QProgressDialog *progress;
    
    if (showProgress)
    {	
	progress=new QProgressDialog( "Start |\n\n\n\n\n\n", "Abort FIT", spinBoxMaxIter->text().toInt()+1, this, "Maximal Number of Iterations"+spinBoxMaxIter->text()+". Progress:", TRUE );
	progress->setMinimumDuration(2000);
	
	//+++ Start +++  1
	progressIter++;
	progress->setProgress( progressIter );    
    }
    //--- Progress dialog

    
    
    if (algorithm.contains("[GenMin]") )    
    {
	genome_count=spinBoxGenomeCount->value();
	generations=spinBoxMaxNumberGenerations->value(); 
	selection_rate=lineEditSelectionRate->text().toDouble();
	mutation_rate=lineEditMutationRate->text().toDouble();
	random_seed=spinBoxRandomSeed->value();
	
	int problem_dimension;
	double	*tempx,*tempg;
	
	srand(random_seed);
	srand(random_seed); //+++ srand48
	
	problem_dimension=np;
	
	tempx=new double[problem_dimension];
	tempg=new double[problem_dimension];
	
	Problem myproblem(problem_dimension);
	
	myproblem.YN2D(false);
	myproblem.sansSupportYN(false); // no SANS support
	myproblem.setSimplyFitP(paraSimple);
	myproblem.dof=dof;
        
	DataG	 L,R;
	L.resize(problem_dimension);
	R.resize(problem_dimension);
	
	double leftFactor=lineEditLeftMargin->text().toDouble();
	leftFactor=fabs(leftFactor);
	
	double rightFactor=lineEditRightMargin->text().toDouble();
	rightFactor=fabs(rightFactor);
	
	double currentParameter, currentLeftLimit, currentRightLimit;
	
	for(int i=0;i<problem_dimension;i++)
	{
	    currentParameter=gsl_vector_get(paraAdjust,i);
	    //+++
	    currentLeftLimit=gsl_vector_get(limitLeft,i);
	    currentRightLimit=gsl_vector_get(limitRight,i);
	    
	    if (currentLeftLimit>-1.0E308)
	    {
		L[i]=currentLeftLimit; 
	    }
	    else
	    { 
		if (leftFactor<=1) leftFactor=2;
		
		if (currentParameter>0)
		{	
		    L[i]=currentParameter/leftFactor;
		}
		else if  (currentParameter<0)
		{
		    L[i]=currentParameter*leftFactor;
		}
		else
		{
		    L[i]=-leftFactor;
		}
	    }
	    
	    if (currentRightLimit<1.0E308)
	    {
		R[i]=currentRightLimit;

	    }
	    else
	    {
		if (rightFactor<=1) rightFactor=2;
		
		if (currentParameter>0)
		{	
		    R[i]=currentParameter*rightFactor;
		}
		else if  (currentParameter<0)
		{
		    R[i]=currentParameter/rightFactor;
		} 
		else
		{
		    R[i]=rightFactor;
		}
	    }
	}
	
	myproblem.setLeftMargin(L);
	myproblem.setRightMargin(R);	
	
	myproblem.fln.f = &function_fm;
	myproblem.fln.df =&function_dfm;
	myproblem.fln.fdf = &function_fdfm;
	myproblem.fln.n = N;
	myproblem.fln.p = np;
	myproblem.fln.params = &paraSimple;  
	
	
	GenMin opt(&myproblem);
	
	//
	opt.Solve();
	
	DataG x;
	double y;
	x.resize(problem_dimension);
	
	opt.getMinimum(x,y);
	
	opt.localSearchGSL(x,prec,5,0,0);
	opt.localSearch(x);
	opt.localSearchGSL(x,prec,d_max_iterations,d_tolerance,absError);
	
	printf("X = [");
	for(int i=0;i<problem_dimension;i++)
	{
	    printf(" %lg ",x[i]);	
	}
	
	printf("] \nchi^2 =%lg\n",y/dof);
	printf("FUNCTION CALLS =%6d\nGRADIENT CALLS=%6d\n\n", myproblem.fevals,myproblem.gevals);
		
	for (int pp=0; pp<np;pp++) gsl_vector_set(paraAdjust, pp, x[pp]);
	
	delete[] tempx;
	delete[] tempg;
    }
    else if (algorithm.contains("Nelder-Mead Simplex"))    
    {
	//+++
	gsl_multimin_function f;
	
	f.f = &function_dm;
	f.n = np;
	f.params = &paraSimple;	  
	
	const gsl_multimin_fminimizer_type *TT;
	
	if (algorithm.contains("nmsimplex2rand"))
	    TT=gsl_multimin_fminimizer_nmsimplex2rand;
	else if (algorithm.contains("nmsimplex2"))
	    TT=gsl_multimin_fminimizer_nmsimplex2;
	else 
	    TT=gsl_multimin_fminimizer_nmsimplex;
	
	gsl_vector *ss = gsl_vector_alloc (np);
	
	//+++set all step sizes to 1 can be increased to converge faster
	gsl_vector_set_all (ss,1.0);
	
	gsl_multimin_fminimizer *s_min = gsl_multimin_fminimizer_alloc (TT, np);
	
	status = gsl_multimin_fminimizer_set(s_min, &f, paraAdjust, ss);
	
	QString s;
	if (status != 0) 
	{
	    s=s.setNum(status);
	    QString report=tr("<b> %1 </b>: GSL error -1- :: ").arg(s);
	    report+= gsl_strerror (status); 
	    QMessageBox::warning(this, tr("QtiKws"),report);          
	    
	    //+++ Delete  Variables
	    delete[]  usePoint;
	    delete[] controlM;
	    delete[] Q;
	    delete[] I;
	    delete[] dI;
	    delete[] Sigma;
	    delete[] Qtotal;
	    delete[] Itotal;
	    delete[] dItotal;
	    delete[] Sigmatotal;	    
	    gsl_vector_free(limitLeft);
	    gsl_vector_free(limitRight); 
	    gsl_vector_free(params); 
	    gsl_vector_int_free(paramsControl);
	    gsl_vector_free(paraAdjust);
	    gsl_multimin_fminimizer_free (s_min);
	    
	    if (showProgress)
	    {
		progress->cancel();
	    }
	    return false;
	}
	
	double size;
	iter=0;
	QString st;
	double chi2local;
	
	do
	{	
	    if (showProgress)
	    {
		//+++ Fit Started 1
		progressIter++;		
		
		if (iter>0)
		{
		    chi2local=function_dm (s_min->x, &paraSimple)/dof;
		    
		    st="";
		    st="Started | Loaded | Fitting > Iterations\n\n";
		    st=st+algorithm+"\n\n";
		    st=st+" # \t\t\t\t\t\t\t Stopping Criterion \t\t\t\t\t\t\t chi^2 \n";
		    st=st+QString::number(iter)+"[<"+QString::number(d_max_iterations)+"] \t\t\t "+QString::number(size, 'E',prec)+" [<"+QString::number(d_tolerance,'E',prec)+"] \t\t\t "+QString::number(chi2local,'E',prec+4)+"\n\n";
		    progress->setLabelText(st);
		}
		progress->setProgress( progressIter );
		if ( progress->wasCanceled() ) 
		{	    
		    break;
		}
	    }
	    iter++;
	    
	    status = gsl_multimin_fminimizer_iterate (s_min); 		
	    size=gsl_multimin_fminimizer_size (s_min);
	    status = gsl_multimin_test_size (size, d_tolerance);
	    
	    if (chi2local==0.0) break;
	}
	    while (status == GSL_CONTINUE && (int)iter < d_max_iterations);	
	
	for (int pp=0; pp<np;pp++) gsl_vector_set(paraAdjust, pp, gsl_vector_get(s_min->x, pp));	
	
	gsl_vector_free(ss);
	gsl_multimin_fminimizer_free(s_min);
    }    
    else
    {
	//+++++
	const gsl_multifit_fdfsolver_type *Tln;
	
	gsl_multifit_fdfsolver *sln;
	gsl_multifit_function_fdf fln;
	
	fln.f = &function_fm;
	fln.df =&function_dfm;
	fln.fdf = &function_fdfm;
	fln.n = N;
	fln.p = np;
	fln.params = &paraSimple;  
	
	//+++
	if (algorithm.contains("Unscaled"))
	    Tln = gsl_multifit_fdfsolver_lmder;
	else     
	    Tln = gsl_multifit_fdfsolver_lmsder;	
	
	bool deltaStop=false;
	if (algorithm.contains("Delta")) deltaStop=true;
			
	//+++
	sln = gsl_multifit_fdfsolver_alloc(Tln, N,np);
	
	//+++
	status=gsl_multifit_fdfsolver_set(sln, &fln, paraAdjust);

	//+++ 
	QString s;
	if (status != 0) 
	{
	    s=s.setNum(status);
	    QMessageBox::warning(this, tr("QtiKWS"),
				 tr("<b> %1 </b>: GSL error -3-").arg(s));        
	    //+++ Delete  Variables 
	    delete[]  usePoint;
	    delete[] controlM;
	    delete[] Q;
	    delete[] I;
	    delete[] dI;
	    delete[] Sigma;
	    delete[] Qtotal;
	    delete[] Itotal;
	    delete[] dItotal;
	    delete[] Sigmatotal;	    
	    gsl_vector_free(limitLeft);
	    gsl_vector_free(limitRight); 
	    gsl_vector_free(params); 
	    gsl_vector_int_free(paramsControl);
	    gsl_vector_free(paraAdjust);
	    gsl_multifit_fdfsolver_free (sln);	
	    if (showProgress)
	    {
		if (progress) delete progress;
	    }  
	    return false;
	}
	
	iter=0;
	
	//+++
	double ssize=0;
	//+++
	QString st;
	//+++
	double tmp;
	//+++
	gsl_vector *vec=gsl_vector_alloc(np);
	//+++
	double chi2local;	
	
	do
	{
	    if (showProgress)
	    {
		//+++ Fit Started 1
		progressIter++;
		
		if (iter>0)
		{
		    ssize=0;
		    if (deltaStop)
		    {
			for (int vvv=0;vvv<np;vvv++) 
			{
			    tmp=fabs(gsl_vector_get(sln->dx, vvv))-d_tolerance*fabs(gsl_vector_get(sln->x, vvv));
			    if (tmp>ssize) ssize=tmp; 
			}
		    }
		    else
		    {
			for (int vvv=0;vvv<np;vvv++) 
			{
			    ssize+=fabs(gsl_vector_get(vec, vvv));
			}	
		    }	
		    
		    chi2local=function_dm (sln->x, &paraSimple)/dof;
		    
		    st="";
		    st="Started | Loaded | Fitting > Iterations\n\n ";
		    st=st+algorithm+"\n\n";
		    st=st+" # \t\t\t\t\t\t\t Stopping Criterion \t\t\t\t\t\t\t chi^2 \n";
		    st=st+QString::number(iter)+"[<"+QString::number(d_max_iterations)+"] \t\t\t "+QString::number(ssize, 'E',prec)+" [<"+QString::number(absError)+"] \t\t\t "+QString::number(chi2local,'E',prec+4)+"\n\n";
		    
		    progress->setLabelText(st);
		}
		
		progress->setProgress( progressIter );
		if ( progress->wasCanceled() ) 
		{
		    break;
		}
	    }
	    iter++;
	    
	    
	    status = gsl_multifit_fdfsolver_iterate (sln);
	    
	    if (deltaStop)
		status = gsl_multifit_test_delta (sln->dx, sln->x, absError, d_tolerance);
	    else
	    {
		gsl_multifit_gradient(sln->J, sln->f,vec);
		status = gsl_multifit_test_gradient (vec, absError);	
	    }
	if (chi2local==0.0) break;
	}
	while (status == GSL_CONTINUE && (int)iter < d_max_iterations);
	
	for (int pp=0; pp<np;pp++) gsl_vector_set(paraAdjust, pp, gsl_vector_get(sln->x, pp));
	
	gsl_multifit_fdfsolver_free (sln);
	gsl_vector_free(vec); 
    }
    
extractDataLabel: ;    
    
    //+++ 
    double tmp;
    for (int pp=0; pp<np;pp++)
    {
	tmp= gsl_vector_get(paraAdjust, pp);
	
	if ( tmp < gsl_vector_get(limitLeft,pp) ) 
	    gsl_vector_set(paraAdjust,pp,gsl_vector_get(limitLeft,pp)); 
	else if ( tmp>gsl_vector_get(limitRight,pp) ) 
	    gsl_vector_set(paraAdjust,pp,gsl_vector_get(limitRight,pp)); 
	else
	    gsl_vector_set(paraAdjust,pp,tmp);    
    }
    
    //+++ Chi
    double chi =sqrt(function_dm (paraAdjust, &paraSimple));
    double c = chi / sqrt(dof);
    
    //+++ Jacobian J
    

    gsl_matrix *J = gsl_matrix_alloc(N, np); 	
    function_dfm(paraAdjust,&paraSimple,J);
    
    //+++ Covariant
    gsl_matrix *covar = gsl_matrix_alloc (np,np);    
    gsl_multifit_covar (J, 0.0, covar);
        
    //+++
#define FIT(i) gsl_vector_get(paraAdjust, i)
#define ERR(i) sqrt(gsl_matrix_get(covar,i,i))
    
    int digits=spinBoxSignDigits->value()-1;		
    int npnp=0;
    
    //+++ Results to Interface
    for (pp=0; pp<p; pp++)  for(mm=0; mm<M; mm++)  
    {
	if (gsl_vector_int_get(paramsControl,M*pp+mm) == 0) 
	{
	    tablePara->setText(pp,3*mm+2, QString::number(FIT(npnp),'G',digits+1));
	    tablePara->setText(pp,3*mm+3, QString::number(c*ERR(npnp),'G',digits+1));
	    gsl_vector_set(params,M*pp+mm,FIT(npnp));
	    npnp++;
	}
	else if (gsl_vector_int_get(paramsControl,M*pp+mm) == 2)
	{
	    tablePara->setText(pp,3*mm+2, tablePara->text(pp,2));
	    tablePara->setText(pp,3*mm+3, "---");
	}
	else
	{
	    tablePara->setText(pp,3*mm+3, "---");
	}			
    }
     
    //+++ Covariant Matrix and errors
    if (checkBoxCovar->isChecked() || extractData) 
    {
	double chiWeight2=0;
	for(nn=0; nn<N; nn++) if (dI[nn]!=0.0) chiWeight2+=1/dI[nn]/dI[nn]; else chiWeight2++;
	chiWeight2=chiWeight2/N;
	
	
	QString info=covarMatrix(N, np, chi, chiWeight2, activeParaNames, covar, paraAdjust);
	
	makeNote(info, "fitCurve-"+comboBoxFunction->currentText()+"-statistics", "TableFit :: statistics info ");	
    }
    
    //+++Time After Fit Run
    textLabelTime->setText(QString::number(dt.msecsTo(QTime::currentTime()), 'G',3)+" ms");

    if (showProgress && progress) delete progress;
        
    //+++ Delete  Variables
    delete[]  usePoint;
    delete[] controlM;
    delete[] Q;
    delete[] I;
    delete[] dI;
    delete[] Qtotal;
    delete[] Itotal;
    delete[] dItotal;
    delete[] Sigmatotal;
 
    gsl_vector_free(limitLeft);
    gsl_vector_free(limitRight); 

    gsl_vector_free(params); 
    gsl_vector_int_free(paramsControl);
    gsl_vector_free(paraAdjust);
    gsl_matrix_free(covar); 
    gsl_matrix_free(J); 
    
    return true;
}


//*******************************************
//+++  set PATH
//*******************************************
void fittable::setPath()
{
    //+++
    QString dir=libPath ;
    QDir dirOld(dir);
    //+++
    if (!dirOld.exists()) dirOld=QDir::homeDirPath();
    
    QDir dirNew;	
    dir = QFileDialog::getExistingDirectory(dir,this,"path to *.fif Functions"  "Choose a directory");
    if (dir=="") 
    {
	QMessageBox::warning(this,tr("QtiKWS"), tr("...Set Real Path..."));
	return;
    }
    else
    {
	dirNew.setPath(dir);
	libPath=dirNew.path(); 			
    }
    scanGroup();
}

//*******************************************
//+++  scan Group
//*******************************************
void fittable::scanGroup()
{
    int i;
    QString s;
    QStringList group;
    QString groupName;
    
    //group<<"ALL";
    
    // +++ WIN    
#if defined( Q_OS_WIN)
    QString filter="*.dll";
    
    // +++  MAC
#elif defined(Q_OS_MAC)
    QString filter="*.dylib";    
    
    // +++ UNIX
#else
    QString filter="*.so";
#endif
    
    QDir d(libPath);
    
    QStringList lstFIF = d.entryList("*.fif");
    
    for(i=0;i<lstFIF.count();i++) 
    {
	if (d.exists(lstFIF[i]))
	{
	    QFile f(libPath+"/"+lstFIF[i]);
	    f.open( IO_ReadOnly );
	    QTextStream t( &f );
	    
	    //+++[group]  
	    s = t.readLine();
	    if (s.contains("[group]")>0) 
	    {
		groupName=t.readLine().stripWhiteSpace();
		if (!group.contains(groupName) && groupName!="") group<<groupName;
	    }
	    
	    f.close();
	}
    }
    
    group.sort();
    group.prepend("ALL");
    listBoxFunctions->clear();
    listBoxGroup->clear();
    listBoxGroup->insertStringList (group);
    
}

//*******************************************
//+++  fing functions of single Group
//*******************************************
void fittable::groupFunctions( const QString &groupName )
{
    int i;
    QString s;
    QStringList functions;
    
    // +++ WIN    
#if defined( Q_OS_WIN )
    QString filter="*.dll";
    
    // +++  MAC
#elif defined(Q_OS_MAC)
    QString filter="*.dylib";    
    
    // +++ UNIX     
#else
    QString filter="*.so";
#endif
    
    
    QDir d(libPath);
    
    QStringList lst = d.entryList(filter);
    QStringList lstFIF = d.entryList("*.fif");
    QStringList lstALL;
    
    bool onlyEFIT;
    
    for(i=0;i<lst.count();i++) 
    {
	onlyEFIT=checkBoxShowEFIT->isChecked();
	
	QFileInfo fi(libPath+"/"+lst[i]);
	QString base=fi.baseName();
	if (d.exists (lst[i]) && d.exists (base+".fif"))
	{
	    lstALL<<base;
	    QFile f(libPath+"/"+base+".fif");
	    f.open( IO_ReadOnly );
	    QTextStream t( &f );
	    
	    //+++[group]  
	    s = t.readLine();
	    if (!onlyEFIT || (onlyEFIT && s.contains("[eFit]"))) onlyEFIT=true;
	    else onlyEFIT=false;
	    
	    if (s.contains("[group]")>0) 
	    {
		if ((groupName=="ALL" || t.readLine().stripWhiteSpace()==groupName) && onlyEFIT) functions<<base;
	    }
	    
	    f.close();
	}
    }
    lstALL.sort();
    listBoxFunctions->clear();
    //    if (groupName=="ALL") 	listBoxFunctions->insertStringList (lstALL);
    //    else listBoxFunctions->insertStringList (functions);
    functions.sort();
    listBoxFunctions->insertStringList (functions);
    
    if (functions.count()>0) listBoxFunctions->setCurrentItem(0);
    else spinBoxPara->setValue(0);
    
}

// +++
void fittable::colList( QString tableName, int col)
{
    int i;
    QStringList lst,lstDI,lstSigma;
    
    QWidgetList *windows = app(this)->windowsList();
    
    if (tableName!="")
    {
	lstDI= app(this)->columnsList(Table::yErr);
	lstDI=lstDI.grep(tableName);
	lstSigma= app(this)->columnsList(Table::xErr);
	lstSigma=lstSigma.grep(tableName);
    }
    
    int Raws=0;
    for (i=0;i<(int)windows->count();i++)
    {
	if (windows->at(i) && windows->at(i)->isA("Table") && windows->at(i)->name()==tableName)
	{
	    Table* table = (Table*)windows->at(i);
	    lst=table->columnsList();
	    Raws=table->numRows();
	}
    }
    
    setSigmaAndWeightCols(lst,lstDI,lstSigma,col,Raws);
    
}


// +++  Add Curve  +++
bool fittable::AddCurve(Graph* g,QString curveName)
{
    int ii;
    
    Table* table;
    
    int xColIndex, yColIndex;
    
    if ( !findFitDataTable(curveName, table, xColIndex,  yColIndex ) ) return false;
    
    // check Table
    int  nReal=0;
    for (ii=0; ii<table->numRows(); ii++) if ((table->text(ii,0))!="") nReal++;
    //
    if (nReal<=2) 
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Check Data Sets"));
	return false;
    }
    
    QStringList contents;
    contents=g->curvesList();
    
    if (g && table && !contents.contains(curveName)) 
    {
	int scatterCounter=0; 

	for (int i=0; i<contents.count();i++)
	{
	    QwtPlotCurve *c = g->curve(i);
	    if (!c) break;
	    int curveType = g->curveType(i);
	    if ( curveType == Graph::Scatter) scatterCounter++;
	}
	
	int style = Graph::Scatter;
	g->insertCurve(table, curveName, style); 
	curveLayout cl = Graph::initCurveLayout();
		
	
	int color =(scatterCounter)%15;
	if (color >= 13) color++; 
	int shape=(scatterCounter)%15+1;
	
	if (scatterCounter==0)
	{
	    color=0;
	    shape=1;
	}
	
	cl.lCol=color;
	cl.symCol=color;
	cl.fillCol=color;
	cl.aCol=color;
	cl.lWidth = app(this)->defaultCurveLineWidth;
	cl.sSize = app(this)->defaultSymbolSize;
	
	cl.sType=shape;
	
	g->updateCurveLayout(contents.count(), &cl);
	g->replot();
    }
    return TRUE;
}


//***************************************************
//  Switcher:  simulate with SANS support or not
//***************************************************
void fittable::simulateSwitcher()
{
    pushButtonSimulate->setFocus();
    
    if (radioButtonSameQrange->isChecked() && comboBoxDatasetSim->currentText()=="")
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Dataset does not exist !!!"));
	return;
    }
    
    
    QString tableName;
    Graph *g;
    bool graphExist=findActiveGraph(g);
    bool maximaizedYN=false;
    myWidget *w;
    
    if ( graphExist ) 
    {
	w= ( myWidget * ) app(this)->ws->activeWindow();
	if (w->status() == myWidget::Maximized && w->isA("MultiLayer") ) 
	{
	    maximaizedYN=true;
	}
    }
        
    
    int mm=comboBoxDatasetSim->currentItem();
    
    Table *ttt;
    //np,chi2,TSS
    int np=0;
    double chi2=0;
    double TSS=0;
    
    generateSimulatedTable(true,0,mm, true, tableName,ttt,np,chi2,TSS);
     
    // +++ constrains
    checkConstrains(-1);
    
    
    if ( graphExist &&  maximaizedYN)  
    {
//	app(this)->updateWindowLists ( w );
	app(this)->modifiedProject (w );
	w->showMaximized();
    }
    
    int mmm=0;
    if (!textLabelFfunc->text().contains("superpositional-") && checkBoxSimIndexing->isChecked())
    {
	QString tName=ttt->name();
	QStringList lst;
	lst.clear();
	lst=lst.split("-",tName,false);
	mmm=lst[lst.count()-1].toInt();
    }
    if ( graphExist)  addGeneralGurve(g, tableName, comboBoxColor->currentItem()+mmm,ttt);    

    if (checkBoxSaveSession->isChecked()) saveFittingSessionSimulation(mm, tableName+"-session") ;
}


//***************************************************
//  Multi Table:: select Pattern
//***************************************************
void fittable::selectPattern()
{
    tableMultiFit->setNumRows(1);
    
    QStringList tables, tablesAll;
    //	tables<<"All";
    tablesAll=app(this)->tableWindows;
    
    QRegExp rx( lineEditPattern->text());
    rx.setWildcard( TRUE );
    
    int i,j;
    for (i=0; i<tablesAll.count();i++) if (rx.exactMatch(tablesAll[i])) tables<<tablesAll[i];
    
    tables.prepend("All");
    tableMultiFit->setNumRows(tables.count());
    tableMultiFit->setRowLabels(tables);
    
    for (i=1; i<tables.count();i++)
    {
	// +++
	QCheckTableItem *yn = new QCheckTableItem(tableMultiFit, QString::null );
	tableMultiFit->setItem(i,0, yn);
	// +++
	QComboTableItem *yCol = new QComboTableItem(tableMultiFit, QString::null );
	tableMultiFit->setItem(i,1,yCol);
	// +++
	QComboTableItem *dYcol = new QComboTableItem(tableMultiFit, QString::null );
	tableMultiFit->setItem(i,2,dYcol);
	
	QRegExp rxCol(tables[i]+"_*");
	rxCol.setWildcard( TRUE );
	
	QStringList cols,colTemp;
	
	// +++
	colTemp=app(this)->columnsList(Table::Y);
	for (j=0; j<colTemp.count();j++)
	{
	    if (rxCol.exactMatch(colTemp[j])) cols<<colTemp[j].remove(tables[i]+"_");
	}
	yCol->setStringList(cols);
	// +++
	cols.clear();
	colTemp=app(this)->columnsList(Table::yErr);
	for (j=0; j<colTemp.count();j++)
	{
	    if (rxCol.exactMatch(colTemp[j])) cols<<colTemp[j].remove(tables[i]+"_");
	}
	dYcol->setStringList(cols);
	int start=3;
	if (checkBoxSANSsupport->isChecked())
	{
	    // +++
	    QComboTableItem *xCol = new QComboTableItem(tableMultiFit, QString::null );
	    tableMultiFit->setItem(i,3,xCol);
	    
	    cols.clear();
	    colTemp=app(this)->columnsList(Table::xErr);
	    for (j=0; j<colTemp.count();j++)
	    {
		if (rxCol.exactMatch(colTemp[j])) cols<<colTemp[j].remove(tables[i]+"_");
	    }
	    
	    QString currentInstrument=comboBoxInstrument->currentText();
	    if ( currentInstrument.contains("Back") ) cols<<"from SPHERES";	    
	    else cols<<"from DANP";
	    
	    xCol->setStringList(cols);
	    
	    // +++
	    start++;
	}
	
	// +++Start values & adjustibility trasfer
	for (j=start;j<tableMultiFit->numCols();j++) 
	{
	    tableMultiFit->setText(i,j,tablePara->text(j-start,2));
	    QCheckTableItem *fitYN = (QCheckTableItem*)tableMultiFit->item (0,j);
	    QCheckTableItem *fitYN0 = (QCheckTableItem*)tablePara->item (j-start,1);
	    if (fitYN0->isChecked()) fitYN->setChecked(TRUE); else fitYN->setChecked(FALSE);
	}
    }
    // +++Weiting option
    QCheckTableItem *wYN = (QCheckTableItem*)tableMultiFit->item (0,2);
    QCheckTableItem *wYN0 = (QCheckTableItem*)tableCurves->item (4,0);
    if (wYN0->isChecked()) wYN->setChecked(TRUE); else wYN->setChecked(FALSE);
    // +++reso
    if (checkBoxSANSsupport->isChecked())
    {
	QCheckTableItem *rYN = (QCheckTableItem*)tableMultiFit->item (0,3);
	QCheckTableItem *rYN0 = (QCheckTableItem*)tableCurves->item (5,0);
	if (rYN0->isChecked()) rYN->setChecked(TRUE); else rYN->setChecked(FALSE);
    }
    
    for (int tt=0; tt<tableMultiFit->numCols();tt++) tableMultiFit->adjustColumn(tt);    
}

// +++
void fittable::setBySetFit()
{
    setToSetSimulYN=false;
    setBySetFitOrSim(true);
}

void fittable::setBySetFitOrSim(bool fitYN)
{
    int i,j; 
    int start=3;
    int Nselected=0;
    int p=spinBoxPara->value();
    
    bool weight=false,reso=false,poly=false;
    QStringList tables, colList, weightColList,resoColList, commentList;
    QString s;
    QString SANSsupport="No";
    QString polyUse="No";
    
    // +++ check #1
    int Ntot=tableMultiFit->numRows()-1;  // number of Availeble Datasets in table
    
    if (Ntot==0) 
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     "There is no table | Select datasets! | Use [Select] button ");
	return;	
    }
    
    //+++ Progress dialog
    int progressIter=0;
    
    QProgressDialog progress( "Set-to-Set Fit", "Abort Set-To-Set FIT", Ntot,
			      this, "Progress ::", TRUE );
    
    progress.setMinimumDuration(1000);
    
    
    setToSetProgressControl=true;   
    
    // +++ weight
    QCheckTableItem *wYN = (QCheckTableItem*)tableMultiFit->item (0,2);
    if (wYN->isChecked()) weight=true; 
    
    // +++ reso
    if (checkBoxSANSsupport->isChecked())
    {
	QCheckTableItem *rYN = (QCheckTableItem*)tableMultiFit->item (0,3);
	if (rYN->isChecked()) reso=true;
	QCheckTableItem *pYN = (QCheckTableItem*)tableCurves->item(6,0);
	if (pYN->isChecked()) poly=true;
	if (poly)
	{
	    polyUse="Yes";
	}
	start++;
	SANSsupport="Yes";
    }
    
    // +++ check #2
    for (i=0; i<Ntot;i++)
    {
	QCheckTableItem *selectedYN = (QCheckTableItem*)tableMultiFit->item (i+1,0);
	if (selectedYN->isChecked()) 
	{
	    tables<<tableMultiFit->verticalHeader()->label(i+1);
	    s=tableMultiFit->verticalHeader()->label(i+1) +" |t| ";
	    colList<<tableMultiFit->text(i+1,1);
	    s+=tableMultiFit->text(i+1,1)+" |y| ";
	    if (weight) {weightColList<<tableMultiFit->text(i+1,2); s+=tableMultiFit->text(i+1,2) +" |w| ";} else s+=" |w| " ;
	    if (reso) {resoColList<<tableMultiFit->text(i+1,3); s+=tableMultiFit->text(i+1,3)+" |r| ";} else s+=" |r| " ;
	    commentList<<s;
	    Nselected++;			
	}
    }
    
    
    if (Nselected==0) 
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     "There are no SELECTED tables | Select datasets! ");
	return;	
    }
    
    
    
    // current folder
    //Folder *cf = ( Folder * ) app(this)->current_folder;	
    //app(this)->changeFolder("FIT :: 1D");	
    
    // +++  create Table
    Table *t;
    s=app(this)->generateUniqueName(tr("Set-By-Set-Fit-"+lineEditSetBySetFit->text()));
    t=app(this)->newHiddenTable(s, "Fitting Results:: Set-By-Set", GSL_MAX(Nselected,19), 2+1+1+3+2*p);
    
    t->setWindowLabel("Fitting Results:: Set-By-Set");
    
    app(this)->setListViewLabel(t->name(), "Fitting Results:: Set-By-Set");
    app(this)->updateWindowLists(t);
    
    t->setColName(0,"Parameter");
    t->setColPlotDesignation(0,Table::None);
    
    t->setColName(1,"Value");	
    t->setColPlotDesignation(1,Table::None);
    
    t->setColName(2,"X");
    t->setColPlotDesignation(2,Table::X);
    
    t->setColName(3,"Dataset");
    t->setColName(4,"Chi2");
    t->setColName(5,"R2");
    t->setColName(6,"Fit-Time");	
    
    s="-> ";
    for (i=0;i<p;i++)
    {
	if (i<(p-1)) s+=F_paraList[i]+" , "; else s+=F_paraList[i]; 
	t->setColName(7+2*i,F_paraList[i]);	
	t->setColName(7+2*i+1,"d"+F_paraList[i]);
	t->setColPlotDesignation(7+2*i+1,Table::yErr);
    }
    // Fit Conrtrol
    int currentChar=0;
    
    // +++  Fitting Function
    t->setText(currentChar,0,"Fitting Function"); t->setText(currentChar,1,"-> " + textLabelFfunc->text()); currentChar++;
    // +++  Number of Parameters   
    t->setText(currentChar,0,"Number of Parameters"); t->setText(currentChar,1,"-> "+QString::number(p));currentChar++;
    // +++  Parameters   
    t->setText(currentChar,0,"Parameters"); t->setText(currentChar,1,s); currentChar++;    
    //+++ Multi Mode
    t->setText(currentChar,0,"Number of Datasets"); t->setText(currentChar,1,"-> 1");currentChar++;
    //+++ SANS Mode
    t->setText(currentChar,0,"SANS Mode"); t->setText(currentChar,1,"-> "+SANSsupport);currentChar++;    
    //+++ Resolusion On 
    if (reso && checkBoxSANSsupport->isChecked()) SANSsupport="Yes"; else SANSsupport="No";
    t->setText(currentChar,0,"Resolution On"); t->setText(currentChar,1,"-> "+ SANSsupport);currentChar++;
    //+++ Weight On
    if (weight) SANSsupport="Yes"; else SANSsupport="No";
    t->setText(currentChar,0,"Weight On"); t->setText(currentChar,1,"-> "+SANSsupport);currentChar++;
    //+++ Polydispersity On 
    t->setText(currentChar,0,"Polydispersity On"); t->setText(currentChar,1,"-> "+polyUse);currentChar++;
    //+++ Polydispersity Parameter 
    t->setText(currentChar,0,"Polydisperse Parameter");
    if (checkBoxSANSsupport->isChecked())  t->setText(currentChar,1,"-> "+tableCurves->text(6,1));
    else t->setText(currentChar,1,"-> No");
    currentChar++;
    
    //+++ Fitting Range: From x[min] 
    t->setText(currentChar,0,"Fitting Range: From x[min]"); t->setText(currentChar,1,"-> "+lineEditFromQ->text());currentChar++;
    //+++ Fitting Range: To x[max] 
    t->setText(currentChar,0,"Fitting Range: To x[max]"); t->setText(currentChar,1,"-> "+lineEditToQ->text());currentChar++;
    
    //+++ Simulation Range: x-Range Source
    t->setText(currentChar,0,"Simulation Range: x-Range Source");
    if (radioButtonSameQrange->isChecked() ) 
	t->setText(currentChar,1,"-> Same Q as Fitting Data");
    else 
	t->setText(currentChar,1,"-> Uniform Q");
    currentChar++;
    //+++ Simulation Range: x-min
    t->setText(currentChar,0,"Simulation Range: x-min");
    t->setText(currentChar,1,"-> "+lineEditFromQsim->text());
    currentChar++;
    //+++ Simulation Range: x-max
    t->setText(currentChar,0,"Simulation Range: x-max");
    t->setText(currentChar,1,"-> "+lineEditToQsim->text());
    currentChar++;
    //+++ Simulation Range: Number Points
    t->setText(currentChar,0,"Simulation Range: Number Points");
    t->setText(currentChar,1,"-> "+lineEditNumPointsSim->text());
    currentChar++;
    //+++ Simulation Range: Logarithmic Step
    t->setText(currentChar,0,"Simulation Range: Logarithmic Step");
    if (checkBoxLogStep->isChecked() ) 
	t->setText(currentChar,1,"-> Yes");
    else
	t->setText(currentChar,1,"-> No");
    currentChar++;    
    
    
    //+++ Fit-Control
    QString line;
    line=QString::number(comboBoxFitMethod->currentItem())+" , ";
    line+=spinBoxMaxIter->text() +" , ";
    line+=lineEditTolerance->text() +" , ";
    line+=QString::number(comboBoxColor->currentItem()) +" , "; 
    line+=spinBoxSignDigits->text() +" , ";
    line+=QString::number(comboBoxWeightingMethod->currentItem()) +" , ";
    
    if (checkBoxCovar->isChecked()) line+="1 , "; else line+="0 , ";
    
    t->setText(currentChar,0,"Fit-Control"); t->setText(currentChar,1,"-> "+line);currentChar++;
    
    
    //+++ Resolution Integral
    t->setText(currentChar,0,"Resolution Integral");
    line="-> "+lineEditAbsErr->text();
    line+=" , "+lineEditRelErr->text();
    line+=" , "+spinBoxIntWorkspase->text();
    line+=" , "+spinBoxIntLimits->text();		 
    line+=" , "+comboBoxResoFunction->currentText();		 
    t->setText(currentChar,1,line);
    currentChar++;
    
    //+++ Polydispersity Integral
    t->setText(currentChar,0,"Polydispersity Integral");
    line="-> "+lineEditAbsErrPoly->text();
    line+=" , "+lineEditRelErrPoly->text();
    line+=" , "+spinBoxIntWorkspasePoly->text();
    line+=" , "+spinBoxIntLimitsPoly->text();		 
    line+=" , "+comboBoxPolyFunction->currentText();		 
    t->setText(currentChar,1,line);
    currentChar++;
    
    
    // +++ Q/N
    QComboTableItem *NQ = (QComboTableItem*) tableCurves->item(1,0);
    NQ->setCurrentItem(1);
    // +++ From
    QCheckTableItem *fromCheckItem = (QCheckTableItem*)tableCurves->item (2,0);
    fromCheckItem->setChecked(true);
    tableCurves->setText(2,1,lineEditFromQ->text());
    // +++ To	
    QCheckTableItem *toCheckItem = (QCheckTableItem*)tableCurves->item (3,0);
    toCheckItem->setChecked(true);
    tableCurves->setText(3,1,lineEditToQ->text());
    // +++ DataSet
    QComboTableItem *dataSetItem = (QComboTableItem*) tableCurves->item(0,1);
    // +++ weight check & Col
    QCheckTableItem *WrealYN = (QCheckTableItem*)tableCurves->item (4,0);
    QComboTableItem *weightColItem = (QComboTableItem*) tableCurves->item(4,1);
    // +++ reso check & Col
    QCheckTableItem *RrealYN;
    QComboTableItem *resoColItem;
    if (checkBoxSANSsupport->isChecked()) 
    {
	RrealYN= (QCheckTableItem*)tableCurves->item (5,0);
	resoColItem = (QComboTableItem*) tableCurves->item(5,1);
    }
    // +++Start values & adjustibility trasfer
    for (j=start;j<tableMultiFit->numCols();j++) 
    {
	QCheckTableItem *fitYN = (QCheckTableItem*)tableMultiFit->item (0,j);
	QCheckTableItem *fitYN0 = (QCheckTableItem*)tablePara->item (j-start,1);
	if (fitYN->isChecked()) fitYN0->setChecked(TRUE); else fitYN0->setChecked(FALSE);
    }
    
    int NselTot=Nselected;
    Nselected=0;
    
    int firstColor=comboBoxColor->currentItem();
    
    //app(this)->changeFolder(cf);
    
    for (i=0; i<Ntot;i++)
    {
	//+++ Start +++  1
	progress.setProgress(i);
	progress.setLabelText("Current data-set: # "+QString::number(i)+" of "+QString::number(Ntot));
	
	if ( progress.wasCanceled() ) {setToSetProgressControl=false;   break;};
	
	QCheckTableItem *selectedYN = (QCheckTableItem*)tableMultiFit->item (i+1,0);
	if (selectedYN->isChecked()) 
	{
	    // +++ RESULT TABLE
	    t->setText(Nselected,2,QString::number(Nselected+1));
	    t->setText(Nselected,3,commentList[Nselected]);
	    // +++ TRANSFER INFO ABOUT FITTED DATASET
	    s=tables[Nselected]+"_"+colList[Nselected];
	    dataSetItem->setCurrentItem(s); 
	    tableCurvechanged(0,1);
	    //+++ TRANSFER OF WEIGHT INFO
	    if (weight) 
	    {
		if ( weightColList[Nselected]=="" && ( comboBoxWeightingMethod->currentItem()==0 || comboBoxWeightingMethod->currentItem()==2) ) 
		    WrealYN->setChecked(false);
		else 
		{
		    WrealYN->setChecked(true);
		    s=tables[Nselected]+"_"+weightColList[Nselected];
		    weightColItem->setCurrentItem(s);
		    tableCurvechanged(4,1);
		}
	    }
	    else WrealYN->setChecked(false);
	    
	    //+++ TRANSFER OF RESOLUTION INFO
	    if (reso && resoColList[Nselected]!="") 
	    {
		RrealYN->setChecked(true);
		if (resoColList[Nselected]=="from DANP") s="from DANP";
		else if (resoColList[Nselected]=="from SPHERES") s="from SPHERES";
		else s=tables[Nselected]+"_"+resoColList[Nselected];
		resoColItem->setCurrentItem(s);
		tableCurvechanged(5,1);
	    }
	    //+++ MOVING OF PARAMETERS TO FITTING INTERFACE
	    if (tableMultiFit->text(0,0)!="c")
	    {
		for (j=start;j<tableMultiFit->numCols();j++) 
		{
		    tablePara->setText(j-start,2,tableMultiFit->text(i+1,j)); 
		}
	    }
	    //+++ FITTING OF CURRENT DATASET
	    setToSetNumber=i+1;	    
	    if (fitYN) fitOrCalculate(false);
	    else fitOrCalculate(true);
	    // +++ COLOR CONTROL
	    if (comboBoxColor->currentItem()+1 <  comboBoxColor->count())
		comboBoxColor->setCurrentItem(comboBoxColor->currentItem()+1);
	    else comboBoxColor->setCurrentItem(0);
	    
	    //+++ TRANSFER OF OBTEINED PARAMETERS TO SET-BY-SET TABLE AND TO RESULT TABLE
	    for (j=0;j<p;j++) 
	    {
		t->setText(Nselected,2*j+7,tablePara->text(j,2));
		t->setText(Nselected,2*j+8,tablePara->text(j,3));
		//new!!
		tableMultiFit->setText(i+1,j+start, tablePara->text(j,2));	
	    }
	    
	    t->setText(Nselected,4,textLabelChi->text());
	    t->setText(Nselected,5,textLabelR2->text());
	    t->setText(Nselected,6,textLabelTime->text());
	    Nselected++;
	}
	for (int tt=0; tt<t->numCols(); tt++) t->table()->adjustColumn (tt);
	
    }
    
    setToSetProgressControl=false;
    comboBoxColor->setCurrentItem(firstColor);
}

// +++
void fittable::changedSetToSet( int raw, int col )
{
    if (raw==0 && col==1)
    {
	bool use;
	QCheckTableItem *uYN = (QCheckTableItem*)tableMultiFit->item (0,1);
	if (uYN->isChecked()) use=true; else use=false;
	int i;
	for (i=1;i<tableMultiFit->numRows();i++)
	{
	    QCheckTableItem *setYN = (QCheckTableItem*)tableMultiFit->item (i,0);
	    setYN->setChecked(use);
	}
    }
}

// +++
void fittable::rename(QString oldNAME, QString newNAME)
{
    int i;
    
    newNAME=app(this)->generateUniqueName(newNAME);	
    
    QWidgetList *windows = app(this)->windowsList();
    
    Table* t;
    
    for (i=0;i<(int)windows->count();i++)
    {
	if (windows->at(i) && windows->at(i)->isA("Table") && windows->at(i)->name()==oldNAME)
	{
	    t = (Table*)windows->at(i);
	}
    }
    
    if(!app(this)->renameWindow(t, newNAME))	return;
    
    app(this)->renameListViewItem(oldNAME,newNAME);
    
    app(this)->modifiedProject(t);
}

// +++
void fittable::simulateMultifitTables()		
{
    setToSetSimulYN=true;
    setBySetFitOrSim(false);
}

void fittable::removeTables(QString pattern)
{
    int i;
    
    QWidgetList *windows = app(this)->windowsList();
    
    QRegExp rx(pattern);
    rx.setWildcard( TRUE );
    
    for (i=0;i<(int)windows->count();i++)
    {
	if (windows->at(i) && windows->at(i)->isA("Table") && rx.exactMatch(windows->at(i)->name()))
	{
	    myWidget *close =(myWidget*)windows->at(i);
	    emit app(this)->closeWindow(close);
	}	
    }
}

// +++ simulatedCurve-Cylinder-1  fitCurve-Cylinder-set-1 simulatedCurve-Cylinder-set-1-1
void fittable::removeSimulatedDatasets()
{
    QString F_name=textLabelFfunc->text();
    
    if ( tabWidgetGenResults->currentPageIndex()==0 )
    {
	removeTables( "simulatedCurve-"+textLabelFfunc->text()+"*");
    }
    if ( tabWidgetGenResults->currentPageIndex()==2 )    
    {
	removeTables( "simulatedCurve-"+textLabelFfunc->text()+"-set*");
	removeTables( "fitCurve-"+textLabelFfunc->text()+"-set*");	
    }
    updateDatasets();
}

// +++ removeFitCurve
void fittable::removeFitCurve()
{
    removeTables( "fitCurve-*");
    updateDatasets();
}

// +++ removeSimulatedCurve
void fittable::removeSimulatedCurve()
{
    removeTables( "simulatedCurve-*");
    updateDatasets();
}

// +++ removeGlobal
void fittable::removeGlobal()
{
    removeTables( "*-global-*");
    updateDatasets();
}

// +++
void fittable::uniformSimulChanged(bool status)
{
    
    if (status)
    {
	radioButtonSameQrange->setChecked(false);
	
	textLabelChi2Sim->hide();
	textLabelChi2dofSim->hide();
	textLabelR2sim->hide();
	
	textLabelChiLabelSim->hide();
	textLabelChiLabelDofSim->hide();
	textLabelR2simInt->hide();
	
	groupBoxPointsPara->hide();
	groupBoxSimRange->hide();
	
	comboBoxDatasetSim->hide();
	checkBoxWeightSim->hide();
	
	groupBoxQrange->show();
    }
    else 
    {
	radioButtonSameQrange->setChecked(true);
	
	textLabelChi2Sim->show();
	textLabelChi2dofSim->show();
	textLabelR2sim->show();
			
	textLabelChiLabelSim->show();
	textLabelChiLabelDofSim->show();
	textLabelR2simInt->show();
			
	groupBoxPointsPara->show();
	groupBoxSimRange->show();
	
	comboBoxDatasetSim->show();
	checkBoxWeightSim->show();
	
	groupBoxQrange->hide();
    }
}

// +++
void fittable::theSameSimulChanged(bool status)
{
    if (status)
    {
	radioButtonUniform_Q->setChecked(false);
	
	textLabelChi2Sim->show();
	textLabelChi2dofSim->show();
	textLabelR2sim->show();
		
	textLabelChiLabelSim->show();
	textLabelChiLabelDofSim->show();
	textLabelR2simInt->show();
	
	groupBoxPointsPara->show();
	groupBoxSimRange->show();
	
	comboBoxDatasetSim->show();
	checkBoxWeightSim->show();
	
	groupBoxQrange->hide();
    }
    else 
    {
	radioButtonUniform_Q->setChecked(true);
		
	textLabelChi2Sim->hide();
	textLabelChi2dofSim->hide();
	textLabelR2sim->hide();
		
	textLabelChiLabelSim->hide();
	textLabelChiLabelDofSim->hide();
	textLabelR2simInt->hide();
	
	groupBoxPointsPara->hide();
	groupBoxSimRange->hide();	
	
	comboBoxDatasetSim->hide();
	checkBoxWeightSim->hide();	
	
	groupBoxQrange->show();
    }
}
// +++
bool fittable::datasetChangedSim( int num)
{	
    //+++
    int p=spinBoxPara->value();
    int M=spinBoxNumberCurvesToFit->value();
    
    //+++ only real data 
    if (num>=M) return false;
    
    int i,m;
    
    QStringList listTemp;
    bool refreshList=true;
    
    //+++ Parameters +++
    for (i=0;i<p;i++) tableParaSimulate->setText(i,0,tablePara->text(i,2+3*num));
    
    bool tablesExists=true;
    if ( tableCurves->text(0,2*num+1)=="" )  tablesExists=false;
    
    for (m=0;m<M;m++) if (tablesExists)
    {
	listTemp << tableCurves->text(0,2*m+1);
	if ( comboBoxDatasetSim->count()<M ) refreshList=false;
	else if (tableCurves->text(0,2*m+1) != comboBoxDatasetSim->text(m) ) refreshList=false;
    }
    
    
    if ( !refreshList && tablesExists )
    {
	comboBoxDatasetSim->clear();
	if (listTemp.count()>0)
	{
	    
	    comboBoxDatasetSim->insertStringList(listTemp);
	    comboBoxDatasetSim->setCurrentItem(num); // here  could be problem!!!
	}
	
    }
    
    //+++ weight combobox import
    QComboTableItem *weightItem = (QComboTableItem*) tableCurves->item(4,2*num+1);
    QStringList listW;
    listW.clear();
    comboBoxWeightSim->clear();
    
    if (weightItem->count()>0)
    {
	for (int j=0;j<weightItem->count();j++) listW<<weightItem->text(j);
	comboBoxWeightSim->insertStringList(listW);
	comboBoxWeightSim->setCurrentText(tableCurves->text(4,2*num+1));
    }
    
    //+++
    QCheckTableItem* weightCh=(QCheckTableItem* )tableCurves->item(4,2*num);
    if (weightCh->isChecked()) checkBoxWeightSim->setChecked(true); 
    else checkBoxWeightSim->setChecked(false);
    
    
    //+++ 
    QString tableName, curveName;
    
    QString currentInstrument=comboBoxInstrument->currentText();	    
    
    double min,max;
    int Ntot;
    
    if (tablesExists)
    {
	tableName=comboBoxDatasetSim->text(num).left(comboBoxDatasetSim->text(num).find("_",0));
	curveName=comboBoxDatasetSim->text(num);
	
	//+++ source dataset +++
	Table *t;
	int xColIndex, yColIndex;
	
	if ( !findFitDataTable(curveName, t, xColIndex,yColIndex ) )
	{
	    comboBoxResoSim->clear();
	    comboBoxResoSim->insertItem("from DANP");
	    
	    
	    if (checkBoxSANSsupport->isChecked() && currentInstrument.contains("SANS") )
	    {
		comboBoxResoSim->insertItem("from DANP");
		
		QComboTableItem *polyItem = (QComboTableItem*) tableCurves->item(6,2*num+1);
		QStringList list;
		list.clear();
		comboBoxPolySim->clear();
		if (polyItem->count()>0)
		{
		    for (int j=0;j<polyItem->count();j++) list<< polyItem->text(j);    
		    comboBoxPolySim->insertStringList(list);
		    comboBoxPolySim->setCurrentText(tableCurves->text(6,2*num+1));
		}
	    }
	    if (checkBoxSANSsupport->isChecked() && currentInstrument.contains("Back") )
	    {
		comboBoxResoSim->insertItem("from SPHERES");
		
	    }
	    
	    return false;
	}
	
	int N=t->numRows();
	int ii=0;
	while(t->text(ii,xColIndex) == "" && ii<N) ii++;
	
	// +++
	Ntot=0;
	QRegExp rx( "((\\-|\\+)?\\d*(\\.|\\,)\\d*((e|E)(\\-|\\+)\\d*)?)|((\\-|\\+)?\\d+)" );	
	for(int j=0;j<N;j++) if (rx.exactMatch(t->text(j,xColIndex))) Ntot++;
	if (Ntot<2) Ntot=1000;
	
	if (radioButtonSameQrange->isChecked()) lineEditNumPointsSim->setText(QString::number(Ntot));
		
	if (ii==N)
	{
	    return false;
	    // min=0.001; max=0.1;
	}
	else
	{
	    min=t->text(ii,xColIndex).toDouble();
	    max=t->text(ii,xColIndex).toDouble();
	    
	    for (int j=ii;j<N;j++)
	    {
		if ((t->text(j,xColIndex).toDouble())>max && t->text(j,xColIndex)!="") max=t->text(j,xColIndex).toDouble();
		if (t->text(j,xColIndex).toDouble()<min && t->text(j,xColIndex)!="") min=t->text(j,xColIndex).toDouble();
	    }
	    
	}
	if (radioButtonSameQrange->isChecked()) lineEditFromQsim->setText(QString::number(min));
	if (radioButtonSameQrange->isChecked()) lineEditToQsim->setText(QString::number(max));
		
	QRegExp rxCol(tableName+"_*");
	rxCol.setWildcard( TRUE );
	QStringList cols;
	
	QStringList colTemp=app(this)->columnsList(Table::xErr);
	for (int j=0; j<colTemp.count();j++)
	{
	    if (rxCol.exactMatch(colTemp[j])) cols<<colTemp[j];
	}
	
	if (checkBoxSANSsupport->isChecked())
	{
	    // +++ Reso & Poly
	    QComboTableItem *resoItem = (QComboTableItem*) tableCurves->item(5,2*num+1);
	    QStringList list;
	  
	    
	    for (int j=0;j<resoItem->count();j++) list<< resoItem->text(j);
	    	    
	    comboBoxResoSim->clear();
	    comboBoxResoSim->insertStringList(list);
	    comboBoxResoSim->setCurrentText(tableCurves->text(5,2*num+1));
	    
	    QCheckTableItem* resoCh=(QCheckTableItem* )tableCurves->item(5,2*num);
	    if (resoCh->isChecked()) checkBoxResoSim->setChecked(true); 
	    else checkBoxResoSim->setChecked(false);
	    
	    if (currentInstrument.contains("SANS") )
	    {
		QComboTableItem *polyItem = (QComboTableItem*) tableCurves->item(6,2*num+1);
		list.clear();
		for (int j=0;j<polyItem->count();j++) list<< polyItem->text(j);
		comboBoxPolySim->clear();
		comboBoxPolySim->insertStringList(list);
		
		comboBoxPolySim->setCurrentText(tableCurves->text(6,2*num+1));
		QCheckTableItem* polyCh=(QCheckTableItem* )tableCurves->item(6,2*num);
		if (polyCh->isChecked()) checkBoxPolySim->setChecked(true); 
		else checkBoxPolySim->setChecked(false);
	    }  
	}
    }
    else
    {
	if (checkBoxSANSsupport->isChecked())
	{
	    comboBoxResoSim->clear();
	    
	    if (currentInstrument.contains("SANS") )
	    {
		
		comboBoxResoSim->insertItem("from DANP");
		
		QComboTableItem *polyItem = (QComboTableItem*) tableCurves->item(6,2*num+1);
		QStringList list;
		list.clear();
		for (int j=0;j<polyItem->count();j++) list<< polyItem->text(j);
		comboBoxPolySim->clear();comboBoxPolySim->clear();
		comboBoxPolySim->insertStringList(list);
		comboBoxPolySim->setCurrentText(tableCurves->text(6,2*num+1));
	    }
	    
	    if (currentInstrument.contains("Back") )
	    {
		
		comboBoxResoSim->insertItem("from SPHRES");
	    }
	}
    }
    
    if (tablesExists)
    {
	// Range transfer
	QComboTableItem *QN = (QComboTableItem*) tableCurves->item(1,2*num);
	comboBoxSimQN->setCurrentItem(QN->currentItem());
	if(comboBoxSimQN->currentText()=="N")
	{
	    textLabelRangeFirstLimit->setText(QString::number(GSL_MIN(1,Ntot)));
	    textLabelRangeLastLimit->setText(QString::number(Ntot));
	}
	else
	{
	    textLabelRangeFirstLimit->setText(QString::number(GSL_MIN(min,max)));
	    textLabelRangeLastLimit->setText(QString::number(max));	
	}
//	textLabelDofSim->setText(QString::number(Ntot)); // 2016

	
	textLabelRangeFirst->setText(tableCurves->text(2,2*num+1));
	textLabelRangeLast->setText(tableCurves->text(3,2*num+1)); 
	
	//    textLabelRangeFirstLimit->setText(QString::number(1));
	//    textLabelRangeLastLimit->setText(QString::number(Ntot));
    }
    return true;
}


//+++ Fit results in graph +++
void fittable::addFitResultToActiveGraph()
{
    int p=spinBoxPara->value();
    int M=spinBoxNumberCurvesToFit->value();
    QString F_name=textLabelFfunc->text();
    
    QDateTime dt = QDateTime::currentDateTime ();
    QString info = "[" + dt.toString(Qt::LocalDate)+ " ]\n";
    info = info+ "<b>Fit Method</b>" + ": " +comboBoxFitMethod->currentText() +"\n";
    info = info+ "<b>Using Function</b>" + ": " + F_name + "\n";
    
    int mm;
    for (mm=0;mm<M;mm++) 
    {
	info+="\n<b>"+tableCurves->text(0,2*mm+1)+"</b>"+ " : \n";
	
	int pp;
	for (pp=0;pp<p;pp++) 
	{
	    info+= "<b>"+F_paraList[pp]+"</b>"+" = "+tablePara->text(pp,3*mm+2);
	    if (tablePara->text(pp,3*mm+3)!="---")
	    {
		info+=" ";
		info+=QChar(177);
		info+=" "+tablePara->text(pp,3*mm+3);
	    }
	    info+="\n";
	}
    }
    info+="\n<b>chi<sup>2</sup></b> = "+textLabelChi->text()+"\n";
    info+="\n<b>R<sup>2</sup></b> = "+textLabelR2->text()+"\n";
    info+="<b>time</b> = "+textLabelTime->text()+"\n";
    
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer"))
	return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
	QMessageBox::warning(this,tr("QtiKWS - Warning"),
			     tr("<h4>There are no plot layers available in this window.</h4>"
				"<p><h4>Please add a layer and try again!</h4>"));
	
	return;
    }
    
    Graph *g = (Graph*)plot->activeGraph();
    if (g) g->newLegend(info);	
    g->replot();
}




void fittable::saveUndo()
{
    //+++
    int M=spinBoxNumberCurvesToFit->value();		// Number of Curves
    int p=spinBoxPara->value();				//Number of Parameters per Curve
    int pM=p*M;					//Total Numbe
    
    QString undo;    
    int pp, mm;
    
    for (mm=0;mm<M;mm++) for (pp=0;pp<p;pp++) undo+=QString::number(tablePara->text(pp, 3*mm+2).toDouble(),'E',spinBoxSignDigits->value()-1)+"  ";
    
    undoRedo<<undo;
    ;
    pushButtonRedo->setEnabled(false);
    pushButtonUndo->setEnabled(true);
    
    undoRedoActive=undoRedo.count();
}

//~~~
void fittable::undo()
{
    //if (!pushButtonRedo->isEnabled() && undoRedoActive==undoRedo.count()) saveUndo();
    
    if(undoRedoActive>1)
    {
	undoRedoActive-=1;
	pushButtonRedo->setEnabled(true);
	
	//+++
	int M=spinBoxNumberCurvesToFit->value();		// Number of Curves
	int p=spinBoxPara->value();				//Number of Parameters per Curve
	int pM=p*M;						//Total Numbe
	
	QString undo=undoRedo[undoRedoActive-1];
	int pp=0, mm=0;
	
	int pos=0;
	
	QRegExp rx( "((\\-|\\+)?\\d*(\\.|\\,)\\d*((e|E)(\\-|\\+)\\d*)?)" );
	
	
	for (mm=0;mm<M;mm++) for (pp=0;pp<p;pp++)
	{
	    pos = rx.search( undo, pos ); pos+=rx.matchedLength();
	    tablePara->setText(pp,3*mm+2,rx.cap(1));
	}
	if(undoRedoActive==1) pushButtonUndo->setEnabled(false);
    }
    else pushButtonUndo->setEnabled(false);
}


void fittable::redo()
{
    if(undoRedoActive<undoRedo.count())
    {
	undoRedoActive+=1;
	pushButtonUndo->setEnabled(true);
	
	//+++
	int M=spinBoxNumberCurvesToFit->value();		// Number of Curves
	int p=spinBoxPara->value();				//Number of Parameters per Curve
	int pM=p*M;						//Total Numbe
	
	QString undo=undoRedo[undoRedoActive-1];
	int pp=0, mm=0;
	
	int pos=0;
	
	//QRegExp rx( "((\\-|\\+)?\\d*(\\.|\\,)\\d*((e|E)(\\-|\\+)\\d*)?)" );	
	QRegExp rx( "((\\-|\\+)?\\d*(\\.|\\,)\\d*((e|E)(\\-|\\+)\\d*)?)" );	   
	for (mm=0;mm<M;mm++) for (pp=0;pp<p;pp++)
	{
	    pos = rx.search( undo, pos ); pos+=rx.matchedLength();
	    tablePara->setText(pp,3*mm+2,rx.cap(1));//
	}
	if(undoRedoActive==undoRedo.count()) pushButtonRedo->setEnabled(false);
    }
    else pushButtonRedo->setEnabled(false);
}


//+++ New reading Data szstem

// +++  Set Q and I  +++
bool fittable::SetQandI(int &Ntotal, double*&Qtotal, double*&Itotal, double*&dItotal, double*&Sigmatotal)
{
    
    bool SANSsupport=checkBoxSANSsupport->isChecked();
    //
    size_t mm,j,ii, nReal, iistart;
    //
    double min, max;
    //
    bool weightYN, resoYN;
    //
    QString colReso;
    //
    int M=spinBoxNumberCurvesToFit->value();
    //
    size_t N=0;
    
    //
    Table *table;
    int xColIndex,yColIndex;
    
    for(mm=0;mm<M;mm++)
    {
	//
	//Table Name
	QComboTableItem *curve =(QComboTableItem*)tableCurves->item (0, 2*mm+1);
	if ( curve->count()==0 ) return false;
	
	QString curveName=curve->currentText();
	QString tableName=curveName.left(curveName.find("_",0));	
	
	if ( findFitDataTable(curveName, table, xColIndex,yColIndex ) )
	{	
	    tableCurves->setText(1,2*mm+1,QString::number(table->numRows()));
	    N+=table->numRows();
	    //
	    nReal=0;
	    for (ii=0; ii<table->numRows(); ii++) if ((table->text(ii,xColIndex))!="") nReal++;
	    //
	    if (nReal<=1) 
	    {
		return false;
	    }
	    
	    if (tableCurves->text(1,2*mm)=="N")
	    {
		QCheckTableItem *iQmin = (QCheckTableItem*)tableCurves->item (2,2*mm);
		//
		if (!iQmin->isChecked()) tableCurves->setText(2,2*mm+1, "1");
		//
		QCheckTableItem *iQmax = (QCheckTableItem*)tableCurves->item (3,2*mm);
		if (!iQmax->isChecked())	tableCurves->setText(3,2*mm+1, QString::number(table->numRows()));
	    }
	    else
	    {
		iistart=0;
		//
		while ((table->text(iistart,xColIndex))=="") iistart++;
		min=table->text(iistart,xColIndex).toDouble();
		max=min;
		//
		for (ii=iistart; ii<table->numRows(); ii++)
		{
		    if ((table->text(ii,xColIndex).toDouble())>max && table->text(ii,xColIndex)!="") max=table->text(ii,xColIndex).toDouble();
		    if ((table->text(ii, xColIndex).toDouble())<min && table->text(ii,xColIndex)!="") min=table->text(ii,xColIndex).toDouble();
		}
		//
		QCheckTableItem *iQmin = (QCheckTableItem*)tableCurves->item (2,2*mm);
		//
		if (!iQmin->isChecked()) tableCurves->setText(2,2*mm+1, QString::number(min));
		//
		QCheckTableItem *iQmax = (QCheckTableItem*)tableCurves->item (3,2*mm);
		//
		if (!iQmax->isChecked())					
		    tableCurves->setText(3,2*mm+1, QString::number(max));
	    }
	}
	else return false;
	
	if (!table) 
	{
	    return false;
	}
    }
    
    Ntotal=N;
    
    double *II=new double[N];
    double *QQ=new double[N];
    double *dII=new double[N];
    double *sigmaResoO=new double[N];
    
    
    
    size_t mnmn=0;
    
    for(mm=0; mm<M;mm++)
    {
	// I & Q
	QComboTableItem *curve =(QComboTableItem*)tableCurves->item (0, 2*mm+1);
	QString curveName=curve->currentText();
	QString tableName=curveName.left(curveName.find("_",0));
	// dI
	weightYN=false;
	QString colWeight="";
	QCheckTableItem *it = (QCheckTableItem *)tableCurves->item(4,2*mm);
	if (it->isChecked()) 
	{
	    weightYN=true;
	    QComboTableItem *weight =(QComboTableItem*)tableCurves->item (4, 2*mm+1);
	    colWeight=weight->currentText();
	}
	
	// Reso
	resoYN=false;
	
	if (SANSsupport)
	{
	    colReso="";
	    it = (QCheckTableItem *)tableCurves->item(5,2*mm);
	    if (it->isChecked()) 
	    {
		resoYN=true;
	    }
        QComboTableItem *reso =(QComboTableItem*)tableCurves->item (5, 2*mm+1);
        colReso=reso->currentText();
	}
	//
	if ( findFitDataTable(curveName, table, xColIndex,yColIndex ) )
	{		
	    double wa=lineEditWA->text().toDouble(); wa=fabs(wa);
	    double wb=lineEditWB->text().toDouble(); wb=fabs(wb); if (wb==0) wb=1.0;
	    double wc=lineEditWC->text().toDouble(); wc=fabs(wc);
	    double wxmax=lineEditWXMAX->text().toDouble();
	    
	    for(j=0;j<table->numRows();j++)
	    {
		//Q
		if (table->text(j,xColIndex)=="")
		    QQ[mnmn]=-911119.119911;
		else
		    QQ[mnmn]=table->text(j,xColIndex).toDouble();
		//I	
		if (table->text(j,yColIndex)=="")
		    II[mnmn]=-911119.119911;
		else
		    II[mnmn]=table->text(j,yColIndex).toDouble();		    //dI
		if (weightYN) 
		{
		    if (comboBoxWeightingMethod->currentItem()==0)//+++ [ w = 1/dY² ] 
		    {
			if (table->text(j,table->colIndex(colWeight))=="" || table->text(j,table->colIndex(colWeight)).toDouble()==0)
			    dII[mnmn]=-911119.119911;
			else
			    dII[mnmn]=fabs(table->text(j,table->colIndex(colWeight)).toDouble());
		    }
		    else if (comboBoxWeightingMethod->currentItem()==1) //+++ [ w = 1/Y  ] 
		    {
			if (II[mnmn]==-911119.119911)
			{
			    QQ[mnmn]=-911119.119911; 
			    dII[mnmn]=-911119.119911;
			}
			else 
			    dII[mnmn]=sqrt(fabs(II[mnmn]));
		    }
		    else if (comboBoxWeightingMethod->currentItem()==2)//+++ [ w = dY  ]
		    {
			if (II[mnmn]==-911119.119911 || table->text(j,table->colIndex(colWeight)).toDouble()==0) 
			    dII[mnmn]=-911119.119911;
			else 
			    dII[mnmn]=1/sqrt(fabs(table->text(j,table->colIndex(colWeight)).toDouble()));
		    }
		    else if (comboBoxWeightingMethod->currentItem()==3) //+++ [ w = 1/Y² ]
		    {
			if (II[mnmn]==-911119.119911)
			{
			    QQ[mnmn]=-911119.119911; 
			    dII[mnmn]=-911119.119911;
			}
			else 
			    dII[mnmn]=fabs(II[mnmn]);
		    }
		    else if (comboBoxWeightingMethod->currentItem()==4) //+++ [ w = 1/Y^a ]
		    {
			if (II[mnmn]==-911119.119911)
			{
			    QQ[mnmn]=-911119.119911; 
			    dII[mnmn]=-911119.119911;
			}
			else 
			    dII[mnmn]=pow( fabs(II[mnmn]),wa/2);
		    }
		    else if (comboBoxWeightingMethod->currentItem()==5) //+++ [ w = 1/|c^a+b*Y^a| ]
		    {
			if (II[mnmn]==-911119.119911)
			{
			    QQ[mnmn]=-911119.119911; 
			    dII[mnmn]=-911119.119911;
			}
			else 
			    dII[mnmn]=sqrt(pow(wc,wa)+wb*pow( fabs(II[mnmn]),wa));
		    }
		    else if (comboBoxWeightingMethod->currentItem()==6) // +++ [ w = 1/ Y^a / c^|Xmax-X| ) ]
		    {
			if (II[mnmn]==-911119.119911)
			{
			    QQ[mnmn]=-911119.119911; 
			    dII[mnmn]=-911119.119911;
			}
			else 
			    dII[mnmn]=sqrt(pow(wc,fabs(wxmax-QQ[mnmn]))*pow( fabs(II[mnmn]),wa));
		    }
		} 
		else 
		    dII[mnmn]=1;
		//Sigma
		if (resoYN)
		{
		    //-NEW
		    if ( colReso=="from DANP") sigmaResoO[mnmn]=app(this)->sigma(QQ[mnmn]);
		    else if ( colReso=="from SPHERES") sigmaResoO[mnmn]=app(this)->sigma(QQ[mnmn]);	 // Change to SPHERES  function    
		    else 			    
		    {
			sigmaResoO[mnmn]=table->text(j,table->colIndex(colReso)).toDouble();
		    }
		}
        else if (SANSsupport)
        {
            //-NEW
            if ( colReso=="from DANP") sigmaResoO[mnmn]=0.0 - fabs ( app(this)->sigma(QQ[mnmn]) );
            else if ( colReso=="from SPHERES") sigmaResoO[mnmn]=0.0 - fabs ( app(this)->sigma(QQ[mnmn]) );	 // Change to SPHERES  function
            else
            {
                sigmaResoO[mnmn]=0.0 - fabs ( table->text(j,table->colIndex(colReso)).toDouble());
            }
        }
		else 
		    sigmaResoO[mnmn]=0.0;
		
		mnmn++;
	    }
	}
    }
    
    
    Qtotal=new double[N];
    Itotal=new double[N];
    dItotal=new double[N];
    Sigmatotal=new double[N];
   
    int prec=spinBoxSignDigits->value();
    
    for(int i=0; i<N; i++)
    {
	if (QQ[i]==-911119.119911) Qtotal[i]=QQ[i]; else Qtotal[i] =  round2prec(QQ[i], prec);
	if (II[i]==-911119.119911) Itotal[i]=II[i]; else Itotal[i] =  round2prec(II[i], prec);	
	if (dII[i]==-911119.119911) dItotal[i]=dII[i]; else dItotal[i] =  round2prec(dII[i], prec);	
	if (sigmaResoO[i]==-911119.119911) Sigmatotal[i]=sigmaResoO[i]; else Sigmatotal[i] =  round2prec(sigmaResoO[i], prec);
    }
    
    delete[] QQ; 
    delete[] II; 
    delete[] dII; 
    delete[] sigmaResoO;
    
    return true;
}


void fittable::headerPressedTablePara( int col )
{
    
    if (col==0 || (col-1)/3*3==(col-1))
    {
	int p=spinBoxPara->value();
	int M=spinBoxNumberCurvesToFit->value();
	
	int pp, ppC=0;
	//+++ get np && params
	for (pp=0; pp<p;pp++)
	{
	    QCheckTableItem *itS = (QCheckTableItem *)tablePara->item(pp,col); //
	    if (itS->isChecked()) ppC++; 
	}
	
	for (pp=0; pp<p;pp++)
	{
	    QCheckTableItem *	itS = (QCheckTableItem *)tablePara->item(pp,col); //
	    if (ppC==p) itS->setChecked(false);
	    else itS->setChecked(true);
	}
    }
    else if ((col-2)/3*3==(col-2))
    {
	fitOrCalculate(true, (int) ((col-1)/3));
    }
    else
    {
	
	Graph *g;
	if (!findActiveGraph(g)) return;
	
	bool maximaizedYN=false;
	myWidget *w;
	
	w= ( myWidget * ) app(this)->ws->activeWindow();
	if (w->status() == myWidget::Maximized) 
	{
	    maximaizedYN=true;
	}
	
	QString nameesidular="fitCurve-"+textLabelFfunc->text();
	if (spinBoxNumberCurvesToFit->value()>1) nameesidular+="-global-"+QString::number(1+((int) ((col-1)/3)));
	nameesidular+="_residues";
	
	AddCurve(g, nameesidular);   
    }
}


void fittable::vertHeaderPressedTablePara( int raw)
{
    int M=spinBoxNumberCurvesToFit->value();
    
    if (M>1)
    {
	QCheckTableItem *itS = (QCheckTableItem *)tablePara->item(raw,0); //
	
	if (itS->isChecked())
	{
	    itS->setChecked(false);
	    
	    
	    for(int mm=0;mm<M;mm++)		
	    {
		QCheckTableItem *itSm = (QCheckTableItem *)tablePara->item(raw,3*mm+1); 
		itSm->setChecked(true);
		
	    }
	}
	else
	{
	    itS->setChecked(true);
	    
	    
	    for(int mm=0;mm<M;mm++)		
	    {
		QCheckTableItem *itSm = (QCheckTableItem *)tablePara->item(raw,3*mm+1); 
		if (mm==0) itSm->setChecked(true);
		else itSm->setChecked(false);
		
	    }
	}    
    }
}

void fittable::QvsN()
{
    int Ntotal;
    double *Qtotal;
    double *Itotal; 
    double *dItotal;
    double *Sigmatotal;
    
    if ( !SetQandI(Ntotal, Qtotal, Itotal, dItotal, Sigmatotal))
    {
	QMessageBox::warning(this,tr("QtiKws"),
			     tr("Check data :: Problem to read data!"));
    }
    
}



void fittable::vertHeaderTableCurves(int raw)
{
    int M=spinBoxNumberCurvesToFit->value();
    
    if (raw==0)
    {
	for(int mm=0;mm<M;mm++)		
	{
	    tableCurves->adjustColumn (2*mm+1);	
	}
	updateDatasets();
    }
    if (raw>1)
    {
	
	QCheckTableItem *itS0 = (QCheckTableItem *)tableCurves->item(raw,0); //
	itS0->setChecked(!itS0->isChecked());
	
	for(int mm=1;mm<M;mm++)		
	{
	    QCheckTableItem *itS = (QCheckTableItem *)tableCurves->item(raw,2*mm); 
	    itS->setChecked(itS0->isChecked());
	}
    }
}

//+++ Multi-Fit-Table header
void fittable::headerTableMultiFit( int col )
{
    int numRows=tableMultiFit->numRows();
    if (col>2 && numRows > 2 )
    {
	int i;
	for (i=2;i<numRows;i++)
	{
	    tableMultiFit->setText(i,col, tableMultiFit->text(1,col));
	}
    }
}
//+++ Multi-Fit-Table header
void fittable::selectRowsTableMultiFit()
{
    int numRows=tableMultiFit->numRows();
    int i;
    for (i=1;i<numRows;i++)
    {
	if ( tableMultiFit->isSelected(i,0) && !tableMultiFit->isSelected(i,1) )
	{
	    QCheckTableItem *itS0 = (QCheckTableItem *)tableMultiFit->item(i,0); //
	    itS0->setChecked(true);
	}
	
    }
}

void fittable::tableParaRepaint()
{
    tablePara->hide();
    tablePara->show();
}

void fittable::tableMultiFitRepaint()
{
    tableMultiFit->hide();
    tableMultiFit->show();
}

void fittable::openHelpOnline()
{
    app(this)->open_browser(this, "http://iffwww.iff.kfa-juelich.de/~pipich/dokuwiki/doku.php/qtikws/fit1d");
}

void fittable::selectMultyFromTable()
{
    int p=spinBoxPara->value();
    //+++
    int i,j;
    // +++ FIRST LINE IS UNTOUCHED, REST  IS OUT 
    tableMultiFit->setNumRows(1);
    
    //+++ 
    QStringList tablesAll,tablesSelected; 
    //+++ ALL TABLES OF PROJECT
    tablesAll=app(this)->tableWindows;    
    //+++ WILD PATTERN FOR SKRIPT SELECTION
    QRegExp rx( lineEditPattern->text());
    rx.setWildcard( TRUE );
    
    for (j=0; j<tablesAll.count(); j++)
    {
	if (rx.exactMatch(tablesAll[j])) tablesSelected<<tablesAll[j];
    }
    
    
    
    //+++ SKRIPT TABLE SELECTION
    bool ok;
    QString skriptTable = QInputDialog::getItem(
	    "QtiKWS", "Select a table with fitting results, you want to work again :", tablesSelected, 1, TRUE, &ok, this );
    if ( !ok || skriptTable=="") return;
    
    //+++ FINDING SKRIPT TABLE OBJECT
    QWidgetList *windows = app(this)->windowsList();
    
    Table *skript;
    bool exist=false;
    
    for (i=0;i<(int)windows->count();i++) 
    {
	if (windows->at(i) && windows->at(i)->isA("Table") && windows->at(i)->name()==skriptTable)
	{
	    skript=(Table*)windows->at(i);
	    exist=true;
	}			
    }
    
    if (!exist)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     "There is no table:: "+skriptTable);
	return;		
    }
    //+++ COUNTER: NUMBER OF EXISTING TABLES IN SKRIPT TABLE
    int activeDatasets=0;
    
    //+++ LIST OF ALL Y-COLUMNS
    QStringList colTemp=app(this)->columnsList(Table::Y);
    //+++ LIST OF EXISTING COLUMNS IN SKRIPT TABLE
    QStringList tables;
    //+++ FIRST STEP OF DATA TRANSFET ANF MULTITABLE ARRANGMENT | USED FOR LEFT HEADER
    for (i=0; i< skript->numRows();i++)
    {
	colTemp=app(this)->columnsList(Table::Y);
	QString info=skript->text(i,3);
	QString currentTable=info.left(info.find("|t|")).stripWhiteSpace();
	QString currentY=info.mid(info.find("|t|")+3, info.find("|y|") - info.find("|t|")-3).stripWhiteSpace();
	QString currentWeight=info.mid(info.find("|y|")+3, info.find("|w|") - info.find("|y|")-3).stripWhiteSpace();
	QString currentReso=info.mid(info.find("|w|")+3, info.find("|r|") - info.find("|w|"-3)).stripWhiteSpace();
	
	if (colTemp.contains(currentTable+"_"+currentY))
	{
	    tableMultiFit->setNumRows(activeDatasets + 2); //+++ add row to table
	    tables<<currentTable; //+++  
	    
	    QStringList cols;
	    
	    //+++ CURRENT TABLE NAME
	    
	    QRegExp rxCol(currentTable+"_*"); //+++ WILD PATTERN OF Y-COLUMNS OF CURRENT DATASET
	    rxCol.setWildcard( TRUE );
	    // +++
	    QCheckTableItem *yn = new QCheckTableItem(tableMultiFit, QString::null );
	    tableMultiFit->setItem(activeDatasets+1,0, yn);
	    
	    // +++
	    QComboTableItem *yCol = new QComboTableItem(tableMultiFit, QString::null );
	    tableMultiFit->setItem(activeDatasets+1,1,yCol);
	    
	    for (j=0; j<colTemp.count();j++)
	    {
		if (rxCol.exactMatch(colTemp[j])) cols<<colTemp[j].remove(currentTable+"_");
	    }
	    yCol->setStringList(cols);
	    yCol->setCurrentItem(currentY);
	    
	    // +++
	    QComboTableItem *dYcol = new QComboTableItem(tableMultiFit, QString::null );
	    tableMultiFit->setItem(activeDatasets+1,2,dYcol);
	    
	    colTemp=app(this)->columnsList(Table::yErr);
	    cols.clear();
	    for (j=0; j<colTemp.count();j++)
	    {
		if (rxCol.exactMatch(colTemp[j])) cols<<colTemp[j].remove(currentTable+"_");
	    }
	    dYcol->setStringList(cols);
	    dYcol->setCurrentItem(currentWeight);
	    
	    //+++ 
	    int resoShift=0;
	    if (checkBoxSANSsupport->isChecked())
	    {
		// +++
		QComboTableItem *resoCol = new QComboTableItem(tableMultiFit, QString::null );
		tableMultiFit->setItem(activeDatasets+1,3,resoCol);
		
		colTemp=app(this)->columnsList(Table::xErr);
		cols.clear();
		for (j=0; j<colTemp.count();j++)
		{
		    if (rxCol.exactMatch(colTemp[j])) cols<<colTemp[j].remove(currentTable+"_");
		}
		resoCol->setStringList(cols);
		resoCol->setCurrentItem(currentReso);
		resoShift++;
	    }   
	    
	    for (j=0;j<p;j++)  
	    {
		tableMultiFit->setText(activeDatasets+1,3+j+resoShift,skript->text(i,7+2*j) ); 
		//		toResLog(currentWeight);
	    }
	    activeDatasets++;
	}
    }
    tables.prepend("All");
    tableMultiFit->setRowLabels(tables);
    for (int tt=0; tt<tableMultiFit->numCols(); tt++) tableMultiFit->adjustColumn (tt);	
}

//*******************************************
//+++ check of Para table to global parameters
//*******************************************
void fittable::checkGlobalParameters(int raw, int col)
{
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value();
    
    if (M>1) 
    {
	//+++ Parameters && Sharing && Varying 
	
	for (int pp=0; pp<p;pp++)
	{
	    QCheckTableItem *itS = (QCheckTableItem *)tablePara->item(pp,0); // Share?
	    
	    for (int mm=1; mm<M;mm++)
	    {
		QCheckTableItem *itA = (QCheckTableItem *)tablePara->item(pp,3*mm+1); // Vary?
		if (itS->isChecked())
		{
		    itA->setChecked(false);
		    tablePara->setText(pp,3*mm+2,tablePara->text(pp,2));
		    tablePara->setText(pp,3*mm+3,"---");
		}
	    }
	    
	}
    }
    QString sss;
    if  (col>0 && ((  (int) ( (col-1)/3) )*3)!=(col-1) )
    {
	sss=tablePara->text(raw, col);
	sss=sss.replace(",", ".");
//+++ 2016 test	tablePara->setText(raw, col, QString::number(sss.toDouble(),'E',spinBoxSignDigits->value()-1));
	tablePara->setText(raw, col, QString::number(sss.toDouble(),'G',spinBoxSignDigits->value()));
    }
}

//*******************************************
//*** findFitDataTable
//*******************************************
bool fittable::findFitDataTable(QString curveName, Table* &table, int &xColIndex, int &yColIndex )
{
    int i, ixy;
    bool exist=false;
    
    QString tableName=curveName.left(curveName.find("_",0));		
    QString colName=curveName.remove(tableName+"_");
    
    QWidgetList *windows = app(this)->windowsList();
    
    for (i=0;i<(int)windows->count();i++)
    {
	if (windows->at(i) && windows->at(i)->isA("Table") && windows->at(i)->name()==tableName)
	{
	    table=(Table*)windows->at(i);	
	    yColIndex=table->colIndex(colName);
	    xColIndex=0;
	    
	    bool xSearch=true;
	    ixy=yColIndex-1; 
	    while(xSearch && ixy>0 )
	    {
		if (table->colPlotDesignation(ixy)==1) 
		{
		    xColIndex=ixy;
		    xSearch=false;
		}
		else ixy--;
	    }
	    exist=true;
	}
    }
    return exist;
}

//*******************************************
//*** findFitDataTable
//*******************************************
bool fittable::findFitDataTableDirect(QString curveName, Table* &table, int &xColIndex, int &yColIndex )
{
    int i, ixy;
    
    QString tableName=curveName.left(curveName.find("_",0));		
    QString colName=curveName.remove(tableName+"_");
    
    
    
    yColIndex=table->colIndex(colName);
    xColIndex=0;
    
    bool xSearch=true;
    ixy=yColIndex-1; 
    while(xSearch && ixy>0 )
    {
	if (table->colPlotDesignation(ixy)==1) 
	{
	    xColIndex=ixy;
	    xSearch=false;
	}
	else ixy--;
    }
    
    
    return true;
}

//*********************************************************
//*** NEW :: findActiveGraph  :: 22-09-2009
//*********************************************************
bool fittable::findActiveGraph( Graph * & g)
{
    if (app(this)->windowsList()->count()==0 || !app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer"))  return false;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty()) return false;
    
    g = (Graph*)plot->activeGraph();
    
    return true;
}

bool fittable::findGraphInActivePlot( myWidget* w, Graph * & g, int grNumber, QString &label)
{
    if (grNumber<0) return false;
    if (!w || !w->isA("MultiLayer"))  return false;
    
    MultiLayer* plot = (MultiLayer*)w;
    if (plot->isEmpty()) return false;
    
    label=plot->windowLabel();
    QWidgetList *graphsList = plot->graphPtrs();
    if (grNumber>=graphsList->count()) return false;
    
    g = ( Graph* ) graphsList->at ( grNumber );
    return true; 
}

//*********************************************************
//*** NEW :: plotSwitcher:: calculate button was pressed  :: 22-09-2009
//*********************************************************
void fittable::plotSwitcher()
{
    fitOrCalculate(true);
}

//***************************************************
//*** NEW :: Simulate No Reso  :: 22-09-2009
//***************************************************
int fittable::simulateNoSANS(int N, double *Q,double *&I, gsl_function FF, bool progressShow)
{
    gsl_set_error_handler_off();
    
    //+++ 2011-09-15
    functionT *functionTpara=(functionT *)FF.params;
    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++  ---process+dialog+control--- Show only xxx times
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    int setProcessNumber=100; //  
    int procNumber=1, restNumber=0;
    if (N>setProcessNumber) { procNumber=N/setProcessNumber; restNumber=N-procNumber*setProcessNumber;}
    else setProcessNumber=N;
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    int i=0,ii,iii;
    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++ Progress dialog
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    QProgressDialog *progress;
    
    
    if (progressShow)
    {
	progress = new QProgressDialog("Function | Simulator | Started", "Stop", N, this, 
				       "Function Simulator", TRUE );
	progress->setMinimumDuration(4000);
    }
    
    //_______________________________________________    
    ((functionT *)FF.params)->beforeIter=true;
    ((functionT *)FF.params)->currentPoint=0; 
    ((functionT *)FF.params)->currentInt=0; 
    GSL_FN_EVAL(&FF,Q[0]);
    
    //+++
    // integral1
    ((functionT *)FF.params)->currentInt=1; 
    double Int1=GSL_FN_EVAL(&FF,Q[0]);
    ((functionT *)FF.params)->Int1=Int1;
    // integral2
    ((functionT *)FF.params)->currentInt=2; 
    double Int2=GSL_FN_EVAL(&FF,Q[0]);
    ((functionT *)FF.params)->Int2=Int2;    
    // integral3
    ((functionT *)FF.params)->currentInt=3; 
    double Int3=GSL_FN_EVAL(&FF,Q[0]);
    ((functionT *)FF.params)->Int3=Int3;
    
    //+++
    ((functionT *)FF.params)->currentInt=0; 
    ((functionT *)FF.params)->beforeIter=false;
    //_______________________________________________
    
    //---
    for (i=0;  i<restNumber;i++)
    {	
	((functionT *)(FF.params))->currentPoint=i;	
	I[i] = GSL_FN_EVAL (&FF,Q[i]);
	
	if (progressShow)
	{
	    //+++ Start +++  1
	    progress->setProgress(i);
	    progress->setLabelText("Function | Simulator | Started: # "+QString::number(i+1)+" of "+QString::number(N));
	    
	    if ( progress->wasCanceled() ) 
	    {
		progress->close();
		return i;
	    }
	}
    }
    
    for (ii=0; ii<setProcessNumber;ii++)
    {
	for (iii=0; iii<procNumber;iii++)
	{
	    ((functionT *)FF.params)->currentPoint=i;
	    I[i] = GSL_FN_EVAL (&FF,Q[i]);
	    i++;
	}
	if (progressShow)
	{
	    //+++ Start +++  1
	    progress->setProgress(i-1);
	    progress->setLabelText("Function | Simulator | Started: # "+QString::number(i)+" of "+QString::number(N));
	    
	    if ( progress->wasCanceled() ) 
	    { 
		progress->close();
		return i;
	    }
	}
    }
    
    //+++ new::  initAfterIteration 2011-08-19
    ((functionT *)FF.params)->afterIter=true;
    ((functionT *)FF.params)->currentPoint=i-1;
    GSL_FN_EVAL(&FF, Q[i-1]);
    ((functionT *)FF.params)->afterIter=false;
    
    //---
    
    if (progressShow) 
    {
	progress->close();
    }
    return N;
}

//***************************************************
//*** NEW :: Simulate only Reso  :: 22-09-2009
//***************************************************
int fittable::simulateSANSreso(int N, double *Q,double *sigma, double *&I, resoSANS &paraReso, bool progressShow)
{
    
    gsl_set_error_handler_off();
    
    //+++ 2011-09-15
    functionT *functionTpara=(functionT *)paraReso.function->params;
    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++  ---process+dialog+control--- Show only xxx times
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    int setProcessNumber=100; //  
    int procNumber=1, restNumber=0;
    if (N>setProcessNumber) { procNumber=N/setProcessNumber; restNumber=N-procNumber*setProcessNumber;}
    else setProcessNumber=N;
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    //
    int i=0,ii,iii;
    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++ Progress dialog
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    QProgressDialog *progress;
    
    
    if (progressShow)
    {
	progress = new QProgressDialog("Function | Simulator | Started", "Stop", N, this, 
				       "Function Simulator", TRUE );
	progress->setMinimumDuration(4000);
    }
    
    //___________________________________________________________
    ((struct functionT *) functionTpara)->beforeIter=true;
    ((struct functionT *) functionTpara)->currentPoint=0;
    //
    paraReso.resoSigma=0;
    paraReso.Q0=0;
    
    ((functionT *)functionTpara)->currentInt=0; 
    resoIntegral(Q[i],&paraReso) ;
    
    //+++
    // integral1
    ((functionT *)functionTpara)->currentInt=1;     
    double Int1=resoIntegral(Q[i],&paraReso) ;
    ((functionT *)functionTpara)->Int1=Int1;
    // integral2
    ((functionT *)functionTpara)->currentInt=2; 
    double Int2=resoIntegral(Q[i],&paraReso) ;
    ((functionT *)functionTpara)->Int2=Int2;    
    // integral3
    ((functionT *)functionTpara)->currentInt=3; 
    double Int3=resoIntegral(Q[i],&paraReso) ;
    ((functionT *)functionTpara)->Int3=Int3;
    
    //+++
    ((functionT *)functionTpara)->currentInt=0;
    ((struct functionT *) functionTpara)->beforeIter=false;
    
    //___________________________________________________________
    
    
    for (i=0; i<restNumber;i++)
    {
	((struct functionT *) functionTpara)->currentPoint=i;
	//+++ paraReso
	paraReso.resoSigma=sigma[i];
	paraReso.Q0=Q[i];
	
	//+++
	I[i]=  resoIntegral(Q[i],&paraReso) ;
	
	if (progressShow)
	{
	    //+++ Start +++  1
	    progress->setProgress(i);
	    progress->setLabelText("Function | Simulator | Started: # "+QString::number(i+1)+" of "+QString::number(N));
	    
	    if ( progress->wasCanceled() ) 
	    {
		progress->close();
		return i;
	    }
	}
    }
    
    for (ii=0; ii<setProcessNumber;ii++)
    {
	for (iii=0; iii<procNumber;iii++)
	{
	    ((struct functionT *) functionTpara)->currentPoint=i;
	    //+++ paraReso
	    paraReso.resoSigma=sigma[i];
	    paraReso.Q0=Q[i];
	    //+++
	    I[i]=resoIntegral(Q[i],&paraReso);
	    i++;
	}
	if (progressShow)
	{
	    //+++ Start +++  1
	    progress->setProgress(i-1);
	    progress->setLabelText("Function | Simulator | Started: # "+QString::number(i)+" of "+QString::number(N));
	    
	    if ( progress->wasCanceled() ) 
	    {
		progress->close();
		return i;
	    }
	}
    }
    
    //+++ new::  initAfterIteration 2011-08-19
    ((struct functionT *) functionTpara)->afterIter=true;
    ((struct functionT *) functionTpara)->currentPoint=0;
    GSL_FN_EVAL(paraReso.function, 1.0);
    ((struct functionT *) functionTpara)->afterIter=false;         
    //---
    
    if ( progressShow ) progress->close();
    
    return N;
}

//***************************************************
//*** NEW :: Simulate only Poly  :: 22-09-2009
//***************************************************
int fittable::simulateSANSpoly(int N, double *Q, double *&I, poly2_SANS poly2, bool progressShow)
{
    gsl_set_error_handler_off();
    
    //+++ 2011-09-15
    functionT *functionTpara=(functionT *)poly2.function->params;
    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++  ---process+dialog+control--- Show only xxx times
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    int setProcessNumber=100; //  
    int procNumber=1, restNumber=0;
    
    if (N>setProcessNumber) { procNumber=N/setProcessNumber; restNumber=N-procNumber*setProcessNumber;}
    else setProcessNumber=N;
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    //+++
    int i=0,ii,iii;
    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++ Progress dialog
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    QProgressDialog *progress;
    
    
    if (progressShow)
    {
	progress = new QProgressDialog("Function | Simulator | Started", "Stop", N, this, 
				       "Function Simulator", TRUE );
	progress->setMinimumDuration(4000);
    }
    
    
    //___________________________________________________________
    ((struct functionT *) functionTpara)->beforeIter=true;
    ((struct functionT *) functionTpara)->currentPoint=0;
    ((functionT *)functionTpara)->currentInt=0; 
    polyIntegral(0,&poly2);
    
    //+++
    // integral1
    ((functionT *)functionTpara)->currentInt=1;     
    double Int1=polyIntegral(0,&poly2);
    ((functionT *)functionTpara)->Int1=Int1;
    // integral2
    ((functionT *)functionTpara)->currentInt=2; 
    double Int2=polyIntegral(0,&poly2);
    ((functionT *)functionTpara)->Int2=Int2;    
    // integral3
    ((functionT *)functionTpara)->currentInt=3; 
    double Int3=polyIntegral(0,&poly2);
    ((functionT *)functionTpara)->Int3=Int3;
    //+++
    ((functionT *)functionTpara)->currentInt=0;
    ((struct functionT *) functionTpara)->beforeIter=false;
    //___________________________________________________________
    
    
    for (i=0; i<restNumber;i++)
    {
	((struct functionT *) functionTpara)->currentPoint=i;
	//+++ poly
	I[i] = polyIntegral(Q[i],&poly2); 
	if (progressShow)
	{
	    //+++ Start +++  1
	    progress->setProgress(i);
	    progress->setLabelText("Function | Simulator | Started: # "+QString::number(i+1)+" of "+QString::number(N));
	    
	    if ( progress->wasCanceled() ) 
	    {
		progress->close();
		return i;
	    }
	}
    }
    
    for (ii=0; ii<setProcessNumber;ii++)
    {
	for (iii=0; iii<procNumber;iii++)
	{
	    ((struct functionT *) functionTpara)->currentPoint=i;
	    //+++ poly
	    I[i] = polyIntegral(Q[i],&poly2); 
	    i++;
	}
	if (progressShow)
	{
	    //+++ Start +++  1
	    progress->setProgress(i-1);
	    progress->setLabelText("Function | Simulator | Started: # "+QString::number(i)+" of "+QString::number(N));
	    
	    if ( progress->wasCanceled() ) 
	    {
		progress->close();
		return i;
	    }
	}
    }
    
    //+++ new::  initAfterIteration 2011-08-19
    ((struct functionT *) functionTpara)->afterIter=true;
    ((struct functionT *) functionTpara)->currentPoint=0;    
    GSL_FN_EVAL(poly2.function, 1.0);
    ((struct functionT *) functionTpara)->afterIter=false;     
    //---
    
    if ( progressShow ) 
    {
	progress->close();
    }
    return N;
}

//***************************************************
//*** NEW :: Simulate Reso && Poly  :: 22-09-2009
//***************************************************
int fittable::simulateSANSpolyReso(int N, double *Q, double *sigma, double *&I, polyReso1_SANS &polyReso1, bool progressShow)
{
    gsl_set_error_handler_off();
    
    //+++ 2011-09-15
    functionT *functionTpara=(functionT *)polyReso1.poly2->function->params;
    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++  ---process+dialog+control--- Show only xxx times
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    int setProcessNumber=100; //  
    int procNumber=1, restNumber=0;
    
    
    if (N>setProcessNumber) { procNumber=N/setProcessNumber; restNumber=N-procNumber*setProcessNumber;}
    else setProcessNumber=N;
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    //
    int i=0,ii,iii;
    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++ Progress dialog
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    QProgressDialog *progress;
    
    if (progressShow)
    {
	progress = new QProgressDialog("Function | Simulator | Started", "Stop", N, this, 
				       "Function Simulator", TRUE );
	progress->setMinimumDuration(4000);
    }
    
    //___________________________________________________________
    ((struct functionT *) functionTpara)->beforeIter=true;
    ((struct functionT *) functionTpara)->currentPoint=0;
    ((functionT *)functionTpara)->currentInt=0; 
    //
    polyReso1.resoSigma=0.0;
    resoPolyFunctionNew(Q[i], &polyReso1);
    //
  
    //+++
    // integral1
    ((functionT *)functionTpara)->currentInt=1;     
    double Int1=resoPolyFunctionNew(Q[i], &polyReso1);
    ((functionT *)functionTpara)->Int1=Int1;
    // integral2
    ((functionT *)functionTpara)->currentInt=2; 
    double Int2=resoPolyFunctionNew(Q[i], &polyReso1);
    ((functionT *)functionTpara)->Int2=Int2;    
    // integral3
    ((functionT *)functionTpara)->currentInt=3; 
    double Int3=resoPolyFunctionNew(Q[i], &polyReso1);
    ((functionT *)functionTpara)->Int3=Int3;
    //+++
    ((functionT *)functionTpara)->currentInt=0;
    ((struct functionT *) functionTpara)->beforeIter=false; 
    //___________________________________________________________
    
    
    for (i=0; i<restNumber;i++)
    {
	((struct functionT *) functionTpara)->currentPoint=i;
	//+++ polyReso
	polyReso1.resoSigma=sigma[i];
	//I[i]=resoPolyIntegral(Q[i],&polyReso1);
	I[i]=resoPolyFunctionNew(Q[i], &polyReso1);
	
	if (progressShow)	
	{
	    //+++ Start +++  1
	    progress->setProgress(i);
	    progress->setLabelText("Function | Simulator | Started: # "+QString::number(i+1)+" of "+QString::number(N));
	    
	    if ( progress->wasCanceled() ) 
	    {
		progress->close();
		return i;
	    }
	}
    }
    
    for (ii=0; ii<setProcessNumber;ii++)
    {
	for (iii=0; iii<procNumber;iii++)
	{
	    ((struct functionT *) functionTpara)->currentPoint=i;
	    //+++ polyReso
	    polyReso1.resoSigma=sigma[i];
	    
	    //I[i]=resoPolyIntegral(Q[i],&polyReso1);
	    I[i]=resoPolyFunctionNew(Q[i], &polyReso1);
	    i++;
	}
	if (progressShow)
	{
	    //+++ Start +++  1
	    progress->setProgress(i-1);
	    progress->setLabelText("Function | Simulator | Started: # "+QString::number(i)+" of "+QString::number(N));
	    
	    if ( progress->wasCanceled() ) 
	    {
		progress->close();
		return i;
	    }
	}
    }
    
    //+++ new::  initAfterIteration 2011-08-19
    ((struct functionT *) functionTpara)->afterIter=true;
    ((struct functionT *) functionTpara)->currentPoint=0;
    GSL_FN_EVAL(polyReso1.poly2->function, 1.0);
    ((struct functionT *) functionTpara)->afterIter=false;     
    //---	
    
    if ( progressShow ) 
    {
	progress->close();
    }
    return N;
}

bool fittable::checkCell(QString &line)
{
    
    QRegExp rx("((\\-|\\+)?\\d\\d*(\\.\\d*)?((E\\-|E\\+)\\d\\d?\\d?\\d?)?)"); 
    
    line=line.stripWhiteSpace();
    line.replace(",",".");
    line.replace("e","E");	
    line.replace("E","E0");	
    line.replace("E0+","E+0");
    line.replace("E0-","E-0");
    line.replace("E0","E+0");
    
    int pos =0;
    pos=rx.search( line, pos );
    
    if ( pos <0 ) return false; 
    
    line=rx.cap( 1 );
    
    return true;
}

//***************************************************
//*** NEW :: SetQandIgivenM :: 22-09-2009
//***************************************************
bool fittable::SetQandIgivenM(int &Ntotal, double*&Qtotal, double*&Itotal, double*&dItotal, double*&Sigmatotal, int m)
{
    
    //++++++++++++++++++
    double min, max;
    int minN, maxN;
    bool weightYN, resoYN;
    //++++++++++++++++++    
    
    //+++
    bool SANSsupport=checkBoxSANSsupport->isChecked();
    //+++
    int M=spinBoxNumberCurvesToFit->value();  if(m>=M) return false;
    //+++ Table Name
    Table *t;
    int xColIndex,yColIndex;
    
    //+++
    QComboTableItem *curve =(QComboTableItem*)tableCurves->item (0, 2*m+1);
    if ( curve->count()==0 ) return false;
    QString curveName=curve->currentText();
    QString tableName=curveName.left(curveName.find("_",0));	
    
    if ( !findFitDataTable(curveName, t, xColIndex,yColIndex ) ) return false;
    
    //+++
    size_t N=t->numRows();
    
    //+++
    bool NnotQ =true; 
    if (tableCurves->text(1,2*m)!="N") NnotQ=false;
    
    //+++ Min Max
    min=tableCurves->text(2,2*m+1).toDouble();
    max=tableCurves->text(3,2*m+1).toDouble();
    minN=tableCurves->text(2,2*m+1).toInt();
    maxN=tableCurves->text(3,2*m+1).toInt();
    
    if (widgetStackFit->id(widgetStackFit->visibleWidget())==2)
    {
	NnotQ =true;
	if (comboBoxSimQN->currentText()!="N") NnotQ=false;
	
	//+++ Min Max
	min=textLabelRangeFirst->text().toDouble();
	max=textLabelRangeLast->text().toDouble();
	minN=textLabelRangeFirst->text().toInt();
	maxN=textLabelRangeLast->text().toInt();
    }
    
    //+++  weight  dI
    weightYN=false;
    QString colWeight="";
    QCheckTableItem *it = (QCheckTableItem *)tableCurves->item(4,2*m);
    if (it->isChecked()) 
    {
	QComboTableItem *weight =(QComboTableItem*)tableCurves->item (4, 2*m+1);
	colWeight=weight->currentText();
	weightYN=true;
    }
    
    if (textLabelCenter->text().contains("Generate Results") && tabWidgetGenResults->currentPageIndex()==0 )    
    {
	weightYN=false;
	colWeight="";
	
	if (checkBoxWeightSim->isChecked())
	{
	    weightYN=true;
	    colWeight=comboBoxResoSim->currentText();
	}
    }
    
    //+++ ResoSigma
    resoYN=false;
    QString colReso="";
    if (SANSsupport)
    {
	colReso="";
	it = (QCheckTableItem *)tableCurves->item(5,2*m);
	if (it->isChecked() )
	{
	    resoYN=true;
	}
    QComboTableItem *reso =(QComboTableItem*)tableCurves->item (5, 2*m+1);
    colReso=reso->currentText();
        
	if (textLabelCenter->text().contains("Generate Results") && tabWidgetGenResults->currentPageIndex()==0 )    
	{
	    resoYN=false;
	    colReso="";
	    
	    if (checkBoxResoSim->isChecked())
	    {
		resoYN=true;
	    }
        colReso=comboBoxResoSim->currentText();
	}
    }
    
    
    
    double *II=new double[N];
    double *QQ=new double[N];
    double *dII=new double[N];
    double *sigmaResoO=new double[N];
    
    
    
    QRegExp rx( "((\\-|\\+)?\\d*(\\.|\\,)\\d*((e|E)(\\-|\\+)\\d*)?)|((\\-|\\+)?\\d+)" );	
    
    int i;
    QString line;
    
    double wa=lineEditWA->text().toDouble(); wa=fabs(wa);
    double wb=lineEditWB->text().toDouble(); wb=fabs(wb); if (wb==0) wb=1.0;
    double wc=lineEditWC->text().toDouble(); wc=fabs(wc);
    double wxmax=lineEditWXMAX->text().toDouble();
    
    
    for(i=0;i<N;i++)
    {
	//Q
	line=t->text(i,xColIndex);
	if ( checkCell(line) ) QQ[i]=line.toDouble();
	else QQ[i]=-911119.119911;
	
	//I	
	line=t->text(i,yColIndex);
	if ( checkCell(line) ) II[i]=line.toDouble();
	else II[i]=-911119.119911;
	
	if (!weightYN) dII[i]=1.00;
	else 
	{
	    if (comboBoxWeightingMethod->currentItem()==0)
	    {
		line=t->text(i,t->colIndex(colWeight));
		if ( checkCell(line)  && line.toDouble()!=0.0) dII[i]=fabs(line.toDouble());
		else dII[i]=-911119.119911;	    
	    }
	    else if (comboBoxWeightingMethod->currentItem()==1)
	    {
		dII[i]=sqrt(fabs(II[i]));
	    }
	    else if (comboBoxWeightingMethod->currentItem()==2)
	    {
		line=t->text(i,t->colIndex(colWeight));
		if ( checkCell(line)  && line.toDouble()!=0.0) dII[i]=1/sqrt(fabs(line.toDouble()));
		else dII[i]=-911119.119911;	
	    }
	    else if (comboBoxWeightingMethod->currentItem()==3)
	    {
		dII[i]= fabs(II[i]);
	    }
	    else if (comboBoxWeightingMethod->currentItem()==4)
	    {
		dII[i]=sqrt(pow( fabs(II[i]),wa));
	    }
	    else if (comboBoxWeightingMethod->currentItem()==5)
	    {
		dII[i]=sqrt(pow(wc,wa)+wb*pow( fabs(II[i]),wa));
	    }
	    else if (comboBoxWeightingMethod->currentItem()==6)
	    {
		dII[i]=sqrt(pow(wc,fabs(wxmax-QQ[i]))*pow( fabs(II[i]),wa));
	    }
	}
	
	//Sigma
	if (resoYN)
	{
	    //-NEW
	    if ( colReso=="from DANP") sigmaResoO[i]=app(this)->sigma(QQ[i]);
	    else if ( colReso=="from SPHERES") sigmaResoO[i]=app(this)->sigma(QQ[i]); //change to SHPERES func
	    else 			    
	    {
		line=t->text(i,t->colIndex(colReso	));
		if ( checkCell(line) ) sigmaResoO[i]=line.toDouble();
		else sigmaResoO[i]=-911119.119911;
	    }
	}
    else if (SANSsupport)
    {
        //-NEW
        if ( colReso=="from DANP") sigmaResoO[i]=0.0 - fabs(app(this)->sigma(QQ[i]));
        else if ( colReso=="from SPHERES") sigmaResoO[i]= 0.0 - fabs(app(this)->sigma(QQ[i])); //change to SHPERES func
        else
        {
            line=t->text(i,t->colIndex(colReso	));
            if ( checkCell(line) ) sigmaResoO[i]= 0.0 - fabs(line.toDouble());
            else sigmaResoO[i]=0.0;
        }
    }
	else
	    sigmaResoO[i]=0.0;
	
    }
    
    int Nfinal=0;
    bool yn;
    
    for (i=0;i<N;i++) if ( QQ[i]!=-911119.119911 && II[i]!=-911119.119911 && dII[i]!=-911119.119911 && sigmaResoO[i]!=-911119.119911) 
    {
	yn=false;
	if (NnotQ)	
	{
	    if (i>=(minN-1) && i<=(maxN-1) ) yn=true;
	}
	else
	{
	    if ( QQ[i]>=min && QQ[i] <= max ) yn=true;
	}
	if (yn) Nfinal++;
    }
    
    if (Nfinal==0) return false;	
    
    Qtotal=new double[Nfinal];
    Itotal=new double[Nfinal];
    dItotal=new double[Nfinal];
    Sigmatotal=new double[Nfinal];
    
    int prec=spinBoxSignDigits->value();
    
    Nfinal=0;
    for (i=0;i<N;i++) if ( QQ[i]!=-911119.119911 && II[i]!=-911119.119911 && dII[i]!=-911119.119911 && sigmaResoO[i]!=-911119.119911)
    {
	yn=false;
	if (NnotQ)	
	{
	    if (i>=(minN-1) && i<=(maxN-1) ) yn=true;
	}
	else
	{
	    if ( QQ[i]>=min && QQ[i] <= max ) yn=true;
	}
	if (yn) 	
	{
	    Qtotal[Nfinal]		= round2prec(QQ[i],prec);
	    Itotal[Nfinal]		= round2prec(II[i],prec);
	    dItotal[Nfinal]		= round2prec(dII[i],prec);
	    Sigmatotal[Nfinal]	= round2prec(sigmaResoO[i],prec);
	    Nfinal++;
	}
    }
    Ntotal=Nfinal;
  
    
    delete[] QQ; 
    delete[] II; 
    delete[] dII; 
    delete[] sigmaResoO;
    
    return true;
}

// +++  Set Q and I  :: uniform range
bool fittable::SetQandIuniform(int &N, double* &QQ, double* &sigmaQ, int m)
{
    int i;
    //+++
    bool SANSsupport=checkBoxSANSsupport->isChecked();
    //+++
    int M=spinBoxNumberCurvesToFit->value();  if(m>=M) return false;
    int p=spinBoxPara->value(); if (p==0) return false;
    //+++
    N=lineEditNumPointsSim->text ().toInt();
        
    sizetNumbers sizetNumbers={N,1,p,p};
  
    
    
    double Qmin=lineEditFromQsim->text ().toDouble();
    double Qmax=lineEditToQsim->text ().toDouble();		
    //+++
    double *Q=new double[N];
    double *sigma=new double[N];		
    
   
    
    //+++  Q [i]  calculation    
    for (i=0;i<N;i++)
    {    
	if (checkBoxLogStep->isChecked()) Q[i]=pow(10, (log10(Qmin)+(log10(Qmax)-log10(Qmin))/ (N-1)*i));
	else Q[i]=Qmin+(Qmax-Qmin)/ (N-1) *i; 
    }
    
    // sigmaReso[i] calculation
    if ( SANSsupport )
    {
        
        
	if (comboBoxResoSim->currentText()=="from DANP") 
	{
	    for (i=0;i<N;i++) sigma[i]=app(this)->sigma(Q[i]);
	}
	else if (comboBoxResoSim->currentText()=="from SPHERES") //chanege to SPHERES func
	{
	    for (i=0;i<N;i++) sigma[i]=app(this)->sigma(Q[i]);
	}
        
	else
	{
	    //~~~ DEFINE table name
	    QString tableName=comboBoxResoSim->currentText().left(comboBoxResoSim->currentText().find('_'));
	    QString sigmaName=comboBoxResoSim->currentText().right(comboBoxResoSim->currentText().find('_')+1);
	    
	    //~~~ check of existence of table
	    bool exist=false;
	    
	    Table *t;
	    QWidgetList *windows = app(this)->windowsList();
	    for (i=0;i<(int)windows->count();i++) 
	    {
		if (windows->at(i) && windows->at(i)->isA("Table") && windows->at(i)->name()==tableName)
		{	
		    t=(Table*)windows->at(i);
		    exist=true;
		}			
	    }
	    
	    if (!exist)
	    {
		QMessageBox::warning(this,tr("QtiKWS"),
				     "There is no table:: "+tableName);
		return false;	
	    }
	    
	    int colIndexSigma=t->colIndex(sigmaName);
	    if (colIndexSigma<1)
	    {
		
		QMessageBox::warning(this,tr("QtiKWS"),
				     "Problem with Sigma 2: "+sigmaName);
		return false;	
	    }
	    
	    //~~~ number of points
	    int Nsigma=0;
	    QRegExp rx( "((\\-|\\+)?\\d*(\\.|\\,)\\d*((e|E)(\\-|\\+)\\d*)?)|((\\-|\\+)?\\d+)" );	
	    for (i=0; i<t->numRows();i++)
	    {
		if (rx.exactMatch(t->text(i,0)) && rx.exactMatch(t->text(i,colIndexSigma)))
		{
		    Nsigma++;
		}
	    }
	    
	    if (Nsigma<3)
	    {
		QMessageBox::warning(this,tr("QtiKWS"),
				     "Sigma problem 3");
		return  false;	
	    }
	    
	    //double QQsigma[Nsigma];
	    double *QQsigma=new double[Nsigma];
	    //    double sigmaSigma[Nsigma];
	    double *sigmaSigma=new double[Nsigma];    
	    Nsigma=0;
	    double Qmin=1;
	    double Qmax=0;
	    double sigmaMin, sigmaMax;
	    
	    
	    for (i=0; i<t->numRows();i++)
	    {
		if (rx.exactMatch(t->text(i,0)) && rx.exactMatch(t->text(i,colIndexSigma)))
		{
		    QQsigma[Nsigma]=t->text(i,0).toDouble();
		    sigmaSigma[Nsigma]=t->text(i,colIndexSigma).toDouble();
		    if (QQsigma[Nsigma]<Qmin) { Qmin=QQsigma[Nsigma]; sigmaMin=sigmaSigma[Nsigma];};
		    if (QQsigma[Nsigma]>Qmax){ Qmax=QQsigma[Nsigma]; sigmaMax=sigmaSigma[Nsigma];};		    
		    Nsigma++;
		}
	    }
	    
	    gsl_interp_accel *acc  = gsl_interp_accel_alloc ();
	    gsl_spline *spline  = gsl_spline_alloc (gsl_interp_cspline, Nsigma);
	    gsl_spline_init (spline, QQsigma, sigmaSigma, Nsigma);
	
	    
	    if ( comboBoxInstrument->currentText().contains("Back") )
	    {
		
		int Ntotal;
		double *Qtotal, *Itotal, *dItotal, *Sigmatotal;
		int m=comboBoxDatasetSim->currentItem();
		
		SetQandIgivenM(Ntotal, Qtotal, Itotal, dItotal, Sigmatotal, m);
		
		if (Ntotal>21)
		{
		    sigmaMin=Sigmatotal[0]+Sigmatotal[1]+Sigmatotal[2]+Sigmatotal[3]+Sigmatotal[4];
		    sigmaMin+=Sigmatotal[5]+Sigmatotal[6]+Sigmatotal[7]+Sigmatotal[8]+Sigmatotal[9];		    
		    sigmaMin=sigmaMin/10;
		    
		    sigmaMax=Sigmatotal[Ntotal-1]+Sigmatotal[Ntotal-2]+Sigmatotal[Ntotal-3]+Sigmatotal[Ntotal-4]+Sigmatotal[Ntotal-5];
		    sigmaMax+=Sigmatotal[Ntotal-6]+Sigmatotal[Ntotal-7]+Sigmatotal[Ntotal-8]+Sigmatotal[Ntotal-9]+Sigmatotal[Ntotal-10];
		    sigmaMax=sigmaMax/10;
		}
		
		for (i=0;i<N;i++)
		{
		    if (Q[i]<Qtotal[0]) 
			sigma[i]=sigmaMin;
		    else if (Q[i]>Qtotal[Ntotal-1]) 
			sigma[i]=sigmaMax;
		    else 
			sigma[i]= gsl_spline_eval (spline, Q[i], acc);
		}
		delete[] Qtotal;
		delete[] Itotal;
		delete[] dItotal;
		delete[] Sigmatotal;
	    }
	    else
	    {
		
		
		for (i=0;i<N;i++)
		{
		    if (Q[i]<Qmin) { if (Qmin!=0) sigma[i]=sigmaMin/Qmin*Q[i]; else sigma[i]=-911119.119911;}
		    else
			if (Q[i]>Qmax) {if (Qmax!=0) sigma[i]=sigmaMax/Qmax*Q[i]; else sigma[i]=-911119.119911;}
		    else sigma[i]= gsl_spline_eval (spline, Q[i], acc);
		}
	    }
	    
        if ( !checkBoxResoSim->isChecked() ) for (i=0;i<N;i++) sigma[i]=0.0 - fabs(sigma[i]);
        
	    delete[] QQsigma;
	    delete[] sigmaSigma;
	}
    }
    else  for (i=0;i<N;i++) sigma[i]=0.00;
    
     
    int Nfinal=0;
    for (i=0;i<N;i++) if ( sigma[i]!=-911119.119911 ) Nfinal++;

    N=Nfinal;
    
    
    if (Nfinal==0) 
    {
	delete[] Q;
	delete[] sigma;
	return false;	
    }
    
    QQ=new double[N];
    sigmaQ=new double[N];
        
    Nfinal=0;
    
    int prec=spinBoxSignDigits->value();
    

    
    for (i=0;i<N;i++) if ( Q[i]!=-911119.119911)
    {
	QQ[Nfinal]	= round2prec( Q[i], prec);
	sigmaQ[Nfinal]	= round2prec( sigma[i], prec);
	Nfinal++;
    }
    
    delete[] Q;
    delete[] sigma;
    return true;
}


//***************************************************
//*** NEW :: simulate Function :: table  :: 22-09-2009
//***************************************************
bool fittable::simulateData( int &N, double *Q,  double *&I, double *sigma, bool progressShow)
{	
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++ init parameters of function
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++    
    int p=spinBoxPara->value(); if (p==0) return false;
    for (int i=0;i<p;i++) gsl_vector_set(F_para, i,  tableParaSimulate->text(i,0).toDouble() );
        
    //+++ init parameters of function	
    //+++ 
    bool polyYN=false;
    if (checkBoxPolySim->isChecked()) polyYN=true;
    int polyFunction=comboBoxPolyFunction->currentItem();
    //+++ 
    bool beforeFit=false;
    bool afterFit=false;
    bool beforeIter=false;
    bool afterIter=false;
    
    
    //+++ 23.09.2011	
    int currentFirstPoint=0;
    int currentLastPoint=N-1;
    int currentPoint=0;
    
    int prec=spinBoxSignDigits->value();
    
    //+++ ,tableName,tableColNames,tableColDestinations,mTable
    std::string tableName="no-matrix";
    std::string *tableColNames; 
    int *tableColDestinations; 
    gsl_matrix * mTable;

    double *Idata= new double[N]; for (int i=0;i<N;i++) Idata[i]=I[i];
    
    functionT paraT={F_para, Q, Idata, sigma, currentFirstPoint, currentLastPoint, currentPoint, polyYN, polyFunction, beforeFit, afterFit, beforeIter, afterIter, 1.0, 1.0, 1.0, 0, prec,tableName,tableColNames,tableColDestinations,mTable};
    
    F.params=&paraT;
    
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++ no SANS support bare function
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    if ( !checkBoxSANSsupport->isChecked() ) 
    {
	N=simulateNoSANS(N,Q,I, F, progressShow);
        delete[] Idata;
	return true;
    }
    
    QString currentInstrument=comboBoxInstrument->currentText();
    bool bsMode=false;    
    if ( currentInstrument.contains("Back") ) 
    {
	bsMode=true; 
    }
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++ SANS support ::
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    bool resoSim=checkBoxResoSim->isChecked();
    bool polySim=checkBoxPolySim->isChecked();
    
    //+++
    double scale=1.0;
    double back=0.0;
    double sigmaPoly=-1;
    
    if (!bsMode)
    {
	scale=gsl_vector_get(F_para, p-3);
	back=gsl_vector_get(F_para, p-4);
	sigmaPoly=gsl_vector_get(F_para, p-2);
    }
    
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++ with SANS support :: no reso no poly 
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    if ( !resoSim && ( !polySim || sigmaPoly<=0) )
    {
	//+++
	N=simulateNoSANS(N,Q,I, F, progressShow);
	//+++
	for (int i=0; i<N;i++) I[i]=round2prec(scale*(I[i]+back), prec);
    
    delete[] Idata;
	//+++
	return true;
    }
    
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++ with SANS support :: only reso no poly 
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    double absErrReso=lineEditAbsErr->text().toDouble();
    double relErrReso=lineEditRelErr->text().toDouble();
    int intWorkspaseReso=spinBoxIntWorkspase->value();
    int numberSigmaReso=spinBoxIntLimits->value();
    int func_reso=comboBoxResoFunction->currentItem();
    
    if ( bsMode ) func_reso+=10;
    
    //+++
    integralControl 	resoIntegralControl={absErrReso,relErrReso, intWorkspaseReso, numberSigmaReso, func_reso};
    
    //+++ paraReso
    resoSANS paraReso= { sigma[0], Q[0], &F, &resoIntegralControl };
    
    
    if ( resoSim &&  ( !polySim || sigmaPoly<=0) )
    {
	//+++
	double *Isim=new double[N];//2014.07 	 
	N=simulateSANSreso(N, Q, sigma, Isim, paraReso, progressShow);
	for(int i=0; i<N;i++) I[i]=Isim[i];//2014.07
	delete[] Isim;	
	//+++
	for (int i=0; i<N;i++) I[i]=round2prec(scale*(I[i]+back), prec);
	
    delete[] Idata;
    //+++
	return true;
    }
    
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++ with SANS support :: no reso only poly 
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    double absErrPoly=lineEditAbsErrPoly->text().toDouble();
    double relErrPoly=lineEditRelErrPoly->text().toDouble();
    int intWorkspasePoly=spinBoxIntWorkspasePoly->value();
    int numberSigmaPoly=spinBoxIntLimitsPoly->value();
    int func_poly=comboBoxPolyFunction->currentItem();     
    //+++
    integralControl polyIntegralControl={absErrPoly,relErrPoly, intWorkspasePoly, numberSigmaPoly, func_poly};
    
    int polyItem=comboBoxPolySim->currentItem();
    
    poly2_SANS poly2={&F, polyItem, &polyIntegralControl};
    
    
    if ( !resoSim && polySim )
    {
	double *Isim=new double[N];//2014.07 	 
	
	N=simulateSANSpoly(N, Q, Isim, poly2, progressShow);
	
	for(int i=0; i<N;i++) I[i]=Isim[i];//2014.07
	delete[] Isim;	
	
	//+++
	for (int i=0; i<N;i++) I[i] = round2prec(scale*(I[i]+back), prec);
	//+++
	
    delete[] Idata;
    return true;
    }
    
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++ with SANS support :: both reso and poly 
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    polyReso1_SANS polyReso1={&poly2,sigma[0], &resoIntegralControl};
    
    
    if ( resoSim && polySim )
    {
	double *Isim=new double[N];//2014.07 
	N=simulateSANSpolyReso(N, Q, sigma, Isim, polyReso1, progressShow);   
	for(int i=0; i<N;i++) I[i]=Isim[i];//2014.07
	delete[] Isim;	
	//+++
	for (int i=0; i<N;i++) I[i] = round2prec(scale*(I[i]+back), prec);
	//+++
	
    delete[] Idata;
    return true;
    }
    
    delete[] Idata;
    return false;
}

//***************************************************
//*** NEW :: simulate Function :: table  :: 22-09-2009
//***************************************************
bool fittable::simulateDataTable( int source, int number, QString &simulatedTable, int N, double *Q,  double *Idata, double *dI, double *sigma,  double *Isim, Table *&t)
{
    
    int prec=spinBoxSignDigits->value();
    
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value(); if (p==0) return false;
    bool uniform=radioButtonUniform_Q->isChecked();	
    
    QString simulatedLabel;
    QString function=textLabelFfunc->text();
    
    //+++ 
    bool tableExist=false;
    
    if (source==0 && function.contains("superpositional-"))
    {
	source=1;
	function.remove("superpositional-");
	function.replace("-","-part-");
    }
    
    switch (source)
    {
    case 0: simulatedTable="simulatedCurve-"+function;
	simulatedLabel="Simulated Curve";	
	if (!checkBoxSimIndexing->isChecked()) break;
//	if (number ==0 ) 
	    simulatedTable=app(this)->generateUniqueName(simulatedTable+"-");
//	else if (number > 0 ) 
//	{ 
//	    simulatedTable+="-"+QString::number(number);
//	    removeTables(simulatedTable);  
//	}
	break;
    case 1: simulatedTable="fitCurve-"+function;
	if (M>1) simulatedTable+="-global-"+QString::number(number+1);	
	simulatedLabel="Fitting Curve"; 
	break;
    case 2:
	if (setToSetSimulYN)
	{
	    simulatedTable="simulatedCurve-"+function+"-set-"+QString::number(setToSetNumber);
	    simulatedTable=app(this)->generateUniqueName(simulatedTable+"-");	
	    simulatedLabel="Simulated Curve by Set-to-Set interface";   
	}
	else
	{
	    simulatedTable="fitCurve-"+function+"-set-"+QString::number(setToSetNumber);
	    simulatedLabel="Fitted Curve by Set-to-Set interface";
	}
	break;
    }
    
    //app(this)->changeFolder("FIT :: 1D");
    
    //    Table *t;
    int cols, rows;
    
    if (checkTableExistence(simulatedTable, t) )
    {
	tableExist=true;
	t->setNumRows(0);
	t->setNumRows(N);
	t->setNumCols(9);
    }
    else
    {
	t=app(this)->newHiddenTable(simulatedTable,simulatedLabel,N, 9);
    }
    
    
    t->setColName(0,"x"); t->setColPlotDesignation(0,Table::X);
    t->setColName(1,"y");t->setColPlotDesignation(1,Table::Y);
    t->setColName(2,"weight"); t->setColPlotDesignation(2,Table::yErr);
    t->setColName(3,"sigma"); t->setColPlotDesignation(3,Table::xErr);
    t->setColName(4,"residues"); t->setColPlotDesignation(4,Table::Y);
    t->setColName(5,"Characteristics");  t->setColPlotDesignation(5,Table::None);
    t->setColName(6,"Conditions"); t->setColPlotDesignation(6,Table::None);
    t->setColName(7,"Parameters");  t->setColPlotDesignation(7,Table::None);
    t->setColName(8,"Values");  t->setColPlotDesignation(8,Table::None);
    
    
    int i;
    for (i=0; i<N;i++)
    {
	t->setText(i,0,QString::number(Q[i],'E',prec));
	t->setText(i,1,QString::number(Isim[i],'E',prec));
	if (uniform ) t->setText(i,2,"---");
	else t->setText(i,2,QString::number(dI[i],'E',prec));
	t->setText(i,3,QString::number(sigma[i],'E',prec));
	if (uniform) t->setText(i,4,"---");
	else t->setText(i,4,QString::number(Idata[i] - Isim[i],'E',prec));
    }
    
    if (t->numRows()<16) t->setNumRows(16);
    if (t->numRows()<p) t->setNumRows(p);
    
    // First Col
    t->setText(0,5,"Fitting Function"); 
    t->setText(0,6,"->   "+function);
    //
    t->setText(1,5,"Number of Parameters");
    t->setText(1,6, "->   "+QString::number(p) ); 
    //
    t->setText(2,5,"Time of Simulation");
    t->setText(2,6,"->   "+textLabelTimeSim->text());
    //
    t->setText(3,5,"x-Range Source");
    if (radioButtonSameQrange->isChecked() ) 
	t->setText(3,6,"->   Same x as Fitting Data");
    else 
	t->setText(3,6,"->   Uniform x");
    //
    t->setText(4,5,"x-min");
    t->setText(4,6,"->   "+lineEditFromQsim->text());
    //
    t->setText(5,5,"x-max");
    t->setText(5,6,"->   "+lineEditToQsim->text());
    //
    t->setText(6,5,"Number Points");
    t->setText(6,6,"->   "+lineEditNumPointsSim->text());
    //
    t->setText(7,5,"Logarithmic Step");
    if (checkBoxLogStep->isChecked() ) 
	t->setText(7,6,"->   Yes");
    else
	t->setText(7,6,"->   No");
    //
    t->setText(8,5,"Dataset");
    t->setText(8,6,"->   "+comboBoxDatasetSim->currentText());
    //
    t->setText(9,5,"SANS mode");
    if (checkBoxSANSsupport->isChecked() ) 
	t->setText(9,6,"->   Yes");
    else
	t->setText(9,6,"->   No");
    //
    t->setText(10,5,"Resolution On");
    if (checkBoxResoSim->isChecked() ) 
	t->setText(10,6,"->   Yes");
    else
	t->setText(10,6,"->   No");
    //
    t->setText(11,5,"Resolution Source");
    t->setText(11,6,"->   "+comboBoxResoSim->currentText());
    //
    t->setText(12,5,"Resolution Integral");
    QString line="->   a "+lineEditAbsErr->text();
    line+=" r "+lineEditRelErr->text();
    line+=" m "+spinBoxIntWorkspase->text();
    line+=" n "+spinBoxIntLimits->text();		 
    line+=" f "+comboBoxResoFunction->currentText();		 
    t->setText(12,6,line);
    //
    t->setText(13,5,"Polydispersity On");
    if (checkBoxPolySim->isChecked() ) 
	t->setText(13,6,"->   Yes");
    else
	t->setText(13,6,"->   No");
    //
    t->setText(14,5,"Polydisperse Parameter");
    t->setText(14,6,"->   "+comboBoxPolySim->currentText());
    //
    t->setText(15,5,"Polydispersity Integral");
    line="->   a "+lineEditAbsErrPoly->text();
    line+=" r "+lineEditRelErrPoly->text();
    line+=" m "+spinBoxIntWorkspasePoly->text();
    line+=" n "+spinBoxIntLimitsPoly->text();		 
    line+=" f "+comboBoxPolyFunction->currentText();		 
    t->setText(15,6,line);
    
    //+++
    for (int pp=0;pp<p;pp++)
    {
	t->setText(pp,7,F_paraList[pp]);
	t->setText(pp,8,tableParaSimulate->text(pp,0));
    };
    
    //+++
    for (int tt=0; tt<t->numCols(); tt++) t->table()->adjustColumn (tt);	    	
    
    //+++  
    
    app(this)->setListViewLabel(t->name(), simulatedLabel);
    
    app(this)->hideWindow(t);
    
    t->notifyChanges();
    
    //+++
    return true;
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++ simulate table :: single interfacef
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// createTable :: (true) generate table :: (false) only calculate chi2, np, tss (2016) 
// source :: (0) simulate interf :: (1) fit interf :: (2) set-to-set interf
// m :: number of curve
// progressShow :: show progress for individual curve
bool fittable::generateSimulatedTable(bool createTable, int source, int m, bool progressShow, QString &simulatedTable, Table *&ttt, int &np, double &chi2, double &TSS)
{
    //++++++++++++++++++++++++++++++++++++++++
    //+++ move marameters of fit table [m] to simulation interface
    //++++++++++++++++++++++++++++++++++++++++
    if (source>0) datasetChangedSim(m);
    
    //++++++++++++++++++++++++++++++++++++++++
    //+ uniform or data defined x-points
    //++++++++++++++++++++++++++++++++++++++++
    bool uniform=radioButtonUniform_Q->isChecked();	
    if(createTable==false) uniform=false; //  (2016)
    
    //++++++++++++++++++++++++++++++++++++++++
    //+ generate vectors:: 
    //++++++++++++++++++++++++++++++++++++++++
    double *Q, *Idata, *Isim, *dI, *sigma;
    
    //+++ number points
    int N;
    
    //++++++++++++++++++++++++++++++++++++++++
    //+++ read data :: in case uniform range
    //++++++++++++++++++++++++++++++++++++++++
    if (uniform) if ( !SetQandIuniform(N, Q, sigma, m) ) return false;
    	
    //++++++++++++++++++++++++++++++++++++++++
    //+++ read data :: in case table defined case
    //++++++++++++++++++++++++++++++++++++++++
    if (!uniform) if ( !SetQandIgivenM (N, Q, Idata, dI, sigma, m ) ) return false;
    
    //+++ Simulated vector
    Isim=new double[N]; // simulated dataset
    if (!uniform) for (int i=0; i<N;i++) Isim[i]=Idata[i];
    
    
    if (uniform) 
    {
	dI =new double[N];
	Idata =new double[N];
	
	for (int i=0; i<N;i++) 
	{
	    Isim[i] =0.0;
	    Idata[i] =0.0;	    
	    dI[i] =1.0;	
	}
	
    }    
    
    //+++ time of calculation ... +++++++++
    QTime dt = QTime::currentTime ();  //++
    //+++++++++++++++++++++++++
    if ( !simulateData( N, Q,  Isim, sigma, progressShow ) ) 
    {
	delete[] Q;
	delete[] Idata;
	delete[] Isim;
	delete[] dI;
	delete[] sigma; 
	return false;
    }
    
    //+++ time of calculation ... ++++++++++++++++++++++++++++++++++++++++++++
    textLabelTimeSim->setText(QString::number(dt.msecsTo(QTime::currentTime()), 'G',3)+" ms");
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
    //++++++++++++++++++++++++++++++++++++++++
    // makeTable:: Q-I-dI-Sigma-Residulas:: Full info ::  
    //++++++++++++++++++++++++++++++++++++++++
    if (createTable)
    {
	if (!simulateDataTable(source,m,simulatedTable,N,Q,Idata,dI,sigma,Isim,ttt) ) 
	{
	    delete[] Q;
	    delete[] Idata;
	    delete[] Isim;
	    delete[] dI;
	    delete[] sigma; 
	    return false;
	}
    }
  
    
    if (!uniform) 
    {
	//+++ 2016 
	//+++  np
	np=0;
	int p=spinBoxPara->value();

	for (int pp=0; pp<p;pp++)
	{
	    QCheckTableItem *itA = (QCheckTableItem *)tablePara->item(pp,3*m+1); // Vary?
	    if (itA->isChecked())  np++;
	}

	//+++
	chi2=0;
	TSS=0;
	double residues=0;
	double data=0;
	double Imean=0;
	for (int n=0; n<N; n++) Imean+=Idata[n];
	Imean/=N;
	
	for (int n=0; n<N; n++)
	{  	
	    residues=Idata[n]-Isim[n];	if (dI[n]!=0) residues/=dI[n]; 
	    data=Idata[n]-Imean; 		if (dI[n]!=0) data/=dI[n]; 
	
	    chi2+=residues*residues;
	    TSS+=data*data;
	}
	
	int prec=spinBoxSignDigits->value();
	
	double R2=0.0;
	if (TSS>0.0) R2=1.0-(chi2*1e6)/(TSS*1e6);
	
	textLabelDofSim->setText(QString::number(N));
	textLabelChi2Sim->setText(QString::number(chi2,'E',prec+4));
	textLabelChi2dofSim->setText(QString::number(chi2/(N-np),'E',prec+4));
	textLabelnpSIM->setText(QString::number(np));
	textLabelR2sim->setText(QString::number(R2,'E',prec+4));

    }
    
    //++++++++++++++++++++++++++++++++++++++++
    //+++ clear memory
    //++++++++++++++++++++++++++++++++++++++++
    delete[] Q;
    delete[] Idata;
    delete[] Isim;
    delete[] dI;
    delete[] sigma;     
    
    return true;
}


//++++++++++++++++++++++++++++++++++++++++
//+++ Add/update fitted/simulated lines  [v. 2016-03-16]
//++++++++++++++++++++++++++++++++++++++++
bool fittable::addGeneralGurve(Graph *g, QString tableName, int m, Table *&table )
{
    int color=(m+17)%16;
    
    curveLayout cl = Graph::initCurveLayout();
    cl.lCol= color;
    cl.symCol=color;
    cl.fillCol=color;	
    cl.lWidth = app(this)->defaultCurveLineWidth+1;
    cl.sSize = app(this)->defaultSymbolSize;
    cl.sType = 0;
    
    int style = Graph::Line;
    int xColIndex, yColIndex;	    
    
    
    findFitDataTableDirect(tableName+"_y", table, xColIndex, yColIndex);
    
    if (g->curvesList().contains(tableName+"_y"))
    {		
	g->updateCurveLayout(g->curvesList().findIndex(tableName+"_y"), &cl);	
	g->replot();
	g->emitModified();  
 
	return true;
    }
    
    g->insertCurve(table,tableName+"_y",style);		    
    
    g->updateCurveLayout(g->curvesList().findIndex(tableName+"_y"), &cl);
    g->replot();
    g->emitModified();  
        
    return true;
}

//***************************************************
//*** NEW :: speedControlReso  :: 29-09-2009
//***************************************************
void fittable::speedControlReso()
{
    if (comboBoxSpeedControlReso->currentItem()==7)
    {
	lineEditAbsErr->setEnabled(TRUE);
	lineEditRelErr->setEnabled(TRUE);
	spinBoxIntWorkspase->setEnabled(TRUE);
	spinBoxIntLimits->setEnabled(TRUE);
    }
    else
    {
	lineEditAbsErr->setText("0");
	lineEditRelErr->setText("0");
	spinBoxIntLimits->setValue(3);
	
	lineEditAbsErr->setEnabled(false);
	lineEditRelErr->setEnabled(false);
	spinBoxIntWorkspase->setEnabled(false);
	spinBoxIntLimits->setEnabled(false);
    }
    
    int speed=comboBoxSpeedControlReso->currentItem();
    
    switch (speed)
    {
    case 0:
	spinBoxIntWorkspase->setValue(5);  // 99.00%
	break;	
    case 1:
	spinBoxIntWorkspase->setValue(6);  // 99.80%
	break;	
    case 2:
	spinBoxIntWorkspase->setValue(7);  // 99.90%
	break;	
    case 3:
	spinBoxIntWorkspase->setValue(8);  // 99.95%
	break;	
    case 4:
	spinBoxIntWorkspase->setValue(15);  // 99.98%	
	break;	
    case 5:
	spinBoxIntWorkspase->setValue(20);  // 99.99%	
	break;	
    case 6:
	spinBoxIntWorkspase->setValue(50);  // >99.99%
	break;	
    }	
    
    if (speed==7) textLabelIntWork->setText("Max. Number of points");
    else textLabelIntWork->setText("Number of points");
    
    if (comboBoxResoFunction->currentItem()==1)
    {
	textLabelSigma->hide();
	spinBoxIntLimits->hide();
    }
    else
    {
	textLabelSigma->show();
	spinBoxIntLimits->show();
    }
}

//***************************************************
//*** NEW :: speedControlPoly  :: 29-09-2009
//***************************************************
void fittable::speedControlPoly()
{
    if (comboBoxSpeedControlPoly->currentItem()==7)
    {
	lineEditAbsErrPoly->setEnabled(TRUE);
	lineEditRelErrPoly->setEnabled(TRUE);
	spinBoxIntWorkspasePoly->setEnabled(TRUE);
	spinBoxIntLimitsPoly->setEnabled(TRUE);
    }
    else
    {
	lineEditAbsErrPoly->setText("0");
	lineEditRelErrPoly->setText("0");
	spinBoxIntLimitsPoly->setValue(3);
	
	lineEditAbsErrPoly->setEnabled(false);
	lineEditRelErrPoly->setEnabled(false);
	spinBoxIntWorkspasePoly->setEnabled(false);
	spinBoxIntLimitsPoly->setEnabled(false);
    }
    
    int speed=comboBoxSpeedControlPoly->currentItem();
    
    switch (speed)
    {
    case 0:
	spinBoxIntWorkspasePoly->setValue(5);  // 99.00%
	break;	
    case 1:
	spinBoxIntWorkspasePoly->setValue(6);  // 99.80%
	break;	
    case 2:
	spinBoxIntWorkspasePoly->setValue(7);  // 99.90%
	break;	
    case 3:
	spinBoxIntWorkspasePoly->setValue(8);  // 99.95%
	break;	
    case 4:
	spinBoxIntWorkspasePoly->setValue(15);  // 99.98%	
	break;	
    case 5:
	spinBoxIntWorkspasePoly->setValue(20);  // 99.99%	
	break;	
    case 6:
	spinBoxIntWorkspasePoly->setValue(50);  // >99.99%
	break;	
    }
    
    if (speed==7) textLabelIntWorkPoly->setText("Max. Number of points");
    else textLabelIntWorkPoly->setText("Number of points");
    
    if (comboBoxPolyFunction->currentItem()>=4)
    {
	textLabelSigmaNpoly->hide();
	spinBoxIntLimitsPoly->hide();
    }
    else
    {
	textLabelSigmaNpoly->show();
	spinBoxIntLimitsPoly->show();
    }
}

//*******************************************
//+++ plot fit result: with SANS support
//*******************************************
bool fittable::chi2m(int m, int &Nres, double &sumChi2, double &sumChi2Norm, double &R2 )
{ 
    int prec=spinBoxSignDigits->value();
    
    R2=1; 
    sumChi2=0.0;
    sumChi2Norm=0.0;
    Nres=0;
    //++++++++++++++++++++++++++++++++++++++++
    //+ generate vectors:: 
    //++++++++++++++++++++++++++++++++++++++++
    double *Q, *Idata, *Isim, *dI, *sigma;
    
    //+++ number points
    int N;
    
    //++++++++++++++++++++++++++++++++++++++++
    //+++ read data :: in case table defined case
    //++++++++++++++++++++++++++++++++++++++++
    if ( !SetQandIgivenM ( N, Q, Idata, dI, sigma, m ) ) return false;
    
    //+++ Simulated vector
    Isim=new double[N]; // simulated dataset
    
    //++++++++++++++++++++++++++++++++++++++++
    //+++ Sign. Digits :: Q, ...
    //++++++++++++++++++++++++++++++++++++++++
    int i;
    for (i=0; i<N;i++) 
    {
	Q[i] 	= round2prec(Q[i], prec); // QString::number(Q[i],'E',prec-1).toDouble();
	//+++
	Idata[i]	= round2prec(Idata[i], prec); // QString::number(Idata[i],'E',prec-1).toDouble();	
	//+++
	Isim[i]	= Idata[i];
	//+++
	dI[i]	= round2prec(dI[i], prec); //QString::number(dI[i],'E',prec-1).toDouble();
	//+++
	sigma[i]	= round2prec(sigma[i], prec); //QString::number(sigma[i],'E',prec-1).toDouble();
    }
    
    
    if ( !simulateData( N, Q,  Isim, sigma, false ) ) return false;
    
    double Imean=0;
    for (i=0; i<N;i++) Imean+=Idata[i];
    
    if (N>0) Imean/=N;
    
    double ssl=0;
	
    //++++++++++++++++++++++++++++++++++++++++
    //+++ Sign. Digits :: Isim
    //++++++++++++++++++++++++++++++++++++++++
    for (i=0; i<N;i++) 
    {
	sumChi2+=(Isim[i] - Idata[i])*(Isim[i] - Idata[i])/dI[i]/dI[i];
	ssl+=(Imean - Idata[i])*(Imean - Idata[i])/dI[i]/dI[i];
	sumChi2Norm+=1/dI[i]/dI[i];
    }
    
    if (ssl>0) R2=1-sumChi2/ssl;
    Nres=N;
    
    //++++++++++++++++++++++++++++++++++++++++
    //+++ clear memory
    //++++++++++++++++++++++++++++++++++++++++
    delete[] Q;
    delete[] Idata; 
    delete[] Isim; 
    delete[] dI; 
    delete[] sigma;
    
    return true;
    
}

//*******************************************
//+++ chi2()
//*******************************************
bool fittable::chi2()
{ 
    int prec=spinBoxSignDigits->value();
    
    //+++
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value();
    int pM=p*M;
    
    //+++
    if (p==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Select Function"));
	return false;
    }
    
    int mm;
    
    
    //+++ number of adjustable parameters
    int np=0;
    for (int pp=0; pp<p;pp++)
    {	
	QCheckTableItem *itS = (QCheckTableItem *)tablePara->item(pp,0); // Share?
	QCheckTableItem *itA0 = (QCheckTableItem *)tablePara->item(pp,1); // Vary?
	if (itA0->isChecked()) 
	{
	    np++;
	}
	
	for (mm=1; mm<M;mm++)
	{
	    QCheckTableItem *itA = (QCheckTableItem *)tablePara->item(pp,3*mm+1); // Vary?
	    if (!itS->isChecked())
	    {
		if (itA->isChecked()) 
		{
		    np++;
		}
		
	    }
	    
	}
    } 
    
    //+++
    if (np==0) 
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("No adjustible parameters (to calculate chi2)"));
	return false;
    }
    
    
    int N=0;
    double chi2=0;
    double chi2weight=0;
    double sum=0;
    double sumWeight=0;
    double R2=1;
    
    int Nres=0;
    double  sumChi2, sumChi2Norm, sumR2;
    
    
    for (mm=0; mm<M; mm++) 
    {
	datasetChangedSim(mm);
	if ( !chi2m(mm, Nres, sumChi2, sumChi2Norm,sumR2) ) return false;
	N+=Nres;
	chi2+=sumChi2;
	chi2weight+=sumChi2Norm;
	R2*=sumR2;
    }
    
//    chi2=chi2/ (N-np)/chi2weight*N;
    chi2=chi2/ (N-np);
    
    textLabelChi->setText(QString::number(chi2,'E',prec+4));
    
    //+++R2
    //    R2=pow(fabs(R2),1/M);
    
    
    textLabelR2->setText(QString::number(R2,'E',prec+4));
    //+++ Delete 
    
    return true;
}



//*******************************************
// fit: readDataForFitAllM() :: new 29.09.09
//*******************************************
// all info from data-tab
bool  fittable::readDataForFitAllM
	(int &Ntotal, int *&numberM, int *&numberSigma,double *&QQ, double *&II, double *&dII, double *&sigmaS)
{
    //+++
    int M=spinBoxNumberCurvesToFit->value(); 	//+++ Number of Curves
    
    int mm;
    
    Ntotal=0;
    
    //+++ Number of real points per curve
    for (mm=0;mm<M;mm++)
    {
	//++++++++++++++++++++++++++++++++++++++++
	//+ generate vectors:: 
	//++++++++++++++++++++++++++++++++++++++++
	double *Q, *Idata, *dI, *sigma;
	
	//+++ number points
	int N;
	
	//++++++++++++++++++++++++++++++++++++++++
	//+++ read data :: in case table defined case
	//++++++++++++++++++++++++++++++++++++++++
	if ( !SetQandIgivenM( N, Q, Idata, dI, sigma, mm ) ) return false;
	if (N<2) return false;
	Ntotal+=N;
	delete[] Q; 
	delete[] Idata; 
	delete[] dI; 
	delete[] sigma; 
    }
    
    
    numberM=new int[M];
    // +++
    QQ=new double[Ntotal];
    II=new double[Ntotal];
    dII=new double[Ntotal];
    sigmaS=new double[Ntotal];
    
    Ntotal=0;
    //+++ Number of real points per curve
    for (mm=0;mm<M;mm++)
    {
	//++++++++++++++++++++++++++++++++++++++++
	//+ generate vectors:: 
	//++++++++++++++++++++++++++++++++++++++++
	double *Q, *Idata, *dI, *sigma;
	
	//+++ number points
	int N;
	
	//++++++++++++++++++++++++++++++++++++++++
	//+++ read data :: in case table defined case
	//++++++++++++++++++++++++++++++++++++++++
	if ( !SetQandIgivenM ( N, Q, Idata, dI, sigma, mm ) ) return false;
	if (N<2) return false;
	
	//++++++++++++++++++++++++++++++++++++++++
	//+++ Sign. Digits :: Q, ...
	//++++++++++++++++++++++++++++++++++++++++
	
	for (int i=0; i<N;i++) 
	{
	    QQ[i+Ntotal] 		= Q[i]; 
	    //+++
	    II[i+Ntotal]		= Idata[i]; 
	    //+++
	    dII[i+Ntotal]		= dI[i];
	    //+++
	    sigmaS[i+Ntotal]	= sigma[i];
	    //+++
	}
	Ntotal+=N;
	numberM[mm]=N;
    }
    
    numberSigma=new int[M];
    
    QString currentInstrument=comboBoxInstrument->currentText();	    
    
    
    //+++ Polydispersity Checks
    for (mm=0;mm<M;mm++)
    {	
	if (checkBoxSANSsupport->isChecked() && currentInstrument.contains("SANS") )
	{
	    
	    QCheckTableItem *itS = (QCheckTableItem *)tableCurves->item(6,2*mm);
	    
	    if (itS->isChecked())
	    {
		QComboTableItem *polyPara =(QComboTableItem*)tableCurves->item (6, 2*mm+1);
		numberSigma[mm]= polyPara->currentItem() ;	    
	    }
	    else
	    {
		numberSigma[mm]=-1;
	    }
	}
	else
	{
	    numberSigma[mm]=-1;
	    
	}
	
    }   
    return true;
}

//*******************************************
// fit: sansFit() :: new 29.09.09
//*******************************************
bool  fittable::sansFit()
{
    //+++ Limits     
    chekLimits();
    chekLimitsAndFittedParameters();
    
    //+++ Progress dialog
    int progressIter=0;
    QProgressDialog *progress;
    
    //+++ Algorithm
    QString algorithm=comboBoxFitMethod->currentText();
    
    //+++ 
    bool showProgress=true;
    if (algorithm.contains("[GenMin]") || setToSetProgressControl) showProgress=false;
    
    //+++ Progress dialog
    if (showProgress)
    {
	progress=new QProgressDialog( "Starting |\n\n\n\n\n\n", "Abort FIT", spinBoxMaxIter->value()+3,
				      this, "Maximal Number of Iterations"+spinBoxMaxIter->text()+". Progress:", TRUE );
	progress->setMinimumDuration(0);
	
	//+++ Start +++  1
	progressIter++;
	progress->setProgress( progressIter );    
    }
    
    //+++
    int mm, np, i, pp;
    int nn=0, nnn=0, nnnn=0;
    size_t pFit;
    
    //+++
    int M=spinBoxNumberCurvesToFit->value(); 	//+++ Number of Curves
    int p=spinBoxPara->value();		//+++ Number of Parameters per Curve
    int pM=p*M;				//+++ Total Number of Parameters
    
    //+++ Polydispersity vector
    int *numberSigma;  
    
    int N;
    int *numberM;
    double *Q, *I, *dI, *sigma;
    
    
    //+++ 29-09-09 NEW reading interface
    if ( !readDataForFitAllM (N, numberM, numberSigma, Q, I, dI, sigma) ) return false;
    
    
    //+++ Number of Adjustible parameters && initial paramerers
    gsl_vector_int *paramsControl= gsl_vector_int_alloc(pM);
    gsl_vector       *params= gsl_vector_alloc(pM);
    
    //+++ check Funcktion Selection: DLL
    if (p==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Select Function"));
	return false;
    }
    
    
    if (showProgress)
    {
	//+++ Data 2
	progressIter++;
	progress->setLabelText("Started | Data Loading |\n\n\n\n\n\n");
	progress->setProgress( progressIter );    
    }
    
    //+++ Parameters && Sharing && Varying 
    np=0;
    for (pp=0; pp<p;pp++)
    {
	QCheckTableItem *itS = (QCheckTableItem *)tablePara->item(pp,0); // Share?
	QCheckTableItem *itA0 = (QCheckTableItem *)tablePara->item(pp,1); // Vary?
	if (itA0->isChecked()) 
	{
	    gsl_vector_int_set(paramsControl, M*pp, 0);
	    np++;
	}
	else
	{
	    gsl_vector_int_set(paramsControl, M*pp, 1);
	}
	
	gsl_vector_set(params,M*pp, tablePara->text(pp,2).toDouble());
	
	for (mm=1; mm<M;mm++)
	{
	    QCheckTableItem *itA = (QCheckTableItem *)tablePara->item(pp,3*mm+1); // Vary?
	    if (itS->isChecked())
	    {
		itA->setChecked(false);
		gsl_vector_int_set(paramsControl, M*pp+mm, 2);
		tablePara->setText(pp,3*mm+2,tablePara->text(pp,2));
	    } 
	    else
	    {
		if (itA->isChecked()) 
		{
		    gsl_vector_int_set(paramsControl, M*pp+mm, 0);
		    np++;
		}
		else
		{
		    gsl_vector_int_set(paramsControl, M*pp+mm, 1);
		}
	    }
	    gsl_vector_set(params,M*pp+mm, tablePara->text(pp,3*mm+2).toDouble());
	}
	//+++
	gsl_vector_set(F_para, pp, tablePara->text(pp,2).toDouble());
    }   
    
    //+++
    if (np==0) 
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("No adjustible parameters"));
	if (showProgress)
	{	
	    progress->cancel();
	}	
	return false;
    }
    
    //+++ Adjustible vector...
    gsl_vector *paraAdjust=gsl_vector_alloc(np);
    
    //+++ Adjustible vector Limits...
    gsl_vector *limitLeft=gsl_vector_alloc(np);
    gsl_vector *limitRight=gsl_vector_alloc(np);
    
    
    pFit=0;    
    for (i=0; i<pM; i++)
    {
	if (gsl_vector_int_get(paramsControl,i)==0) 
	{
	    gsl_vector_set(paraAdjust,pFit,gsl_vector_get(params,i));
	    pFit++;
	}
    }
    
    
    pFit=0;    
    //+++ 
    for (pp=0; pp<p;pp++) 
    {
	for (mm=0; mm<M;mm++)
	{
	    QCheckTableItem *itA0 = (QCheckTableItem *)tablePara->item(pp,3*mm+1); // Vary?	
	    
	    if (itA0->isChecked()) 
	    {
		gsl_vector_set(limitLeft,pFit, tableControl->text(pp,0).toDouble() );
		gsl_vector_set(limitRight,pFit, tableControl->text(pp,4).toDouble() );
		pFit++;
	    }
	}
    }
    
    
    
    //+++ 
    bool polyYN=false;
    int polyFunction=comboBoxPolyFunction->currentItem();
    //+++ 
    bool beforeFit=false;
    bool afterFit=false;
    bool beforeIter=false;
    bool afterIter=false;
    
    //+++ 23.09.2011	
    int currentFirstPoint=0;
    int currentLastPoint=0;
    int currentPoint=0;
    
    int prec=spinBoxSignDigits->value();
        
    //+++ ,tableName,tableColNames,tableColDestinations,mTable
    std::string tableName="no-matrix";
    std::string *tableColNames; 
    int *tableColDestinations; 
    gsl_matrix * mTable;
    
    functionT paraT={F_para, Q, I, sigma, currentFirstPoint, currentLastPoint, currentPoint, polyYN, polyFunction, beforeFit, afterFit, beforeIter, afterIter, 1.0, 1.0, 1.0, 0, prec,tableName,tableColNames,tableColDestinations,mTable};
    
    //+++
    F.params=&paraT;
    
    //+++
    double absErrReso=lineEditAbsErr->text().toDouble();
    double relErrReso=lineEditRelErr->text().toDouble();
    int intWorkspaseReso=spinBoxIntWorkspase->value();
    int numberSigmaReso=spinBoxIntLimits->value();
    int func_reso=comboBoxResoFunction->currentItem();
    
    QString currentInstrument=comboBoxInstrument->currentText();
    if ( currentInstrument.contains("Back") ) func_reso+=10;
    
    double absErrPoly=lineEditAbsErrPoly->text().toDouble();
    double relErrPoly=lineEditRelErrPoly->text().toDouble();
    int intWorkspasePoly=spinBoxIntWorkspasePoly->value();
    int numberSigmaPoly=spinBoxIntLimitsPoly->value();
    int func_poly=comboBoxPolyFunction->currentItem();     
        
    //+++
    sizetNumbers sizetNumbers={N,M,p,np};
    sansData sansData={Q,I,dI,sigma};
    integralControl resoIntegralControl={absErrReso,relErrReso, intWorkspaseReso, numberSigmaReso, func_reso};
    integralControl polyIntegralControl={absErrPoly,relErrPoly, intWorkspasePoly, numberSigmaPoly, func_poly};
    
    
    fitDataSANSpoly para2={&sizetNumbers, &sansData, numberM, params, paramsControl, &F, &resoIntegralControl, numberSigma, &polyIntegralControl,limitLeft,limitRight};
    
    //+++ maximum number of iterations
    int d_max_iterations=spinBoxMaxIter->value();
    
    //+++ 
    double d_tolerance=lineEditTolerance->text().toDouble();
    double absError=lineEditToleranceAbs->text().toDouble();
    //+++
    if (d_tolerance<0) d_tolerance=0;
    
    //+++
    gsl_matrix *covar = gsl_matrix_alloc (np,np);
    
    //+++ 
    size_t iter = 0;
    int status;
    
    //+++ Time of Fit Run
    QTime dt = QTime::currentTime ();
    
    if (showProgress)
    {
	//+++ Ready 3
	progressIter++;
	progress->setLabelText("Started | Loaded | Fitting |\n\n\n\n\n\n");
	progress->setProgress( progressIter );    
    }
    //+++
    gsl_set_error_handler_off();
    
    double chi;
    double dof = N - np;
    
    
    if (algorithm.contains("[GenMin]") )    
    {
	genome_count=spinBoxGenomeCount->value();
	generations=spinBoxMaxNumberGenerations->value();
	selection_rate=lineEditSelectionRate->text().toDouble();
	mutation_rate=lineEditMutationRate->text().toDouble();
	random_seed=spinBoxRandomSeed->value();
	
	int problem_dimension;
	double	*tempx,*tempg;	
	
	srand(random_seed);
	srand(random_seed); //+++ srand48
	
	problem_dimension=np;
	
	tempx=new double[problem_dimension];
	tempg=new double[problem_dimension];
	
	Problem myproblem(problem_dimension);
	
	myproblem.YN2D(false);
	myproblem.sansSupportYN(true); // SANS support
	myproblem.setSANSfitP(para2);
	myproblem.dof=dof;
	
	DataG	 L,R;
	L.resize(problem_dimension);
	R.resize(problem_dimension);
	
	double leftFactor=lineEditLeftMargin->text().toDouble();
	leftFactor=fabs(leftFactor);
	
	double rightFactor=lineEditRightMargin->text().toDouble();
	rightFactor=fabs(rightFactor);
	
	double currentParameter, currentLeftLimit, currentRightLimit;
	
	for(int i=0;i<problem_dimension;i++)
	{
	    currentParameter=gsl_vector_get(paraAdjust,i);
	    //+++
	    currentLeftLimit=gsl_vector_get(limitLeft,i);
	    currentRightLimit=gsl_vector_get(limitRight,i);
	    
	    if (currentLeftLimit>-1.0E308)
	    {
		L[i]=currentLeftLimit;
	    }
	    else
	    {
		if (leftFactor<=1) leftFactor=2;
		
		if (currentParameter>0)
		{	
		    L[i]=currentParameter/leftFactor;
		}
		else if  (currentParameter<0)
		{
		    L[i]=currentParameter*leftFactor;
		}
		else
		{
		    L[i]=-leftFactor;
		}
	    }
	    
	    if (currentRightLimit<1.0E308)
	    {
		R[i]=currentRightLimit;
	    }
	    else
	    {
		if (rightFactor<=1) rightFactor=2;
		
		if (currentParameter>0)
		{	
		    R[i]=currentParameter*rightFactor;
		}
		else if  (currentParameter<0)
		{
		    R[i]=currentParameter/rightFactor;
		} 
		else
		{
		    R[i]=rightFactor;
		}
	    }
	}
	
	myproblem.setLeftMargin(L);
	myproblem.setRightMargin(R);
	
	myproblem.fln.f = &function_fmPoly;
	myproblem.fln.df =&function_dfmPoly;
	myproblem.fln.fdf = &function_fdfmPoly;
	myproblem.fln.n = N;
	myproblem.fln.p = np;
	myproblem.fln.params = &para2;   
	

	
	GenMin opt(&myproblem);
	
	//
	opt.Solve();
	
	
	DataG x;
	double y;
	x.resize(problem_dimension);
	opt.getMinimum(x,y);
	
	
	opt.localSearchGSL(x,prec,5,0,0);
	opt.localSearch(x);
	opt.localSearchGSL(x,prec,d_max_iterations,d_tolerance,absError);


	printf("X = [");
	for(int i=0;i<problem_dimension;i++)
	{
	    printf(" %lg ",x[i]);	
	}
	printf("] \nchi^2 =%lg\n",y/dof);
	printf("FUNCTION CALLS =%6d\nGRADIENT CALLS=%6d\n\n",
	       myproblem.fevals,myproblem.gevals);
	delete[] tempx;
	delete[] tempg;
	
	
	
	int digits=spinBoxSignDigits->value()-1;
	//+++ Parameters to parameter Table
	int npnp=0;
	for (pp=0; pp<p; pp++) for(mm=0; mm<M; mm++)    
	{
	    if (gsl_vector_int_get(paramsControl,M*pp+mm) == 0) 
	    {
		tablePara->setText(pp,3*mm+2, QString::number(x[npnp],'G',digits+1));
		//tablePara->setText(pp,3*mm+3, QString::number(c*ERR2(npnp),'E',digits));
		tablePara->setText(pp,3*mm+3, "---");
		gsl_vector_set(params,M*pp+mm,x[npnp]);
		npnp++;
	    }
	    else if (gsl_vector_int_get(paramsControl,M*pp+mm) == 2)
	    {
		tablePara->setText(pp,3*mm+2, tablePara->text(pp,2));
		tablePara->setText(pp,3*mm+3, "---");
	    }
	    else
	    {
		tablePara->setText(pp,3*mm+3, "---");
	    }			
	}
    }    
    else if (algorithm.contains("Nelder-Mead Simplex"))    
    {	
	gsl_multimin_function f;
	
	f.f = &function_dmPoly;
	f.n = np;
	f.params = &para2;  
	
	const gsl_multimin_fminimizer_type *TT;
	
	if (algorithm.contains("nmsimplex2rand"))
	    TT=gsl_multimin_fminimizer_nmsimplex2rand;
	else if (algorithm.contains("nmsimplex2"))
	    TT=gsl_multimin_fminimizer_nmsimplex2;
	else 
	    TT=gsl_multimin_fminimizer_nmsimplex;
	
	
	gsl_vector *ss = gsl_vector_alloc (np);
	
	//+++ set all step sizes to 1 can be increased to converge faster
	gsl_vector_set_all (ss,1.0);
	
	gsl_multimin_fminimizer *s_min = gsl_multimin_fminimizer_alloc (TT, np);
	
	
	//	return false;	
	status = gsl_multimin_fminimizer_set(s_min, &f, paraAdjust, ss);
	
	int scaleProgress=0;
	
	double size;
	iter=0;
	QString st;
	double chi2local;
	do
	{
	    if (showProgress)
	    {
		//+++ Fit Started 1
		progressIter++;		
		
		if (iter>0)
		{
		    chi2local=s_min->fval/dof;
		    st="";
		    st="Started | Loaded | Fitting > Iterations\n\n";
		    st=st+algorithm+"\n\n";
		    st=st+" # \t\t\t\t\t\t\t Stopping Criterion \t\t\t\t\t\t\t chi^2 \n";
		    st=st+QString::number(iter)+"[<"+QString::number(d_max_iterations)+"] \t\t\t "+QString::number(size, 'E',prec)+" [<"+QString::number(d_tolerance)+"] \t\t\t "+QString::number(chi2local,'E',prec+4)+"\n\n";
		    progress->setLabelText(st);
		}
		progress->setProgress( progressIter );
		if ( progress->wasCanceled() ) 
		{
		    break;
		}
	    }
	    
	    
	    iter++;
	    
	    
	    status = gsl_multimin_fminimizer_iterate (s_min);
	    
	    size=gsl_multimin_fminimizer_size (s_min);	    
	    
	    status = gsl_multimin_test_size (size, d_tolerance);
	    
	    if (chi2local==0.0) break;
	}
	while (status == GSL_CONTINUE && (int)iter < d_max_iterations);
	
	
	double tmp;
	for (int pp=0; pp<np;pp++)
	{
	    tmp= gsl_vector_get(s_min->x, pp);
	    
	    if ( tmp < gsl_vector_get(limitLeft,pp) ) 
		gsl_vector_set(paraAdjust,pp,gsl_vector_get(limitLeft,pp)); 
	    else if ( tmp>gsl_vector_get(limitRight,pp) ) 
		gsl_vector_set(paraAdjust,pp,gsl_vector_get(limitRight,pp)); 
	    else
		gsl_vector_set(paraAdjust,pp,tmp);    
	}
	
	
	
	gsl_matrix *J = gsl_matrix_alloc(N, np); 
	//function_dfmPoly(s_min->x,&para2,J);
	function_dfmPoly(paraAdjust,&para2,J);
	gsl_multifit_covar (J,0.0, covar);  
	
#define FIT2(i) gsl_vector_get(paraAdjust, i)
#define ERR2(i) sqrt(gsl_matrix_get(covar,i,i))   
	
	QStringList activeParaNames;

	chi = sqrt(s_min->fval);
	dof = N - np;
	double c = 1;
	c=chi / sqrt(dof);
	
	int digits=spinBoxSignDigits->value()-1;
	
	int npnp=0;
	
	for (pp=0; pp<p; pp++) for(mm=0; mm<M; mm++) 	 
	{
	    if (gsl_vector_int_get(paramsControl,M*pp+mm) == 0) 
	    {
		tablePara->setText(pp,3*mm+2, QString::number(FIT2(npnp),'G',digits+1));
		tablePara->setText(pp,3*mm+3, QString::number(c*ERR2(npnp),'G',digits+1));
		
		activeParaNames<<tablePara->verticalHeader()->label(pp)+QString::number( ( mm > 0 ? mm+1 : 1 ) ); 
		gsl_vector_set(params,M*pp+mm,FIT2(npnp));
		npnp++;
	    }
	    else if (gsl_vector_int_get(paramsControl,M*pp+mm) == 2)
	    {
		tablePara->setText(pp,3*mm+2, tablePara->text(pp,2));
		tablePara->setText(pp,3*mm+3, "---");
	    }
	    else
	    {
		tablePara->setText(pp,3*mm+3, "---");
	    }			
	}
	
	
	//+++ Covariant Matrix and errors
	if (checkBoxCovar->isChecked() ) 
	{
	    double chiWeight2=0;
	    for(nn=0; nn<N; nn++) if (dI[nn]!=0.0) chiWeight2+=1/dI[nn]/dI[nn]; else chiWeight2++;
	    chiWeight2=chiWeight2/N;
	    
	    
	    QString info=covarMatrix(N, np, chi, chiWeight2, activeParaNames, covar, paraAdjust);
	    
	    makeNote(info, "fitCurve-"+comboBoxFunction->currentText()+"-statistics", "TableFit :: statistics info ");	
	}
	
	gsl_vector_free(ss);
	gsl_matrix_free(J);
	gsl_multimin_fminimizer_free(s_min);
    }    
    else
    {	
	const gsl_multifit_fdfsolver_type *Tln;
	gsl_multifit_fdfsolver *sln;
	gsl_multifit_function_fdf fln;
	
	fln.f = &function_fmPoly;
	fln.df = &function_dfmPoly;
	fln.fdf = &function_fdfmPoly;
	fln.n = N;
	fln.p = np;
	fln.params = &para2;  
	
	if (algorithm.contains("Unscaled"))      
	    Tln = gsl_multifit_fdfsolver_lmder;
	else
	    if (algorithm.contains("Scaled"))      
		Tln = gsl_multifit_fdfsolver_lmsder;
	else
	    return false;
	
	bool deltaStop=false;
	if (algorithm.contains("Delta")) deltaStop=true;
	
	
	sln = gsl_multifit_fdfsolver_alloc(Tln, N,np);
	
	status=gsl_multifit_fdfsolver_set(sln, &fln, paraAdjust);
	
	iter=0;
	int scaleProgress=0;
	
	//+++
	double ssize=0;
	QString st;
	double tmp;
	gsl_vector *vec=gsl_vector_alloc(np);
	double chi2local;
	
	do
	{
	    if (showProgress)
	    {
		//+++ Fit Started 1
		progressIter++;
		
		if (iter>0)
		{
		    ssize=0;
		    if (deltaStop)
		    {
			for (int vvv=0;vvv<np;vvv++) 
			{
			    tmp=fabs(gsl_vector_get(sln->dx, vvv))-d_tolerance*fabs(gsl_vector_get(sln->x, vvv));
			    if (tmp>ssize) ssize=tmp; 
			}
		    }
		    else
		    {
			for (int vvv=0;vvv<np;vvv++) 
			{
			    ssize+=fabs(gsl_vector_get(vec, vvv));
			}	
		    }	
		    
		    chi2local=pow(gsl_blas_dnrm2(sln->f),2)/dof; 
		    st="";
		    st="Started | Loaded | Fiiting > Iterations\n\n";
		    st=st+algorithm+"\n\n";
		    st=st+" # \t\t\t\t\t\t\t Stopping Criterion \t\t\t\t\t\t\t chi^2 \n";
		    st=st+QString::number(iter)+"[<"+QString::number(d_max_iterations)+"] \t\t\t "+QString::number(ssize, 'E',prec)+" [<"+QString::number(absError)+"] \t\t\t "+QString::number(chi2local,'E',prec+4)+"\n\n";
		    
		    progress->setLabelText(st);
		}
		
		progress->setProgress( progressIter );
		if ( progress->wasCanceled() ) 
		{
		    progress->cancel();
		    break;
		}
	    }
	    
	    iter++;
	    
	    
	    status = gsl_multifit_fdfsolver_iterate (sln);
	    
	    if (deltaStop)
		status = gsl_multifit_test_delta (sln->dx, sln->x, absError, d_tolerance);
	    else
	    {
		gsl_multifit_gradient(sln->J, sln->f,vec);
		status = gsl_multifit_test_gradient (vec, absError);	
	    }
	    
	    if (chi2local==0.0) break;  
	}
	while (status == GSL_CONTINUE && (int)iter < d_max_iterations);
	
	for (int pp=0; pp<np;pp++)
	{
	    tmp= gsl_vector_get(sln->x, pp);
	    
	    if ( tmp < gsl_vector_get(limitLeft,pp) ) 
		gsl_vector_set(paraAdjust,pp,gsl_vector_get(limitLeft,pp)); 
	    else if ( tmp>gsl_vector_get(limitRight,pp) ) 
		gsl_vector_set(paraAdjust,pp,gsl_vector_get(limitRight,pp)); 
	    else
		gsl_vector_set(paraAdjust,pp,tmp);    
	}	
	
	status=gsl_multifit_covar (sln->J, 0.0, covar);
	
#define FIT(i) gsl_vector_get(paraAdjust, i)
#define ERR(i) sqrt(gsl_matrix_get(covar,i,i))
	
	QStringList activeParaNames;
	
	chi =gsl_blas_dnrm2(sln->f);
	dof = N - np;
	
	double c =chi / sqrt(dof);
	
	int digits=spinBoxSignDigits->value()-1;
	
	int npnp=0;
	for (pp=0; pp<p; pp++) for(mm=0; mm<M; mm++)    
	{
	    if (gsl_vector_int_get(paramsControl,M*pp+mm) == 0) 
	    {
		tablePara->setText(pp,3*mm+2, QString::number(FIT(npnp),'G',digits+1));
		tablePara->setText(pp,3*mm+3, QString::number(c*ERR(npnp),'G',digits+1));
		gsl_vector_set(params,M*pp+mm,FIT(npnp));
		
		activeParaNames<<tablePara->verticalHeader()->label(pp)+QString::number( ( mm > 0 ? mm+1 : 1 ) ); 
		npnp++;
	    }
	    else if (gsl_vector_int_get(paramsControl,M*pp+mm) == 2)
	    {
		tablePara->setText(pp,3*mm+2, tablePara->text(pp,2));
		tablePara->setText(pp,3*mm+3, "---");
	    }
	    else
	    {
		tablePara->setText(pp,3*mm+3, "---");
	    }			
	}
		
	//+++ Covariant Matrix and errors
	if (checkBoxCovar->isChecked() ) 
	{
	    double chiWeight2=0;
	    for(nn=0; nn<N; nn++) if (dI[nn]!=0.0) chiWeight2+=1/dI[nn]/dI[nn]; else chiWeight2++;
	    chiWeight2=chiWeight2/N;
	    
	    
	    QString info=covarMatrix(N, np, chi, chiWeight2, activeParaNames, covar, paraAdjust);
	    
	    makeNote(info, "fitCurve-"+comboBoxFunction->currentText()+"-statistics", "TableFit :: statistics info ");	
	}	
	gsl_multifit_fdfsolver_free (sln);	
    }
    
    //+++ Delete  Variables
    delete[] numberSigma;
    delete[] numberM;
    delete[] Q;
    delete[] I;
    delete[] dI;
    delete[] sigma;
    
    
    gsl_vector_free(params); 
    gsl_vector_int_free(paramsControl);
    gsl_vector_free(paraAdjust);
    gsl_matrix_free(covar); 
    
    //+++Time After Fit Run
    textLabelTime->setText(QString::number(dt.msecsTo(QTime::currentTime()), 'G',3)+" ms");
    
    if (showProgress && progress) delete progress;
    
    return true;
}


void fittable::checkConstrains(int m)
{ 
    int M=spinBoxNumberCurvesToFit->value();
    int P=spinBoxPara->value();
    int digits=spinBoxSignDigits->value()-1;
    
    if (m<-1) return;
    if (m>=M) return;
    
    for (int pp=0; pp<P; pp++)
    {	
	if (m>-1)
	    tablePara->setText(pp,3*m+2, QString::number(gsl_vector_get(F_para,pp),'G',digits+1));
	else
	    tableParaSimulate->setText(pp,0,QString::number(gsl_vector_get(F_para,pp),'G',digits+1));
    }
}



//+++++FUNCTION::check Table Existence ++++++++++++++++++++++++
bool fittable::checkTableExistence(QString tableName, Table* &w)
{
    int i;
    bool exist=false;
    
    QWidgetList* tableList=app(this)->tableList();
    //+++
    for (i=0;i<(int)tableList->count();i++)  
    {
	if (tableList->at(i) && tableList->at(i)->name()==tableName) 
	{
	    w=(Table *)tableList->at(i);
	    exist=true;
	}
    }
    return exist;
}

//+++++FUNCTION::check Table Existence ++++++++++++++++++++++++
bool fittable::checkTableExistence(QString tableName)
{
    int i;
    bool exist=false;
    
    QWidgetList* tableList=app(this)->tableList();
    //+++
    for (i=0;i<(int)tableList->count();i++)  
    {
	if (tableList->at(i) && tableList->at(i)->name()==tableName) 
	{
	    exist=true;
	}
    }
    return exist;
}

//*******************************************
//+++  new-daDan:: find Table List By Label
//*******************************************
void fittable::findTableListByLabel(QString winLabel,QStringList  &list)
{
    int mm;
    list.clear();
    //+++
    QWidgetList* windows=app(this)->windowsList();
    //+++
    for (mm=0; mm < (int)windows->count(); mm++ )
    {
	if ( windows->at(mm)->isA("Table")  )
	{
	    Table* ttt=(Table*) windows->at(mm);
	    if (ttt->windowLabel().contains(winLabel) )
		list<<windows->at(mm)->name();
	}
    }
}



void fittable::readSettingsTable()
{
    
    QStringList list;
    findTableListByLabel("FIT1D::Settings::Table",list);
    
    if (list.count()==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("No table with lablel FIT1D::Settings::Table was found!"));
	return;
    }
    
    bool ok;
    QString table = QInputDialog::getItem(
	    "QtiKWS", "Select Settings-Table:", list, 0, FALSE, &ok,
	    this );
    if ( !ok )return;
    
    Table *w;
    if (!checkTableExistence(table,w) ) return;
    
    QStringList parameters;
    parameters.clear();
    
    for (int i=0; i<w->numRows(); i++) parameters<<w->text(i,0);
    
    if (parameters.count()==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Check Settings-Table!"));
	return;
    }
    
    QString s;
    
    //+++ Function::Folder
    if (parameters.findIndex("Function::Folder")>=0) 
    {
	libPath=w->text(parameters.findIndex("Function::Folder"),1).remove(" <").stripWhiteSpace();
	scanGroup();
	listBoxGroup->setSelected(0,TRUE);
	groupFunctions("ALL");
    } 
    else return;
    
    //+++ Function::Name
    if (parameters.findIndex("Function::Name")>=0) 
    {
	s=w->text(parameters.findIndex("Function::Name"),1).remove(" <").stripWhiteSpace();
	
	if (listBoxFunctions->index(listBoxFunctions->findItem(s,Qt::ExactMatch))<0) return;
	
	listBoxFunctions->setSelected(listBoxFunctions->findItem(s,Qt::ExactMatch), true);
	
	openDLL(s);
    }
    else return;
    
    //+++ Function::SANS::Support
    if (parameters.findIndex("Function::SANS::Support")>=0) 
    {
	s=w->text(parameters.findIndex("Function::SANS::Support"),1).remove(" <").stripWhiteSpace();
	
	if (s.contains("yes")) checkBoxSANSsupport->setChecked(true);
	else checkBoxSANSsupport->setChecked(false);
	SANSsupportYN();
	SANSsupportYN(); // TEST
    }
    
    //+++ Function::Parameters::Number
    if (parameters.findIndex("Function::Parameters::Number")>=0) 
    {
	s=w->text(parameters.findIndex("Function::Parameters::Number"),1).remove(" <").stripWhiteSpace();
	
	if (spinBoxPara->value()!=s.toInt())
	{
	    QMessageBox::warning(this,tr("QtiKWS"),
				 tr("Check Function :: Number of parameters!"));
	    return;
	}
    }
    else return;
    
    //+++ Function::Global::Fit
    if (parameters.findIndex("Function::Global::Fit")>=0) 
    {
	s=w->text(parameters.findIndex("Function::Global::Fit"),1).remove(" <").stripWhiteSpace();
	
	if (s.contains("yes")) 
	{
	    checkBoxMultiData->setChecked(true);
	    spinBoxNumberCurvesToFit->setEnabled(true);
	}
	else 
	{
	    checkBoxMultiData->setChecked(false);
	    spinBoxNumberCurvesToFit->setEnabled(false);
	    spinBoxNumberCurvesToFit->setValue(1);
	}
    }
    else return;
    
    //+++ Function::Global::Fit::Number
    if (parameters.findIndex("Function::Global::Fit::Number")>=0) 
    {
	s=w->text(parameters.findIndex("Function::Global::Fit::Number"),1).remove(" <").stripWhiteSpace();
	
	if (s.toInt()>0 && checkBoxMultiData->isChecked())
	{
	    spinBoxNumberCurvesToFit->setValue(s.toInt());
	}
    }
    
    slotStackFitNext();
    
    QStringList lst, allCurves;
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value();
    //+++ Session::Data::Datasets
    if (parameters.findIndex("Session::Data::Datasets")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Data::Datasets"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	allCurves=app(this)->columnsList(Table::Y);
	
	for (int mm=0;mm<M;mm++)
	{
	    QComboTableItem *curves =(QComboTableItem*)tableCurves->item (0, 2*mm+1);
	    
	    if (allCurves.findIndex(lst[mm])>=0)
	    {
		curves->setCurrentItem(allCurves.findIndex(lst[mm]));
		tableCurvechanged(0, 2*mm+1);
	    }
	}
	
    }
    
    
    //+++ Session::Data::N
    if (parameters.findIndex("Session::Data::N")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Data::N"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{
	    QComboTableItem *curves =(QComboTableItem*)tableCurves->item (1, 2*mm);
	    
	    if (lst[mm]=="N") curves->setCurrentItem(0);
	    else curves->setCurrentItem(1);
	    tableCurvechanged(1, 2*mm);
	}
	
    }
    
    //+++ Session::Data::NN
    if (parameters.findIndex("Session::Data::NN")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Data::NN"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{
	    tableCurves->setText(1, 2*mm+1, lst[mm]);
	}
	
    }    
    
    //+++ Session::Data::From::Use
    if (parameters.findIndex("Session::Data::From::Use")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Data::From::Use"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{
	    QCheckTableItem *item = (QCheckTableItem*)tableCurves->item (2,2*mm);
	    if (lst[mm]=="1") item->setChecked(true);
	    else item->setChecked(false);
	    tableCurvechanged(2, 2*mm);
	}
	
    }    
    
    //+++ Session::Data::From::Number
    if (parameters.findIndex("Session::Data::From::Number")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Data::From::Number"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{
	    tableCurves->setText(2, 2*mm+1, lst[mm]);
	    tableCurvechanged(2, 2*mm+1);
	}
    }    
    
    //+++ Session::Data::To::Use
    if (parameters.findIndex("Session::Data::To::Use")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Data::To::Use"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{
	    QCheckTableItem *item = (QCheckTableItem*)tableCurves->item (3,2*mm);
	    if (lst[mm]=="1") item->setChecked(true);
	    else item->setChecked(false);
	    tableCurvechanged(3, 2*mm);
	}
	
    }    
    
    //+++ Session::Data::To::Number
    if (parameters.findIndex("Session::Data::To::Number")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Data::To::Number"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{
	    tableCurves->setText(3, 2*mm+1, lst[mm]);
	    tableCurvechanged(3, 2*mm+1);
	}
    }    
    
    //+++ Session::Weighting::Use
    if (parameters.findIndex("Session::Weighting::Use")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Weighting::Use"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{
	    QCheckTableItem *item = (QCheckTableItem*)tableCurves->item (4,2*mm);
	    if (lst[mm]=="1") item->setChecked(true);
	    else item->setChecked(false);
	}
    }    
    
    //+++ Session::Weighting::Dataset
    if (parameters.findIndex("Session::Weighting::Dataset")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Weighting::Dataset"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{
	    allCurves.clear();
	    allCurves=app(this)->columnsList(Table::yErr);
	    QString tableName=tableCurves->text(0,2*mm+1);
	    tableName=tableName.left(tableName.find("_"));
	    allCurves=allCurves.grep(tableName);
	    
	    QComboTableItem *curves =(QComboTableItem*)tableCurves->item (4, 2*mm+1);
	    
	    if (allCurves.findIndex(lst[mm])>=0)
	    {
		curves->setCurrentItem(allCurves.findIndex(lst[mm]));
	    }
	}
    }
    
    //+++ Session::Limits::Left
    if (parameters.findIndex("Session::Limits::Left")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Limits::Left"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int pp=0; pp<gsl_min(p,lst.count());pp++)
	{
	    tableControl->setText(pp,0,lst[pp]);
	}
    }
    
    //+++ Session::Limits::Right
    if (parameters.findIndex("Session::Limits::Right")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Limits::Right"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int pp=0; pp<gsl_min(p,lst.count());pp++)
	{
	    tableControl->setText(pp,4,lst[pp]);
	}
    }
    
    //+++ Session::Limits::Scale::Left
    if (parameters.findIndex("Session::Limits::Scale::Left")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Limits::Scale::Left"),1).remove(" <").stripWhiteSpace();
	lineEditLeftMargin->setText(s);
    }
    
    //+++ Session::Limits::Scale::Right
    if (parameters.findIndex("Session::Limits::Scale::Right")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Limits::Scale::Right"),1).remove(" <").stripWhiteSpace();
	lineEditRightMargin->setText(s);
    }
    
    if (checkBoxSANSsupport->isChecked())
    {
	//+++ Session::Resolution::Use
	if (parameters.findIndex("Session::Resolution::Use")>=0) 
	{
	    s=w->text(parameters.findIndex("Session::Resolution::Use"),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    
	    for (int mm=0;mm<M;mm++)
	    {
		QCheckTableItem *item = (QCheckTableItem*)tableCurves->item (5,2*mm);
		if (lst[mm]=="1") item->setChecked(true);
		else item->setChecked(false);
	    }
	}    
	
	//+++ Session::Resolution::Datasets
	if (parameters.findIndex("Session::Resolution::Datasets")>=0) 
	{
	    s=w->text(parameters.findIndex("Session::Resolution::Datasets"),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    
	    for (int mm=0;mm<M;mm++)
	    {
		allCurves.clear();
		allCurves=app(this)->columnsList(Table::xErr);
		QString tableName=tableCurves->text(0,2*mm+1);
		tableName=tableName.left(tableName.find("_"));
		allCurves=allCurves.grep(tableName);
		
		QComboTableItem *curves =(QComboTableItem*)tableCurves->item (5, 2*mm+1);
		
		if (allCurves.findIndex(lst[mm])>=0)
		{
		    curves->setCurrentItem(allCurves.findIndex(lst[mm]));
		}
	    }
	}
	
	//+++ Session::Polydispersity::Use
	if (parameters.findIndex("Session::Polydispersity::Use")>=0) 
	{
	    s=w->text(parameters.findIndex("Session::Polydispersity::Use"),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    
	    for (int mm=0;mm<M;mm++)
	    {
		QCheckTableItem *item = (QCheckTableItem*)tableCurves->item (6,2*mm);
		if (lst[mm]=="1") item->setChecked(true);
		else item->setChecked(false);
	    }
	}    
	
	//+++ Session::Polydispersity::Datasets
	if (parameters.findIndex("Session::Polydispersity::Datasets")>=0) 
	{
	    s=w->text(parameters.findIndex("Session::Polydispersity::Datasets"),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    allCurves.clear();
	    allCurves=F_paraList;
	    
	    for (int mm=0;mm<M;mm++)
	    {
		QComboTableItem *curves =(QComboTableItem*)tableCurves->item (6, 2*mm+1);
		
		if (allCurves.findIndex(lst[mm])>=0)
		{
		    curves->setCurrentItem(allCurves.findIndex(lst[mm]));
		}
	    }
	}
	
	//+++ Session::Options::Reso
	if (parameters.findIndex("Session::Options::Reso")>=0) 
	{
	    s=w->text(parameters.findIndex("Session::Options::Reso"),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    //+++
	    comboBoxResoFunction->setCurrentItem(lst[0].toInt());
	    //+++
	    comboBoxSpeedControlReso->setCurrentItem(lst[1].toInt());
	    //+++
	    lineEditAbsErr->setText(lst[2]);
	    //+++
	    lineEditRelErr->setText(lst[3]);
	    //+++
	    spinBoxIntWorkspase->setValue(lst[4].toInt());
	    //+++
	    spinBoxIntLimits->setValue(lst[5].toInt());
	    
	}
	//+++ Session::Options::Poly
	if (parameters.findIndex("Session::Options::Poly")>=0) 
	{
	    s=w->text(parameters.findIndex("Session::Options::Poly"),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    //+++
	    comboBoxPolyFunction->setCurrentItem(lst[0].toInt());
	    //+++
	    comboBoxSpeedControlPoly->setCurrentItem(lst[1].toInt());
	    //+++
	    lineEditAbsErrPoly->setText(lst[2]);
	    //+++
	    lineEditRelErrPoly->setText(lst[3]);
	    //+++
	    spinBoxIntWorkspasePoly->setValue(lst[4].toInt());
	    //+++
	    spinBoxIntLimitsPoly->setValue(lst[5].toInt());
	    
	}
    }
    
    //+++ Session::Options::Fit::Control
    if (parameters.findIndex("Session::Options::Fit::Control")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Options::Fit::Control"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	int value=lst[0].toInt();
	if (value >-1 && value<=6) comboBoxFitMethod->setCurrentItem(value);
	//+++
	spinBoxMaxIter->setValue(lst[1].toInt());
	//+++
	lineEditTolerance->setText(lst[2]);
	//+++
	lineEditToleranceAbs->setText(lst[3]);	
	//+++
	spinBoxSignDigits->setValue(lst[4].toInt());
	//+++
	value=lst[5].toInt();
	if (value >-1 && value<=6) comboBoxWeightingMethod->setCurrentItem(value);
	//+++
	if (lst[6]=="1") checkBoxCovar->setChecked(true); else checkBoxCovar->setChecked(false);
	//+++
	lineEditWA->setText(lst[7]);
	//+++
	lineEditWB->setText(lst[8]);
	//+++
	lineEditWC->setText(lst[9]);
	//+++
	lineEditWXMAX->setText(lst[10]);
	//
	spinBoxGenomeCount->setValue(lst[11].toInt());
	//
	spinBoxMaxNumberGenerations->setValue(lst[12].toInt());
	//
	lineEditSelectionRate->setText(lst[13]);
	//
	lineEditMutationRate->setText(lst[14]);
	//
	spinBoxRandomSeed->setValue(lst[15].toInt());   
    }
    algorithmSelected();
    weightChanged();
    
    //+++ Session::Options::Instrument::Reso
    if (parameters.findIndex("Session::Options::Instrument::Reso")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Options::Instrument::Reso"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	if (lst.count()==6) 
	{
	    int value=lst[0].toInt();
	    if (value >-1 && value<=4) comboBoxResoFunction->setCurrentItem(value);
	    //+++
	    value=lst[1].toInt();
	    if (value >-1 && value<=8) comboBoxSpeedControlReso->setCurrentItem(value);
	    //+++
	    lineEditAbsErr->setText(lst[2]);	
	    //+++
	    lineEditRelErr->setText(lst[3]);		
	    //+++
	    spinBoxIntWorkspase->setValue(lst[4].toInt());
	    //+++
	    spinBoxIntLimits->setValue(lst[5].toInt());
	}
    }
    speedControlReso();
    
    //+++ Session::Options::Instrument::Poly
    if (parameters.findIndex("Session::Options::Instrument::Poly")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Options::Instrument::Poly"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	if (lst.count()==6) 
	{
	    int value=lst[0].toInt();
	    if (value >-1 && value<=4) comboBoxPolyFunction->setCurrentItem(value);
	    //+++
	    value=lst[1].toInt();
	    if (value >-1 && value<=8) comboBoxSpeedControlPoly->setCurrentItem(value);
	    //+++
	    lineEditAbsErrPoly->setText(lst[2]);	
	    //+++
	    lineEditRelErrPoly->setText(lst[3]);		
	    //+++
	    spinBoxIntWorkspasePoly->setValue(lst[4].toInt());
	    //+++
	    spinBoxIntLimitsPoly->setValue(lst[5].toInt());
	}
    }
    speedControlPoly();
  
    
    
    if (checkBoxMultiData->isChecked())
    {
	//+++ Session::Parameters::Shared
	if (parameters.findIndex("Session::Parameters::Shared")>=0) 
	{
	    s=w->text(parameters.findIndex("Session::Parameters::Shared"),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    
	    for (int pp=0;pp<p;pp++)
	    {
		QCheckTableItem *active = (QCheckTableItem *)tablePara->item(pp,0);
		
		if (lst[pp]=="1") active->setChecked(true); else active->setChecked(false);
	    }
	}
    }
    
    for (int pp=0;pp<p;pp++)
    {
	QString uselName="Session::Parameters::Use::"+QString::number(pp+1);
	
	//+++ useName
	if (parameters.findIndex(uselName)>=0) 
	{
	    s=w->text(parameters.findIndex(uselName),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    
	    for (int mm=0; mm<M;mm++)
	    {
		QCheckTableItem *active = (QCheckTableItem *)tablePara->item(pp,3*mm+1);			
		if (lst[mm]=="1") active->setChecked(true); else active->setChecked(false)		;
	    }
	}
	
	QString cellName="Session::Parameters::Values::"+QString::number(pp+1);
	
	//+++ useName
	if (parameters.findIndex(cellName)>=0) 
	{
	    s=w->text(parameters.findIndex(cellName),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    
	    for (int mm=0; mm<M;mm++)
	    {
		tablePara->setText(pp,3*mm+2, lst[mm]);
	    }
	}
    }
    
    QString uselName="Session::Parameters::Limit::Left";
    if (parameters.findIndex(uselName)>=0) 
    {
	s=w->text(parameters.findIndex(uselName),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int pp=0;pp<p;pp++)
	{
	    tableControl->setText(pp,0,lst[pp]);
	}
	lineEditLeftMargin->setText(lst[p]);
    }
    
    uselName="Session::Parameters::Limit::Right";
    if (parameters.findIndex(uselName)>=0) 
    {
	s=w->text(parameters.findIndex(uselName),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int pp=0;pp<p;pp++)
	{
	    tableControl->setText(pp,4,lst[pp]);
	}
	lineEditRightMargin->setText(lst[p]);
    }
    
    //+++ Session::Parameters::Errors
    if (parameters.findIndex("Session::Parameters::Errors")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Parameters::Errors"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	int iii=0;
	for (int i=0; i<M;i++) for (int pp=0;pp<p;pp++) 
	{
	    tablePara->setText(pp,3*i+3,lst[iii]);
	    iii++;
	}
    } 
    
    //+++ Session::Chi2
    if (parameters.findIndex("Session::Chi2")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Chi2"),1).remove(" <").stripWhiteSpace();
	textLabelChi->setText(s);
    } 
    //+++ Session::R2
    if (parameters.findIndex("Session::R2")>=0) 
    {
	s=w->text(parameters.findIndex("Session::R2"),1).remove(" <").stripWhiteSpace();
	textLabelR2->setText(s);
    } 
    //+++ Session::Time
    if (parameters.findIndex("Session::Time")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Time"),1).remove(" <").stripWhiteSpace();
	textLabelTime->setText(s);
    } 
        
    //+++ Simulate::Color
    if (parameters.findIndex("Simulate::Color")>=0) 
    {
	s=w->text(parameters.findIndex("Simulate::Color"),1).remove(" <").stripWhiteSpace();
	comboBoxColor->setCurrentItem(s.toInt());
    }  
    
    //+++ Simulate::Statistics
    if (parameters.findIndex("Simulate::Statistics")>=0) 
    {
	s=w->text(parameters.findIndex("Simulate::Statistics"),1).remove(" <").stripWhiteSpace();
	if (s.contains("yes"))
	{
	    checkBoxCovar->setChecked(true);
	}
	else
	{
	    checkBoxCovar->setChecked(false);
	}
    }  
    
    //+++ Simulate::SaveSession
    if (parameters.findIndex("Simulate::SaveSession")>=0) 
    {
	s=w->text(parameters.findIndex("Simulate::SaveSession"),1).remove(" <").stripWhiteSpace();
	if (s.contains("yes"))
	{
	    checkBoxSaveSession->setChecked(true);
	}
	else
	{
	    checkBoxSaveSession->setChecked(false);
	}
    }   
        
    //+++ Simulate::Indexing
    if (parameters.findIndex("Simulate::Indexing")>=0) 
    {
	s=w->text(parameters.findIndex("Simulate::Indexing"),1).remove(" <").stripWhiteSpace();
	if (s.contains("yes"))
	{
	    checkBoxSimIndexing->setChecked(true);
	}
	else
	{
	    checkBoxSimIndexing->setChecked(false);
	}
    }   

    //+++ Simulate::Uniform
    if (parameters.findIndex("Simulate::Uniform")>=0) 
    {
	s=w->text(parameters.findIndex("Simulate::Uniform"),1).remove(" <").stripWhiteSpace();
	if (s.contains("yes"))
	{
	    radioButtonUniform_Q->setChecked(true);
	}
	else
	{
	    radioButtonUniform_Q->setChecked(false);
	}
    }  
    
    if (radioButtonUniform_Q->isChecked())
    {
	//+++ Simulate::Uniform::Parameters
	if (parameters.findIndex("Simulate::Uniform::Parameters")>=0) 
	{
	    s=w->text(parameters.findIndex("Simulate::Uniform::Parameters"),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    
	    lineEditFromQsim->setText(lst[0]);
	    //+++
	    lineEditToQsim->setText(lst[1]);
	    //+++
	    lineEditNumPointsSim->setText(lst[2]);
	    //+++
	    if (lst[3]=="1") checkBoxLogStep->setChecked(true); else checkBoxLogStep->setChecked(false);
	}
    }
}


void fittable::horizHeaderCurves( int col )
{
    tableCurves->adjustColumn (col);
    
    
    if (int( col/2)*2!=col)
    {
	Graph *g;
    
	if(!findActiveGraph(g)){QMessageBox::critical(this,tr("QtiKWS"), tr("Activate first GRAPH with data to fit !!!")); return;};
    
	if (g->curves()==0) {QMessageBox::critical(this,tr("QtiKWS"), tr("Graph is EMPTY !!!")); return;};
	
	QString curveName=g->selectedCurveTitle();
    
	double startID,endID;
    
	bool selectedRange=true;
    
	if (curveName=="") selectedRange=false;
    
	if ( selectedRange)
	{
	    curveName=g->selectedCurveTitle();
	    startID=g->selectedXStartValue();
	    endID=g->selectedXEndValue();
	
	    if (startID>endID)
	    {
		double tmp=endID;
		endID=startID;
		startID=tmp;
	    }	
	
	    if (startID==endID) {QMessageBox::critical(this,tr("QtiKWS"), tr("min=max !!!")); return; };
	}
	else 
	{
	    curveName=g->curvesList()[0];
	}
	
	
	tableCurves->setText(0,col-1,curveName); tableCurvechanged(0,col-1); tableCurvechanged(0,col);tableCurves->setText(0,col-1,"");	
    
       
	if (selectedRange)
	{
	    QComboTableItem *iQ =(QComboTableItem*)tableCurves->item (1, col-1); iQ->setCurrentItem(1); tableCurvechanged(1,col-1);
	    QCheckTableItem *cbImin = (QCheckTableItem*)tableCurves->item(2,col-1);cbImin->setChecked(true);tableCurves->setText(2,col,QString::number(startID,'g',10));
	    QCheckTableItem *cbImax = (QCheckTableItem*)tableCurves->item(3,col-1);cbImax->setChecked(true);tableCurves->setText(3,col,QString::number(endID,'g',10));
	}
	else
	{
	    QComboTableItem *iQ =(QComboTableItem*)tableCurves->item (1, col-1); iQ->setCurrentItem(0); tableCurvechanged(1,col-1);
	}
	
    }
    
	
}


void fittable::readOutputToResLog()
{
    QFile f("toResLog.log");
    QTextStream t( &f );
    if (!f.open(IO_ReadOnly)) 
    {
	f.close();
	return;
    }
    
    QString s;
    
    s="\n\nFunction \""+textLabelFfunc->text()+"\" sent debugging data:\n\n";
    
    while (!t.atEnd())
    {
	s+=t.readLine()+"\n";
    }
    f.close();
    
    s+="\n\n";
    
    toResLog(s);
    
    QDir d;
    d.refresh ();
    d.remove("toResLog.log");
}


void fittable::readOutputToTable(myWidget* w)
{
    QFile f("toResLog.log");
    QTextStream tt( &f );
    if (!f.open(IO_ReadOnly)) 
    {
	
	return;
    }
    
    QString s, colNames, tableName, comment, actions, plotCurve;    
    int skeapLines=0;
    comment="toResLog.log";
    actions="";
    plotCurve="";
    
    bool headerNamesYN=false;
    bool tableNameYN=false;
    bool commentYN=false;
    bool overwriteExistingTableYN=false;  
    bool actionsYN=false;
    bool plotYN=false;
    
    for (int i=0;i<8;i++)
    {
	if (tt.atEnd()) break;
	s=tt.readLine();
	
	if (s.left(1)!="#") break;
	skeapLines++;
	
	if (s.left(11)=="#ColNames: ") 
	{
	    headerNamesYN=true;
	    colNames=s.remove("#ColNames: ");
	}
	else if (s.left(12)=="#TableName: ") 
	{
	    tableNameYN=true;
	    tableName=s.remove("#TableName: ");
	}
	else if (s.left(25)=="#OverwriteExistingTable: ") 
	{
	    if (s.contains("yes") || s.contains("Yes") || s.contains("YES"))
		overwriteExistingTableYN=true;
	}
	else if (s.left(10)=="#Comment: ") 
	{
	    commentYN=true;
	    comment=s.remove("#Comment: ");
	}
	else if (s.left(10)=="#Actions: ") 
	{
	    actionsYN=true;
	    actions=s.remove("#Actions: ");
	}
	else if (s.left(7)=="#Plot: ") 
	{
	    plotYN=true;
	    plotCurve=s.remove("#Plot: ");
	}
    }
    
    
    f.close();
    
    // --00--  Headers names & Destinations
    QStringList lst, lstCols, lstDesignation; 
    if (headerNamesYN)
    {
	lst=lst.split(" ",colNames,false);
	
	for (int i=0; i<lst.count(); i++)
	{
	    if (lst[i].contains("[x]")) 
	    {
		lstCols<<lst[i].remove("[x]");
		lstDesignation<<"1";
		continue;
	    }
	    if (lst[i].contains("[y]")) 
	    {
		lstCols<<lst[i].remove("[y]");
		lstDesignation<<"2";
		continue;
	    }
	    if (lst[i].contains("[z]")) 
	    {
		lstCols<<lst[i].remove("[z]");
		lstDesignation<<"3";
		continue;
	    }	
	    if (lst[i].contains("[xErr]")) 
	    {
		lstCols<<lst[i].remove("[xErr]");
		lstDesignation<<"4";
		continue;
	    }
	    if (lst[i].contains("[yErr]")) 
	    {
		lstCols<<lst[i].remove("[yErr]");
		lstDesignation<<"5";
		continue;
	    }
	    lstCols<<lst[i];
	    lstDesignation<<"0";
	}
    }
    
    // --01--  Read ASCII file to TableX    
    Table* t = app(this)->newTable ( "toResLog.log", " ", skeapLines, true, false, false);
    
    // --02--  Genarate Unique Name of Table or Delete old table
    if (actionsYN==true)
    {
	if (tableNameYN)
	{
	    if (actions.contains("generateUniqueName"))
		tableName=app(this)->generateUniqueName(tableName+"-");	
	}
    }
    else
    {
	if (tableNameYN) 
	{
	    removeTables(tableName);
	    
	}
    }
    
    // --03-- Rename table
    if (tableNameYN) 
    {
	QString oldName=t->name();
	app(this)->renameWindow(t, tableName);
	app(this)->renameListViewItem(oldName,tableName);
	app(this)->modifiedProject(t);
    }
    
    // --04-- Hide Table    
    if (actionsYN==true)
    {
	if (actions.contains("hideTable"))
	{
	    app(this)->hideActiveWindow();
	}
    }
    
    // --05--  Change col names and designations
    if (headerNamesYN)
    {
	for(int i=0;i<lst.count();i++) 
	{
	    t->setColName(i,lstCols[i]);
	    if (lstDesignation[i]=="0") 
		t->setColPlotDesignation(i,Table::None);
	    else if (lstDesignation[i]=="1") 
		t->setColPlotDesignation(i,Table::X);
	    else if (lstDesignation[i]=="2") 
		t->setColPlotDesignation(i,Table::Y);
	    else if (lstDesignation[i]=="3") 
		t->setColPlotDesignation(i,Table::Z);
	    else if (lstDesignation[i]=="4") 
		t->setColPlotDesignation(i,Table::xErr);
	    else if (lstDesignation[i]=="5") 
		t->setColPlotDesignation(i,Table::yErr);
	}
    }
    
    // --06-- Plot Data, label Graph    
    if (plotYN)
    {
	
	lst.clear();
	lst=lst.split(" ",plotCurve,false);
	// activeGraphNumber: #4
	int activeGraphNumber=0;
	if (lst.count()>=5) activeGraphNumber=lst[4].toInt();		
	// templateFile: #5
	QString templateFile="no";
	if (lst.count()>=6) templateFile=lst[5];	    
	
	Graph *g;
	QString currentPlotLabel="";
	bool graphExist=findGraphInActivePlot(w, g, activeGraphNumber,currentPlotLabel); 
	s="Template:"+app(this)->qtiKwsPath+"/templates/"+templateFile;
	if ( currentPlotLabel != s) 
	{
	    graphExist=false;
	}
	
	
	if (!graphExist) 
	{
	    app(this)->openTemplate(app(this)->qtiKwsPath+"/templates/"+templateFile, true);
	    graphExist=findGraphInActivePlot(( myWidget * ) app(this)->ws->activeWindow(), g, activeGraphNumber,currentPlotLabel); 
	}
	
	
	if ( graphExist) 
	{
	    
	    if (lst.count()>=4)
	    {
		plotTable(g,t, t->name(), lst[0].toInt(), lst[1].toInt(),lst[2].toInt(), lst[3].toInt());
		s=t->name();
		s+= "_";
		if (actions.contains("labelGraph"))
		{
		    g->setAxisTitle(0,t->colName(0).replace(s,""));
		    g->setAxisTitle(1,t->colName(1).replace(s,""));
		}
	    }
	    else if (lst.count()==3)
	    {
		plotTable(g,t, t->name(), lst[0].toInt(), lst[1].toInt(),-1, lst[2].toInt());
		if (actions.contains("labelGraph"))
		{
		    g->setAxisTitle(0,t->colName(0).replace(s,""));
		    g->setAxisTitle(1,t->colName(1).replace(s,""));
		}
	    }
	    else if (lst.count()==2)
	    {
		plotTable(g,t, t->name(), lst[0].toInt(), lst[1].toInt(),-1, -1);
		if (actions.contains("labelGraph"))
		{
		    g->setAxisTitle(0,t->colName(0).replace(s,""));
		    g->setAxisTitle(1,t->colName(1).replace(s,""));
		}
	    }
	}
    }
    
    // --07-- Change comment of table
    t->setCaptionPolicy ( myWidget::Both );
    app(this)->setListViewLabel ( t->name(),  comment );
    
    // --08-- Adjust col width
    for (int tt=0; tt<t->numCols(); tt++) 
    {
	t->table()->adjustColumn (tt);
	t->table()->setColumnWidth(tt, t->table()->columnWidth(tt)+10); 
    }
}

void fittable::readOutputToTable()
{
    myWidget *w;
    readOutputToTable(w);
}


void fittable::updateDatasets()
{
    //+++ Initiation of multi-Set Tables
    int M=spinBoxNumberCurvesToFit->value();
    
    
    //+++ Set Data-Sets List
    for(int mm=0;mm<M;mm++)		
    {
	//+++ Data sets selection ComboBox
	
	QComboTableItem *xxx =(QComboTableItem*)tableCurves->item (0, 2*mm+1);
	QString oldYcol=xxx->currentText();
	
	QStringList lst=app(this)->columnsList(Table::Y);
	
	QStringList lstNew;
	
	for(int i=0;i<lst.count();i++) if (lst[i].length()>14 &&lst[i].right(9)=="_residues" && ( lst[i].left(14)=="simulatedCurve"|| lst[i].left(8)=="fitCurve")) continue; else lstNew<<lst[i];
	
	
	xxx->setStringList(lstNew);
	if (oldYcol!="") xxx->setCurrentItem(oldYcol);
	else
	{
	    tableCurvechanged(0, 2*mm+1 );
	}
    }
}

void fittable::algorithmSelected()
{
    QString newAlgorithm=comboBoxFitMethod->currentText();
    
    if (newAlgorithm.contains("Simplex"))
    {
	buttonGroupGenMin->hide();
	buttonGroupSimplex->show();
	
	buttonGroupSimplex->setTitle("Simplex Options");
	
	lineEditToleranceAbs->hide();
	textLabel2_2->hide();
    }
    else if (newAlgorithm.contains("Levenberg"))
    {
	buttonGroupGenMin->hide();
	buttonGroupSimplex->show();
	
	buttonGroupSimplex->setTitle("Levenberg-Marquardt Options");
	
	lineEditToleranceAbs->show();
	textLabel2_2->show(); 
    }
    else  if (newAlgorithm.contains("[GenMin]"))
    {
	buttonGroupGenMin->show();
	buttonGroupSimplex->hide();
	
	lineEditToleranceAbs->hide();
	textLabel2_2->hide();
	
    }
    
}

void fittable::weightChanged()
{ 
    int currentWeight=comboBoxWeightingMethod->currentItem();
    textLabelWA->hide();
    lineEditWA->hide();
    textLabelWB->hide();
    lineEditWB->hide();
    textLabelWC->hide();
    lineEditWC->hide();
    textLabelWXMAX->hide();
    lineEditWXMAX->hide();
    
    switch ( currentWeight )    {
	
    case 4: 
	textLabelWA->show();
	lineEditWA->show();
	textLabelWB->hide();
	lineEditWB->hide();
	textLabelWC->hide();
	lineEditWC->hide();
	textLabelWXMAX->hide();
	lineEditWXMAX->hide();
	break;
    case 5: 
	textLabelWA->show();
	lineEditWA->show();
	textLabelWB->show();
	lineEditWB->show();
	textLabelWC->show();
	lineEditWC->show();
	textLabelWXMAX->hide();
	lineEditWXMAX->hide();
	break;	
    case 6: 
	textLabelWA->show();
	lineEditWA->show();
	textLabelWB->hide();
	lineEditWB->hide();
	textLabelWC->show();
	lineEditWC->show();
	textLabelWXMAX->show();
	lineEditWXMAX->show();	
	break;	
	defaulf:
	    textLabelWA->hide();
	    lineEditWA->hide();
	    textLabelWB->hide();
	    lineEditWB->hide();
	    textLabelWC->hide();
	    lineEditWC->hide();
	    textLabelWXMAX->hide();
	    lineEditWXMAX->hide();
	    break;
	    
	}
}


void fittable::initParametersBeforeFit()
{    
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value();
    int digits=spinBoxSignDigits->value()-1;
    
    //+++
    if (p==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Select Function"));
	return;
    }
    
    
    int N;
    int *numberM;
    int *numberSigma;  
    double *Q, *I, *dI, *sigma;
    
    
    if ( !readDataForFitAllM (N, numberM, numberSigma, Q, I, dI, sigma) ) 
    {
	Q=new double[1];Q[0]=0.0;
	I=new double[1];I[0]=0.0;    
	sigma=new double[1];Q[0]=0.0;    
	numberM=new int[1];numberM[0]=0;
	
    }
    
    
    //+++ 
    bool polyYN=false;
    int polyFunction=comboBoxPolyFunction->currentItem();
    //+++ 
    bool beforeFit=true;
    bool afterFit=false;
    bool beforeIter=false;
    bool afterIter=false;
    
    int currentFirstPoint=0;
    int currentLastPoint=0;
    int currentPoint=0;
    
    //+++ ,tableName,tableColNames,tableColDestinations,mTable
    std::string tableName="no-matrix";
    std::string *tableColNames; 
    int *tableColDestinations; 
    gsl_matrix * mTable;
    
    for (int mm=0;mm<M;mm++)
    {	
	for (int pp=0;pp<p;pp++) gsl_vector_set(F_para,pp,tablePara->text(pp, 3*mm+2).toDouble());
	if (mm>0) currentFirstPoint=numberM[mm-1];
	currentLastPoint=numberM[mm]-1;
	currentPoint=currentFirstPoint;
	
	int prec=spinBoxSignDigits->value();
	
	functionT paraT={F_para, Q, I, sigma, currentFirstPoint, currentLastPoint, currentPoint, polyYN, polyFunction, beforeFit, afterFit, beforeIter, afterIter, 1.0, 1.0, 1.0, 0, prec ,tableName,tableColNames,tableColDestinations,mTable};
	
	//+++
	F.params=&paraT;
	
	GSL_FN_EVAL(&F,1.0);
	
	for (int pp=0;pp<p;pp++) tablePara->setText(pp, 3*mm+2,QString::number(gsl_vector_get(F_para,pp),'G',digits+1));
	
    }  
    delete[] Q; 
    delete[] I; 
    delete[] dI; 
    delete[] sigma;  
}

void fittable::initParametersAfterFit()
{    
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value();
    int digits=spinBoxSignDigits->value()-1;
    
    //+++
    if (p==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Select Function"));
	return;
    }
    
    int N;
    int *numberM;
    int *numberSigma;      
    double *Q, *I, *dI, *sigma;
    
    if ( !readDataForFitAllM (N, numberM, numberSigma, Q, I, dI, sigma) ) return;
    //+++ 
    bool polyYN=false;
    int polyFunction=comboBoxPolyFunction->currentItem();
    //+++ 
    bool beforeFit=false;
    bool afterFit=true;
    bool beforeIter=false;
    bool afterIter=false;
    
    int currentFirstPoint=0;
    int currentLastPoint=0;
    int currentPoint=0;
    
    //+++
    size_t iMstart=0, iMfinish=0;
        
    //+++ ,tableName,tableColNames,tableColDestinations,mTable
    std::string tableName="no-matrix";
    std::string *tableColNames=0; 
    int *tableColDestinations=0; 
    gsl_matrix * mTable=0;
    
    for (int mm=0;mm<M;mm++)
    {	
	for (int pp=0;pp<p;pp++) gsl_vector_set(F_para,pp,tablePara->text(pp, 3*mm+2).toDouble());
	
	if (mm==0) 
	{
	    iMstart=0;
	    iMfinish=numberM[0];
	}
	else 
	{
	    iMfinish+=numberM[mm];
	    iMstart=iMfinish-numberM[mm];
	}
	
	currentLastPoint=numberM[mm]-1;
	currentPoint=currentFirstPoint;
	
	int prec=spinBoxSignDigits->value();
	
	functionT paraT={F_para, Q, I, sigma, currentFirstPoint, currentLastPoint, currentPoint, polyYN, polyFunction, beforeFit, afterFit, beforeIter, afterIter, 1.0, 1.0, 1.0, 0, prec ,tableName,tableColNames,tableColDestinations,mTable};
	
	//+++
	F.params=&paraT;
	
	GSL_FN_EVAL(&F,1);
	
	for (int pp=0;pp<p;pp++) tablePara->setText(pp, 3*mm+2,QString::number(gsl_vector_get(F_para,pp),'G',digits+1));
	//+++ 2016:: table after fit

	if (paraT.tableName!="no-matrix") makeTableFromMatrix (paraT.tableName, paraT.tableColNames, paraT.tableColDestinations, paraT.mTable);
	    
	    
	    if (paraT.tableColNames!=0) delete[] paraT.tableColNames; 
	    if (paraT.tableColDestinations!=0) delete[] paraT.tableColDestinations; 
	    if (paraT.mTable!=0) gsl_matrix_free(paraT.mTable);
	
    } 
    delete[] Q; 
    delete[] I; 
    delete[] dI; 
    delete[] sigma;
}


bool fittable::plotTable(Graph *g,Table *table, QString tableName, int colX, int colY, int colDX, int colDY)
{
    int cols=table->numCols();
    
    if (colX<0 || colX>=cols) return false;
    if (colY<0 || colY>=cols) return false;    
    
    bool checkBoxYerror=false;
    if (colDY>0 && colDY<cols) checkBoxYerror=true; 
    bool checkBoxXerror=false;
    if (colDX>0 && colDX<cols) checkBoxXerror=true; 
    //
    int style = Graph::Scatter;
    QStringList columnsListOnPlot=g->curvesList();
    //		
    g->resizeMy(g->curves());
    
    if (!checkBoxYerror && columnsListOnPlot.contains(table->colName(colDY))	)
    {
	g->removeCurve(table->colName(colDY));	  
    }
    else if (checkBoxYerror && !columnsListOnPlot.contains(table->colName(colDY)))
    {
	g->addErrorBars(table,table->colName(colX),table->colName(colY),table,table->colName(colDY), 1, 1, 1, QColor(black), TRUE, TRUE,TRUE);
    }
    
    if (!columnsListOnPlot.contains(table->colName(colY)))
    {
	g->insertCurve(table,table->colName(colY),style);	    
    }
    curveLayout cl = Graph::initCurveLayout();
    
    int color;		
    int curve = g->curves()-1 ;		
    long key = g->curveKey(curve);  
    if (key == (long) curve ) key++;
    g->guessUniqueCurveLayout(color, cl.sType);
    int shape=key%9;
    if (shape == 0) shape = 1; //avoid white invisible symbol   tableCurves
    
    cl.lCol=color;
    cl.symCol=color;
    cl.fillCol=color;
    cl.aCol=color;
    cl.lWidth = app(this)->defaultCurveLineWidth;
    cl.sSize = app(this)->defaultSymbolSize;
    
    //cl.sType=shape;
    
    g->updateCurveLayout(curve, &cl);
    
    if (cols>3 && !checkBoxXerror && columnsListOnPlot.contains(table->colName(colDX)))
    {
	g->removeCurve(table->colName(colDX));	
    }
    else if (cols>3 &&  checkBoxXerror && !columnsListOnPlot.contains(table->colName(colDX)))
    {
	g->addErrorBars(table,table->colName(colX), table->colName(colY),table, table->colName(colDX), 0, 2, 10, color, TRUE, TRUE,TRUE);
	curve = g->curves() - 1; 
	g->updateErrorBars(curve,TRUE,1,1, color, TRUE,TRUE,FALSE);
    }
    
    g->replot();
}

bool fittable::iFitAdv(){
    return iFit(true);
}


bool fittable::iFit(){
    return iFit(false);
}

bool fittable::iFit(bool modeAdv){
  
    int idStart=widgetStackFit->id(widgetStackFit->visibleWidget ()); 
    
    if (idStart>1) return false;
    
    Graph *g;
    
    if(!findActiveGraph(g)){QMessageBox::critical(this,tr("QtiKWS"), tr("Activate first GRAPH with data to fit !!!")); return false;};
    
    if (g->curves()==0) {QMessageBox::critical(this,tr("QtiKWS"), tr("Graph is EMPTY !!!")); return false;};
    
    
    QString curveName=g->selectedCurveTitle();
    
    double startID,endID;
    
    bool selectedRange=true;
    
    if (curveName=="") selectedRange=false;
    
    if ( selectedRange)
    {
	curveName=g->selectedCurveTitle();
	startID=g->selectedXStartValue();
	endID=g->selectedXEndValue();
	if (startID>endID)
	{
	    double tmp=endID;
	    endID=startID;
	    startID=tmp;
	}	
	
	if (startID==endID) return false;
    }
    else 
    {
	curveName=g->curvesList()[0];
    }
    
    
    if (idStart==0) 
    {
	if (!slotStackFitNext()) return false;    
    }
    
    widgetStackFit->hide();
    
    tableCurves->setText(0,0,curveName);tableCurvechanged(0,0); tableCurvechanged(0,1);tableCurves->setText(0,0,"");	
    
    
    
    if (selectedRange)
    {
	QComboTableItem *iQ =(QComboTableItem*)tableCurves->item (1, 0); iQ->setCurrentItem(1); tableCurvechanged(1,0);
	QCheckTableItem *cbImin = (QCheckTableItem*)tableCurves->item(2,0);cbImin->setChecked(true);tableCurves->setText(2,1,QString::number(startID,'g',10));
	QCheckTableItem *cbImax = (QCheckTableItem*)tableCurves->item(3,0);cbImax->setChecked(true);tableCurves->setText(3,1,QString::number(endID,'g',10));
    }
    else
    {
	QComboTableItem *iQ =(QComboTableItem*)tableCurves->item (1, 0); iQ->setCurrentItem(0); tableCurvechanged(1,0);
    }
    
    initParametersBeforeFit();
    fitSwitcher();
    initParametersAfterFit();
    resToLogWindow();
    
    
    if (checkBoxSuperpositionalFit->isChecked())
    {
	
	int totalNumberIndex=spinBoxSubFitNumber->value()-1;
	int currentNumberIndex=spinBoxSubFitCurrent->value()-1;
	int totalNumberOfParameters=tableParaSimulate->numRows();
	
	if (currentNumberIndex!=totalNumberIndex && currentNumberIndex<=totalNumberOfParameters && totalNumberIndex<=totalNumberOfParameters)
	{
	    slotStackFitNext();
	    int totalNumber=tableParaSimulate->text(totalNumberIndex,0).toDouble();
	    int currentNumber=tableParaSimulate->text(currentNumberIndex,0).toDouble();
	    
	    if (currentNumber==0 && totalNumber>1)
	    {
		QString funName=textLabelFfunc->text();
		int initColor=comboBoxColor->currentItem();
		for (int ii=0;ii<totalNumber;ii++)
		{
		    comboBoxColor->setCurrentItem( initColor+1+ii-int( (initColor+1+ii)/16)*16);
		    textLabelFfunc->setText("superpositional-"+funName+"-"+QString::number(ii+1));
		    tableParaSimulate->setText(currentNumberIndex,0,QString::number(ii+1));
		    simulateSwitcher();
		}
		textLabelFfunc->setText(funName);
		comboBoxColor->setCurrentItem(initColor);
		
		tableParaSimulate->setText(currentNumber,0,"0");
	    }
	    slotStackFitPrev();
	}
    }
    
    if (!modeAdv) slotStackFitPrev();
    
    widgetStackFit->show();
    
    return true;
}


void fittable::readFIFheader(QString fifName)
{
    eFitWeight=false;
    
    //+++
    if (fifName.isEmpty()) return;
    
    //+++
    if (!QFile::exists (fifName))	return;
    
    //+++
    QFile f(fifName);
    
    //+++
    if ( !f.open( IO_ReadOnly ) ) return;
    
    QTextStream t( &f );
    QString s = t.readLine();		
    
    if (s.contains("[group]")==0) return;
    
    s.remove("[group] ");
    if (s.contains("[eFit]")) s.remove("[eFit] ");
    
    if (s.contains("[Weight]"))
    {
	eFitWeight=true;
	s.remove("[Weight] ");
	comboBoxWeightingMethod->setCurrentItem(s.left(1).toInt());
	weightChanged();
	s=s.right(s.length()-2);
    }
    
    if (s.contains("[Algorithm]")) 
    {
	s.remove("[Algorithm] ");
	comboBoxFitMethod->setCurrentItem(s.left(1).toInt());
	algorithmSelected();
	s=s.right(s.length()-2);
    }
    
    if (s.contains("[Superpositional]"))
    {
	checkBoxSuperpositionalFit->setChecked(true);
	s.remove("[Superpositional] ");
	QStringList sLst = QStringList::split(" ", s, false);
	spinBoxSubFitNumber->setValue(sLst[0].toInt());
	spinBoxSubFitCurrent->setValue(sLst[1].toInt());		
    }
    else
    {
	checkBoxSuperpositionalFit->setChecked(false);
	spinBoxSubFitNumber->setValue(1);
	spinBoxSubFitCurrent->setValue(2);	
    }
    SuperpositialFitYN();	
}


void fittable::readFIFheader()
{
    
}


void fittable::updateEFunctions()
{
    groupFunctions(listBoxGroup->text(listBoxGroup->currentItem()) );
}


void fittable::simulateSuperpositional()
{
    bool usedInFittingSession = false;
    int id=widgetStackFit->id(widgetStackFit->visibleWidget ());
    
    if (id!=2) usedInFittingSession = true;
    

    
    if (checkBoxSuperpositionalFit->isChecked())
    {
	
	int totalNumberIndex=spinBoxSubFitNumber->value()-1;
	int currentNumberIndex=spinBoxSubFitCurrent->value()-1;
	int totalNumberOfParameters=tableParaSimulate->numRows();
	
	if (currentNumberIndex!=totalNumberIndex && currentNumberIndex<=totalNumberOfParameters && totalNumberIndex<=totalNumberOfParameters)
	{
	    if (usedInFittingSession) slotStackFitNext();
	    int totalNumber=tableParaSimulate->text(totalNumberIndex,0).toDouble();
	    int currentNumber=tableParaSimulate->text(currentNumberIndex,0).toDouble();
	    
	    if (currentNumber==0 && totalNumber>1)
	    {
		QString funName=textLabelFfunc->text();
		int initColor=comboBoxColor->currentItem();
		for (int ii=0;ii<totalNumber;ii++)
		{
		    comboBoxColor->setCurrentItem( initColor+1+ii-int( (initColor+1+ii)/16)*16);
		    textLabelFfunc->setText("superpositional-"+funName+"-"+QString::number(ii+1));
		    tableParaSimulate->setText(currentNumberIndex,0,QString::number(ii+1));
		    simulateSwitcher();
		}
		textLabelFfunc->setText(funName);
		comboBoxColor->setCurrentItem(initColor);
		
		tableParaSimulate->setText(currentNumberIndex,0,"0");
	    }
	    if (usedInFittingSession) slotStackFitPrev();
	}
    }
}


void fittable::changeFunctionLocal(const QString& newFunction)
{
    //+++
    QString oldFunction=textLabelFfunc->text();
    //+++
    if(oldFunction==newFunction) return;
    //+++
    openDLL( newFunction);
    //+++
    initLimits();
    //+++
    initFitPage();
    //+++
    for (int i=0;i<spinBoxPara->value();i++) tableParaSimulate->setText(i,0,tablePara->text(i,2));    
}


QString fittable::covarMatrix(int N, int P, double chi, double chiNormalization, QStringList paraActive, gsl_matrix *covar, gsl_vector *paraAdjust)
{
if (P<1) return "";
if (P!=paraActive.count()) return "";

int prec=spinBoxSignDigits->value();


gsl_matrix * covarCopy = gsl_matrix_alloc (P, P);
gsl_matrix * inverse = gsl_matrix_alloc (P, P);
gsl_matrix_memcpy(covarCopy, covar);

inversion (P, covarCopy, inverse);


QString s,ss, sChi, sChi2, sRoot, sDot;
sChi=QChar(967);
sChi2=sChi; sChi2+=QChar(178);
sRoot=QChar(8730);
sDot=QChar(8901);

int sMinLength=spinBoxSignDigits->value()+6;

s="\n"; 

QString F_name=textLabelFfunc->text();
QDateTime dt = QDateTime::currentDateTime ();
s += "[ " + dt.toString(Qt::LocalDate)+ " ]\n";
for(int i=0; i<2*(5+sMinLength)*(P+1);i++) s+="-";
s+="\n";

s += tr("Using Function") + ":\t " + F_name + "\n";

s+="\n\n"; 



s+="The Variance-Covariance Matrix cov(i,i):\n";
//------------------------------------------------------------------------
for(int i=0; i<2*(5+sMinLength)*(P+1);i++) s+="-";
s+="\n";



for(int p=0;p<P;p++)
{
    s+=paraActive[p];
    
    //    for(int i=0; i<sMinLength-paraActive[p].length();i++) s+=" ";
    s+="\t\t";
}
s+="  \t \n";

//------------------------------------------------------------------------
for(int i=0; i<2*(5+sMinLength)*(P+1);i++) s+="-";
s+="\n";



for(int p=0;p<P;p++) 
{
    
    for(int pp=0;pp<P;pp++)
    {    
     
	ss="+";
	if (gsl_matrix_get(covar, pp,p)<0) ss="";
	s+=ss+QString::number(gsl_matrix_get(covar, pp,p),'E',spinBoxSignDigits->value()-1) +"\t";	
    }
    s+="| "+paraActive[p]; 
    s+="\n";  
}
//------------------------------------------------------------------------
for(int i=0; i<2*(5+sMinLength)*(P+1);i++) s+="-";
s+="\n\n";

s+="Values, Errors and Dependences:\n";
//------------------------------------------------------------------------
for(int i=0; i<(5+sMinLength)*12;i++) s+="-";
s+="\n";

s+="Value \t\t Error[ "+ sRoot+" "+sChi2+"/(N-p)"+sDot+"cov(i,i)  ]  \t Error[ "+ sRoot+" cov(i,i)  ] \t Dependency [1-1/cov(i,i)/cov'(i,i)]\t\t Name  \n";
//------------------------------------------------------------------------
for(int i=0; i<(5+sMinLength)*12;i++) s+="-";
s+="\n";


for(int p=0;p<P;p++) 
{
    s+=QString::number(gsl_vector_get(paraAdjust, p),'E',spinBoxSignDigits->value()-1)+"\t\t";
    s+=QChar(177);
    s+=" "+ QString::number( sqrt(fabs(chi*chi/(N-P)*gsl_matrix_get(covar,p,p))),'E',spinBoxSignDigits->value()-1)+"\t\t";
    s+=QChar(177);
    s+=" "+ QString::number( sqrt(gsl_matrix_get(covar,p,p)),'E',spinBoxSignDigits->value()-1)+"\t\t";
    
    
    double tmp=fabs(gsl_matrix_get(covar, p,p)*gsl_matrix_get(inverse, p,p));
    
    if (tmp>pow(10.0,prec+2)) tmp=1.0;
    else 
    {
	if(tmp<1 ) tmp=0.0; 
	else tmp=1-1/tmp;
    };
    if (tmp<0 || tmp>1) tmp=1.0;
    s+=QString::number(tmp,'E',spinBoxSignDigits->value()-1)+"\t\t\t\t";
    s+="| "+paraActive[p];
    s+="\n";  
}
//------------------------------------------------------------------------
for(int i=0; i<(5+sMinLength)*12;i++) s+="-";
s+="\n";
//s+="chi   = "+ QString::number(chi,'E',20)+"\tchi/sqrt(N-p) \t= "+QString::number(chi/sqrt(N-P),'E',20)+"\n"; 
s+=sChi2+" = "+ QString::number(chi*chi,'E', prec+4)+"\t";
s+=sChi2+"/(N-p) = "+QString::number(chi*chi/(N-P),'E', prec+4)+"\t";
s+=sChi2+"/(N-p)/Weight = "+QString::number(chi*chi/(N-P)/chiNormalization,'E', prec+4)+"\n"; 

gsl_matrix_free(covarCopy );
gsl_matrix_free(inverse);

return s;
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++FUNCTIONS::additional output table      ++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
bool fittable::makeTableFromMatrix (std::string name, std::string *tableColNames, int *tableColDestinations, gsl_matrix * m)
{    
    QString tableName=name.c_str();
    
    if (tableName=="no-matrix") return false;
    
    //+++ checking datat +++++
    tableName=tableName.remove(" ").remove("_").remove(",").remove("."); if (tableName=="") return false;
//    if (tableColNames->size()!=tableColDestinations->size() || tableColNames->size()<1) return false;
    
    int mRows=m->size1; if (mRows<1) return false;
    int mCols=m->size2; if (mCols<1) return false;
//    if (mCols!=tableColNames.count()) return false;
    
    //+++
    QWidgetList* windows=app(this)->windowsList();
    //+++
    bool existYN=false;
    //+++
    QString ss;
    //+++
    Table* t;
    
    //+++ find existing table
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
	ss=windows->at(mm)->name();
	
	if (ss==tableName && windows->at(mm)->isA("Table"))
	{
	    t=(Table *)windows->at(mm);
	    existYN=true;
	    t->setNumRows(0);
	    t->setNumRows(mRows);
	    t->setNumCols(mCols);
	}
    }
    
    //+++create new table
    if (!existYN) t=app(this)->newHiddenTable(tableName,"Matrix Fit :: Matrix-to-Table", mRows ,mCols);
    
    QString s;
    //+++ col names & destination
    for(int cc=0; cc<mCols; cc++)
    {	
	s=tableColNames[cc].c_str(); s=s.remove(" ").remove("_");
	t->setColName(cc,s);
	t->setColPlotDesignation(cc,Table::PlotDesignation(tableColDestinations[cc]));
    }
    t->setHeaderColType();
    
    int digits=spinBoxSignDigits->value()-1;
    
    //+++ transfet data to table
    for (int rr=0; rr<mRows;rr++) for(int cc=0;cc<mCols;cc++) t->setText(rr,cc,QString::number(gsl_matrix_get(m,rr,cc),'E',digits)); 
       
    //+++ table actions
    t->notifyChanges();
    
    //+++
    t->setWindowLabel("Matrix Fit :: Matrix-to-Table");
    app(this)->setListViewLabel(t->name(), "Matrix Fit :: Matrix-to-Table");
    app(this)->updateWindowLists(t);
    
    for (int tt=0; tt<t->numCols(); tt++)
    {
	t->table()->adjustColumn (tt);
	t->table()->setColumnWidth(tt, t->table()->columnWidth(tt)+10); 
    }  
    
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++make note+++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
void fittable::makeNote(QString info, QString name, QString label)
{    
    QWidgetList* windows=app(this)->windowsList();
    //+++
    QString ss;
    //+++
    bool existYN=false;
    Note* nn;
    //+++
    
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
	ss=windows->at(mm)->name();
	
	if (ss==name && windows->at(mm)->isA("Note"))
	{
	    nn=(Note *)windows->at(mm);
	    existYN=true;	    
	}
    }
    
    //+++make Unique Name    
    if (!existYN)
    {
	nn=app(this)->newHiddenNote(name);
	nn->setWindowLabel(label);
	app(this)->setListViewLabel(nn->name(), label);
	app(this)->hideWindow(nn);
    }
    
 
 
    //+++
    nn->setText(info);
}


//*******************************************
//  2016
//*******************************************
void fittable::dataLimitsSimulation(int value)
{    
    QString NQ=comboBoxSimQN->currentText();
    
    //+++ Table Name
    Table *t;
    int xColIndex,yColIndex;
    
    //+++
    QString curveName=comboBoxDatasetSim->currentText();
    QString tableName=curveName.left(curveName.find("_",0));	
    
    if ( !findFitDataTable(curveName, t, xColIndex,yColIndex ) ) return;
    
    int N=t->numRows();
    int ii=0;
    while(t->text(ii,xColIndex) == "" && ii<N) ii++;
	
    // +++
    int Ntot=0;
    QRegExp rx( "((\\-|\\+)?\\d*(\\.|\\,)\\d*((e|E)(\\-|\\+)\\d*)?)|((\\-|\\+)?\\d+)" );	
    for(int j=0;j<N;j++) if (rx.exactMatch(t->text(j,xColIndex))) Ntot++;
    if (Ntot<2) Ntot=1000;
			
    if (ii==N) return;
    
    double min=t->text(ii,xColIndex).toDouble();
    double max=t->text(ii,xColIndex).toDouble();
	    
    for (int j=ii;j<N;j++)
    {
	if ((t->text(j,xColIndex).toDouble())>max && t->text(j,xColIndex)!="") max=t->text(j,xColIndex).toDouble();
	if (t->text(j,xColIndex).toDouble()<min && t->text(j,xColIndex)!="") min=t->text(j,xColIndex).toDouble();
    }
	    
    if(NQ=="Q")
    {
	textLabelRangeFirstLimit->setText(QString::number(GSL_MIN(1,Ntot)));
	textLabelRangeLastLimit->setText(QString::number(Ntot));
	textLabelRangeFirst->setText(QString::number(GSL_MIN(1,Ntot)));
	textLabelRangeLast->setText(QString::number(Ntot)); 
    }
    else
    {
	textLabelRangeFirstLimit->setText(QString::number(GSL_MIN(min,max)));
	textLabelRangeLastLimit->setText(QString::number(max));	
	textLabelRangeFirst->setText(QString::number(GSL_MIN(min,max)));
	textLabelRangeLast->setText(QString::number(max)); 
    }  
}

void fittable::rangeFirstCheck()
{
    QString NQ=comboBoxSimQN->currentText();
    
    if (NQ=="N")
    {
	int min=textLabelRangeFirstLimit->text().toInt();
	int max=textLabelRangeLast->text().toInt();
	int value=textLabelRangeFirst->text().toInt();
	
	if (value<min || value >max) textLabelRangeFirst->setText(QString::number(min));
    }
    else
    {
	double min=textLabelRangeFirstLimit->text().toDouble();
	double max=textLabelRangeLast->text().toDouble();
	double value=textLabelRangeFirst->text().toDouble();
	
	if (value<min || value >max) textLabelRangeFirst->setText(QString::number(min));
    }	
}

void fittable::rangeLastCheck()
{
    QString NQ=comboBoxSimQN->currentText();
    
    if (NQ=="N")
    {
	int min=textLabelRangeFirst->text().toInt();
	int max=textLabelRangeLastLimit->text().toInt();
	int value=textLabelRangeLast->text().toInt();
	
	if (value<min || value >max) textLabelRangeLast->setText(QString::number(max));
    }
    else
    {
	double min=textLabelRangeFirst->text().toDouble();
	double max=textLabelRangeLastLimit->text().toDouble();
	double value=textLabelRangeLast->text().toDouble();
	
	if (value<min || value >max) textLabelRangeLast->setText(QString::number(max));
    }	
}


bool fittable::findActiveCurve(QString &name, bool &selectedRange, double &min, double &max)
{
    Graph *g;
    
    if(!findActiveGraph(g)){QMessageBox::critical(this,tr("QtiKWS"), tr("Activate first GRAPH with data to fit !!!")); return false;};
    
    if (g->curves()==0) {QMessageBox::critical(this,tr("QtiKWS"), tr("Graph is EMPTY !!!")); return false;};
    
    name=g->selectedCurveTitle();
        
    selectedRange=true;
    if (name=="") selectedRange=false;
    
    if ( selectedRange)
    {
	name=g->selectedCurveTitle();
	min=g->selectedXStartValue();
	max=g->selectedXEndValue();
	if (min>max)
	{
	    double tmp=max;
	    max=min;
	    min=tmp;
	}	
	
	if (min==max) return false;
    }
    else 
    {
	name=g->curvesList()[0];
    }
    return true;
}

bool fittable::selectActiveCurve(int m)
{  
    m=m-1;
    
    QString name;
    bool selectedRange; 
    double min, max;
    
    if (!findActiveCurve(name, selectedRange, min, max) ) return false;
    
    tableCurves->setText(0,2*m,name); tableCurvechanged(0,2*m); tableCurvechanged(0,2*m+1);tableCurves->setText(0,2*m,"");	
    
    
    if (selectedRange)
    {
	QComboTableItem *iQ =(QComboTableItem*)tableCurves->item (1, 2*m); iQ->setCurrentItem(1); tableCurvechanged(1,2*m);
	QCheckTableItem *cbImin = (QCheckTableItem*)tableCurves->item(2,2*m);cbImin->setChecked(true);tableCurves->setText(2,2*m+1,QString::number(min,'g',10));
	QCheckTableItem *cbImax = (QCheckTableItem*)tableCurves->item(3,2*m);cbImax->setChecked(true);tableCurves->setText(3,2*m+1,QString::number(max,'g',10));
    }
    else
    {
	QComboTableItem *iQ =(QComboTableItem*)tableCurves->item (1, 2*m); iQ->setCurrentItem(0); tableCurvechanged(1,2*m);
    }
    
    return true;
}


//+++ select data
bool fittable::selectData(int m, QString name)
{  
    m=m-1;
    
    tableCurves->setText(0,2*m,name); tableCurvechanged(0,2*m); tableCurvechanged(0,2*m+1);tableCurves->setText(0,2*m,"");	
    if (tableCurves->text(0,2*m+1).contains(name)) return true;
    return false;
}

//+++ select range
bool fittable::selectRange(int m, QString QN, double min, double max)
{
    m=m-1;
    
    QComboTableItem *iQ =(QComboTableItem*)tableCurves->item (1, 2*m);
    if (QN=="N") iQ->setCurrentItem(0); else iQ->setCurrentItem(1);
    tableCurvechanged(1,2*m);
    
    if (min>max)
    {
    double tmp=max;
    max=min;
    min=tmp;
    }
    
    if (min==max) return true;
    
    QCheckTableItem *cbImin = (QCheckTableItem*)tableCurves->item(2,2*m);cbImin->setChecked(true);tableCurves->setText(2,2*m+1,QString::number(min,'g',10));
    
    QCheckTableItem *cbImax = (QCheckTableItem*)tableCurves->item(3,2*m);cbImax->setChecked(true);tableCurves->setText(3,2*m+1,QString::number(max,'g',10));
    
    tableCurvechanged(2,2*m+1);
    tableCurvechanged(3,2*m+1);
    
    return true;  
}

bool fittable::callFromTerminal(QString commandLine)
{
    commandLine=commandLine.simplifyWhiteSpace();
    commandLine=commandLine.stripWhiteSpace();
    
    QStringList lst;
    lst.clear();
    lst=lst.split(" ",commandLine,false);
    
    if (lst.count()==0) return false;
    
    QString command=lst[0];
    
    int id=widgetStackFit->id(widgetStackFit->visibleWidget ());

    //+++ id ==0
    
    if(command=="setFunction") 
    {
	if (id!=0 || lst.count()!=2) return false;
	QString function=lst[1];
	scanGroup();
	listBoxGroup->setSelected(0,TRUE);
	groupFunctions("ALL");
	if (listBoxFunctions->index(listBoxFunctions->findItem(function,Qt::ExactMatch))<0) return false;
	listBoxFunctions->setSelected(listBoxFunctions->findItem(function,Qt::ExactMatch), true);
	openDLL(function);
	return true;
    }
    
    if(command=="setMode") 
    {
	if (id!=0 || lst.count()!=2) return false;
	int mode=lst[1].toInt();
	if(mode>2) return false;
	if (mode==0) 
	{
	    comboBoxInstrument->setCurrentItem(0);
	    checkBoxSANSsupport->setChecked(false); 
	}
	 else
	{
	    checkBoxSANSsupport->setChecked(true); 
	    comboBoxInstrument->setCurrentItem(mode-1);
	}
	SANSsupportYN();
	return true;
    }
    
    if(command=="setGlobalMode") 
    {
	if (id!=0 || lst.count()!=2) return false;
	int curves=lst[1].toInt();
	if(curves>20) return false;
	if (curves<=1) 
	{
	    spinBoxNumberCurvesToFit->setValue(1);
	    checkBoxMultiData->setChecked(false); 
	}
	 else
	{
	    checkBoxMultiData->setChecked(true); 
	    spinBoxNumberCurvesToFit->setValue(curves);
	}
	initMultiParaTable();
	return true;
    }    
    
    if(command=="setSuperpositionalMode") 
    {
	if (id!=0 || (lst.count()!=2 && lst.count()!=4) ) return false;
	
	if (lst[1].toInt()==0) checkBoxSuperpositionalFit->setChecked(false);
	else checkBoxSuperpositionalFit->setChecked(true);
	
	SuperpositialFitYN();
	
	if (lst.count()==2) return true;
	
	spinBoxSubFitNumber->setValue(int(fabs(double(lst[2].toInt()))));
	spinBoxSubFitCurrent->setValue(int(fabs(double(lst[3].toInt()))));
	return true;
    }    
    
    if(command=="e-Fit") 
    {
	if (id!=0) return false;
	return iFit();
    } 
    
    if(command=="e-Fit+++") 
    {
	return iFitAdv();
    }
    
    if(command=="next") 
    {
	slotStackFitNext();
	return true;
    }
    
    if(command=="prev") 
    {
	slotStackFitPrev();
	return true;
    }
    
    if(command=="setActiveCurve") 
    {
	if (id!=1 || lst.count()!=2) return false;	
	
	int M=spinBoxFnumber->value();	
	int m=lst[1].toInt();
	if (m<1 || m>M) return false;
	return selectActiveCurve(m);
    }    
      
    if(command=="setData") 
    {
	if (id!=1 || lst.count()!=3) return false;	
	
	int M=spinBoxFnumber->value();	
	int m=lst[1].toInt();
	if (m<1 || m>M) return false;
	
	QString name=lst[2];
	return selectData(m, name);
    } 
    
    if(command=="setRange") 
    {
	if (id!=1 || lst.count()!=5) return false;	
	
	int M=spinBoxFnumber->value();	
	int m=lst[1].toInt();
	if (m<1 || m>M) return false;
	
	QString QN=lst[2];
	
	double min  = lst[3].toDouble();
	double max = lst[4].toDouble();
	
	return selectRange(m, QN, min, max);
    }
    
    if(command=="fit")
    {
        if (id!=1) return false;
        int repeat=1;
        
        if (lst.count()>=2 && lst[1].toInt()>1) repeat=lst[1].toInt();
        
        for (int ff=0; ff<repeat; ff++) fitSwitcher();
    } 

}
	
