#include <gsl/gsl_math.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_sf_gamma.h>

double polyAB(double R, void *paraM)
{
    gsl_vector  *Para=(gsl_vector *) paraM;
    double R0=gsl_vector_get(Para,0);
    double sigma=gsl_vector_get(Para,1);
	//
    if (sigma<0 || R<0 || R<(R0-sigma) || R>(R0+sigma)) {return 0;};
	//
	return 1/2/sigma;
}

double polyABC(double R, void *paraM)
{
    gsl_vector  *Para=(gsl_vector *) paraM;
    double C=gsl_vector_get(Para,0);
    double A=gsl_vector_get(Para,1);
    double B=gsl_vector_get(Para,2);

    //
    if (B<=A || R<0 || C<A || C>B) return 0;
    //
    if (R>=A && R<=C) return 2*(R-A)/(B-A)/(C-A);
    if (R>C && R<=B)  return  2*(B-R)/(B-A)/(B-C);
    else return 0;
}

double polyLogNorm(double R, void *paraM)
{
    gsl_vector  *Para=(gsl_vector *) paraM;
    double R0 	=gsl_vector_get(Para,0);
    double sigma 	=gsl_vector_get(Para,1);
    double P 	=gsl_vector_get(Para,2);
    //
    if (sigma<0 || R<0 || R0<=0) return 0;
    //
    double cLN=M_SQRT2*M_SQRTPI*sigma;
    //    
    return 1/cLN*exp(-P*log(R) - log(R/R0)*log(R/R0)/2/sigma/sigma - (log(R0)* (1-P) + (1-P)*(1-P)*sigma*sigma/2));
}

double polyGaussian(double R, void *paraM)
{
    gsl_vector  *Para=(gsl_vector *) paraM;
    double R0 	=gsl_vector_get(Para,0);
    double sigma 	=gsl_vector_get(Para,1);
    //
    if (sigma<0 || R<0 || R0<=0) return 0;
    //    
    return gsl_ran_gaussian_tail_pdf(R-R0,-R0,sigma);
}

double polySZ(double R, void *paraM)
{
    gsl_vector  *Para=(gsl_vector *) paraM;
    double R0 	=gsl_vector_get(Para,0);
    double poly 	=gsl_vector_get(Para,1);
    //
    if (poly<=1.077 || R<0 || R0<=0) return 0;
    //    
      //
     double z=1/ (poly-1) / (poly-1);
     double k=R/R0* (z+1);
    //
    return (z+1)/R*exp( log(k)*(z+1) - gsl_sf_lngamma(z+1) - k);
    
}

double polyGamma(double R, void *paraM)
{
    gsl_vector  *Para=(gsl_vector *) paraM;
    double R0 	=gsl_vector_get(Para,0);
    double sigma 	=gsl_vector_get(Para,1);
    //
    if (sigma<0 || R<0 || R0<=0) return 0;
    //    
    double k=R0*R0/sigma/sigma;
    double theta=sigma*sigma/R0;
    double RtoTheta=R/theta;
    //
    if (k==1 && R==0) return 1/theta;
   return 1/theta*exp( log(RtoTheta) * (k-1)  - gsl_sf_lngamma(k)  - RtoTheta);   
   //
}
