/****************************************************************************
** Form implementation generated from reading ui file '../qtiKWS/sans/fitTable10/fitTable10.ui'
**
** Created: Thu Mar 2 12:12:52 2017
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "fitTable10.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qbuttongroup.h>
#include <qlabel.h>
#include <qtoolbutton.h>
#include <qwidgetstack.h>
#include <qsplitter.h>
#include <qlistbox.h>
#include <qtabwidget.h>
#include <qtextbrowser.h>
#include <qtable.h>
#include <qcheckbox.h>
#include <qframe.h>
#include <qcombobox.h>
#include <qspinbox.h>
#include <qlineedit.h>
#include <qtoolbox.h>
#include <qgroupbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "fitTable10.ui.h"
static const unsigned char image0_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xe0, 0x77, 0x3d, 0xf8, 0x00, 0x00, 0x05,
    0x0e, 0x49, 0x44, 0x41, 0x54, 0x48, 0x89, 0xb5, 0x95, 0x4b, 0x6c, 0x9c,
    0xd5, 0x15, 0xc7, 0x7f, 0xf7, 0x7b, 0xce, 0x8c, 0xc7, 0x19, 0x1b, 0xd7,
    0x8e, 0x63, 0xac, 0x1a, 0x04, 0x06, 0x04, 0x56, 0x30, 0xca, 0x26, 0x0b,
    0x04, 0x56, 0x25, 0x14, 0x51, 0xb2, 0xc8, 0x06, 0x2a, 0x55, 0x14, 0xa9,
    0x0b, 0x50, 0xd4, 0xaa, 0x15, 0xb0, 0x41, 0x3c, 0xa4, 0x09, 0x12, 0x0b,
    0x90, 0x88, 0x6a, 0x1e, 0x1b, 0x76, 0xb4, 0x3c, 0x84, 0xe8, 0x82, 0x88,
    0x56, 0x2d, 0x1b, 0xc4, 0x44, 0x2c, 0x20, 0xa5, 0x11, 0xa9, 0x54, 0x29,
    0xd8, 0xb1, 0x9b, 0xb1, 0xe5, 0xcc, 0x64, 0xc6, 0xc6, 0xf3, 0x9e, 0x7c,
    0xdf, 0x7d, 0x76, 0x61, 0x12, 0x32, 0x49, 0x4a, 0xab, 0x22, 0xce, 0xea,
    0xe8, 0xe8, 0xea, 0xfc, 0xcf, 0xef, 0x9e, 0x73, 0xee, 0x15, 0xce, 0x39,
    0x7e, 0x48, 0x0b, 0xfe, 0x97, 0x43, 0x2f, 0xbe, 0xf8, 0xd1, 0x0d, 0x5a,
    0xeb, 0x79, 0x63, 0xf4, 0xbc, 0xb5, 0x1a, 0x63, 0x4c, 0xd3, 0x18, 0x77,
    0x3c, 0x93, 0x59, 0xfa, 0xc7, 0xc5, 0x33, 0x47, 0x8e, 0x14, 0x9d, 0x73,
    0x5c, 0x55, 0xad, 0xf8, 0x2e, 0x82, 0xa3, 0x47, 0x3f, 0x3e, 0xe4, 0x9c,
    0x2b, 0x06, 0x41, 0x30, 0x1f, 0x45, 0x11, 0x61, 0x18, 0xa2, 0xb5, 0xa6,
    0xd3, 0x69, 0xd3, 0x6e, 0xb7, 0x48, 0xd3, 0x64, 0x4d, 0x29, 0xf3, 0x56,
    0x9a, 0xa6, 0xaf, 0x4d, 0x4e, 0xd6, 0xb6, 0x01, 0x5b, 0x2c, 0x16, 0xed,
    0x7f, 0x25, 0x58, 0x5c, 0x2c, 0x8d, 0x08, 0xe1, 0x7f, 0xb0, 0x67, 0xcf,
    0xe4, 0xc2, 0xdc, 0xdc, 0x8f, 0x19, 0x1d, 0xcd, 0x92, 0xc9, 0x04, 0x28,
    0x05, 0x9d, 0x8e, 0xa4, 0xd5, 0x4a, 0x38, 0x77, 0x6e, 0x93, 0xb5, 0xb5,
    0xf2, 0x4c, 0xa5, 0x52, 0x7d, 0xce, 0x5a, 0xfd, 0x48, 0xad, 0x36, 0xf1,
    0x33, 0x63, 0xfc, 0x93, 0x42, 0x30, 0x40, 0x72, 0x15, 0xc1, 0xe2, 0x62,
    0x69, 0x3e, 0x0c, 0xa3, 0xd2, 0xdd, 0x77, 0xdf, 0x51, 0x98, 0x9d, 0x2d,
    0xd0, 0x6e, 0x1b, 0xea, 0x75, 0x49, 0xa3, 0x91, 0xd0, 0xef, 0xa7, 0x58,
    0xab, 0x89, 0x22, 0x9f, 0x38, 0x8e, 0x50, 0xca, 0xb0, 0xb2, 0xb2, 0xca,
    0xc6, 0xc6, 0x3a, 0xdb, 0xdb, 0xdb, 0x2d, 0xa5, 0xd4, 0x4f, 0xaf, 0xbf,
    0xbe, 0xf1, 0xb7, 0x62, 0xb1, 0xa8, 0xaf, 0x49, 0xb0, 0xb8, 0x58, 0x1a,
    0xf1, 0x3c, 0xbf, 0x74, 0xdf, 0x7d, 0x77, 0x15, 0xa6, 0xa7, 0xb3, 0x94,
    0xcb, 0x96, 0x56, 0x4b, 0xa3, 0x94, 0x41, 0x6b, 0x87, 0x10, 0x60, 0x8c,
    0xa3, 0xd5, 0xea, 0x91, 0xa6, 0xdb, 0x38, 0x67, 0x99, 0x98, 0x98, 0x24,
    0x49, 0x52, 0x94, 0xd2, 0x85, 0x46, 0xa3, 0xf1, 0x97, 0x4a, 0x65, 0x6c,
    0xbf, 0x10, 0x2c, 0x5d, 0xa4, 0xf0, 0x2e, 0x17, 0x50, 0x4a, 0x7d, 0xb0,
    0x6f, 0xdf, 0x6d, 0x85, 0xf1, 0xf1, 0x0c, 0xa7, 0x4f, 0x6b, 0xba, 0x5d,
    0x87, 0x73, 0xe0, 0x9c, 0x43, 0x29, 0xc5, 0xca, 0xca, 0xbf, 0x76, 0xb0,
    0x85, 0x00, 0xa0, 0xd1, 0x68, 0x52, 0x2e, 0x97, 0xc9, 0x66, 0x73, 0x8c,
    0x8e, 0x8e, 0xe1, 0xfb, 0x5e, 0x41, 0x6b, 0xf5, 0xf2, 0x83, 0x0f, 0xfe,
    0xf1, 0x52, 0xde, 0x4b, 0xce, 0x0b, 0x2f, 0xfc, 0x79, 0x61, 0x64, 0x64,
    0xd7, 0xc2, 0xad, 0xb7, 0xfe, 0x88, 0x33, 0x67, 0xfa, 0x5c, 0xb8, 0xa0,
    0x50, 0x4a, 0x61, 0x8c, 0x26, 0x4d, 0x53, 0x3e, 0xf9, 0xa4, 0x44, 0xa3,
    0xb1, 0x05, 0x38, 0xc0, 0x51, 0xab, 0xd5, 0x38, 0x7d, 0x7a, 0x99, 0x34,
    0x4d, 0xe9, 0xf7, 0x7b, 0x08, 0x01, 0x85, 0xc2, 0x28, 0xce, 0xb9, 0x07,
    0xe2, 0x78, 0xf5, 0xc6, 0xab, 0x04, 0x9c, 0x73, 0xc5, 0xb9, 0xb9, 0x9b,
    0xa9, 0x54, 0xfa, 0x74, 0xbb, 0x12, 0xad, 0x15, 0x5a, 0x4b, 0x36, 0x37,
    0xb7, 0xf8, 0xf0, 0xc3, 0x3f, 0x31, 0x31, 0x31, 0xc4, 0xa1, 0x43, 0x77,
    0x61, 0xad, 0xe5, 0xab, 0xaf, 0x96, 0x59, 0x5a, 0x5a, 0x61, 0x61, 0xe1,
    0x76, 0xba, 0xdd, 0x1e, 0x52, 0x4a, 0x9c, 0xb3, 0xe4, 0x72, 0x43, 0x78,
    0x02, 0x84, 0x10, 0xbf, 0x1d, 0xe8, 0xc1, 0xf3, 0xcf, 0x1f, 0x1b, 0x89,
    0xa2, 0x68, 0x61, 0x74, 0x34, 0xcf, 0xfa, 0x7a, 0x13, 0xf0, 0x10, 0xc2,
    0x52, 0xa9, 0x54, 0xf8, 0xe2, 0x8b, 0xbf, 0x73, 0xe0, 0xc0, 0x5e, 0x0e,
    0x1e, 0xdc, 0xc7, 0xf2, 0x72, 0x85, 0x13, 0x27, 0x3e, 0x47, 0x08, 0xcd,
    0x93, 0x4f, 0x1e, 0xe4, 0x96, 0x5b, 0xa6, 0x68, 0xb7, 0x8f, 0xd3, 0xf8,
    0x3a, 0x41, 0xe0, 0x11, 0x87, 0x3e, 0x41, 0x18, 0x91, 0x4a, 0x79, 0xe7,
    0x80, 0x80, 0x52, 0xe9, 0xbd, 0xf9, 0x7c, 0x1e, 0x29, 0x0d, 0x69, 0xaa,
    0xf0, 0x3c, 0x8f, 0xb3, 0x67, 0xcb, 0xac, 0xac, 0x2c, 0x73, 0xf8, 0xf0,
    0x01, 0x66, 0x67, 0xa7, 0x90, 0x12, 0x94, 0x82, 0xbd, 0x7b, 0xa7, 0xb9,
    0xff, 0xfe, 0x7d, 0x64, 0xb3, 0x11, 0x52, 0x82, 0x35, 0xe0, 0x7b, 0xe0,
    0x7b, 0x1e, 0xca, 0x38, 0xe2, 0x28, 0xa4, 0xdb, 0x75, 0xf7, 0x0c, 0x08,
    0x18, 0xe3, 0xe6, 0xc3, 0x30, 0xa4, 0x52, 0x69, 0xa0, 0xb5, 0xc2, 0x5a,
    0x8b, 0x10, 0x92, 0x67, 0x9e, 0xf9, 0xf9, 0xa5, 0x44, 0x00, 0x33, 0x33,
    0x53, 0xcc, 0xcc, 0x4c, 0x01, 0x5c, 0x8a, 0x69, 0x63, 0xf0, 0x3d, 0x41,
    0x1c, 0x04, 0x38, 0xe7, 0x10, 0xec, 0x2c, 0xc2, 0x80, 0xc0, 0x37, 0xeb,
    0x4f, 0xab, 0xd9, 0xc1, 0xf7, 0x3d, 0x10, 0x1e, 0xfb, 0xf7, 0xef, 0xc5,
    0x39, 0x1f, 0xa5, 0xbe, 0x9d, 0xb2, 0x24, 0x91, 0x64, 0x32, 0xd1, 0xc0,
    0xde, 0x78, 0x42, 0x10, 0x87, 0x01, 0x71, 0x10, 0xa0, 0xad, 0xc1, 0x5a,
    0xf3, 0xcd, 0x20, 0x5c, 0xd6, 0x64, 0xad, 0x2d, 0x5a, 0x49, 0xac, 0xd5,
    0x58, 0x63, 0x30, 0x5a, 0xb1, 0x72, 0xa6, 0xc6, 0x67, 0x9f, 0x9d, 0x65,
    0x63, 0xa3, 0x8d, 0x94, 0x3b, 0x15, 0xaf, 0xaf, 0x6f, 0xf1, 0xde, 0x7b,
    0x9f, 0x52, 0xad, 0x7e, 0x1b, 0x1b, 0x9f, 0xb8, 0x8e, 0x5c, 0x14, 0xe3,
    0xfb, 0x3e, 0xce, 0x59, 0x2e, 0x5c, 0xe8, 0x03, 0x9c, 0x1a, 0x20, 0x70,
    0xce, 0x94, 0x3a, 0x9d, 0x0e, 0x38, 0x8b, 0x70, 0x3b, 0x88, 0xda, 0x58,
    0x92, 0x34, 0xe5, 0xe4, 0xc9, 0x16, 0x63, 0x63, 0x05, 0x66, 0x67, 0xa7,
    0x31, 0xc6, 0xa3, 0x52, 0xa9, 0xf3, 0xd1, 0x5f, 0x4f, 0x70, 0xf3, 0x4d,
    0xd3, 0xdc, 0x3e, 0x77, 0x13, 0xce, 0x0a, 0x32, 0x71, 0x40, 0xaa, 0x14,
    0xbd, 0x5e, 0x0f, 0x6d, 0x0c, 0xce, 0x51, 0x1a, 0x10, 0xe8, 0xf5, 0xd4,
    0x29, 0x5f, 0xf4, 0x90, 0x69, 0x42, 0x94, 0xcd, 0x12, 0xf8, 0x02, 0xe1,
    0xc0, 0x6a, 0x83, 0xd6, 0x9a, 0xea, 0xb9, 0x3a, 0xe7, 0xab, 0x5b, 0x8c,
    0x8c, 0xe4, 0xd9, 0x95, 0xcf, 0x11, 0xfb, 0x1e, 0x9b, 0xe7, 0xea, 0xfc,
    0xb3, 0x9f, 0x12, 0x85, 0x3e, 0xda, 0xf3, 0xe8, 0x19, 0x4b, 0xb5, 0x56,
    0xc3, 0x18, 0x03, 0x78, 0xc7, 0x06, 0xae, 0xe8, 0x8d, 0x37, 0x1e, 0x6b,
    0x19, 0xab, 0xde, 0xaa, 0xd7, 0xce, 0x23, 0x9c, 0x25, 0xf2, 0x04, 0x43,
    0x91, 0xcf, 0x50, 0x14, 0x30, 0x14, 0xfa, 0x64, 0x43, 0x8f, 0x10, 0x4b,
    0x77, 0xbb, 0xc9, 0xee, 0xd1, 0x5d, 0x8c, 0x0d, 0x0f, 0x31, 0x31, 0x32,
    0x4c, 0x2e, 0xf0, 0xf0, 0xb5, 0x26, 0xd5, 0x9a, 0x6a, 0xbd, 0x46, 0xb7,
    0xd7, 0xc3, 0x3a, 0x5b, 0x7a, 0xf7, 0xdd, 0xa7, 0x8f, 0x0f, 0x10, 0x00,
    0x08, 0x63, 0x7e, 0x57, 0xdf, 0xdc, 0xfc, 0x45, 0x61, 0x38, 0xcf, 0xd4,
    0xf8, 0x38, 0x99, 0x28, 0x24, 0x1b, 0xf8, 0x58, 0x17, 0xa1, 0xb5, 0xc1,
    0x5a, 0x87, 0x10, 0x0e, 0x4f, 0x78, 0x04, 0x9e, 0x40, 0x08, 0x81, 0xd4,
    0x9a, 0xbe, 0x94, 0xd4, 0xb6, 0xb6, 0x58, 0xdb, 0xd8, 0x40, 0x6a, 0x89,
    0xb5, 0xde, 0x91, 0x81, 0x21, 0xb8, 0xe8, 0x1c, 0x7d, 0xf5, 0xf0, 0x97,
    0x89, 0x4c, 0x5e, 0x5b, 0x2d, 0xaf, 0x71, 0x7e, 0x6b, 0x93, 0x54, 0xee,
    0x8c, 0x4f, 0x1c, 0x06, 0x0c, 0x67, 0x33, 0x14, 0x86, 0x32, 0xec, 0xca,
    0x65, 0xc9, 0xc6, 0x21, 0xc2, 0x13, 0x24, 0x52, 0xd2, 0xec, 0xf6, 0x38,
    0x53, 0x5e, 0x63, 0x69, 0x75, 0x95, 0x24, 0x4d, 0xb1, 0x96, 0x23, 0x97,
    0x57, 0x0f, 0x57, 0x3f, 0xd7, 0xe2, 0xd7, 0xbf, 0x7a, 0xfd, 0x0f, 0xb9,
    0x38, 0x7e, 0x78, 0xcf, 0xee, 0xdd, 0x4c, 0x4f, 0x4e, 0x32, 0x9c, 0xcd,
    0x10, 0x06, 0x01, 0x9e, 0x00, 0x63, 0x2d, 0x52, 0x69, 0xfa, 0x69, 0x4a,
    0xb5, 0xbe, 0xc9, 0x46, 0xb5, 0x42, 0xb3, 0xd3, 0x25, 0x91, 0x29, 0xc6,
    0xd8, 0x37, 0xdf, 0x79, 0xe7, 0xd9, 0x5f, 0x72, 0x85, 0x5d, 0xeb, 0x47,
    0x13, 0x87, 0x1f, 0x5b, 0x7c, 0x25, 0x08, 0xfc, 0xdf, 0xe4, 0xe2, 0x98,
    0xfc, 0x50, 0x9e, 0xc2, 0xf0, 0x30, 0x41, 0xe0, 0x23, 0xa5, 0xa4, 0xdb,
    0xeb, 0xd1, 0x6c, 0xb7, 0xe9, 0x27, 0x92, 0x44, 0xa6, 0x68, 0xa3, 0x9b,
    0xce, 0xb9, 0xc7, 0xdf, 0x7e, 0xfb, 0xd9, 0xdf, 0x5f, 0x99, 0xe8, 0x3f,
    0x09, 0x00, 0xf0, 0xe8, 0xa3, 0x2f, 0xff, 0x24, 0xf0, 0xfd, 0x27, 0x02,
    0x11, 0x1c, 0x8c, 0xc2, 0x00, 0x21, 0xc0, 0x5a, 0x87, 0x54, 0x9a, 0x54,
    0x49, 0xa4, 0x32, 0x4d, 0x63, 0xf5, 0x31, 0x29, 0x83, 0xc7, 0xdf, 0x7f,
    0xff, 0xa9, 0xd6, 0x35, 0x93, 0x7c, 0x97, 0xc0, 0x45, 0x7b, 0xe8, 0xa1,
    0x97, 0x0a, 0x61, 0xa8, 0x17, 0x40, 0xcc, 0xef, 0x44, 0x6c, 0xd3, 0x39,
    0xff, 0xd4, 0x95, 0x77, 0xfd, 0x7f, 0x0b, 0x7c, 0x5f, 0xfb, 0x37, 0x71,
    0x0c, 0xd8, 0x66, 0xa7, 0xad, 0x85, 0xb9, 0x00, 0x00, 0x00, 0x00, 0x49,
    0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image1_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xe0, 0x77, 0x3d, 0xf8, 0x00, 0x00, 0x05,
    0x05, 0x49, 0x44, 0x41, 0x54, 0x48, 0x89, 0xb5, 0x95, 0x4b, 0x6c, 0x9c,
    0xd5, 0x15, 0xc7, 0x7f, 0xf7, 0x7b, 0xcd, 0x7c, 0x9e, 0x19, 0x8f, 0x2d,
    0xd7, 0x8e, 0x13, 0xd2, 0x94, 0x48, 0x58, 0x44, 0x22, 0xa2, 0x46, 0x59,
    0x40, 0x25, 0xd4, 0x5a, 0x95, 0x00, 0xa9, 0xf5, 0x22, 0x52, 0x04, 0x95,
    0x10, 0x20, 0xb1, 0x00, 0x21, 0x5e, 0x22, 0x62, 0x11, 0xa1, 0x20, 0x4d,
    0x90, 0xb2, 0x00, 0x89, 0xa8, 0xa6, 0x74, 0xc3, 0xae, 0x2d, 0x8f, 0x05,
    0x5d, 0x90, 0x45, 0x55, 0xd2, 0x45, 0xab, 0xa1, 0x74, 0x55, 0xa9, 0x24,
    0x66, 0x13, 0xdb, 0xc9, 0x10, 0x0f, 0x72, 0xc6, 0xf9, 0x6c, 0xe3, 0x79,
    0x8f, 0xe7, 0xbb, 0x4f, 0x16, 0x26, 0x56, 0x26, 0x09, 0x01, 0x81, 0x7a,
    0x56, 0xf7, 0x5e, 0x1d, 0x9d, 0xdf, 0xf9, 0x5f, 0xfd, 0xcf, 0xbd, 0xc2,
    0x39, 0xc7, 0xff, 0x33, 0x82, 0xef, 0x93, 0xf4, 0xfa, 0xeb, 0x67, 0x6e,
    0xd7, 0x5a, 0x4f, 0x1b, 0xa3, 0xa7, 0xad, 0xd5, 0x18, 0x63, 0x1a, 0xc6,
    0xb8, 0x4f, 0xb2, 0xd9, 0xc5, 0xf9, 0xab, 0x39, 0x27, 0x4e, 0x94, 0x9c,
    0x73, 0xdc, 0xd0, 0xad, 0xb8, 0x95, 0x82, 0x53, 0xa7, 0xfe, 0x79, 0xd8,
    0x39, 0x57, 0x0a, 0x82, 0x60, 0x3a, 0x8a, 0x22, 0xc2, 0x30, 0x44, 0x6b,
    0x4d, 0xbb, 0xdd, 0xa2, 0xd5, 0x6a, 0x92, 0xa6, 0xfd, 0xaa, 0x52, 0xe6,
    0xdd, 0x34, 0x4d, 0xdf, 0x9e, 0x9c, 0x4c, 0x36, 0x01, 0x5b, 0x2a, 0x95,
    0xec, 0x77, 0x2a, 0x98, 0x9b, 0x2b, 0x8f, 0x08, 0xe1, 0x7f, 0xb4, 0x7b,
    0xf7, 0xe4, 0xcc, 0xc1, 0x83, 0xfb, 0x18, 0x1d, 0x8d, 0xc9, 0x66, 0x03,
    0x94, 0x82, 0x76, 0x5b, 0xd2, 0x6c, 0xf6, 0xb9, 0x7c, 0x79, 0x9d, 0x6a,
    0x75, 0xf9, 0x67, 0xb5, 0xda, 0xea, 0xab, 0xd6, 0xea, 0x27, 0x92, 0x64,
    0xe2, 0x77, 0xc6, 0xf8, 0xff, 0x13, 0x82, 0x01, 0x25, 0x37, 0x28, 0x98,
    0x9b, 0x2b, 0x4f, 0x87, 0x61, 0x54, 0xbe, 0xff, 0xfe, 0xbb, 0x8a, 0x53,
    0x53, 0x45, 0x5a, 0x2d, 0xc3, 0xda, 0x9a, 0xa4, 0x5e, 0xef, 0xd3, 0xeb,
    0xa5, 0x58, 0xab, 0x89, 0x22, 0x9f, 0x4c, 0x26, 0x42, 0x29, 0xc3, 0xc5,
    0x8b, 0x15, 0x56, 0x56, 0xbe, 0x64, 0x73, 0x73, 0xb3, 0xa9, 0x94, 0xfa,
    0xcd, 0x6d, 0xb7, 0xd5, 0xff, 0x5b, 0x2a, 0x95, 0xf4, 0x4d, 0x15, 0xcc,
    0xcd, 0x95, 0x47, 0x3c, 0xcf, 0x2f, 0x3f, 0xf0, 0xc0, 0x3d, 0xc5, 0xbd,
    0x7b, 0x63, 0x96, 0x97, 0x2d, 0xcd, 0xa6, 0x46, 0x29, 0x83, 0xd6, 0x0e,
    0x21, 0xc0, 0x18, 0x47, 0xb3, 0xd9, 0x25, 0x4d, 0x37, 0x71, 0xce, 0x32,
    0x31, 0x31, 0x49, 0xbf, 0x9f, 0xa2, 0x94, 0x2e, 0xd6, 0xeb, 0xf5, 0xbf,
    0xd7, 0x6a, 0x63, 0xf7, 0x09, 0xc1, 0xe2, 0x55, 0x15, 0xde, 0xb5, 0x00,
    0xa5, 0xd4, 0x47, 0x87, 0x0e, 0x1d, 0x28, 0x8e, 0x8f, 0x67, 0x39, 0x7f,
    0x5e, 0x73, 0xf6, 0xec, 0x12, 0x69, 0x2a, 0xb9, 0x56, 0xe5, 0xca, 0xca,
    0x65, 0x84, 0x10, 0x00, 0xa4, 0x69, 0x4a, 0x92, 0x24, 0xc4, 0xf1, 0x10,
    0xa3, 0xa3, 0x63, 0xf8, 0xbe, 0x57, 0xd4, 0x5a, 0xbd, 0xf9, 0xf0, 0xc3,
    0x7f, 0xdd, 0xa9, 0xbb, 0xb3, 0x38, 0x79, 0xf2, 0x6f, 0x33, 0x23, 0x23,
    0xc3, 0x33, 0x77, 0xde, 0xf9, 0x13, 0x2e, 0x5c, 0xe8, 0xb1, 0xb5, 0xa5,
    0x58, 0x5a, 0x5a, 0xe2, 0xcc, 0x99, 0x33, 0x74, 0x3a, 0x6d, 0xac, 0xb5,
    0xd4, 0xeb, 0x4d, 0xe6, 0xe7, 0x3f, 0x67, 0x61, 0x61, 0x09, 0x70, 0x38,
    0xe7, 0x50, 0x4a, 0xd2, 0xeb, 0x75, 0x11, 0x02, 0x8a, 0xc5, 0x51, 0x9c,
    0x73, 0xbf, 0xcd, 0x64, 0x2a, 0xfb, 0x6f, 0x00, 0x38, 0xe7, 0x4a, 0x07,
    0x0f, 0xde, 0x41, 0xad, 0xd6, 0xa3, 0xd3, 0x91, 0x68, 0xad, 0x38, 0x70,
    0x60, 0x17, 0xf9, 0xbc, 0xc7, 0xc7, 0x1f, 0xff, 0x83, 0x24, 0x59, 0x43,
    0xca, 0x94, 0x97, 0x5f, 0x9e, 0x65, 0x63, 0x23, 0x61, 0x71, 0xf1, 0x02,
    0x4a, 0x29, 0xac, 0xb5, 0x48, 0x29, 0x71, 0xce, 0x32, 0x34, 0x94, 0xc3,
    0x13, 0x20, 0x84, 0x78, 0x71, 0x00, 0xf0, 0xda, 0x6b, 0xa7, 0x47, 0x82,
    0xc0, 0x9f, 0x19, 0x1d, 0xcd, 0x73, 0xe5, 0x4a, 0x07, 0xad, 0x35, 0x4a,
    0x29, 0x26, 0x26, 0x86, 0x39, 0x7e, 0xfc, 0x08, 0x0f, 0x3d, 0x74, 0x37,
    0x9f, 0x7e, 0xfa, 0x1f, 0xbe, 0xf8, 0xe2, 0x12, 0x53, 0x53, 0x7b, 0x38,
    0x79, 0xf2, 0x51, 0x8a, 0xc5, 0x90, 0xc5, 0xc5, 0x8b, 0x68, 0xa5, 0x11,
    0x0e, 0x3c, 0x3c, 0x32, 0xa1, 0x4f, 0x10, 0x46, 0x38, 0xe7, 0x7e, 0x3e,
    0x00, 0x50, 0x2a, 0xfd, 0x55, 0x14, 0x45, 0x48, 0x69, 0x48, 0x53, 0x85,
    0x52, 0x0a, 0xad, 0x15, 0x5a, 0x6b, 0xa4, 0x84, 0x07, 0x1f, 0x3c, 0xc4,
    0xb1, 0x63, 0x47, 0xf0, 0xfd, 0xed, 0x7d, 0x10, 0x44, 0x3c, 0xff, 0xfc,
    0x2c, 0xf7, 0xde, 0x3b, 0x45, 0xa5, 0xb2, 0x8c, 0x56, 0x92, 0x28, 0xf0,
    0xf0, 0x3c, 0x8f, 0x4c, 0x14, 0xe2, 0x9c, 0xfb, 0xe5, 0x80, 0x8b, 0x8c,
    0x71, 0xd3, 0x61, 0x18, 0x52, 0xab, 0xd5, 0xd1, 0x5a, 0xe1, 0x79, 0x1e,
    0x42, 0x08, 0xf6, 0xed, 0x1b, 0x43, 0xca, 0xed, 0xc4, 0xf1, 0xf1, 0x31,
    0x8e, 0x1e, 0x3d, 0xb2, 0xb3, 0x07, 0x98, 0x9d, 0xfd, 0x05, 0xfb, 0xf7,
    0xef, 0xa1, 0xfc, 0xaf, 0xcf, 0xc9, 0x04, 0x01, 0xce, 0x39, 0x04, 0x62,
    0xc0, 0x14, 0x01, 0xc0, 0x37, 0xe3, 0x4f, 0xb3, 0xd1, 0xc6, 0xf7, 0x3d,
    0x8c, 0xd8, 0x06, 0x68, 0xbd, 0x3d, 0x5c, 0xb7, 0x8a, 0x3d, 0xbb, 0x27,
    0xb8, 0xfd, 0xa7, 0xbb, 0xd8, 0x6a, 0xf7, 0xd1, 0xd6, 0x60, 0xad, 0x01,
    0xae, 0x03, 0x68, 0x6d, 0xd1, 0x4a, 0x62, 0xad, 0x46, 0xe0, 0xe3, 0x30,
    0x68, 0xad, 0xd1, 0x3a, 0xde, 0xe9, 0xf8, 0xd2, 0xa5, 0x84, 0xf9, 0xf9,
    0x45, 0x0e, 0x1f, 0xde, 0x56, 0x2f, 0xa5, 0x62, 0xe1, 0x7c, 0x95, 0xca,
    0x42, 0x95, 0x5c, 0x26, 0x8b, 0xef, 0xfb, 0x38, 0x67, 0xd9, 0xda, 0xea,
    0x01, 0x9c, 0x1b, 0x00, 0x38, 0x67, 0xca, 0xed, 0x76, 0x1b, 0x9c, 0x45,
    0xb8, 0x6d, 0x89, 0xcd, 0x46, 0x93, 0x5c, 0x6e, 0x3f, 0x49, 0xd2, 0xa2,
    0x52, 0x59, 0x65, 0x63, 0xa3, 0x49, 0xaf, 0x97, 0x22, 0x25, 0x5c, 0x5e,
    0x59, 0xe3, 0xdc, 0xd9, 0x05, 0xd0, 0x9a, 0x42, 0x9c, 0x25, 0x0a, 0x03,
    0x52, 0xa5, 0xe8, 0x76, 0xbb, 0x68, 0x63, 0x70, 0x8e, 0xf2, 0x00, 0xa0,
    0xdb, 0x55, 0xe7, 0x7c, 0xd1, 0x45, 0xa6, 0x7d, 0xa2, 0x38, 0x26, 0xf0,
    0x05, 0xf9, 0x38, 0x43, 0xb2, 0x5a, 0xa7, 0x5a, 0xad, 0xa1, 0xb5, 0xc1,
    0x58, 0x4b, 0x71, 0xb8, 0xc0, 0xbf, 0xcb, 0x9f, 0xd1, 0xf8, 0xaa, 0x4e,
    0x36, 0x0c, 0x28, 0xe4, 0x73, 0xc4, 0x99, 0x10, 0x6d, 0x0c, 0x5d, 0x63,
    0x59, 0x4d, 0x12, 0x8c, 0x31, 0x80, 0x77, 0x7a, 0xc0, 0x45, 0xef, 0xbc,
    0xf3, 0x74, 0xd3, 0x58, 0xf5, 0xee, 0x5a, 0x72, 0x05, 0xe1, 0x2c, 0x91,
    0x27, 0x18, 0x1b, 0x1e, 0xa2, 0xb5, 0xbe, 0x49, 0x2e, 0xf4, 0x89, 0x43,
    0x8f, 0x38, 0xf0, 0x10, 0x4a, 0x63, 0xb6, 0xb6, 0x18, 0x2b, 0xe4, 0x98,
    0x18, 0x29, 0x30, 0x92, 0x8f, 0xf1, 0x3d, 0x41, 0xaa, 0x35, 0xab, 0x6b,
    0x09, 0x9d, 0x6e, 0x17, 0xeb, 0x6c, 0xf9, 0x83, 0x0f, 0x5e, 0xf9, 0x64,
    0x40, 0x01, 0x80, 0x30, 0xe6, 0xf7, 0x6b, 0xeb, 0xeb, 0x8f, 0x17, 0x0b,
    0x79, 0xf6, 0x8c, 0x8f, 0x93, 0x8d, 0x42, 0xe2, 0xc0, 0xc7, 0xba, 0x08,
    0xad, 0x0d, 0xd6, 0x3a, 0x84, 0x70, 0x78, 0xc2, 0x23, 0xf0, 0x04, 0x42,
    0x08, 0xa4, 0xd6, 0xf4, 0xa4, 0x24, 0xd9, 0xd8, 0xa0, 0xba, 0xb2, 0x82,
    0xd4, 0x12, 0x6b, 0xbd, 0x13, 0xd7, 0x9a, 0x60, 0x67, 0x92, 0x4f, 0xfd,
    0xe1, 0x99, 0xb3, 0x7d, 0xd9, 0x7f, 0xbb, 0xb2, 0x5c, 0xe5, 0xca, 0xc6,
    0x3a, 0xa9, 0xdc, 0xb6, 0x4f, 0x26, 0x0c, 0x28, 0xc4, 0x59, 0x8a, 0xb9,
    0x2c, 0xc3, 0x43, 0x31, 0x71, 0x26, 0x44, 0x78, 0x82, 0xbe, 0x94, 0x34,
    0x3a, 0x5d, 0x2e, 0x2c, 0x57, 0x59, 0xac, 0x54, 0xe8, 0xa7, 0x29, 0xd6,
    0x72, 0xe2, 0xda, 0xee, 0xe1, 0xc6, 0xe7, 0x5a, 0x3c, 0xf7, 0xec, 0x1f,
    0xff, 0x32, 0x94, 0xc9, 0x3c, 0xb6, 0x7b, 0xd7, 0x2e, 0xf6, 0x4e, 0x4e,
    0x52, 0x88, 0xb3, 0x84, 0x41, 0x80, 0x27, 0xc0, 0x58, 0x8b, 0x54, 0x9a,
    0x5e, 0x9a, 0xb2, 0xba, 0xb6, 0xce, 0xca, 0x6a, 0x8d, 0x46, 0xbb, 0x43,
    0x5f, 0xa6, 0x18, 0x63, 0xff, 0xf4, 0xfe, 0xfb, 0xc7, 0x9f, 0xbc, 0xde,
    0xc6, 0x37, 0xfb, 0xd1, 0xc4, 0x33, 0x4f, 0xcf, 0xbd, 0x15, 0x04, 0xfe,
    0x0b, 0x43, 0x99, 0x0c, 0xf9, 0x5c, 0x9e, 0x62, 0xa1, 0x40, 0x10, 0xf8,
    0x48, 0x29, 0xe9, 0x74, 0xbb, 0x34, 0x5a, 0x2d, 0x7a, 0x7d, 0x49, 0x5f,
    0xa6, 0x68, 0xa3, 0x1b, 0xce, 0xb9, 0x97, 0xde, 0x7b, 0xef, 0xf8, 0x9f,
    0xaf, 0x2f, 0xf4, 0x6d, 0x00, 0x00, 0x9e, 0x7a, 0xea, 0xcd, 0x5f, 0x07,
    0xbe, 0x7f, 0x34, 0x10, 0xc1, 0x6c, 0x14, 0x06, 0x08, 0x01, 0xd6, 0x3a,
    0xa4, 0xd2, 0xa4, 0x4a, 0x22, 0x95, 0x69, 0x18, 0xab, 0x4f, 0x4b, 0x19,
    0xbc, 0xf4, 0xe1, 0x87, 0xc7, 0x9a, 0x37, 0x2d, 0x72, 0x2b, 0xc0, 0xd5,
    0x78, 0xe4, 0x91, 0x37, 0x8a, 0x61, 0xa8, 0x67, 0x40, 0x4c, 0x6f, 0x9f,
    0xd8, 0x86, 0x73, 0xfe, 0xb9, 0xeb, 0xef, 0xfa, 0x07, 0x03, 0x7e, 0x6c,
    0x7c, 0x0d, 0xe2, 0x16, 0xda, 0xc3, 0xa5, 0x00, 0x07, 0xce, 0x00, 0x00,
    0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image2_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xc2, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0x8d, 0xd2, 0x5b, 0x68, 0x93,
    0x77, 0x18, 0xc7, 0xf1, 0xef, 0x3f, 0xef, 0xfb, 0x26, 0xb1, 0x6d, 0x1a,
    0x1b, 0xe9, 0xc9, 0xb6, 0x69, 0x17, 0xcf, 0x53, 0xeb, 0x01, 0xe9, 0x26,
    0x1e, 0x6e, 0x6c, 0xb1, 0xe0, 0xc0, 0x8b, 0x0d, 0x15, 0x44, 0x44, 0xf1,
    0x40, 0xbb, 0x4d, 0x6f, 0x36, 0x44, 0xbc, 0x12, 0xb5, 0x73, 0x38, 0x1c,
    0x73, 0xbb, 0x72, 0xb0, 0xa1, 0xb0, 0x8d, 0x89, 0x22, 0xbd, 0x11, 0xf4,
    0x6a, 0xb3, 0x07, 0xd1, 0xd2, 0xd8, 0xe2, 0x21, 0xa6, 0xb1, 0x69, 0x73,
    0x40, 0xa2, 0xb1, 0x36, 0x6d, 0x12, 0x93, 0xf7, 0x7d, 0x93, 0xfc, 0xbd,
    0x51, 0xec, 0x96, 0x0e, 0xf6, 0x83, 0xe7, 0xf6, 0xc3, 0x73, 0x12, 0x52,
    0x4a, 0xde, 0x45, 0x1c, 0xbe, 0xa8, 0xa1, 0xb8, 0xf6, 0xa2, 0x28, 0x07,
    0x11, 0x85, 0x16, 0x32, 0xa9, 0x49, 0x32, 0x89, 0x5b, 0x28, 0xe2, 0x27,
    0x79, 0xe9, 0x48, 0x2f, 0xb3, 0x44, 0xbc, 0x03, 0xc4, 0xc9, 0x3b, 0x2e,
    0x74, 0xe3, 0xd2, 0x87, 0xb5, 0xe5, 0x9f, 0xb4, 0x7a, 0x5c, 0x54, 0x3a,
    0x4a, 0x78, 0x1a, 0x4f, 0x73, 0xdb, 0x37, 0xca, 0x58, 0xd0, 0x9f, 0x24,
    0x9b, 0x3c, 0x21, 0x7f, 0x3f, 0xf6, 0xe3, 0xac, 0x80, 0x38, 0xf9, 0xd8,
    0x4a, 0x6e, 0xb2, 0x7b, 0xe7, 0x1a, 0x77, 0xfb, 0x85, 0xf6, 0x06, 0x46,
    0x26, 0x24, 0xc7, 0xbb, 0xef, 0x60, 0x2b, 0x71, 0xe2, 0xaa, 0xae, 0xe7,
    0x71, 0x68, 0x1c, 0xbf, 0xb7, 0x07, 0x99, 0x4e, 0x1e, 0xca, 0xfd, 0x71,
    0xfc, 0xe7, 0x99, 0x80, 0x05, 0x80, 0x44, 0xf0, 0x8b, 0xa5, 0x35, 0x8e,
    0xf6, 0xb3, 0x5b, 0x1a, 0x08, 0x4d, 0xc3, 0xc5, 0xc1, 0x38, 0xbd, 0x8f,
    0xc6, 0xe9, 0xf5, 0x3d, 0x25, 0x94, 0x7a, 0x8d, 0xa5, 0xba, 0x1e, 0xe7,
    0xe2, 0x15, 0xa8, 0x9a, 0x38, 0x23, 0xb6, 0x7e, 0x5d, 0x55, 0x0c, 0x20,
    0x3a, 0xda, 0x3c, 0x2e, 0x86, 0x63, 0x3a, 0x1d, 0xd7, 0x1e, 0xd0, 0x33,
    0x12, 0x00, 0xab, 0x42, 0xc1, 0xcc, 0x32, 0xfa, 0xd0, 0xcb, 0x44, 0x64,
    0x84, 0x0a, 0xb7, 0x1b, 0xcd, 0xe1, 0xac, 0xc4, 0xaa, 0x6e, 0x98, 0x09,
    0xa8, 0x00, 0x48, 0x73, 0x61, 0x85, 0xdd, 0xc6, 0x9f, 0xc3, 0x51, 0x06,
    0x87, 0x86, 0x41, 0x13, 0xa0, 0x08, 0x4c, 0x23, 0xc3, 0xc4, 0xf3, 0x28,
    0x8c, 0xc1, 0xca, 0x4f, 0x3f, 0x43, 0x2b, 0x29, 0x05, 0x21, 0x97, 0x14,
    0x03, 0x99, 0x64, 0xcc, 0xff, 0x3c, 0x51, 0x53, 0xee, 0xaa, 0x64, 0x59,
    0xf3, 0x72, 0xa6, 0xa6, 0x13, 0x3c, 0x0b, 0x07, 0xd1, 0x34, 0x85, 0xf9,
    0x2d, 0xeb, 0xa8, 0xa8, 0xaf, 0x42, 0x28, 0x02, 0x23, 0x95, 0x02, 0xa9,
    0x46, 0x8a, 0x47, 0xd0, 0x53, 0xd7, 0xff, 0xf2, 0x05, 0xc8, 0x08, 0x0b,
    0xee, 0x25, 0x1e, 0x6a, 0x1b, 0xeb, 0x20, 0x39, 0x85, 0xcd, 0xa6, 0xb0,
    0x6c, 0xd3, 0x3a, 0xe6, 0x2d, 0x58, 0xc0, 0x44, 0x28, 0x84, 0x39, 0x19,
    0xcf, 0x13, 0x6f, 0xfa, 0xbb, 0x18, 0xb0, 0x99, 0x67, 0x5f, 0xc4, 0xa2,
    0x91, 0xfe, 0x07, 0x43, 0x24, 0x0b, 0x39, 0xec, 0x35, 0x2e, 0xea, 0x56,
    0xad, 0xa0, 0x71, 0x75, 0x33, 0x69, 0x03, 0x42, 0x43, 0x0f, 0x09, 0xdf,
    0xf3, 0xd3, 0x3a, 0x77, 0x80, 0x9b, 0x6d, 0x07, 0x0f, 0xcc, 0xfa, 0x07,
    0xda, 0xbe, 0xef, 0xdb, 0xa5, 0x45, 0xed, 0x9e, 0x5b, 0x5b, 0x6b, 0x75,
    0xba, 0x9b, 0xb0, 0x39, 0xca, 0x28, 0x18, 0x06, 0x53, 0xa1, 0x31, 0x62,
    0xc3, 0x41, 0xd6, 0x7b, 0xc2, 0x5c, 0xfd, 0xfc, 0x15, 0x2f, 0xfa, 0xae,
    0x13, 0x7a, 0x94, 0xdc, 0xbf, 0xbd, 0x4b, 0xfe, 0xfa, 0x0f, 0x00, 0x40,
    0xec, 0xf8, 0x76, 0xa3, 0x50, 0x73, 0x17, 0xac, 0xaa, 0xba, 0x46, 0x55,
    0x2d, 0xe4, 0x0c, 0x93, 0x9c, 0x61, 0xb2, 0xab, 0xd9, 0xa4, 0x6b, 0xfb,
    0x7d, 0x1a, 0x3c, 0xaf, 0x49, 0x25, 0xd7, 0xd2, 0x7f, 0xf9, 0x7c, 0x6c,
    0xf4, 0x09, 0x2d, 0x9d, 0xbf, 0xc8, 0x88, 0x65, 0x66, 0x3b, 0xf2, 0xca,
    0xb1, 0x5e, 0x39, 0xd0, 0xb7, 0x5e, 0x9f, 0x9e, 0xfa, 0x38, 0x3d, 0xa9,
    0x77, 0x7a, 0x52, 0xde, 0x73, 0x27, 0xaa, 0xae, 0x71, 0x6a, 0x63, 0x98,
    0x6a, 0xc7, 0x7c, 0x5e, 0x8e, 0x47, 0x50, 0x88, 0x52, 0x5e, 0xf7, 0x41,
    0x0d, 0x70, 0xf4, 0xfd, 0x15, 0x66, 0x22, 0x81, 0x1b, 0x3a, 0x70, 0xf7,
    0x6d, 0xf1, 0xdd, 0xbe, 0xf2, 0x8f, 0xee, 0x7b, 0x4b, 0x37, 0xdb, 0xcb,
    0x96, 0x92, 0xd7, 0xdd, 0x98, 0xd3, 0x4f, 0xd0, 0x54, 0x27, 0x66, 0x9e,
    0x6d, 0xc0, 0x57, 0x45, 0xc0, 0xbf, 0x93, 0xd6, 0xf5, 0x2f, 0x83, 0xbe,
    0xd1, 0x3e, 0x4d, 0xc9, 0x97, 0x2d, 0x5e, 0xa8, 0xa1, 0x6a, 0x56, 0x02,
    0xbe, 0x20, 0x89, 0x34, 0x63, 0x45, 0x3b, 0xf8, 0xaf, 0x7c, 0xb3, 0x67,
    0xce, 0x26, 0xa1, 0xda, 0x7f, 0x9b, 0x57, 0x59, 0xda, 0x20, 0x0b, 0x06,
    0xcf, 0xc2, 0x71, 0x6f, 0xbe, 0xc0, 0xae, 0x53, 0x57, 0x65, 0xe0, 0x7f,
    0x01, 0x00, 0xa7, 0x77, 0xdb, 0x17, 0x65, 0xb3, 0xf9, 0x03, 0x39, 0x33,
    0x97, 0x35, 0xec, 0xfc, 0x70, 0xfe, 0x8a, 0x7c, 0x05, 0xf0, 0x06, 0xcf,
    0xaf, 0x31, 0x9a, 0x6d, 0x4a, 0x96, 0xaf, 0x00, 0x00, 0x00, 0x00, 0x49,
    0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image3_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0x9f, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0xcf, 0x4b, 0x93,
    0x71, 0x1c, 0xc7, 0xdf, 0xdf, 0xe7, 0xf9, 0xee, 0xd9, 0x96, 0xcf, 0x7e,
    0xb8, 0x74, 0x96, 0x95, 0x03, 0x69, 0xc3, 0x22, 0x8b, 0xd0, 0x25, 0x21,
    0x41, 0x7f, 0x80, 0x10, 0x15, 0xf3, 0x22, 0x78, 0x89, 0x8c, 0xa0, 0x0e,
    0x41, 0xe1, 0x49, 0xc6, 0x0e, 0x9d, 0x82, 0x0e, 0x0a, 0x49, 0x18, 0x75,
    0xa8, 0x40, 0x57, 0x82, 0x87, 0xce, 0x9d, 0x72, 0x58, 0xa6, 0x96, 0x69,
    0x35, 0xcd, 0x6d, 0x9a, 0xca, 0xa6, 0x6e, 0xcf, 0x74, 0x3f, 0x9e, 0x67,
    0xcf, 0xaf, 0x6f, 0x87, 0x28, 0xbc, 0x14, 0x82, 0xef, 0xe3, 0xfb, 0xf3,
    0x7e, 0xbf, 0x4e, 0xef, 0x0f, 0x61, 0x8c, 0x61, 0x3f, 0xe2, 0xf6, 0xd5,
    0x06, 0x40, 0x23, 0x91, 0x57, 0x42, 0x36, 0xab, 0xda, 0xfa, 0xfb, 0xbb,
    0x76, 0x76, 0x1f, 0x7a, 0x7a, 0x5e, 0x76, 0x50, 0xca, 0xf5, 0x39, 0x1c,
    0xc2, 0x39, 0x10, 0x86, 0xbc, 0x94, 0x4b, 0xe4, 0xf3, 0xdb, 0xf7, 0x47,
    0x46, 0xee, 0x3d, 0xdd, 0x9d, 0x23, 0xbd, 0xbd, 0xd1, 0x06, 0x4d, 0xa3,
    0x43, 0xaa, 0x6a, 0x3e, 0x1f, 0x18, 0xb8, 0xfa, 0x22, 0x12, 0xf9, 0x2a,
    0x48, 0xd2, 0xd2, 0x83, 0x43, 0x75, 0x55, 0xb7, 0x9b, 0x4e, 0x1e, 0x25,
    0x35, 0x07, 0xdd, 0x60, 0x26, 0x90, 0xdf, 0x2e, 0x22, 0x16, 0xfb, 0xa8,
    0x27, 0x93, 0xc9, 0x5b, 0xc3, 0xc3, 0xbd, 0x8f, 0xff, 0x02, 0xba, 0xbb,
    0x07, 0x8f, 0xf8, 0x7c, 0xbe, 0x99, 0xba, 0x3a, 0x67, 0x6d, 0x3c, 0x9e,
    0x1e, 0x02, 0xe0, 0x0d, 0x06, 0xfd, 0x97, 0xce, 0x07, 0xfd, 0xd0, 0xf3,
    0x26, 0xa4, 0x8d, 0x6d, 0xc8, 0x8a, 0x02, 0x66, 0xe3, 0x41, 0x5d, 0x0e,
    0x8c, 0x8d, 0xbd, 0xd1, 0x57, 0x56, 0x92, 0x6d, 0xa3, 0xa3, 0xe1, 0x69,
    0x00, 0xa0, 0xa9, 0xd4, 0x9a, 0x10, 0x08, 0x34, 0x1a, 0xa1, 0x50, 0x1b,
    0x26, 0x26, 0xbe, 0x5f, 0x57, 0x14, 0x0e, 0xed, 0x2d, 0x27, 0x90, 0x5e,
    0xcc, 0x63, 0x3e, 0xbe, 0x88, 0xf5, 0xad, 0x4d, 0x78, 0x44, 0x11, 0xb5,
    0x0e, 0x11, 0xb4, 0xac, 0xe0, 0xf4, 0x99, 0x53, 0x74, 0x75, 0xf5, 0xe7,
    0x35, 0x00, 0xbf, 0x01, 0x1c, 0x57, 0x71, 0x01, 0x46, 0x5d, 0x66, 0x43,
    0x87, 0x3f, 0xe0, 0x87, 0x9d, 0x12, 0xcc, 0x4e, 0xad, 0x60, 0x66, 0x6e,
    0x0e, 0xcb, 0x99, 0x75, 0xb9, 0xa2, 0x69, 0x92, 0x85, 0xa0, 0x3e, 0x18,
    0x68, 0x82, 0x97, 0x10, 0xb8, 0x6b, 0x5d, 0x10, 0x45, 0x7b, 0x47, 0x7b,
    0xfb, 0xcd, 0xc8, 0xf8, 0xf8, 0xe0, 0x06, 0xb7, 0xb5, 0x95, 0x31, 0x05,
    0x01, 0xa4, 0x20, 0x95, 0xb1, 0xb6, 0x90, 0xc5, 0xea, 0xbc, 0x84, 0xa9,
    0xcf, 0xd3, 0x98, 0x4b, 0xc4, 0xa5, 0x4a, 0x45, 0xbe, 0x50, 0xe6, 0x2a,
    0xcd, 0x45, 0xb9, 0xf0, 0xfa, 0xc7, 0xda, 0x32, 0x44, 0x6a, 0x85, 0x59,
    0x94, 0xe1, 0x76, 0xbb, 0x1b, 0x78, 0xde, 0x0c, 0x02, 0x00, 0x57, 0xe5,
    0x3c, 0xe0, 0x67, 0x8c, 0xc1, 0x28, 0x6a, 0x70, 0xe9, 0x1c, 0x3c, 0x44,
    0xc0, 0xd9, 0xe3, 0x4d, 0xf0, 0x56, 0x3b, 0xed, 0x85, 0x82, 0xd4, 0x1c,
    0x7d, 0x72, 0x27, 0x57, 0x96, 0x0b, 0x93, 0x25, 0xb9, 0x88, 0x2a, 0x8b,
    0x0d, 0xb4, 0xa2, 0xc3, 0x30, 0x34, 0x58, 0xed, 0xb6, 0x46, 0x00, 0xa0,
    0x1e, 0x97, 0xe8, 0xc9, 0x6e, 0x6e, 0xe2, 0xd3, 0x97, 0x59, 0x30, 0x45,
    0x85, 0xa6, 0x69, 0x28, 0xa9, 0x0a, 0x54, 0x55, 0xb6, 0xf1, 0x1c, 0x7b,
    0x16, 0x0a, 0x45, 0x52, 0x86, 0xa1, 0x9b, 0x94, 0x10, 0xd8, 0xa9, 0x00,
    0x41, 0x25, 0xd0, 0x55, 0x15, 0x56, 0xab, 0xad, 0x09, 0x00, 0xa8, 0x28,
    0x8a, 0x8e, 0xd4, 0x72, 0x0a, 0x89, 0x64, 0x62, 0x47, 0x37, 0xcc, 0xbc,
    0x61, 0x6a, 0xdb, 0x0c, 0x2c, 0x4e, 0x39, 0x3a, 0x2f, 0x08, 0x34, 0xc9,
    0x73, 0xfa, 0x12, 0x35, 0xf8, 0xae, 0x1a, 0x67, 0x35, 0xec, 0x54, 0x00,
    0x18, 0x81, 0x69, 0x32, 0xc0, 0x64, 0x6b, 0x00, 0x40, 0x01, 0x7c, 0xd0,
    0x0d, 0xed, 0x4a, 0x85, 0xb1, 0xc5, 0x5c, 0x46, 0x5e, 0x8a, 0xc5, 0x1e,
    0xca, 0xbb, 0x87, 0xd2, 0xda, 0x7a, 0xc3, 0xe2, 0xf3, 0x79, 0x5b, 0x0e,
    0x57, 0x7b, 0x61, 0xe1, 0x79, 0x14, 0x35, 0x05, 0x25, 0xb9, 0x04, 0x42,
    0xf8, 0x6f, 0x00, 0x40, 0xa3, 0xd1, 0xf0, 0xbb, 0xff, 0x4d, 0xb5, 0x3e,
    0x50, 0xef, 0x42, 0xc5, 0x38, 0x96, 0x2e, 0xe4, 0x30, 0x9d, 0x4e, 0xe0,
    0xfd, 0xc2, 0x2c, 0xca, 0x72, 0x39, 0x27, 0x08, 0xb6, 0x49, 0x00, 0x20,
    0x7b, 0x79, 0xa6, 0xce, 0xce, 0xf0, 0x35, 0x42, 0xb8, 0x47, 0x1c, 0xe1,
    0x04, 0x45, 0x53, 0x67, 0x2c, 0x3c, 0xbd, 0x1b, 0x8d, 0x86, 0xdf, 0xee,
    0x19, 0x00, 0x00, 0x97, 0x43, 0x7d, 0x17, 0x89, 0x61, 0x88, 0x94, 0x5a,
    0x63, 0xd1, 0x68, 0x38, 0xf7, 0xc7, 0xdf, 0x33, 0xe0, 0x5f, 0xfa, 0x05,
    0xf1, 0xab, 0x36, 0xf5, 0x3e, 0x95, 0x6c, 0x8e, 0x00, 0x00, 0x00, 0x00,
    0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image4_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xe0, 0x77, 0x3d, 0xf8, 0x00, 0x00, 0x05,
    0xb1, 0x49, 0x44, 0x41, 0x54, 0x48, 0x89, 0xb5, 0x96, 0x7b, 0x6c, 0xd5,
    0x67, 0x19, 0xc7, 0x3f, 0xef, 0xef, 0x9c, 0xdf, 0xb9, 0xf7, 0x9c, 0xd3,
    0x1f, 0xa7, 0x1d, 0x2d, 0xbd, 0x50, 0x5a, 0xe9, 0xda, 0xca, 0xe8, 0xe8,
    0x60, 0x97, 0xd6, 0x39, 0x44, 0xdd, 0xcd, 0xbb, 0x35, 0xba, 0x64, 0xa0,
    0xd1, 0xc4, 0x84, 0x6d, 0x9a, 0xa8, 0xa8, 0xc9, 0xb2, 0xe1, 0x00, 0x8d,
    0x99, 0x99, 0x31, 0xa8, 0xd9, 0x34, 0xd1, 0xfa, 0x87, 0x26, 0x66, 0x83,
    0x41, 0xb6, 0x94, 0xad, 0x11, 0xcc, 0x46, 0x18, 0x5d, 0x4b, 0x07, 0x6b,
    0xa5, 0xd8, 0x32, 0x68, 0x01, 0x5b, 0x7a, 0x3d, 0xa7, 0xe7, 0xb4, 0xe7,
    0xb4, 0xfd, 0xdd, 0xde, 0xdf, 0xeb, 0x1f, 0x6e, 0x9d, 0x6c, 0xf2, 0x9f,
    0x7c, 0xff, 0x7c, 0xf3, 0xe6, 0xf9, 0x3c, 0xef, 0x73, 0x79, 0x9f, 0x47,
    0x28, 0xa5, 0xb8, 0x91, 0xd2, 0x6e, 0xa8, 0x75, 0xc0, 0xff, 0xc1, 0x83,
    0xee, 0xdf, 0x0b, 0xb1, 0x9c, 0x23, 0xee, 0xb8, 0xdc, 0x69, 0xdb, 0x7c,
    0xce, 0x76, 0xd8, 0xe4, 0xba, 0x34, 0x3a, 0x92, 0x22, 0xd7, 0xc1, 0x71,
    0x1c, 0xc6, 0xa5, 0xe2, 0x9c, 0xf4, 0x78, 0xc5, 0x95, 0xbc, 0xe6, 0x7a,
    0x8c, 0xee, 0xfa, 0x93, 0xb2, 0xaf, 0x07, 0x10, 0xff, 0x1d, 0xa2, 0xde,
    0x67, 0x45, 0x91, 0xe5, 0xf0, 0x65, 0xc7, 0xe6, 0x31, 0x4f, 0x05, 0x5b,
    0x7c, 0x91, 0x30, 0xfe, 0x48, 0x12, 0x9f, 0x5e, 0x84, 0x74, 0x15, 0xd2,
    0x95, 0x98, 0x8b, 0x79, 0xb2, 0x33, 0x59, 0x72, 0x73, 0x2e, 0x96, 0x6d,
    0x2f, 0x48, 0x57, 0xbd, 0xea, 0xba, 0x74, 0x38, 0x92, 0x93, 0x4f, 0x3e,
    0xaf, 0x16, 0xaf, 0x0b, 0xe8, 0x7d, 0x4e, 0x18, 0x9e, 0xc3, 0x7e, 0x29,
    0xf4, 0x87, 0x63, 0x95, 0x8d, 0x94, 0xdf, 0xf2, 0x35, 0xc2, 0x89, 0x0d,
    0x84, 0x8a, 0x92, 0xe8, 0x01, 0x0d, 0x4f, 0x2e, 0xa0, 0xdc, 0x45, 0x3c,
    0x99, 0x67, 0xa9, 0x30, 0xc9, 0xfc, 0xf4, 0x28, 0xa3, 0x67, 0xfa, 0xb8,
    0xd0, 0x3f, 0x4a, 0x66, 0xb6, 0x80, 0x6d, 0x79, 0x7f, 0x76, 0x24, 0x4f,
    0xee, 0x3b, 0xa4, 0xae, 0x7c, 0x08, 0xd0, 0xfd, 0x9c, 0x08, 0xba, 0x26,
    0xbf, 0xd2, 0x23, 0xe1, 0x9d, 0x15, 0xb7, 0x7f, 0x8b, 0x35, 0xcd, 0x4f,
    0x90, 0x3d, 0x3d, 0xce, 0x95, 0xce, 0x4e, 0xd0, 0xd3, 0x14, 0xb7, 0x05,
    0x88, 0xd5, 0x48, 0xec, 0xf9, 0x0c, 0x42, 0xd8, 0x08, 0xbf, 0x46, 0x30,
    0x10, 0x22, 0x14, 0x4b, 0x60, 0xe6, 0x16, 0x78, 0xfb, 0xf5, 0x3e, 0xfa,
    0x7b, 0x2f, 0x90, 0xcb, 0x5a, 0xbd, 0xca, 0x63, 0xc7, 0x4f, 0x0f, 0xab,
    0x77, 0xae, 0x01, 0x1c, 0xfb, 0x85, 0xb8, 0xdf, 0xef, 0xf7, 0xbf, 0x52,
    0x7d, 0xf7, 0xd7, 0xa9, 0xb9, 0xed, 0x0f, 0x5c, 0xe9, 0xec, 0xe2, 0xcd,
    0x6f, 0xdc, 0x4f, 0x2a, 0x01, 0xd2, 0x81, 0x42, 0x3c, 0x46, 0xe3, 0xd3,
    0x5b, 0x31, 0x9a, 0x63, 0x5c, 0xed, 0x9c, 0x62, 0xba, 0x53, 0xa2, 0x70,
    0x28, 0xde, 0x3a, 0x43, 0xd9, 0x16, 0x03, 0x63, 0xf5, 0x5a, 0x2e, 0x0d,
    0x4d, 0x70, 0xfc, 0xd5, 0xb3, 0xcc, 0xcd, 0xe6, 0x4f, 0x7a, 0x52, 0x7d,
    0x61, 0xef, 0x21, 0x95, 0x86, 0x77, 0xab, 0xc8, 0x5a, 0xe6, 0x9b, 0x7a,
    0xc2, 0xa0, 0xf2, 0xb6, 0x5d, 0x98, 0xd9, 0x59, 0x86, 0x3b, 0x7e, 0xc0,
    0xba, 0x35, 0xf0, 0xc9, 0xc7, 0xdb, 0xb8, 0xa3, 0xbd, 0x86, 0xd2, 0xb9,
    0x02, 0xe3, 0x9d, 0x17, 0x48, 0x0f, 0x3a, 0xcc, 0xfe, 0xb6, 0x9c, 0x75,
    0x53, 0x3b, 0xa9, 0x1d, 0x7f, 0x8c, 0xf9, 0x8e, 0x66, 0xa6, 0xde, 0x4a,
    0x33, 0x33, 0x7e, 0x9e, 0xea, 0xba, 0x14, 0xad, 0xdb, 0xea, 0x89, 0x25,
    0xa2, 0xad, 0x42, 0x63, 0xc7, 0x7b, 0x2f, 0xd0, 0x00, 0xa4, 0x04, 0xdb,
    0x52, 0x78, 0x56, 0x01, 0x5f, 0x78, 0x18, 0x7f, 0xc8, 0x41, 0x58, 0x3e,
    0x66, 0x5e, 0x1f, 0x62, 0xae, 0x77, 0x0c, 0xe1, 0x81, 0x2b, 0x1c, 0xd2,
    0xc7, 0x4c, 0x6e, 0xf6, 0xb7, 0x51, 0xff, 0xf9, 0x56, 0xea, 0xb7, 0x6d,
    0xa6, 0x6a, 0xb4, 0x05, 0xf3, 0x62, 0x04, 0xcf, 0xef, 0xc3, 0x74, 0x75,
    0xd6, 0x35, 0x55, 0x53, 0x5b, 0x5f, 0x8a, 0xd0, 0xb4, 0x9d, 0x3f, 0xbc,
    0x57, 0xac, 0x5a, 0x01, 0xb8, 0x82, 0x9f, 0xe7, 0x26, 0x33, 0x63, 0xff,
    0xe8, 0xdc, 0xc5, 0x7c, 0xf6, 0x28, 0x37, 0x3d, 0xd0, 0xcc, 0x58, 0x2e,
    0xc0, 0xc0, 0x81, 0x0c, 0x43, 0x3d, 0x2e, 0x0b, 0x6b, 0xcb, 0xa9, 0x79,
    0xe8, 0x66, 0x42, 0xab, 0x3d, 0xd2, 0x73, 0x17, 0xc9, 0x1f, 0xe8, 0x66,
    0xe1, 0x50, 0x0f, 0xf9, 0xd0, 0x65, 0x12, 0x6b, 0x24, 0x49, 0x4d, 0x23,
    0x1a, 0x88, 0x12, 0x88, 0xad, 0xa2, 0xaa, 0xae, 0x04, 0x5d, 0xd7, 0xeb,
    0x02, 0x41, 0xee, 0x5a, 0x01, 0x7c, 0x69, 0x8f, 0x3a, 0x23, 0x3d, 0xef,
    0x8b, 0x83, 0x7f, 0x3f, 0xde, 0x7f, 0x6c, 0xff, 0x3e, 0xfc, 0xf5, 0x16,
    0x4d, 0xbf, 0x7b, 0x08, 0xeb, 0xbe, 0x46, 0x7c, 0x3b, 0x36, 0xb2, 0x76,
    0x77, 0x2b, 0xa5, 0xb7, 0xac, 0x26, 0xd5, 0x06, 0xb3, 0xad, 0x6f, 0xd2,
    0x37, 0xf9, 0x3c, 0xa7, 0xcc, 0x83, 0x68, 0xdb, 0x7b, 0x88, 0x36, 0x98,
    0x8c, 0x4c, 0x2f, 0x62, 0x5a, 0x92, 0x68, 0x24, 0x41, 0xd2, 0x88, 0x13,
    0x4f, 0x06, 0x40, 0x70, 0xeb, 0x35, 0x8d, 0x36, 0x37, 0x8b, 0x13, 0x08,
    0xe2, 0x86, 0xe3, 0xb5, 0x24, 0x8a, 0xb7, 0x51, 0xb6, 0x79, 0x33, 0x65,
    0x9f, 0x2e, 0xc6, 0x73, 0x24, 0xe6, 0xdc, 0x3c, 0xf9, 0xf3, 0x59, 0x02,
    0x41, 0x8d, 0xba, 0xef, 0x06, 0x98, 0xb9, 0xe7, 0x12, 0xf1, 0x90, 0xc3,
    0x52, 0xa9, 0xc5, 0x2f, 0xc7, 0x97, 0xe8, 0xb7, 0x0b, 0xd4, 0xe5, 0xcf,
    0xf0, 0xb3, 0x78, 0x92, 0x68, 0x34, 0x42, 0x38, 0xa2, 0x83, 0xa0, 0x7a,
    0x05, 0xf0, 0xc7, 0x47, 0xc5, 0xfa, 0x70, 0xdc, 0xdf, 0xd9, 0xf8, 0xb1,
    0x07, 0x2b, 0x1b, 0xb7, 0xed, 0x26, 0x14, 0xd5, 0xd4, 0xd0, 0xf1, 0x0e,
    0x31, 0x39, 0x72, 0x8c, 0xb2, 0xda, 0x2a, 0x92, 0x46, 0x0a, 0xe5, 0xb9,
    0x38, 0x79, 0x1b, 0x34, 0x8d, 0x35, 0x5b, 0x62, 0x94, 0x38, 0x26, 0x8f,
    0x9f, 0x4e, 0xf3, 0xd7, 0xa8, 0x86, 0x51, 0x97, 0xe4, 0xd4, 0x3b, 0xc3,
    0x84, 0xdf, 0x0a, 0xf3, 0x54, 0x75, 0x05, 0x7e, 0x9f, 0x1f, 0x4d, 0xa3,
    0x6a, 0x05, 0x60, 0x5a, 0xb4, 0x45, 0x57, 0x05, 0x2a, 0x1b, 0x3f, 0xbe,
    0x83, 0x70, 0xcc, 0xcf, 0xa9, 0xc3, 0xbb, 0xd4, 0x89, 0x17, 0x8e, 0x9e,
    0x70, 0x6d, 0x4e, 0x57, 0x34, 0xcc, 0x6c, 0xbf, 0xf5, 0x9e, 0xe6, 0x54,
    0x91, 0x51, 0x84, 0x63, 0x49, 0x8a, 0xb5, 0x1c, 0xc6, 0x72, 0x0e, 0x6d,
    0xc9, 0xc7, 0xc4, 0x92, 0x4d, 0x3e, 0x2c, 0x89, 0x2e, 0x5b, 0xb0, 0xe8,
    0x71, 0xc5, 0x3f, 0x8f, 0xf4, 0xca, 0x41, 0x28, 0x94, 0xa2, 0xf0, 0x7e,
    0x92, 0x25, 0xd8, 0x16, 0x38, 0xd6, 0x34, 0x4b, 0xb3, 0x2f, 0x93, 0xbd,
    0x3a, 0x28, 0xb2, 0x69, 0x26, 0x7e, 0xfc, 0xa2, 0xfa, 0xfe, 0xf0, 0xdb,
    0x99, 0xfd, 0x23, 0x67, 0x2f, 0xa0, 0x79, 0x26, 0x09, 0x3d, 0xcf, 0xd8,
    0xb4, 0xc6, 0xe1, 0x81, 0x9b, 0x18, 0xcf, 0xeb, 0x7c, 0xbb, 0x2a, 0x4c,
    0xc3, 0xb4, 0xc9, 0x54, 0x4f, 0x96, 0x92, 0xa5, 0x38, 0x3f, 0xda, 0x74,
    0x07, 0xc2, 0xb1, 0x29, 0xe4, 0x1d, 0x94, 0xe2, 0xe2, 0xfb, 0x39, 0x10,
    0x9c, 0x5d, 0xc8, 0x5a, 0x0c, 0x9f, 0x3c, 0xc8, 0xc6, 0xbb, 0x5b, 0xf9,
    0xc8, 0xa6, 0x4d, 0xc2, 0x95, 0x43, 0xf7, 0x3d, 0xfd, 0xb0, 0xef, 0x40,
    0x69, 0x65, 0xd0, 0x30, 0x52, 0x51, 0xc2, 0x6e, 0x9a, 0x81, 0xf1, 0x08,
    0xfb, 0x46, 0xbf, 0xca, 0xa0, 0x7b, 0x27, 0x2d, 0x99, 0xa3, 0x3c, 0xb3,
    0xe1, 0x08, 0x07, 0xee, 0x5a, 0x4f, 0xaf, 0x6b, 0xd0, 0x54, 0x55, 0xc7,
    0xed, 0xc5, 0x92, 0xde, 0xbf, 0x9d, 0x63, 0x3e, 0xb7, 0x8c, 0x50, 0xbc,
    0xb1, 0x02, 0xf0, 0xe0, 0x9c, 0x74, 0xe4, 0x1b, 0xfd, 0xc7, 0xbb, 0xdb,
    0x62, 0xf1, 0x10, 0x95, 0xeb, 0xcb, 0x89, 0x24, 0x92, 0xc9, 0xb2, 0xda,
    0xea, 0x76, 0x9f, 0xe6, 0x51, 0x92, 0xd2, 0xd1, 0xec, 0x0c, 0x5d, 0x63,
    0x8d, 0xbc, 0x16, 0xfa, 0x0c, 0xac, 0xad, 0xa2, 0xab, 0x27, 0xc4, 0x67,
    0xb3, 0x19, 0x1e, 0xf9, 0x84, 0xa0, 0x29, 0x56, 0x03, 0x32, 0xcf, 0xcc,
    0x60, 0x37, 0x83, 0x03, 0x93, 0xb8, 0x96, 0x7d, 0x59, 0xba, 0x74, 0xaf,
    0x84, 0xe8, 0x7b, 0x1d, 0x6a, 0x49, 0x2a, 0x9e, 0xc8, 0x65, 0x4d, 0xef,
    0xc4, 0x91, 0x93, 0x0c, 0xf6, 0x0e, 0xe3, 0xf7, 0xeb, 0x34, 0x6d, 0xfe,
    0x28, 0x35, 0x4d, 0x8d, 0x44, 0x52, 0xd5, 0xc4, 0xab, 0xd6, 0xb3, 0xa5,
    0x21, 0x42, 0xe4, 0xea, 0x28, 0x1c, 0x19, 0xc7, 0x30, 0x27, 0xd8, 0xb0,
    0xb1, 0x04, 0x62, 0x06, 0x58, 0x53, 0xcc, 0x0c, 0xf5, 0x71, 0xe2, 0xe8,
    0x20, 0x53, 0xff, 0x9a, 0xc3, 0x53, 0xea, 0x37, 0xd2, 0x25, 0x7d, 0xcd,
    0x6f, 0xba, 0xbb, 0x5d, 0x68, 0xe1, 0x20, 0x8f, 0x2a, 0xc5, 0xaf, 0x83,
    0x91, 0x30, 0x65, 0x35, 0x15, 0xd4, 0x35, 0x55, 0x53, 0xb1, 0x6e, 0x35,
    0x91, 0x64, 0x9c, 0x48, 0x38, 0x80, 0x10, 0x3e, 0xba, 0xce, 0x26, 0x38,
    0x3d, 0x52, 0x44, 0x6b, 0xc3, 0x02, 0x5b, 0x1b, 0x0a, 0x2c, 0x15, 0x72,
    0x5c, 0xfe, 0xe7, 0x25, 0x06, 0xfb, 0x46, 0xb8, 0x7c, 0x7e, 0x12, 0xdb,
    0x36, 0x8f, 0x78, 0x1e, 0xdb, 0xf7, 0x1e, 0x54, 0xd9, 0x0f, 0xcd, 0x83,
    0xa7, 0xda, 0x85, 0x2e, 0x34, 0x1e, 0x50, 0x8a, 0x67, 0x34, 0x9f, 0xa8,
    0x0b, 0xc7, 0x62, 0x24, 0x52, 0x09, 0x8c, 0xd2, 0x24, 0x46, 0x2a, 0x49,
    0xd2, 0x88, 0x10, 0x09, 0xf9, 0x90, 0x9e, 0xc2, 0xb1, 0x2c, 0x32, 0xe9,
    0x45, 0xa6, 0xae, 0xce, 0x91, 0x9e, 0xc8, 0x90, 0xcf, 0xe5, 0x71, 0x6c,
    0xf7, 0x25, 0xe0, 0x91, 0x3d, 0x07, 0xd5, 0xc4, 0xff, 0x1c, 0x38, 0x00,
    0xdf, 0xf9, 0x94, 0x10, 0xab, 0x12, 0x94, 0x2b, 0xd8, 0x0e, 0xb4, 0x6b,
    0x9a, 0x68, 0xd1, 0x7c, 0x3e, 0xf4, 0x40, 0x00, 0x3d, 0xa8, 0xe3, 0xd7,
    0xfd, 0x68, 0x3e, 0x0d, 0xd7, 0x76, 0x31, 0x97, 0x97, 0x71, 0x6d, 0x1b,
    0xcf, 0xf5, 0x86, 0x95, 0xe2, 0x59, 0xa5, 0xf8, 0xcb, 0x9e, 0x17, 0xff,
    0xe3, 0xf9, 0x75, 0x01, 0xef, 0xe9, 0x27, 0xed, 0xc2, 0xe7, 0x49, 0xc2,
    0x9a, 0x60, 0x0b, 0x82, 0xaf, 0x68, 0x82, 0x16, 0x34, 0x6a, 0x01, 0xe3,
    0xdd, 0x2b, 0x17, 0x3d, 0xc5, 0x80, 0x92, 0xbc, 0xe4, 0x49, 0xba, 0x34,
    0x8d, 0xcc, 0xde, 0xc3, 0xca, 0xfb, 0xa0, 0x9d, 0xeb, 0x02, 0xfe, 0x5f,
    0xba, 0xe1, 0x5b, 0xc5, 0xbf, 0x01, 0x33, 0x54, 0xa9, 0x68, 0x24, 0x82,
    0x81, 0xee, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42,
    0x60, 0x82
};

static const unsigned char image5_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0x99, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x92, 0x4b, 0x48, 0x54,
    0x71, 0x18, 0xc5, 0xcf, 0xfd, 0x3f, 0xee, 0x9d, 0x3b, 0x8e, 0x57, 0x67,
    0xf4, 0x4e, 0x8d, 0xa5, 0xe6, 0xa3, 0x24, 0xc8, 0x07, 0x48, 0x68, 0x21,
    0x49, 0x1b, 0xb5, 0x5a, 0x54, 0x12, 0x03, 0xa5, 0xd0, 0x63, 0x23, 0x21,
    0x11, 0x45, 0xd0, 0xc2, 0x1e, 0xb8, 0x6b, 0x29, 0x81, 0x81, 0x0b, 0x29,
    0x28, 0xc8, 0xc6, 0x16, 0xae, 0x4a, 0x2c, 0xd3, 0x22, 0x8d, 0x48, 0x28,
    0xe8, 0x41, 0x64, 0xe4, 0x23, 0x1d, 0x33, 0x52, 0x67, 0xc6, 0xc7, 0xcc,
    0xfc, 0xef, 0x9d, 0x7b, 0x5b, 0x88, 0x12, 0x65, 0x8b, 0xf2, 0x2c, 0x3f,
    0xf8, 0x7e, 0x9c, 0xc3, 0x39, 0x92, 0x6d, 0xdb, 0x58, 0x8f, 0xc8, 0xba,
    0xbe, 0x01, 0xb0, 0xdf, 0x0f, 0xd5, 0xd5, 0x8d, 0x99, 0x80, 0x5a, 0xc7,
    0x39, 0xdf, 0x4a, 0x08, 0x37, 0x85, 0x30, 0x9f, 0x6b, 0x9a, 0x7e, 0x3f,
    0x10, 0x38, 0x17, 0x5d, 0x0b, 0x20, 0xfd, 0x1a, 0xa1, 0xaa, 0xea, 0x7c,
    0x95, 0xcf, 0xe7, 0x6b, 0x2b, 0x2a, 0x2a, 0xde, 0x92, 0xae, 0x7b, 0x00,
    0xdb, 0xc6, 0xc4, 0x44, 0x10, 0xc3, 0xc3, 0x63, 0x7d, 0xa1, 0xd0, 0xfc,
    0xa5, 0xae, 0xae, 0xa6, 0x41, 0x00, 0xf0, 0xfb, 0x6f, 0xe4, 0xeb, 0xba,
    0xe6, 0x6d, 0x6d, 0xad, 0x1f, 0x5c, 0x05, 0x54, 0x56, 0x36, 0x66, 0x66,
    0x67, 0x67, 0xbd, 0x39, 0x78, 0xe8, 0x88, 0x67, 0x83, 0xdb, 0x0d, 0x6a,
    0x98, 0x70, 0xaa, 0x2a, 0x94, 0x64, 0x8a, 0xaf, 0xd3, 0x41, 0xf4, 0xf6,
    0xbd, 0x12, 0x23, 0x23, 0x13, 0xa7, 0xe3, 0x71, 0x69, 0x2e, 0x2f, 0x6f,
    0x53, 0x7b, 0x22, 0x61, 0x3f, 0x6c, 0x69, 0x39, 0x56, 0xb7, 0x1a, 0x21,
    0x29, 0x59, 0x3d, 0x5b, 0x5e, 0x5e, 0xe1, 0x51, 0x2c, 0x09, 0xc1, 0x77,
    0xc3, 0x88, 0x19, 0x06, 0x16, 0x63, 0x51, 0x64, 0xfa, 0x36, 0x23, 0x67,
    0x5b, 0x16, 0x4e, 0xd4, 0x1f, 0x90, 0xef, 0xdc, 0xeb, 0x6e, 0x4f, 0x4d,
    0x55, 0xb1, 0x7f, 0xdf, 0x6e, 0x74, 0x74, 0xbc, 0x70, 0x49, 0x92, 0x44,
    0x19, 0x00, 0x94, 0x95, 0x1d, 0x4f, 0x2b, 0x28, 0xd8, 0x7e, 0xd8, 0xa3,
    0xa5, 0x20, 0x36, 0x3d, 0x83, 0xc8, 0xe2, 0x02, 0x06, 0x3e, 0xbc, 0x46,
    0xcc, 0x34, 0xe0, 0x1e, 0xfd, 0x84, 0xd2, 0x50, 0x09, 0x0a, 0x8b, 0x77,
    0xa0, 0xfe, 0x68, 0x0d, 0x64, 0x55, 0x86, 0x88, 0xdb, 0x00, 0x4c, 0x3d,
    0x3d, 0xbd, 0xc0, 0xc9, 0x00, 0x80, 0x73, 0xb9, 0x2c, 0x4d, 0xf7, 0xe6,
    0x4a, 0x51, 0x01, 0x17, 0x77, 0x60, 0x70, 0x6c, 0x08, 0xa1, 0xc5, 0xf0,
    0x13, 0x2e, 0x3b, 0x6e, 0x7d, 0x8f, 0xcc, 0xe6, 0x3f, 0x7a, 0xd9, 0x7f,
    0xe1, 0x47, 0x78, 0xd6, 0x59, 0xb1, 0xab, 0x1c, 0x51, 0x08, 0xa8, 0x2e,
    0x09, 0x4e, 0x27, 0xcb, 0xb0, 0xac, 0xec, 0x54, 0x02, 0x00, 0x9a, 0x96,
    0xba, 0xd7, 0x14, 0x02, 0x8a, 0x05, 0xc0, 0xb2, 0x10, 0x59, 0x5a, 0x84,
    0x61, 0x1a, 0x37, 0x03, 0x77, 0x9b, 0x6e, 0xc7, 0x62, 0xf3, 0x8f, 0x53,
    0x92, 0x5d, 0x3c, 0x2b, 0xcd, 0x0b, 0xe7, 0x12, 0x20, 0x2f, 0xc4, 0xb1,
    0x34, 0x1b, 0x85, 0x99, 0x48, 0x78, 0x1d, 0x0e, 0xc7, 0xb2, 0x03, 0xc6,
    0x88, 0x66, 0x19, 0x26, 0x9c, 0x44, 0x86, 0x4a, 0x38, 0x28, 0xa1, 0xb0,
    0xed, 0x84, 0xf0, 0xfb, 0xaf, 0x14, 0x2a, 0x4c, 0xe9, 0x49, 0x49, 0xd2,
    0xb8, 0x10, 0x71, 0x7c, 0x99, 0x1c, 0x05, 0x18, 0x05, 0x49, 0x72, 0xc0,
    0x32, 0x84, 0xaa, 0xeb, 0x8a, 0xce, 0x00, 0xc0, 0x92, 0x20, 0x51, 0x4a,
    0xa0, 0x50, 0x0e, 0x8f, 0x23, 0x19, 0x4e, 0x45, 0x01, 0x25, 0x34, 0xd7,
    0xb6, 0xa5, 0x19, 0x46, 0x49, 0x60, 0x74, 0x72, 0x3c, 0x67, 0x3c, 0x38,
    0xbe, 0x91, 0x73, 0xae, 0x51, 0x4a, 0xdd, 0x44, 0x22, 0xb2, 0x30, 0x05,
    0x72, 0x73, 0x0b, 0x76, 0x2e, 0xb7, 0x60, 0x63, 0x56, 0x98, 0x26, 0x0c,
    0x2b, 0x01, 0x95, 0xc9, 0xf0, 0x79, 0xbc, 0x18, 0x99, 0x0e, 0x96, 0x74,
    0x76, 0x36, 0x5f, 0x03, 0xd0, 0xbb, 0xd2, 0xd4, 0x9e, 0x9a, 0x06, 0x5f,
    0x92, 0xec, 0xce, 0xe3, 0x40, 0x86, 0x2c, 0xf3, 0x6c, 0x45, 0x91, 0x87,
    0x18, 0x00, 0x50, 0x46, 0xfa, 0xc3, 0x91, 0xf0, 0xc5, 0x8f, 0xdf, 0xc6,
    0xe0, 0x60, 0x32, 0x24, 0x42, 0x40, 0x09, 0x4a, 0xfd, 0xfe, 0x66, 0x57,
    0x20, 0x70, 0x75, 0x61, 0x05, 0xf0, 0xac, 0xbb, 0x6d, 0x0a, 0xc0, 0xd4,
    0x1f, 0x53, 0x56, 0x98, 0xf7, 0xa9, 0x10, 0xa1, 0xb6, 0x81, 0xb7, 0x43,
    0x0d, 0x9f, 0x83, 0xa3, 0x98, 0x09, 0xcf, 0x01, 0x60, 0x3d, 0xc0, 0xfb,
    0x35, 0xe7, 0xfb, 0xd7, 0x29, 0xd7, 0xd6, 0x5e, 0x3e, 0x99, 0xb0, 0xad,
    0x53, 0x8c, 0x91, 0x97, 0x51, 0x9f, 0xb7, 0xe9, 0xc1, 0xf5, 0x33, 0xf1,
    0x7f, 0x02, 0xfc, 0x8f, 0x7e, 0x02, 0x70, 0x5e, 0xfb, 0x18, 0x97, 0xfc,
    0x1a, 0x5e, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42,
    0x60, 0x82
};

static const unsigned char image6_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xae, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x4b, 0x68, 0x54,
    0x77, 0x14, 0xc6, 0x7f, 0xf7, 0x35, 0x73, 0x27, 0x99, 0xcc, 0x4b, 0x93,
    0x8c, 0x31, 0x8a, 0x36, 0x69, 0x7c, 0x10, 0x8c, 0xd2, 0x85, 0x0f, 0x44,
    0x88, 0x60, 0x69, 0x5d, 0x74, 0x5b, 0xe8, 0x42, 0x29, 0x05, 0xa5, 0x8b,
    0x28, 0x94, 0x0a, 0xbe, 0xf0, 0x85, 0x0a, 0x06, 0x17, 0x82, 0xd6, 0x85,
    0x3b, 0x17, 0xa2, 0xe0, 0xca, 0x8d, 0x2f, 0xdc, 0x05, 0x05, 0x21, 0xbe,
    0x28, 0x7d, 0xa4, 0x23, 0x23, 0x9d, 0x24, 0x75, 0x92, 0x99, 0x71, 0xcc,
    0xdc, 0xce, 0x9d, 0xdc, 0x7b, 0xff, 0x73, 0x4f, 0x57, 0x0d, 0x46, 0xd3,
    0x45, 0xf1, 0x5b, 0x1e, 0xce, 0xf9, 0x71, 0xf8, 0xce, 0x77, 0x34, 0x11,
    0xe1, 0x63, 0x64, 0x2e, 0x54, 0xbc, 0xa9, 0x69, 0x31, 0x49, 0x24, 0xb6,
    0xc5, 0xc3, 0x70, 0x6b, 0xa8, 0xd4, 0xca, 0xb7, 0xa1, 0xca, 0x4f, 0xfa,
    0xea, 0x6e, 0x0b, 0x3c, 0x19, 0x12, 0xf1, 0xde, 0xed, 0xd5, 0xde, 0xdd,
    0xe0, 0xa4, 0xa6, 0x99, 0x5b, 0xbb, 0x3a, 0x06, 0xbb, 0x56, 0x2c, 0xfb,
    0x31, 0xd6, 0xbf, 0xe6, 0x73, 0x33, 0x9d, 0x42, 0x6a, 0x15, 0x9c, 0xb1,
    0x1c, 0x13, 0xbf, 0xe4, 0x66, 0xc7, 0xcb, 0xb5, 0xfb, 0xa5, 0xa6, 0x9c,
    0x38, 0x28, 0xf2, 0x6c, 0x41, 0xc0, 0x48, 0x67, 0xe6, 0x40, 0xcf, 0x77,
    0xbb, 0x87, 0xb3, 0x83, 0x1b, 0xd1, 0x27, 0x7f, 0xc3, 0xcf, 0xe5, 0xf0,
    0xa7, 0xca, 0x28, 0xa5, 0xe3, 0xd5, 0x3d, 0xf2, 0xa3, 0xbf, 0xf2, 0x73,
    0xa1, 0x34, 0x3d, 0x11, 0xca, 0x57, 0xa7, 0x44, 0x1e, 0xcf, 0x03, 0xdc,
    0xd6, 0xb4, 0x1d, 0xfd, 0x7b, 0x77, 0xdd, 0x5f, 0xfe, 0xcd, 0x4e, 0xdc,
    0xeb, 0x17, 0xf1, 0xa6, 0xab, 0x18, 0xb3, 0x1e, 0x33, 0x55, 0x9f, 0xa6,
    0xab, 0xf0, 0x3c, 0x05, 0x2d, 0x49, 0x0a, 0xf9, 0xd7, 0x3c, 0x7f, 0xeb,
    0xe6, 0x5c, 0x64, 0xcb, 0x71, 0x91, 0xb2, 0x0e, 0xf0, 0xad, 0xa6, 0xd9,
    0xed, 0x03, 0x6b, 0x86, 0x3b, 0x37, 0x0f, 0xe0, 0xfc, 0x74, 0x86, 0x9c,
    0x93, 0xa6, 0xfe, 0xf5, 0x11, 0xaa, 0x99, 0x5e, 0x4a, 0x9f, 0x7d, 0x49,
    0x6c, 0xef, 0x0f, 0x48, 0x2a, 0x43, 0xe5, 0xaf, 0x12, 0x6d, 0x11, 0x83,
    0x8c, 0x69, 0x7c, 0xea, 0xc1, 0x9e, 0x39, 0x13, 0xb7, 0xc0, 0x60, 0xdb,
    0xea, 0xde, 0xf5, 0xda, 0x8b, 0x11, 0x66, 0xa6, 0x6a, 0x2c, 0x39, 0xb6,
    0x8f, 0x8e, 0xed, 0x3b, 0x28, 0xaf, 0x5e, 0x4b, 0xd7, 0x92, 0x0e, 0xac,
    0xf6, 0x4e, 0xa4, 0xee, 0x50, 0x1c, 0x3e, 0x8f, 0x65, 0xda, 0xa4, 0xa3,
    0x16, 0x11, 0x15, 0x7e, 0x0f, 0x9c, 0xd5, 0x01, 0x12, 0xb0, 0xd3, 0xf0,
    0x5d, 0xdc, 0x89, 0x22, 0x76, 0x24, 0x82, 0x73, 0xfd, 0x0a, 0xee, 0x9f,
    0x2f, 0x59, 0xbc, 0x6e, 0x00, 0xab, 0x35, 0x82, 0xff, 0xf4, 0x11, 0xd3,
    0x77, 0xee, 0xd2, 0x34, 0x2d, 0xcc, 0x54, 0x82, 0xa8, 0x6d, 0xa3, 0x6b,
    0x5a, 0x37, 0x80, 0x0e, 0xd0, 0x84, 0x76, 0x35, 0x55, 0x24, 0x98, 0x71,
    0x79, 0x53, 0x74, 0x08, 0xba, 0x7b, 0xb1, 0xa2, 0x26, 0xcc, 0x56, 0x41,
    0x14, 0xd2, 0x0c, 0x50, 0xf1, 0x24, 0x66, 0x32, 0x41, 0x6b, 0x3a, 0x41,
    0x68, 0x19, 0x04, 0xe0, 0xcd, 0x01, 0xde, 0xc0, 0x68, 0xc3, 0x53, 0x68,
    0xba, 0x45, 0x18, 0x6a, 0x24, 0xbb, 0xbb, 0xb0, 0xb2, 0xed, 0xb8, 0x8f,
    0x46, 0xf8, 0x7b, 0xf4, 0x29, 0xd1, 0x81, 0xf5, 0xac, 0x3a, 0x7a, 0x98,
    0x4c, 0xdf, 0x4a, 0x6c, 0x43, 0xa7, 0xec, 0x07, 0x28, 0x09, 0xef, 0xcd,
    0x79, 0x90, 0x83, 0x5b, 0x3d, 0x4e, 0xe3, 0xd8, 0xd2, 0x6c, 0xaa, 0x2d,
    0xbe, 0xa2, 0x1b, 0xe7, 0xc6, 0x55, 0xa4, 0x54, 0xa4, 0xfc, 0xe0, 0x01,
    0x61, 0x5b, 0x92, 0x4f, 0x64, 0x08, 0xef, 0xd9, 0x63, 0x16, 0xd9, 0x11,
    0x5e, 0x55, 0x1c, 0x26, 0x9d, 0x46, 0xa8, 0x21, 0xc3, 0xf3, 0xce, 0x78,
    0x39, 0xde, 0x72, 0x61, 0xed, 0xf2, 0xec, 0xfe, 0xfe, 0x0d, 0xbd, 0x84,
    0x96, 0xc1, 0xac, 0xaf, 0x50, 0xcd, 0x10, 0x3d, 0x62, 0x10, 0x4b, 0x2f,
    0x42, 0x4a, 0x25, 0xc6, 0xf3, 0x45, 0x1e, 0xfe, 0x5e, 0xa0, 0x5c, 0x73,
    0x2e, 0x9d, 0x16, 0x19, 0x9a, 0x17, 0xe5, 0x42, 0xbd, 0x71, 0x9c, 0xc9,
    0xca, 0xaa, 0x06, 0x7c, 0xd1, 0xd7, 0xb7, 0x8c, 0x78, 0x3a, 0x4e, 0x2c,
    0x6a, 0xa3, 0x3c, 0x8f, 0xca, 0x58, 0x9e, 0x97, 0x85, 0x69, 0xfe, 0x98,
    0x28, 0x51, 0xab, 0xbb, 0xb7, 0x2c, 0x38, 0xf4, 0x5f, 0x51, 0x4e, 0xb4,
    0xda, 0xb1, 0xc3, 0xf1, 0x54, 0x7c, 0x77, 0x26, 0xd1, 0x9a, 0xb5, 0x23,
    0x06, 0xb5, 0x86, 0x4f, 0xb9, 0xea, 0xe0, 0x38, 0xf5, 0x31, 0x2f, 0x08,
    0x2e, 0x04, 0x70, 0xed, 0x9c, 0x88, 0xb3, 0x20, 0xe0, 0xdf, 0x7f, 0x50,
    0xd1, 0x68, 0x8f, 0x89, 0x31, 0x88, 0x84, 0x9b, 0x10, 0x71, 0xc3, 0x40,
    0x8d, 0x78, 0x34, 0x1f, 0x9e, 0x83, 0x71, 0x79, 0x6f, 0xe0, 0x03, 0xc0,
    0xff, 0xd5, 0x3f, 0x2b, 0x61, 0x47, 0xa6, 0x4f, 0xbb, 0x88, 0xee, 0x00,
    0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image7_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00, 0x16,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xc4, 0xb4, 0x6c, 0x3b, 0x00, 0x00, 0x04,
    0xa2, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xb5, 0x95, 0x6b, 0x68, 0xd5,
    0x75, 0x18, 0xc7, 0x3f, 0xbf, 0xff, 0xfd, 0x5c, 0x76, 0xb6, 0x9d, 0x6d,
    0x39, 0xb7, 0xa3, 0x98, 0x79, 0x03, 0xcb, 0x02, 0xb5, 0x10, 0x03, 0x51,
    0x11, 0x11, 0x2c, 0x22, 0xf2, 0x8d, 0x96, 0xa5, 0x25, 0x92, 0x66, 0x08,
    0x31, 0x22, 0x41, 0x86, 0x97, 0xd0, 0x50, 0x88, 0x32, 0xb0, 0x7a, 0xd1,
    0x8b, 0x20, 0xc4, 0xec, 0x82, 0xa2, 0x99, 0x11, 0x94, 0x26, 0x19, 0x58,
    0x39, 0x4d, 0x5d, 0x4e, 0x73, 0xba, 0xcd, 0xcd, 0x6d, 0x67, 0x3b, 0x97,
    0x9d, 0xff, 0xb9, 0xfc, 0x2f, 0xbf, 0x5f, 0x2f, 0x52, 0x41, 0x4b, 0xf1,
    0x4d, 0xdf, 0xd7, 0xcf, 0xf3, 0xe1, 0x0b, 0xcf, 0xf3, 0x7c, 0x1f, 0xa1,
    0x94, 0xe2, 0xff, 0x90, 0x71, 0x3f, 0x45, 0xbb, 0x85, 0xa8, 0xad, 0x85,
    0xb8, 0x0f, 0x86, 0x07, 0x32, 0x0b, 0x6e, 0x07, 0xe4, 0x3e, 0x52, 0xca,
    0xbf, 0x5b, 0x8f, 0xb8, 0x97, 0xe3, 0x3d, 0x42, 0x4c, 0x89, 0xc1, 0xc2,
    0xaa, 0x44, 0xfc, 0x39, 0x65, 0x1a, 0xb3, 0xa4, 0x94, 0x7a, 0xb1, 0x54,
    0x26, 0x5f, 0xf6, 0xfe, 0xc8, 0xc2, 0xa1, 0x3c, 0xec, 0xdd, 0xa0, 0x54,
    0xdb, 0x7d, 0x83, 0x5b, 0x84, 0x88, 0x2d, 0x80, 0x97, 0xeb, 0x27, 0x3c,
    0xf8, 0x66, 0xcd, 0x93, 0x8f, 0x37, 0xc5, 0x27, 0x8d, 0xc7, 0x70, 0x2c,
    0x34, 0x37, 0x47, 0xb1, 0xf3, 0x2a, 0xd9, 0xf6, 0x0e, 0xba, 0xce, 0x5f,
    0xa6, 0x2b, 0x57, 0x72, 0xf3, 0xb0, 0xc3, 0x87, 0x0f, 0xde, 0x52, 0x6a,
    0xe8, 0x9e, 0xe0, 0x4d, 0x42, 0x44, 0xe7, 0xc2, 0xee, 0xd4, 0xd2, 0x25,
    0xcb, 0x9b, 0xd6, 0xaf, 0xc5, 0x89, 0x6b, 0xc8, 0xf6, 0xd3, 0xf8, 0x57,
    0xae, 0xe0, 0xa5, 0x87, 0x40, 0x82, 0x26, 0x04, 0xe5, 0xce, 0xab, 0x74,
    0xfe, 0x72, 0x86, 0x33, 0x5d, 0x69, 0x06, 0x14, 0x87, 0x2b, 0xb0, 0xb4,
    0x55, 0xa9, 0xec, 0x7f, 0x82, 0x77, 0x0a, 0x11, 0x7b, 0x4c, 0x63, 0xd7,
    0xe4, 0x35, 0xab, 0x57, 0x8c, 0x79, 0xbb, 0x15, 0x4e, 0x7d, 0x07, 0xdf,
    0xec, 0xa5, 0xd8, 0xd9, 0x8d, 0xe7, 0x7a, 0x68, 0x52, 0xe0, 0x97, 0x43,
    0x46, 0x3c, 0x81, 0x5e, 0x57, 0x8f, 0x51, 0xf1, 0xe8, 0x39, 0xfb, 0x17,
    0x27, 0xfb, 0x72, 0x64, 0x94, 0xf8, 0x24, 0x81, 0x5c, 0xb3, 0x4e, 0xa9,
    0x0a, 0xdc, 0x31, 0xbc, 0xf1, 0xb0, 0xac, 0x69, 0xe1, 0xfc, 0x15, 0xa9,
    0xf5, 0xab, 0xe1, 0xab, 0xf7, 0x08, 0x8f, 0x7c, 0xc9, 0x60, 0x5f, 0x9e,
    0x58, 0x6d, 0x92, 0x48, 0x7d, 0x1d, 0x43, 0x57, 0xfa, 0x71, 0xaf, 0xf5,
    0xe3, 0x44, 0xa3, 0x14, 0x86, 0xf3, 0xf8, 0xa6, 0x43, 0x34, 0x11, 0xe3,
    0xa1, 0x7c, 0x85, 0x33, 0x85, 0xf2, 0xca, 0x0c, 0x1c, 0x04, 0xbe, 0x06,
    0xd0, 0x6e, 0x42, 0xdf, 0x15, 0xa2, 0xb9, 0x3e, 0xd5, 0xd4, 0x92, 0x5a,
    0xb6, 0x04, 0x71, 0xe2, 0x10, 0xe5, 0x7d, 0x9f, 0xf2, 0xeb, 0xd9, 0x3c,
    0x83, 0x73, 0x57, 0x11, 0xce, 0x58, 0x40, 0xf7, 0xe9, 0x0b, 0x9c, 0x1e,
    0x08, 0xb1, 0x5f, 0x6d, 0x21, 0x18, 0x95, 0x42, 0x0e, 0x0f, 0x51, 0xca,
    0x8e, 0x90, 0x73, 0x8b, 0xd4, 0xd8, 0x1a, 0x35, 0x86, 0x8e, 0x10, 0xe2,
    0xa5, 0x16, 0x21, 0x62, 0xb7, 0x39, 0x7e, 0x00, 0x16, 0x26, 0xa7, 0x4d,
    0x9e, 0x90, 0x70, 0x42, 0x82, 0xfd, 0xfb, 0xb9, 0x98, 0xd6, 0x31, 0x5f,
    0x78, 0x83, 0x89, 0xeb, 0xd6, 0x61, 0x96, 0x32, 0x5c, 0xbe, 0x56, 0x64,
    0xca, 0xdc, 0x79, 0xa4, 0x96, 0x3c, 0x8b, 0x3b, 0xed, 0x51, 0x7a, 0xb6,
    0x6e, 0x22, 0x3c, 0xd7, 0x4e, 0x59, 0x77, 0xb0, 0xd1, 0xa8, 0x33, 0x75,
    0x06, 0x42, 0xb9, 0x50, 0x47, 0x8d, 0x03, 0xce, 0x19, 0x00, 0xbb, 0x84,
    0x48, 0x8c, 0xad, 0x8a, 0x3f, 0x5f, 0xd5, 0x3c, 0x0a, 0xef, 0xf4, 0x49,
    0x4a, 0x3d, 0xbd, 0x54, 0x8d, 0x4e, 0x51, 0xff, 0xcc, 0x22, 0x9c, 0x88,
    0x05, 0x22, 0xc6, 0xd4, 0x6d, 0xef, 0x60, 0xeb, 0x40, 0x7a, 0x90, 0xaa,
    0x79, 0x73, 0x19, 0x3d, 0x3c, 0xc8, 0xe0, 0xea, 0xb5, 0x78, 0x84, 0xd8,
    0xb6, 0x43, 0xb5, 0x2f, 0xd1, 0xbd, 0xd0, 0xd6, 0x43, 0x39, 0x1d, 0x38,
    0xa7, 0x01, 0x98, 0x50, 0xa5, 0x19, 0xfa, 0x13, 0x96, 0xa5, 0x51, 0xea,
    0xea, 0xc6, 0xc3, 0x21, 0x19, 0xe4, 0x19, 0xd8, 0xda, 0x42, 0xb6, 0xed,
    0x24, 0xa8, 0x00, 0x5b, 0x84, 0x50, 0x2c, 0x80, 0x0c, 0xf0, 0xda, 0xda,
    0xe8, 0xff, 0x7c, 0x1f, 0x15, 0x05, 0x7a, 0x55, 0x1c, 0x3d, 0xe2, 0x60,
    0x58, 0x26, 0x08, 0x81, 0x84, 0x06, 0x21, 0x84, 0xd0, 0x00, 0x02, 0xb0,
    0x90, 0x61, 0x54, 0x2f, 0x8e, 0xe0, 0xe7, 0x5d, 0x0c, 0x74, 0x06, 0xaf,
    0xe7, 0x39, 0x7f, 0xfc, 0x14, 0x85, 0xde, 0x5e, 0x08, 0x03, 0x28, 0xb9,
    0x10, 0xfa, 0x20, 0x20, 0x73, 0xec, 0x28, 0xdd, 0x07, 0x7f, 0x80, 0x68,
    0x0c, 0xab, 0x2a, 0x8e, 0x1d, 0xb5, 0xd1, 0x0c, 0x03, 0x25, 0x04, 0x80,
    0xbc, 0x35, 0x3c, 0x01, 0xd2, 0xf3, 0x43, 0x55, 0xee, 0xeb, 0x47, 0x94,
    0x2a, 0xf8, 0x39, 0x97, 0xfe, 0x11, 0xc9, 0xd4, 0xed, 0x3b, 0x49, 0xcd,
    0x9f, 0x03, 0xf9, 0x1c, 0x68, 0x02, 0x50, 0x50, 0x2a, 0x91, 0x7c, 0xea,
    0x69, 0x9a, 0xd7, 0xad, 0x42, 0x8b, 0x44, 0xb0, 0xa3, 0x16, 0x4e, 0xc4,
    0xa1, 0xa2, 0x6b, 0x84, 0xff, 0xac, 0x6e, 0x46, 0x29, 0xa5, 0x34, 0x80,
    0x1c, 0x94, 0xdd, 0x30, 0xec, 0x73, 0x87, 0xb2, 0xa8, 0x50, 0x52, 0x56,
    0x1a, 0x0d, 0x89, 0x18, 0x35, 0x9a, 0x0f, 0x95, 0x12, 0x38, 0x16, 0x7e,
    0x5f, 0x1f, 0xfe, 0x40, 0x3f, 0xe8, 0x02, 0xb3, 0x2e, 0xc9, 0xc4, 0xd7,
    0xd6, 0x30, 0x6a, 0xf6, 0x4c, 0x1c, 0x5d, 0x60, 0x6a, 0x82, 0x21, 0x3f,
    0x24, 0x94, 0xaa, 0x12, 0x42, 0xdb, 0x2d, 0xc7, 0x69, 0xc8, 0x17, 0xfc,
    0xe0, 0x68, 0x7a, 0x30, 0x8b, 0xa6, 0xeb, 0x88, 0xc6, 0x46, 0xb4, 0xc0,
    0xe3, 0xda, 0xb6, 0x2d, 0xe4, 0x7f, 0x3e, 0x8e, 0xd7, 0xdb, 0xc3, 0xa5,
    0x8d, 0x1b, 0x69, 0xdf, 0xb6, 0x83, 0x30, 0x54, 0x10, 0x84, 0x0c, 0x7f,
    0x7f, 0x04, 0xbd, 0x54, 0xa0, 0x36, 0x11, 0xa7, 0x50, 0x28, 0xd3, 0xeb,
    0x96, 0xf1, 0x65, 0xf8, 0x63, 0x0c, 0x2e, 0xdf, 0x76, 0x79, 0x3b, 0x85,
    0x78, 0xaa, 0xa9, 0x36, 0x7e, 0x60, 0xf6, 0xc3, 0xe3, 0x88, 0x37, 0x26,
    0x71, 0xa5, 0x46, 0xb1, 0xa7, 0x07, 0xb3, 0x79, 0x2c, 0xd2, 0x30, 0x19,
    0xfa, 0xed, 0x14, 0xd2, 0x30, 0x19, 0xf3, 0xe2, 0x72, 0xe2, 0xa9, 0x46,
    0x06, 0x0f, 0x1e, 0x20, 0xea, 0xfb, 0xc8, 0x8c, 0xcb, 0x4f, 0x17, 0xba,
    0xe8, 0x18, 0xc8, 0xa0, 0xc2, 0x60, 0xf5, 0x66, 0xa5, 0x3e, 0xbe, 0x0d,
    0xbc, 0x49, 0x88, 0x68, 0x8d, 0xe3, 0x7c, 0x31, 0xa9, 0x31, 0xb9, 0x68,
    0xc6, 0x23, 0xe3, 0xd0, 0xea, 0x6a, 0xf1, 0x6d, 0x8b, 0x4a, 0x26, 0x8b,
    0xe7, 0xf9, 0xe8, 0xd5, 0xd5, 0x08, 0x5d, 0x47, 0x56, 0x4a, 0x98, 0x86,
    0x81, 0x1d, 0x48, 0xfc, 0x74, 0x9e, 0xdf, 0x2f, 0x76, 0xd3, 0xd6, 0x9b,
    0xc6, 0x2f, 0x57, 0x4e, 0x18, 0xa8, 0xc5, 0xad, 0x4a, 0x0d, 0xff, 0x2b,
    0x2b, 0xb6, 0x5b, 0xd6, 0xf4, 0x98, 0x65, 0x1d, 0x9e, 0xd8, 0x54, 0xd7,
    0x30, 0x6d, 0xf2, 0x18, 0xa2, 0xa3, 0x92, 0x88, 0x58, 0x14, 0x69, 0x9a,
    0x20, 0x00, 0xa9, 0x50, 0xc5, 0x22, 0xde, 0xf0, 0x08, 0xe9, 0xeb, 0x19,
    0xce, 0x76, 0xf5, 0x71, 0x69, 0x20, 0x83, 0x57, 0xaa, 0xf4, 0xa3, 0xe4,
    0xa2, 0xcd, 0x4a, 0x9d, 0xba, 0x6b, 0xba, 0x6d, 0x33, 0x8c, 0xc5, 0xb6,
    0x6d, 0x7f, 0xd6, 0x98, 0x4c, 0x24, 0xc6, 0x37, 0x37, 0xd0, 0x50, 0x57,
    0x8d, 0x1d, 0x73, 0x00, 0xf0, 0x3c, 0x8f, 0x5c, 0xce, 0xa5, 0x2f, 0x9d,
    0xa7, 0xb3, 0x7f, 0x98, 0x74, 0xae, 0x40, 0xe8, 0xf9, 0x17, 0x75, 0xe4,
    0x2b, 0xad, 0x4a, 0x1d, 0xbb, 0x67, 0x6c, 0x02, 0x6c, 0x31, 0xcd, 0x59,
    0x86, 0xae, 0x6d, 0xb0, 0x2d, 0x7b, 0x71, 0x3c, 0x1e, 0x21, 0xe2, 0x58,
    0xe8, 0x02, 0x8a, 0x7e, 0xc0, 0x48, 0xa9, 0x42, 0xc9, 0x2d, 0xe3, 0x55,
    0xfc, 0x00, 0x29, 0x3f, 0x14, 0xc8, 0x5d, 0xad, 0x4a, 0x75, 0xdc, 0xc9,
    0xb8, 0xeb, 0x07, 0xd9, 0x24, 0x44, 0x42, 0x62, 0xcc, 0x34, 0x1d, 0x63,
    0xa5, 0x10, 0xcc, 0x51, 0x8a, 0x66, 0x29, 0xa5, 0xaf, 0x82, 0xe0, 0x4f,
    0x29, 0xf9, 0x56, 0x21, 0xf7, 0x64, 0xe1, 0xfc, 0xfb, 0x37, 0x62, 0xf2,
    0xbe, 0xc1, 0x37, 0xf5, 0xba, 0x10, 0x76, 0x04, 0x2c, 0x71, 0x63, 0x35,
    0x43, 0x08, 0xe2, 0x50, 0x69, 0x55, 0x2a, 0xb8, 0x57, 0xdf, 0xdf, 0x19,
    0x8a, 0x49, 0xab, 0x9e, 0xbc, 0xb2, 0x45, 0x00, 0x00, 0x00, 0x00, 0x49,
    0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image8_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xce, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x4b, 0x6c, 0x54,
    0x65, 0x18, 0x86, 0x9f, 0xff, 0x3f, 0x67, 0xe6, 0xf4, 0xf4, 0x74, 0xc6,
    0x19, 0xc2, 0x14, 0x28, 0xd8, 0x80, 0x58, 0x05, 0x9c, 0x20, 0x8b, 0xa6,
    0xc1, 0xd0, 0x86, 0x4b, 0x82, 0x55, 0x63, 0x0a, 0x1b, 0xdc, 0x34, 0xb0,
    0x60, 0x65, 0x34, 0x2e, 0xbd, 0x60, 0xa2, 0x05, 0xd3, 0x70, 0xdd, 0x91,
    0x48, 0x42, 0xd4, 0xb0, 0x34, 0xc1, 0x85, 0x92, 0xc0, 0x6c, 0x08, 0x29,
    0x68, 0xdc, 0x98, 0x58, 0x25, 0x31, 0x81, 0x60, 0x9b, 0xb6, 0x43, 0x60,
    0xc0, 0x76, 0x66, 0x3a, 0xb7, 0x73, 0xce, 0x9c, 0xcb, 0xff, 0xbb, 0x30,
    0x4c, 0x22, 0x82, 0x1b, 0xbe, 0xe5, 0x97, 0xf7, 0x7b, 0xf2, 0x7e, 0xc9,
    0xfb, 0x0a, 0xad, 0x35, 0xcf, 0x32, 0xe6, 0x93, 0x96, 0x42, 0x08, 0xf1,
    0xfc, 0xd0, 0x07, 0xc3, 0xaa, 0xbf, 0x6f, 0x57, 0xca, 0x4a, 0xbc, 0xb0,
    0xc2, 0x6b, 0xce, 0xf6, 0xfa, 0xad, 0xcb, 0xdf, 0x5f, 0x39, 0xfd, 0xfb,
    0x7f, 0xb4, 0x8f, 0x3b, 0x78, 0xe9, 0xf5, 0x8f, 0xb6, 0x6d, 0xdc, 0x31,
    0x74, 0x74, 0xeb, 0xc6, 0x75, 0xfb, 0xd6, 0xac, 0x48, 0xf1, 0x57, 0x60,
    0x30, 0x5b, 0x2c, 0x51, 0xfa, 0x73, 0xc6, 0x4b, 0x94, 0x17, 0x2f, 0xc9,
    0x28, 0xfc, 0xf8, 0xea, 0xc5, 0x89, 0xe2, 0x13, 0x01, 0x83, 0xe3, 0x27,
    0x0f, 0xec, 0x79, 0x7b, 0xe7, 0x85, 0xc1, 0xa1, 0xbc, 0xf3, 0x8b, 0xdf,
    0xc5, 0xad, 0x87, 0x75, 0x82, 0x46, 0x8b, 0xd5, 0x09, 0x03, 0xd3, 0x6d,
    0xb1, 0x30, 0x3d, 0x8d, 0x28, 0x2e, 0xdc, 0x96, 0x81, 0x3f, 0xfa, 0x08,
    0xd2, 0x01, 0x6c, 0x1d, 0xfb, 0x74, 0xd3, 0xc8, 0xfe, 0x37, 0xa7, 0x5f,
    0x7b, 0x63, 0xd8, 0xfe, 0xec, 0x96, 0xc7, 0xfc, 0x52, 0x03, 0xa7, 0xdd,
    0xc4, 0xf4, 0x5d, 0xec, 0x56, 0x8d, 0xf5, 0xa6, 0x66, 0x95, 0x69, 0xd0,
    0xb8, 0x73, 0x1b, 0x71, 0xaf, 0x74, 0x35, 0x76, 0xa2, 0xb1, 0xa9, 0x0b,
    0x13, 0xbe, 0x7c, 0xf4, 0x73, 0x7f, 0x7e, 0xcb, 0x44, 0xfe, 0xd5, 0x2d,
    0xf6, 0x87, 0xd3, 0x15, 0xe6, 0x2b, 0x2d, 0x52, 0x46, 0x8c, 0x29, 0x60,
    0x34, 0x2e, 0xf3, 0x49, 0x3e, 0x4b, 0xd3, 0x6f, 0xb3, 0x54, 0x5e, 0xc2,
    0x48, 0xa7, 0xc0, 0xb6, 0xf6, 0x8a, 0xe5, 0x78, 0x0c, 0x40, 0x02, 0xac,
    0xda, 0x34, 0x9e, 0x1f, 0x18, 0xd8, 0xb0, 0xaf, 0xb0, 0x0c, 0x95, 0x6a,
    0x9d, 0x6c, 0xec, 0x91, 0x08, 0x03, 0xdc, 0x86, 0x4b, 0xfe, 0xc5, 0xd5,
    0xac, 0x5c, 0x99, 0x81, 0x30, 0x44, 0x44, 0x21, 0x5a, 0x82, 0x74, 0xba,
    0xd1, 0xda, 0x78, 0xb7, 0x03, 0xc8, 0xe5, 0x5f, 0x1e, 0x6d, 0xcb, 0xa4,
    0x5d, 0x2c, 0xd7, 0xc9, 0x44, 0x3e, 0x56, 0xd8, 0x46, 0x55, 0x2a, 0x8c,
    0xeb, 0x07, 0x18, 0x52, 0x32, 0x79, 0x63, 0x16, 0x5b, 0x87, 0x98, 0x86,
    0x84, 0xa4, 0x05, 0x96, 0x85, 0x96, 0x0c, 0x77, 0x00, 0xbd, 0xe9, 0xd4,
    0x2b, 0xbf, 0x2e, 0xd6, 0x71, 0x6b, 0x35, 0xba, 0x43, 0x1f, 0xd1, 0x6a,
    0xb2, 0x3b, 0x78, 0xc8, 0xd7, 0x87, 0xb6, 0x93, 0xcb, 0x38, 0x44, 0xf5,
    0x06, 0x5d, 0x51, 0x88, 0x34, 0x0c, 0xb0, 0x6d, 0x30, 0x0d, 0x80, 0x44,
    0x27, 0x07, 0xa6, 0x8a, 0xdd, 0xd8, 0x6b, 0x91, 0xe8, 0xee, 0x41, 0x2a,
    0x85, 0x55, 0xad, 0xf2, 0xf9, 0xfe, 0xcd, 0xdc, 0xf4, 0x0d, 0xce, 0x16,
    0x7e, 0x23, 0x17, 0xb7, 0xff, 0xb9, 0x71, 0x1c, 0x48, 0x98, 0xa8, 0x30,
    0x46, 0x45, 0xf1, 0x6c, 0xc7, 0x01, 0xf5, 0xe6, 0x54, 0x97, 0xe7, 0x62,
    0x27, 0x04, 0x49, 0xad, 0x58, 0xdb, 0x25, 0xc8, 0x65, 0x1d, 0xce, 0x7c,
    0xfb, 0x13, 0xbb, 0xd3, 0x9a, 0x91, 0x81, 0x5e, 0xfc, 0x9e, 0x0c, 0xf1,
    0x73, 0x59, 0x88, 0x62, 0xd4, 0x72, 0x1d, 0x19, 0xeb, 0x8b, 0x1d, 0x80,
    0xe1, 0x95, 0x6f, 0x98, 0xb5, 0xda, 0x1d, 0x2b, 0x0c, 0xb0, 0x33, 0x69,
    0x96, 0x2d, 0x87, 0xbb, 0x8d, 0x80, 0xf3, 0xe3, 0xdb, 0x79, 0x6b, 0xef,
    0x20, 0x37, 0x45, 0x0a, 0xb9, 0xa6, 0x0f, 0x69, 0x48, 0xf4, 0xfd, 0x12,
    0x71, 0xbd, 0x51, 0x32, 0xd0, 0xe7, 0x3b, 0x80, 0x42, 0xe1, 0xec, 0xa2,
    0xac, 0x54, 0xbe, 0xb4, 0xe6, 0xe7, 0x48, 0x2a, 0x85, 0xe8, 0x5b, 0xcb,
    0xb9, 0xbb, 0x8a, 0x6f, 0x4a, 0x8a, 0x53, 0x33, 0x6d, 0xaa, 0x56, 0x0f,
    0x49, 0x15, 0x20, 0x66, 0x66, 0x88, 0xe6, 0x8a, 0x88, 0x20, 0x3c, 0x71,
    0xed, 0xca, 0xe4, 0xc2, 0xbf, 0x82, 0x24, 0xc4, 0x31, 0xb9, 0xf3, 0x60,
    0xcf, 0x57, 0x22, 0x97, 0x3b, 0xac, 0x37, 0xac, 0xc7, 0x4d, 0x67, 0xf1,
    0x35, 0x64, 0x88, 0x31, 0xab, 0x15, 0xf4, 0xdc, 0x3c, 0xea, 0xfe, 0x03,
    0x44, 0x18, 0x9c, 0xbb, 0xfe, 0xc3, 0xd1, 0xf7, 0x9f, 0xda, 0x85, 0x5d,
    0x07, 0x8e, 0x1f, 0xd1, 0x4e, 0xf7, 0x7b, 0x22, 0x9d, 0x5a, 0x47, 0x32,
    0x89, 0x76, 0x3d, 0xa8, 0xd5, 0xc0, 0xf3, 0xfe, 0x10, 0x41, 0xf0, 0xc5,
    0xf5, 0xcb, 0x93, 0xdf, 0xfd, 0x6f, 0x99, 0x00, 0x46, 0xde, 0x39, 0xd6,
    0x2f, 0x62, 0xb9, 0x47, 0x6a, 0xb5, 0x43, 0x2b, 0x5c, 0x2d, 0x98, 0xa2,
    0xdd, 0xfe, 0xf9, 0xc7, 0xc2, 0xf1, 0xc5, 0xc7, 0xb5, 0x7f, 0x03, 0x93,
    0x83, 0x44, 0x68, 0x5e, 0x64, 0x97, 0x74, 0x00, 0x00, 0x00, 0x00, 0x49,
    0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};


/*
 *  Constructs a fitTable10 as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
fitTable10::fitTable10( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    QImage img;
    img.loadFromData( image0_data, sizeof( image0_data ), "PNG" );
    image0 = img;
    img.loadFromData( image1_data, sizeof( image1_data ), "PNG" );
    image1 = img;
    img.loadFromData( image2_data, sizeof( image2_data ), "PNG" );
    image2 = img;
    img.loadFromData( image3_data, sizeof( image3_data ), "PNG" );
    image3 = img;
    img.loadFromData( image4_data, sizeof( image4_data ), "PNG" );
    image4 = img;
    img.loadFromData( image5_data, sizeof( image5_data ), "PNG" );
    image5 = img;
    img.loadFromData( image6_data, sizeof( image6_data ), "PNG" );
    image6 = img;
    img.loadFromData( image7_data, sizeof( image7_data ), "PNG" );
    image7 = img;
    img.loadFromData( image8_data, sizeof( image8_data ), "PNG" );
    image8 = img;
    if ( !name )
	setName( "fitTable10" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 0, 0 ) );
    setMaximumSize( QSize( 5150, 6500 ) );
    setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 85, 85, 85) );
    cg.setColor( QColorGroup::Mid, QColor( 199, 199, 199) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 103, 141, 178) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 85, 85, 85) );
    cg.setColor( QColorGroup::Mid, QColor( 199, 199, 199) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 103, 141, 178) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 85, 85, 85) );
    cg.setColor( QColorGroup::Mid, QColor( 199, 199, 199) );
    cg.setColor( QColorGroup::Text, QColor( 199, 199, 199) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 86, 117, 148) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setDisabled( cg );
    setPalette( pal );
    QFont f( font() );
    setFont( f ); 
    fitTable10Layout = new QVBoxLayout( this, 4, 0, "fitTable10Layout"); 

    buttonGroupNavigator = new QButtonGroup( this, "buttonGroupNavigator" );
    buttonGroupNavigator->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroupNavigator->sizePolicy().hasHeightForWidth() ) );
    buttonGroupNavigator->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 247, 247, 247) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setDisabled( cg );
    buttonGroupNavigator->setPalette( pal );
    buttonGroupNavigator->setFrameShape( QButtonGroup::Box );
    buttonGroupNavigator->setFrameShadow( QButtonGroup::Plain );
    buttonGroupNavigator->setLineWidth( 2 );
    buttonGroupNavigator->setColumnLayout(0, Qt::Vertical );
    buttonGroupNavigator->layout()->setSpacing( 3 );
    buttonGroupNavigator->layout()->setMargin( 5 );
    buttonGroupNavigatorLayout = new QVBoxLayout( buttonGroupNavigator->layout() );
    buttonGroupNavigatorLayout->setAlignment( Qt::AlignTop );

    layout279 = new QHBoxLayout( 0, 0, 2, "layout279"); 

    pushButtonLoadFittingSession = new QPushButton( buttonGroupNavigator, "pushButtonLoadFittingSession" );
    pushButtonLoadFittingSession->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonLoadFittingSession->sizePolicy().hasHeightForWidth() ) );
    pushButtonLoadFittingSession->setMinimumSize( QSize( 0, 20 ) );
    pushButtonLoadFittingSession->setMaximumSize( QSize( 10000, 20 ) );
    pushButtonLoadFittingSession->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonLoadFittingSession->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont pushButtonLoadFittingSession_font(  pushButtonLoadFittingSession->font() );
    pushButtonLoadFittingSession_font.setBold( TRUE );
    pushButtonLoadFittingSession->setFont( pushButtonLoadFittingSession_font ); 
    pushButtonLoadFittingSession->setFlat( TRUE );
    layout279->addWidget( pushButtonLoadFittingSession );

    pushButtonSaveSession = new QPushButton( buttonGroupNavigator, "pushButtonSaveSession" );
    pushButtonSaveSession->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonSaveSession->sizePolicy().hasHeightForWidth() ) );
    pushButtonSaveSession->setMinimumSize( QSize( 0, 20 ) );
    pushButtonSaveSession->setMaximumSize( QSize( 10000, 20 ) );
    pushButtonSaveSession->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonSaveSession->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont pushButtonSaveSession_font(  pushButtonSaveSession->font() );
    pushButtonSaveSession_font.setBold( TRUE );
    pushButtonSaveSession->setFont( pushButtonSaveSession_font ); 
    pushButtonSaveSession->setFlat( TRUE );
    layout279->addWidget( pushButtonSaveSession );
    buttonGroupNavigatorLayout->addLayout( layout279 );

    buttonGroup56_2 = new QButtonGroup( buttonGroupNavigator, "buttonGroup56_2" );
    buttonGroup56_2->setMinimumSize( QSize( 0, 25 ) );
    buttonGroup56_2->setMaximumSize( QSize( 32767, 25 ) );
    buttonGroup56_2->setFrameShape( QButtonGroup::NoFrame );
    buttonGroup56_2->setFrameShadow( QButtonGroup::Plain );
    buttonGroup56_2->setLineWidth( 0 );
    buttonGroup56_2->setMargin( 0 );
    buttonGroup56_2->setColumnLayout(0, Qt::Vertical );
    buttonGroup56_2->layout()->setSpacing( 2 );
    buttonGroup56_2->layout()->setMargin( 0 );
    buttonGroup56_2Layout = new QHBoxLayout( buttonGroup56_2->layout() );
    buttonGroup56_2Layout->setAlignment( Qt::AlignTop );

    textLabelLeft = new QLabel( buttonGroup56_2, "textLabelLeft" );
    textLabelLeft->setEnabled( TRUE );
    textLabelLeft->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelLeft->sizePolicy().hasHeightForWidth() ) );
    textLabelLeft->setMinimumSize( QSize( 0, 20 ) );
    textLabelLeft->setMaximumSize( QSize( 32767, 20 ) );
    textLabelLeft->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelLeft->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    QFont textLabelLeft_font(  textLabelLeft->font() );
    textLabelLeft->setFont( textLabelLeft_font ); 
    textLabelLeft->setFrameShape( QLabel::Panel );
    textLabelLeft->setLineWidth( 1 );
    textLabelLeft->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    buttonGroup56_2Layout->addWidget( textLabelLeft );

    pushButtonFitPrev = new QToolButton( buttonGroup56_2, "pushButtonFitPrev" );
    pushButtonFitPrev->setMinimumSize( QSize( 20, 20 ) );
    pushButtonFitPrev->setMaximumSize( QSize( 20, 20 ) );
    pushButtonFitPrev->setIconSet( QIconSet( image0 ) );
    pushButtonFitPrev->setAutoRaise( TRUE );
    buttonGroup56_2Layout->addWidget( pushButtonFitPrev );

    textLabelCenter = new QLabel( buttonGroup56_2, "textLabelCenter" );
    textLabelCenter->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelCenter->sizePolicy().hasHeightForWidth() ) );
    textLabelCenter->setMinimumSize( QSize( 0, 20 ) );
    textLabelCenter->setMaximumSize( QSize( 32767, 20 ) );
    textLabelCenter->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    textLabelCenter->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelCenter_font(  textLabelCenter->font() );
    textLabelCenter_font.setBold( TRUE );
    textLabelCenter->setFont( textLabelCenter_font ); 
    textLabelCenter->setFrameShape( QLabel::Panel );
    textLabelCenter->setLineWidth( 2 );
    textLabelCenter->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    buttonGroup56_2Layout->addWidget( textLabelCenter );

    pushButtonFitNext = new QToolButton( buttonGroup56_2, "pushButtonFitNext" );
    pushButtonFitNext->setMinimumSize( QSize( 20, 20 ) );
    pushButtonFitNext->setMaximumSize( QSize( 20, 20 ) );
    pushButtonFitNext->setIconSet( QIconSet( image1 ) );
    pushButtonFitNext->setAutoRaise( TRUE );
    buttonGroup56_2Layout->addWidget( pushButtonFitNext );

    textLabelRight = new QLabel( buttonGroup56_2, "textLabelRight" );
    textLabelRight->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelRight->sizePolicy().hasHeightForWidth() ) );
    textLabelRight->setMinimumSize( QSize( 0, 20 ) );
    textLabelRight->setMaximumSize( QSize( 32767, 20 ) );
    textLabelRight->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelRight->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    QFont textLabelRight_font(  textLabelRight->font() );
    textLabelRight->setFont( textLabelRight_font ); 
    textLabelRight->setFrameShape( QLabel::Panel );
    textLabelRight->setLineWidth( 1 );
    textLabelRight->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    textLabelRight->setIndent( -1 );
    buttonGroup56_2Layout->addWidget( textLabelRight );
    buttonGroupNavigatorLayout->addWidget( buttonGroup56_2 );
    fitTable10Layout->addWidget( buttonGroupNavigator );
    spacer38 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Fixed );
    fitTable10Layout->addItem( spacer38 );

    widgetStackFit = new QWidgetStack( this, "widgetStackFit" );
    widgetStackFit->setEnabled( TRUE );
    widgetStackFit->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)2, 0, 0, widgetStackFit->sizePolicy().hasHeightForWidth() ) );
    widgetStackFit->setMinimumSize( QSize( 420, 300 ) );
    widgetStackFit->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    widgetStackFit->setPalette( pal );
    widgetStackFit->setFrameShape( QWidgetStack::NoFrame );
    widgetStackFit->setFrameShadow( QWidgetStack::Plain );
    widgetStackFit->setLineWidth( 0 );

    WStackPageFitFunction = new QWidget( widgetStackFit, "WStackPageFitFunction" );
    WStackPageFitFunctionLayout = new QVBoxLayout( WStackPageFitFunction, 0, 6, "WStackPageFitFunctionLayout"); 

    splitter8 = new QSplitter( WStackPageFitFunction, "splitter8" );
    splitter8->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, splitter8->sizePolicy().hasHeightForWidth() ) );
    splitter8->setMinimumSize( QSize( 311, 372 ) );
    splitter8->setLineWidth( 0 );
    splitter8->setOrientation( QSplitter::Vertical );
    splitter8->setHandleWidth( 8 );

    splitter7 = new QSplitter( splitter8, "splitter7" );
    splitter7->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, splitter7->sizePolicy().hasHeightForWidth() ) );
    splitter7->setLineWidth( 0 );
    splitter7->setOrientation( QSplitter::Horizontal );
    splitter7->setOpaqueResize( TRUE );
    splitter7->setHandleWidth( 8 );

    QWidget* privateLayoutWidget = new QWidget( splitter7, "layout33" );
    layout33 = new QVBoxLayout( privateLayoutWidget, 0, 0, "layout33"); 

    layout32 = new QHBoxLayout( 0, 0, 0, "layout32"); 

    textLabelGroupName_2 = new QLabel( privateLayoutWidget, "textLabelGroupName_2" );
    textLabelGroupName_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, textLabelGroupName_2->sizePolicy().hasHeightForWidth() ) );
    textLabelGroupName_2->setMinimumSize( QSize( 0, 20 ) );
    textLabelGroupName_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelGroupName_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelGroupName_2->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QFont textLabelGroupName_2_font(  textLabelGroupName_2->font() );
    textLabelGroupName_2->setFont( textLabelGroupName_2_font ); 
    textLabelGroupName_2->setAlignment( int( QLabel::AlignVCenter ) );
    layout32->addWidget( textLabelGroupName_2 );
    layout33->addLayout( layout32 );

    listBoxGroup = new QListBox( privateLayoutWidget, "listBoxGroup" );
    listBoxGroup->setMinimumSize( QSize( 0, 150 ) );
    listBoxGroup->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    listBoxGroup->setPalette( pal );
    listBoxGroup->setBackgroundOrigin( QListBox::WidgetOrigin );
    listBoxGroup->setFrameShape( QListBox::GroupBoxPanel );
    listBoxGroup->setLineWidth( 2 );
    layout33->addWidget( listBoxGroup );

    QWidget* privateLayoutWidget_2 = new QWidget( splitter7, "layout75" );
    layout75 = new QVBoxLayout( privateLayoutWidget_2, 0, 0, "layout75"); 

    layout74 = new QHBoxLayout( 0, 0, 6, "layout74"); 

    textLabelFunctionName_2 = new QLabel( privateLayoutWidget_2, "textLabelFunctionName_2" );
    textLabelFunctionName_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelFunctionName_2->sizePolicy().hasHeightForWidth() ) );
    textLabelFunctionName_2->setMinimumSize( QSize( 0, 20 ) );
    textLabelFunctionName_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelFunctionName_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelFunctionName_2->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QFont textLabelFunctionName_2_font(  textLabelFunctionName_2->font() );
    textLabelFunctionName_2->setFont( textLabelFunctionName_2_font ); 
    textLabelFunctionName_2->setAlignment( int( QLabel::AlignVCenter ) );
    layout74->addWidget( textLabelFunctionName_2 );
    layout75->addLayout( layout74 );

    listBoxFunctions = new QListBox( privateLayoutWidget_2, "listBoxFunctions" );
    listBoxFunctions->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    listBoxFunctions->setPalette( pal );
    listBoxFunctions->setFrameShape( QListBox::GroupBoxPanel );
    listBoxFunctions->setLineWidth( 2 );
    layout75->addWidget( listBoxFunctions );

    tabWidget4 = new QTabWidget( splitter8, "tabWidget4" );
    tabWidget4->setTabPosition( QTabWidget::Bottom );
    tabWidget4->setTabShape( QTabWidget::Rounded );
    tabWidget4->setMargin( 0 );

    tab = new QWidget( tabWidget4, "tab" );
    tabLayout = new QVBoxLayout( tab, 0, 6, "tabLayout"); 

    textBrowserFunctionDescription00 = new QTextBrowser( tab, "textBrowserFunctionDescription00" );
    textBrowserFunctionDescription00->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont textBrowserFunctionDescription00_font(  textBrowserFunctionDescription00->font() );
    textBrowserFunctionDescription00->setFont( textBrowserFunctionDescription00_font ); 
    textBrowserFunctionDescription00->setFrameShape( QTextBrowser::GroupBoxPanel );
    textBrowserFunctionDescription00->setFrameShadow( QTextBrowser::Plain );
    textBrowserFunctionDescription00->setLineWidth( 0 );
    textBrowserFunctionDescription00->setMargin( 7 );
    textBrowserFunctionDescription00->setTextFormat( QTextBrowser::RichText );
    tabLayout->addWidget( textBrowserFunctionDescription00 );
    tabWidget4->insertTab( tab, QString::fromLatin1("") );

    tab_2 = new QWidget( tabWidget4, "tab_2" );
    tabLayout_2 = new QHBoxLayout( tab_2, 11, 6, "tabLayout_2"); 

    tableParaComments00 = new QTable( tab_2, "tableParaComments00" );
    tableParaComments00->setNumCols( tableParaComments00->numCols() + 1 );
    tableParaComments00->horizontalHeader()->setLabel( tableParaComments00->numCols() - 1, tr( "Description of Parameters      " ) );
    tableParaComments00->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tableParaComments00->setPalette( pal );
    tableParaComments00->setFrameShape( QTable::GroupBoxPanel );
    tableParaComments00->setFrameShadow( QTable::Sunken );
    tableParaComments00->setLineWidth( 2 );
    tableParaComments00->setMargin( 0 );
    tableParaComments00->setResizePolicy( QTable::AutoOne );
    tableParaComments00->setVScrollBarMode( QTable::Auto );
    tableParaComments00->setHScrollBarMode( QTable::Auto );
    tableParaComments00->setNumRows( 0 );
    tableParaComments00->setNumCols( 1 );
    tableParaComments00->setShowGrid( FALSE );
    tableParaComments00->setRowMovingEnabled( FALSE );
    tableParaComments00->setReadOnly( TRUE );
    tabLayout_2->addWidget( tableParaComments00 );
    tabWidget4->insertTab( tab_2, QString::fromLatin1("") );

    TabPage = new QWidget( tabWidget4, "TabPage" );
    TabPageLayout = new QVBoxLayout( TabPage, 11, 6, "TabPageLayout"); 

    layout127 = new QHBoxLayout( 0, 0, 6, "layout127"); 

    layout125 = new QVBoxLayout( 0, 0, 6, "layout125"); 

    layout46 = new QHBoxLayout( 0, 0, 0, "layout46"); 

    checkBoxSANSsupport = new QCheckBox( TabPage, "checkBoxSANSsupport" );
    checkBoxSANSsupport->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, checkBoxSANSsupport->sizePolicy().hasHeightForWidth() ) );
    checkBoxSANSsupport->setMinimumSize( QSize( 0, 25 ) );
    checkBoxSANSsupport->setMaximumSize( QSize( 32767, 25 ) );
    checkBoxSANSsupport->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxSANSsupport->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    layout46->addWidget( checkBoxSANSsupport );

    line1_2_2_2 = new QFrame( TabPage, "line1_2_2_2" );
    line1_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, line1_2_2_2->sizePolicy().hasHeightForWidth() ) );
    line1_2_2_2->setMinimumSize( QSize( 30, 0 ) );
    line1_2_2_2->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_2_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_2_2->setFrameShape( QFrame::HLine );
    line1_2_2_2->setFrameShadow( QFrame::Plain );
    line1_2_2_2->setLineWidth( 1 );
    line1_2_2_2->setFrameShape( QFrame::HLine );
    layout46->addWidget( line1_2_2_2 );
    layout125->addLayout( layout46 );

    layout47 = new QHBoxLayout( 0, 0, 0, "layout47"); 

    checkBoxMultiData = new QCheckBox( TabPage, "checkBoxMultiData" );
    checkBoxMultiData->setMinimumSize( QSize( 0, 25 ) );
    checkBoxMultiData->setMaximumSize( QSize( 32767, 25 ) );
    checkBoxMultiData->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxMultiData->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    layout47->addWidget( checkBoxMultiData );

    line1_2_2_2_2 = new QFrame( TabPage, "line1_2_2_2_2" );
    line1_2_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, line1_2_2_2_2->sizePolicy().hasHeightForWidth() ) );
    line1_2_2_2_2->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_2_2_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_2_2_2->setFrameShape( QFrame::HLine );
    line1_2_2_2_2->setFrameShadow( QFrame::Plain );
    line1_2_2_2_2->setLineWidth( 1 );
    line1_2_2_2_2->setFrameShape( QFrame::HLine );
    layout47->addWidget( line1_2_2_2_2 );
    layout125->addLayout( layout47 );

    layout48 = new QHBoxLayout( 0, 0, 0, "layout48"); 

    checkBoxSuperpositionalFit = new QCheckBox( TabPage, "checkBoxSuperpositionalFit" );
    checkBoxSuperpositionalFit->setMinimumSize( QSize( 0, 25 ) );
    checkBoxSuperpositionalFit->setMaximumSize( QSize( 32767, 25 ) );
    checkBoxSuperpositionalFit->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxSuperpositionalFit->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    layout48->addWidget( checkBoxSuperpositionalFit );

    line1_2_2_2_3 = new QFrame( TabPage, "line1_2_2_2_3" );
    line1_2_2_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, line1_2_2_2_3->sizePolicy().hasHeightForWidth() ) );
    line1_2_2_2_3->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_2_2_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_2_2_3->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_2_2_3->setFrameShape( QFrame::HLine );
    line1_2_2_2_3->setFrameShadow( QFrame::Plain );
    line1_2_2_2_3->setLineWidth( 1 );
    line1_2_2_2_3->setFrameShape( QFrame::HLine );
    layout48->addWidget( line1_2_2_2_3 );
    layout125->addLayout( layout48 );

    layout124 = new QHBoxLayout( 0, 0, 0, "layout124"); 

    checkBoxShowEFIT = new QCheckBox( TabPage, "checkBoxShowEFIT" );
    checkBoxShowEFIT->setMinimumSize( QSize( 0, 25 ) );
    checkBoxShowEFIT->setMaximumSize( QSize( 32767, 25 ) );
    checkBoxShowEFIT->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout124->addWidget( checkBoxShowEFIT );

    line1_2_2_2_3_2 = new QFrame( TabPage, "line1_2_2_2_3_2" );
    line1_2_2_2_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, line1_2_2_2_3_2->sizePolicy().hasHeightForWidth() ) );
    line1_2_2_2_3_2->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_2_2_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_2_2_3_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_2_2_3_2->setFrameShape( QFrame::HLine );
    line1_2_2_2_3_2->setFrameShadow( QFrame::Plain );
    line1_2_2_2_3_2->setLineWidth( 1 );
    line1_2_2_2_3_2->setFrameShape( QFrame::HLine );
    layout124->addWidget( line1_2_2_2_3_2 );
    layout125->addLayout( layout124 );
    layout127->addLayout( layout125 );

    layout126 = new QVBoxLayout( 0, 0, 6, "layout126"); 

    comboBoxInstrument = new QComboBox( FALSE, TabPage, "comboBoxInstrument" );
    comboBoxInstrument->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxInstrument->sizePolicy().hasHeightForWidth() ) );
    comboBoxInstrument->setMaximumSize( QSize( 2000, 25 ) );
    comboBoxInstrument->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, white );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 127, 127, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 170, 170, 170) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, white );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 127, 127, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 170, 170, 170) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, white );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 127, 127, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 170, 170, 170) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    comboBoxInstrument->setPalette( pal );
    layout126->addWidget( comboBoxInstrument );

    spinBoxNumberCurvesToFit = new QSpinBox( TabPage, "spinBoxNumberCurvesToFit" );
    spinBoxNumberCurvesToFit->setEnabled( TRUE );
    spinBoxNumberCurvesToFit->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxNumberCurvesToFit->sizePolicy().hasHeightForWidth() ) );
    spinBoxNumberCurvesToFit->setMaximumSize( QSize( 2000, 25 ) );
    spinBoxNumberCurvesToFit->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    spinBoxNumberCurvesToFit->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxNumberCurvesToFit->setPalette( pal );
    spinBoxNumberCurvesToFit->setMaxValue( 20 );
    spinBoxNumberCurvesToFit->setMinValue( 1 );
    layout126->addWidget( spinBoxNumberCurvesToFit );

    layout157 = new QHBoxLayout( 0, 0, 6, "layout157"); 

    spinBoxSubFitNumber = new QSpinBox( TabPage, "spinBoxSubFitNumber" );
    spinBoxSubFitNumber->setEnabled( TRUE );
    spinBoxSubFitNumber->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxSubFitNumber->sizePolicy().hasHeightForWidth() ) );
    spinBoxSubFitNumber->setMaximumSize( QSize( 2000, 25 ) );
    spinBoxSubFitNumber->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    spinBoxSubFitNumber->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxSubFitNumber->setPalette( pal );
    spinBoxSubFitNumber->setMaxValue( 100 );
    spinBoxSubFitNumber->setMinValue( 1 );
    layout157->addWidget( spinBoxSubFitNumber );

    spinBoxSubFitCurrent = new QSpinBox( TabPage, "spinBoxSubFitCurrent" );
    spinBoxSubFitCurrent->setEnabled( TRUE );
    spinBoxSubFitCurrent->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxSubFitCurrent->sizePolicy().hasHeightForWidth() ) );
    spinBoxSubFitCurrent->setMaximumSize( QSize( 2000, 25 ) );
    spinBoxSubFitCurrent->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    spinBoxSubFitCurrent->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxSubFitCurrent->setPalette( pal );
    spinBoxSubFitCurrent->setMaxValue( 100 );
    spinBoxSubFitCurrent->setMinValue( 1 );
    spinBoxSubFitCurrent->setValue( 2 );
    layout157->addWidget( spinBoxSubFitCurrent );
    layout126->addLayout( layout157 );

    layout97 = new QHBoxLayout( 0, 0, 6, "layout97"); 

    pushButtonIFIT = new QPushButton( TabPage, "pushButtonIFIT" );
    pushButtonIFIT->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonIFIT->sizePolicy().hasHeightForWidth() ) );
    pushButtonIFIT->setMinimumSize( QSize( 0, 25 ) );
    pushButtonIFIT->setMaximumSize( QSize( 10000, 25 ) );
    pushButtonIFIT->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonIFIT->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont pushButtonIFIT_font(  pushButtonIFIT->font() );
    pushButtonIFIT_font.setBold( TRUE );
    pushButtonIFIT->setFont( pushButtonIFIT_font ); 
    pushButtonIFIT->setFlat( TRUE );
    layout97->addWidget( pushButtonIFIT );

    pushButtonIFITadv = new QPushButton( TabPage, "pushButtonIFITadv" );
    pushButtonIFITadv->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonIFITadv->sizePolicy().hasHeightForWidth() ) );
    pushButtonIFITadv->setMinimumSize( QSize( 0, 25 ) );
    pushButtonIFITadv->setMaximumSize( QSize( 10000, 25 ) );
    pushButtonIFITadv->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonIFITadv->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont pushButtonIFITadv_font(  pushButtonIFITadv->font() );
    pushButtonIFITadv_font.setBold( TRUE );
    pushButtonIFITadv->setFont( pushButtonIFITadv_font ); 
    pushButtonIFITadv->setFlat( TRUE );
    layout97->addWidget( pushButtonIFITadv );
    layout126->addLayout( layout97 );
    layout127->addLayout( layout126 );
    TabPageLayout->addLayout( layout127 );
    spacer73 = new QSpacerItem( 16, 413, QSizePolicy::Minimum, QSizePolicy::Expanding );
    TabPageLayout->addItem( spacer73 );
    tabWidget4->insertTab( TabPage, QString::fromLatin1("") );
    WStackPageFitFunctionLayout->addWidget( splitter8 );
    widgetStackFit->addWidget( WStackPageFitFunction, 0 );

    WStackPageFitData = new QWidget( widgetStackFit, "WStackPageFitData" );
    WStackPageFitDataLayout = new QVBoxLayout( WStackPageFitData, 0, 6, "WStackPageFitDataLayout"); 

    tabWidgetFit = new QTabWidget( WStackPageFitData, "tabWidgetFit" );
    tabWidgetFit->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, tabWidgetFit->sizePolicy().hasHeightForWidth() ) );
    tabWidgetFit->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    tabWidgetFit->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tabWidgetFit->setPalette( pal );
    tabWidgetFit->setBackgroundOrigin( QTabWidget::WidgetOrigin );
    QFont tabWidgetFit_font(  tabWidgetFit->font() );
    tabWidgetFit->setFont( tabWidgetFit_font ); 
    tabWidgetFit->setTabPosition( QTabWidget::Top );
    tabWidgetFit->setTabShape( QTabWidget::Rounded );
    tabWidgetFit->setMargin( 0 );

    dataSets = new QWidget( tabWidgetFit, "dataSets" );
    dataSetsLayout = new QHBoxLayout( dataSets, 5, 0, "dataSetsLayout"); 

    tableCurves = new QTable( dataSets, "tableCurves" );
    tableCurves->setNumRows( tableCurves->numRows() + 1 );
    tableCurves->verticalHeader()->setLabel( tableCurves->numRows() - 1, image2, tr( "DataSets" ) );
    tableCurves->setNumRows( tableCurves->numRows() + 1 );
    tableCurves->verticalHeader()->setLabel( tableCurves->numRows() - 1, tr( "# points" ) );
    tableCurves->setNumRows( tableCurves->numRows() + 1 );
    tableCurves->verticalHeader()->setLabel( tableCurves->numRows() - 1, tr( "first point" ) );
    tableCurves->setNumRows( tableCurves->numRows() + 1 );
    tableCurves->verticalHeader()->setLabel( tableCurves->numRows() - 1, tr( "last point" ) );
    tableCurves->setNumRows( tableCurves->numRows() + 1 );
    tableCurves->verticalHeader()->setLabel( tableCurves->numRows() - 1, tr( "Weighting" ) );
    tableCurves->setNumRows( tableCurves->numRows() + 1 );
    tableCurves->verticalHeader()->setLabel( tableCurves->numRows() - 1, tr( "Resolution" ) );
    tableCurves->setNumRows( tableCurves->numRows() + 1 );
    tableCurves->verticalHeader()->setLabel( tableCurves->numRows() - 1, tr( "Polydispersity" ) );
    tableCurves->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, tableCurves->sizePolicy().hasHeightForWidth() ) );
    tableCurves->setMaximumSize( QSize( 32767, 3500 ) );
    tableCurves->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    tableCurves->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tableCurves->setPalette( pal );
    tableCurves->setBackgroundOrigin( QTable::ParentOrigin );
    QFont tableCurves_font(  tableCurves->font() );
    tableCurves->setFont( tableCurves_font ); 
    tableCurves->setAcceptDrops( TRUE );
    tableCurves->setFrameShape( QTable::LineEditPanel );
    tableCurves->setFrameShadow( QTable::Plain );
    tableCurves->setLineWidth( 0 );
    tableCurves->setMargin( 0 );
    tableCurves->setMidLineWidth( 0 );
    tableCurves->setResizePolicy( QTable::Default );
    tableCurves->setNumRows( 7 );
    tableCurves->setNumCols( 2 );
    dataSetsLayout->addWidget( tableCurves );
    tabWidgetFit->insertTab( dataSets, QString::fromLatin1("") );

    Function = new QWidget( tabWidgetFit, "Function" );
    FunctionLayout = new QVBoxLayout( Function, 5, 2, "FunctionLayout"); 

    textLabelFfunc = new QLabel( Function, "textLabelFfunc" );
    textLabelFfunc->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelFfunc->sizePolicy().hasHeightForWidth() ) );
    textLabelFfunc->setMinimumSize( QSize( 0, 20 ) );
    textLabelFfunc->setMaximumSize( QSize( 32767, 20 ) );
    textLabelFfunc->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelFfunc->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelFfunc_font(  textLabelFfunc->font() );
    textLabelFfunc_font.setBold( TRUE );
    textLabelFfunc->setFont( textLabelFfunc_font ); 
    textLabelFfunc->setFrameShape( QLabel::Panel );
    textLabelFfunc->setFrameShadow( QLabel::Plain );
    textLabelFfunc->setLineWidth( 1 );
    textLabelFfunc->setMargin( 0 );
    textLabelFfunc->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignLeft ) );
    FunctionLayout->addWidget( textLabelFfunc );

    layout62 = new QHBoxLayout( 0, 0, 3, "layout62"); 

    spinBoxPara = new QSpinBox( Function, "spinBoxPara" );
    spinBoxPara->setEnabled( FALSE );
    spinBoxPara->setMinimumSize( QSize( 35, 20 ) );
    spinBoxPara->setMaximumSize( QSize( 500, 20 ) );
    spinBoxPara->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    spinBoxPara->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 245, 244, 235) );
    cg.setColor( QColorGroup::Dark, QColor( 118, 116, 108) );
    cg.setColor( QColorGroup::Mid, QColor( 157, 155, 143) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 254, 249) );
    cg.setColor( QColorGroup::Dark, QColor( 118, 116, 108) );
    cg.setColor( QColorGroup::Mid, QColor( 157, 155, 143) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 254, 249) );
    cg.setColor( QColorGroup::Dark, QColor( 118, 116, 108) );
    cg.setColor( QColorGroup::Mid, QColor( 157, 155, 143) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxPara->setPalette( pal );
    QFont spinBoxPara_font(  spinBoxPara->font() );
    spinBoxPara->setFont( spinBoxPara_font ); 
    spinBoxPara->setWrapping( FALSE );
    spinBoxPara->setMaxValue( 1000 );
    spinBoxPara->setValue( 0 );
    layout62->addWidget( spinBoxPara );

    spinBoxXnumber = new QSpinBox( Function, "spinBoxXnumber" );
    spinBoxXnumber->setEnabled( FALSE );
    spinBoxXnumber->setMinimumSize( QSize( 35, 20 ) );
    spinBoxXnumber->setMaximumSize( QSize( 500, 20 ) );
    spinBoxXnumber->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    spinBoxXnumber->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 245, 244, 235) );
    cg.setColor( QColorGroup::Dark, QColor( 118, 116, 108) );
    cg.setColor( QColorGroup::Mid, QColor( 157, 155, 143) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 254, 249) );
    cg.setColor( QColorGroup::Dark, QColor( 118, 116, 108) );
    cg.setColor( QColorGroup::Mid, QColor( 157, 155, 143) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 254, 249) );
    cg.setColor( QColorGroup::Dark, QColor( 118, 116, 108) );
    cg.setColor( QColorGroup::Mid, QColor( 157, 155, 143) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxXnumber->setPalette( pal );
    QFont spinBoxXnumber_font(  spinBoxXnumber->font() );
    spinBoxXnumber->setFont( spinBoxXnumber_font ); 
    spinBoxXnumber->setWrapping( FALSE );
    spinBoxXnumber->setMaxValue( 10 );
    spinBoxXnumber->setMinValue( 1 );
    spinBoxXnumber->setValue( 1 );
    layout62->addWidget( spinBoxXnumber );

    spinBoxFnumber = new QSpinBox( Function, "spinBoxFnumber" );
    spinBoxFnumber->setEnabled( FALSE );
    spinBoxFnumber->setMinimumSize( QSize( 35, 20 ) );
    spinBoxFnumber->setMaximumSize( QSize( 500, 20 ) );
    spinBoxFnumber->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    spinBoxFnumber->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 245, 244, 235) );
    cg.setColor( QColorGroup::Dark, QColor( 118, 116, 108) );
    cg.setColor( QColorGroup::Mid, QColor( 157, 155, 143) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 254, 249) );
    cg.setColor( QColorGroup::Dark, QColor( 118, 116, 108) );
    cg.setColor( QColorGroup::Mid, QColor( 157, 155, 143) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 254, 249) );
    cg.setColor( QColorGroup::Dark, QColor( 118, 116, 108) );
    cg.setColor( QColorGroup::Mid, QColor( 157, 155, 143) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxFnumber->setPalette( pal );
    QFont spinBoxFnumber_font(  spinBoxFnumber->font() );
    spinBoxFnumber->setFont( spinBoxFnumber_font ); 
    spinBoxFnumber->setWrapping( FALSE );
    spinBoxFnumber->setMaxValue( 20 );
    spinBoxFnumber->setMinValue( 1 );
    spinBoxFnumber->setValue( 1 );
    layout62->addWidget( spinBoxFnumber );
    FunctionLayout->addLayout( layout62 );

    splitter8_2 = new QSplitter( Function, "splitter8_2" );
    splitter8_2->setLineWidth( 0 );
    splitter8_2->setOrientation( QSplitter::Vertical );

    textBrowserFunctionDescription = new QTextBrowser( splitter8_2, "textBrowserFunctionDescription" );
    QFont textBrowserFunctionDescription_font(  textBrowserFunctionDescription->font() );
    textBrowserFunctionDescription_font.setPointSize( 11 );
    textBrowserFunctionDescription->setFont( textBrowserFunctionDescription_font ); 
    textBrowserFunctionDescription->setFrameShape( QTextBrowser::GroupBoxPanel );
    textBrowserFunctionDescription->setFrameShadow( QTextBrowser::Sunken );
    textBrowserFunctionDescription->setLineWidth( 2 );
    textBrowserFunctionDescription->setTextFormat( QTextBrowser::RichText );

    tableParaComments = new QTable( splitter8_2, "tableParaComments" );
    tableParaComments->setNumCols( tableParaComments->numCols() + 1 );
    tableParaComments->horizontalHeader()->setLabel( tableParaComments->numCols() - 1, tr( "Description of Parameters      " ) );
    tableParaComments->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, tableParaComments->sizePolicy().hasHeightForWidth() ) );
    tableParaComments->setMaximumSize( QSize( 32767, 3500 ) );
    tableParaComments->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tableParaComments->setPalette( pal );
    tableParaComments->setFrameShape( QTable::NoFrame );
    tableParaComments->setFrameShadow( QTable::Plain );
    tableParaComments->setLineWidth( 0 );
    tableParaComments->setResizePolicy( QTable::Default );
    tableParaComments->setVScrollBarMode( QTable::Auto );
    tableParaComments->setHScrollBarMode( QTable::Auto );
    tableParaComments->setNumRows( 0 );
    tableParaComments->setNumCols( 1 );
    tableParaComments->setShowGrid( FALSE );
    tableParaComments->setReadOnly( TRUE );
    tableParaComments->setFocusStyle( QTable::SpreadSheet );
    FunctionLayout->addWidget( splitter8_2 );
    tabWidgetFit->insertTab( Function, QString::fromLatin1("") );

    parameters = new QWidget( tabWidgetFit, "parameters" );
    parametersLayout = new QHBoxLayout( parameters, 5, 2, "parametersLayout"); 

    tablePara = new QTable( parameters, "tablePara" );
    tablePara->setNumCols( tablePara->numCols() + 1 );
    tablePara->horizontalHeader()->setLabel( tablePara->numCols() - 1, tr( " Share?" ) );
    tablePara->setNumCols( tablePara->numCols() + 1 );
    tablePara->horizontalHeader()->setLabel( tablePara->numCols() - 1, tr( "Vary?" ) );
    tablePara->setNumCols( tablePara->numCols() + 1 );
    tablePara->horizontalHeader()->setLabel( tablePara->numCols() - 1, tr( "Value" ) );
    tablePara->setNumCols( tablePara->numCols() + 1 );
    tablePara->horizontalHeader()->setLabel( tablePara->numCols() - 1, tr( "Error" ) );
    tablePara->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, tablePara->sizePolicy().hasHeightForWidth() ) );
    tablePara->setMaximumSize( QSize( 32767, 3500 ) );
    tablePara->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    tablePara->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tablePara->setPalette( pal );
    tablePara->setBackgroundOrigin( QTable::WidgetOrigin );
    QFont tablePara_font(  tablePara->font() );
    tablePara->setFont( tablePara_font ); 
    tablePara->setFrameShape( QTable::NoFrame );
    tablePara->setFrameShadow( QTable::Plain );
    tablePara->setLineWidth( 0 );
    tablePara->setMidLineWidth( 0 );
    tablePara->setResizePolicy( QTable::Default );
    tablePara->setNumRows( 0 );
    tablePara->setNumCols( 4 );
    tablePara->setFocusStyle( QTable::SpreadSheet );
    parametersLayout->addWidget( tablePara );
    tabWidgetFit->insertTab( parameters, QString::fromLatin1("") );

    TabPage_2 = new QWidget( tabWidgetFit, "TabPage_2" );
    TabPageLayout_2 = new QVBoxLayout( TabPage_2, 11, 6, "TabPageLayout_2"); 

    tableControl = new QTable( TabPage_2, "tableControl" );
    tableControl->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, tableControl->sizePolicy().hasHeightForWidth() ) );
    tableControl->setMaximumSize( QSize( 32767, 3500 ) );
    tableControl->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tableControl->setPalette( pal );
    tableControl->setFocusPolicy( QTable::WheelFocus );
    tableControl->setFrameShape( QTable::NoFrame );
    tableControl->setFrameShadow( QTable::Plain );
    tableControl->setLineWidth( 0 );
    tableControl->setMargin( 0 );
    tableControl->setMidLineWidth( 0 );
    tableControl->setResizePolicy( QTable::Default );
    tableControl->setNumRows( 0 );
    tableControl->setNumCols( 5 );
    tableControl->setShowGrid( TRUE );
    TabPageLayout_2->addWidget( tableControl );

    buttonGroup21 = new QButtonGroup( TabPage_2, "buttonGroup21" );
    buttonGroup21->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup21->sizePolicy().hasHeightForWidth() ) );
    buttonGroup21->setColumnLayout(0, Qt::Vertical );
    buttonGroup21->layout()->setSpacing( 6 );
    buttonGroup21->layout()->setMargin( 11 );
    buttonGroup21Layout = new QHBoxLayout( buttonGroup21->layout() );
    buttonGroup21Layout->setAlignment( Qt::AlignTop );

    textLabelRandomSeed_3 = new QLabel( buttonGroup21, "textLabelRandomSeed_3" );
    textLabelRandomSeed_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabelRandomSeed_3->sizePolicy().hasHeightForWidth() ) );
    textLabelRandomSeed_3->setMaximumSize( QSize( 32767, 25 ) );
    buttonGroup21Layout->addWidget( textLabelRandomSeed_3 );

    lineEditLeftMargin = new QLineEdit( buttonGroup21, "lineEditLeftMargin" );
    lineEditLeftMargin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)7, 0, 0, lineEditLeftMargin->sizePolicy().hasHeightForWidth() ) );
    lineEditLeftMargin->setMinimumSize( QSize( 20, 15 ) );
    lineEditLeftMargin->setMaximumSize( QSize( 50, 25 ) );
    buttonGroup21Layout->addWidget( lineEditLeftMargin );

    textLabel2 = new QLabel( buttonGroup21, "textLabel2" );
    textLabel2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel2->sizePolicy().hasHeightForWidth() ) );
    textLabel2->setMinimumSize( QSize( 0, 25 ) );
    buttonGroup21Layout->addWidget( textLabel2 );

    lineEditRightMargin = new QLineEdit( buttonGroup21, "lineEditRightMargin" );
    lineEditRightMargin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)7, 0, 0, lineEditRightMargin->sizePolicy().hasHeightForWidth() ) );
    lineEditRightMargin->setMinimumSize( QSize( 20, 25 ) );
    lineEditRightMargin->setMaximumSize( QSize( 50, 30 ) );
    buttonGroup21Layout->addWidget( lineEditRightMargin );

    textLabelRandomSeed_3_2 = new QLabel( buttonGroup21, "textLabelRandomSeed_3_2" );
    textLabelRandomSeed_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabelRandomSeed_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabelRandomSeed_3_2->setMaximumSize( QSize( 32444, 25 ) );
    buttonGroup21Layout->addWidget( textLabelRandomSeed_3_2 );

    toolButtonApplyLimits = new QToolButton( buttonGroup21, "toolButtonApplyLimits" );
    toolButtonApplyLimits->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, toolButtonApplyLimits->sizePolicy().hasHeightForWidth() ) );
    toolButtonApplyLimits->setMaximumSize( QSize( 32767, 25 ) );
    buttonGroup21Layout->addWidget( toolButtonApplyLimits );

    toolButtonResetLimits = new QToolButton( buttonGroup21, "toolButtonResetLimits" );
    toolButtonResetLimits->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, toolButtonResetLimits->sizePolicy().hasHeightForWidth() ) );
    toolButtonResetLimits->setMaximumSize( QSize( 32767, 25 ) );
    buttonGroup21Layout->addWidget( toolButtonResetLimits );
    TabPageLayout_2->addWidget( buttonGroup21 );
    tabWidgetFit->insertTab( TabPage_2, QString::fromLatin1("") );

    TabPage_3 = new QWidget( tabWidgetFit, "TabPage_3" );
    TabPageLayout_3 = new QHBoxLayout( TabPage_3, 11, 6, "TabPageLayout_3"); 

    layout130 = new QVBoxLayout( 0, 0, 6, "layout130"); 

    buttonGroup18 = new QButtonGroup( TabPage_3, "buttonGroup18" );
    buttonGroup18->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, buttonGroup18->sizePolicy().hasHeightForWidth() ) );
    buttonGroup18->setLineWidth( 0 );
    buttonGroup18->setColumnLayout(0, Qt::Vertical );
    buttonGroup18->layout()->setSpacing( 6 );
    buttonGroup18->layout()->setMargin( 0 );
    buttonGroup18Layout = new QHBoxLayout( buttonGroup18->layout() );
    buttonGroup18Layout->setAlignment( Qt::AlignTop );

    layout76 = new QVBoxLayout( 0, 0, 6, "layout76"); 

    textLabel1_2_2 = new QLabel( buttonGroup18, "textLabel1_2_2" );
    textLabel1_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabel1_2_2_font(  textLabel1_2_2->font() );
    textLabel1_2_2_font.setBold( TRUE );
    textLabel1_2_2->setFont( textLabel1_2_2_font ); 
    layout76->addWidget( textLabel1_2_2 );

    textLabel2_2_2_2 = new QLabel( buttonGroup18, "textLabel2_2_2_2" );
    textLabel2_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout76->addWidget( textLabel2_2_2_2 );
    buttonGroup18Layout->addLayout( layout76 );

    layout395 = new QVBoxLayout( 0, 0, 6, "layout395"); 

    comboBoxFitMethod = new QComboBox( FALSE, buttonGroup18, "comboBoxFitMethod" );
    comboBoxFitMethod->setEnabled( TRUE );
    comboBoxFitMethod->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, comboBoxFitMethod->sizePolicy().hasHeightForWidth() ) );
    comboBoxFitMethod->setMinimumSize( QSize( 250, 25 ) );
    comboBoxFitMethod->setMaximumSize( QSize( 3000, 25 ) );
    comboBoxFitMethod->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxFitMethod->setPalette( pal );
    QFont comboBoxFitMethod_font(  comboBoxFitMethod->font() );
    comboBoxFitMethod->setFont( comboBoxFitMethod_font ); 
    comboBoxFitMethod->setAutoMask( FALSE );
    comboBoxFitMethod->setMaxCount( 20 );
    layout395->addWidget( comboBoxFitMethod );

    spinBoxSignDigits = new QSpinBox( buttonGroup18, "spinBoxSignDigits" );
    spinBoxSignDigits->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, spinBoxSignDigits->sizePolicy().hasHeightForWidth() ) );
    spinBoxSignDigits->setMinimumSize( QSize( 220, 25 ) );
    spinBoxSignDigits->setMaximumSize( QSize( 3000, 25 ) );
    QFont spinBoxSignDigits_font(  spinBoxSignDigits->font() );
    spinBoxSignDigits->setFont( spinBoxSignDigits_font ); 
    spinBoxSignDigits->setMaxValue( 15 );
    spinBoxSignDigits->setMinValue( 3 );
    spinBoxSignDigits->setValue( 6 );
    layout395->addWidget( spinBoxSignDigits );
    buttonGroup18Layout->addLayout( layout395 );
    layout130->addWidget( buttonGroup18 );

    layout290 = new QVBoxLayout( 0, 0, 10, "layout290"); 

    buttonGroupGenMin = new QButtonGroup( TabPage_3, "buttonGroupGenMin" );
    buttonGroupGenMin->setEnabled( TRUE );
    buttonGroupGenMin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, buttonGroupGenMin->sizePolicy().hasHeightForWidth() ) );
    buttonGroupGenMin->setMinimumSize( QSize( 0, 185 ) );
    buttonGroupGenMin->setMaximumSize( QSize( 32685, 185 ) );
    buttonGroupGenMin->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont buttonGroupGenMin_font(  buttonGroupGenMin->font() );
    buttonGroupGenMin_font.setBold( TRUE );
    buttonGroupGenMin->setFont( buttonGroupGenMin_font ); 
    buttonGroupGenMin->setCheckable( FALSE );
    buttonGroupGenMin->setChecked( FALSE );
    buttonGroupGenMin->setColumnLayout(0, Qt::Vertical );
    buttonGroupGenMin->layout()->setSpacing( 6 );
    buttonGroupGenMin->layout()->setMargin( 11 );
    buttonGroupGenMinLayout = new QGridLayout( buttonGroupGenMin->layout() );
    buttonGroupGenMinLayout->setAlignment( Qt::AlignTop );

    textLabel1 = new QLabel( buttonGroupGenMin, "textLabel1" );
    textLabel1->setEnabled( TRUE );
    QFont textLabel1_font(  textLabel1->font() );
    textLabel1_font.setBold( FALSE );
    textLabel1->setFont( textLabel1_font ); 

    buttonGroupGenMinLayout->addWidget( textLabel1, 0, 0 );

    textLabel1_3 = new QLabel( buttonGroupGenMin, "textLabel1_3" );
    textLabel1_3->setEnabled( TRUE );
    QFont textLabel1_3_font(  textLabel1_3->font() );
    textLabel1_3_font.setBold( FALSE );
    textLabel1_3->setFont( textLabel1_3_font ); 

    buttonGroupGenMinLayout->addWidget( textLabel1_3, 1, 0 );

    textLabel1_3_2 = new QLabel( buttonGroupGenMin, "textLabel1_3_2" );
    textLabel1_3_2->setEnabled( TRUE );
    QFont textLabel1_3_2_font(  textLabel1_3_2->font() );
    textLabel1_3_2_font.setBold( FALSE );
    textLabel1_3_2->setFont( textLabel1_3_2_font ); 

    buttonGroupGenMinLayout->addWidget( textLabel1_3_2, 2, 0 );

    textLabel1_3_2_2 = new QLabel( buttonGroupGenMin, "textLabel1_3_2_2" );
    textLabel1_3_2_2->setEnabled( TRUE );
    QFont textLabel1_3_2_2_font(  textLabel1_3_2_2->font() );
    textLabel1_3_2_2_font.setBold( FALSE );
    textLabel1_3_2_2->setFont( textLabel1_3_2_2_font ); 

    buttonGroupGenMinLayout->addWidget( textLabel1_3_2_2, 3, 0 );

    spinBoxGenomeCount = new QSpinBox( buttonGroupGenMin, "spinBoxGenomeCount" );
    spinBoxGenomeCount->setEnabled( TRUE );
    spinBoxGenomeCount->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, spinBoxGenomeCount->sizePolicy().hasHeightForWidth() ) );
    spinBoxGenomeCount->setMinimumSize( QSize( 0, 25 ) );
    spinBoxGenomeCount->setMaximumSize( QSize( 2500, 25 ) );
    QFont spinBoxGenomeCount_font(  spinBoxGenomeCount->font() );
    spinBoxGenomeCount_font.setBold( FALSE );
    spinBoxGenomeCount->setFont( spinBoxGenomeCount_font ); 
    spinBoxGenomeCount->setMaxValue( 1000000 );
    spinBoxGenomeCount->setMinValue( 2 );
    spinBoxGenomeCount->setLineStep( 5 );
    spinBoxGenomeCount->setValue( 100 );

    buttonGroupGenMinLayout->addWidget( spinBoxGenomeCount, 0, 1 );

    spinBoxMaxNumberGenerations = new QSpinBox( buttonGroupGenMin, "spinBoxMaxNumberGenerations" );
    spinBoxMaxNumberGenerations->setEnabled( TRUE );
    spinBoxMaxNumberGenerations->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, spinBoxMaxNumberGenerations->sizePolicy().hasHeightForWidth() ) );
    spinBoxMaxNumberGenerations->setMinimumSize( QSize( 220, 25 ) );
    spinBoxMaxNumberGenerations->setMaximumSize( QSize( 3000, 25 ) );
    QFont spinBoxMaxNumberGenerations_font(  spinBoxMaxNumberGenerations->font() );
    spinBoxMaxNumberGenerations_font.setBold( FALSE );
    spinBoxMaxNumberGenerations->setFont( spinBoxMaxNumberGenerations_font ); 
    spinBoxMaxNumberGenerations->setMaxValue( 10000 );
    spinBoxMaxNumberGenerations->setMinValue( 1 );
    spinBoxMaxNumberGenerations->setLineStep( 10 );
    spinBoxMaxNumberGenerations->setValue( 500 );

    buttonGroupGenMinLayout->addWidget( spinBoxMaxNumberGenerations, 1, 1 );

    lineEditSelectionRate = new QLineEdit( buttonGroupGenMin, "lineEditSelectionRate" );
    lineEditSelectionRate->setEnabled( TRUE );
    lineEditSelectionRate->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditSelectionRate->sizePolicy().hasHeightForWidth() ) );
    lineEditSelectionRate->setMinimumSize( QSize( 220, 25 ) );
    lineEditSelectionRate->setMaximumSize( QSize( 3000, 25 ) );
    QFont lineEditSelectionRate_font(  lineEditSelectionRate->font() );
    lineEditSelectionRate_font.setBold( FALSE );
    lineEditSelectionRate->setFont( lineEditSelectionRate_font ); 

    buttonGroupGenMinLayout->addWidget( lineEditSelectionRate, 2, 1 );

    lineEditMutationRate = new QLineEdit( buttonGroupGenMin, "lineEditMutationRate" );
    lineEditMutationRate->setEnabled( TRUE );
    lineEditMutationRate->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditMutationRate->sizePolicy().hasHeightForWidth() ) );
    lineEditMutationRate->setMinimumSize( QSize( 220, 25 ) );
    lineEditMutationRate->setMaximumSize( QSize( 3000, 25 ) );
    QFont lineEditMutationRate_font(  lineEditMutationRate->font() );
    lineEditMutationRate_font.setBold( FALSE );
    lineEditMutationRate->setFont( lineEditMutationRate_font ); 

    buttonGroupGenMinLayout->addWidget( lineEditMutationRate, 3, 1 );

    spinBoxRandomSeed = new QSpinBox( buttonGroupGenMin, "spinBoxRandomSeed" );
    spinBoxRandomSeed->setEnabled( TRUE );
    spinBoxRandomSeed->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, spinBoxRandomSeed->sizePolicy().hasHeightForWidth() ) );
    spinBoxRandomSeed->setMinimumSize( QSize( 220, 25 ) );
    spinBoxRandomSeed->setMaximumSize( QSize( 3000, 25 ) );
    QFont spinBoxRandomSeed_font(  spinBoxRandomSeed->font() );
    spinBoxRandomSeed_font.setBold( FALSE );
    spinBoxRandomSeed->setFont( spinBoxRandomSeed_font ); 
    spinBoxRandomSeed->setMaxValue( 10000 );
    spinBoxRandomSeed->setMinValue( 1 );
    spinBoxRandomSeed->setLineStep( 1 );
    spinBoxRandomSeed->setValue( 1 );

    buttonGroupGenMinLayout->addWidget( spinBoxRandomSeed, 4, 1 );

    textLabelRandomSeed = new QLabel( buttonGroupGenMin, "textLabelRandomSeed" );
    textLabelRandomSeed->setEnabled( TRUE );
    QFont textLabelRandomSeed_font(  textLabelRandomSeed->font() );
    textLabelRandomSeed_font.setBold( FALSE );
    textLabelRandomSeed->setFont( textLabelRandomSeed_font ); 

    buttonGroupGenMinLayout->addWidget( textLabelRandomSeed, 4, 0 );
    layout290->addWidget( buttonGroupGenMin );

    buttonGroupSimplex = new QButtonGroup( TabPage_3, "buttonGroupSimplex" );
    buttonGroupSimplex->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, buttonGroupSimplex->sizePolicy().hasHeightForWidth() ) );
    buttonGroupSimplex->setMinimumSize( QSize( 0, 125 ) );
    buttonGroupSimplex->setMaximumSize( QSize( 32685, 125 ) );
    buttonGroupSimplex->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont buttonGroupSimplex_font(  buttonGroupSimplex->font() );
    buttonGroupSimplex_font.setBold( TRUE );
    buttonGroupSimplex->setFont( buttonGroupSimplex_font ); 
    buttonGroupSimplex->setCheckable( FALSE );
    buttonGroupSimplex->setChecked( FALSE );
    buttonGroupSimplex->setColumnLayout(0, Qt::Vertical );
    buttonGroupSimplex->layout()->setSpacing( 6 );
    buttonGroupSimplex->layout()->setMargin( 11 );
    buttonGroupSimplexLayout = new QHBoxLayout( buttonGroupSimplex->layout() );
    buttonGroupSimplexLayout->setAlignment( Qt::AlignTop );

    layout80 = new QVBoxLayout( 0, 0, 6, "layout80"); 

    textLabel1_2 = new QLabel( buttonGroupSimplex, "textLabel1_2" );
    QFont textLabel1_2_font(  textLabel1_2->font() );
    textLabel1_2_font.setBold( FALSE );
    textLabel1_2->setFont( textLabel1_2_font ); 
    layout80->addWidget( textLabel1_2 );

    textLabel2_2 = new QLabel( buttonGroupSimplex, "textLabel2_2" );
    QFont textLabel2_2_font(  textLabel2_2->font() );
    textLabel2_2_font.setBold( FALSE );
    textLabel2_2->setFont( textLabel2_2_font ); 
    layout80->addWidget( textLabel2_2 );

    textLabel2_2_2 = new QLabel( buttonGroupSimplex, "textLabel2_2_2" );
    QFont textLabel2_2_2_font(  textLabel2_2_2->font() );
    textLabel2_2_2_font.setBold( FALSE );
    textLabel2_2_2->setFont( textLabel2_2_2_font ); 
    textLabel2_2_2->setMargin( 0 );
    textLabel2_2_2->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );
    layout80->addWidget( textLabel2_2_2 );
    buttonGroupSimplexLayout->addLayout( layout80 );

    layout81 = new QVBoxLayout( 0, 0, 6, "layout81"); 

    spinBoxMaxIter = new QSpinBox( buttonGroupSimplex, "spinBoxMaxIter" );
    spinBoxMaxIter->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, spinBoxMaxIter->sizePolicy().hasHeightForWidth() ) );
    spinBoxMaxIter->setMinimumSize( QSize( 220, 25 ) );
    spinBoxMaxIter->setMaximumSize( QSize( 3000, 25 ) );
    QFont spinBoxMaxIter_font(  spinBoxMaxIter->font() );
    spinBoxMaxIter_font.setBold( FALSE );
    spinBoxMaxIter->setFont( spinBoxMaxIter_font ); 
    spinBoxMaxIter->setMaxValue( 10000 );
    spinBoxMaxIter->setMinValue( 1 );
    spinBoxMaxIter->setLineStep( 5 );
    spinBoxMaxIter->setValue( 100 );
    layout81->addWidget( spinBoxMaxIter );

    lineEditToleranceAbs = new QLineEdit( buttonGroupSimplex, "lineEditToleranceAbs" );
    lineEditToleranceAbs->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditToleranceAbs->sizePolicy().hasHeightForWidth() ) );
    lineEditToleranceAbs->setMinimumSize( QSize( 220, 25 ) );
    lineEditToleranceAbs->setMaximumSize( QSize( 3000, 25 ) );
    QFont lineEditToleranceAbs_font(  lineEditToleranceAbs->font() );
    lineEditToleranceAbs_font.setBold( FALSE );
    lineEditToleranceAbs->setFont( lineEditToleranceAbs_font ); 
    layout81->addWidget( lineEditToleranceAbs );

    lineEditTolerance = new QLineEdit( buttonGroupSimplex, "lineEditTolerance" );
    lineEditTolerance->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditTolerance->sizePolicy().hasHeightForWidth() ) );
    lineEditTolerance->setMinimumSize( QSize( 220, 25 ) );
    lineEditTolerance->setMaximumSize( QSize( 3000, 25 ) );
    QFont lineEditTolerance_font(  lineEditTolerance->font() );
    lineEditTolerance_font.setBold( FALSE );
    lineEditTolerance->setFont( lineEditTolerance_font ); 
    layout81->addWidget( lineEditTolerance );
    buttonGroupSimplexLayout->addLayout( layout81 );
    layout290->addWidget( buttonGroupSimplex );

    buttonGroupWM = new QButtonGroup( TabPage_3, "buttonGroupWM" );
    buttonGroupWM->setEnabled( TRUE );
    buttonGroupWM->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, buttonGroupWM->sizePolicy().hasHeightForWidth() ) );
    buttonGroupWM->setMinimumSize( QSize( 0, 95 ) );
    buttonGroupWM->setMaximumSize( QSize( 32767, 95 ) );
    buttonGroupWM->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont buttonGroupWM_font(  buttonGroupWM->font() );
    buttonGroupWM_font.setBold( TRUE );
    buttonGroupWM->setFont( buttonGroupWM_font ); 
    buttonGroupWM->setCheckable( FALSE );
    buttonGroupWM->setChecked( FALSE );
    buttonGroupWM->setExclusive( TRUE );
    buttonGroupWM->setProperty( "selectedId", -1 );
    buttonGroupWM->setColumnLayout(0, Qt::Vertical );
    buttonGroupWM->layout()->setSpacing( 6 );
    buttonGroupWM->layout()->setMargin( 11 );
    buttonGroupWMLayout = new QVBoxLayout( buttonGroupWM->layout() );
    buttonGroupWMLayout->setAlignment( Qt::AlignTop );

    comboBoxWeightingMethod = new QComboBox( FALSE, buttonGroupWM, "comboBoxWeightingMethod" );
    comboBoxWeightingMethod->setEnabled( TRUE );
    comboBoxWeightingMethod->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, comboBoxWeightingMethod->sizePolicy().hasHeightForWidth() ) );
    comboBoxWeightingMethod->setMinimumSize( QSize( 220, 25 ) );
    comboBoxWeightingMethod->setMaximumSize( QSize( 3000, 25 ) );
    comboBoxWeightingMethod->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxWeightingMethod->setPalette( pal );
    QFont comboBoxWeightingMethod_font(  comboBoxWeightingMethod->font() );
    comboBoxWeightingMethod_font.setBold( FALSE );
    comboBoxWeightingMethod->setFont( comboBoxWeightingMethod_font ); 
    buttonGroupWMLayout->addWidget( comboBoxWeightingMethod );

    layout75_2 = new QHBoxLayout( 0, 0, 6, "layout75_2"); 

    textLabelWA = new QLabel( buttonGroupWM, "textLabelWA" );
    textLabelWA->setEnabled( TRUE );
    textLabelWA->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabelWA->sizePolicy().hasHeightForWidth() ) );
    layout75_2->addWidget( textLabelWA );

    lineEditWA = new QLineEdit( buttonGroupWM, "lineEditWA" );
    lineEditWA->setEnabled( TRUE );
    lineEditWA->setMaximumSize( QSize( 50, 32767 ) );
    QFont lineEditWA_font(  lineEditWA->font() );
    lineEditWA_font.setBold( FALSE );
    lineEditWA->setFont( lineEditWA_font ); 
    layout75_2->addWidget( lineEditWA );

    textLabelWB = new QLabel( buttonGroupWM, "textLabelWB" );
    textLabelWB->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabelWB->sizePolicy().hasHeightForWidth() ) );
    layout75_2->addWidget( textLabelWB );

    lineEditWB = new QLineEdit( buttonGroupWM, "lineEditWB" );
    lineEditWB->setMaximumSize( QSize( 50, 32767 ) );
    QFont lineEditWB_font(  lineEditWB->font() );
    lineEditWB_font.setBold( FALSE );
    lineEditWB->setFont( lineEditWB_font ); 
    layout75_2->addWidget( lineEditWB );

    textLabelWC = new QLabel( buttonGroupWM, "textLabelWC" );
    textLabelWC->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabelWC->sizePolicy().hasHeightForWidth() ) );
    layout75_2->addWidget( textLabelWC );

    lineEditWC = new QLineEdit( buttonGroupWM, "lineEditWC" );
    lineEditWC->setMaximumSize( QSize( 50, 32767 ) );
    QFont lineEditWC_font(  lineEditWC->font() );
    lineEditWC_font.setBold( FALSE );
    lineEditWC->setFont( lineEditWC_font ); 
    layout75_2->addWidget( lineEditWC );

    textLabelWXMAX = new QLabel( buttonGroupWM, "textLabelWXMAX" );
    textLabelWXMAX->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabelWXMAX->sizePolicy().hasHeightForWidth() ) );
    layout75_2->addWidget( textLabelWXMAX );

    lineEditWXMAX = new QLineEdit( buttonGroupWM, "lineEditWXMAX" );
    lineEditWXMAX->setEnabled( TRUE );
    lineEditWXMAX->setMaximumSize( QSize( 50, 32767 ) );
    QFont lineEditWXMAX_font(  lineEditWXMAX->font() );
    lineEditWXMAX_font.setBold( FALSE );
    lineEditWXMAX->setFont( lineEditWXMAX_font ); 
    layout75_2->addWidget( lineEditWXMAX );
    spacer20_2 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout75_2->addItem( spacer20_2 );
    buttonGroupWMLayout->addLayout( layout75_2 );
    layout290->addWidget( buttonGroupWM );
    spacer141 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout290->addItem( spacer141 );
    layout130->addLayout( layout290 );
    TabPageLayout_3->addLayout( layout130 );

    layout128 = new QVBoxLayout( 0, 0, 6, "layout128"); 

    toolBoxResoPoly = new QToolBox( TabPage_3, "toolBoxResoPoly" );
    toolBoxResoPoly->setMinimumSize( QSize( 220, 275 ) );
    toolBoxResoPoly->setMaximumSize( QSize( 220, 275 ) );
    toolBoxResoPoly->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    toolBoxResoPoly->setCurrentIndex( 0 );

    page1 = new QWidget( toolBoxResoPoly, "page1" );
    page1->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout = new QVBoxLayout( page1, 11, 6, "page1Layout"); 

    groupBoxResoInt = new QGroupBox( page1, "groupBoxResoInt" );
    groupBoxResoInt->setEnabled( TRUE );
    groupBoxResoInt->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)7, 0, 0, groupBoxResoInt->sizePolicy().hasHeightForWidth() ) );
    groupBoxResoInt->setMinimumSize( QSize( 0, 195 ) );
    groupBoxResoInt->setMaximumSize( QSize( 32767, 195 ) );
    groupBoxResoInt->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont groupBoxResoInt_font(  groupBoxResoInt->font() );
    groupBoxResoInt_font.setBold( TRUE );
    groupBoxResoInt->setFont( groupBoxResoInt_font ); 
    groupBoxResoInt->setFrameShape( QGroupBox::NoFrame );
    groupBoxResoInt->setCheckable( FALSE );
    groupBoxResoInt->setChecked( FALSE );
    groupBoxResoInt->setColumnLayout(0, Qt::Vertical );
    groupBoxResoInt->layout()->setSpacing( 6 );
    groupBoxResoInt->layout()->setMargin( 0 );
    groupBoxResoIntLayout = new QVBoxLayout( groupBoxResoInt->layout() );
    groupBoxResoIntLayout->setAlignment( Qt::AlignTop );

    comboBoxResoFunction = new QComboBox( FALSE, groupBoxResoInt, "comboBoxResoFunction" );
    comboBoxResoFunction->setEnabled( TRUE );
    comboBoxResoFunction->setMinimumSize( QSize( 25, 25 ) );
    comboBoxResoFunction->setMaximumSize( QSize( 32767, 25 ) );
    comboBoxResoFunction->setPaletteForegroundColor( QColor( 85, 85, 255 ) );
    comboBoxResoFunction->setBackgroundOrigin( QComboBox::ParentOrigin );
    QFont comboBoxResoFunction_font(  comboBoxResoFunction->font() );
    comboBoxResoFunction_font.setBold( FALSE );
    comboBoxResoFunction->setFont( comboBoxResoFunction_font ); 
    groupBoxResoIntLayout->addWidget( comboBoxResoFunction );

    comboBoxSpeedControlReso = new QComboBox( FALSE, groupBoxResoInt, "comboBoxSpeedControlReso" );
    comboBoxSpeedControlReso->setMinimumSize( QSize( 50, 25 ) );
    comboBoxSpeedControlReso->setMaximumSize( QSize( 32767, 25 ) );
    QFont comboBoxSpeedControlReso_font(  comboBoxSpeedControlReso->font() );
    comboBoxSpeedControlReso_font.setBold( FALSE );
    comboBoxSpeedControlReso->setFont( comboBoxSpeedControlReso_font ); 
    groupBoxResoIntLayout->addWidget( comboBoxSpeedControlReso );

    layout40 = new QHBoxLayout( 0, 0, 6, "layout40"); 

    textLabelAbsErr = new QLabel( groupBoxResoInt, "textLabelAbsErr" );
    textLabelAbsErr->setEnabled( TRUE );
    QFont textLabelAbsErr_font(  textLabelAbsErr->font() );
    textLabelAbsErr_font.setBold( FALSE );
    textLabelAbsErr->setFont( textLabelAbsErr_font ); 
    layout40->addWidget( textLabelAbsErr );
    spacer4 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout40->addItem( spacer4 );

    lineEditAbsErr = new QLineEdit( groupBoxResoInt, "lineEditAbsErr" );
    lineEditAbsErr->setEnabled( TRUE );
    lineEditAbsErr->setMinimumSize( QSize( 0, 25 ) );
    lineEditAbsErr->setMaximumSize( QSize( 50, 25 ) );
    QFont lineEditAbsErr_font(  lineEditAbsErr->font() );
    lineEditAbsErr_font.setBold( FALSE );
    lineEditAbsErr->setFont( lineEditAbsErr_font ); 
    layout40->addWidget( lineEditAbsErr );
    groupBoxResoIntLayout->addLayout( layout40 );

    layout41 = new QHBoxLayout( 0, 0, 6, "layout41"); 

    textLabelAbsErr_2 = new QLabel( groupBoxResoInt, "textLabelAbsErr_2" );
    textLabelAbsErr_2->setEnabled( TRUE );
    QFont textLabelAbsErr_2_font(  textLabelAbsErr_2->font() );
    textLabelAbsErr_2_font.setBold( FALSE );
    textLabelAbsErr_2->setFont( textLabelAbsErr_2_font ); 
    layout41->addWidget( textLabelAbsErr_2 );
    spacer4_2 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout41->addItem( spacer4_2 );

    lineEditRelErr = new QLineEdit( groupBoxResoInt, "lineEditRelErr" );
    lineEditRelErr->setEnabled( TRUE );
    lineEditRelErr->setMinimumSize( QSize( 0, 25 ) );
    lineEditRelErr->setMaximumSize( QSize( 50, 25 ) );
    QFont lineEditRelErr_font(  lineEditRelErr->font() );
    lineEditRelErr_font.setBold( FALSE );
    lineEditRelErr->setFont( lineEditRelErr_font ); 
    layout41->addWidget( lineEditRelErr );
    groupBoxResoIntLayout->addLayout( layout41 );

    layout42 = new QHBoxLayout( 0, 0, 6, "layout42"); 

    textLabelIntWork = new QLabel( groupBoxResoInt, "textLabelIntWork" );
    textLabelIntWork->setEnabled( TRUE );
    QFont textLabelIntWork_font(  textLabelIntWork->font() );
    textLabelIntWork_font.setBold( FALSE );
    textLabelIntWork->setFont( textLabelIntWork_font ); 
    layout42->addWidget( textLabelIntWork );
    spacer4_3 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout42->addItem( spacer4_3 );

    spinBoxIntWorkspase = new QSpinBox( groupBoxResoInt, "spinBoxIntWorkspase" );
    spinBoxIntWorkspase->setEnabled( TRUE );
    spinBoxIntWorkspase->setMinimumSize( QSize( 0, 25 ) );
    spinBoxIntWorkspase->setMaximumSize( QSize( 50, 25 ) );
    QFont spinBoxIntWorkspase_font(  spinBoxIntWorkspase->font() );
    spinBoxIntWorkspase_font.setBold( FALSE );
    spinBoxIntWorkspase->setFont( spinBoxIntWorkspase_font ); 
    spinBoxIntWorkspase->setMaxValue( 10000 );
    spinBoxIntWorkspase->setMinValue( 5 );
    spinBoxIntWorkspase->setLineStep( 1 );
    spinBoxIntWorkspase->setValue( 5 );
    layout42->addWidget( spinBoxIntWorkspase );
    groupBoxResoIntLayout->addLayout( layout42 );

    layout43 = new QHBoxLayout( 0, 0, 6, "layout43"); 

    textLabelSigma = new QLabel( groupBoxResoInt, "textLabelSigma" );
    textLabelSigma->setEnabled( TRUE );
    textLabelSigma->setMinimumSize( QSize( 0, 0 ) );
    QFont textLabelSigma_font(  textLabelSigma->font() );
    textLabelSigma_font.setBold( FALSE );
    textLabelSigma->setFont( textLabelSigma_font ); 
    layout43->addWidget( textLabelSigma );
    spacer4_4 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout43->addItem( spacer4_4 );

    spinBoxIntLimits = new QSpinBox( groupBoxResoInt, "spinBoxIntLimits" );
    spinBoxIntLimits->setEnabled( TRUE );
    spinBoxIntLimits->setMinimumSize( QSize( 0, 15 ) );
    spinBoxIntLimits->setMaximumSize( QSize( 50, 30 ) );
    QFont spinBoxIntLimits_font(  spinBoxIntLimits->font() );
    spinBoxIntLimits_font.setBold( FALSE );
    spinBoxIntLimits->setFont( spinBoxIntLimits_font ); 
    spinBoxIntLimits->setMaxValue( 1000 );
    spinBoxIntLimits->setMinValue( 1 );
    spinBoxIntLimits->setLineStep( 1 );
    spinBoxIntLimits->setValue( 3 );
    layout43->addWidget( spinBoxIntLimits );
    groupBoxResoIntLayout->addLayout( layout43 );
    page1Layout->addWidget( groupBoxResoInt );
    spacer62 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page1Layout->addItem( spacer62 );
    toolBoxResoPoly->addItem( page1, QString::fromLatin1("") );

    page2 = new QWidget( toolBoxResoPoly, "page2" );
    page2->setBackgroundMode( QWidget::PaletteBackground );
    page2Layout = new QVBoxLayout( page2, 11, 6, "page2Layout"); 

    groupBoxPolyInt = new QGroupBox( page2, "groupBoxPolyInt" );
    groupBoxPolyInt->setEnabled( TRUE );
    groupBoxPolyInt->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)7, 0, 0, groupBoxPolyInt->sizePolicy().hasHeightForWidth() ) );
    groupBoxPolyInt->setMinimumSize( QSize( 0, 195 ) );
    groupBoxPolyInt->setMaximumSize( QSize( 32767, 195 ) );
    groupBoxPolyInt->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont groupBoxPolyInt_font(  groupBoxPolyInt->font() );
    groupBoxPolyInt_font.setBold( TRUE );
    groupBoxPolyInt->setFont( groupBoxPolyInt_font ); 
    groupBoxPolyInt->setFrameShape( QGroupBox::NoFrame );
    groupBoxPolyInt->setMargin( 0 );
    groupBoxPolyInt->setCheckable( FALSE );
    groupBoxPolyInt->setChecked( FALSE );
    groupBoxPolyInt->setColumnLayout(0, Qt::Vertical );
    groupBoxPolyInt->layout()->setSpacing( 6 );
    groupBoxPolyInt->layout()->setMargin( 0 );
    groupBoxPolyIntLayout = new QVBoxLayout( groupBoxPolyInt->layout() );
    groupBoxPolyIntLayout->setAlignment( Qt::AlignTop );

    comboBoxPolyFunction = new QComboBox( FALSE, groupBoxPolyInt, "comboBoxPolyFunction" );
    comboBoxPolyFunction->setEnabled( TRUE );
    comboBoxPolyFunction->setMinimumSize( QSize( 50, 25 ) );
    comboBoxPolyFunction->setMaximumSize( QSize( 32767, 25 ) );
    comboBoxPolyFunction->setPaletteForegroundColor( QColor( 85, 85, 255 ) );
    QFont comboBoxPolyFunction_font(  comboBoxPolyFunction->font() );
    comboBoxPolyFunction_font.setBold( FALSE );
    comboBoxPolyFunction->setFont( comboBoxPolyFunction_font ); 
    groupBoxPolyIntLayout->addWidget( comboBoxPolyFunction );

    comboBoxSpeedControlPoly = new QComboBox( FALSE, groupBoxPolyInt, "comboBoxSpeedControlPoly" );
    comboBoxSpeedControlPoly->setMinimumSize( QSize( 50, 25 ) );
    comboBoxSpeedControlPoly->setMaximumSize( QSize( 32767, 25 ) );
    QFont comboBoxSpeedControlPoly_font(  comboBoxSpeedControlPoly->font() );
    comboBoxSpeedControlPoly_font.setBold( FALSE );
    comboBoxSpeedControlPoly->setFont( comboBoxSpeedControlPoly_font ); 
    groupBoxPolyIntLayout->addWidget( comboBoxSpeedControlPoly );

    layout35 = new QHBoxLayout( 0, 0, 6, "layout35"); 

    textLabelAbsErrPoly = new QLabel( groupBoxPolyInt, "textLabelAbsErrPoly" );
    QFont textLabelAbsErrPoly_font(  textLabelAbsErrPoly->font() );
    textLabelAbsErrPoly_font.setBold( FALSE );
    textLabelAbsErrPoly->setFont( textLabelAbsErrPoly_font ); 
    layout35->addWidget( textLabelAbsErrPoly );
    spacer4_5 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout35->addItem( spacer4_5 );

    lineEditAbsErrPoly = new QLineEdit( groupBoxPolyInt, "lineEditAbsErrPoly" );
    lineEditAbsErrPoly->setMinimumSize( QSize( 0, 25 ) );
    lineEditAbsErrPoly->setMaximumSize( QSize( 50, 25 ) );
    QFont lineEditAbsErrPoly_font(  lineEditAbsErrPoly->font() );
    lineEditAbsErrPoly_font.setBold( FALSE );
    lineEditAbsErrPoly->setFont( lineEditAbsErrPoly_font ); 
    layout35->addWidget( lineEditAbsErrPoly );
    groupBoxPolyIntLayout->addLayout( layout35 );

    layout36 = new QHBoxLayout( 0, 0, 6, "layout36"); 

    textLabelPelErrPoly = new QLabel( groupBoxPolyInt, "textLabelPelErrPoly" );
    QFont textLabelPelErrPoly_font(  textLabelPelErrPoly->font() );
    textLabelPelErrPoly_font.setBold( FALSE );
    textLabelPelErrPoly->setFont( textLabelPelErrPoly_font ); 
    layout36->addWidget( textLabelPelErrPoly );
    spacer4_2_2 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout36->addItem( spacer4_2_2 );

    lineEditRelErrPoly = new QLineEdit( groupBoxPolyInt, "lineEditRelErrPoly" );
    lineEditRelErrPoly->setMinimumSize( QSize( 0, 25 ) );
    lineEditRelErrPoly->setMaximumSize( QSize( 50, 25 ) );
    QFont lineEditRelErrPoly_font(  lineEditRelErrPoly->font() );
    lineEditRelErrPoly_font.setBold( FALSE );
    lineEditRelErrPoly->setFont( lineEditRelErrPoly_font ); 
    lineEditRelErrPoly->setFrameShape( QLineEdit::LineEditPanel );
    lineEditRelErrPoly->setFrameShadow( QLineEdit::Sunken );
    layout36->addWidget( lineEditRelErrPoly );
    groupBoxPolyIntLayout->addLayout( layout36 );

    layout38 = new QHBoxLayout( 0, 0, 6, "layout38"); 

    textLabelIntWorkPoly = new QLabel( groupBoxPolyInt, "textLabelIntWorkPoly" );
    QFont textLabelIntWorkPoly_font(  textLabelIntWorkPoly->font() );
    textLabelIntWorkPoly_font.setBold( FALSE );
    textLabelIntWorkPoly->setFont( textLabelIntWorkPoly_font ); 
    layout38->addWidget( textLabelIntWorkPoly );
    spacer4_3_2 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout38->addItem( spacer4_3_2 );

    spinBoxIntWorkspasePoly = new QSpinBox( groupBoxPolyInt, "spinBoxIntWorkspasePoly" );
    spinBoxIntWorkspasePoly->setMinimumSize( QSize( 0, 25 ) );
    spinBoxIntWorkspasePoly->setMaximumSize( QSize( 50, 25 ) );
    QFont spinBoxIntWorkspasePoly_font(  spinBoxIntWorkspasePoly->font() );
    spinBoxIntWorkspasePoly_font.setBold( FALSE );
    spinBoxIntWorkspasePoly->setFont( spinBoxIntWorkspasePoly_font ); 
    spinBoxIntWorkspasePoly->setMaxValue( 300 );
    spinBoxIntWorkspasePoly->setMinValue( 5 );
    spinBoxIntWorkspasePoly->setLineStep( 1 );
    spinBoxIntWorkspasePoly->setValue( 5 );
    layout38->addWidget( spinBoxIntWorkspasePoly );
    groupBoxPolyIntLayout->addLayout( layout38 );

    layout39 = new QHBoxLayout( 0, 0, 6, "layout39"); 

    textLabelSigmaNpoly = new QLabel( groupBoxPolyInt, "textLabelSigmaNpoly" );
    textLabelSigmaNpoly->setMinimumSize( QSize( 0, 0 ) );
    QFont textLabelSigmaNpoly_font(  textLabelSigmaNpoly->font() );
    textLabelSigmaNpoly_font.setBold( FALSE );
    textLabelSigmaNpoly->setFont( textLabelSigmaNpoly_font ); 
    layout39->addWidget( textLabelSigmaNpoly );
    spacer4_4_2 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout39->addItem( spacer4_4_2 );

    spinBoxIntLimitsPoly = new QSpinBox( groupBoxPolyInt, "spinBoxIntLimitsPoly" );
    spinBoxIntLimitsPoly->setMinimumSize( QSize( 0, 25 ) );
    spinBoxIntLimitsPoly->setMaximumSize( QSize( 50, 25 ) );
    QFont spinBoxIntLimitsPoly_font(  spinBoxIntLimitsPoly->font() );
    spinBoxIntLimitsPoly_font.setBold( FALSE );
    spinBoxIntLimitsPoly->setFont( spinBoxIntLimitsPoly_font ); 
    spinBoxIntLimitsPoly->setMaxValue( 1000 );
    spinBoxIntLimitsPoly->setMinValue( 1 );
    spinBoxIntLimitsPoly->setLineStep( 1 );
    spinBoxIntLimitsPoly->setValue( 3 );
    layout39->addWidget( spinBoxIntLimitsPoly );
    groupBoxPolyIntLayout->addLayout( layout39 );
    page2Layout->addWidget( groupBoxPolyInt );
    spacer63 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page2Layout->addItem( spacer63 );
    toolBoxResoPoly->addItem( page2, QString::fromLatin1("") );
    layout128->addWidget( toolBoxResoPoly );
    spacer142 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout128->addItem( spacer142 );
    TabPageLayout_3->addLayout( layout128 );
    spacer26 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    TabPageLayout_3->addItem( spacer26 );
    tabWidgetFit->insertTab( TabPage_3, QString::fromLatin1("") );
    WStackPageFitDataLayout->addWidget( tabWidgetFit );

    layout49_2 = new QHBoxLayout( 0, 0, 6, "layout49_2"); 

    buttonGroup58_2 = new QButtonGroup( WStackPageFitData, "buttonGroup58_2" );
    buttonGroup58_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup58_2->sizePolicy().hasHeightForWidth() ) );
    buttonGroup58_2->setColumnLayout(0, Qt::Vertical );
    buttonGroup58_2->layout()->setSpacing( 3 );
    buttonGroup58_2->layout()->setMargin( 5 );
    buttonGroup58_2Layout = new QVBoxLayout( buttonGroup58_2->layout() );
    buttonGroup58_2Layout->setAlignment( Qt::AlignTop );

    layout181 = new QHBoxLayout( 0, 0, 3, "layout181"); 

    pushButtonUndo = new QToolButton( buttonGroup58_2, "pushButtonUndo" );
    pushButtonUndo->setEnabled( FALSE );
    pushButtonUndo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonUndo->sizePolicy().hasHeightForWidth() ) );
    pushButtonUndo->setMinimumSize( QSize( 0, 25 ) );
    pushButtonUndo->setMaximumSize( QSize( 25, 25 ) );
    pushButtonUndo->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonUndo->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonUndo->setPalette( pal );
    QFont pushButtonUndo_font(  pushButtonUndo->font() );
    pushButtonUndo_font.setBold( TRUE );
    pushButtonUndo->setFont( pushButtonUndo_font ); 
    pushButtonUndo->setIconSet( QIconSet( image3 ) );
    pushButtonUndo->setUsesBigPixmap( FALSE );
    pushButtonUndo->setUsesTextLabel( FALSE );
    pushButtonUndo->setTextPosition( QToolButton::BesideIcon );
    layout181->addWidget( pushButtonUndo );

    pushButtonMultiFit = new QToolButton( buttonGroup58_2, "pushButtonMultiFit" );
    pushButtonMultiFit->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonMultiFit->sizePolicy().hasHeightForWidth() ) );
    pushButtonMultiFit->setMinimumSize( QSize( 0, 25 ) );
    pushButtonMultiFit->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonMultiFit->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonMultiFit->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonMultiFit->setPalette( pal );
    QFont pushButtonMultiFit_font(  pushButtonMultiFit->font() );
    pushButtonMultiFit_font.setBold( TRUE );
    pushButtonMultiFit->setFont( pushButtonMultiFit_font ); 
    pushButtonMultiFit->setUsesBigPixmap( FALSE );
    pushButtonMultiFit->setUsesTextLabel( FALSE );
    pushButtonMultiFit->setPopupDelay( 600 );
    pushButtonMultiFit->setTextPosition( QToolButton::BesideIcon );
    layout181->addWidget( pushButtonMultiFit );

    pushButtonSimulateSuperpositional = new QToolButton( buttonGroup58_2, "pushButtonSimulateSuperpositional" );
    pushButtonSimulateSuperpositional->setEnabled( TRUE );
    pushButtonSimulateSuperpositional->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonSimulateSuperpositional->sizePolicy().hasHeightForWidth() ) );
    pushButtonSimulateSuperpositional->setMinimumSize( QSize( 0, 25 ) );
    pushButtonSimulateSuperpositional->setMaximumSize( QSize( 25, 25 ) );
    pushButtonSimulateSuperpositional->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonSimulateSuperpositional->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonSimulateSuperpositional->setPalette( pal );
    QFont pushButtonSimulateSuperpositional_font(  pushButtonSimulateSuperpositional->font() );
    pushButtonSimulateSuperpositional_font.setBold( TRUE );
    pushButtonSimulateSuperpositional->setFont( pushButtonSimulateSuperpositional_font ); 
    pushButtonSimulateSuperpositional->setIconSet( QIconSet( image4 ) );
    pushButtonSimulateSuperpositional->setUsesBigPixmap( FALSE );
    pushButtonSimulateSuperpositional->setUsesTextLabel( FALSE );
    pushButtonSimulateSuperpositional->setTextPosition( QToolButton::BesideIcon );
    layout181->addWidget( pushButtonSimulateSuperpositional );

    pushButtonChiSqr = new QToolButton( buttonGroup58_2, "pushButtonChiSqr" );
    pushButtonChiSqr->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonChiSqr->sizePolicy().hasHeightForWidth() ) );
    pushButtonChiSqr->setMinimumSize( QSize( 0, 25 ) );
    pushButtonChiSqr->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonChiSqr->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonChiSqr->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonChiSqr->setPalette( pal );
    QFont pushButtonChiSqr_font(  pushButtonChiSqr->font() );
    pushButtonChiSqr_font.setBold( TRUE );
    pushButtonChiSqr->setFont( pushButtonChiSqr_font ); 
    pushButtonChiSqr->setAcceptDrops( TRUE );
    pushButtonChiSqr->setUsesBigPixmap( FALSE );
    pushButtonChiSqr->setUsesTextLabel( FALSE );
    pushButtonChiSqr->setTextPosition( QToolButton::BesideIcon );
    layout181->addWidget( pushButtonChiSqr );

    pushButtonRedo = new QToolButton( buttonGroup58_2, "pushButtonRedo" );
    pushButtonRedo->setEnabled( FALSE );
    pushButtonRedo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonRedo->sizePolicy().hasHeightForWidth() ) );
    pushButtonRedo->setMinimumSize( QSize( 0, 25 ) );
    pushButtonRedo->setMaximumSize( QSize( 25, 25 ) );
    pushButtonRedo->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonRedo->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonRedo->setPalette( pal );
    QFont pushButtonRedo_font(  pushButtonRedo->font() );
    pushButtonRedo_font.setBold( TRUE );
    pushButtonRedo->setFont( pushButtonRedo_font ); 
    pushButtonRedo->setIconSet( QIconSet( image5 ) );
    pushButtonRedo->setUsesBigPixmap( FALSE );
    pushButtonRedo->setUsesTextLabel( FALSE );
    pushButtonRedo->setTextPosition( QToolButton::BesideIcon );
    layout181->addWidget( pushButtonRedo );
    buttonGroup58_2Layout->addLayout( layout181 );

    pushButtonINITbefore = new QToolButton( buttonGroup58_2, "pushButtonINITbefore" );
    pushButtonINITbefore->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonINITbefore->sizePolicy().hasHeightForWidth() ) );
    pushButtonINITbefore->setMinimumSize( QSize( 0, 25 ) );
    pushButtonINITbefore->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonINITbefore->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonINITbefore->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonINITbefore->setPalette( pal );
    QFont pushButtonINITbefore_font(  pushButtonINITbefore->font() );
    pushButtonINITbefore_font.setBold( TRUE );
    pushButtonINITbefore->setFont( pushButtonINITbefore_font ); 
    pushButtonINITbefore->setUsesBigPixmap( FALSE );
    pushButtonINITbefore->setUsesTextLabel( FALSE );
    pushButtonINITbefore->setTextPosition( QToolButton::BesideIcon );
    buttonGroup58_2Layout->addWidget( pushButtonINITbefore );

    pushButtonINITafter = new QToolButton( buttonGroup58_2, "pushButtonINITafter" );
    pushButtonINITafter->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonINITafter->sizePolicy().hasHeightForWidth() ) );
    pushButtonINITafter->setMinimumSize( QSize( 0, 25 ) );
    pushButtonINITafter->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonINITafter->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonINITafter->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonINITafter->setPalette( pal );
    QFont pushButtonINITafter_font(  pushButtonINITafter->font() );
    pushButtonINITafter_font.setBold( TRUE );
    pushButtonINITafter->setFont( pushButtonINITafter_font ); 
    pushButtonINITafter->setUsesBigPixmap( FALSE );
    pushButtonINITafter->setUsesTextLabel( FALSE );
    pushButtonINITafter->setTextPosition( QToolButton::BesideIcon );
    buttonGroup58_2Layout->addWidget( pushButtonINITafter );
    layout49_2->addWidget( buttonGroup58_2 );

    buttonGroup57_2 = new QButtonGroup( WStackPageFitData, "buttonGroup57_2" );
    buttonGroup57_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup57_2->sizePolicy().hasHeightForWidth() ) );
    buttonGroup57_2->setColumnLayout(0, Qt::Vertical );
    buttonGroup57_2->layout()->setSpacing( 5 );
    buttonGroup57_2->layout()->setMargin( 11 );
    buttonGroup57_2Layout = new QGridLayout( buttonGroup57_2->layout() );
    buttonGroup57_2Layout->setAlignment( Qt::AlignTop );

    textLabelChiLabel_3_2 = new QLabel( buttonGroup57_2, "textLabelChiLabel_3_2" );
    textLabelChiLabel_3_2->setMinimumSize( QSize( 65, 15 ) );
    textLabelChiLabel_3_2->setMaximumSize( QSize( 65, 32767 ) );
    textLabelChiLabel_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelChiLabel_3_2->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelChiLabel_3_2_font(  textLabelChiLabel_3_2->font() );
    textLabelChiLabel_3_2_font.setBold( TRUE );
    textLabelChiLabel_3_2->setFont( textLabelChiLabel_3_2_font ); 
    textLabelChiLabel_3_2->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignLeft ) );

    buttonGroup57_2Layout->addWidget( textLabelChiLabel_3_2, 1, 0 );

    textLabelChiLabel_2_3 = new QLabel( buttonGroup57_2, "textLabelChiLabel_2_3" );
    textLabelChiLabel_2_3->setMinimumSize( QSize( 65, 15 ) );
    textLabelChiLabel_2_3->setMaximumSize( QSize( 65, 32767 ) );
    textLabelChiLabel_2_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelChiLabel_2_3->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelChiLabel_2_3_font(  textLabelChiLabel_2_3->font() );
    textLabelChiLabel_2_3_font.setBold( TRUE );
    textLabelChiLabel_2_3->setFont( textLabelChiLabel_2_3_font ); 
    textLabelChiLabel_2_3->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignLeft ) );

    buttonGroup57_2Layout->addWidget( textLabelChiLabel_2_3, 2, 0 );

    textLabelR2 = new QLabel( buttonGroup57_2, "textLabelR2" );
    textLabelR2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelR2->sizePolicy().hasHeightForWidth() ) );
    textLabelR2->setMinimumSize( QSize( 0, 20 ) );
    textLabelR2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelR2->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelR2_font(  textLabelR2->font() );
    textLabelR2_font.setPointSize( 7 );
    textLabelR2->setFont( textLabelR2_font ); 
    textLabelR2->setFrameShape( QLabel::Panel );
    textLabelR2->setLineWidth( 1 );
    textLabelR2->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignRight ) );

    buttonGroup57_2Layout->addWidget( textLabelR2, 1, 1 );

    textLabelChi = new QLabel( buttonGroup57_2, "textLabelChi" );
    textLabelChi->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, textLabelChi->sizePolicy().hasHeightForWidth() ) );
    textLabelChi->setMinimumSize( QSize( 0, 20 ) );
    textLabelChi->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelChi->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelChi_font(  textLabelChi->font() );
    textLabelChi_font.setPointSize( 7 );
    textLabelChi->setFont( textLabelChi_font ); 
    textLabelChi->setFrameShape( QLabel::Panel );
    textLabelChi->setLineWidth( 1 );
    textLabelChi->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignRight ) );

    buttonGroup57_2Layout->addWidget( textLabelChi, 0, 1 );

    textLabelChiLabel = new QLabel( buttonGroup57_2, "textLabelChiLabel" );
    textLabelChiLabel->setMinimumSize( QSize( 65, 15 ) );
    textLabelChiLabel->setMaximumSize( QSize( 65, 32767 ) );
    textLabelChiLabel->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelChiLabel->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelChiLabel_font(  textLabelChiLabel->font() );
    textLabelChiLabel_font.setBold( TRUE );
    textLabelChiLabel->setFont( textLabelChiLabel_font ); 
    textLabelChiLabel->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignLeft ) );

    buttonGroup57_2Layout->addWidget( textLabelChiLabel, 0, 0 );

    textLabelTime = new QLabel( buttonGroup57_2, "textLabelTime" );
    textLabelTime->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelTime->sizePolicy().hasHeightForWidth() ) );
    textLabelTime->setMinimumSize( QSize( 0, 20 ) );
    textLabelTime->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelTime->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelTime_font(  textLabelTime->font() );
    textLabelTime_font.setPointSize( 7 );
    textLabelTime->setFont( textLabelTime_font ); 
    textLabelTime->setFrameShape( QLabel::Panel );
    textLabelTime->setLineWidth( 1 );
    textLabelTime->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignRight ) );

    buttonGroup57_2Layout->addWidget( textLabelTime, 2, 1 );
    layout49_2->addWidget( buttonGroup57_2 );
    WStackPageFitDataLayout->addLayout( layout49_2 );
    widgetStackFit->addWidget( WStackPageFitData, 1 );

    WStackPage = new QWidget( widgetStackFit, "WStackPage" );
    WStackPageLayout = new QVBoxLayout( WStackPage, 0, 6, "WStackPageLayout"); 

    tabWidgetGenResults = new QTabWidget( WStackPage, "tabWidgetGenResults" );
    tabWidgetGenResults->setEnabled( TRUE );
    tabWidgetGenResults->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, tabWidgetGenResults->sizePolicy().hasHeightForWidth() ) );
    tabWidgetGenResults->setMinimumSize( QSize( 0, 0 ) );
    tabWidgetGenResults->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    tabWidgetGenResults->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tabWidgetGenResults->setPalette( pal );
    tabWidgetGenResults->setBackgroundOrigin( QTabWidget::WidgetOrigin );

    tab_3 = new QWidget( tabWidgetGenResults, "tab_3" );
    tabLayout_3 = new QVBoxLayout( tab_3, 11, 6, "tabLayout_3"); 

    splitter5 = new QSplitter( tab_3, "splitter5" );
    splitter5->setOrientation( QSplitter::Horizontal );

    QWidget* privateLayoutWidget_3 = new QWidget( splitter5, "layout64" );
    layout64 = new QVBoxLayout( privateLayoutWidget_3, 2, 2, "layout64"); 

    tableParaSimulate = new QTable( privateLayoutWidget_3, "tableParaSimulate" );
    tableParaSimulate->setNumCols( tableParaSimulate->numCols() + 1 );
    tableParaSimulate->horizontalHeader()->setLabel( tableParaSimulate->numCols() - 1, tr( "Value" ) );
    tableParaSimulate->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, tableParaSimulate->sizePolicy().hasHeightForWidth() ) );
    tableParaSimulate->setMinimumSize( QSize( 200, 50 ) );
    tableParaSimulate->setMaximumSize( QSize( 32767, 3500 ) );
    tableParaSimulate->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    tableParaSimulate->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tableParaSimulate->setPalette( pal );
    tableParaSimulate->setBackgroundOrigin( QTable::WidgetOrigin );
    QFont tableParaSimulate_font(  tableParaSimulate->font() );
    tableParaSimulate->setFont( tableParaSimulate_font ); 
    tableParaSimulate->setFrameShape( QTable::GroupBoxPanel );
    tableParaSimulate->setFrameShadow( QTable::Sunken );
    tableParaSimulate->setLineWidth( 2 );
    tableParaSimulate->setMidLineWidth( 0 );
    tableParaSimulate->setResizePolicy( QTable::Default );
    tableParaSimulate->setNumRows( 0 );
    tableParaSimulate->setNumCols( 1 );
    layout64->addWidget( tableParaSimulate );

    buttonGroup9 = new QButtonGroup( privateLayoutWidget_3, "buttonGroup9" );
    buttonGroup9->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup9->sizePolicy().hasHeightForWidth() ) );
    buttonGroup9->setMinimumSize( QSize( 0, 100 ) );
    buttonGroup9->setMaximumSize( QSize( 32767, 750 ) );
    buttonGroup9->setColumnLayout(0, Qt::Vertical );
    buttonGroup9->layout()->setSpacing( 6 );
    buttonGroup9->layout()->setMargin( 11 );
    buttonGroup9Layout = new QVBoxLayout( buttonGroup9->layout() );
    buttonGroup9Layout->setAlignment( Qt::AlignTop );

    layout312 = new QHBoxLayout( 0, 0, 6, "layout312"); 

    pushButtonSimulate = new QToolButton( buttonGroup9, "pushButtonSimulate" );
    pushButtonSimulate->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonSimulate->sizePolicy().hasHeightForWidth() ) );
    pushButtonSimulate->setMinimumSize( QSize( 0, 25 ) );
    pushButtonSimulate->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonSimulate->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonSimulate->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonSimulate->setPalette( pal );
    QFont pushButtonSimulate_font(  pushButtonSimulate->font() );
    pushButtonSimulate_font.setBold( TRUE );
    pushButtonSimulate->setFont( pushButtonSimulate_font ); 
    pushButtonSimulate->setUsesBigPixmap( FALSE );
    pushButtonSimulate->setUsesTextLabel( FALSE );
    pushButtonSimulate->setTextPosition( QToolButton::BesideIcon );
    layout312->addWidget( pushButtonSimulate );

    checkBoxSimIndexing = new QCheckBox( buttonGroup9, "checkBoxSimIndexing" );
    checkBoxSimIndexing->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, checkBoxSimIndexing->sizePolicy().hasHeightForWidth() ) );
    checkBoxSimIndexing->setMinimumSize( QSize( 14, 0 ) );
    checkBoxSimIndexing->setMaximumSize( QSize( 14, 32767 ) );
    layout312->addWidget( checkBoxSimIndexing );

    pushButtonSimulateSuperpositionalRes = new QToolButton( buttonGroup9, "pushButtonSimulateSuperpositionalRes" );
    pushButtonSimulateSuperpositionalRes->setEnabled( TRUE );
    pushButtonSimulateSuperpositionalRes->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonSimulateSuperpositionalRes->sizePolicy().hasHeightForWidth() ) );
    pushButtonSimulateSuperpositionalRes->setMinimumSize( QSize( 0, 25 ) );
    pushButtonSimulateSuperpositionalRes->setMaximumSize( QSize( 25, 25 ) );
    pushButtonSimulateSuperpositionalRes->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonSimulateSuperpositionalRes->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonSimulateSuperpositionalRes->setPalette( pal );
    QFont pushButtonSimulateSuperpositionalRes_font(  pushButtonSimulateSuperpositionalRes->font() );
    pushButtonSimulateSuperpositionalRes_font.setBold( TRUE );
    pushButtonSimulateSuperpositionalRes->setFont( pushButtonSimulateSuperpositionalRes_font ); 
    pushButtonSimulateSuperpositionalRes->setIconSet( QIconSet( image4 ) );
    pushButtonSimulateSuperpositionalRes->setUsesBigPixmap( FALSE );
    pushButtonSimulateSuperpositionalRes->setUsesTextLabel( FALSE );
    pushButtonSimulateSuperpositionalRes->setTextPosition( QToolButton::BesideIcon );
    layout312->addWidget( pushButtonSimulateSuperpositionalRes );

    pushButtonSimulateDelete = new QToolButton( buttonGroup9, "pushButtonSimulateDelete" );
    pushButtonSimulateDelete->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonSimulateDelete->sizePolicy().hasHeightForWidth() ) );
    pushButtonSimulateDelete->setMinimumSize( QSize( 0, 25 ) );
    pushButtonSimulateDelete->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonSimulateDelete->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonSimulateDelete->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonSimulateDelete->setPalette( pal );
    QFont pushButtonSimulateDelete_font(  pushButtonSimulateDelete->font() );
    pushButtonSimulateDelete_font.setBold( TRUE );
    pushButtonSimulateDelete->setFont( pushButtonSimulateDelete_font ); 
    pushButtonSimulateDelete->setIconSet( QIconSet( image6 ) );
    pushButtonSimulateDelete->setUsesBigPixmap( FALSE );
    pushButtonSimulateDelete->setUsesTextLabel( TRUE );
    pushButtonSimulateDelete->setTextPosition( QToolButton::BesideIcon );
    layout312->addWidget( pushButtonSimulateDelete );
    buttonGroup9Layout->addLayout( layout312 );

    layout65 = new QHBoxLayout( 0, 0, 6, "layout65"); 

    textLabelChiLabel_2_2 = new QLabel( buttonGroup9, "textLabelChiLabel_2_2" );
    textLabelChiLabel_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)7, 0, 0, textLabelChiLabel_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelChiLabel_2_2->setMinimumSize( QSize( 60, 0 ) );
    textLabelChiLabel_2_2->setMaximumSize( QSize( 60, 20 ) );
    textLabelChiLabel_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelChiLabel_2_2->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabelChiLabel_2_2->setPalette( pal );
    QFont textLabelChiLabel_2_2_font(  textLabelChiLabel_2_2->font() );
    textLabelChiLabel_2_2->setFont( textLabelChiLabel_2_2_font ); 
    textLabelChiLabel_2_2->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignLeft ) );
    layout65->addWidget( textLabelChiLabel_2_2 );

    textLabelTimeSim = new QLabel( buttonGroup9, "textLabelTimeSim" );
    textLabelTimeSim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, textLabelTimeSim->sizePolicy().hasHeightForWidth() ) );
    textLabelTimeSim->setMinimumSize( QSize( 0, 20 ) );
    textLabelTimeSim->setMaximumSize( QSize( 32767, 20 ) );
    textLabelTimeSim->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelTimeSim->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabelTimeSim->setPalette( pal );
    QFont textLabelTimeSim_font(  textLabelTimeSim->font() );
    textLabelTimeSim->setFont( textLabelTimeSim_font ); 
    textLabelTimeSim->setFrameShape( QLabel::Panel );
    textLabelTimeSim->setLineWidth( 1 );
    textLabelTimeSim->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignRight ) );
    layout65->addWidget( textLabelTimeSim );
    buttonGroup9Layout->addLayout( layout65 );

    layout273_2 = new QHBoxLayout( 0, 0, 6, "layout273_2"); 

    textLabelChiLabelSim = new QLabel( buttonGroup9, "textLabelChiLabelSim" );
    textLabelChiLabelSim->setMinimumSize( QSize( 60, 15 ) );
    textLabelChiLabelSim->setMaximumSize( QSize( 60, 32767 ) );
    textLabelChiLabelSim->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelChiLabelSim->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelChiLabelSim_font(  textLabelChiLabelSim->font() );
    textLabelChiLabelSim->setFont( textLabelChiLabelSim_font ); 
    textLabelChiLabelSim->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignLeft ) );
    layout273_2->addWidget( textLabelChiLabelSim );

    textLabelChi2Sim = new QLabel( buttonGroup9, "textLabelChi2Sim" );
    textLabelChi2Sim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelChi2Sim->sizePolicy().hasHeightForWidth() ) );
    textLabelChi2Sim->setMinimumSize( QSize( 0, 20 ) );
    textLabelChi2Sim->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelChi2Sim->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelChi2Sim_font(  textLabelChi2Sim->font() );
    textLabelChi2Sim->setFont( textLabelChi2Sim_font ); 
    textLabelChi2Sim->setFrameShape( QLabel::Panel );
    textLabelChi2Sim->setLineWidth( 1 );
    textLabelChi2Sim->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignRight ) );
    layout273_2->addWidget( textLabelChi2Sim );
    buttonGroup9Layout->addLayout( layout273_2 );

    layout273 = new QHBoxLayout( 0, 0, 6, "layout273"); 

    textLabelChiLabelDofSim = new QLabel( buttonGroup9, "textLabelChiLabelDofSim" );
    textLabelChiLabelDofSim->setMinimumSize( QSize( 60, 15 ) );
    textLabelChiLabelDofSim->setMaximumSize( QSize( 60, 32767 ) );
    textLabelChiLabelDofSim->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelChiLabelDofSim->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelChiLabelDofSim_font(  textLabelChiLabelDofSim->font() );
    textLabelChiLabelDofSim->setFont( textLabelChiLabelDofSim_font ); 
    textLabelChiLabelDofSim->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignLeft ) );
    layout273->addWidget( textLabelChiLabelDofSim );

    textLabelChi2dofSim = new QLabel( buttonGroup9, "textLabelChi2dofSim" );
    textLabelChi2dofSim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelChi2dofSim->sizePolicy().hasHeightForWidth() ) );
    textLabelChi2dofSim->setMinimumSize( QSize( 0, 20 ) );
    textLabelChi2dofSim->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelChi2dofSim->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelChi2dofSim_font(  textLabelChi2dofSim->font() );
    textLabelChi2dofSim->setFont( textLabelChi2dofSim_font ); 
    textLabelChi2dofSim->setFrameShape( QLabel::Panel );
    textLabelChi2dofSim->setLineWidth( 1 );
    textLabelChi2dofSim->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignRight ) );
    layout273->addWidget( textLabelChi2dofSim );
    buttonGroup9Layout->addLayout( layout273 );

    layout271 = new QHBoxLayout( 0, 0, 6, "layout271"); 

    textLabelR2simInt = new QLabel( buttonGroup9, "textLabelR2simInt" );
    textLabelR2simInt->setMinimumSize( QSize( 60, 15 ) );
    textLabelR2simInt->setMaximumSize( QSize( 60, 32767 ) );
    textLabelR2simInt->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelR2simInt->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelR2simInt_font(  textLabelR2simInt->font() );
    textLabelR2simInt->setFont( textLabelR2simInt_font ); 
    textLabelR2simInt->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignLeft ) );
    layout271->addWidget( textLabelR2simInt );

    textLabelR2sim = new QLabel( buttonGroup9, "textLabelR2sim" );
    textLabelR2sim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelR2sim->sizePolicy().hasHeightForWidth() ) );
    textLabelR2sim->setMinimumSize( QSize( 0, 20 ) );
    textLabelR2sim->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelR2sim->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelR2sim_font(  textLabelR2sim->font() );
    textLabelR2sim->setFont( textLabelR2sim_font ); 
    textLabelR2sim->setFrameShape( QLabel::Panel );
    textLabelR2sim->setLineWidth( 1 );
    textLabelR2sim->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignRight ) );
    layout271->addWidget( textLabelR2sim );
    buttonGroup9Layout->addLayout( layout271 );

    groupBoxPointsPara = new QGroupBox( buttonGroup9, "groupBoxPointsPara" );
    groupBoxPointsPara->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, groupBoxPointsPara->sizePolicy().hasHeightForWidth() ) );
    groupBoxPointsPara->setFrameShape( QGroupBox::NoFrame );
    groupBoxPointsPara->setFrameShadow( QGroupBox::Plain );
    groupBoxPointsPara->setColumnLayout(0, Qt::Vertical );
    groupBoxPointsPara->layout()->setSpacing( 6 );
    groupBoxPointsPara->layout()->setMargin( 0 );
    groupBoxPointsParaLayout = new QHBoxLayout( groupBoxPointsPara->layout() );
    groupBoxPointsParaLayout->setAlignment( Qt::AlignTop );

    textLabelfromQsim_2 = new QLabel( groupBoxPointsPara, "textLabelfromQsim_2" );
    textLabelfromQsim_2->setEnabled( TRUE );
    textLabelfromQsim_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelfromQsim_2->sizePolicy().hasHeightForWidth() ) );
    textLabelfromQsim_2->setMinimumSize( QSize( 60, 0 ) );
    textLabelfromQsim_2->setMaximumSize( QSize( 60, 32767 ) );
    textLabelfromQsim_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBoxPointsParaLayout->addWidget( textLabelfromQsim_2 );

    textLabelnpSIM = new QLabel( groupBoxPointsPara, "textLabelnpSIM" );
    textLabelnpSIM->setEnabled( TRUE );
    textLabelnpSIM->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelnpSIM->sizePolicy().hasHeightForWidth() ) );
    textLabelnpSIM->setMinimumSize( QSize( 70, 20 ) );
    textLabelnpSIM->setMaximumSize( QSize( 70, 32767 ) );
    textLabelnpSIM->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelnpSIM->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelnpSIM_font(  textLabelnpSIM->font() );
    textLabelnpSIM_font.setPointSize( 7 );
    textLabelnpSIM->setFont( textLabelnpSIM_font ); 
    textLabelnpSIM->setFrameShape( QLabel::Panel );
    textLabelnpSIM->setLineWidth( 1 );
    textLabelnpSIM->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignRight ) );
    groupBoxPointsParaLayout->addWidget( textLabelnpSIM );
    spacer156 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    groupBoxPointsParaLayout->addItem( spacer156 );

    textLabelToQsim_2 = new QLabel( groupBoxPointsPara, "textLabelToQsim_2" );
    textLabelToQsim_2->setEnabled( TRUE );
    textLabelToQsim_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelToQsim_2->sizePolicy().hasHeightForWidth() ) );
    textLabelToQsim_2->setMinimumSize( QSize( 95, 0 ) );
    textLabelToQsim_2->setMaximumSize( QSize( 95, 32767 ) );
    textLabelToQsim_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBoxPointsParaLayout->addWidget( textLabelToQsim_2 );

    textLabelDofSim = new QLabel( groupBoxPointsPara, "textLabelDofSim" );
    textLabelDofSim->setEnabled( TRUE );
    textLabelDofSim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelDofSim->sizePolicy().hasHeightForWidth() ) );
    textLabelDofSim->setMinimumSize( QSize( 70, 20 ) );
    textLabelDofSim->setMaximumSize( QSize( 70, 32767 ) );
    textLabelDofSim->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelDofSim->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelDofSim_font(  textLabelDofSim->font() );
    textLabelDofSim_font.setPointSize( 7 );
    textLabelDofSim->setFont( textLabelDofSim_font ); 
    textLabelDofSim->setFrameShape( QLabel::Panel );
    textLabelDofSim->setLineWidth( 1 );
    textLabelDofSim->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignRight ) );
    groupBoxPointsParaLayout->addWidget( textLabelDofSim );
    buttonGroup9Layout->addWidget( groupBoxPointsPara );
    layout64->addWidget( buttonGroup9 );

    QWidget* privateLayoutWidget_4 = new QWidget( splitter5, "layout131" );
    layout131 = new QVBoxLayout( privateLayoutWidget_4, 11, 6, "layout131"); 

    buttonGroup10 = new QButtonGroup( privateLayoutWidget_4, "buttonGroup10" );
    buttonGroup10->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, buttonGroup10->sizePolicy().hasHeightForWidth() ) );
    buttonGroup10->setMinimumSize( QSize( 0, 40 ) );
    buttonGroup10->setMaximumSize( QSize( 32767, 120 ) );
    buttonGroup10->setColumnLayout(0, Qt::Vertical );
    buttonGroup10->layout()->setSpacing( 6 );
    buttonGroup10->layout()->setMargin( 11 );
    buttonGroup10Layout = new QVBoxLayout( buttonGroup10->layout() );
    buttonGroup10Layout->setAlignment( Qt::AlignTop );

    comboBoxColor = new QComboBox( FALSE, buttonGroup10, "comboBoxColor" );
    comboBoxColor->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, comboBoxColor->sizePolicy().hasHeightForWidth() ) );
    comboBoxColor->setMinimumSize( QSize( 50, 20 ) );
    comboBoxColor->setMaximumSize( QSize( 32767, 20 ) );
    comboBoxColor->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxColor->setPalette( pal );
    comboBoxColor->setSizeLimit( 100 );
    buttonGroup10Layout->addWidget( comboBoxColor );

    checkBoxCovar = new QCheckBox( buttonGroup10, "checkBoxCovar" );
    checkBoxCovar->setChecked( FALSE );
    buttonGroup10Layout->addWidget( checkBoxCovar );

    checkBoxSaveSession = new QCheckBox( buttonGroup10, "checkBoxSaveSession" );
    checkBoxSaveSession->setChecked( FALSE );
    buttonGroup10Layout->addWidget( checkBoxSaveSession );
    layout131->addWidget( buttonGroup10 );

    radioButtonUniform_Q = new QButtonGroup( privateLayoutWidget_4, "radioButtonUniform_Q" );
    radioButtonUniform_Q->setEnabled( TRUE );
    radioButtonUniform_Q->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, radioButtonUniform_Q->sizePolicy().hasHeightForWidth() ) );
    radioButtonUniform_Q->setMaximumSize( QSize( 32767, 150 ) );
    radioButtonUniform_Q->setCheckable( TRUE );
    radioButtonUniform_Q->setChecked( FALSE );
    radioButtonUniform_Q->setColumnLayout(0, Qt::Vertical );
    radioButtonUniform_Q->layout()->setSpacing( 6 );
    radioButtonUniform_Q->layout()->setMargin( 11 );
    radioButtonUniform_QLayout = new QHBoxLayout( radioButtonUniform_Q->layout() );
    radioButtonUniform_QLayout->setAlignment( Qt::AlignTop );

    groupBoxQrange = new QGroupBox( radioButtonUniform_Q, "groupBoxQrange" );
    groupBoxQrange->setFrameShape( QGroupBox::NoFrame );
    groupBoxQrange->setColumnLayout(0, Qt::Vertical );
    groupBoxQrange->layout()->setSpacing( 6 );
    groupBoxQrange->layout()->setMargin( 0 );
    groupBoxQrangeLayout = new QVBoxLayout( groupBoxQrange->layout() );
    groupBoxQrangeLayout->setAlignment( Qt::AlignTop );

    layout29 = new QGridLayout( 0, 1, 1, 0, 6, "layout29"); 

    textLabelfromQsim = new QLabel( groupBoxQrange, "textLabelfromQsim" );
    textLabelfromQsim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabelfromQsim->sizePolicy().hasHeightForWidth() ) );

    layout29->addWidget( textLabelfromQsim, 0, 0 );

    lineEditFromQsim = new QLineEdit( groupBoxQrange, "lineEditFromQsim" );
    lineEditFromQsim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditFromQsim->sizePolicy().hasHeightForWidth() ) );
    lineEditFromQsim->setMinimumSize( QSize( 0, 15 ) );
    lineEditFromQsim->setMaximumSize( QSize( 32767, 30 ) );

    layout29->addWidget( lineEditFromQsim, 0, 1 );

    lineEditToQsim = new QLineEdit( groupBoxQrange, "lineEditToQsim" );
    lineEditToQsim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditToQsim->sizePolicy().hasHeightForWidth() ) );
    lineEditToQsim->setMinimumSize( QSize( 0, 15 ) );
    lineEditToQsim->setMaximumSize( QSize( 32767, 30 ) );

    layout29->addWidget( lineEditToQsim, 1, 1 );

    lineEditNumPointsSim = new QLineEdit( groupBoxQrange, "lineEditNumPointsSim" );
    lineEditNumPointsSim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditNumPointsSim->sizePolicy().hasHeightForWidth() ) );
    lineEditNumPointsSim->setMinimumSize( QSize( 0, 15 ) );
    lineEditNumPointsSim->setMaximumSize( QSize( 32767, 30 ) );

    layout29->addWidget( lineEditNumPointsSim, 2, 1 );

    textLabelToQsim = new QLabel( groupBoxQrange, "textLabelToQsim" );
    textLabelToQsim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, textLabelToQsim->sizePolicy().hasHeightForWidth() ) );

    layout29->addWidget( textLabelToQsim, 1, 0 );

    textLabelnumPointssim = new QLabel( groupBoxQrange, "textLabelnumPointssim" );

    layout29->addWidget( textLabelnumPointssim, 2, 0 );
    groupBoxQrangeLayout->addLayout( layout29 );

    checkBoxLogStep = new QCheckBox( groupBoxQrange, "checkBoxLogStep" );
    checkBoxLogStep->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxLogStep->sizePolicy().hasHeightForWidth() ) );
    checkBoxLogStep->setChecked( TRUE );
    groupBoxQrangeLayout->addWidget( checkBoxLogStep );
    radioButtonUniform_QLayout->addWidget( groupBoxQrange );
    layout131->addWidget( radioButtonUniform_Q );

    radioButtonSameQrange = new QButtonGroup( privateLayoutWidget_4, "radioButtonSameQrange" );
    radioButtonSameQrange->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, radioButtonSameQrange->sizePolicy().hasHeightForWidth() ) );
    radioButtonSameQrange->setMinimumSize( QSize( 330, 40 ) );
    radioButtonSameQrange->setMaximumSize( QSize( 3300, 90 ) );
    radioButtonSameQrange->setAlignment( int( QButtonGroup::AlignLeft ) );
    radioButtonSameQrange->setCheckable( TRUE );
    radioButtonSameQrange->setChecked( TRUE );
    radioButtonSameQrange->setColumnLayout(0, Qt::Vertical );
    radioButtonSameQrange->layout()->setSpacing( 6 );
    radioButtonSameQrange->layout()->setMargin( 11 );
    radioButtonSameQrangeLayout = new QVBoxLayout( radioButtonSameQrange->layout() );
    radioButtonSameQrangeLayout->setAlignment( Qt::AlignTop );

    comboBoxDatasetSim = new QComboBox( FALSE, radioButtonSameQrange, "comboBoxDatasetSim" );
    comboBoxDatasetSim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, comboBoxDatasetSim->sizePolicy().hasHeightForWidth() ) );
    comboBoxDatasetSim->setMinimumSize( QSize( 50, 20 ) );
    comboBoxDatasetSim->setMaximumSize( QSize( 32767, 20 ) );
    comboBoxDatasetSim->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxDatasetSim->setPalette( pal );
    QFont comboBoxDatasetSim_font(  comboBoxDatasetSim->font() );
    comboBoxDatasetSim->setFont( comboBoxDatasetSim_font ); 
    comboBoxDatasetSim->setAutoMask( TRUE );
    comboBoxDatasetSim->setSizeLimit( 100 );
    comboBoxDatasetSim->setAutoCompletion( FALSE );
    comboBoxDatasetSim->setDuplicatesEnabled( FALSE );
    radioButtonSameQrangeLayout->addWidget( comboBoxDatasetSim );

    groupBoxSimRange = new QGroupBox( radioButtonSameQrange, "groupBoxSimRange" );
    groupBoxSimRange->setEnabled( TRUE );
    groupBoxSimRange->setFrameShape( QGroupBox::NoFrame );
    groupBoxSimRange->setColumnLayout(0, Qt::Vertical );
    groupBoxSimRange->layout()->setSpacing( 2 );
    groupBoxSimRange->layout()->setMargin( 0 );
    groupBoxSimRangeLayout = new QHBoxLayout( groupBoxSimRange->layout() );
    groupBoxSimRangeLayout->setAlignment( Qt::AlignTop );

    comboBoxSimQN = new QComboBox( FALSE, groupBoxSimRange, "comboBoxSimQN" );
    comboBoxSimQN->setMinimumSize( QSize( 45, 20 ) );
    comboBoxSimQN->setMaximumSize( QSize( 45, 20 ) );
    groupBoxSimRangeLayout->addWidget( comboBoxSimQN );

    label11_4 = new QLabel( groupBoxSimRange, "label11_4" );
    label11_4->setEnabled( TRUE );
    label11_4->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, label11_4->sizePolicy().hasHeightForWidth() ) );
    label11_4->setMinimumSize( QSize( 10, 0 ) );
    label11_4->setMaximumSize( QSize( 10, 32767 ) );
    label11_4->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBoxSimRangeLayout->addWidget( label11_4 );

    textLabelRangeFirstLimit = new QLabel( groupBoxSimRange, "textLabelRangeFirstLimit" );
    textLabelRangeFirstLimit->setEnabled( TRUE );
    textLabelRangeFirstLimit->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelRangeFirstLimit->sizePolicy().hasHeightForWidth() ) );
    textLabelRangeFirstLimit->setMinimumSize( QSize( 50, 20 ) );
    textLabelRangeFirstLimit->setMaximumSize( QSize( 50, 32767 ) );
    textLabelRangeFirstLimit->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelRangeFirstLimit->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelRangeFirstLimit_font(  textLabelRangeFirstLimit->font() );
    textLabelRangeFirstLimit_font.setPointSize( 7 );
    textLabelRangeFirstLimit->setFont( textLabelRangeFirstLimit_font ); 
    textLabelRangeFirstLimit->setFrameShape( QLabel::Panel );
    textLabelRangeFirstLimit->setLineWidth( 1 );
    textLabelRangeFirstLimit->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignRight ) );
    groupBoxSimRangeLayout->addWidget( textLabelRangeFirstLimit );

    label11 = new QLabel( groupBoxSimRange, "label11" );
    label11->setEnabled( TRUE );
    label11->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, label11->sizePolicy().hasHeightForWidth() ) );
    label11->setMinimumSize( QSize( 10, 0 ) );
    label11->setMaximumSize( QSize( 10, 32767 ) );
    label11->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBoxSimRangeLayout->addWidget( label11 );

    textLabelRangeFirst = new QLineEdit( groupBoxSimRange, "textLabelRangeFirst" );
    textLabelRangeFirst->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, textLabelRangeFirst->sizePolicy().hasHeightForWidth() ) );
    textLabelRangeFirst->setMinimumSize( QSize( 50, 20 ) );
    textLabelRangeFirst->setMaximumSize( QSize( 50, 20 ) );
    groupBoxSimRangeLayout->addWidget( textLabelRangeFirst );

    label11_2 = new QLabel( groupBoxSimRange, "label11_2" );
    label11_2->setEnabled( TRUE );
    label11_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, label11_2->sizePolicy().hasHeightForWidth() ) );
    label11_2->setMinimumSize( QSize( 10, 0 ) );
    label11_2->setMaximumSize( QSize( 10, 32767 ) );
    label11_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBoxSimRangeLayout->addWidget( label11_2 );

    textLabelRangeLast = new QLineEdit( groupBoxSimRange, "textLabelRangeLast" );
    textLabelRangeLast->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, textLabelRangeLast->sizePolicy().hasHeightForWidth() ) );
    textLabelRangeLast->setMinimumSize( QSize( 50, 20 ) );
    textLabelRangeLast->setMaximumSize( QSize( 50, 20 ) );
    groupBoxSimRangeLayout->addWidget( textLabelRangeLast );

    label11_3 = new QLabel( groupBoxSimRange, "label11_3" );
    label11_3->setEnabled( TRUE );
    label11_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, label11_3->sizePolicy().hasHeightForWidth() ) );
    label11_3->setMinimumSize( QSize( 10, 0 ) );
    label11_3->setMaximumSize( QSize( 10, 32767 ) );
    label11_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBoxSimRangeLayout->addWidget( label11_3 );

    textLabelRangeLastLimit = new QLabel( groupBoxSimRange, "textLabelRangeLastLimit" );
    textLabelRangeLastLimit->setEnabled( TRUE );
    textLabelRangeLastLimit->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelRangeLastLimit->sizePolicy().hasHeightForWidth() ) );
    textLabelRangeLastLimit->setMinimumSize( QSize( 50, 20 ) );
    textLabelRangeLastLimit->setMaximumSize( QSize( 50, 32767 ) );
    textLabelRangeLastLimit->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelRangeLastLimit->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont textLabelRangeLastLimit_font(  textLabelRangeLastLimit->font() );
    textLabelRangeLastLimit_font.setPointSize( 7 );
    textLabelRangeLastLimit->setFont( textLabelRangeLastLimit_font ); 
    textLabelRangeLastLimit->setFrameShape( QLabel::Panel );
    textLabelRangeLastLimit->setLineWidth( 1 );
    textLabelRangeLastLimit->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignRight ) );
    groupBoxSimRangeLayout->addWidget( textLabelRangeLastLimit );
    spacer61 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    groupBoxSimRangeLayout->addItem( spacer61 );
    radioButtonSameQrangeLayout->addWidget( groupBoxSimRange );
    layout131->addWidget( radioButtonSameQrange );

    checkBoxWeightSim = new QButtonGroup( privateLayoutWidget_4, "checkBoxWeightSim" );
    checkBoxWeightSim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxWeightSim->sizePolicy().hasHeightForWidth() ) );
    checkBoxWeightSim->setMaximumSize( QSize( 32767, 60 ) );
    checkBoxWeightSim->setCheckable( TRUE );
    checkBoxWeightSim->setChecked( FALSE );
    checkBoxWeightSim->setColumnLayout(0, Qt::Vertical );
    checkBoxWeightSim->layout()->setSpacing( 6 );
    checkBoxWeightSim->layout()->setMargin( 11 );
    checkBoxWeightSimLayout = new QHBoxLayout( checkBoxWeightSim->layout() );
    checkBoxWeightSimLayout->setAlignment( Qt::AlignTop );

    comboBoxWeightSim = new QComboBox( FALSE, checkBoxWeightSim, "comboBoxWeightSim" );
    comboBoxWeightSim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, comboBoxWeightSim->sizePolicy().hasHeightForWidth() ) );
    comboBoxWeightSim->setMinimumSize( QSize( 0, 20 ) );
    comboBoxWeightSim->setMaximumSize( QSize( 32767, 20 ) );
    comboBoxWeightSim->setPaletteForegroundColor( QColor( 128, 128, 128 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxWeightSim->setPalette( pal );
    QFont comboBoxWeightSim_font(  comboBoxWeightSim->font() );
    comboBoxWeightSim->setFont( comboBoxWeightSim_font ); 
    checkBoxWeightSimLayout->addWidget( comboBoxWeightSim );
    layout131->addWidget( checkBoxWeightSim );

    checkBoxResoSim = new QButtonGroup( privateLayoutWidget_4, "checkBoxResoSim" );
    checkBoxResoSim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxResoSim->sizePolicy().hasHeightForWidth() ) );
    checkBoxResoSim->setMaximumSize( QSize( 32767, 60 ) );
    checkBoxResoSim->setCheckable( TRUE );
    checkBoxResoSim->setChecked( FALSE );
    checkBoxResoSim->setColumnLayout(0, Qt::Vertical );
    checkBoxResoSim->layout()->setSpacing( 6 );
    checkBoxResoSim->layout()->setMargin( 11 );
    checkBoxResoSimLayout = new QHBoxLayout( checkBoxResoSim->layout() );
    checkBoxResoSimLayout->setAlignment( Qt::AlignTop );

    comboBoxResoSim = new QComboBox( FALSE, checkBoxResoSim, "comboBoxResoSim" );
    comboBoxResoSim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, comboBoxResoSim->sizePolicy().hasHeightForWidth() ) );
    comboBoxResoSim->setMinimumSize( QSize( 0, 20 ) );
    comboBoxResoSim->setMaximumSize( QSize( 32767, 20 ) );
    comboBoxResoSim->setPaletteForegroundColor( QColor( 128, 128, 128 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxResoSim->setPalette( pal );
    QFont comboBoxResoSim_font(  comboBoxResoSim->font() );
    comboBoxResoSim->setFont( comboBoxResoSim_font ); 
    checkBoxResoSimLayout->addWidget( comboBoxResoSim );
    layout131->addWidget( checkBoxResoSim );

    checkBoxPolySim = new QButtonGroup( privateLayoutWidget_4, "checkBoxPolySim" );
    checkBoxPolySim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxPolySim->sizePolicy().hasHeightForWidth() ) );
    checkBoxPolySim->setMaximumSize( QSize( 32767, 60 ) );
    checkBoxPolySim->setCheckable( TRUE );
    checkBoxPolySim->setChecked( FALSE );
    checkBoxPolySim->setColumnLayout(0, Qt::Vertical );
    checkBoxPolySim->layout()->setSpacing( 6 );
    checkBoxPolySim->layout()->setMargin( 11 );
    checkBoxPolySimLayout = new QHBoxLayout( checkBoxPolySim->layout() );
    checkBoxPolySimLayout->setAlignment( Qt::AlignTop );

    comboBoxPolySim = new QComboBox( FALSE, checkBoxPolySim, "comboBoxPolySim" );
    comboBoxPolySim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, comboBoxPolySim->sizePolicy().hasHeightForWidth() ) );
    comboBoxPolySim->setMinimumSize( QSize( 0, 20 ) );
    comboBoxPolySim->setMaximumSize( QSize( 32767, 20 ) );
    comboBoxPolySim->setPaletteForegroundColor( QColor( 128, 128, 128 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxPolySim->setPalette( pal );
    QFont comboBoxPolySim_font(  comboBoxPolySim->font() );
    comboBoxPolySim->setFont( comboBoxPolySim_font ); 
    checkBoxPolySimLayout->addWidget( comboBoxPolySim );
    layout131->addWidget( checkBoxPolySim );
    spacer21 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout131->addItem( spacer21 );
    tabLayout_3->addWidget( splitter5 );
    tabWidgetGenResults->insertTab( tab_3, QString::fromLatin1("") );

    tab_4 = new QWidget( tabWidgetGenResults, "tab_4" );
    tabLayout_4 = new QVBoxLayout( tab_4, 11, 6, "tabLayout_4"); 

    pushButtonNewTabRes = new QPushButton( tab_4, "pushButtonNewTabRes" );
    pushButtonNewTabRes->setEnabled( TRUE );
    pushButtonNewTabRes->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, pushButtonNewTabRes->sizePolicy().hasHeightForWidth() ) );
    pushButtonNewTabRes->setMinimumSize( QSize( 0, 40 ) );
    pushButtonNewTabRes->setMaximumSize( QSize( 32767, 40 ) );
    tabLayout_4->addWidget( pushButtonNewTabRes );

    pushButtonNewTabResCol = new QPushButton( tab_4, "pushButtonNewTabResCol" );
    pushButtonNewTabResCol->setEnabled( TRUE );
    pushButtonNewTabResCol->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, pushButtonNewTabResCol->sizePolicy().hasHeightForWidth() ) );
    pushButtonNewTabResCol->setMinimumSize( QSize( 0, 40 ) );
    pushButtonNewTabResCol->setMaximumSize( QSize( 32767, 40 ) );
    tabLayout_4->addWidget( pushButtonNewTabResCol );

    pushButtonresToLogWindow = new QPushButton( tab_4, "pushButtonresToLogWindow" );
    pushButtonresToLogWindow->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, pushButtonresToLogWindow->sizePolicy().hasHeightForWidth() ) );
    pushButtonresToLogWindow->setMinimumSize( QSize( 0, 40 ) );
    pushButtonresToLogWindow->setMaximumSize( QSize( 32767, 40 ) );
    tabLayout_4->addWidget( pushButtonresToLogWindow );

    pushButtonresToLogWindowOne = new QPushButton( tab_4, "pushButtonresToLogWindowOne" );
    pushButtonresToLogWindowOne->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, pushButtonresToLogWindowOne->sizePolicy().hasHeightForWidth() ) );
    pushButtonresToLogWindowOne->setMinimumSize( QSize( 0, 40 ) );
    pushButtonresToLogWindowOne->setMaximumSize( QSize( 32767, 40 ) );
    tabLayout_4->addWidget( pushButtonresToLogWindowOne );

    pushButtonresToActiveGraph = new QPushButton( tab_4, "pushButtonresToActiveGraph" );
    pushButtonresToActiveGraph->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, pushButtonresToActiveGraph->sizePolicy().hasHeightForWidth() ) );
    pushButtonresToActiveGraph->setMinimumSize( QSize( 0, 40 ) );
    pushButtonresToActiveGraph->setMaximumSize( QSize( 32767, 40 ) );
    tabLayout_4->addWidget( pushButtonresToActiveGraph );

    layout94 = new QHBoxLayout( 0, 0, 6, "layout94"); 

    pushButtonFitCurveDelete = new QToolButton( tab_4, "pushButtonFitCurveDelete" );
    pushButtonFitCurveDelete->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonFitCurveDelete->sizePolicy().hasHeightForWidth() ) );
    pushButtonFitCurveDelete->setMinimumSize( QSize( 0, 25 ) );
    pushButtonFitCurveDelete->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonFitCurveDelete->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonFitCurveDelete->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonFitCurveDelete->setPalette( pal );
    QFont pushButtonFitCurveDelete_font(  pushButtonFitCurveDelete->font() );
    pushButtonFitCurveDelete_font.setBold( TRUE );
    pushButtonFitCurveDelete->setFont( pushButtonFitCurveDelete_font ); 
    pushButtonFitCurveDelete->setIconSet( QIconSet( image6 ) );
    pushButtonFitCurveDelete->setUsesBigPixmap( FALSE );
    pushButtonFitCurveDelete->setUsesTextLabel( TRUE );
    pushButtonFitCurveDelete->setTextPosition( QToolButton::BesideIcon );
    layout94->addWidget( pushButtonFitCurveDelete );

    pushButtonSimulatedCurveDelete = new QToolButton( tab_4, "pushButtonSimulatedCurveDelete" );
    pushButtonSimulatedCurveDelete->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonSimulatedCurveDelete->sizePolicy().hasHeightForWidth() ) );
    pushButtonSimulatedCurveDelete->setMinimumSize( QSize( 0, 25 ) );
    pushButtonSimulatedCurveDelete->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonSimulatedCurveDelete->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonSimulatedCurveDelete->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonSimulatedCurveDelete->setPalette( pal );
    QFont pushButtonSimulatedCurveDelete_font(  pushButtonSimulatedCurveDelete->font() );
    pushButtonSimulatedCurveDelete_font.setBold( TRUE );
    pushButtonSimulatedCurveDelete->setFont( pushButtonSimulatedCurveDelete_font ); 
    pushButtonSimulatedCurveDelete->setIconSet( QIconSet( image6 ) );
    pushButtonSimulatedCurveDelete->setUsesBigPixmap( FALSE );
    pushButtonSimulatedCurveDelete->setUsesTextLabel( TRUE );
    pushButtonSimulatedCurveDelete->setTextPosition( QToolButton::BesideIcon );
    layout94->addWidget( pushButtonSimulatedCurveDelete );

    pushButtonGlobalDelete = new QToolButton( tab_4, "pushButtonGlobalDelete" );
    pushButtonGlobalDelete->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonGlobalDelete->sizePolicy().hasHeightForWidth() ) );
    pushButtonGlobalDelete->setMinimumSize( QSize( 0, 25 ) );
    pushButtonGlobalDelete->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonGlobalDelete->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonGlobalDelete->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonGlobalDelete->setPalette( pal );
    QFont pushButtonGlobalDelete_font(  pushButtonGlobalDelete->font() );
    pushButtonGlobalDelete_font.setBold( TRUE );
    pushButtonGlobalDelete->setFont( pushButtonGlobalDelete_font ); 
    pushButtonGlobalDelete->setIconSet( QIconSet( image6 ) );
    pushButtonGlobalDelete->setUsesBigPixmap( FALSE );
    pushButtonGlobalDelete->setUsesTextLabel( TRUE );
    pushButtonGlobalDelete->setTextPosition( QToolButton::BesideIcon );
    layout94->addWidget( pushButtonGlobalDelete );
    tabLayout_4->addLayout( layout94 );
    spacer17_2 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    tabLayout_4->addItem( spacer17_2 );
    tabWidgetGenResults->insertTab( tab_4, QString::fromLatin1("") );

    TabPage_4 = new QWidget( tabWidgetGenResults, "TabPage_4" );
    TabPageLayout_4 = new QVBoxLayout( TabPage_4, 11, 6, "TabPageLayout_4"); 

    layout25 = new QHBoxLayout( 0, 0, 6, "layout25"); 

    textLabelPattern = new QLabel( TabPage_4, "textLabelPattern" );
    textLabelPattern->setMinimumSize( QSize( 0, 0 ) );
    textLabelPattern->setMaximumSize( QSize( 70, 32767 ) );
    layout25->addWidget( textLabelPattern );

    lineEditPattern = new QLineEdit( TabPage_4, "lineEditPattern" );
    lineEditPattern->setEnabled( TRUE );
    layout25->addWidget( lineEditPattern );

    pushButtonPattern = new QPushButton( TabPage_4, "pushButtonPattern" );
    pushButtonPattern->setEnabled( FALSE );
    pushButtonPattern->setMaximumSize( QSize( 120, 30 ) );
    layout25->addWidget( pushButtonPattern );

    pushButtonSelectFromTable = new QPushButton( TabPage_4, "pushButtonSelectFromTable" );
    pushButtonSelectFromTable->setEnabled( FALSE );
    pushButtonSelectFromTable->setMaximumSize( QSize( 120, 30 ) );
    layout25->addWidget( pushButtonSelectFromTable );
    TabPageLayout_4->addLayout( layout25 );

    tableMultiFit = new QTable( TabPage_4, "tableMultiFit" );
    tableMultiFit->setNumRows( tableMultiFit->numRows() + 1 );
    tableMultiFit->verticalHeader()->setLabel( tableMultiFit->numRows() - 1, tr( "All" ) );
    tableMultiFit->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, tableMultiFit->sizePolicy().hasHeightForWidth() ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tableMultiFit->setPalette( pal );
    tableMultiFit->setFrameShape( QTable::GroupBoxPanel );
    tableMultiFit->setLineWidth( 2 );
    tableMultiFit->setResizePolicy( QTable::Default );
    tableMultiFit->setNumRows( 1 );
    tableMultiFit->setNumCols( 0 );
    TabPageLayout_4->addWidget( tableMultiFit );

    layout5 = new QHBoxLayout( 0, 2, 2, "layout5"); 

    textLabelfromQ = new QLabel( TabPage_4, "textLabelfromQ" );
    textLabelfromQ->setMinimumSize( QSize( 70, 0 ) );
    layout5->addWidget( textLabelfromQ );

    lineEditFromQ = new QLineEdit( TabPage_4, "lineEditFromQ" );
    lineEditFromQ->setMaximumSize( QSize( 32767, 30 ) );
    layout5->addWidget( lineEditFromQ );

    textLabelToQ = new QLabel( TabPage_4, "textLabelToQ" );
    textLabelToQ->setMinimumSize( QSize( 70, 0 ) );
    layout5->addWidget( textLabelToQ );

    lineEditToQ = new QLineEdit( TabPage_4, "lineEditToQ" );
    lineEditToQ->setMaximumSize( QSize( 32767, 30 ) );
    layout5->addWidget( lineEditToQ );
    TabPageLayout_4->addLayout( layout5 );

    layout24 = new QHBoxLayout( 0, 2, 2, "layout24"); 

    textLabelfromQ_2 = new QLabel( TabPage_4, "textLabelfromQ_2" );
    textLabelfromQ_2->setMaximumSize( QSize( 100, 30 ) );
    layout24->addWidget( textLabelfromQ_2 );

    lineEditSetBySetFit = new QLineEdit( TabPage_4, "lineEditSetBySetFit" );
    lineEditSetBySetFit->setMaximumSize( QSize( 32767, 30 ) );
    layout24->addWidget( lineEditSetBySetFit );
    TabPageLayout_4->addLayout( layout24 );

    layout26 = new QHBoxLayout( 0, 0, 6, "layout26"); 

    pushButtonSetBySetFit = new QPushButton( TabPage_4, "pushButtonSetBySetFit" );
    pushButtonSetBySetFit->setEnabled( FALSE );
    pushButtonSetBySetFit->setMaximumSize( QSize( 32767, 30 ) );
    layout26->addWidget( pushButtonSetBySetFit );

    pushButtonSimulateMulti = new QPushButton( TabPage_4, "pushButtonSimulateMulti" );
    pushButtonSimulateMulti->setEnabled( FALSE );
    pushButtonSimulateMulti->setMaximumSize( QSize( 32767, 30 ) );
    layout26->addWidget( pushButtonSimulateMulti );

    pushButtonDeleteCurves = new QPushButton( TabPage_4, "pushButtonDeleteCurves" );
    pushButtonDeleteCurves->setEnabled( TRUE );
    pushButtonDeleteCurves->setMaximumSize( QSize( 32767, 30 ) );
    pushButtonDeleteCurves->setIconSet( QIconSet( image7 ) );
    layout26->addWidget( pushButtonDeleteCurves );
    TabPageLayout_4->addLayout( layout26 );
    tabWidgetGenResults->insertTab( TabPage_4, QString::fromLatin1("") );
    WStackPageLayout->addWidget( tabWidgetGenResults );
    widgetStackFit->addWidget( WStackPage, 2 );
    fitTable10Layout->addWidget( widgetStackFit );

    layout93 = new QHBoxLayout( 0, 0, 3, "layout93"); 

    comboBoxFunction = new QComboBox( FALSE, this, "comboBoxFunction" );
    comboBoxFunction->setEnabled( TRUE );
    comboBoxFunction->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxFunction->sizePolicy().hasHeightForWidth() ) );
    comboBoxFunction->setMinimumSize( QSize( 90, 15 ) );
    comboBoxFunction->setMaximumSize( QSize( 32767, 30 ) );
    comboBoxFunction->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 103, 141, 178) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 103, 141, 178) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 103, 141, 178) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setDisabled( cg );
    comboBoxFunction->setPalette( pal );
    layout93->addWidget( comboBoxFunction );

    comboBoxPolyFunction_2 = new QComboBox( FALSE, this, "comboBoxPolyFunction_2" );
    comboBoxPolyFunction_2->setEnabled( TRUE );
    comboBoxPolyFunction_2->setMinimumSize( QSize( 90, 15 ) );
    comboBoxPolyFunction_2->setMaximumSize( QSize( 32767, 30 ) );
    comboBoxPolyFunction_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 103, 141, 178) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 103, 141, 178) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 103, 141, 178) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setDisabled( cg );
    comboBoxPolyFunction_2->setPalette( pal );
    layout93->addWidget( comboBoxPolyFunction_2 );
    fitTable10Layout->addLayout( layout93 );

    layout7_2 = new QHBoxLayout( 0, 0, 6, "layout7_2"); 

    textLabelInfoSAS = new QLabel( this, "textLabelInfoSAS" );
    textLabelInfoSAS->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfoSAS->sizePolicy().hasHeightForWidth() ) );
    textLabelInfoSAS->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfoSAS->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfoSAS->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    textLabelInfoSAS->setFrameShape( QLabel::Box );
    textLabelInfoSAS->setTextFormat( QLabel::RichText );
    textLabelInfoSAS->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    textLabelInfoSAS->setIndent( 0 );
    layout7_2->addWidget( textLabelInfoSAS );

    textLabelInfo_2 = new QLabel( this, "textLabelInfo_2" );
    textLabelInfo_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo_2->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfo_2->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    textLabelInfo_2->setFrameShape( QLabel::Box );
    textLabelInfo_2->setAlignment( int( QLabel::AlignCenter ) );
    layout7_2->addWidget( textLabelInfo_2 );

    textLabelInfo_2_2 = new QLabel( this, "textLabelInfo_2_2" );
    textLabelInfo_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo_2_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfo_2_2->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    textLabelInfo_2_2->setFrameShape( QLabel::Box );
    textLabelInfo_2_2->setFrameShadow( QLabel::Plain );
    textLabelInfo_2_2->setAlignment( int( QLabel::AlignCenter ) );
    layout7_2->addWidget( textLabelInfo_2_2 );

    pushButtonHelp = new QPushButton( this, "pushButtonHelp" );
    pushButtonHelp->setMinimumSize( QSize( 20, 20 ) );
    pushButtonHelp->setMaximumSize( QSize( 20, 20 ) );
    pushButtonHelp->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 223, 223, 223) );
    cg.setColor( QColorGroup::Dark, QColor( 96, 96, 96) );
    cg.setColor( QColorGroup::Mid, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 192, 192, 192) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Dark, QColor( 96, 96, 96) );
    cg.setColor( QColorGroup::Mid, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 192, 192, 192) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Dark, QColor( 96, 96, 96) );
    cg.setColor( QColorGroup::Mid, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 192, 192, 192) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonHelp->setPalette( pal );
    pushButtonHelp->setPixmap( image8 );
    pushButtonHelp->setFlat( TRUE );
    layout7_2->addWidget( pushButtonHelp );
    fitTable10Layout->addLayout( layout7_2 );
    languageChange();
    resize( QSize(930, 911).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
fitTable10::~fitTable10()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void fitTable10::languageChange()
{
    setCaption( tr( "QtiKWS::FIT::Curve(s)" ) );
    buttonGroupNavigator->setTitle( QString::null );
    pushButtonLoadFittingSession->setText( tr( "Load Fitting Session" ) );
    pushButtonSaveSession->setText( tr( "Save Current Fitting Session" ) );
    buttonGroup56_2->setTitle( QString::null );
    textLabelLeft->setText( tr( "..." ) );
    pushButtonFitPrev->setText( QString::null );
    textLabelCenter->setText( tr( "Select Function" ) );
    pushButtonFitNext->setText( QString::null );
    textLabelRight->setText( tr( "Fitting Session" ) );
    textLabelGroupName_2->setText( tr( "Categories" ) );
    QToolTip::add( listBoxGroup, tr( "Click to Select Group" ) );
    QWhatsThis::add( listBoxGroup, tr( "Click to Select Group" ) );
    textLabelFunctionName_2->setText( tr( "Functions" ) );
    QToolTip::add( listBoxFunctions, tr( "Click to Select Function" ) );
    QWhatsThis::add( listBoxFunctions, tr( "Click to Select Function" ) );
    textBrowserFunctionDescription00->setText( QString::null );
    QToolTip::add( textBrowserFunctionDescription00, tr( "Description of the selected Function" ) );
    QWhatsThis::add( textBrowserFunctionDescription00, tr( "Description of the selected Function" ) );
    tabWidget4->changeTab( tab, tr( "Info :: Function" ) );
    tableParaComments00->horizontalHeader()->setLabel( 0, tr( "Description of Parameters      " ) );
    QToolTip::add( tableParaComments00, tr( "Description of Parameters of the selected Function" ) );
    QWhatsThis::add( tableParaComments00, tr( "Description of Parameters of the selected Function" ) );
    tabWidget4->changeTab( tab_2, tr( "Info :: Parameters" ) );
    checkBoxSANSsupport->setText( tr( "[Instrumental Fit]" ) );
    QToolTip::add( checkBoxSANSsupport, QString::null );
    QWhatsThis::add( checkBoxSANSsupport, QString::null );
    checkBoxMultiData->setText( tr( "[Global Fit]" ) );
    QToolTip::add( checkBoxMultiData, tr( "Simultanious Fit of Several Datasets" ) );
    QWhatsThis::add( checkBoxMultiData, tr( "Simultanious Fit of Several Datasets" ) );
    checkBoxSuperpositionalFit->setText( tr( "[Superpositional Fit]" ) );
    QToolTip::add( checkBoxSuperpositionalFit, tr( "Simultanious Fit of Several Datasets" ) );
    QWhatsThis::add( checkBoxSuperpositionalFit, tr( "Simultanious Fit of Several Datasets" ) );
    checkBoxShowEFIT->setText( tr( "[ONLY eFit functions]" ) );
    comboBoxInstrument->clear();
    comboBoxInstrument->insertItem( tr( "SANS" ) );
    comboBoxInstrument->insertItem( tr( "Back-Scattering" ) );
    spinBoxNumberCurvesToFit->setPrefix( tr( "# Curves:  " ) );
    spinBoxNumberCurvesToFit->setSuffix( QString::null );
    QToolTip::add( spinBoxNumberCurvesToFit, tr( "Number of Curves" ) );
    QWhatsThis::add( spinBoxNumberCurvesToFit, tr( "Number of Curves" ) );
    spinBoxSubFitNumber->setPrefix( tr( "#Functions:  " ) );
    spinBoxSubFitNumber->setSuffix( QString::null );
    QToolTip::add( spinBoxSubFitNumber, tr( "Number of Curves" ) );
    QWhatsThis::add( spinBoxSubFitNumber, tr( "Number of Curves" ) );
    spinBoxSubFitCurrent->setPrefix( tr( "Current Function:  " ) );
    spinBoxSubFitCurrent->setSuffix( QString::null );
    QToolTip::add( spinBoxSubFitCurrent, tr( "Number of Curves" ) );
    QWhatsThis::add( spinBoxSubFitCurrent, tr( "Number of Curves" ) );
    pushButtonIFIT->setText( tr( "e-Fit" ) );
    pushButtonIFITadv->setText( tr( "e-Fit+++" ) );
    tabWidget4->changeTab( TabPage, tr( "Options" ) );
    tableCurves->verticalHeader()->setLabel( 0, tr( "DataSets" ) );
    tableCurves->verticalHeader()->setLabel( 1, tr( "# points" ) );
    tableCurves->verticalHeader()->setLabel( 2, tr( "first point" ) );
    tableCurves->verticalHeader()->setLabel( 3, tr( "last point" ) );
    tableCurves->verticalHeader()->setLabel( 4, tr( "Weighting" ) );
    tableCurves->verticalHeader()->setLabel( 5, tr( "Resolution" ) );
    tableCurves->verticalHeader()->setLabel( 6, tr( "Polydispersity" ) );
    tabWidgetFit->changeTab( dataSets, tr( "Data" ) );
    textLabelFfunc->setText( tr( "..." ) );
    QToolTip::add( textLabelFfunc, tr( "Selected Function" ) );
    spinBoxPara->setPrefix( tr( "# Parameters: " ) );
    QToolTip::add( spinBoxPara, tr( "Fitting Function: Number of Parameters." ) );
    spinBoxXnumber->setPrefix( tr( "# Indep. Variables: " ) );
    QToolTip::add( spinBoxXnumber, tr( "Fitting Function: Number of Indepenrent Variables." ) );
    spinBoxFnumber->setPrefix( tr( "# Dep. Variables: " ) );
    QToolTip::add( spinBoxFnumber, tr( "Fitting Function: Number of Indepenrent Variables." ) );
    textBrowserFunctionDescription->setText( tr( "..Function Comments..." ) );
    tableParaComments->horizontalHeader()->setLabel( 0, tr( "Description of Parameters      " ) );
    tabWidgetFit->changeTab( Function, tr( "Function" ) );
    tablePara->horizontalHeader()->setLabel( 0, tr( " Share?" ) );
    tablePara->horizontalHeader()->setLabel( 1, tr( "Vary?" ) );
    tablePara->horizontalHeader()->setLabel( 2, tr( "Value" ) );
    tablePara->horizontalHeader()->setLabel( 3, tr( "Error" ) );
    tabWidgetFit->changeTab( parameters, tr( "Parameters" ) );
    buttonGroup21->setTitle( tr( "Scale Limits by Initial Parameter Values" ) );
    textLabelRandomSeed_3->setText( tr( "P[initial] /" ) );
    lineEditLeftMargin->setText( tr( "5" ) );
    textLabel2->setText( tr( "< P <" ) );
    lineEditRightMargin->setText( tr( "5" ) );
    textLabelRandomSeed_3_2->setText( tr( "* P[initial]" ) );
    toolButtonApplyLimits->setText( tr( "Apply" ) );
    toolButtonResetLimits->setText( tr( "Reset" ) );
    tabWidgetFit->changeTab( TabPage_2, tr( "Limits" ) );
    buttonGroup18->setTitle( QString::null );
    textLabel1_2_2->setText( tr( "Algorithm" ) );
    textLabel2_2_2_2->setText( tr( "Significant Digits" ) );
    comboBoxFitMethod->clear();
    comboBoxFitMethod->insertItem( tr( "Nelder-Mead Simplex  [nmsimplex2]" ) );
    comboBoxFitMethod->insertItem( tr( "Nelder-Mead Simplex  [nmsimplex2rand]" ) );
    comboBoxFitMethod->insertItem( tr( "Levenberg-Marquardt [Delta, Scaled]" ) );
    comboBoxFitMethod->insertItem( tr( "Levenberg-Marquardt [Delta, Unscaled]" ) );
    comboBoxFitMethod->insertItem( tr( "Levenberg-Marquardt [Gradient, Scaled]" ) );
    comboBoxFitMethod->insertItem( tr( "Levenberg-Marquardt [Gradient, Unscaled]" ) );
    comboBoxFitMethod->insertItem( tr( "[GenMin]" ) );
    comboBoxFitMethod->setCurrentItem( 3 );
    buttonGroupGenMin->setTitle( tr( "Genetiv Algorithm Options [GenMin]" ) );
    textLabel1->setText( tr( "Genome count" ) );
    textLabel1_3->setText( tr( "Max. # of Generations" ) );
    textLabel1_3_2->setText( tr( "Selection Rate" ) );
    textLabel1_3_2_2->setText( tr( "Mutation Rate" ) );
    lineEditSelectionRate->setText( tr( "0.05" ) );
    lineEditMutationRate->setText( tr( "0.03" ) );
    textLabelRandomSeed->setText( tr( "Random Seed" ) );
    buttonGroupSimplex->setTitle( tr( "Simplex Options" ) );
    textLabel1_2->setText( tr( "Iterations" ) );
    textLabel2_2->setText( tr( "Eps. Absolute" ) );
    textLabel2_2_2->setText( tr( "Eps. Relative" ) );
    lineEditToleranceAbs->setText( tr( "0" ) );
    lineEditTolerance->setText( tr( "0.0001" ) );
    buttonGroupWM->setTitle( tr( "Weighting Method" ) );
    comboBoxWeightingMethod->clear();
    comboBoxWeightingMethod->insertItem( trUtf8( "\x77\x20\x3d\x20\x31\x2f\x57\xc2\xb2\x20\x7c\x20\x41\x72\x62\x69\x74\x72\x61\x72\x79"
    "\x20\x44\x61\x74\x61\x73\x65\x74\x20\x5b\x57\x65\x69\x67\x68\x74\x5d\x20\x7c\x20"
    "\x57\x3d\x57\x28\x78\x29" ) );
    comboBoxWeightingMethod->insertItem( tr( "w = 1/Y  | Statistical | Y=|Y(x)|  fitted data" ) );
    comboBoxWeightingMethod->insertItem( tr( "w = W   | Direct | Arbitrary Dataset [Weight] | W=W(x)" ) );
    comboBoxWeightingMethod->insertItem( trUtf8( "\x77\x20\x3d\x20\x31\x2f\x59\xc2\xb2\x20\x7c\x20\x56\x61\x72\x69\x61\x6e\x63\x65\x20"
    "\x7c\x20\x59\x3d\x59\x28\x78\x29\x20\x20\x66\x69\x74\x74\x65\x64\x20\x64\x61\x74"
    "\x61" ) );
    comboBoxWeightingMethod->insertItem( tr( "w = 1/Y^a | Variance | Y=Y(x)  fitted data" ) );
    comboBoxWeightingMethod->insertItem( tr( "w = 1/[c^a+b*Y^a]  | Variance | Y=Y(x)  fitted data" ) );
    comboBoxWeightingMethod->insertItem( tr( "w = 1/ Y^a / c^|Xmax-X|  | Variance" ) );
    comboBoxWeightingMethod->setCurrentItem( 1 );
    textLabelWA->setText( tr( "a" ) );
    lineEditWA->setText( tr( "2.00" ) );
    textLabelWB->setText( tr( "b" ) );
    lineEditWB->setText( tr( "1.00" ) );
    textLabelWC->setText( tr( "c" ) );
    lineEditWC->setText( tr( "1.00" ) );
    textLabelWXMAX->setText( tr( "xmax" ) );
    lineEditWXMAX->setText( tr( "0.00" ) );
    groupBoxResoInt->setTitle( QString::null );
    comboBoxResoFunction->clear();
    comboBoxResoFunction->insertItem( tr( "Gauss-SANS" ) );
    comboBoxResoFunction->insertItem( tr( "Triangular" ) );
    comboBoxResoFunction->insertItem( tr( "Bessel-SANS" ) );
    comboBoxResoFunction->insertItem( tr( "Gauss" ) );
    comboBoxResoFunction->setCurrentItem( 0 );
    QToolTip::add( comboBoxResoFunction, tr( "Select shape of the resolution function" ) );
    QWhatsThis::add( comboBoxResoFunction, tr( "Select shape of the resolution function" ) );
    comboBoxSpeedControlReso->clear();
    comboBoxSpeedControlReso->insertItem( tr( "Fastest (>99.00%)" ) );
    comboBoxSpeedControlReso->insertItem( tr( "Fast       (99.80%)" ) );
    comboBoxSpeedControlReso->insertItem( tr( "Faster   (>99.90%)" ) );
    comboBoxSpeedControlReso->insertItem( tr( "Slow      (>99.95%)" ) );
    comboBoxSpeedControlReso->insertItem( tr( "Slower   (>99.98%)" ) );
    comboBoxSpeedControlReso->insertItem( tr( "Slowest (>99.99%)" ) );
    comboBoxSpeedControlReso->insertItem( tr( "Perfect ( >>> 99.99%)" ) );
    comboBoxSpeedControlReso->insertItem( tr( "Custom (> ??.??%)" ) );
    comboBoxSpeedControlReso->setCurrentItem( 2 );
    QToolTip::add( comboBoxSpeedControlReso, tr( "Select pre-defined modes of integral calculation" ) );
    QWhatsThis::add( comboBoxSpeedControlReso, tr( "Select pre-defined modes of integral calculation" ) );
    textLabelAbsErr->setText( tr( "Absolute Error" ) );
    lineEditAbsErr->setText( tr( "0" ) );
    QToolTip::add( lineEditAbsErr, tr( "Integral control in custom mode:: the absolute error" ) );
    QWhatsThis::add( lineEditAbsErr, tr( "Integral control in custom mode:: the absolute error" ) );
    textLabelAbsErr_2->setText( tr( "Relative Error" ) );
    lineEditRelErr->setText( tr( "0" ) );
    QToolTip::add( lineEditRelErr, tr( "Integral control in custom mode:: the relative error" ) );
    QWhatsThis::add( lineEditRelErr, tr( "Integral control in custom mode:: the relative error" ) );
    textLabelIntWork->setText( tr( "Number of points" ) );
    QToolTip::add( spinBoxIntWorkspase, tr( "Integral control in custom mode:: upper limit of nodes" ) );
    QWhatsThis::add( spinBoxIntWorkspase, tr( "Integral control in custom mode:: upper limit of nodes" ) );
    textLabelSigma->setText( trUtf8( "\x2b\x2f\x2d\x4e\xcf\x83" ) );
    QToolTip::add( spinBoxIntLimits, trUtf8( "\x49\x6e\x74\x65\x67\x72\x61\x74\x69\x6f\x6e\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x20"
    "\x6c\x69\x6d\x69\x74\x61\x74\x69\x6f\x6e\x3a\x3a\x20\x3c\x52\x3e\x5b\x31\x2d\x4e"
    "\xcf\x83\x5d\x20\x2e\x2e\x2e\x20\x3c\x52\x3e\x5b\x31\x2b\x4e\xcf\x83\x5d" ) );
    QWhatsThis::add( spinBoxIntLimits, trUtf8( "\x49\x6e\x74\x65\x67\x72\x61\x74\x69\x6f\x6e\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x20"
    "\x6c\x69\x6d\x69\x74\x61\x74\x69\x6f\x6e\x3a\x3a\x20\x3c\x52\x3e\x5b\x31\x2d\x4e"
    "\xcf\x83\x5d\x20\x2e\x2e\x2e\x20\x3c\x52\x3e\x5b\x31\x2b\x4e\xcf\x83\x5d" ) );
    toolBoxResoPoly->setItemLabel( toolBoxResoPoly->indexOf(page1), tr( "Resolution Options" ) );
    groupBoxPolyInt->setTitle( QString::null );
    comboBoxPolyFunction->clear();
    comboBoxPolyFunction->insertItem( tr( "Gauss" ) );
    comboBoxPolyFunction->insertItem( tr( "Schultz-Zimm" ) );
    comboBoxPolyFunction->insertItem( tr( "Gamma" ) );
    comboBoxPolyFunction->insertItem( tr( "Log-Normal" ) );
    comboBoxPolyFunction->insertItem( tr( "Uniform" ) );
    comboBoxPolyFunction->insertItem( tr( "Triangular" ) );
    QToolTip::add( comboBoxPolyFunction, tr( "Select type of polydistersidy distribution" ) );
    QWhatsThis::add( comboBoxPolyFunction, tr( "Select type of polydistersidy distribution" ) );
    comboBoxSpeedControlPoly->clear();
    comboBoxSpeedControlPoly->insertItem( tr( "Fastest (>99.00%)" ) );
    comboBoxSpeedControlPoly->insertItem( tr( "Fast       (99.80%)" ) );
    comboBoxSpeedControlPoly->insertItem( tr( "Faster   (>99.90%)" ) );
    comboBoxSpeedControlPoly->insertItem( tr( "Slow      (>99.95%)" ) );
    comboBoxSpeedControlPoly->insertItem( tr( "Slower   (>99.98%)" ) );
    comboBoxSpeedControlPoly->insertItem( tr( "Slowest (>99.99%)" ) );
    comboBoxSpeedControlPoly->insertItem( tr( "Perfect ( >>> 99.99%)" ) );
    comboBoxSpeedControlPoly->insertItem( tr( "Custom (> ??.??%)" ) );
    comboBoxSpeedControlPoly->setCurrentItem( 2 );
    QToolTip::add( comboBoxSpeedControlPoly, tr( "Select pre-defined modes of integral calculation" ) );
    QWhatsThis::add( comboBoxSpeedControlPoly, tr( "Select pre-defined modes of integral calculation" ) );
    textLabelAbsErrPoly->setText( tr( "Absolute Error" ) );
    lineEditAbsErrPoly->setText( tr( "0" ) );
    QToolTip::add( lineEditAbsErrPoly, tr( "Integral control in custom mode:: the absolute error" ) );
    QWhatsThis::add( lineEditAbsErrPoly, tr( "Integral control in custom mode:: the absolute error" ) );
    textLabelPelErrPoly->setText( tr( "Relative Error" ) );
    lineEditRelErrPoly->setText( tr( "0" ) );
    QToolTip::add( lineEditRelErrPoly, tr( "Integral control in custom mode:: the relative error" ) );
    QWhatsThis::add( lineEditRelErrPoly, tr( "Integral control in custom mode:: the relative error" ) );
    textLabelIntWorkPoly->setText( tr( "Number of points" ) );
    QToolTip::add( spinBoxIntWorkspasePoly, tr( "Integral control in custom mode:: upper limit of nodes" ) );
    QWhatsThis::add( spinBoxIntWorkspasePoly, tr( "Integral control in custom mode:: upper limit of nodes" ) );
    textLabelSigmaNpoly->setText( trUtf8( "\x2b\x2f\x2d\x4e\xcf\x83" ) );
    QToolTip::add( spinBoxIntLimitsPoly, trUtf8( "\x49\x6e\x74\x65\x67\x72\x61\x74\x69\x6f\x6e\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x20"
    "\x6c\x69\x6d\x69\x74\x61\x74\x69\x6f\x6e\x3a\x3a\x20\x3c\x52\x3e\x5b\x31\x2d\x4e"
    "\xcf\x83\x5d\x20\x2e\x2e\x2e\x20\x3c\x52\x3e\x5b\x31\x2b\x4e\xcf\x83\x5d" ) );
    QWhatsThis::add( spinBoxIntLimitsPoly, trUtf8( "\x49\x6e\x74\x65\x67\x72\x61\x74\x69\x6f\x6e\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x20"
    "\x6c\x69\x6d\x69\x74\x61\x74\x69\x6f\x6e\x3a\x3a\x20\x3c\x52\x3e\x5b\x31\x2d\x4e"
    "\xcf\x83\x5d\x20\x2e\x2e\x2e\x20\x3c\x52\x3e\x5b\x31\x2b\x4e\xcf\x83\x5d" ) );
    toolBoxResoPoly->setItemLabel( toolBoxResoPoly->indexOf(page2), tr( "Polydispersity Options" ) );
    tabWidgetFit->changeTab( TabPage_3, tr( "Fit - Control" ) );
    buttonGroup58_2->setTitle( QString::null );
    pushButtonUndo->setText( QString::null );
    pushButtonUndo->setTextLabel( QString::null );
    pushButtonMultiFit->setText( tr( "FIT" ) );
    pushButtonMultiFit->setTextLabel( QString::null );
    pushButtonSimulateSuperpositional->setText( QString::null );
    pushButtonSimulateSuperpositional->setTextLabel( QString::null );
    pushButtonChiSqr->setText( tr( "Simulate" ) );
    pushButtonChiSqr->setTextLabel( QString::null );
    pushButtonRedo->setText( QString::null );
    pushButtonRedo->setTextLabel( QString::null );
    pushButtonINITbefore->setText( tr( "Script: Before Fit" ) );
    pushButtonINITbefore->setTextLabel( QString::null );
    QToolTip::add( pushButtonINITbefore, tr( "In function body: bool initBeforeFit >> true." ) );
    QWhatsThis::add( pushButtonINITbefore, tr( "In function body: bool initBeforeFit >> true." ) );
    pushButtonINITafter->setText( tr( "Script: After Fit" ) );
    pushButtonINITafter->setTextLabel( QString::null );
    QToolTip::add( pushButtonINITafter, tr( "In function body: bool initAfrerFit >> true." ) );
    QWhatsThis::add( pushButtonINITafter, tr( "In function body: bool initAfrerFit >> true." ) );
    buttonGroup57_2->setTitle( QString::null );
    textLabelChiLabel_3_2->setText( tr( "R<sup> 2</sup>=" ) );
    textLabelChiLabel_2_3->setText( tr( "time=" ) );
    textLabelR2->setText( tr( "..." ) );
    textLabelChi->setText( tr( "..." ) );
    textLabelChiLabel->setText( trUtf8( "\xcf\x87\x3c\x73\x75\x70\x3e\x20\x32\x3c\x2f\x73\x75\x70\x3e\x2f\x64\x6f\x66\x3d" ) );
    textLabelTime->setText( tr( "..." ) );
    tableParaSimulate->horizontalHeader()->setLabel( 0, tr( "Value" ) );
    buttonGroup9->setTitle( QString::null );
    pushButtonSimulate->setText( tr( "Simulate" ) );
    pushButtonSimulate->setTextLabel( QString::null );
    checkBoxSimIndexing->setText( QString::null );
    QToolTip::add( checkBoxSimIndexing, tr( "Indexing of Simulated Matrixes" ) );
    QWhatsThis::add( checkBoxSimIndexing, tr( "Indexing of Simulated Matrixes" ) );
    pushButtonSimulateSuperpositionalRes->setText( QString::null );
    pushButtonSimulateSuperpositionalRes->setTextLabel( QString::null );
    pushButtonSimulateDelete->setText( QString::null );
    pushButtonSimulateDelete->setTextLabel( tr( "Delete All" ) );
    textLabelChiLabel_2_2->setText( tr( "time=" ) );
    textLabelTimeSim->setText( tr( "..." ) );
    textLabelChiLabelSim->setText( trUtf8( "\xcf\x87\x3c\x73\x75\x70\x3e\x32\x3c\x2f\x73\x75\x70\x3e\x3d" ) );
    textLabelChi2Sim->setText( tr( "..." ) );
    QToolTip::add( textLabelChi2Sim, tr( "chi^2" ) );
    QWhatsThis::add( textLabelChi2Sim, tr( "chi^2" ) );
    textLabelChiLabelDofSim->setText( trUtf8( "\xcf\x87\x3c\x73\x75\x70\x3e\x32\x3c\x2f\x73\x75\x70\x3e\x2f\x64\x6f\x66\x3d" ) );
    textLabelChi2dofSim->setText( tr( "..." ) );
    QToolTip::add( textLabelChi2dofSim, tr( "\"reduced\" chi^2" ) );
    QWhatsThis::add( textLabelChi2dofSim, tr( "\"reduced\" chi^2" ) );
    textLabelR2simInt->setText( tr( "R<sup> 2</sup>=" ) );
    textLabelR2sim->setText( tr( "..." ) );
    QToolTip::add( textLabelR2sim, tr( "R^2 :: the goodness of a fit" ) );
    QWhatsThis::add( textLabelR2sim, tr( "R^2 :: the goodness of a fit" ) );
    groupBoxPointsPara->setTitle( QString::null );
    textLabelfromQsim_2->setText( tr( "# np" ) );
    QToolTip::add( textLabelfromQsim_2, tr( "number of adjustable parameters" ) );
    QWhatsThis::add( textLabelfromQsim_2, tr( "number of adjustable parameters" ) );
    textLabelnpSIM->setText( tr( "..." ) );
    QToolTip::add( textLabelnpSIM, tr( "number of adjustable parameters" ) );
    QWhatsThis::add( textLabelnpSIM, tr( "number of adjustable parameters" ) );
    textLabelToQsim_2->setText( tr( "# data points" ) );
    QToolTip::add( textLabelToQsim_2, tr( "active data points" ) );
    QWhatsThis::add( textLabelToQsim_2, tr( "active data points" ) );
    textLabelDofSim->setText( tr( "..." ) );
    QToolTip::add( textLabelDofSim, tr( "active data points" ) );
    QWhatsThis::add( textLabelDofSim, tr( "active data points" ) );
    buttonGroup10->setTitle( tr( "Output control" ) );
    checkBoxCovar->setText( tr( "+ Statistics Notes [after fit]" ) );
    QToolTip::add( checkBoxCovar, tr( "Generation of Note with statistical data: Covariance Matrix, Errors, Dependences, ..." ) );
    QWhatsThis::add( checkBoxCovar, tr( "Generation of Note with statistical data: Covariance Matrix, Errors, Dependences, ..." ) );
    checkBoxSaveSession->setText( tr( "+ Save Session" ) );
    QToolTip::add( checkBoxSaveSession, tr( "Save Session" ) );
    QWhatsThis::add( checkBoxSaveSession, tr( "Save Session" ) );
    radioButtonUniform_Q->setTitle( tr( "Q-range" ) );
    groupBoxQrange->setTitle( QString::null );
    textLabelfromQsim->setText( tr( "Q[min]=" ) );
    lineEditFromQsim->setText( tr( "0.001" ) );
    lineEditToQsim->setText( tr( "0.55" ) );
    lineEditNumPointsSim->setText( tr( "100" ) );
    textLabelToQsim->setText( tr( "Q[max]=" ) );
    textLabelnumPointssim->setText( tr( "# Points" ) );
    checkBoxLogStep->setText( tr( "Logarithmic Step" ) );
    radioButtonSameQrange->setTitle( tr( "Dataset" ) );
    groupBoxSimRange->setTitle( QString::null );
    comboBoxSimQN->clear();
    comboBoxSimQN->insertItem( tr( "N" ) );
    comboBoxSimQN->insertItem( tr( "Q" ) );
    label11_4->setText( tr( "::" ) );
    QToolTip::add( label11_4, QString::null );
    QWhatsThis::add( label11_4, QString::null );
    textLabelRangeFirstLimit->setText( tr( "..." ) );
    QToolTip::add( textLabelRangeFirstLimit, QString::null );
    QWhatsThis::add( textLabelRangeFirstLimit, QString::null );
    label11->setText( trUtf8( "\xe2\x89\xa4" ) );
    QToolTip::add( label11, QString::null );
    QWhatsThis::add( label11, QString::null );
    textLabelRangeFirst->setText( tr( "..." ) );
    label11_2->setText( trUtf8( "\xe2\x89\xa4" ) );
    QToolTip::add( label11_2, QString::null );
    QWhatsThis::add( label11_2, QString::null );
    textLabelRangeLast->setText( tr( "..." ) );
    label11_3->setText( trUtf8( "\xe2\x89\xa4" ) );
    QToolTip::add( label11_3, QString::null );
    QWhatsThis::add( label11_3, QString::null );
    textLabelRangeLastLimit->setText( tr( "..." ) );
    QToolTip::add( textLabelRangeLastLimit, QString::null );
    QWhatsThis::add( textLabelRangeLastLimit, QString::null );
    checkBoxWeightSim->setTitle( tr( "Weight" ) );
    checkBoxResoSim->setTitle( tr( "Resolution" ) );
    checkBoxPolySim->setTitle( tr( "Polydispersity" ) );
    tabWidgetGenResults->changeTab( tab_3, tr( "Simulate Curve" ) );
    pushButtonNewTabRes->setText( tr( "Results -> New Table (row)" ) );
    pushButtonNewTabResCol->setText( tr( "Results -> New Table (col)" ) );
    pushButtonresToLogWindow->setText( tr( "Results ->  to Log-Window" ) );
    pushButtonresToLogWindowOne->setText( tr( "Results ->  to Log-Window (one line)" ) );
    pushButtonresToActiveGraph->setText( tr( "Results ->  Active Graph" ) );
    pushButtonFitCurveDelete->setText( QString::null );
    pushButtonFitCurveDelete->setTextLabel( tr( "\"fitCurve-...\"" ) );
    pushButtonSimulatedCurveDelete->setText( QString::null );
    pushButtonSimulatedCurveDelete->setTextLabel( tr( "\"simulatedCurve-...\"" ) );
    pushButtonGlobalDelete->setText( QString::null );
    pushButtonGlobalDelete->setTextLabel( tr( "\"...-global-...\"" ) );
    tabWidgetGenResults->changeTab( tab_4, tr( "Generate Tables" ) );
    textLabelPattern->setText( tr( "Pattern" ) );
    lineEditPattern->setText( tr( "*" ) );
    pushButtonPattern->setText( tr( "Select by Pattern" ) );
    pushButtonSelectFromTable->setText( tr( "Select from Table" ) );
    tableMultiFit->verticalHeader()->setLabel( 0, tr( "All" ) );
    textLabelfromQ->setText( tr( "Q[min]=" ) );
    lineEditFromQ->setText( tr( "0" ) );
    textLabelToQ->setText( tr( "Q[max]=" ) );
    lineEditToQ->setText( tr( "1" ) );
    textLabelfromQ_2->setText( tr( "Table Code::" ) );
    pushButtonSetBySetFit->setText( tr( "Fit" ) );
    pushButtonSimulateMulti->setText( tr( "Simulate" ) );
    pushButtonDeleteCurves->setText( tr( ">>>  Delete" ) );
    tabWidgetGenResults->changeTab( TabPage_4, tr( "Batch-Fit [Set-by-Set]" ) );
    QToolTip::add( comboBoxFunction, tr( "Select(ed) Function" ) );
    QWhatsThis::add( comboBoxFunction, tr( "Select(ed) Function" ) );
    comboBoxPolyFunction_2->clear();
    comboBoxPolyFunction_2->insertItem( tr( "Poly: Gauss" ) );
    comboBoxPolyFunction_2->insertItem( tr( "Poly: Schultz-Zimm" ) );
    comboBoxPolyFunction_2->insertItem( tr( "Poly: Gamma" ) );
    comboBoxPolyFunction_2->insertItem( tr( "Poly: Log-Normal" ) );
    comboBoxPolyFunction_2->insertItem( tr( "Poly: Uniform" ) );
    comboBoxPolyFunction_2->insertItem( tr( "Poly: Triangular" ) );
    QToolTip::add( comboBoxPolyFunction_2, tr( "Select type of polydistersidy distribution" ) );
    QWhatsThis::add( comboBoxPolyFunction_2, tr( "Select type of polydistersidy distribution" ) );
    textLabelInfoSAS->setText( tr( "Fit Curve [1D fit]" ) );
    textLabelInfo_2->setText( tr( "v.10-31.03.2016" ) );
    textLabelInfo_2_2->setText( tr( "Vitaliy Pipich @ JCNS" ) );
    pushButtonHelp->setText( QString::null );
}

