# include <stdio.h>
# include <problem.h>
# include <genmin.h>
# include <math.h>
#if (_MSC_VER != 1600)
# include <unistd.h>
# include <sys/times.h>
#else
# include <time.h>
#endif
# include <get_options.h>

/*	This program executes the algorithm for the specified 
 *	problem. The linking with the objective function 
 *	is performed with the tool make_genmin.
 * */


/*	Some external declarations. The directive extern "C" must
 *	be used in order to avoid the name magling of the C++ 
 *	compilers.
 * */
extern "C"
{
	extern int getdimension();
	extern void getleftmargin(double *x);
	extern void getrightmargin(double *x);
	extern double funmin(double *x);
	extern void   granal(double *x,double *g);
}

/*	Some helping variables.
 * */
int problem_dimension;
double	*tempx,*tempg;

/*	This class inherites the class Problem. This is performed
 *	in order to user counters for the function and the gradient
 *	evaluations.
 * */
class MyProblem :public Problem
{
	public:
		int fevals,gevals;
		MyProblem(int N);
		virtual double funmin(Data x);
		virtual void   granal(Data x,Data &g);
};

/*	The constructor of the class.
 *	Initialization of the counters to 0.
 * */
MyProblem::MyProblem(int N)
	:Problem(N)
{
	fevals = 0;
	gevals = 0;
}


/*	Return the function value evaluated at the point x
 *	and increment the function evaluation counter.
 * */
double	MyProblem::funmin(Data x)
{
	++fevals;
	for(int i=0;i<problem_dimension;i++) tempx[i]=x[i];
	return ::funmin(tempx);
}

/*	Evaluate the gradient at the point x. The gradient
 *	is returned to the vector g. Also, the function 
 *	increments the gradient evaluation counter.
 * */
void	MyProblem::granal(Data x,Data &g)
{
	++gevals;
	for(int i=0;i<problem_dimension;i++) tempx[i]=x[i];
	::granal(tempx,tempg);
	for(int i=0;i<problem_dimension;i++) g[i]=tempg[i];
}

/*	Load the objective function, run the optimized and 
 *	print the statistics from the run.
 * */
int main(int argc, char **argv)
{
	parse_cmd_line(argc,argv);
	srand(random_seed);
	srand48(random_seed);
	problem_dimension=getdimension();
	tempx=new double[problem_dimension];
	tempg=new double[problem_dimension];
	MyProblem myproblem(problem_dimension);
	double *l,*r;
	l=new double[problem_dimension];
	r=new double[problem_dimension];
	getleftmargin(l);
	getrightmargin(r);
	Data L,R;
	L.resize(problem_dimension);
	R.resize(problem_dimension);
	for(int i=0;i<problem_dimension;i++)
	{
		L[i]=l[i];
		R[i]=r[i];
	}
	myproblem.setLeftMargin(L);
	myproblem.setRightMargin(R);
	delete[] l;
	delete[] r;
	GenMin opt(&myproblem);
	opt.Solve();
	Data x;
	double y;
	x.resize(problem_dimension);
	opt.getMinimum(x,y);
	printf("X*= [");
	for(int i=0;i<problem_dimension;i++)
	{
		printf(" %lg ",x[i]);	
	}
	printf("] Y*=%lg\n",y);
	printf("FUNCTION CALLS =%6d\tGRADIENT CALLS=%6d\n",
			myproblem.fevals,myproblem.gevals);
	delete[] tempx;
	delete[] tempg;
	return 0;
}
