# include <genmin.h>
# include <tolmin.h>
# include <math.h>
# include <rlsprogram.h>
# include <multi_population.h>
# include <get_options.h>
# include <stdio.h>
#include <qprogressdialog.h>
#include <qstring.h> 

/*	This class implements the main algorithm.
 *	CLASS VARIABLES
 *	======================================================================
 *	problem: A pointer to the objective function to be minimized.
 *	bestx:   A vector that will hold the global minimum located.
 *	besty:   The value of objective function at the point bestx.
 * */


/*	The constructor of the class.
 * */
GenMin::GenMin(Problem *p)
{
	problem = p;
	bestx.resize(p->getDimension());
	besty=1e+100;
}

/*	Evaluate the local search procedure at point x.
 *	The function returns the local minimum obtained by 
 *	the local search procedure. The local search procedure
 *	used is a BFGS variant due to Powell. The maximum number
 *	of iterations is 2001.
 * */
double	GenMin::localSearch(DataG &x)
{
	MinInfo Info;
	Info.p=problem;
	Info.iters=2001;
	return tolmin(x,Info);
}

double GenMin::localSearchGSL(DataG &x,int prec, int d_max_iterations, double d_tolerance, double absError )
{
    
    int dimension = problem->getDimension();
//    double d_tolerance=0;
//    double absError=0;
//    int d_max_iterations=100;
    
    
    //+++ fln integrate in h-file
    int N=problem->fln.n;
    
    //+++
    gsl_vector *xx=gsl_vector_alloc(dimension);
    for(int i=0;i<dimension;i++) gsl_vector_set(xx,i,round2prec(x[i],prec));
    
    //+++ ok
    const gsl_multifit_fdfsolver_type *Tln = gsl_multifit_fdfsolver_lmder;
    
    //+++ ok
    gsl_multifit_fdfsolver *sln = gsl_multifit_fdfsolver_alloc(Tln, N,dimension);
    
    //+++ ok
    int status=gsl_multifit_fdfsolver_set(sln, &problem->fln, xx);
    
    
    int iter=0;
    
    double chi2, chi2prev=1e308;

    
    bool iterContinue=true;
    do
    {
        //+++ iteration
        status = gsl_multifit_fdfsolver_iterate (sln);
        //+++ chi2 calculation
        if (problem->YN2D()) chi2=function_dm2D(sln->x,problem->fln.params);
        else if (problem->sansSupportYN()) chi2=function_dmPoly(sln->x,problem->fln.params);
        else chi2=function_dm(sln->x,problem->fln.params);
        //+++ terminal output
//        printf("# (local) \t\t%4d[100]\tchi2\t%20.10lg\t[",iter+1,chi2/(N-dimension));
//        for(int i=0;i<GSL_MIN(dimension,5);i++) printf("%20.10lg  ",gsl_vector_get(sln->x,i));
//        printf("\t...\t]\n");
        iter++;
        //+++ fit control
        if (chi2==0.0) break;
        if (fabs((chi2prev-chi2)/chi2)<d_tolerance) break;
        if (fabs(chi2prev-chi2) < absError) break;
        chi2prev=chi2;
    }
    while (iter < d_max_iterations);
    
    //+++
    for(int i=0;i<dimension;i++) x[i]= round2prec(gsl_vector_get(sln->x,i),prec);
    
    //+++
    gsl_multifit_fdfsolver_free (sln);
    gsl_vector_free(xx);
    
    return chi2;
}

/*	
 *	The proposed algorithm.
 * */
void	GenMin::Solve()
{
	/*	
	 *	The initialization step of the algorithm.
	 * */
    
    
    //+++ new: 2016 DoF
    int dof=problem->dof;
    int prec=6;
    
	int genome_length=5;
	int dimension = problem->getDimension();
	RlsProgram *program = new RlsProgram(problem);
	MultiPopulation pop(genome_count,genome_length,problem->getDimension(),program);
	pop.setSelectionRate(selection_rate);
	pop.setMutationRate(mutation_rate);
	vector<int> genome;
	genome.resize(pop.getSize());
	DataG trialx;
	trialx.resize(bestx.size());
    
	double trialy=1e+100;
	double oldbest=1e+100;
	double xx1=0.0;
	double xx2=0.0;
	double stopat=0.0;
	/*
	 *	The main loop of the algorithm.
	 * */
	QString genMinMessage;
    genMinMessage = "\tStarted | Loaded | Fitting > Iterations\n\n";
    genMinMessage+= "\t[GenMin] Genetic Algorithm\n\n";

/*
	genMinMessage+="Genetic Algorithm info:\n\n"; 
	genMinMessage+="Genetic Algorithm code was taken from paper:\n\n";
	genMinMessage+="I.G. Tsoulos, I.E. Lagaris,\n"; 
	genMinMessage+="GenMin: An enhanced genetic algorithm for global optimization,\n"; 
	genMinMessage+="Computer Physics Communications, 178(11), 2008, pp. 843-851,\n";
	genMinMessage+="DOI: 10.1016/j.cpc.2008.01.040.\n\n";
	genMinMessage+="Authors would be appreciated if you give a citation or an acknowledgement in case of using Genetic Algorithm here.\n\n";
*/
	QProgressDialog *progress;
	progress=new QProgressDialog( genMinMessage+"\n\n\n", "Abort FIT", generations,
				      0, "Maximal Number of Generations"+QString::number(generations)+". Progress:", TRUE );

	progress->setProgress( 1 ); 
	//+++ Start +++  1
	QString plusStr;
	for(int iters=2;iters<=generations;iters++)
	{

		/*	
		 *	This is the Genetic operations step of the algorithm.
		 * */
		pop.nextGeneration();
		double f=pop.getBestFitness();
		int newmin=0;
		double v;
		/*	
		 *	This is the Local Search step of the algorithm.
		 *	A decision is to be made about perfoming a local search.
		 * */
		if( fabs(f-oldbest)>1e-5 )
		{
			oldbest = f;
			genome=pop.getBestGenome();
			program->getX(genome,trialx);
            for(int i=0;i<dimension;i++)
            {
            trialx[i]=round2prec(trialx[i], prec);
                
            if (trialx[i]<problem->lmargin[i]) trialx[i]=problem->lmargin[i];
            else if (trialx[i]>problem->rmargin[i]) trialx[i]=problem->rmargin[i];
            }
            
            /*	local search procedure
			 * */
			
            trialy=localSearchGSL(trialx,6,5,0,0);
            trialy=localSearch(trialx);
            trialy=localSearchGSL(trialx,6,100,1e-3,1e-6);

            trialy=round2prec(trialy,prec);
			
            if ( trialy<besty && fabs(trialy-besty)>1e-7 )
			{
				newmin=1;
				besty=trialy;
				bestx=trialx;
			}
		}
		/*
		 *	This is the Termination Check step.
		 * */

		/*	Calculate the variance of the best values.
		 * */
		v=fabs(besty);
		v=besty;
		xx1+=(v);
		xx2+=(v)*(v);
		double variance=xx2/iters-(xx1/iters)*(xx1/iters);

		variance = fabs(variance);
		if(newmin || stopat<1e-7)
        {
			stopat=variance/2.0;
		}
		/*	Print some output to the screen.
		 * */
        
        
        printf("# (global) \t\t%4d[<%4d]\tvariance\t%10.5lg [<%10.5lg]\tchi^2\t%10.5lg",iters-1,generations,variance/dof,stopat/dof, besty/dof);
        printf("\t[");
        for(int i=0;i<GSL_MIN(dimension,5);i++) printf("%10.5lg  ",bestx[i]);
        printf("\t...\t]\n");
        
        plusStr = "#\t\t\t\t\t\t\t\t Stopping Criterion \t \t \t Chi^2/dof\n";
        plusStr = plusStr + QString::number(iters-1)+"[<"+QString::number(generations)+"]\t\t "+QString::number(variance/dof)+" [<"+QString::number(stopat/dof)+"]\t "+QString::number(besty/dof)+"\n\n";
        
		progress->setProgress( iters );
        progress->setLabelText(genMinMessage+plusStr);
		

		/*	If the stopping rule holds, then terminate
		 * */
		if(variance>1e-8 && variance <=stopat ) break;
		if(variance<1e-10 && iters>5) break;

		if ( progress->wasCanceled() ) 
		{
		    progress->close();
		    break;
		}
	}
        progress->close();

	delete program;
}

/*	Return the global minimum obtained by the proposed algorithm.
 *	The array x is the located global minimum and the variable y
 *	is the value of the objective function at x.
 * */
void	GenMin::getMinimum(DataG &x,double &y)
{
	x = bestx;
	y = besty;
}

/*	The destructor of the class.
 * */
GenMin::~GenMin()
{
}
