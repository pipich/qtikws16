double	GenMin::localSearchGSL(DataG &x)
{
    double d_tolerance=0.0001;
    int d_max_iterations=100;
    int prec=6;
    
    //+++ fln integrate in h-file
    int N=fln.n;
    
    //+++
    gsl_vector *xx=gsl_vector_alloc(dimension);
    for(int i=0;i<dimension;i++) gsl_vector_set(xx,i,round2prec(x[i],prec));

    //+++ ok
    const gsl_multifit_fdfsolver_type *Tln = gsl_multifit_fdfsolver_lmder;

    //+++ ok
    gsl_multifit_fdfsolver *sln = gsl_multifit_fdfsolver_alloc(Tln, N,dimension);

    //+++ ok
    status=gsl_multifit_fdfsolver_set(sln, &fln, xx);

    //+++
    //if (status != 0) {...};

    int iter=0;
    //+++
    double ssize=0;
    double tmp;
    gsl_vector *vec=gsl_vector_alloc(dimension);
    double chi2;

    do
    {
		if (iter>0)
		{
		    ssize=0;
            for (int vvv=0;vvv<np;vvv++)
            {
                tmp  = fabs(gsl_vector_get(sln->dx, vvv));
                tmp -= d_tolerance * fabs( gsl_vector_get(sln->x, vvv));
                if (tmp>ssize) ssize=tmp;
            }
		    
            chi2=fln.f(sln->x, fln.params);
		
            //printf("#\t\t%4d[100]\tvariance\t%10.5lg [<%10.5lg]\tchi^2\t%10.5lg",iters-1,generations,variance/dof,stopat/dof, besty/dof);
        }
        iter++;
        
		status = gsl_multifit_test_delta (sln->dx, sln->x, absError, d_tolerance);
        if (chi2==0.0) break;
    }
    while (status == GSL_CONTINUE && iter < d_max_iterations);

    //+++
    for(int i=0;i<dimension;i++) x[i]= round2prec(gsl_vector_get(xx,i),prec);
    
    //+++
    gsl_multifit_fdfsolver_free (sln);
    gsl_vector_free(vec);
    gsl_vector_free(xx);
    
    return chi2;
}