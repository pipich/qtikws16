# ifndef __FC_GETOPTIONS__H
# define __FC_GETOPTIONS__H
/*	
 *	The command line options of the proposed software.
 * */
extern	int 	genome_count;
extern	int	generations;
extern  double	selection_rate;
extern 	double	mutation_rate;
extern	int	random_seed;
//extern char	train_file[1024];
//extern void	parse_cmd_line(int argc,char **argv);
# endif
