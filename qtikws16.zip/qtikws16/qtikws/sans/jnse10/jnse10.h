/****************************************************************************
** Form interface generated from reading ui file '..\qtiKWS\sans\jnse10\jnse10.ui'
**
** Created: Do 14. Sep 01:52:13 2017
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.4   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef JNSE10_H
#define JNSE10_H

#include <qvariant.h>
#include <qwidget.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QTabWidget;
class QFrame;
class QPushButton;
class QLineEdit;
class QGroupBox;
class QComboBox;
class QButtonGroup;
class QSpinBox;

class jnse10 : public QWidget
{
    Q_OBJECT

public:
    jnse10( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~jnse10();

    QLabel* textLabelInfo;
    QTabWidget* sansTab;
    QWidget* TabPage;
    QFrame* frameRAD;
    QPushButton* pushButtonRADpath;
    QLineEdit* lineEditPathDAT;
    QLabel* textLabel1;
    QWidget* TabPage_2;
    QPushButton* pushButtonMakeList;
    QLineEdit* lineEditFileName;
    QPushButton* pushButtonCOHINCOH;
    QWidget* TabPage_3;
    QGroupBox* groupBox1;
    QComboBox* comboBoxHeaderTables;
    QButtonGroup* buttonGroupRemove;
    QLabel* textLabel6;
    QSpinBox* spinBoxFrom;
    QLabel* textLabel6_2;
    QSpinBox* spinBoxTo;
    QPushButton* pushButtonStartNSEfit;
    QLabel* textLabelInfoSAS;
    QLabel* textLabelInfo_2_2;
    QLabel* textLabelInfo_2;

public slots:
    virtual void readSettings();
    virtual void writeSettings();
    virtual void buttomRADpath();
    virtual void slotMakeList();
    virtual void findHeaderTables();
    virtual void headerTableSeleted();
    virtual void nseFit();
    virtual void tabSelected();
    virtual void forceReadSettings();
    virtual void slotMakeListCohIncoh();

signals:
    void signalJnse10Fit();

protected:
    QVBoxLayout* jnse10Layout;
    QSpacerItem* spacer39;
    QVBoxLayout* layout69;
    QVBoxLayout* TabPageLayout;
    QSpacerItem* spacer48;
    QVBoxLayout* frameRADLayout;
    QHBoxLayout* layout72;
    QSpacerItem* spacer46;
    QSpacerItem* spacer47;
    QVBoxLayout* TabPageLayout_2;
    QSpacerItem* spacer45;
    QVBoxLayout* TabPageLayout_3;
    QSpacerItem* spacer44;
    QVBoxLayout* groupBox1Layout;
    QHBoxLayout* buttonGroupRemoveLayout;
    QHBoxLayout* layout68;

protected slots:
    virtual void languageChange();

private:
    void init();
    void destroy();

};

#endif // JNSE10_H
