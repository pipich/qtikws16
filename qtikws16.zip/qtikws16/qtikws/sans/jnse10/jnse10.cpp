/****************************************************************************
** Form implementation generated from reading ui file '../qtiKWS/sans/jnse10/jnse10.ui'
**
** Created: Thu Sep 14 02:32:07 2017
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "jnse10.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qtabwidget.h>
#include <qframe.h>
#include <qlineedit.h>
#include <qgroupbox.h>
#include <qcombobox.h>
#include <qbuttongroup.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include "jnse10.ui.h"

/*
 *  Constructs a jnse10 as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
jnse10::jnse10( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "jnse10" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, 0, 0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 510, 300 ) );
    setMaximumSize( QSize( 5100, 3000 ) );
    setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QFont f( font() );
    setFont( f ); 
    jnse10Layout = new QVBoxLayout( this, 11, 6, "jnse10Layout"); 

    layout69 = new QVBoxLayout( 0, 0, 6, "layout69"); 

    textLabelInfo = new QLabel( this, "textLabelInfo" );
    textLabelInfo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo->setMinimumSize( QSize( 0, 20 ) );
    textLabelInfo->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfo->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    textLabelInfo->setFrameShape( QLabel::Box );
    textLabelInfo->setAlignment( int( QLabel::AlignCenter ) );
    layout69->addWidget( textLabelInfo );

    sansTab = new QTabWidget( this, "sansTab" );
    sansTab->setEnabled( TRUE );
    sansTab->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, sansTab->sizePolicy().hasHeightForWidth() ) );
    sansTab->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 63, 75, 138) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    sansTab->setPalette( pal );

    TabPage = new QWidget( sansTab, "TabPage" );
    TabPageLayout = new QVBoxLayout( TabPage, 11, 6, "TabPageLayout"); 

    frameRAD = new QFrame( TabPage, "frameRAD" );
    frameRAD->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, frameRAD->sizePolicy().hasHeightForWidth() ) );
    frameRAD->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 63, 75, 138) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    frameRAD->setPalette( pal );
    frameRAD->setBackgroundOrigin( QFrame::AncestorOrigin );
    frameRAD->setFrameShape( QFrame::GroupBoxPanel );
    frameRAD->setFrameShadow( QFrame::Sunken );
    frameRADLayout = new QVBoxLayout( frameRAD, 10, 10, "frameRADLayout"); 

    pushButtonRADpath = new QPushButton( frameRAD, "pushButtonRADpath" );
    pushButtonRADpath->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonRADpath->sizePolicy().hasHeightForWidth() ) );
    pushButtonRADpath->setMinimumSize( QSize( 0, 0 ) );
    pushButtonRADpath->setMaximumSize( QSize( 3800, 40 ) );
    QFont pushButtonRADpath_font(  pushButtonRADpath->font() );
    pushButtonRADpath->setFont( pushButtonRADpath_font ); 
    frameRADLayout->addWidget( pushButtonRADpath );

    lineEditPathDAT = new QLineEdit( frameRAD, "lineEditPathDAT" );
    lineEditPathDAT->setEnabled( TRUE );
    lineEditPathDAT->setMinimumSize( QSize( 200, 15 ) );
    lineEditPathDAT->setMaximumSize( QSize( 3800, 25 ) );
    lineEditPathDAT->setPaletteForegroundColor( QColor( 166, 163, 157 ) );
    lineEditPathDAT->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QFont lineEditPathDAT_font(  lineEditPathDAT->font() );
    lineEditPathDAT->setFont( lineEditPathDAT_font ); 
    lineEditPathDAT->setFrameShadow( QLineEdit::Sunken );
    lineEditPathDAT->setLineWidth( 1 );
    lineEditPathDAT->setReadOnly( TRUE );
    frameRADLayout->addWidget( lineEditPathDAT );
    TabPageLayout->addWidget( frameRAD );

    layout72 = new QHBoxLayout( 0, 0, 6, "layout72"); 
    spacer46 = new QSpacerItem( 111, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout72->addItem( spacer46 );

    textLabel1 = new QLabel( TabPage, "textLabel1" );
    textLabel1->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabel1_font(  textLabel1->font() );
    textLabel1_font.setPointSize( 14 );
    textLabel1->setFont( textLabel1_font ); 
    layout72->addWidget( textLabel1 );
    spacer47 = new QSpacerItem( 161, 21, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout72->addItem( spacer47 );
    TabPageLayout->addLayout( layout72 );
    spacer48 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    TabPageLayout->addItem( spacer48 );
    sansTab->insertTab( TabPage, QString::fromLatin1("") );

    TabPage_2 = new QWidget( sansTab, "TabPage_2" );
    TabPageLayout_2 = new QVBoxLayout( TabPage_2, 11, 6, "TabPageLayout_2"); 

    pushButtonMakeList = new QPushButton( TabPage_2, "pushButtonMakeList" );
    pushButtonMakeList->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonMakeList->sizePolicy().hasHeightForWidth() ) );
    pushButtonMakeList->setMaximumSize( QSize( 4500, 40 ) );
    QFont pushButtonMakeList_font(  pushButtonMakeList->font() );
    pushButtonMakeList->setFont( pushButtonMakeList_font ); 
    TabPageLayout_2->addWidget( pushButtonMakeList );

    lineEditFileName = new QLineEdit( TabPage_2, "lineEditFileName" );
    lineEditFileName->setEnabled( FALSE );
    lineEditFileName->setMinimumSize( QSize( 150, 25 ) );
    lineEditFileName->setMaximumSize( QSize( 32767, 25 ) );
    lineEditFileName->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    lineEditFileName->setPalette( pal );
    QFont lineEditFileName_font(  lineEditFileName->font() );
    lineEditFileName->setFont( lineEditFileName_font ); 
    lineEditFileName->setFrameShape( QLineEdit::LineEditPanel );
    lineEditFileName->setFrameShadow( QLineEdit::Sunken );
    lineEditFileName->setLineWidth( 1 );
    TabPageLayout_2->addWidget( lineEditFileName );

    pushButtonCOHINCOH = new QPushButton( TabPage_2, "pushButtonCOHINCOH" );
    pushButtonCOHINCOH->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonCOHINCOH->sizePolicy().hasHeightForWidth() ) );
    pushButtonCOHINCOH->setMaximumSize( QSize( 4500, 40 ) );
    QFont pushButtonCOHINCOH_font(  pushButtonCOHINCOH->font() );
    pushButtonCOHINCOH->setFont( pushButtonCOHINCOH_font ); 
    TabPageLayout_2->addWidget( pushButtonCOHINCOH );
    spacer45 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    TabPageLayout_2->addItem( spacer45 );
    sansTab->insertTab( TabPage_2, QString::fromLatin1("") );

    TabPage_3 = new QWidget( sansTab, "TabPage_3" );
    TabPageLayout_3 = new QVBoxLayout( TabPage_3, 11, 18, "TabPageLayout_3"); 

    groupBox1 = new QGroupBox( TabPage_3, "groupBox1" );
    groupBox1->setColumnLayout(0, Qt::Vertical );
    groupBox1->layout()->setSpacing( 6 );
    groupBox1->layout()->setMargin( 11 );
    groupBox1Layout = new QVBoxLayout( groupBox1->layout() );
    groupBox1Layout->setAlignment( Qt::AlignTop );

    comboBoxHeaderTables = new QComboBox( FALSE, groupBox1, "comboBoxHeaderTables" );
    groupBox1Layout->addWidget( comboBoxHeaderTables );
    TabPageLayout_3->addWidget( groupBox1 );

    buttonGroupRemove = new QButtonGroup( TabPage_3, "buttonGroupRemove" );
    buttonGroupRemove->setEnabled( TRUE );
    buttonGroupRemove->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, buttonGroupRemove->sizePolicy().hasHeightForWidth() ) );
    buttonGroupRemove->setColumnLayout(0, Qt::Vertical );
    buttonGroupRemove->layout()->setSpacing( 6 );
    buttonGroupRemove->layout()->setMargin( 11 );
    buttonGroupRemoveLayout = new QHBoxLayout( buttonGroupRemove->layout() );
    buttonGroupRemoveLayout->setAlignment( Qt::AlignTop );

    textLabel6 = new QLabel( buttonGroupRemove, "textLabel6" );
    textLabel6->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel6->sizePolicy().hasHeightForWidth() ) );
    buttonGroupRemoveLayout->addWidget( textLabel6 );

    spinBoxFrom = new QSpinBox( buttonGroupRemove, "spinBoxFrom" );
    spinBoxFrom->setMaxValue( 1 );
    spinBoxFrom->setMinValue( 1 );
    spinBoxFrom->setValue( 1 );
    buttonGroupRemoveLayout->addWidget( spinBoxFrom );

    textLabel6_2 = new QLabel( buttonGroupRemove, "textLabel6_2" );
    textLabel6_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel6_2->sizePolicy().hasHeightForWidth() ) );
    buttonGroupRemoveLayout->addWidget( textLabel6_2 );

    spinBoxTo = new QSpinBox( buttonGroupRemove, "spinBoxTo" );
    spinBoxTo->setMaxValue( 1 );
    spinBoxTo->setMinValue( 1 );
    spinBoxTo->setValue( 1 );
    buttonGroupRemoveLayout->addWidget( spinBoxTo );
    TabPageLayout_3->addWidget( buttonGroupRemove );

    pushButtonStartNSEfit = new QPushButton( TabPage_3, "pushButtonStartNSEfit" );
    TabPageLayout_3->addWidget( pushButtonStartNSEfit );
    spacer44 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    TabPageLayout_3->addItem( spacer44 );
    sansTab->insertTab( TabPage_3, QString::fromLatin1("") );
    layout69->addWidget( sansTab );

    layout68 = new QHBoxLayout( 0, 0, 6, "layout68"); 

    textLabelInfoSAS = new QLabel( this, "textLabelInfoSAS" );
    textLabelInfoSAS->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfoSAS->sizePolicy().hasHeightForWidth() ) );
    textLabelInfoSAS->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfoSAS->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfoSAS->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    textLabelInfoSAS->setFrameShape( QLabel::Box );
    textLabelInfoSAS->setTextFormat( QLabel::RichText );
    textLabelInfoSAS->setAlignment( int( QLabel::WordBreak | QLabel::AlignBottom | QLabel::AlignHCenter ) );
    textLabelInfoSAS->setIndent( 0 );
    layout68->addWidget( textLabelInfoSAS );

    textLabelInfo_2_2 = new QLabel( this, "textLabelInfo_2_2" );
    textLabelInfo_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo_2_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfo_2_2->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    textLabelInfo_2_2->setFrameShape( QLabel::Box );
    textLabelInfo_2_2->setAlignment( int( QLabel::AlignCenter ) );
    layout68->addWidget( textLabelInfo_2_2 );

    textLabelInfo_2 = new QLabel( this, "textLabelInfo_2" );
    textLabelInfo_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo_2->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfo_2->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    textLabelInfo_2->setFrameShape( QLabel::Box );
    textLabelInfo_2->setAlignment( int( QLabel::AlignCenter ) );
    layout68->addWidget( textLabelInfo_2 );
    layout69->addLayout( layout68 );
    jnse10Layout->addLayout( layout69 );
    spacer39 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    jnse10Layout->addItem( spacer39 );
    languageChange();
    resize( QSize(917, 886).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
jnse10::~jnse10()
{
    destroy();
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void jnse10::languageChange()
{
    setCaption( tr( "QtiKWS::JNSE" ) );
    textLabelInfo->setText( tr( "Path >>> Set Location of JNSE-Files <<<" ) );
    pushButtonRADpath->setText( tr( "Set Path to ASCII data" ) );
    lineEditPathDAT->setText( tr( "home" ) );
    textLabel1->setText( tr( "J-NSE" ) );
    sansTab->changeTab( TabPage, tr( "Path" ) );
    pushButtonMakeList->setText( tr( "JNSE :: Import of \"b\"-files" ) );
    lineEditFileName->setText( tr( "info" ) );
    pushButtonCOHINCOH->setText( tr( "JNSE :: Import of \"con/inc\" - files" ) );
    sansTab->changeTab( TabPage_2, tr( "Import" ) );
    groupBox1->setTitle( QString::null );
    comboBoxHeaderTables->clear();
    comboBoxHeaderTables->insertItem( tr( "Select Table of Headers" ) );
    buttonGroupRemove->setTitle( tr( "Select Row-range" ) );
    textLabel6->setText( tr( "From:" ) );
    textLabel6_2->setText( tr( "To:" ) );
    pushButtonStartNSEfit->setText( tr( "Start Multi-Fit" ) );
    sansTab->changeTab( TabPage_3, tr( "Multi-Fitting" ) );
    textLabelInfoSAS->setText( tr( "Neutron-Spin-Echo Tools" ) );
    textLabelInfo_2_2->setText( tr( "v.10-29.01.14" ) );
    textLabelInfo_2->setText( tr( "Vitaliy Pipich @ JCNS" ) );
}

