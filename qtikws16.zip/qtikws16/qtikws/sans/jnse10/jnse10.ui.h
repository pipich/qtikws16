/***************************************************************************
 File                 : jnse10.ui.h
 Project              : QtiKWS
 --------------------------------------------------------------------
 Copyright            : (C) 2006-2013 by Vitaliy Pipich
 Email (use @ for *)  : v.pipich*gmail.com
 Description          : JNSE Data Reading Interface
 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *  This program is free software; you can redistribute it and/or modify   *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation; either version 2 of the License, or      *
 *  (at your option) any later version.                                    *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the Free Software           *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor,                    *
 *   Boston, MA  02110-1301  USA                                           *
 *                                                                         *
 ***************************************************************************/

#include "../qtiKWS/src/application.h"
#include "../qtiKWS/src/fileDialogs.h"
#include "../standart-functions/standartFunctions.h"

#include <gsl/gsl_math.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h> 
#include <math.h> 
#include <qdir.h>
#include <qvalidator.h> 
#include <qmessagebox.h>
#include <qpainter.h> 
#include <qfiledialog.h> 
#include <qtextstream.h> 
#include <qaction.h> 
#include <qprocess.h> 

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <qworkspace.h>
#include <qfiledialog.h>
#include <qinputdialog.h>

#include <qmessagebox.h>
#include <qapplication.h>
#include <qdockwindow.h>
#include <qsettings.h>

#include <iostream>

//+++   INIT   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void jnse10::init()
{
    // signals and slots connections
    connect( pushButtonRADpath, SIGNAL( clicked() ), this, SLOT( buttomRADpath() ) );
    connect( pushButtonMakeList, SIGNAL( clicked() ), this, SLOT( slotMakeList() ) );
    connect( pushButtonCOHINCOH, SIGNAL( clicked() ), this, SLOT( slotMakeListCohIncoh() ) );
    
    connect( comboBoxHeaderTables, SIGNAL( activated(int) ), this, SLOT( headerTableSeleted() ) );
    connect( pushButtonStartNSEfit, SIGNAL( clicked() ), this, SLOT( nseFit() ) );
    connect( sansTab, SIGNAL( selected(const QString&) ), this, SLOT( tabSelected() ) );
    connect( lineEditPathDAT, SIGNAL( textChanged(const QString&) ), this, SLOT( forceReadSettings() ) );
    
    readSettings();
    
    lineEditFileName->hide();
}

//*******************************************
//+++ Destroy
//*******************************************
void jnse10::destroy()
{    
    writeSettings();
}

// ************************************************************************************
// ************************************************************************************
//            Settings Tab
// ************************************************************************************
// ************************************************************************************


//*******************************************
//+++  Read settings at init()
//*******************************************
void jnse10::readSettings()
{
#ifdef Q_OS_MAC // Mac 
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
    
    settings.setPath("JCNS", "QtiKWS", QSettings::User);
    
    bool ok;
    QString ss;
    
    settings.beginGroup("/JNSE");
    //
    ss=settings.readEntry("/lineEditPathDAT",0,&ok); if (ok) lineEditPathDAT->setText(ss);
    ss=settings.readEntry("/lineEditFileName",0,&ok); if (ok) lineEditFileName->setText(ss);
    
    settings.endGroup();
    
    
}

//*******************************************
//+++  Write settings at destroy()
//*******************************************
void jnse10::writeSettings()
{
#ifdef Q_OS_MAC // Mac 
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
    
    settings.setPath("JCNS", "QtiKWS", QSettings::User);
    //
    settings.beginGroup("/JNSE");
    //
    settings.writeEntry("/lineEditPathDAT",  lineEditPathDAT->text());
    settings.writeEntry("/lineEditFileName",  lineEditFileName->text());    
    //
    settings.endGroup();
}

//+++  Options: Buttons: DAT & RAD direcrories  ++++++++++++++++++++
void jnse10::buttomRADpath()
{
    QString pppath=lineEditPathDAT->text();
    
    if (pppath=="home") pppath = QDir::home().path();
    
    QString s = QFileDialog::getExistingDirectory(
	    pppath, 
	    this,
	    "get data directory"
	    "Choose a directory");
    if (s)
    {
	lineEditPathDAT->setText(s);
    }
}

//++++++SLOT::Make Table+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void jnse10::slotMakeList()
{    
    app(this)->changeFolder("JNSE :: b files");
    
    QString TableName	= lineEditFileName->text();
    QString DatDir	=lineEditPathDAT->text();
    
    bool ok;
    TableName = QInputDialog::getText(
	    "Table's Generation: all header info", "Enter name of Table:", QLineEdit::Normal,
	    TableName, &ok, this );
    if ( !ok ||  TableName.isEmpty() ) 
    {
	return;
    }
    
    
    int i;
    
    //+++ create table
    Table* tableDat;
    
    //+++ select files
    QFileDialog *fd = new QFileDialog(DatDir,"Make Yours Filter (*.YOURS)",this,"JNSE - File Import");
    fd->setDir(DatDir);
    fd->setMode( QFileDialog::ExistingFiles );
    fd->setCaption(tr("QtiKWS - File Import"));
    fd->addFilter("JNSE - b files (*)");
    
    if (!fd->exec() == QDialog::Accepted ) return;
    
    lineEditFileName->setText(TableName);
    
    
    QStringList selectedDat=fd->selectedFiles();
    int filesNumber= selectedDat.count();
    
    int startRaw=0;
    
    
    bool exist=false;
    QWidgetList* tableListAll=app(this)->tableList();
    //+++
    for (i=0;i<(int)tableListAll->count();i++)  if (tableListAll->at(i) && tableListAll->at(i)->name()==TableName) exist=true;
    
    //+++
    if (exist)
    {
	for (i=0;i<(int)tableListAll->count();i++)
	{
	    if (tableListAll->at(i) && tableListAll->at(i)->name()==TableName)
	    {
		tableDat=(Table*)tableListAll->at(i);
		
	    }
	}
	
	
	if (tableDat->numCols()<19) 
	{
	    QMessageBox::critical( 0, "QtiKWS", "Create new table (# cols)");
	    return;
	}	    
	
	startRaw=tableDat->numRows();
	
    }	  
    else
    {
	tableDat=app(this)->newTable(TableName, 0,19);
    }
    
    QStringList typeCols;
    
    //+++ Cols Names
    tableDat->setColName(0,"Sample-Code"); tableDat->setColPlotDesignation(0,Table::None);  typeCols<<"1";
    tableDat->setColName(1,"Date"); tableDat->setColPlotDesignation(1,Table::None); typeCols<<"1";
    tableDat->setColName(2,"Code");tableDat->setColPlotDesignation(2,Table::None); typeCols<<"1";
    tableDat->setColName(3,"Run-Number");tableDat->setColPlotDesignation(3,Table::None);typeCols<<"0";
    tableDat->setColName(4,"Q"); tableDat->setColPlotDesignation(4,Table::X); typeCols<<"0";
    tableDat->setColName(5,"Volf-Bgr");tableDat->setColPlotDesignation(5,Table::None);typeCols<<"0";
    tableDat->setColName(6,"Trans-Fak");tableDat->setColPlotDesignation(6,Table::None);typeCols<<"0";
    tableDat->setColName(7,"Temp");tableDat->setColPlotDesignation(7,Table::None);typeCols<<"0";
    tableDat->setColName(8,"Ref");tableDat->setColPlotDesignation(8,Table::None);typeCols<<"0";
    tableDat->setColName(9,"Bgr");tableDat->setColPlotDesignation(9,Table::None);typeCols<<"0";
    tableDat->setColName(10,"Keep-Pha");tableDat->setColPlotDesignation(10,Table::None);typeCols<<"0";
    tableDat->setColName(11,"Zero_Pof");tableDat->setColPlotDesignation(11,Table::None);typeCols<<"0";
    tableDat->setColName(12,"Fit-Pha");tableDat->setColPlotDesignation(12,Table::None);typeCols<<"0";
    tableDat->setColName(13,"Window");tableDat->setColPlotDesignation(13,Table::None);typeCols<<"0";
    tableDat->setColName(14,"Windowpo");tableDat->setColPlotDesignation(14,Table::None);typeCols<<"0";
    tableDat->setColName(15,"Ud-Strat");tableDat->setColPlotDesignation(15,Table::None);typeCols<<"0";
    tableDat->setColName(16,"W-Fitpha");tableDat->setColPlotDesignation(16,Table::None);typeCols<<"0";
    tableDat->setColName(17,"Chisqlim");tableDat->setColPlotDesignation(17,Table::None);typeCols<<"0";
    tableDat->setColName(18,"Raterrli");tableDat->setColPlotDesignation(18,Table::None);typeCols<<"0";
    
    tableDat->setColumnTypes(typeCols);
    //+++
    tableDat->show();
    //+++
    QString fnameOnly;
    
    QString s,ss,nameMatrix;
    int iter;
    QString currentQ;
    //
    for(iter=0; iter<filesNumber;iter++)
    {	
	// Files
	
	QFile f(selectedDat[iter]);
	QTextStream t( &f );
	f.open(IO_ReadOnly);
	
	QStringList lst=lst.split("/",selectedDat[iter]);
	
	QString fileCode=lst[lst.count()-1];
	
	fileCode=fileCode.replace("_","-");
	
	int lineNum=0;
	
	bool stop=false;
	
	do
	{
	    tableDat->setNumRows(startRaw+1);
	    
	    //+++ First line;;  Table Name & Date
	    s = t.readLine().stripWhiteSpace(); lineNum++;
	    
	    //+++ Code 1
	    tableDat->setText(startRaw,0,s.left(s.find(" ",0))+"  "+fileCode); 
	    //+++ Date
	    tableDat->setText(startRaw,1,s.right(s.length()-s.find(" ",0)).stripWhiteSpace()); 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    //+++
	    if (!s.contains("Sqt/Sq  vs tau/ns") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    //+++ Code 2
	    tableDat->setText(startRaw,2,s.left(s.find("Sqt",0)-1).stripWhiteSpace().remove("\"")); 
	    
	    //+++ Run Number 	    
	    QString matrixName=s.right(s.length()-s.find("ns",0)-2).stripWhiteSpace();	 
	    tableDat->setText(startRaw,3,matrixName);
	    matrixName.prepend(fileCode+"-");
	    matrixName.append("-v-");
	    matrixName=app(this)->generateUniqueName(matrixName);
	    	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    if (!s.contains("parameter") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++ q	    
	    if (!s.contains("q")) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    
	    currentQ=s.remove("q").stripWhiteSpace();
	    tableDat->setText(startRaw,4,currentQ);
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  trans_fak
	    if (!s.contains("trans_fak") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,5,s.remove("trans_fak").stripWhiteSpace());
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  volf_bgr
	    if (!s.contains("volf_bgr") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,6,s.remove("volf_bgr").stripWhiteSpace());
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  temp
	    if (!s.contains("temp") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,7,s.remove("temp").stripWhiteSpace());
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  ref
	    if (!s.contains("ref") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,8,s.remove("ref").stripWhiteSpace());	 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  bgr
	    if (!s.contains("bgr") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,9,s.remove("bgr").stripWhiteSpace());	 	 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  keep_pha
	    if (!s.contains("keep_pha") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,10,s.remove("keep_pha").stripWhiteSpace());
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  zero_pof
	    if (!s.contains("zero_pof") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,11,s.remove("zero_pof").stripWhiteSpace());	 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  fit_pha
	    if (!s.contains("fit_pha") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,12,s.remove("fit_pha").stripWhiteSpace());
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  window
	    if (!s.contains("window") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,13,s.remove("window").stripWhiteSpace());
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  windowpo
	    if (!s.contains("windowpo") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,14,s.remove("windowpo").stripWhiteSpace());
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  ud_strat
	    if (!s.contains("ud_strat") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,15,s.remove("ud_strat").stripWhiteSpace());	 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  w_fitpha
	    if (!s.contains("w_fitpha") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,16,s.remove("w_fitpha").stripWhiteSpace());	 	 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  chisqlim
	    if (!s.contains("chisqlim") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,17,s.remove("chisqlim").stripWhiteSpace());	 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  raterrli
	    if (!s.contains("raterrli") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,18,s.remove("raterrli").stripWhiteSpace());
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    if (s.contains("values")) s = t.readLine().stripWhiteSpace();lineNum++;
	    
	    //+++  Read Table +++
	    Table* tableResults=app(this)->newTable(matrixName, 0,4);
	    
	    //+++ Cols Names
	    tableResults->setColName(0,"Time"); 	tableResults->setColPlotDesignation(0,Table::X);  
	    tableResults->setColName(1,"SqtToSq"); 	tableResults->setColPlotDesignation(1,Table::Y);
	    tableResults->setColComment(1, "Q="+currentQ+"/A");
	    tableResults->setColName(2,"dSqtToSq");	tableResults->setColPlotDesignation(2,Table::yErr);
	    tableResults->setColName(3,"dTime");	tableResults->setColPlotDesignation(3,Table::xErr);
	    
	    	    
	    //+++
	    int Ncur=0;
	    QRegExp rx("((\\-|\\+)?\\d*(\\.|\\,)\\d*((e|E)(\\-|\\+)\\d*)?)");	
	    
	    //s = t.readLine().stripWhiteSpace();lineNum++;
	    s.replace(',','.');
	    
	    while(s!="" && !s.contains("#eod") && !s.contains("#nxt") )
	    {
		
		s=s.simplifyWhiteSpace();
	    
		QStringList lst;
		lst=lst.split(" ",s);

		if(lst.count()<3) continue;
	    				
		tableResults->setNumRows(Ncur+1);
		
		for (i=0;i<4;i++) tableResults->setText(Ncur,i,QString::number(lst[i].toDouble(),'E'));
		if (lst.count()==4) tableResults->setText(Ncur,3,QString::number(lst[3].toDouble(),'E'));
		
		Ncur++;
		
		
		if (t.atEnd()) break;
		
		s = t.readLine().stripWhiteSpace();lineNum++;
		s.replace(',','.');
		

	    }

	    //
	    for (int tt=0; tt<tableResults->numCols(); tt++) tableResults->table()->adjustColumn (tt);		    
	    // +++ Hide all files
	    tableResults->setWindowLabel("NSE Dataset");    
	    app(this)->setListViewLabel(tableResults->name(), "NSE Dataset");	
	    app(this)->hiddenWindows->append(tableResults);
	    tableResults->setHidden();
	    
	    
	    // ---
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++
	    if (s=="#eod" || t.atEnd()) 
	    {
		stop=true;
	    }
	    startRaw++;
	    
	} while(!stop);
	
	f.close();
	
	
    }
    
    //+++
    for (int tt=0; tt<tableDat->numCols(); tt++) tableDat->table()->adjustColumn (tt);	
    tableDat->setWindowLabel("NSE Headers");    
    app(this)->setListViewLabel(tableDat->name(), "NSE Headers");
    app(this)->updateWindowLists(tableDat);
    tableDat->showMaximized();
    
    findHeaderTables();
}


//+++ Search of  Header tables
void jnse10::findHeaderTables()	
{    
    QString activeTable=comboBoxHeaderTables->currentText();    
    //+++
    QStringList list;
    
    QWidgetList* tableListAll=app(this)->tableList();
    
    for (int i=0;i<(int)tableListAll->count();i++)
    {
	if (tableListAll->at(i))
	{
	    Table *t=(Table*)tableListAll->at(i);
	    if (t->table()->horizontalHeader()->label(3)=="Run-Number") list<<tableListAll->at(i)->name();
	}
    }
    
    //
    list.prepend("Select Table of Headers");
    comboBoxHeaderTables->clear();
    comboBoxHeaderTables->insertStringList(list);
    if (list.contains(activeTable))comboBoxHeaderTables->setCurrentText(activeTable);
}

//+++
void jnse10::headerTableSeleted()
{    
    if (comboBoxHeaderTables->currentItem()>0)
    {
	QWidgetList* tableListAll=app(this)->tableList();
	for (int i=0;i<(int)tableListAll->count();i++)
	{
	    if (tableListAll->at(i)->name()==comboBoxHeaderTables->currentText())
	    {
		Table *t=(Table*)tableListAll->at(i);
		spinBoxFrom->setMaxValue(t->numRows());
		spinBoxTo->setMaxValue(t->numRows());
	    }
	}
    }
    else 
    {
	spinBoxFrom->setMaxValue(1);
	spinBoxTo->setMaxValue(1);
	findHeaderTables();
    }
    
}

//+++
void jnse10::nseFit()
{
    if (comboBoxHeaderTables->currentItem()>0)
    {
	emit signalJnse10Fit();
    }
    else QMessageBox::warning(this,tr("QtiKWS"), tr("Select Header's Table first!"));
}

//+++ Tab changed:: show new Title
void jnse10::tabSelected()
{
    QString newLabel=sansTab->label(sansTab->currentPageIndex());
    
    switch ( sansTab->currentPageIndex() )    {
	
    case 0: newLabel+=" >>> Set Location of JNSE-Files <<<";
	break;
    case 1: newLabel+=" >>> Import of JNSE-Files <<<";	
	break;
    case 2: newLabel+=" >>> Data Selection for simultaneous Fit <<<";
	break;	
    }
    textLabelInfo->setText(newLabel);
}


void jnse10::forceReadSettings()
{
    if (lineEditPathDAT->text()=="home") readSettings();
}


void jnse10::slotMakeListCohIncoh()
{
    QString DatDir	=lineEditPathDAT->text();
    
  
    app(this)->changeFolder("JNSE :: coh/inc files");
    
    //+++ select files
    QFileDialog *fd = new QFileDialog(DatDir,"Make Yours Filter (*.YOURS)",this,"JNSE - File Import");
    fd->setDir(DatDir);
    fd->setMode( QFileDialog::ExistingFiles );
    fd->setCaption(tr("QtiKWS - File Import"));
    fd->addFilter("JNSE coh/incoh files (*)");
    
    if (!fd->exec() == QDialog::Accepted ) return;
    
    
    QStringList selectedDat=fd->selectedFiles();
    int filesNumber= selectedDat.count();
    
    int startRaw=0;
        
    //+++
    QString fnameOnly, fileLabel, s;
    //
    for(int iter=0; iter<filesNumber;iter++)
    {	
	// Files
	
	QFile f(selectedDat[iter]);
	QTextStream t( &f );
	f.open(IO_ReadOnly);
	
	
	QStringList lst=lst.split("/",selectedDat[iter]);
	fnameOnly=selectedDat[iter];
	fnameOnly=fnameOnly.remove(DatDir);
	
	if (lst.count()>1) 	fnameOnly=lst[lst.count()-2]+"-"+lst[lst.count()-1];
	if (lst.count()==1) fnameOnly=lst[0];
	
			
	fnameOnly=fnameOnly.remove("/").remove("(").remove(")");
	fnameOnly=fnameOnly.replace(".","-");
	fnameOnly=fnameOnly.replace("_","-");
	fnameOnly=app(this)->generateUniqueName(fnameOnly+"-");
	
	fileLabel="";
	
	//+++ First line;;  Table Name & Date
	s = t.readLine().stripWhiteSpace();
	
	if (!s.contains("coh")) 
	{
	    f.close();
	    continue;
	}
	
	
	fileLabel+="JNSE coh/inc file:  "+selectedDat[iter];
//	fileLabel+=s+"\n";
	
	while(!s.contains("values"))
	{
	    s = t.readLine().stripWhiteSpace();
//	    fileLabel+=s+" --- ";
	}
//	fileLabel+="\n";

	//+++  Read Table +++
	Table* tableResults=app(this)->newTable(fnameOnly, 0,5);
	    
	//+++ Cols Names
	tableResults->setColName(0,"Q"); 		tableResults->setColPlotDesignation(0,Table::X);  
	tableResults->setColName(1,"Icoh"); 	tableResults->setColPlotDesignation(1,Table::Y);
	tableResults->setColName(2,"dIcoh");	tableResults->setColPlotDesignation(2,Table::yErr);
	tableResults->setColName(3,"Iinc"); 	tableResults->setColPlotDesignation(3,Table::Y);
	tableResults->setColName(4,"dIinc");	tableResults->setColPlotDesignation(4,Table::yErr);
	
	int rows=0;
	
	do
	{
	    s = t.readLine().stripWhiteSpace(); 
	    if (s.contains("#nxt")) break;
	  
	    s=s.simplifyWhiteSpace();
	    
	    QStringList lst;
	    lst=lst.split(" ",s);

	    if(lst.count()!=3) continue;
	    if(lst[0]=="NaN" || lst[1]=="NaN" || lst[2]=="NaN") continue;  
	    
	    rows++;
	    tableResults->setNumRows(rows);
	    
	    tableResults->setText(rows-1,0,QString::number(lst[0].toDouble(),'E'));
	    tableResults->setText(rows-1,1,QString::number(lst[1].toDouble(),'E'));	    
	    tableResults->setText(rows-1,2,QString::number(lst[2].toDouble(),'E'));	    
	}while (true);
	    
	
	//+++ First line;;  Table Name & Date
	s = t.readLine().stripWhiteSpace();
	
	if (!s.contains("inc")) 
	{
	    f.close();
	    continue;
	}
	
	
//	fileLabel+="\n\n"+s+"\n";
	
	while(!s.contains("values"))
	{
	    s = t.readLine().stripWhiteSpace();
//	    fileLabel+=s+" --- ";
	}
//	fileLabel+="\n";

	int irows=0;
	
	do
	{
	    s = t.readLine().stripWhiteSpace(); 
	    if (s.contains("#eod")) break;
	  
	    s=s.simplifyWhiteSpace();
	    
	    QStringList lst;
	    lst=lst.split(" ",s);

	    if(lst.count()!=3) continue;
	    if(lst[0]=="NaN" || lst[1]=="NaN" || lst[2]=="NaN") continue;    
	    
	    irows++;
	    if (irows>rows) 
	    {
		tableResults->setNumRows(rows);
		tableResults->setText(irows-1,0,QString::number(lst[0].toDouble(),'E'));

	    }
	    tableResults->setText(irows-1,3,QString::number(lst[1].toDouble(),'E'));	    
	    tableResults->setText(irows-1,4,QString::number(lst[2].toDouble(),'E'));	    
	}while (true);
	
	for (int tt=0; tt<tableResults->numCols(); tt++) tableResults->table()->adjustColumn (tt);		    
	
	// +++ Hide all files
	tableResults->setWindowLabel(fileLabel);    
	app(this)->setListViewLabel(tableResults->name(), fileLabel);	
	app(this)->hiddenWindows->append(tableResults);
	tableResults->setHidden();
    	f.close();
    }
    
    //+++

}
