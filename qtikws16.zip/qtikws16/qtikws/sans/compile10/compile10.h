/****************************************************************************
** Form interface generated from reading ui file '..\qtiKWS\sans\compile10\compile10.ui'
**
** Created: Do 14. Sep 01:52:12 2017
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.4   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef COMPILE10_H
#define COMPILE10_H

#include <qvariant.h>
#include <qpixmap.h>
#include <qwidget.h>
#include "qprocess.h"

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QButtonGroup;
class QRadioButton;
class QToolButton;
class QSplitter;
class QLabel;
class QListBox;
class QListBoxItem;
class QLineEdit;
class QFrame;
class QSpinBox;
class QSlider;
class QTable;
class QTabWidget;
class QTextEdit;
class QPushButton;
class QComboBox;
class QGroupBox;
class QCheckBox;
class Note;

class compile10 : public QWidget
{
    Q_OBJECT

public:
    compile10( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~compile10();

    QButtonGroup* buttonGroup13;
    QRadioButton* radioButton1D;
    QRadioButton* radioButton2D;
    QToolButton* pushButtonNew;
    QToolButton* pushButtonSave;
    QToolButton* pushButtonDelete;
    QToolButton* pushButtonMakeDLL;
    QSplitter* splitterMain;
    QButtonGroup* buttonGroupExplorer;
    QSplitter* splitter7;
    QLabel* textLabelGroupName_2;
    QListBox* listBoxGroup;
    QLineEdit* lineEditGroupName;
    QLabel* textLabelFunctionName_2;
    QListBox* listBoxFunctions;
    QLineEdit* lineEditFunctionName;
    QToolButton* pushButtonExplDown;
    QToolButton* pushButtonExplUp;
    QButtonGroup* buttonGroup5;
    QFrame* framePara_2;
    QLabel* textLabelNumberParameters_2_2;
    QLabel* textLabel1_3;
    QLineEdit* lineEditY;
    QLineEdit* lineEditXXX;
    QSpinBox* spinBoxXnumber;
    QFrame* framePara;
    QSlider* spinBoxP;
    QTable* tableParaNames;
    QToolButton* pushButtonParaDown;
    QToolButton* pushButtonParaUp;
    QButtonGroup* buttonGroup6;
    QTabWidget* tabWidgetCode;
    QWidget* tab;
    QToolButton* pushButtonMenu;
    QButtonGroup* frameMenu;
    QToolButton* pushButtonMenuSTD;
    QToolButton* pushButtonMenuFlags;
    QToolButton* pushButtonMenuData;
    QToolButton* pushButtonMenuSANS;
    QToolButton* pushButtonMenuMath;
    QToolButton* pushButtonMenuMULTI;
    QTextEdit* textEditCode;
    QWidget* tab_2;
    QSplitter* splitterInc;
    QSplitter* splitter6;
    QLabel* textLabel2_2_2;
    QTextEdit* textEditHFiles;
    QLabel* textLabel2_2_2_2;
    QToolButton* pushButtonAddHeader;
    QToolButton* pushButtonOpenInNote;
    QToolButton* pushButtonMakeIncluded;
    QToolButton* pushButtonIncludedDelete;
    QListBox* listBoxIncludeFunctions;
    QLabel* textLabel2_2_3_2;
    QTextEdit* textEditFunctions;
    QWidget* TabPage;
    QTextEdit* textEditDescription;
    QPushButton* pushButtonEXP;
    QPushButton* pushButtonSub;
    QPushButton* pushButtonGreek;
    QToolButton* pushButtonBold;
    QToolButton* pushButtonItal;
    QToolButton* pushButtonUnder;
    QComboBox* comboBoxFont;
    QComboBox* comboBoxFontSize;
    QToolButton* pushButtonLeft;
    QToolButton* pushButtonCenter;
    QToolButton* pushButtonRight;
    QToolButton* pushButtonJust;
    QWidget* TabPage_2;
    QGroupBox* groupBoxMinGw;
    QLabel* textLabel2_2;
    QLineEdit* fitPath;
    QToolButton* pushButtonPath;
    QCheckBox* checkBoxGSLlocal;
    QCheckBox* checkBoxGSLstatic;
    QLabel* textLabelGSL;
    QLineEdit* gslPathline;
    QToolButton* pushButtonPathGSL;
    QCheckBox* checkBoxCompilerLocal;
    QLabel* textLabelMingw;
    QLineEdit* mingwPathline;
    QToolButton* pushButtonPathMingw;
    QButtonGroup* buttonGroup12;
    QToolButton* pushButtonOpenFIF;
    QToolButton* pushButtonSaveAs;
    QToolButton* pushButtonCompileAll;
    QToolButton* pushButtonDefaultOptions;
    QSplitter* splitter3;
    QLabel* textLabel1;
    QLineEdit* lineEditCompileFlags;
    QLabel* textLabel1_2;
    QLineEdit* lineEditLinkFlags;
    QWidget* TabPage_3;
    QCheckBox* checkBoxAddFortran;
    QLineEdit* fortranFunction;
    QToolButton* pushButtonFortranFunction;
    QToolButton* pushButtonFortranFunctionView;
    QLabel* textLabelFortran_2;
    QTextEdit* textEditForwardFortran;
    QWidget* TabPage_4;
    QGroupBox* groupBox45;
    QSpinBox* spinBoxSubFitNumber;
    QSpinBox* spinBoxSubFitCurrent;
    QCheckBox* checkBoxSuperpositionalFit;
    QCheckBox* checkBoxAlgorithm;
    QCheckBox* checkBoxWeight;
    QComboBox* comboBoxWeightingMethod;
    QComboBox* comboBoxFitMethod;
    QCheckBox* checkBoxEfit;
    QWidget* TabPage_5;
    QButtonGroup* buttonGroup28;
    QRadioButton* radioButtonFIF;
    QRadioButton* radioButtonCPP;
    QRadioButton* radioButtonBAT;
    QToolButton* pushButtonInNoteFiles;
    QToolButton* pushButtonTestSave;
    QToolButton* pushButtonTestCompile;
    QTable* tableCPP;
    QToolButton* pushButtonCodeDown;
    QToolButton* pushButtonCodeUp;
    QLabel* textLabelInfoSAS;
    QLabel* textLabelInfo_2_2;
    QLabel* textLabelInfo_2;
    QPushButton* pushButtonHelp;

    bool boolYN;
    QString pathGSL;
    QString pathFIF;
    QString pathMinGW;

public slots:
    virtual void processFinished();
    virtual void connectSlot();
    virtual void readSettings();
    virtual void writeSettings();
    virtual void openHelpOnline();
    virtual void scanIncludedFunctions();
    virtual void setNumberparameters( int paraNumber );
    virtual void scanGroups();
    virtual void groupFunctions( const QString & groupName );
    virtual void openFIFfileSimple();
    virtual void openFIFfile();
    virtual void openFIFfile( const QString & fifName );
    virtual void makeCPP();
    virtual void makeBATnew();
    virtual void readFromStdout();
    virtual void compileSingleFunction();
    virtual void makeDLL();
    virtual void compileTest();
    virtual void makeFIF();
    virtual void saveasFIF();
    virtual void save( QString fn, bool askYN );
    virtual void saveTest();
    virtual void deleteFIF();
    virtual void deleteIncluded();
    virtual void makeIncluded();
    virtual void addHeaderFile();
    virtual void addIncludedFunction( const QString & fn );
    virtual void parseOrigin( QStringList lst );
    virtual void openOrigin( QString fdfName );
    virtual void saveAsCPP( QString fn );
    virtual bool saveAsIncluded( QString fn );
    virtual void newFIF();
    virtual void setPath();
    virtual void pathChanged();
    virtual void gslPath();
    virtual void mingwPath();
    virtual void openFortranFilePath();
    virtual void extructFortranFunctions( QString fileName );
    virtual void textFamily( const QString & f );
    virtual void textSize( const QString & p );
    virtual void textBold();
    virtual void textUnderline();
    virtual void textItalic();
    virtual void textLeft();
    virtual void textRight();
    virtual void textCenter();
    virtual void textJust();
    virtual void textEXP();
    virtual void textIndex();
    virtual void textGreek();
    virtual void readTextFormatting( int para, int pos );
    virtual void changedVertAlignment();
    virtual void stot1Dto2D();
    virtual void expandParaTrue();
    virtual void expandParaFalse();
    virtual void expandPara( bool YN );
    virtual void expandCodeTrue();
    virtual void expandCodeFalse();
    virtual void expandCode( bool YN );
    virtual void expandExplTrue();
    virtual void expandExplFalse();
    virtual void expandExpl( bool YN );
    virtual bool functionISbusy();
    virtual void toResLog( QString text );
    virtual void updateFiles();
    virtual void updateFiles2();
    virtual void moveParaLine( int line );
    virtual void compileAll();
    virtual void newFunctionName();
    virtual void newCategoryName();
    virtual void adjustResolusion();
    virtual void gslLocal( bool YN );
    virtual void compilerLocal( bool YN );
    virtual void gslStatic( bool YN );
    virtual void defaultOptions();
    virtual void pathUpdate();
    virtual void openHeaderInNote();
    virtual void openFortranFileInNote();
    virtual void openInNote( QString fn );
    virtual void openInNoteCPP();
    virtual void changedNumberIndepvar( int newNumber );
    virtual void changedFXYinfo();
    virtual void checkFunctionName();
    virtual void inputMenuCall();
    virtual void includeData();
    virtual void includeMath( int id );
    virtual void stdMenu();
    virtual void flagsMenu();
    virtual void dataMenu();
    virtual void mathMenu();
    virtual void sansMenu();
    virtual void multiMenu();
    virtual void includeIDmulti( int id );
    virtual void includeID( int id );
    virtual void showMenu();
    virtual void selectRowsTableMultiFit();

protected:
    QProcess *procc;
    bool boolCompileAll;

    QHBoxLayout* compile10Layout;
    QVBoxLayout* layout49;
    QHBoxLayout* buttonGroup13Layout;
    QHBoxLayout* buttonGroupExplorerLayout;
    QVBoxLayout* layout37;
    QVBoxLayout* layout38;
    QVBoxLayout* layout44;
    QSpacerItem* spacer23_2_2;
    QHBoxLayout* buttonGroup5Layout;
    QVBoxLayout* layout100;
    QVBoxLayout* layout99;
    QSpacerItem* spacer21_2_4_4;
    QHBoxLayout* framePara_2Layout;
    QVBoxLayout* layout43;
    QVBoxLayout* layout45;
    QHBoxLayout* layout44_2;
    QHBoxLayout* frameParaLayout;
    QVBoxLayout* layout47;
    QSpacerItem* spacer23_2;
    QHBoxLayout* buttonGroup6Layout;
    QVBoxLayout* layout101;
    QVBoxLayout* tabLayout;
    QHBoxLayout* layout38_2;
    QSpacerItem* spacer29;
    QHBoxLayout* frameMenuLayout;
    QVBoxLayout* tabLayout_2;
    QSpacerItem* spacer21_2_2;
    QVBoxLayout* layout51;
    QVBoxLayout* layout37_2;
    QHBoxLayout* layout36;
    QVBoxLayout* layout55;
    QVBoxLayout* TabPageLayout;
    QSpacerItem* spacer21_2_3;
    QHBoxLayout* layout69;
    QVBoxLayout* layout68;
    QSpacerItem* spacer21;
    QVBoxLayout* layout9;
    QHBoxLayout* layout102;
    QVBoxLayout* TabPageLayout_2;
    QSpacerItem* spacer21_2_4;
    QSpacerItem* spacer20;
    QHBoxLayout* layout39;
    QVBoxLayout* groupBoxMinGwLayout;
    QVBoxLayout* layout106;
    QHBoxLayout* layout97;
    QVBoxLayout* layout37_3;
    QHBoxLayout* layout36_2;
    QHBoxLayout* layout98;
    QVBoxLayout* layout42;
    QHBoxLayout* layout40;
    QHBoxLayout* layout99_2;
    QVBoxLayout* buttonGroup12Layout;
    QVBoxLayout* layout32;
    QVBoxLayout* layout33;
    QVBoxLayout* TabPageLayout_3;
    QSpacerItem* spacer21_2_4_2;
    QVBoxLayout* layout38_3;
    QHBoxLayout* layout37_4;
    QVBoxLayout* layout72;
    QVBoxLayout* TabPageLayout_4;
    QVBoxLayout* groupBox45Layout;
    QSpacerItem* spacer127;
    QHBoxLayout* layout272;
    QSpacerItem* spacer126;
    QGridLayout* layout271;
    QSpacerItem* spacer125;
    QHBoxLayout* layout157;
    QVBoxLayout* TabPageLayout_5;
    QSpacerItem* spacer21_2_4_3;
    QHBoxLayout* layout77;
    QHBoxLayout* buttonGroup28Layout;
    QVBoxLayout* layout48;
    QSpacerItem* spacer23_2_2_3;
    QHBoxLayout* layout50;

protected slots:
    virtual void languageChange();

private:
    QPixmap image0;
    QPixmap image1;
    QPixmap image2;
    QPixmap image3;
    QPixmap image4;
    QPixmap image5;
    QPixmap image6;
    QPixmap image7;
    QPixmap image8;
    QPixmap image9;
    QPixmap image10;
    QPixmap image11;
    QPixmap image12;
    QPixmap image13;
    QPixmap image14;
    QPixmap image15;
    QPixmap image16;

    void init();
    void destroy();

};

#endif // COMPILE10_H
