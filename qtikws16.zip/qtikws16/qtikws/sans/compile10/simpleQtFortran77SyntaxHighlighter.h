/***************************************************************************
 File                 : simpleQtCppSyntaxHighlighter.h
 Project              : QtiKWS
 --------------------------------------------------------------------
 Copyright            : (C) 2006-2013 by Vitaliy Pipich
 Email (use @ for *)  : v.pipich*gmail.com
 Description          : F77 Sintax Highlighter for Compile Fitting Interface
 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *  This program is free software; you can redistribute it and/or modify   *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation; either version 2 of the License, or      *
 *  (at your option) any later version.                                    *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the Free Software           *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor,                    *
 *   Boston, MA  02110-1301  USA                                           *
 *                                                                         *
 ***************************************************************************/

#ifndef SIMPLEHIGHTLIGHTERFORTRAN77_H
#define SIMPLEHIGHTLIGHTERFORTRAN77_H
#include <qsyntaxhighlighter.h>
#include <qtextedit.h>
#define NORMAL_STATE 0
#define COMMENT_STATE 1

class SyntaxHighlighterFortran77: public QSyntaxHighlighter 
{
    QStringList varList;
    QStringList keywordList ;
    
    QStringList leftList ;
    QStringList rightList;
    
    QColor keyColor;
    QColor varColor;    
    QColor commentColor;
    QColor gridColor;
    
    QFont xFont;
public:
    SyntaxHighlighterFortran77(QTextEdit* textEditFF ) : QSyntaxHighlighter(textEditFF) 
    {
	keyColor = Qt::blue;
	commentColor = Qt::red;
	varColor = Qt::green;
	gridColor=Qt::darkMagenta;
	
	//FORTRAN
	keywordList <<"IF"<<"THEN"<<"ELSE"<<"GO"<<"TO"<<"ENDIF"<<"DO"<<"SUBROUTINE"<<"DIMENSION"<<"DATA"<<"CALL"<<"IMPLICIT"<<"DOUBLE"<<"INTEGER"<<"REAL"<<"PRECISION"<<"FUNCTION"<<"END"<<"RETURN"<<"PARAMETER"<<"EXTERNAL"<<"COMMON"<<"LOGICAL"<<"COMPLEX"<<"EQUIVALENCE"<<"GOTO"<<"READ"<<"WRITE"<<"BACKSPACE"<<"REWIND"<<"ENDFILE"<<"FORMAT"<<"PAUSE"<<"STOP"<<"INQUIRE"<<"OPEN"<<"CLOSE"<<"CHARACTER"<<"PARAMETER"<<"SAVE"<<"LGE"<<"LGT"<<"LLE"<<"LLT"<<"SELECT"<<"CASE";
	keywordList<<"ABS"<<"**"<<"SIN"<<"COS"<<"SQRT"<<"SIND"<<"COSD"<<"TAN"<<"TAND"<<"ATAN"<<"ACOS"<<"ASIN"<<"ASIND"<<"ACOSD"<<"ATAND"<<"AINT"<<"ANINT"<<"NINT"<<"MOD"<<"SIGN";
	
	leftList <<" "<<";"<<","<<"("<<"{"<<"\t";
	rightList <<" "<<";"<<","<<")"<<"}"<<"\t"<<"["<<"*";
    }
    
    ~SyntaxHighlighterFortran77() 
    {
    }
    
    void addVars(const QString &str) {
        varList << str;
    }

    int highlightParagraph(const QString & text, int endStateOfLastPara) 
    {
	int index = 0;
	int count = 0;
	QStringList::iterator it = keywordList.begin();
	
	xFont=textEdit()->font();
	xFont.setBold(false);
	xFont.setItalic(true);
	xFont.setUnderline(false);
        
	// Assume the text to not contain keywords
	setFormat(0, text.length(), textEdit()->font(), Qt::black);

	int currentState = endStateOfLastPara;
	
	if (endStateOfLastPara == NORMAL_STATE || endStateOfLastPara < 0) 
	{
	    // keep it simple and assume that comment delimiters appear on a single line
	    
	    if (text.contains("/*")) 
	    {
		setFormat(0, text.length(), xFont, commentColor);
		currentState = COMMENT_STATE;
	    } 
	    else 
	    {
		xFont.setItalic(false);
		// Look for keywords
		while (it != keywordList.end()) 
		{
		    index=0;
		    count = text.contains(*it);
		    if (count) {
			for (int i = 0; i < count; i++) {
			    index = text.find(*it, index);	
			    if( ( index==0 || leftList.grep(text[index-1]).count()>0 ) && rightList.grep(text[index+(*it).length()]).count()>0)				
			    setFormat(index, (*it).length(), xFont, keyColor);
			    ++index;
			}
		    }
		    ++it;
		}
		//ilabels
		{
		    xFont.setItalic(false);
		    setFormat(0, 6, xFont, gridColor);
		    currentState = NORMAL_STATE;
		}

		if (text.contains("\"")) 
		{
		    xFont.setItalic(false);
		    int countPares=text.contains("\"")/2;
		    index=0;
		    int firstPos;
		    for(int i=0;i<countPares;i++)
		    {
			index = text.find("\"", index)+1;
			firstPos=index-1;
			index = text.find("\"", index)+1;
			setFormat(firstPos, index-firstPos, xFont, varColor);
		    }
		    currentState = NORMAL_STATE;
		}
		if (text.contains("!")) 
		{
		    xFont.setItalic(true);
		    setFormat(text.find("!"), text.length()-text.find("!"), xFont, commentColor);
		    currentState = NORMAL_STATE;
		}
		if (text.left(1)=="C" || text.left(1)=="c") 
		{
		    xFont.setItalic(true);
		    setFormat(0, text.length(), xFont, commentColor);
		    currentState = NORMAL_STATE;
		}
	    }
	} 
	else if (endStateOfLastPara == COMMENT_STATE) 
	{
	    setFormat(0, text.length(), xFont, commentColor);
	    if (text.contains("*/")) currentState = NORMAL_STATE;
	} 
	else 
	{
	    currentState = NORMAL_STATE;
	}
	
        return currentState;
    }
};
#endif
