/***************************************************************************
 File                 : compile.ui.h
 Project              : QtiKWS
 --------------------------------------------------------------------
 Copyright            : (C) 2006-2013 by Vitaliy Pipich
 Email (use @ for *)  : v.pipich*gmail.comf
 Description          : Compile Fitting Functions Interface
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *  This program is free software; you can redistribute it and/or modify   *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation; either version 2 of the License, or      *
 *  (at your option) any later version.                                    *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the Free Software           *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor,                    *
 *   Boston, MA  02110-1301  USA                                           *
 *                                                                         *
 ***************************************************************************/

#include "../../src/application.h"
#include "../../src/note.h"
#include "../../src/pixmaps.h"
#include "../../src/fileDialogs.h"
#include "../standart-functions/standartFunctions.h"
#ifdef FITTABLE
#include "../fittable16/fittable16.h"
#endif
#include "../fitMatrix10/fitMatrix10.h"
#include "simpleQtCppSyntaxHighlighter.h"
#include "simpleQtFortran77SyntaxHighlighter.h"

#include <qmessagebox.h>
#include <qfiledialog.h>
#include <qprocess.h>
#include <qdir.h>
#include <qapplication.h> 
#include <qsettings.h>
#include <qfontdatabase.h>
#include <qregexp.h> 
#include <qtextedit.h> 
#include <qtimer.h> 
#include <qpopupmenu.h>
#include <qaction.h>
#include <qwaitcondition.h> 
#include <qprogressdialog.h>
#include <qsyntaxhighlighter.h>
#include <qtextedit.h>
#include <qtooltip.h> 
#include <qmenubar.h> 
#include <iostream>
#include <qinputdialog.h> 

#ifdef Q_OS_WIN
//#include <windows.h>
//#define sleep(n) Sleep(n)
#endif

bool compileOK=true;

void compile10::processFinished()
{
    if (!boolCompileAll)
    {
	
	QString soName=fitPath->text()+"/"+lineEditFunctionName->text()+".";
	
#ifdef Q_OS_MAC // Mac
	soName+="dylib";
#elif defined(Q_OS_WIN)
	soName+="dll";
#else
	soName+="so";
#endif
	if (radioButton2D->isChecked()) soName+="2d";
	
	if (compileOK &&  QFile::exists (soName))	
	    toResLog("<< compile status >> OK: function '"+ lineEditFunctionName->text()+"' is ready\n");
	else if (compileOK && !QFile::exists (soName)) 
	    toResLog("<< compile status >>  ERROR: check compiler options\n");
	else 
	{
	    toResLog("<< compile status >>  ERROR: check function code\n");
	}
	
	app(this)->actionShowLog->setOn(true);
	app(this)->results->scrollToBottom();
	compileOK=true;
}
    return;
};

void compile10::connectSlot()
{
    connect( radioButtonBAT, SIGNAL( clicked() ), this, SLOT( updateFiles() ) );
    connect( radioButtonFIF, SIGNAL( clicked() ), this, SLOT( updateFiles() ) );
    connect( radioButtonCPP, SIGNAL( clicked() ), this, SLOT( updateFiles() ) );
    
    //+++
    connect(tableParaNames->verticalHeader(), SIGNAL(clicked (int)), this, SLOT(moveParaLine(int)));
    
    //+++
    connect( pushButtonParaDown, SIGNAL( clicked() ), this, SLOT( expandParaTrue() ) );
    connect( pushButtonParaUp, SIGNAL( clicked() ), this, SLOT( expandParaFalse() ) );    
    
    //+++
    connect( pushButtonCodeDown, SIGNAL( clicked() ), this, SLOT( expandCodeTrue() ) );
    connect( pushButtonCodeUp, SIGNAL( clicked() ), this, SLOT( expandCodeFalse() ) );    
    
    //+++
    connect( pushButtonExplDown, SIGNAL( clicked() ), this, SLOT( expandExplTrue() ) );
    connect( pushButtonExplUp, SIGNAL( clicked() ), this, SLOT( expandExplFalse() ) );    
    
    //+++ hELP
    connect( pushButtonHelp, SIGNAL( clicked() ), this, SLOT( openHelpOnline() ) );
    
    connect(pushButtonEXP, SIGNAL( clicked() ), this, SLOT( textEXP() ) );
    connect( pushButtonJust, SIGNAL( clicked() ), this, SLOT( textJust() ) );
    connect( pushButtonRight, SIGNAL( clicked() ), this, SLOT( textRight() ) );
    connect( pushButtonCenter, SIGNAL( clicked() ), this, SLOT( textCenter() ) );
    connect( pushButtonLeft, SIGNAL( clicked() ), this, SLOT( textLeft() ) );
    connect( pushButtonItal, SIGNAL( clicked() ), this, SLOT( textItalic() ) );
    connect( pushButtonUnder, SIGNAL( clicked() ), this, SLOT( textUnderline() ) );
    connect( pushButtonBold, SIGNAL( clicked() ), this, SLOT( textBold() ) );
    connect( comboBoxFontSize, SIGNAL( activated(const QString&) ), this, SLOT( textSize(const QString&) ) );
    connect( comboBoxFont, SIGNAL( activated(const QString&) ), this, SLOT( textFamily(const QString&) ) );
    connect( checkBoxAddFortran, SIGNAL( toggled(bool) ), textEditForwardFortran, SLOT( setEnabled(bool) ) );
    connect( pushButtonFortranFunction, SIGNAL( clicked() ), this, SLOT( openFortranFilePath() ) );
    connect( pushButtonPathMingw, SIGNAL( clicked() ), this, SLOT( mingwPath() ) );
    connect( pushButtonPathGSL, SIGNAL( clicked() ), this, SLOT( gslPath() ) );
    
    connect( fitPath, SIGNAL( textChanged(const QString&) ), this, SLOT( pathChanged() ) );
    
    connect( pushButtonPath, SIGNAL( clicked() ), this, SLOT( setPath() ) );
    connect( pushButtonNew, SIGNAL( clicked() ), this, SLOT( newFIF() ) );
    connect( listBoxIncludeFunctions, SIGNAL( selected(const QString&) ), this, SLOT( addIncludedFunction(const QString&) ) );
    
    connect( pushButtonAddHeader, SIGNAL( clicked() ), this, SLOT( addHeaderFile() ) );
    connect( pushButtonOpenInNote, SIGNAL( clicked() ), this, SLOT( openHeaderInNote() ) );
    connect( pushButtonFortranFunctionView, SIGNAL( clicked() ), this, SLOT( openFortranFileInNote() ) );    
    
    
    connect( pushButtonMakeIncluded, SIGNAL( clicked() ), this, SLOT( makeIncluded() ) );
    connect( pushButtonDelete, SIGNAL( clicked() ), this, SLOT( deleteFIF() ) );
    connect( pushButtonSaveAs, SIGNAL( clicked() ), this, SLOT( saveasFIF() ) );
    connect( pushButtonSave, SIGNAL( clicked() ), this, SLOT( makeFIF() ) );
        
    connect( pushButtonTestSave, SIGNAL( clicked() ), this, SLOT( saveTest() ) );
    
    connect( pushButtonMakeDLL, SIGNAL( clicked() ), this, SLOT( compileSingleFunction() ) );
    connect( pushButtonCompileAll, SIGNAL( clicked() ), this, SLOT( compileAll() ) );
    connect( pushButtonDefaultOptions, SIGNAL( clicked() ), this, SLOT( defaultOptions() ) );
    connect( pushButtonIncludedDelete, SIGNAL( clicked() ), this, SLOT( deleteIncluded() ) );  
    
    connect( pushButtonTestCompile, SIGNAL( clicked() ), this, SLOT( compileTest() ) );
    
    connect( listBoxGroup, SIGNAL( highlighted(const QString&) ), this, SLOT( groupFunctions(const QString&) ) );
    connect(  listBoxFunctions, SIGNAL( highlighted(const QString&) ), this, SLOT( openFIFfileSimple() ) );
    connect( pushButtonOpenFIF, SIGNAL( clicked() ), this, SLOT( openFIFfile() ) );
    connect( spinBoxP, SIGNAL( valueChanged(int) ), this, SLOT( setNumberparameters(int) ) );
    connect( pushButtonGreek, SIGNAL( clicked() ), this, SLOT( textGreek() ) );
    connect( pushButtonSub, SIGNAL( clicked() ), this, SLOT( textIndex() ) );
    connect( tabWidgetCode, SIGNAL( selected(const QString&) ), this, SLOT( pathUpdate() ) );
    connect( textEditDescription, SIGNAL( cursorPositionChanged(int,int) ), this, SLOT( readTextFormatting(int,int) ) );
    connect( textEditDescription, SIGNAL( currentVerticalAlignmentChanged(VerticalAlignment) ), this, SLOT( changedVertAlignment() ) );
    connect( radioButton1D, SIGNAL( stateChanged(int) ), this, SLOT( stot1Dto2D() ) );
    
    connect( lineEditFunctionName, SIGNAL( textChanged(const QString&) ), this, SLOT( newFunctionName() ) );
    connect( lineEditGroupName, SIGNAL( textChanged(const QString&) ), this, SLOT( newCategoryName() ) );    
    
    connect( checkBoxGSLlocal, SIGNAL( toggled(bool) ),this, SLOT( gslLocal(bool) ) );
    connect( checkBoxCompilerLocal, SIGNAL( toggled(bool) ),this, SLOT( compilerLocal(bool) ) );
    
    connect( checkBoxGSLstatic, SIGNAL( toggled(bool) ),this, SLOT( gslStatic(bool) ) );
  
    connect( spinBoxXnumber, SIGNAL( valueChanged ( int)), this, SLOT(changedNumberIndepvar(int)));
    
    connect( lineEditY, SIGNAL( textChanged(const QString&) ), this, SLOT( changedFXYinfo() ) );
    connect( lineEditXXX, SIGNAL( textChanged(const QString&) ), this, SLOT( changedFXYinfo() ) );
  
    connect(tableCPP->horizontalHeader(), SIGNAL(clicked(int)), this, SLOT(openInNoteCPP()));
    connect(pushButtonInNoteFiles, SIGNAL(clicked()), this, SLOT(openInNoteCPP()));	 
	  
//    connect(pushButtonMenu, SIGNAL(clicked()), this, SLOT(inputMenuCall()));	 
    connect(pushButtonMenu, SIGNAL(clicked()), this, SLOT(showMenu()));	 
    
    connect(pushButtonMenuFlags, SIGNAL(clicked()), this, SLOT(flagsMenu()));
    connect(pushButtonMenuData, SIGNAL(clicked()), this, SLOT(dataMenu()));
    connect(pushButtonMenuMath, SIGNAL(clicked()), this, SLOT(mathMenu()));    
    connect(pushButtonMenuSANS, SIGNAL(clicked()), this, SLOT(sansMenu()));     
    connect(pushButtonMenuSTD, SIGNAL(clicked()), this, SLOT(stdMenu())); 
    
    connect(pushButtonMenuMULTI, SIGNAL(clicked()), this, SLOT(multiMenu())); 
    
    
    connect(tableParaNames, SIGNAL(selectionChanged()), this, SLOT(selectRowsTableMultiFit()));
}

//*******************************************
//+++ Initiation
//*******************************************
void compile10::init()
{

    //+++
    connectSlot();
    
    //+++ 1D or 2D
    stot1Dto2D();
    
    //+++  Greek
    pushButtonGreek->hide();
    pushButtonEXP->hide();
    pushButtonSub->hide();
    
    defaultOptions();
    readSettings ();


    //+++ Para-Table******************
    tableParaNames->setColumnWidth(0,80);
    tableParaNames->setColumnWidth(1,120);
    tableParaNames->setColumnWidth(2,45);
    //    tableParaNames->setColumnWidth(3,200);
    tableParaNames->setColumnStretchable(3,true);
    //+++
    scanGroups();
    scanIncludedFunctions();
    
    //+++
    QFontDatabase db;
    comboBoxFont->insertStringList( db.families() );
    
    QValueList<int> sizes = db.standardSizes();
    QValueList<int>::Iterator it = sizes.begin();
    for ( ; it != sizes.end(); ++it )
	comboBoxFontSize->insertItem( QString::number( *it ) );
    boolYN=false;
    
    //+++
    pushButtonEXP->setPixmap (QPixmap(exp_xpm));
    pushButtonSub->setPixmap (QPixmap(index_sub));
    pushButtonGreek->setPixmap(QPixmap(ABG_xpm));
    
    expandExpl(false);
    
    //tableCPP->setColumnWidth(0,405);    
    tableCPP->setColumnStretchable(0,true);
    
    pushButtonParaUp->hide();
    pushButtonExplUp->hide();
    pushButtonCodeUp->hide();

    
    SyntaxHighlighter* codeMain = new SyntaxHighlighter(textEditCode);

    SyntaxHighlighter* codeIncluded = new SyntaxHighlighter(textEditFunctions);

    SyntaxHighlighter* fortranInc = new SyntaxHighlighter(textEditForwardFortran);
    
    QString toolText="Main Code Window";
    QToolTip::add( textEditCode, toolText);
    
    pushButtonMenu->setText(QChar(0x226A));
    showMenu();
    
    //pushButtonMenuGSL->hide();
}

//*******************************************
//+++ Destroy
//*******************************************
void compile10::destroy()
{    
    writeSettings();
}


// ************************************************************************************
// ************************************************************************************
//            Settings Tab
// ************************************************************************************
// ************************************************************************************

 
//*******************************************
//+++  Read settings at init()
//*******************************************
void compile10::readSettings()
{
#ifdef Q_OS_MAC // Mac 
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
    
    settings.setPath("JCNS", "QtiKWS", QSettings::User);
    
    bool ok;
    QString ss;
    
    settings.beginGroup("/Compile");
    ss=settings.readEntry("/Compile_compilerLocal",0,&ok); 
    if (ok) 
    {
	if (ss=="yes") 
	{
	    checkBoxCompilerLocal->setChecked(true);
	    compilerLocal(true);
	}
	else
	{
	    checkBoxCompilerLocal->setChecked(false);	    
	    compilerLocal(false);
	}	
    };      
    
    ss=settings.readEntry("/Compile_gslLocal",0,&ok); 
    if (ok) 
    {
	
	if (ss=="yes") 
	{
	    checkBoxGSLlocal->setChecked(true);
	    gslLocal(true);
	    
	    ss=settings.readEntry("/Compile_gslStatic",0,&ok); 

	    if (ss=="yes") 
		checkBoxGSLstatic->setChecked(true);
	    else
		checkBoxGSLstatic->setChecked(false);

	}
	else
	{
	    checkBoxGSLlocal->setChecked(false);	    
	    gslLocal(false);
	    checkBoxGSLstatic->setChecked(false);
	}	
    };      
    ss=settings.readEntry("/Compile_gslPath",0,&ok); if (ok) { gslPathline->setText(ss); pathGSL=ss;};
    ss=settings.readEntry("/Compile_mingwPath",0,&ok); if (ok) {mingwPathline->setText(ss); pathMinGW=ss;};    
    ss=settings.readEntry("/Compile_compileFlags",0,&ok); if (ok) {lineEditCompileFlags->setText(ss);};    
    ss=settings.readEntry("/Compile_linkFlags",0,&ok); if (ok) {lineEditLinkFlags->setText(ss);};    
    
    


    
    
    settings.endGroup();
    
    
}

//*******************************************
//+++  Write settings at destroy()
//*******************************************
void compile10::writeSettings()
{
#ifdef Q_OS_MAC // Mac 
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
  
    QString ss;
    
    settings.setPath("JCNS", "QtiKWS", QSettings::User);
    
    settings.beginGroup("/Compile");
    ss=settings.writeEntry("/Compile_gslPath",gslPathline->text());
    ss=settings.writeEntry("/Compile_mingwPath",mingwPathline->text());
    ss=settings.writeEntry("/Compile_compileFlags",lineEditCompileFlags->text());
    ss=settings.writeEntry("/Compile_linkFlags",lineEditLinkFlags->text());
    
    if (checkBoxGSLlocal->isChecked())
    {
	ss=settings.writeEntry("/Compile_gslLocal","yes");
	if (checkBoxGSLstatic->isChecked())
	    ss=settings.writeEntry("/Compile_gslStatic","yes");
	else
	    ss=settings.writeEntry("/Compile_gslStatic","no");
    }
    else
    {
	ss=settings.writeEntry("/Compile_gslLocal","no");
	ss=settings.writeEntry("/Compile_gslStatic","no");
    }
    
    if (checkBoxCompilerLocal->isChecked())
	ss=settings.writeEntry("/Compile_compilerLocal","yes");
    else
	ss=settings.writeEntry("/Compile_compilerLocal","no");
    
    settings.endGroup();
}

//+++  openHelpOnline +++
void compile10::openHelpOnline()
{
    app(this)->open_browser(this, "http://iffwww.iff.kfa-juelich.de/~pipich/dokuwiki/doku.php/qtikws/compile");
}


//*******************************************
//+++  scan Included Functions
//*******************************************
void compile10::scanIncludedFunctions()
{
    int i;
    QString s;
    QString fileName;
    
    QStringList group;
    
    QDir d(pathFIF+"/IncludedFunctions");
    QStringList lst = d.entryList("*.h");
    lst += d.entryList("*.cpp");
    
    listBoxIncludeFunctions->clear();
    listBoxIncludeFunctions->insertStringList (lst);
}


//*******************************************
//+++ set number parameters in table
//*******************************************
void compile10::setNumberparameters( int paraNumber )
{
    int i;
    int oldNumberParameters=tableParaNames->numRows();
    tableParaNames->setNumRows(paraNumber);
    
    for(i=oldNumberParameters;i<paraNumber;i++)
    {
	//+++ 
	QCheckTableItem *adjust = new QCheckTableItem(tableParaNames, QString::null );
	tableParaNames->setItem(i,2, adjust);
	tableParaNames->verticalHeader()->setLabel(i,"^");
    }
}

//*******************************************
//+++ scan FitFunction dir on groups
//*******************************************
void compile10::scanGroups()
{
    int i;
    QString s;
    QStringList group;
    QString groupName;
    
    //group<<"ALL";
    
    QDir d(pathFIF);
    //+++
    QString fifExt="*.";
    if (radioButton2D->isChecked()) fifExt+="2d";
    fifExt+="fif";
    //+++
    QStringList lst = d.entryList(fifExt);
    
    
    for(i=0;i<lst.count();i++) 
    {
	if (d.exists(lst[i]))
	{
	    QFile f(pathFIF+"/"+lst[i]);
	    f.open( IO_ReadOnly );
	    QTextStream t( &f );
	    
	    //+++[group]  
	    s = t.readLine();
	    if (s.contains("[group]")>0) 
	    {
		groupName=t.readLine().stripWhiteSpace();
		if (!group.contains(groupName) && groupName!="") group<<groupName;
	    }
	    
	    f.close();
	}
    }
    group.sort();
    group.prepend("ALL");
    listBoxFunctions->clear();
    listBoxGroup->clear();
    listBoxGroup->insertStringList (group);
    
    lineEditGroupName->setText("");
    lineEditFunctionName->setText("");
    
}

//*******************************************
//+++  fing functions of single Group
//*******************************************
void compile10::groupFunctions( const QString &groupName )
{
    
    
    QString oldFunction=lineEditFunctionName->text();
    
    int i;
    QString s;
    QStringList functions;
    
    QDir d(pathFIF);
    
    QString fifExt=".";
    if (radioButton2D->isChecked()) fifExt+="2d";
    fifExt+="fif";	
    //+++
    QStringList lst = d.entryList("*"+fifExt);
    
    QStringList lstALL;
    
    for(i=0;i<lst.count();i++) 
    {
	if (d.exists (lst[i]))
	{
	    QFile f(pathFIF+"/"+lst[i]);
	    f.open( IO_ReadOnly );
	    QTextStream t( &f );
	    
	    //+++[group]  
	    s = t.readLine();
	    if (s.contains("[group]")>0) 
	    {
		if (t.readLine().stripWhiteSpace()==groupName) functions<<lst[i].remove(fifExt);
	    }
	    
	    f.close();
	    lstALL<<lst[i].remove(fifExt);
	}
    }
    lstALL.sort();
    
    listBoxFunctions->clear();
    
    if (groupName=="ALL") 	listBoxFunctions->insertStringList (lstALL);
    else listBoxFunctions->insertStringList (functions);
    
    lineEditGroupName->setText(groupName);
    //    lineEditFunctionName->setText("");
    if (functions.contains(oldFunction)) listBoxFunctions->setSelected( listBoxFunctions->findItem(oldFunction), true );  
    else
    {
	lineEditFunctionName->clear();
	spinBoxP->setValue(0);
	
	lineEditY->setText("f");
	textEditCode->clear();
	textEditDescription->clear();
	textEditDescription->setText("good place for function's comments");
	textEditHFiles->clear();
	textEditFunctions->clear();
	
	tabWidgetCode->setCurrentPage(0);
	tableCPP->setNumRows(0);
	radioButtonBAT->setChecked(false);
	radioButtonCPP->setChecked(false); radioButtonCPP->setText("*.cpp");
	radioButtonFIF->setChecked(false); radioButtonFIF->setText("*.fif"); 
    }
    
}

//*******************************************
//+++  open FIF: from listbox
//*******************************************
void compile10::openFIFfileSimple()
{
    pathUpdate();
    QString fifExt=".";
    if (radioButton2D->isChecked()) fifExt+="2d";
    fifExt+="fif";	
    
    QString ss=pathFIF+"/"+listBoxFunctions->currentText()+fifExt;
    
    openFIFfile(ss);
    
    
    if (listBoxGroup->currentText()=="ALL")
    {
	//listBoxGroup->setCurrentItem(listBoxGroup->findItem(lineEditGroupName->text()));
	//listBoxFunctions->setCurrentItem(listBoxFunctions->findItem(lineEditFunctionName->text()));
    }
}
//*******************************************
//+++  open FIF: from file
//*******************************************
void compile10::openFIFfile()
{   
    QString filter = tr("QtiKWS function") + " (*.fif);;";
    filter += tr("QtiKWS 2D-function") + " (*.2dfif);;";
    filter += tr("Origin function") + " (*.fdf *.FDF);;";
    
    //+++
    QString fn = QFileDialog::getOpenFileName(pathFIF, filter, this, 0, "Qtiplot - Fit - Function", 0, TRUE);
    
    
    newFIF();
    
    if (fn.contains("fif",TRUE))
    {
	openFIFfile(fn);
	scanGroups();
    }
    else if (fn.contains(".fdf",FALSE))
    {
	openOrigin(fn);
    }
    
}

//*******************************************
//+++ open FIF: code 
//*******************************************
void compile10::openFIFfile(const QString& fifName)
{
    //    functionISbusy();
    
    textEditForwardFortran->clear();
    fortranFunction->clear();
    
    if ( fifName.contains(".2dfif") ) radioButton2D->setChecked(true);
    
    int i;
    spinBoxP->setValue(0);
    
    //+++
    if (fifName.isEmpty())
    {
	QMessageBox::warning(this,tr("QtKws"), tr("Error: <p> no FIF file, 1"));
	return;
    }   
    
    //+++
    if (!QFile::exists (fifName))
    {
	QMessageBox::warning(this,tr("QtKws"), tr("Error: <p> no FIF file, 2"));
	return;
    }
    
    //+++
    QFile f(fifName);
    
    //+++
    if ( !f.open( IO_ReadOnly ) ) 
    {
	QMessageBox::critical(0, tr("QtKws"),
			      tr("Could not write to file: <br><h4>"+fifName+ 
				 "</h4><p>Please verify that you have the right to read from this location!"));
	return;
    }
    else
    {
	QTextStream t( &f );
	QString s;
	
	//+++[group]
	s = t.readLine();		
	if (s.contains("[group]")==0) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [group]"));
	    return;
	}
	else
	{
	    s.remove("[group] ");
	    if (s.contains("[eFit]")) checkBoxEfit->setChecked(true);	else checkBoxEfit->setChecked(false);
	    s.remove("[eFit] ");
	    if (s.contains("[Weight]"))
	    {
		checkBoxWeight->setChecked(true);
		s.remove("[Weight] ");
		comboBoxWeightingMethod->setCurrentItem(s.left(1).toInt());
		s=s.right(s.length()-2);
	    }
	    else
	    {
		checkBoxWeight->setChecked(false);
		comboBoxWeightingMethod->setCurrentItem(0);	    
	    }
	    if (s.contains("[Algorithm]")) 
	    {
		checkBoxAlgorithm->setChecked(true);
		s.remove("[Algorithm] ");
		comboBoxFitMethod->setCurrentItem(s.left(1).toInt());
		s=s.right(s.length()-2);
	    }
	    else
	    {
		checkBoxAlgorithm->setChecked(false);
		comboBoxFitMethod->setCurrentItem(0);
	    }
	    if (s.contains("[Superpositional]"))
	    {
		checkBoxSuperpositionalFit->setChecked(true);
		s.remove("[Superpositional] ");
		QStringList sLst = QStringList::split(" ", s, false);
		spinBoxSubFitNumber->setValue(sLst[0].toInt());
		spinBoxSubFitCurrent->setValue(sLst[1].toInt());		
	    }
	    else
	    {
		checkBoxSuperpositionalFit->setChecked(false);
		spinBoxSubFitNumber->setValue(1);
		spinBoxSubFitCurrent->setValue(2);		
	    }
	}
	
	/*	
	if (s.find("[Function from Standard Library]")>0) 
	{
	    pushButtonSave->setEnabled(false);
	    pushButtonDelete->setEnabled(false);
	}
	else
	{
	    pushButtonSave->setEnabled(true);
	    pushButtonDelete->setEnabled(true);
	}
	*/
	//+++group Name
	QString groupName=t.readLine().stripWhiteSpace();
	if (groupName=="") groupName="ALL";
	lineEditGroupName->setText(groupName);
	//+++ skip
	s = t.readLine();
	
	//+++[name]
	s = t.readLine();	
	if (s.contains("[name]")==0) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [name]"));
	    return;
	}
	
	//+++ function Name
	QString functionName=t.readLine().stripWhiteSpace();
	if (functionName=="") 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [name]"));
	    return;
	}
	lineEditFunctionName->setText(functionName);
	
	//+++ skip
	s = t.readLine();
	
	//+++[number parameters]
	s = t.readLine();	
	if (s.contains("[number parameters]")==0) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [number parameters]"));
	    return;
	}
	//+++[number parameters]
	int pNumber=t.readLine().remove(",").stripWhiteSpace().toInt();
	if (pNumber<=0) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [number parameters]"));
	    return;
	}
	spinBoxP->setValue(pNumber);
	
	//+++ skip
	s = t.readLine();		
	//+++[description]
	s = t.readLine();	
	if (s.contains("[description]")==0) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [description]"));
	    return;
	}
	//+++[description]
	s = t.readLine();
	textEditDescription->clear();
	while(s.contains("[x]")==0)
	{
	    textEditDescription->append(s);
	    s = t.readLine();
	}
	
	//+++[x]
	s=t.readLine().stripWhiteSpace();
	if (radioButton2D->isChecked())
	{
	    QStringList lst=QStringList::split(",", s.remove(" "));
	    
	    spinBoxXnumber->setValue(lst.count());	
	    lineEditXXX->setText(s.remove(" "));
	}
	else
	{
	    lineEditXXX->setText(s.remove(" "));
	}  
		
	//+++ skip
	s = t.readLine();
	
	//+++[y]
	s = t.readLine();	
	if (s.contains("[y]")==0) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [y]"));
	    return;
	}
	lineEditY->setText(t.readLine().stripWhiteSpace());
	
	//+++ skip
	s = t.readLine();
	//+++[parameter name]
	s = t.readLine();	
	if (s.contains("[parameter names]")==0) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [parameter names]"));
	    return;
	}
	//+++[parameter names]
	s = t.readLine().stripWhiteSpace();
	QStringList paraNames=QStringList::split(",", s, false);
	if (paraNames.size()!=pNumber) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [parameter names]"));
	}
	
	//+++ skip
	s = t.readLine();
	//+++[initial values]
	s = t.readLine();	
	if (s.contains("[initial values]")==0) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [initial values]"));
	    return;
	}
	//+++[initial values]
	s 	= t.readLine().stripWhiteSpace();
	QStringList initValues=QStringList::split(",", s, false);
	if (initValues.size()!=pNumber) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [initial values]"));
	}
	
	//+++ skip
	s = t.readLine();
	//+++[adjustibility]
	s = t.readLine();	
	if (s.contains("[adjustibility]")==0) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [adjustibility]"));
	    return;
	}
	//+++[adjustibility]
	s = t.readLine().stripWhiteSpace();
	QStringList adjustibilityList=QStringList::split(",", s, false);
	if (adjustibilityList.size()!=pNumber) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [adjustibility]"));
	}
	
	//+++ skip
	s = t.readLine();
	//+++[parameter description]
	s = t.readLine();	
	if (s.contains("[parameter description]")==0) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [parameter description]"));
	    return;
	}
	//+++[parameter description]
	s = t.readLine().stripWhiteSpace();
	QStringList paraDescription=QStringList::split(",", s, false);
	if (paraDescription.size()!=pNumber) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [parameter description]"));
	}
	
	for(i=0; i<pNumber; i++) 	
	{
	    //+++
	    tableParaNames->setText(i,0,paraNames[i]);

	    QString sCurrent=initValues[i];
	    
	    if (sCurrent.contains('[') && sCurrent.contains("..") && sCurrent.contains(']'))    
		tableParaNames->setText(i,1,sCurrent);
	    else
		tableParaNames->setText(i,1,QString::number(sCurrent.toDouble()));
	    //+++ 
	    QCheckTableItem *adjust = (QCheckTableItem *)tableParaNames->item(i,2);			
	    if (adjustibilityList[i].toInt()==1) adjust->setChecked(true);
	    //+++
	    tableParaNames->setText(i,3,paraDescription[i]);
	}
	
	//+++ skip
	s = t.readLine();
	//+++ [h-headers]
	s = t.readLine();	
	if (s.contains("[h-headers]")==0) 
	{
	    QMessageBox::warning(this,tr("QtKws"), tr("Error: [h-headers]"));
	    return;
	}
	//+++[h-headers]
	s = t.readLine();
	textEditHFiles->clear();
	while(s.contains("[included functions]")==0)
	{
	    textEditHFiles->append(s);
	    s = t.readLine();
	}
	
	//+++ [included functions]
	QString ssss;
	s = t.readLine();
	textEditFunctions->clear();
	while(s.contains("[code]")==0)
	{
	    ssss+=s+"\n";
	    s = t.readLine();
	}
	
	textEditFunctions->append(ssss.left(ssss.length()-2));
	textEditFunctions->moveCursor(QTextEdit::MoveHome,true);
	
	//+++[code]
	ssss="";
	s = t.readLine();
	textEditCode->clear();
	while(s.contains("[fortran]" )==0 && s.contains("[end]")==0)
	{
	    ssss+=s+"\n";
	    s = t.readLine();
	}
	
	textEditCode->append(ssss.left(ssss.length()-2));
	textEditCode->moveCursor(QTextEdit::MoveHome,true);
	
	if (s.contains("[fortran]"))
	{
	    //+++[fortran]
	    s = t.readLine().remove(",");
	    
	    if (!s.contains("1")) checkBoxAddFortran->setChecked(false); 
	    else 
	    {
		checkBoxAddFortran->setChecked(true);
		s=t.readLine();
		fortranFunction->setText(s);
		s=t.readLine();
		textEditForwardFortran->clear();
		while(s.contains("[end]")==0)
		{
		    textEditForwardFortran->append(s);
		    s = t.readLine();
		}
	    }
	}
	else
	{
	    checkBoxAddFortran->setChecked(false); 
	    fortranFunction->setText("");
	    textEditForwardFortran->clear();
	}
	
    }
    f.close();
    
    radioButtonCPP->setText(lineEditFunctionName->text()+".cpp");
    radioButtonFIF->setText(lineEditFunctionName->text()+".fif");
    updateFiles2();
}

//*******************************************
//+++  make CPP file
//*******************************************
void compile10::makeCPP()
{
    QString fn=pathFIF+"/"+lineEditFunctionName->text().stripWhiteSpace()+".cpp";
    
    if (lineEditFunctionName->text().stripWhiteSpace()=="") 
    {
	QMessageBox::warning(this,tr("QtKws"), tr("Error: <p> Fill Function name!"));
	return;
    }
    saveAsCPP(fn);
    
}

//*******************************************
//+++  make BAT file
//*******************************************
void compile10::makeBATnew()
{
    //+++ extension
    QString ext="";
#if defined(Q_OS_WIN)
    ext=".dll";
#elif defined(Q_OS_MAC)
    ext=".dylib";
#else
    ext=".so";
#endif
    
    //+++ 2D or 1D
    if (radioButton2D->isChecked()) ext+="2d";
    
    pathFIF=fitPath->text();
    pathMinGW=mingwPathline->text();
    pathGSL=gslPathline->text();
    
    QString fn=pathFIF+"/BAT.BAT";
    
    QString text; // body
    QString fortranText=""; // fortran o-file
    
    QString compileFlags=lineEditCompileFlags->text();
    QString linkFlags=lineEditLinkFlags->text();
    
    text ="";
    
    

#if defined(Q_OS_WIN)
    fn=fn.replace("\/","\\");
    pathFIF=pathFIF.replace("\/","\\");
    pathMinGW=pathMinGW.replace("\/","\\");
    pathGSL=pathGSL.replace("\/","\\");
    
    if (pathFIF.contains(":"))
    {
	text=text+pathFIF.left(pathFIF.find(":")+1)+"\n";
    }
    
    
    text=text+"cd "+"\""+pathFIF+"\""+"\n";
    
    //+++ %COMPILER%
    
    text=text+"set MINGW_IN_SHELL=1\n";
    if (checkBoxCompilerLocal->isChecked()) 
    {
	// 2012-09-20  text=text+"set COMPILER="+"\""+pathMinGW+"\""+"\n";
	text=text+"set COMPILER="+pathMinGW+"\n";
	text=text+"set PATH=%COMPILER%/bin;%PATH%\n";	
    }
    
    //+++ %GSL%
    if (checkBoxGSLlocal->isChecked()) 
    {
	text=text+"set GSL="+"\""+pathGSL+"\""+"\n";
    }
	
	
    
    compileFlags=compileFlags.replace("$GSL","%GSL%");
    linkFlags=linkFlags.replace("$GSL","%GSL%");
    
#else
    text=text+"cd "+pathFIF+"\n";  
    //+++ $COMPILER
    if (checkBoxCompilerLocal->isChecked()) 
    {	
	text=text+"export COMPILER="+"\""+pathMinGW+"\""+"\n";
	text=text+"export PATH=$COMPILER/bin:$PATH\n";
    }
    
    //+++ $GSL
    if (checkBoxGSLlocal->isChecked()) 
    {
	text=text+"export GSL="+"\""+pathGSL+"\""+"\n";
    }
    
#endif
    
    text =text+ compileFlags+" "+lineEditFunctionName->text().stripWhiteSpace()+".cpp\n";
    
    if (checkBoxAddFortran->isChecked()) 
    {
	 QString gfortranlib="";

#if defined(Q_OS_WIN)
	text =text+ compileFlags+" "+"\""+fortranFunction->text()+"\""+" -o "+"\""+"fortran.o"+"\""+" \n";
#elif defined(Q_OS_MAC)
	compileFlags=compileFlags.replace("g++ ","gfortran -arch i386 ");
	text =text+ compileFlags+"  "+fortranFunction->text()+" -o "+"fortran.o"+"\n";
	text=text+"gfortranPath=\"$(dirname `gfortran --print-file-name libgfortran.a`)\"; gfortranPath=${gfortranPath%x*4}\n";
	gfortranlib=" $gfortranPath/i386/libgfortran.a ";
#else
	text =text+ compileFlags+"  "+fortranFunction->text()+" -o "+"fortran.o"+"\n";
#endif
	fortranText=gfortranlib+"fortran.o";
    }
    
    linkFlags=linkFlags.replace(" -o","  -o " +lineEditFunctionName->text().stripWhiteSpace()+ext+"  " +lineEditFunctionName->text().stripWhiteSpace()+".o" +fortranText);
    text =text+ linkFlags+"  ";
    
    text =text+"\n";

    if (checkBoxAddFortran->isChecked()) 
    {
#if defined(Q_OS_WIN)
    text =text+ "del "+"\""+"fortran.o"+"\""+" \n ";
#else
        text =text+ "rm "+"fortran.o\n";
#endif
    }
    
#if defined(Q_OS_WIN)
    text =text+"del "+lineEditFunctionName->text().stripWhiteSpace()+".o\n" ;
    text.replace("/","\\");
#else
    text =text+ "rm "+lineEditFunctionName->text().stripWhiteSpace()+".o\n" ;    
#endif    
      
    QFile f(fn);
    if ( !f.open( IO_WriteOnly ) )
    {
	QMessageBox::critical(0, tr("QtiKWS - File Save Error"),
			      tr("Could not write to file: <br><h4> %1 </h4><p>Please verify that you have the right to write to this location!").arg(fn));
	return;
    }
    QTextStream t( &f );
    t.setEncoding(QTextStream::UnicodeUTF8);
    t << text;
    f.close();
    
    if ( radioButtonBAT->isChecked() )
    {
	tableCPP->setNumRows(0);
	QStringList lst=QStringList::split("\n",text,true);
	tableCPP->setNumRows(lst.count());
	for (int ii=0; ii<lst.count();ii++) tableCPP->setText(ii,0,lst[ii]);
    }
   
}


void compile10::readFromStdout()
{    
    QString s=procc->readStderr();    
    	
    compileOK=TRUE;
    
    QStringList lst;
    lst =QStringList::split("\n",s);
        
    s="";
    for(int i=0;i<lst.count();i++) if (lst[i].contains("error:")) s+= lst[i]+"\n";
    for(int i=0;i<lst.count();i++) if (lst[i].contains("error:")) s+= lst[i]+"\n";
    
    s=s.replace("‘","`").replace("’","'");
    
    toResLog( s);
    
    if (s.contains("error:"))
    {
	compileOK=false;
    }
    
}

void compile10::compileSingleFunction()
{
    boolCompileAll=false;
    makeDLL();
}

//*******************************************
//+++  make dll file
//*******************************************
void compile10::makeDLL()
{
#ifdef Q_OS_WIN
    if ( functionISbusy() )
    {
	if (!boolCompileAll)
	{
	    toResLog("\n<< compile >>\n<< compile status >>  ERROR: Function is now active in Fit::Curves!\n");    
	    app(this)->actionShowLog->setOn(true);
	    app(this)->results->scrollToBottom();
	}
	return;
    }
#endif    
    //+++
    QString ext="";
    if (radioButton2D->isChecked()) ext="2d";
    
    if (pushButtonSave->isEnabled()) 
    {
	makeFIF();
    }
    else
    {
	//toResLog("Function from Standard Library");
	openFIFfileSimple();
    }
    makeCPP();
    makeBATnew();
    
    
    QDir d(pathFIF);
    
    QString file=pathFIF+"/BAT.BAT";
    d.remove(lineEditFunctionName->text().stripWhiteSpace()+".o",false);
    
#ifdef Q_OS_WIN
    d.remove(lineEditFunctionName->text().stripWhiteSpace()+".dll"+ext,false);
#elif defined(Q_OS_MAC)
    d.remove(lineEditFunctionName->text().stripWhiteSpace()+".dylib"+ext,false);    
#else
    d.remove(lineEditFunctionName->text().stripWhiteSpace()+".so"+ext,false);
#endif 
    
#ifndef Q_OS_WIN
    //+++ +++ chmod 777 file +++ +++++++++++++++++++++++++++
    QProcess *proc = new QProcess( qApp);
    proc->addArgument( "chmod" );
    proc->addArgument( "777" );
    proc->addArgument( file );
    
    if ( !proc->start() ) 
    {
	QMessageBox::critical(0, tr("QtiKWS"),
			      tr("chmod 777 %1 has problem!").arg(file));
    }	
    //+++++++++++++++++++++++++++++++++++++++++++++++
#endif 
    
    procc = new QProcess(qApp);
    procc->addArgument(file);
    
    if (!boolCompileAll) toResLog("\n<< compile >>\n");    
    
    connect( procc, SIGNAL(readyReadStderr ()), this, SLOT(readFromStdout()) );
    connect( procc, SIGNAL(processExited ()), this, SLOT(processFinished()) );
 
    if ( !procc->start() ) 
    {
	if (!boolCompileAll) toResLog("<< compile-output >> !!! ERROR!!!\n");
    }
    
    
    bool OK=false;
    
    
    if (d.exists(lineEditFunctionName->text().stripWhiteSpace()+".o"+ext)) 
    {
	OK=true;
	d.remove(lineEditFunctionName->text().stripWhiteSpace()+".o"+ext,false);
    } 
    
    
}

//*******************************************
//+++  make dll file
//*******************************************
void compile10::compileTest()
{
#ifdef Q_OS_WIN
    if ( functionISbusy() )
    { 
	toResLog("\n<< compile >>\n<< compile status >>  ERROR: Function is now active in Fit::Curves!\n");
	
	app(this)->actionShowLog->setOn(true);
	app(this)->results->scrollToBottom();
	return;
    }
#endif    
    //+++
    QString ext="";
    if (radioButton2D->isChecked()) ext="2d";
  
    QDir d(pathFIF);
    
    QString file=pathFIF+"/BAT.BAT";
    d.remove(lineEditFunctionName->text().stripWhiteSpace()+".o",false);
    
#ifdef Q_OS_WIN
    d.remove(lineEditFunctionName->text().stripWhiteSpace()+".dll"+ext,false);
#elif defined(Q_OS_MAC)
    d.remove(lineEditFunctionName->text().stripWhiteSpace()+".dylib"+ext,false);    
#else
    d.remove(lineEditFunctionName->text().stripWhiteSpace()+".so"+ext,false);
#endif 
    
#ifndef Q_OS_WIN
    //+++ +++ chmod 777 file +++ +++++++++++++++++++++++++++
    QProcess *proc = new QProcess( qApp);
    proc->addArgument( "chmod" );
    proc->addArgument( "777" );
    proc->addArgument( file );
    
    if ( !proc->start() ) 
    {
	QMessageBox::critical(0, tr("QtiKWS"),
			      tr("chmod 777 %1 has problem!").arg(file));
    }	
    //+++++++++++++++++++++++++++++++++++++++++++++++
#endif 
    
    procc = new QProcess(qApp);
    
    procc->addArgument(file);
    
    toResLog("\n<< compile >>\n");    
    
    connect( procc, SIGNAL(readyReadStderr ()), this, SLOT(readFromStdout()) );
    connect( procc, SIGNAL(processExited ()), this, SLOT(processFinished()) );
 
    if ( !procc->start() ) 
    {
	toResLog("<< compile-output >> !!! ERROR!!!\n");
    }	
    
    
    bool OK=false;
    
    
    if (d.exists(lineEditFunctionName->text().stripWhiteSpace()+".o"+ext)) 
    {
	OK=true;
	d.remove(lineEditFunctionName->text().stripWhiteSpace()+".o"+ext,false);
    } 
    
    
}


//*******************************************
//+++  save FIF file /slot
//*******************************************
void compile10::makeFIF()
{
    
    //+++
    QString fifExt=".";
    if (radioButton2D->isChecked()) fifExt+="2d";
    fifExt+="fif";
    
    QString nameOld=listBoxFunctions->currentText()+fifExt;		
    //+++
    QString fn=pathFIF+"/"+lineEditFunctionName->text().stripWhiteSpace()+fifExt;
    save(fn,false);
    
    //+++
    QString group=lineEditGroupName->text().stripWhiteSpace();
    QString name=lineEditFunctionName->text().stripWhiteSpace()+fifExt;		
    if (nameOld!=name)
    {
	scanGroups();
	listBoxGroup->setCurrentItem(listBoxGroup->findItem(group,Qt::ExactMatch));
	listBoxFunctions->setCurrentItem(listBoxFunctions->findItem(name.remove(fifExt),Qt::ExactMatch));
    }
}

//*******************************************
//+++ save as FIF file /slot
//*******************************************
void compile10::saveasFIF()
{
    //+++
    QString fifExt=".";
    QString filter;
    
    if (radioButton1D->isChecked())
    {
	filter = tr("QtiKWS function") + " (*.fif);;";	
    }
    else
    {
	filter = tr("QtiKWS 2D-function") + " (*.2dfif);;";	
	fifExt+="2d";
    }	
    
    fifExt+="fif";
    
    filter += tr("C++ function") + " (*.cpp);;";
    //+++
    QString selectedFilter;
    QString fn = QFileDialog::getSaveFileName( pathFIF + lineEditGroupName->text().stripWhiteSpace(), filter, this, 0,
					       tr("Save Window As"), &selectedFilter, false);
    
    QFileInfo fi(fn);
    QString baseName = fi.fileName();	
    if (!baseName.contains("."))
    {
	if (selectedFilter.contains(fifExt)) save(fn+fifExt, true);
	else if (selectedFilter.contains("C++ function")) saveAsCPP(fn+".cpp");
	
    }
    
    
}

//*******************************************
//+++  save FIF file /function
//*******************************************
void compile10::save( QString fn, bool askYN )
{
    int i;
    QString text;
    
    if (spinBoxP->value()==0)
    {
	QMessageBox::warning(this,tr("QtKws"), tr("Error: <p> Check function!"));
	return;
    }	
    
    if (lineEditFunctionName->text().stripWhiteSpace()=="") 
    {
	QMessageBox::warning(this,tr("QtKws"), tr("Error: <p> Fill Function name!"));
	return;
    }
    
    
    if (askYN && QFile::exists(fn) &&  QMessageBox::question(this, tr("QtiKWS -- Overwrite File? "), tr("A file called: <p><b>%1</b><p>already exists.\n"   "Do you want to overwrite it?").arg(fn), tr("&Yes"), tr("&No"),QString::null, 0, 1 ) ) return;
    
    else
    {
	text+="[group]";
	
	if (checkBoxEfit->isChecked()) text+=" [eFit]";
	if (checkBoxWeight->isChecked()) text+=" [Weight] "+QString::number(comboBoxWeightingMethod->currentItem());
	if (checkBoxAlgorithm->isChecked()) text+=" [Algorithm] "+QString::number(comboBoxFitMethod->currentItem());
	if (checkBoxSuperpositionalFit->isChecked()) text+=" [Superpositional] "+QString::number(spinBoxSubFitNumber->value())+" "+QString::number(spinBoxSubFitCurrent->value());
	
	text+="\n";
	
	text+=lineEditGroupName->text().stripWhiteSpace();
	text+="\n\n";
	
	text+="[name]\n";
	text+=lineEditFunctionName->text().stripWhiteSpace();
	text+="\n\n";
	
	text+="[number parameters]\n";
	text+=QString::number(spinBoxP->value())+",";
	text+="\n\n";
	
	text+="[description]\n";
	text+=textEditDescription->text();
	text+="\n\n";
	
	text+="[x]\n";	
	text+=lineEditXXX->text().remove(" ");
	text+="\n\n";
	
	text+="[y]\n";
	if (lineEditY->text().stripWhiteSpace()!="") text+=lineEditY->text().stripWhiteSpace(); else text+="I";
	text+="\n\n";
	
	text+="[parameter names]\n";
	i=0;
	if (spinBoxP->value()>1) 
	{
	    for(i=0;i<(spinBoxP->value()-1);i++)
	    {
		if (tableParaNames->text(i,0)=="") tableParaNames->setText(i,0, "P"+QString::number(i+1));
		text=text+tableParaNames->text(i,0).stripWhiteSpace()+','; 
	    }
	}
	if (tableParaNames->text(i,0)=="") tableParaNames->setText(i,0, "P"+QString::number(i+1));
	text=text+tableParaNames->text(i,0).stripWhiteSpace()+','; 
	text+="\n\n";
	
	text+="[initial values]\n";
//	for(i=0;i<(spinBoxP->value()-1);i++) text=text+QString::number(tableParaNames->text(i,1).toDouble())+',';
//	text+=QString::number(tableParaNames->text(i,1).toDouble());
	for(i=0;i<(spinBoxP->value()-1);i++) 
	{
	    QString sCurrent=tableParaNames->text(i,1);
	    if (sCurrent.contains('[') && sCurrent.contains("..") && sCurrent.contains(']'))
		text=text+sCurrent.remove(" ")+',';
	    else
		text=text+QString::number(tableParaNames->text(i,1).toDouble())+',';
	}
	QString sCurrent=tableParaNames->text(i,1);
	if (sCurrent.contains('[') && sCurrent.contains("..") && sCurrent.contains(']'))	    
	    text+=sCurrent.remove(" ");
	else
	    text+=QString::number(tableParaNames->text(i,1).toDouble());   
	text+="\n\n";
	
	text+="[adjustibility]\n";
	for(i=0;i<(spinBoxP->value()-1);i++) 
	{
	    QCheckTableItem *adjust = (QCheckTableItem *)tableParaNames->item(i,2);			
	    if (adjust->isChecked()) text=text+'1'+','; else text=text+'0'+','; 
	}
	QCheckTableItem *adjust = (QCheckTableItem *)tableParaNames->item(i,2);			
	if (adjust->isChecked()) text=text+'1'; else text=text+'0'; 
	text+="\n\n";
	
	text+="[parameter description]\n";
	i=0;
	if (spinBoxP->value()>1) 	
	{
	    for(i=0;i<(spinBoxP->value()-1);i++) 
	    {
		if (tableParaNames->text(i,3).stripWhiteSpace()=="") tableParaNames->setText(i,3,"---");
		text=text+tableParaNames->text(i,3)+",";
	    }
	}
	if (tableParaNames->text(i,3).stripWhiteSpace()=="") tableParaNames->setText(i,3,"---");
	text=text+tableParaNames->text(i,3)+",";
	text+="\n\n";
	
	text+="[h-headers]\n";
	text+=textEditHFiles->text();
	text+="\n\n";
	
	text+="[included functions]\n";
	text+=textEditFunctions->text();
	text+="\n\n";
	
	text+="[code]\n";
	text+=textEditCode->text();
	text+="\n\n";
	
	text+="[fortran]\n";
	if (checkBoxAddFortran->isChecked()) text+="1,"; else text+="0,";
	text+="\n";
	text+=fortranFunction->text();
	text+="\n";
	text+=textEditForwardFortran->text();
	text+="\n\n";
	
	text+="[end]";
	
	QFile f(fn);
	if ( !f.open( IO_WriteOnly ) )
	{
	    QMessageBox::critical(0, tr("QtiPlot - File Save Error"),
				  tr("Could not writ<e to file: <br><h4> %1 </h4><p>Please verify that you have the right to write to this location!").arg(fn));
	    return;
	}
	QTextStream t( &f );
	t.setEncoding(QTextStream::UnicodeUTF8);
	t << text;
	f.close();	
	
	if ( radioButtonFIF->isChecked() )
	{
	    tableCPP->setNumRows(0);
	    QStringList lst=QStringList::split("\n",text,true);
	    tableCPP->setNumRows(lst.count());
	    for (int ii=0; ii<lst.count();ii++) tableCPP->setText(ii,0,lst[ii]);
	}
    }
}


//*******************************************
//+++  save Test
//*******************************************
void compile10::saveTest()
{
    if (radioButtonFIF->isChecked()) return;
    if (radioButtonCPP->text()=="*.cpp") return;
    
    QString fn;
    if (radioButtonCPP->isChecked()) fn=radioButtonCPP->text();
    if (radioButtonBAT->isChecked()) fn=radioButtonBAT->text();
    fn=fitPath->text()+"/"+fn;
    
    QString text;
    
    for(int i=0;i<tableCPP->numRows();i++) text+=tableCPP->text(i,0)+"\n";
    
    QFile f(fn);
    if ( !f.open( IO_WriteOnly ) )
    {
	QMessageBox::critical(0, tr("QtiPlot - File Save Error"),
			      tr("Could not writ<e to file: <br><h4> %1 </h4><p>Please verify that you have the right to write to this location!").arg(fn));
	return;
    }
    QTextStream t( &f );
    t.setEncoding(QTextStream::UnicodeUTF8);
    t << text;
    f.close();	
}

//*******************************************
//+++  delete FIF file
//*******************************************
void compile10::deleteFIF()
{
    
    //+++
    QString fifExt=".";
    if (radioButton2D->isChecked()) fifExt+="2d";
    fifExt+="fif";
    
    QString fn=listBoxFunctions->currentText().stripWhiteSpace()+fifExt;
    if (fn=="") return;
    
    if ( QMessageBox::question(this, tr("QtiKWS::Delete Function? "), tr( "Do you want to delete Function %1?").arg(fn), tr("&Yes"), tr("&No"),QString::null, 0, 1 ) ) return;
    
    QDir d(pathFIF );
    d.remove(fn,true);
    d.remove(fn.remove(fifExt,false)+".cpp",true);	
    
    QString group=lineEditGroupName->text().stripWhiteSpace();
    
    scanGroups();
    if (listBoxGroup->findItem(group,Qt::ExactMatch)) listBoxGroup->setCurrentItem(listBoxGroup->findItem(group,Qt::ExactMatch));
    //remove dll
    d.remove(fn.remove(fifExt,false)+".dll",true);	
    d.remove(fn.remove(fifExt,false)+".so",true);
    d.remove(fn.remove(fifExt,false)+".dylib",true);
    
    newFIF();
    
    listBoxGroup->setCurrentItem(listBoxGroup->findItem(group,true));
}

//*******************************************
//+++  delete FIF file
//*******************************************
void compile10::deleteIncluded()
{
    
    //+++    
    QString fn=listBoxIncludeFunctions->currentText().stripWhiteSpace();
    if (fn=="") return;
    
    if ( QMessageBox::question(this, tr("QtiKWS::Delete Included Function? "), tr( "Do you want to delete Included Function %1?").arg(fn), tr("&Yes"), tr("&No"),QString::null, 0, 1 ) ) return;
    
    QDir d(pathFIF+"/IncludedFunctions" );
    d.remove(fn,true);
    scanIncludedFunctions();
}

//*******************************************
//+++  make Included
//*******************************************
void compile10::makeIncluded()
{
    QString fn = QFileDialog::getSaveFileName(
	    fitPath->text()+"/IncludedFunctions/",
	    "Headers (*.h)",
	    this,
	    "Create header file with Included Functions",
	    "Choose a filename to save under" );
    
    fn.remove(".cpp");
    fn.remove(".c");
    fn.remove(".c++");
    
    if (!fn.contains(".h")) fn+=".h";

    if (saveAsIncluded(fn))
    {
	textEditFunctions->setText("");
	textEditHFiles->setText("");
	addIncludedFunction(fn.remove(pathFIF+"/IncludedFunctions/"));	
    }
}

void compile10::addHeaderFile()
{
    QString fn=listBoxIncludeFunctions->currentText();
    
    if (fn!="") addIncludedFunction( fn );
}
//*******************************************
//+++ add Included Functions
//*******************************************
void compile10::addIncludedFunction( const QString &fn )
{
    
    //+++
    if (!QFile::exists (pathFIF+"/IncludedFunctions/"+fn))
    {
	scanIncludedFunctions();
	return;
    }
    
    if (fn.contains(".h") || fn.contains(".cpp"))
    {
	QString sss="#include ";
	sss+="\"";
	sss+="IncludedFunctions/"+fn;
	sss+="\"";
	sss+="\n";
	
	if (!textEditHFiles->text().contains(sss))
	    textEditHFiles->append(sss);
//	else openInNote(fn);	
	
    }

}

void compile10::parseOrigin(QStringList lst)
{
    QStringList lstBlockName, lstBlock;
    
    QString currentBody;
    int numberBlocks=0;
    for (int i=0; i<lst.count();i++)
    {
//toResLog(lst[i]);
	if (lst[i].left(1)=="[" && lst[i].contains("]"))
	{
	    lstBlockName<<lst[i].left(lst[i].find("]")+1);
	    numberBlocks++;
	    if (numberBlocks>1) lstBlock<<currentBody;
	    currentBody="";
	}
	if (i==(lst.count()-1))
	{
	    if (numberBlocks>1) lstBlock<<currentBody;
	    currentBody="";
	}
	currentBody+=lst[i]+"\n";  
    }
    
    int blockLocated;
    QString s;
    QStringList lstBody; 
    // [General Information]
    blockLocated=-1;
    lstBody.clear();
    s="";
    for (int i=0; i<lstBlockName.count();i++) 
    {
	if (lstBlockName[i].contains("[General Information]",false)) blockLocated=i;
    }
    if (blockLocated<0) return;
    lstBody=QStringList::split("\n",lstBlock[blockLocated]);
  
    QString fName, fDescription, fSource, fType, fForm, fNumberOfParameters, fNumberIndVars, fNumberDepVars;
    for (int j=0; j<lstBody.count();j++) 
    {
	if (lstBody[j].contains("Function Name=",false)) 
	{
	    s=lstBody[j];
	    if (s.contains(";")) s=s.left(s.find(";"));
	    s=s.right(s.length()-s.find("=")-1);
	    fName=s;
	}
	if (lstBody[j].contains("Brief Description=",false)) 
	{
	    s=lstBody[j];
	    if (s.contains(";")) s=s.left(s.find(";"));
	    s=s.right(s.length()-s.find("=")-1);
	    fDescription=s;
	}
	if (lstBody[j].contains("Function Source=",false)) 
	{
	    s=lstBody[j];
	    if (s.contains(";")) s=s.left(s.find(";"));
	    s=s.right(s.length()-s.find("=")-1);
	    fSource=s;
	}
	if (lstBody[j].contains("Function Type=",false)) 
	{
	    s=lstBody[j];
	    if (s.contains(";")) s=s.left(s.find(";"));
	    s=s.right(s.length()-s.find("=")-1);
	    fType=s;
	}
	if (lstBody[j].contains("Function Form=",false)) 
	{
	    s=lstBody[j];
	    if (s.contains(";")) s=s.left(s.find(";"));
	    s=s.right(s.length()-s.find("=")-1);
	    fForm=s;
	}
	if (lstBody[j].contains("Number Of Parameters=",false)) 
	{
	    s=lstBody[j];
	    if (s.contains(";")) s=s.left(s.find(";"));
	    s=s.right(s.length()-s.find("=")-1);
	    fNumberOfParameters=s;
	}
	if (lstBody[j].contains("Number Of Independent Variables=",false)) 
	{
	    s=lstBody[j];
	    if (s.contains(";")) s=s.left(s.find(";"));
	    s=s.right(s.length()-s.find("=")-1);
	    fNumberIndVars=s;
	}
	if (lstBody[j].contains("Number Of Dependent Variables=",false)) 
	{
	    s=lstBody[j];
	    if (s.contains(";")) s=s.left(s.find(";"));
	    s=s.right(s.length()-s.find("=")-1);
	    fNumberDepVars=s;
	}
    }    
    
    
    toResLog(fName +"\n"+fDescription +"\n"+fSource +"\n"+fType +"\n"+fForm +"\n"+fNumberOfParameters +"\n"+fNumberIndVars +"\n"+fNumberDepVars);
    
    
/*



[FITTING PARAMETERS]
Naming Method=User-Defined
Names=y0, a, Wmax
Meanings=y initial value, amplitude, Maximun growth rate
Lower Bounds=0.0(X,ON),0.0(X,ON),0.0(X,ON)
Upper Bounds=--,--,--
Number Of Significant Digits=


[FORMULA]
y = a/(1 + ((a-y0)/y0)*exp(-4*Wmax*x/a))


[CONSTRAINTS]
a > y0


[Parameters Initialization]
sort( x_y_curve );
//smooth( x_y_curve, 2 );
y0 = min( y_data );
a = max( y_data );
Wmax = a / fwhm( x_y_curve );


[CONSTANTS]


[INITIALIZATIONS]



[AFTER FITTING]



[INDEPENDENT VARIABLES]
x=


[DEPENDENT VARIABLES]
y=


[CONTROLS]
General Linear Constraints=Off
Initialization Scripts=Off
Scripts After Fitting=Off
Number Of Duplicates=N/A
Duplicate Offset=N/A
Duplicate Unit=N/A

*/
}

void compile10::openOrigin(QString fdfName)
{
    //+++
    radioButton1D->setChecked(true);
    int i;
    
    
    //+++
    if (fdfName.isEmpty())
    {
	QMessageBox::warning(this,tr("QtKWS"), tr("Error: <p> File not selected"));
	return;
    }   
    
    //+++
    if (!QFile::exists (fdfName))
    {
	QMessageBox::warning(this,tr("QtKWS"), tr("Error: <p> File does not exist"));
	return;
    }
    
    spinBoxP->setValue(0);	
    
    //+++
    QFile f(fdfName);
    
    //+++
    if ( !f.open( IO_ReadOnly ) ) 
    {
	QMessageBox::critical(0, tr("QtKWS"),
tr("Could not read file: <br><h4>"+fdfName+ 
				 "</h4><p>Please verify that you have the right to read from this location!"));
	return;
    }
    
    QTextStream t( &f );
    
    QStringList lst;
    while ( !t.atEnd() ) lst << t.readLine();
    
    
    parseOrigin(lst);
    
    return;   
    
    QString s;
    bool userYN=true;
    
    //+++ Category
    lineEditGroupName->setText("Origin::Built-In");
    
    
    //+++[General Information]
    s = t.readLine();
    
    if (s.contains("[General Information]") || s.contains("[GENERAL INFORMATION]")  )
    {
	lineEditGroupName->setText("Origin::User-Defined");
	userYN=true;
    }
    else
    {
	QMessageBox::warning(this,tr("QtKWS"), tr("Error: [General Information]"));
	return;
    }
    
    
    
    int iterNumber=0;
    QString ss; 
    int pNumber=0;
    do
    {
	s = t.readLine();
	ss=s;
	
	if (s.contains("Function Name="))  
	{
	    //+++Function Name
	    ss.remove("Function Name=");
	    if (ss.contains(";")>=0)  ss=ss.left(ss.find(';')-1);
	    lineEditFunctionName->setText(ss.stripWhiteSpace());
	}
	else   if (s.contains("Brief Description="))  
	{
	    //+++Brief Description
	    ss.remove("Brief Description=");
	    
	    textEditDescription->setText(ss+"\n");
	}
	else   if (s.contains("Function Type="))
	{
	    //+++Function Type
	    if (ss.find(";")) ss=ss.left(ss.find(";"));
	    textEditDescription->append(ss+"\n");
	}
	else   if (s.contains("Function Form="))
	{
	    //+++ Function Form
	    if (ss.find(";")) ss=ss.left(ss.find(";"));
	    textEditDescription->append(ss+"\n");
	}
	else   if (s.contains("Function Source="))
	{
	    //+++ Function Source
	    textEditDescription->append(ss+"\n");
	}
	else   if (s.contains("Number Of Parameters="))
	{
	    //+++ Number Of Parameters
	    ss.remove("Number Of Parameters=");
	    spinBoxP->setValue(ss.toInt());
	    
	    if (spinBoxP->value()==0) 
	    {
		QMessageBox::warning(this,tr("QtKWS"), tr("Error: Number Of Parameters: 0"));
		return;
	    }
	    pNumber=spinBoxP->value();
	}
	else   if (s.contains("Number Of Independent Variables="))
	{
	    //+++Number Of Independent Variables
	    ss.stripWhiteSpace();
	    ss.remove("Number Of Independent Variables=");
	    
	    if (ss.toInt()!=1) 
	    {
		QMessageBox::warning(this,tr("QtKWS"), tr("Error: Number Of Independent Variables more than 1 not supported "));
		return;
	    }	
	}
	else   if (s.contains("Number Of Dependent Variables="))
	{
	    //+++ Number Of Dependent Variables
	    ss.stripWhiteSpace();
	    ss.remove("Number Of Dependent Variables=");
	    
	    if (ss.toInt()!=1) 
	    {
		QMessageBox::warning(this,tr("QtKWS"), tr("Error: Number Of Independent Variables more than 1 not supported "));
		return;
	    }	
	}
	else   if (s.contains("Analytical Derivatives for User-Defined="))
	{
	    //+++ Analytical Derivatives for User-Defined
	    textEditDescription->append(ss+"\n");
	}
	
	//+++   
	iterNumber++;
    }
    while (!s.contains("[Fitting Parameters]") && !s.contains("[FITTING PARAMETERS]") && iterNumber<33);
    
    
    //+++[Fitting Parameters]   
    iterNumber=0;   
    QStringList paraNames, paraDescription, initPara;
    
    do
    {
	s = t.readLine();
	ss=s;
	
	if (s.contains("Naming Method="))  
	{
	    //+++Naming Method
	    textEditDescription->append(ss+"\n");
	}
	else   if (s.contains("Names="))     
	{
	    ss=ss.remove("Names=");
	    paraNames=QStringList::split(",", ss, false);
	}
	else   if (s.contains("Meanings="))     
	{
	    ss=ss.remove("Meanings=");
	    paraDescription=QStringList::split(",", ss, false);
	}
	else   if (s.contains("Initial Values="))     
	{
	    ss=ss.remove("Initial Values=");
	    ss=ss.remove("(V)");
	    ss=ss.remove("(F)");
	    initPara=QStringList::split(",", ss, false);
	}
	
	
	iterNumber++;
    }
    while (!s.contains("[") && iterNumber<33);
    
    for(i=0; i<pNumber; i++) 	
    {
	//+++
	tableParaNames->setText(i,0,paraNames[i].stripWhiteSpace());
	//+++
	tableParaNames->setText(i,3,paraDescription[i].stripWhiteSpace());
	//+++
	tableParaNames->setText(i,1,initPara[i].stripWhiteSpace());
    }
    
    
    
    //+++ [FORMULA] user-defined-format
    if (s.contains("[FORMULA]"))
    {
	//+++ [FORMULA] user-defined-format
	s = t.readLine();
	
	while  (!s.contains("[CONSTRAINTS]") )
	{
	    ss=s;
	    ss=ss.stripWhiteSpace();
	    if (ss!="") 
	    {
		ss+=";\n";
		ss.replace(";;",";");
		ss.replace("; ;",";");
		ss.replace(";  ;",";");
		
		//+++ ln() to log()
		ss.replace("ln(", "log(");
		//+++ log() to log10()
		ss.replace("log(", "log10(");
		//+++ ^ to pow(,)
		if (ss.contains("^")) 
		{
		    ss.replace("^", " pow(,) ");
		    
		    ss+="// edit this line to adjust pow(,) function:  a^b=pow(a,b)";
		}
		
		
		
		textEditCode->append(ss);
		// textEditDescription->append(ss+"\n");
	    }
	    
	    s = t.readLine();
	}
    }
    
    
    while (!s.contains("[INDEPENDENT VARIABLES]") && !s.contains("[Independent Variables]") ) s = t.readLine();
    if (s.contains("[Independent Variables]")) s = t.readLine();
    s = t.readLine();
    ss=s;
    ss=ss.stripWhiteSpace();
    ss=ss.remove("=");
    //+++ x
    lineEditXXX->setText(ss);
    
    
    while (!s.contains("[DEPENDENT VARIABLES]") && !s.contains("[Dependent Variables]") ) s = t.readLine();
    if (s.contains("[Dependent Variables]")) {s = t.readLine(); userYN=false;};
    s = t.readLine();
    ss=s;
    ss=ss.stripWhiteSpace();
    ss=ss.remove("=");
    //+++ x
    lineEditY->setText(ss);
    
    
    if (!userYN)
    {
	while (!s.contains("[Formula]") ) s = t.readLine();
	//+++ [Formula] standart
	iterNumber=0;   
	s = t.readLine();
	
	while  (!s.contains("[") && iterNumber<33)
	{
	    ss=s;
	    ss=ss.stripWhiteSpace();
	    if (ss!="") 
	    {
		ss+=";";
		ss.replace(";;",";");
		ss.replace("; ;",";");
		ss.replace(";  ;",";");
		
		//+++ ln() to log()
		ss.replace("ln(", "log(");
		//+++ log() to log10()
		ss.replace("log(", "log10(");
		//+++ ^ to pow(,)
		if (ss.contains("^")) 
		{
		    ss.replace("^", " pow(,) ");
		    
		    ss+="// edit this line to adjust pow(,) function:  a^b=pow(a,b)";
		}
		
		textEditCode->append(ss);
		
		ss.remove(";");
		if (ss.find("//")) ss=ss.left(ss.find("//"));
		ss.replace( " pow(,) ","^");
		textEditDescription->insert(ss+"\n");
	    }
	    iterNumber++;
	    s = t.readLine();
	}
    }
}


void compile10::saveAsCPP( QString fn )
{
    
    //+++
    QString fifExt=".";
    if (radioButton2D->isChecked()) fifExt+="2d";
    fifExt+="fif";
    int i;
    QString text;
    
    text+="/////////////////////////////////////////////////////////////////////////////////\n";
    text+="//+++ do not change\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";		
    text+="#if defined(_WIN64) || defined(_WIN32) //MSVC Compiler\n#define MY_EXPORT __declspec(dllexport)\n#else\n#define MY_EXPORT\n#endif\n\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";
    text+="//+++ h-files\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";		
    text+="#include <math.h>\n#include <iostream>\n#include <string>\n#include <gsl/gsl_vector.h>\n#include <gsl/gsl_matrix.h>\n#include <gsl/gsl_math.h>\n";
    //+++
    for(i=0;i<textEditHFiles->paragraphs();i++) if (textEditHFiles->text(i).contains("#include")) text=text+textEditHFiles->text(i)+"\n";
    text+="using namespace std;\n";
    
    text=text+"string fitFunctionPath="+'"';
    text+=fitPath->text().ascii();
    text=text+'"' +";\n";
    text=text+"string OS="+'"';
#if defined(_WIN64) || defined(_WIN32)
    text+="WINDOWS";
#elif defined(Q_OS_MAC)
    text+="MAC";
#else 
    text+="LINUX";
#endif
		text=text+'"' +";\n";
    //+++ NEW matrix v10
    if (radioButton2D->isChecked())
    {
	text+="\n/////////////////////////////////////////////////////////////////////////////////\n";
	text+="//+++ N-Dimensional Function Structure\n";
	text+="/////////////////////////////////////////////////////////////////////////////////\n";	

	text+="#ifndef  NDFUNCTION_H\n#define NDFUNCTION_H\n\n";
	
	text+="struct functionND\n{\n";
	
	text+="double *Q;\n";
	text+="gsl_vector *para;\n";        
	text+="size_t xNumber;\n";
	text+="size_t yNumber;\n";
	
	text+="size_t *Rows;\n";
	text+="size_t *Columns;\n";
	
	
	text+="gsl_matrix *I;\n";
	text+="gsl_matrix *dI;\n";
	text+="gsl_matrix *mask;\n";
	text+="gsl_matrix *xMatrix;\n";   
	
	text+="bool beforeFit;\n";
	text+="bool afterFit;\n";
	text+="bool beforeIter;\n";
	text+="bool afterIter;\n";   
	text+="int prec;\n";
	
	text+="std::string tableName;\n";
	text+="std::string *tableColNames;\n";
	text+="int *tableColDestinations;\n";
	text+="gsl_matrix *mTable;\n";	
	
	text+="};\n\n#endif\n ";
	
	//+++
	text+="\n/////////////////////////////////////////////////////////////////////////////////\n";
	text+="//+++ Function returns list of x-Names\n";
	text+="/////////////////////////////////////////////////////////////////////////////////\n";	
	text=text+"extern " +'"'+"C"+'"'+" MY_EXPORT char *xName()\n{\n\treturn "+'"';
	text+=lineEditXXX->text();
	text=text+'"'+";\n}\n\n";
    }
    else
    {
    	text+="\n/////////////////////////////////////////////////////////////////////////////////\n";
	text+="//+++ Parameters Structure\n";
	text+="/////////////////////////////////////////////////////////////////////////////////\n";	

	text+="#ifndef  TFUNCTION_H\n#define TFUNCTION_H\n\n";
	
	text+="struct functionT\n{\n";
	
	text+="gsl_vector *para;\n";

	text+="double *Q;\n";
	text+="double *I;\n";
	text+="double *SIGMA;\n";	
	
	text+="int currentFirstPoint;\n";
	text+="int currentLastPoint;\n";
	text+="int currentPoint;\n";

	text+="bool polyYN;\n";
	text+="int polyFunction;\n";
		
	text+="bool beforeFit;\n";
	text+="bool afterFit;\n";
	text+="bool beforeIter;\n";
	text+="bool afterIter;\n";   
	text+="double Int1;\n";   
	text+="double Int2;\n";
	text+="double Int3;\n";   
	text+="int currentInt;\n";   	
	text+="int prec;\n";
		
	text+="std::string tableName;\n";
	text+="std::string *tableColNames;\n";
	text+="int *tableColDestinations;\n";
	text+="gsl_matrix *mTable;\n";	
	
	text+="};\n\n#endif\n ";
	
    }
    
	text+="\n/////////////////////////////////////////////////////////////////////////////////\n";
	text+="//+++ Rounding of doubles to selected precition\n";
	text+="/////////////////////////////////////////////////////////////////////////////////\n";
	text+="double round2prec(double f, int prec)\n{\n";
	text+="if(f==0.0) return 0.0;\ndouble sign=1.0; if (f<0.0) sign=-1.0;\n";
	text+="f=fabs(f);\nif (f>1.0) prec--;\nprec=prec-(int)log10(f);\n\n";
	text+="if (prec<0)  return sign*double(rint(f / pow(10,fabs(prec))))*pow(10,fabs(prec));\n";
	text+="else return sign*double(rint(f * pow(10,prec)))/pow(10,prec);\n}\n";
	
	//+++
    text+="\n/////////////////////////////////////////////////////////////////////////////////\n";
    text+="//+++ Function returns Name of Function\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";	
    text=text+"extern " +'"'+"C"+'"'+" MY_EXPORT char *name()\n{\n\treturn "+'"';
    text+=lineEditFunctionName->text();
    text=text+'"'+";\n}\n\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";
    text+="//+++ Function return List of names of Parameters \n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";		
    text=text+"extern " +'"'+"C"+'"'+" MY_EXPORT char *parameters()\n{\n\treturn "+'"';
  
    text=text+tableParaNames->text(0,0).stripWhiteSpace();
    
    for(i=1;i<spinBoxP->value();i++) text=text+','+tableParaNames->text(i,0).stripWhiteSpace();
   
    if (!radioButton2D->isChecked() ) 
	text=text+','+lineEditXXX->text().stripWhiteSpace();	
 
    text=text+'"'+";\n}\n\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";
    text+="//+++ Initial value of Parameters  \n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";		
    text=text+"extern " +'"'+"C"+'"'+" MY_EXPORT char *init_parameters()\n{\n\treturn "+'"';
    
//    for(i=0;i<(spinBoxP->value()-1);i++) text=text+QString::number(tableParaNames->text(i,1).toDouble())+',';
//   text=text+QString::number(tableParaNames->text(i,1).toDouble());
    

    for(i=0;i<(spinBoxP->value()-1);i++) 
    {
	QString sCurrent=tableParaNames->text(i,1);
	if (sCurrent.contains('[') && sCurrent.contains("..") && sCurrent.contains(']'))
	    text=text+sCurrent.remove(" ")+',';
	else
	    text=text+QString::number(tableParaNames->text(i,1).toDouble())+',';
    }
    
    QString sCurrent=tableParaNames->text(i,1);
    if (sCurrent.contains('[') && sCurrent.contains("..") && sCurrent.contains(']'))	    
	text+=sCurrent.remove(" ");
    else
	text+=QString::number(tableParaNames->text(i,1).toDouble());  
    
    text=text+'"'+";\n}\n\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";
    text+="//+++ Initial 'Adjustibility' of Parameters  \n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";		
    text=text+"extern " +'"'+"C"+'"'+" MY_EXPORT char *adjust_parameters()\n{\n\treturn "+'"';
    for(i=0;i<(spinBoxP->value()-1);i++) 
    {
	QCheckTableItem *adjust = (QCheckTableItem *)tableParaNames->item(i,2);			
	if (adjust->isChecked()) text=text+'1'+','; else text=text+'0'+','; 
    }
    QCheckTableItem *adjust = (QCheckTableItem *)tableParaNames->item(i,2);			
    if (adjust->isChecked()) text=text+'1'; else text=text+'0'; 
    text=text+'"'+";\n}\n\n";		
    text+="/////////////////////////////////////////////////////////////////////////////////\n";
    text+="//+++ Number of parameters\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";	
    text=text+"extern " +'"'+"C"+'"'+" MY_EXPORT char *paraNumber()\n{\n\treturn "+'"';
    text+=QString::number(spinBoxP->value());
    text=text+'"'+";\n}\n\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";
    text+="//+++ Description of Function and parameters\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";	
    text=text+"extern " +'"'+"C"+'"'+" MY_EXPORT char *listComments()\n{\n ";
    text+="\tchar  *list;\n\tlist=";		
    //+++
    QString htmlText=textEditDescription->text().remove("\n").replace("\\;", "\\\\ \\\\;");
    
    //	htmlText.replace("\\"+'\\"', "\\"+"\\ \\"+'"');
    QString richText;
    uint nChars=htmlText.length();
    for (i=0;i<nChars;i++)
    {
	if (htmlText[i]=='"') richText+=" \\";
	richText+=htmlText[i];
    }
    richText.replace("\\ ", "\\\\ ");
    richText.replace("\\\\\\", "\\\\");
    
    if (richText=="") richText="---";
    
    text=text+'"'+richText+'"'+"\n"; 
    
    text=text+"\t\t\t"+'"';
    for(i=0;i<spinBoxP->value();i++) text=text+",,"+tableParaNames->text(i,3);
    text=text+'"'+";\n\treturn list;\n}\n\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";
    text+="//+++ Included Functions\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n\n";	
        
    text+=textEditFunctions->text();	
    
    if (checkBoxAddFortran->isChecked())
    {
	text+="\n/////////////////////////////////////////////////////////////////////////////////\n";
	text+="//+++ Forward Declaration Fortran Functions\n";
	text+="/////////////////////////////////////////////////////////////////////////////////\n";
	text=text+"extern "+'"'+"C"+'"'+" \n{\n";
	text=text+textEditForwardFortran->text()+"\n}\n\n";
    }
    
    text+="\n\n/////////////////////////////////////////////////////////////////////////////////\n";
    text+="//+++ Fit Function\n";
    text+="/////////////////////////////////////////////////////////////////////////////////\n";	
    text=text+"extern "+'"'+"C"+'"'+" MY_EXPORT double functionSANS(double key";    
    
    
    if (radioButton2D->isChecked() ) 
    {
	text=text+", void * ParaM)\n{\n//+++\ngsl_vector *Para\t=((struct functionND *) ParaM)->para;\n";
	text=text+"double *xxxx\t=((struct functionND *) ParaM)->Q;\n";
	

	QStringList lst=QStringList::split(",", lineEditXXX->text().remove(" "));
	    
	text=text+"double "+lst[0]+"\t\t=1.0 + xxxx[0];\n";
	text=text+"double "+lst[1]+"\t\t=1.0 + xxxx[1];\n";
	
	for (int i=2; i<spinBoxXnumber->value(); i++)
	    text=text+"double "+lst[i]+"\t\t= xxxx["+QString::number(i)+"];\n";
	
	for(i=0;i<spinBoxP->value();i++)
	{
	    text=text+"double "+tableParaNames->text(i,0).stripWhiteSpace()+"\t\t=gsl_vector_get(Para,"+QString::number(i)+");\n";
	}
    
    text=text+"int prec\t=((struct functionND *) ParaM)->prec;\n//+++\n";
    
    }
    else
    {
	text=text+", void * ParaM)\n{\n//+++\ngsl_vector *Para\t=((struct functionT *) ParaM)->para;\n";
	for(i=0;i<spinBoxP->value();i++)
	{
	    text=text+"double "+tableParaNames->text(i,0).stripWhiteSpace()+"\t\t=gsl_vector_get(Para, "+QString::number(i)+");\n";
	}
	
	text=text+"//+++\ndouble\t" +lineEditXXX->text().remove(" ")+"=key;\n";
	text=text+"int prec\t=((struct functionT *) ParaM)->prec;\n//+++\n";
	

    }
    
    
    text=text+"double\t" +lineEditY->text().stripWhiteSpace()+";\n\n//+++++++++++++++++++++++++++++++++++++++++++++\n";
  
    //+++
    text=text+"gsl_set_error_handler_off();";    
    text=text+"\n//+++++++++++++++++++++++++++++++++++++++++++++\n\n";
    text+=textEditCode->text();
    text=text+"\n//+++++++++++++++++++++++++++++++++++++++++++++\n\n";
    if (radioButton2D->isChecked() ) 
    {
	text=text+"stop:\n";
	
	for(i=0;i<spinBoxP->value();i++)
	{
	    text=text+"gsl_vector_set(Para," +QString::number(i)+",round2prec("+tableParaNames->text(i,0).stripWhiteSpace()+",prec));\n";
	}	
    }
    else
    {
	for(i=0;i<spinBoxP->value();i++)
	{
//	    text=text+"gsl_vector_set((gsl_vector *)ParaM," +QString::number(i)+","+tableParaNames->text(i,0).stripWhiteSpace()+");\n";
	    text=text+"gsl_vector_set(Para," +QString::number(i)+",round2prec("+tableParaNames->text(i,0).stripWhiteSpace()+",prec));\n";
	}	
    }
	text=text+"\n"+"return round2prec("+lineEditY->text().stripWhiteSpace()+", prec);\n}\n";
    

    
    QFile f(fn);
    if ( !f.open( IO_WriteOnly ) )
    {
	QMessageBox::critical(0, tr("QtiKWS - File Save Error"),
			      tr("Could not write to file: <br><h4> %1 </h4><p>Please verify that you have the right to write to this location!").arg(fn));
	return;
    }	
    QTextStream t( &f );
    t.setEncoding(QTextStream::UnicodeUTF8);
    t << text;
    f.close();	
    
    if ( radioButtonCPP->isChecked() )
    {
	tableCPP->setNumRows(0);
	QStringList lst=QStringList::split("\n",text,true);
	tableCPP->setNumRows(lst.count()+1);
	for (int ii=0; ii<lst.count();ii++) tableCPP->setText(ii+1,0,lst[ii]);
    }   
}


bool compile10::saveAsIncluded( QString fn )
{
    int i;
    QString text;
    QString s=fn;
    s=s.replace(pathFIF,"").replace("IncludedFunctions","").replace('\/',"").replace(".","_").replace("-","_");
    
    if ( QFile::exists(fn) &&  QMessageBox::question(this, tr("QtiKWS -- Overwrite File? "), tr("A file called: <p><b>%1</b><p>already exists.\n"   "Do you want to overwrite it?").arg(fn), tr("&Yes"), tr("&No"),QString::null, 0, 1 ) ) return false;
    
    else
    {
	//+++
	text+="#ifndef "+s+"\n";
	text+="#define "+s+"\n\n";
	
	text+="//[Included Headers]\n";
	text+=textEditHFiles->text().remove("IncludedFunctions/")+"\n";
		
	//+++	
	text+="//[included Functions]\n";
	text+=textEditFunctions->text();	
	
	//+++
	text+="\n//[end]\n\n";
	text+="#endif\n";

	QFile f(fn);
	if ( !f.open( IO_WriteOnly ) )
	{
	    QMessageBox::critical(0, tr("QtiPlot - File Save Error"),
				  tr("Could not write to file: <br><h4> %1 </h4><p>Please verify that you have the right to write to this location!").arg(fn));
	    return false;
	}		
	QTextStream t( &f );
	t.setEncoding(QTextStream::UnicodeUTF8);
	t << text;
	f.close();	
	scanIncludedFunctions();
    }
    return true;
}


void compile10::newFIF()
{
    lineEditGroupName->clear();
    lineEditFunctionName->clear();
    
    spinBoxP->setValue(0);
    lineEditY->setText("f");
    
    stot1Dto2D();

    textEditCode->clear();
    changedFXYinfo();
//    textEditCode->setText("// --->  f = f ( "+lineEditXXX->text().remove(" ")+", {P1, ...} );");
    
    textEditDescription->clear();
    textEditDescription->setText("good place for function's comments");
    textEditHFiles->clear();
    textEditFunctions->clear();
    scanGroups();
    scanIncludedFunctions();
    
    tabWidgetCode->setCurrentPage(0);
    tableCPP->setNumRows(0);
    radioButtonBAT->setChecked(false);
    radioButtonCPP->setChecked(false); radioButtonCPP->setText("*.cpp");
    radioButtonFIF->setChecked(false); radioButtonFIF->setText("*.fif");    
    
    checkBoxAddFortran->setChecked(false);
    fortranFunction->setText("");
    textEditForwardFortran->setText("");
}


void compile10::setPath()
{
    //+++
    QString dir=pathFIF ;
    QDir dirOld(dir);
    //+++
    if (!dirOld.exists()) dirOld=QDir::homeDirPath();
    
    QDir dirNew;	
    dir = QFileDialog::getExistingDirectory(dir,this,"path to *.fif Functions"  "Choose a directory");
    
    if (dir!="") 
    {
	dirNew.setPath(dir);
	if (!dirNew.exists("/IncludedFunctions")) dirNew.mkdir(dir + "/IncludedFunctions");
	fitPath->setText(dirNew.path()); 
	pathFIF=dirNew.path();
    }	
    newFIF();
}


void compile10::pathChanged()
{
    scanGroups();
    scanIncludedFunctions();
}


void compile10::gslPath()
{
    //+++
    QString dir=pathGSL.stripWhiteSpace() ;
    QDir dirOld(dir);
    //+++
    if (!dirOld.exists()) dirOld=QDir::homeDirPath();
    
    QDir dirNew;	
    dir = QFileDialog::getExistingDirectory(dir,this,"set path to GSL directory"  "Choose a directory");
    if (dir=="") 
    {
	pathGSL="Set GSL Directory";
	gslPathline->setText("Set GSL Directory");
    }
    else
    {
	dirNew.setPath(dir);
	gslPathline->setText(dirNew.path()); 
	pathGSL=dirNew.path();
    }	
}


void compile10::mingwPath()
{ 
    //+++
    QString dir=pathMinGW.stripWhiteSpace() ;
    QDir dirOld(dir);
    //+++
    if (!dirOld.exists()) dirOld=QDir::homeDirPath();
    
    QDir dirNew;	
    dir = QFileDialog::getExistingDirectory(dir,this,"set path to MinGw->bin directory"  "Choose a directory");
    if (dir=="") 
    {
	mingwPathline->setText("set path to MinGw->bin directory");
	pathMinGW="set path to MinGw->bin directory";
    }
    else
    {
	dirNew.setPath(dir);
	mingwPathline->setText(dirNew.path()); 
	pathMinGW=dirNew.path();
    }	
    
}


void compile10::openFortranFilePath()
{
    QString filter = tr("Fortran file") + " (*.f *.F *.for *.FOR);;";	
    
    //+++
    QString fn = QFileDialog::getOpenFileName(pathFIF, filter, this, 0, "QtiKWS - Fortran - File", 0, FALSE);
    QFileInfo fi(fn);
    fortranFunction->setText(fi.fileName());
    extructFortranFunctions(fn);
}

void compile10::extructFortranFunctions(QString fileName)
{
    QFile f(fileName);
    
    
    QString s="";
    QString ss="";
    QString sFinal="";
    
    //+++
    if ( !f.open( IO_ReadOnly ) ) 
    {
	return;
    }
    else
    {
	QTextStream t( &f );

	while ( !t.atEnd() ) 
	{
	    s =t.readLine();
	    ss="";
	    if ( s.left(1)!="!" && s.left(1)!="c" && s.left(1)!="C" && s.contains("function", false) && s.contains("(") )
	    {
		if (!s.contains(")"))
		{
		    while (!s.contains(")") && !t.atEnd())
		    {
			s +=t.readLine();
		    }
		}
		s.simplifyWhiteSpace(); 
		s=s.right(s.length()-s.find("function",0, false)-8);
		ss=s.left(s.find("(")).remove(" ").remove("\n").lower(); 
		s=s.right(s.length()-s.find("(")-1);
		s=s.left(s.find(")"));
		QStringList lst=QStringList::split(",",s);
		sFinal+= "double "+ ss + "_(";
		for (int si=0; si<lst.count(); si++) sFinal+="double*,";
		if (sFinal.right(1)==",") sFinal=sFinal.left(sFinal.length()-1);
		sFinal+=");\n";
	    }
	 
	    if ( s.left(1)!="!" && s.left(1)!="c" && s.left(1)!="C" && s.contains("subroutine", false) && s.contains("(") )
	    {
		if (!s.contains(")"))
		{
		    while (!s.contains(")") && !t.atEnd())
		    {
			s +=t.readLine();
		    }
		}
		s.simplifyWhiteSpace(); 
		s=s.right(s.length()-s.find("subroutine",0, false)-10);
		ss=s.left(s.find("(")).remove(" ").remove("\n").lower(); 
		s=s.right(s.length()-s.find("(")-1);
		s=s.left(s.find(")"));
		QStringList lst=QStringList::split(",",s);
		sFinal+= "void "+ ss + "_(";
		for (int si=0; si<lst.count(); si++) sFinal+="double*,";
		if (sFinal.right(1)==",") sFinal=sFinal.left(sFinal.length()-1);
		sFinal+=");\n";
	    }
	}
	
    }
    textEditForwardFortran->setText(sFinal);
    f.close();

    
}


void compile10::textFamily( const QString &f )
{
    
    textEditDescription->setFamily( f );
    textEditDescription->viewport()->setFocus();
}


void compile10::textSize( const QString &p )
{
    textEditDescription->setPointSize( p.toInt() );
    textEditDescription->viewport()->setFocus();
}


void compile10::textBold()
{
    textEditDescription->setBold( !textEditDescription->bold());
}


void compile10::textUnderline()
{
    textEditDescription->setUnderline( !textEditDescription->underline());
}

void compile10::textItalic()
{
    textEditDescription->setItalic(!textEditDescription->italic());
}

void compile10::textLeft()
{
    textEditDescription->setAlignment( AlignLeft );
}


void compile10::textRight()
{
    textEditDescription->setAlignment( AlignRight );
}


void compile10::textCenter()
{
    textEditDescription->setAlignment( AlignCenter );
}


void compile10::textJust()
{
    textEditDescription->setAlignment( AlignJustify);
}


void compile10::textEXP()
{
    /*
    if (!pushButtonEXP->On() ) textEditDescription->setVerticalAlignment (QTextEdit::AlignSuperScript);
    else textEditDescription->setVerticalAlignment (QTextEdit::AlignNormal);
*/    
}


void compile10::textIndex()
{
    /*
    if (!pushButtonSub->On() ) textEditDescription->setVerticalAlignment (QTextEdit::AlignSubScript);
    else textEditDescription->setVerticalAlignment (QTextEdit::AlignNormal);
*/    
}


void compile10::textGreek()
{
    QString selected=textEditDescription->selectedText();
    textEditDescription->cut();
    
    QString pattern="<*>";
    QRegExp rx(pattern);
    rx.setWildcard( TRUE );
    
    selected.remove(rx);
    
    int length=selected.length();
    
    for (int i=0; i<length;i++)
    {
	if (selected[i].unicode() >= 0x0061 && selected[i].unicode() <= 0x007A) selected[i]=QChar(selected[i].unicode()-0x0061+0x03B1);
	else if (selected[i].unicode() >= 0x03B1 && selected[i].unicode() <= 0x03C9) selected[i]=QChar(selected[i].unicode()-0x03B1+0x0061);
    }
    
    textEditDescription->insert(selected);    
}

 
void compile10::readTextFormatting( int para, int pos )
{
    
    if (textEditDescription->bold()) pushButtonBold->setOn(true);
    else pushButtonBold->setOn(false);
    
    if (textEditDescription->italic()) pushButtonItal->setOn(true);
    else pushButtonItal->setOn(false);
    
    if (textEditDescription->underline()) pushButtonUnder->setOn(true);
    else pushButtonUnder->setOn(false);
    
    if (textEditDescription->underline()) pushButtonUnder->setOn(true);
    else pushButtonUnder->setOn(false);
    
    //+++
    pushButtonLeft->setOn(false);
    pushButtonCenter->setOn(false);
    pushButtonRight->setOn(false);
    pushButtonJust->setOn(false);
    
    //	QMessageBox::warning(this,tr("QtKws"), QString::number(textEditDescription->alignment()));
    
    
    switch (textEditDescription->alignment())
    {
    case Qt::AlignLeft: pushButtonLeft->setOn(true); break;
    case Qt::AlignRight: pushButtonRight->setOn(true);break;
    case -8: pushButtonJust->setOn(true);break;
    case 4:     pushButtonCenter->setOn(true);break;
    }
    
    //+++ font
    comboBoxFont->setCurrentText(textEditDescription->family());
    comboBoxFontSize->setCurrentText(QString::number(textEditDescription->pointSize ()));
}

//*** To Do
void compile10::changedVertAlignment()
{
    /*
    if (QTextEdit::VerticalAlignment(textEditDescription)=="AlignSuperScript") 
    {
	pushButtonEXP->setOn(true);
	pushButtonSub->setOn(false);
    }
    else
	if (a == " AlignSubScript") 
    {
	pushButtonEXP->setOn(false);
	pushButtonSub->setOn(true);
    }
    else
    {
	pushButtonEXP->setOn(false);
	pushButtonSub->setOn(false);
    }
    */
}


void compile10::stot1Dto2D()
{
    if (radioButton1D->isChecked())
    {
	spinBoxXnumber->setMinValue(1);
	spinBoxXnumber->setValue(1);
	spinBoxXnumber->setEnabled(false);
	lineEditXXX->setText("x");
	pushButtonMenuSANS->show();
  }
    else
    {
	spinBoxXnumber->setMinValue(2);	
	spinBoxXnumber->setValue(2);
	spinBoxXnumber->setEnabled(true);
	lineEditXXX->setText("ix,iy");
	pushButtonMenuSANS->hide();
    }
    scanGroups();
    
    textEditCode->clear();
    //textEditCode->setText("// --->  f = f ( "+lineEditXXX->text().remove(" ")+", {P1, ... } );");
    changedFXYinfo();
}


void compile10::expandParaTrue()
{
    expandPara(true);
    pushButtonParaUp->show();
    pushButtonParaDown->hide();
}


void compile10::expandParaFalse()
{
    expandPara(false);
    pushButtonParaUp->hide();
    pushButtonParaDown->show();
}

void compile10::expandPara( bool YN )
{
    QValueList<int> lst;    
    
    if (YN)
    {
	lst<<0<<100<<0<<0;
	splitterMain->setSizes(lst);
    }
    else
    {
	lst<<135<<85<<135<<15;
	splitterMain->setSizes(lst);
    }
}


void compile10::expandCodeTrue()
{
    expandCode(true);
    pushButtonCodeUp->show();
    pushButtonCodeDown->hide();
    
}


void compile10::expandCodeFalse()
{
    expandCode(false);
    pushButtonCodeUp->hide();
    pushButtonCodeDown->show();
}


void compile10::expandCode( bool YN )
{
    QValueList<int> lst;    
    
    if (YN)
    {
	lst<<0<<0<<100<<0;
	
	splitterMain->setSizes(lst);
	lst.clear();
	QValueList<int> lst22;
	lst22<<40<<320;
	splitterInc->setSizes(lst22);
    }
    else
    {
	lst<<135<<85<<135<<15;
	splitterMain->setSizes(lst);
    }
    
}

void compile10::expandExplTrue()
{
    expandExpl(true);
    pushButtonExplUp->show();
    pushButtonExplDown->hide();
}


void compile10::expandExplFalse()
{
    expandExpl(false);
    pushButtonExplUp->hide();
    pushButtonExplDown->show();
}

void compile10::expandExpl( bool YN )
{
    QValueList<int> lst;    
    
    if (YN)
    {
	lst<<100<<0<<0<<0;
	splitterMain->setSizes(lst);
    }
    else
    {
	lst<<135<<85<<135<<15;
	splitterMain->setSizes(lst);
    }
    
}


bool compile10::functionISbusy()
{
#ifdef FITTABLE
    if (radioButton1D->isChecked())
    {

	if (app(this)->fittableWidget->listBoxFunctions->count() == 0 ) return false;
	if (app(this)->fittableWidget->listBoxFunctions->currentText()==listBoxFunctions->currentText() )
	{ 
	    return true;
	}
	else
	{
	    return false;
	}
    }
    else
    {
	if (app(this)->fitMatrix10Widget->listBoxFunctions->count() == 0 ) return false;
	if (app(this)->fitMatrix10Widget->listBoxFunctions->currentText()==listBoxFunctions->currentText() )
	{ 
	    return true;
	}
	else
	{
	    return false;
	}
    }
    return false;
#endif
    return false;
}


//*******************************************
//*** Log-output *** !OB
//*******************************************
void compile10::toResLog(QString text)
{    
    QString info =text;
        
    app(this)->logInfo+=info;
    app(this)->actionShowLog->setOn(true);
    app(this)->results->setText(app(this)->logInfo);	
    app(this)->results->scrollToBottom();	
}


void compile10::updateFiles()
{
    if ( radioButtonFIF->isChecked() && pushButtonSave->isEnabled()) 
    {
	makeFIF();
    }
    else
    {
	//toResLog("Function from Standard Library");
	openFIFfileSimple();
    }
    
    if ( radioButtonCPP->isChecked() ) makeCPP();
    if ( radioButtonBAT->isChecked() ) makeBATnew();
}

void compile10::updateFiles2()
{
    if ( radioButtonFIF->isChecked() && pushButtonSave->isEnabled()) 
    {
	makeFIF();
    }
    
    if ( radioButtonCPP->isChecked() ) makeCPP();
    if ( radioButtonBAT->isChecked() ) makeBATnew();
}

//*******************************************
//+++ move Para Line
//*******************************************
void compile10::moveParaLine(int line)
{
    int rowsNumber=spinBoxP->value();
    if (rowsNumber==1) return;
    
    int oldPos=line;
    int newPos=line-1;
    if (newPos<0) newPos=rowsNumber-1;
    
    QString s;
    s=tableParaNames->text(newPos,0);
    tableParaNames->setText(newPos,0, tableParaNames->text(oldPos,0));
    tableParaNames->setText(oldPos,0,s);
    
    s=tableParaNames->text(newPos,1);
    tableParaNames->setText(newPos,1, tableParaNames->text(oldPos,1));
    tableParaNames->setText(oldPos,1,s);
    
    s=tableParaNames->text(newPos,3);
    tableParaNames->setText(newPos,3, tableParaNames->text(oldPos,3));
    tableParaNames->setText(oldPos,3,s);
    
    QCheckTableItem *oldIt = (QCheckTableItem *)tableParaNames->item(oldPos,2);	
    bool oldChecked=oldIt->isChecked();
    QCheckTableItem *newIt = (QCheckTableItem *)tableParaNames->item(newPos,2);
    oldIt->setChecked(newIt->isChecked());
    newIt->setChecked(oldChecked);
}


void compile10::compileAll()
{
    boolCompileAll=true;
    int numberFunctions=listBoxFunctions->count();
    if (numberFunctions==0) return;
    if (listBoxFunctions->currentItem()>=0) makeFIF();
    
    //+++ Progress Dialog +++
    QProgressDialog progress( "Compile All Functions in Functions Window ...", "Abort Compilation", numberFunctions+1 , this, "Progress:", TRUE );
    
    
    progress.setProgress(0);
    
    int currentCategory=listBoxGroup->currentItem();
    
    for (int i=0;i<numberFunctions;i++)
    {
	
	listBoxGroup->setCurrentItem(currentCategory);
	listBoxFunctions->setCurrentItem(i);
	openFIFfileSimple();	
	
//	sleep(500);
	/*
	time_t start_time, cur_time;
	
	time(&start_time);
	do
	{
	    time(&cur_time);
	}
	while((cur_time - start_time) < 10);
	*/
	//openFIFfileSimple();
	
	makeDLL();
	
//	sleep(1);
	
	//+++ Progress +++
	progress.setProgress(i+1);
	progress.setLabelText("Function :: " + lineEditFunctionName->text() +" is ready");
	if ( progress.wasCanceled() ) break; 
	
	
	
	
    }
    
    listBoxGroup->setCurrentItem(currentCategory);
}


void compile10::newFunctionName()
{
    if (lineEditFunctionName->text() != listBoxFunctions->currentText()) listBoxFunctions->clearSelection();
}


void compile10::newCategoryName()
{
    if (listBoxGroup->currentText()=="ALL") return;
    
    if ( lineEditGroupName->text() != listBoxGroup->currentText()) 
    {
	listBoxGroup->clearSelection();
	listBoxFunctions->clear();
	//	lineEditFunctionName->setText("");
    }
}

void compile10::adjustResolusion()
{
    int displayHight=QApplication::desktop()->height();
    
    if (app(this)->appStyle.contains("Windows") && displayHight<1040) 
    {
	pushButtonNew->setMaximumHeight(15);
	pushButtonSave->setMaximumHeight(15);
	pushButtonDelete->setMaximumHeight(15);
	pushButtonMakeDLL->setMaximumHeight(15);
	radioButton2D->setMaximumHeight(15);
	radioButton1D->setMaximumHeight(15);
	buttonGroup13->setMaximumHeight(20);
    }
    
    if (app(this)->appStyle.contains("Aqua"))
    {
	buttonGroup13->setMinimumHeight(34);
	//
	pushButtonNew->setMinimumHeight(32);
	pushButtonNew->setMinimumHeight(32);
	//
	pushButtonSave->setMinimumHeight(32);
	pushButtonSave->setMinimumHeight(32);
	//
	pushButtonDelete->setMinimumHeight(32);
	pushButtonDelete->setMinimumHeight(32);
	//
	pushButtonMakeDLL->setMinimumHeight(32);
	pushButtonMakeDLL->setMinimumHeight(32);
	//
	radioButton1D->setMinimumHeight(32);
	radioButton1D->setMinimumHeight(32);
	//
	radioButton2D->setMinimumHeight(32);
	radioButton2D->setMinimumHeight(32);
    }
    
}

void compile10::gslLocal(bool YN)
{
    
    if (YN)
    {
	textLabelGSL->show();
	gslPathline->show();
	pushButtonPathGSL->show();
	checkBoxGSLstatic->show();
	
	lineEditCompileFlags->setText ("g++ -m32 -O2 -w -I$GSL -c");
	lineEditLinkFlags->setText	     ("g++ -m32 -O2 -Wl,--no-as-needed -Wall -shared -L$GSL/bin -lgsl -lgslcblas -o");
	
#ifdef __x86_64__
	lineEditCompileFlags->setText  ("g++ -fPIC -O2 -w -I$GSL  -c");
	lineEditLinkFlags->setText        ("g++ -O2 -Wall -shared -Wl,--no-as-needed -L$GSL/bin -lgsl -lgslcblas -o");	
#endif
				   
#ifdef Q_OS_WIN
	lineEditCompileFlags->setText  ("g++ -m32 -O2 -w -I$GSL -c");
	lineEditLinkFlags->setText        ("g++ -m32 -O2 -Wl,--no-as-needed -Wall -shared -DGSL_DLL -L$GSL/bin -lgsl -lgslcblas -o");
#endif	
    
    }
    else
    {
	checkBoxGSLstatic->setChecked(false);
	textLabelGSL->hide();
	gslPathline->hide();
	pushButtonPathGSL->hide();
	checkBoxGSLstatic->hide();
	
	lineEditCompileFlags->setText  ("g++ -m32 -O2 -w -c");
	lineEditLinkFlags->setText        ("g++ -m32 -O2 -Wl,--no-as-needed -Wall -shared -lgsl -lgslcblas -o");
	
#ifdef __x86_64__
	lineEditCompileFlags->setText  ("g++ -fPIC -O2 -w -c");
	lineEditLinkFlags->setText        ("g++ -O2 -Wl,--no-as-needed -Wall -shared -lgsl -lgslcblas -o");	
#endif

	
#ifdef Q_OS_WIN
	lineEditCompileFlags->setText  ("g++ -m32 -O2 -w -c");
	lineEditLinkFlags->setText("g++ -m32 -O2 -Wl,--no-as-needed -Wall -shared -DGSL_DLL -lgsl -lgslcblas -o");
#endif
	
#ifdef Q_OS_MAC
	lineEditCompileFlags->setText  ("g++ -m32 -O2 -w -c");
	lineEditLinkFlags->setText        ("g++ -m32 -O2  -Wall -shared -lgsl -lgslcblas -o");
#endif
	
	
    }    
}

void compile10::compilerLocal(bool YN)
{
    if (YN)
    {
	textLabelMingw->show();
	mingwPathline->show();
	pushButtonPathMingw->show();    
    }
    else
    {
	textLabelMingw->hide();
	mingwPathline->hide();
	pushButtonPathMingw->hide();
    }
}

void compile10::gslStatic(bool YN)
{
    if (YN)
    {
	lineEditLinkFlags->setText("g++ -m32 -O2 -Wl,--no-as-needed -Wall -shared  -o $GSL/bin/libgsl.a $GSL/bin/libgslcblas.a");
#ifdef __x86_64__
	lineEditLinkFlags->setText("g++ -O2 -Wl,--no-as-needed -Wall -shared $GSL/bin/libgsl.a $GSL/bin/libgslcblas.a -o");
#endif
	
#ifdef Q_OS_MAC
	lineEditLinkFlags->setText("g++ -m32 -O2 -Wall -shared  -o $GSL/bin/libgsl.a $GSL/bin/libgslcblas.a");
#endif
	
    }
    else
    {
	lineEditLinkFlags->setText("g++ -m32 -O2 -Wl,--no-as-needed -Wall -shared -L$GSL/bin -lgsl -lgslcblas -o");

#ifdef __x86_64__
	lineEditLinkFlags->setText("g++ -O2 -Wl,--no-as-needed -Wall -shared -L$GSL/bin -lgsl -lgslcblas -o");
#endif
	
#ifdef Q_OS_WIN
	lineEditLinkFlags->setText("g++ -m32 -O2 -Wl,--no-as-needed -Wall -shared -DGSL_DLL -L$GSL/bin -lgsl -lgslcblas -o");
#endif
	
#ifdef Q_OS_MAC
	lineEditLinkFlags->setText("g++ -m32 -O2 -Wall -shared -L$GSL/bin -lgsl -lgslcblas -o");
#endif	
    }
}

void compile10::defaultOptions()
{
    //+++
    QDir dd;
    QString funPath=app(this)->qtiKwsPath+"/FitFunctions";
    funPath=funPath.replace("//","/");
    if (!dd.cd(funPath)) 
    {
	funPath=QDir::homeDirPath()+"/FitFunctions";
	funPath=funPath.replace("//","/");
	
	if (!dd.cd(funPath)) 
	{
	    dd.cd(QDir::homeDirPath());
	    dd.mkdir("./qtiKWS/FitFunctions");
	    dd.cd("./qtiKWS/FitFunctions");
	}
    };
    funPath=dd.absPath();
    
    pathFIF=funPath;
    fitPath->setText(funPath);
    
    
#ifdef Q_OS_WIN
    
    checkBoxGSLlocal->setChecked(true);    
    checkBoxGSLstatic->setChecked(false);
    gslLocal(true);
    
    checkBoxCompilerLocal->setChecked(true);
    compilerLocal(true);    
    
    checkBoxGSLstatic->setChecked(true);
    gslStatic(true);
  
#elif defined(Q_OS_MAC)
    
    checkBoxGSLlocal->setChecked(true);    
    checkBoxGSLstatic->setChecked(true);
    gslLocal(true);
    
    checkBoxCompilerLocal->setChecked(false);
    compilerLocal(false);
    
    checkBoxGSLstatic->setChecked(true);
    gslStatic(true);
#else
    
    checkBoxGSLlocal->setChecked(false);    
    checkBoxGSLstatic->setChecked(false);
    gslLocal(false);
    
    checkBoxCompilerLocal->setChecked(false);
    compilerLocal(false);  
    
#endif
    //+++
    
    
#if defined(Q_OS_WIN)
    //+++  gsl WIN
    dd.cd(qApp->applicationDirPath());
    
    pathGSL="Select GSL Directory!!!";
    
    if (dd.cd("../3rdparty/GSL")) pathGSL=dd.absPath(); 
    else if (dd.cd(funPath.remove("/FitFunctions")+"/3rdparty/GSL")) pathGSL=dd.absPath();
   
    gslPathline->setText(pathGSL);
#endif
    
    
#if defined(Q_OS_MAC)
    //+++  gsl WIN
    dd.cd(qApp->applicationDirPath());
    if (!dd.cd("../3rdparty/GSL")) 
    { 
	if (dd.cd("/Applications/qtiKWS10.app/Contents/3rdparty/GSL")) 
	{
	    pathGSL=dd.absPath();    
	}
	else if (dd.cd(funPath.remove("/FitFunctions")+"/3rdparty/GSL"))	
	{
	    pathGSL=dd.absPath();    
	}	
	else if (dd.cd(QDir::homeDirPath()+"/qtiKWS/3rdparty/GSL")) 
	{
	    pathGSL=dd.absPath();    
	}
	else pathGSL="Select GSL Directory!!!";
    }
    else
    {
	pathGSL=dd.absPath();
    }
    gslPathline->setText(pathGSL);
#endif    
    
    
#if defined(Q_OS_WIN)
    
    //+++  MinGW WIN
    dd.cd(QDir::rootDirPath ());
    if (!dd.cd("./MinGW")) 
    { 
	pathMinGW="Select Compiler Directory!!!";
    }
    else
    {
	pathMinGW=dd.absPath();
    }
    mingwPathline->setText(pathMinGW);    
#endif
    
    QString compileFlag="g++ -m32 -O2 -Wl,--no-as-needed -w";
  
#ifdef __x86_64__
	compileFlag="g++ -fPIC -O2 -Wl,--no-as-needed -w";
#endif  
	
	
	
    pathChanged();
}


void compile10::pathUpdate()
{
    if (lineEditCompileFlags->text()!="-m32 -w") return;
    
    defaultOptions();
    readSettings();
    scanGroups();
    scanIncludedFunctions();    
    
    if (lineEditCompileFlags->text()=="-m32 -w")     defaultOptions();
}

void compile10::openHeaderInNote()
{
	app(this)->changeFolder("FIT :: COMPILE");
	
    QString fn=listBoxIncludeFunctions->currentText();
    if (fn!="") openInNote( fn );

	app(this)->changeFolder("FIT :: COMPILE");

}

void compile10::openFortranFileInNote()
{
	app(this)->changeFolder("FIT :: COMPILE");
    
	QString fn=fortranFunction->text();
    if (fn!="") openInNote( fn );
	
	app(this)->changeFolder("FIT :: COMPILE");
}

void compile10::openInNote(QString fn)
{  
	app(this)->changeFolder("FIT :: COMPILE");
    
	QFile f;
    if (tabWidgetCode->currentPageIndex()==4)
    {
	f.setName(pathFIF+"/"+fn);
    }
    else 	
	f.setName(pathFIF+"/IncludedFunctions/"+fn);
    
    
    QString s="";
    
    //+++
    if ( !f.open( IO_ReadOnly ) ) 
    {
	QMessageBox::critical(0, tr("QtKws"),
			      tr("Could not read from file: <br><h4>"+fn+ 
				 "</h4><p>Please verify that you have the right to read from this location!"));
	return;
    }
    else
    {
	QTextStream t( &f );
	
	while ( !t.atEnd() ) 
	    s +=t.readLine() +"\n";
	
	
    }
    f.close();
    
    
	Note* note=app(this)->newNoteText(fn.replace(".","-"),s);	
	if (tabWidgetCode->currentPageIndex()==4)
	    SyntaxHighlighterFortran77* noteLighterF77 = new SyntaxHighlighterFortran77(note->textWidget());
	else
	    SyntaxHighlighter* noteLighter = new SyntaxHighlighter(note->textWidget());
	
	
	app(this)->changeFolder("FIT :: COMPILE");
//	note->importASCII(file);
	//note->setMaximized();
}

void compile10::openInNoteCPP()
{    
	app(this)->changeFolder("FIT :: COMPILE");
    
	QString fn=lineEditFunctionName->text();
    
    if (radioButtonCPP->isChecked()) fn+=".cpp";
    if (radioButtonFIF->isChecked()) fn+=".fif";
    if (radioButtonBAT->isChecked()) fn="BAT.BAT";
    
    QFile f(pathFIF+"/"+fn);
    QString s="";
    
    //+++
    if ( !f.open( IO_ReadOnly ) ) 
    {
	QMessageBox::critical(0, tr("QtKws"),
			      tr("Could not read from file: <br><h4>"+fn+ 
				 "</h4><p>Please verify that you have the right to read from this location!"));
	return;
    }
    else
    {
	QTextStream t( &f );
	
	while ( !t.atEnd() ) 
	    s +=t.readLine() +"\n";
	
	
    }
    f.close();
    
    
    Note* note=app(this)->newNoteText(fn.replace(".","-"),s);	
	
    SyntaxHighlighter* noteLighter = new SyntaxHighlighter(note->textWidget());

	app(this)->changeFolder("FIT :: COMPILE");
}

//*******************************************
//+++ scan FitFunction dir on groups
//*******************************************
void compile10::changedNumberIndepvar(int newNumber)
{
    QString oldNames=lineEditXXX->text();
    oldNames.remove(" ");

    QStringList oldList=QStringList::split(",", oldNames);
    
    if (oldList.count() < newNumber)
    {
	for (int i=oldList.count(); i<newNumber;i++) oldList<<"x"+QString::number(i+1-2);
    }
    
    QString newList;
    for (int i=0;i<newNumber-1;i++) newList+=oldList[i]+",";
    newList+=oldList[newNumber-1];
    
    QString newMask="nnnn";
    for (int i=1; i<newNumber;i++) newMask+=",nnnn";
    newMask+=";";

    lineEditXXX->setInputMask(newMask);
    lineEditXXX->setText(newList);
}

//*******************************************
//+++ 
//*******************************************
void compile10::changedFXYinfo()
{
    if (textEditCode->text(0).contains("// --->  "))
    {
	textEditCode->removeParagraph(0);
    }
    
    textEditCode->insertParagraph( "// --->  "+lineEditY->text().remove(" ")+" = f ( "+lineEditXXX->text().remove(" ")+", {P1, ...} );",0);  
}


void compile10::checkFunctionName()
{
    QString name=lineEditFunctionName->text();
    
    name=name.replace("_","-");
    name=name.remove(" ");
    name=name.remove(".");
    name=name.remove(":").remove(";").remove("|").remove("!").remove("%").remove("@");
    name=name.remove("[").remove("]").remove("=").remove("?");
    name=name.remove("/").remove(",").remove("~").remove("*").remove("<").remove(">");
    
    lineEditFunctionName->setText(name);
}

void compile10::inputMenuCall()
{
    QPopupMenu* menuCPP = new QPopupMenu( app(this) );
    menuCPP->insertItem( tr("Include &Data"), this, SLOT( includeData() ), CTRL+Key_D );
    menuCPP->insertItem( tr("Include &Flags"), this, SLOT( includeFlags() ), CTRL+Key_F );
  
    QPopupMenu* mathFunctions = new QPopupMenu(this, "Math Functions");
    
    mathFunctions->insertItem( tr("abs()"),100);
    mathFunctions->insertItem( tr("log2()"),101);
    mathFunctions->insertItem( tr("log10()"),102);
    mathFunctions->insertItem( tr("ln()"),103);
    
    mathFunctions->insertSeparator();
    
    mathFunctions->insertItem( tr("sin()"),201);
    mathFunctions->insertItem( tr("cos()"),202);
    mathFunctions->insertItem( tr("tan()"),203);
    mathFunctions->insertItem( tr("asin()"),204);
    mathFunctions->insertItem( tr("acos()"),205);
    mathFunctions->insertItem( tr("atan()"),206);
    mathFunctions->insertItem( tr("sinh()"),207);
    mathFunctions->insertItem( tr("cosh()"),208);
    mathFunctions->insertItem( tr("tanh()"),209);
    mathFunctions->insertItem( tr("asinh()"),210);
    mathFunctions->insertItem( tr("acosh()"),211);
    mathFunctions->insertItem( tr("atanh()"),212);
    
    mathFunctions->insertSeparator();
    
    
    //    mathFunctions->insertItem( tr("pow(a,b)"),200);
        
    menuCPP->insertItem(tr("Math Functions"),mathFunctions);
    
    //QPoint point;Q
    //textEditCode->mapToGlobal ( point ) ;
    menuCPP->popup( textEditCode->mapToGlobal ( QPoint(0,0) ) );
    
    connect(mathFunctions, SIGNAL( activated ( int ) ), this, SLOT( includeMath(int) ) );
    
}

void compile10::includeData()
{
    QString s="\n";
    s+="//++++++++++++++++++++++++++++++++++++++++++\n";    
    s+="//+++  Current Data Sets\n";
    s+="//+++     XXX  :  fitted data X-vector\n";
    s+="//+++     YYY   :  fitted data Y-vector\n";
    s+="//+++     RESO:  fitted data Reso-vector\n";
    s+="//++++++++++++++++++++++++++++++++++++++++++\n\n";
    s+="double *XXX  =((struct functionT *) ParaM)->Q;\n";
    s+="double *YYY   =((struct functionT *) ParaM)->I;\n";
    s+="double *RESO=((struct functionT *) ParaM)->SIGMA;\n\n";
    s+="//++++++++++++++++++++++++++++++++++++++++++\n";    
    s+="//+++     Current Data Set Limits and Current Data Point : \n";
    s+="//+++     currentFirstPoint <=currentPoint <= currentLastPoint\n";
    s+="//++++++++++++++++++++++++++++++++++++++++++\n\n";
    s+="int currentPoint=((struct functionT *) ParaM)->currentPoint;\n";
    s+="int currentFirstPoint=((struct functionT *) ParaM)->currentFirstPoint;\n";
    s+="int currentLastPoint=((struct functionT *) ParaM)->currentLastPoint;\n";
    
    
    textEditCode->insert(s);
}

void compile10::includeMath(int id)
{
    QString s=textEditCode->selectedText();
    if (s=="") s="x";
    
    switch (id)
    {
    case 100:  textEditCode->insert("fabs("+s+")"); break; 
    case 101:  textEditCode->insert( "log("+s+")/log(2)"); break;// log2
    case 102:  textEditCode->insert("log10("+s+")"); break; 
    case 103:  textEditCode->insert("ln("+s+")"); break; 
 
    
    case 201:  textEditCode->insert("sin("+s+")"); break;
    case 202:  textEditCode->insert("cos("+s+")"); break;
    case 203:  textEditCode->insert("tan("+s+")"); break;
    case 204:  textEditCode->insert("asin("+s+")"); break;
    case 205:  textEditCode->insert("acos("+s+")"); break;
    case 206:  textEditCode->insert("atan("+s+")"); break;
    case 207:  textEditCode->insert("sinh("+s+")"); break;
    case 208:  textEditCode->insert("cosh("+s+")"); break;
    case 209:  textEditCode->insert("tanh("+s+")"); break;
    case 210:  textEditCode->insert( "log("+s+" + sqrt("+s+" * "+s+" + 1))"); break;// asinh
    case 211:  textEditCode->insert( "log("+s+" + sqrt("+s+" * "+s+" - 1))"); break;// acosh
    case 212:  textEditCode->insert( "(0.5 * log((1 + "+s+") / (1 - "+s+")))"); break;// atanh
    
    }
    /*
    // misc 
    DefineFun(_T("exp"), Exp); 
    DefineFun(_T("sqrt"), Sqrt); 
    DefineFun(_T("sign"), Sign); 
    DefineFun(_T("rint"), Rint); 
    DefineFun(_T("abs"), Abs); 
    DefineFun(_T("if"), Ite); 
    // Functions with variable number of arguments 
    DefineFun(_T("sum"), Sum); 
    DefineFun(_T("avg"), Avg); 
    DefineFun(_T("min"), Min); 
    DefineFun(_T("max"), Max);
	//case 4:     pushButtonCenter->setOn(true);break;
    }
    */
}

void compile10::stdMenu()
{
    QPopupMenu* menuSTD = new QPopupMenu( app(this) );
    menuSTD->insertSeparator();
    menuSTD->insertSeparator();    
    
    menuSTD->insertItem(lineEditY->text(), 1000);
  
    menuSTD->insertSeparator();
    menuSTD->insertSeparator();
        
    QStringList lst=QStringList::split(",", lineEditXXX->text().remove(" "));
    for (int i=0; i<lst.count();i++) 
    {
	menuSTD->insertItem(lst[i], 1001+i);
    }
    
    menuSTD->insertSeparator();
    menuSTD->insertSeparator();
    
    
    for (int i=0; i<spinBoxP->value();i++) 
    {
	menuSTD->insertItem(tableParaNames->text(i,0), 2001+i);
    }
    
    if (spinBoxP->value()>0) menuSTD->insertSeparator();
    menuSTD->insertItem("all parameters", 2000);
  
    menuSTD->insertSeparator();
    menuSTD->insertSeparator();
    
    menuSTD->popup( textEditCode->mapToGlobal ( QPoint(0,0) ) );
    connect(menuSTD, SIGNAL( activated ( int ) ), this, SLOT( includeID(int) ) );
}

void compile10::flagsMenu()
{
    QPopupMenu* menuFlags = new QPopupMenu( app(this) );
//    if(radioButton1D->isChecked())
//    {  
	menuFlags->insertSeparator();
	menuFlags->insertSeparator();    
	menuFlags->insertItem("[get] (bool) beforeFit", 101);
	menuFlags->insertItem("[get] (bool) afterFit", 102);
	menuFlags->insertItem("[get] (bool) beforeIter", 103);
	menuFlags->insertItem("[get] (bool) afterIter", 104);
//    }
    
    menuFlags->insertSeparator();
    menuFlags->insertSeparator();
    menuFlags->insertItem("[use] beforeFit", 111);
    menuFlags->insertItem("[use] afterFit", 112);
    menuFlags->insertItem("[use] beforeIter", 113);
    menuFlags->insertItem("[use] afterIter", 114);
    menuFlags->insertSeparator();
    menuFlags->insertSeparator();    
    menuFlags->insertItem( "if (beforeFit) {...} else {...}", 105);
    menuFlags->insertItem( "if (afterFit) {...} else {...}", 106);
    menuFlags->insertItem( "if (beforeIter) {...} else {...}", 107);
    menuFlags->insertItem( "if (afterIter) {...} else {...}", 108);
    menuFlags->insertSeparator();
    menuFlags->insertSeparator();
    menuFlags->popup( textEditCode->mapToGlobal ( QPoint(0,0) ) );
    
    connect(menuFlags, SIGNAL( activated ( int ) ), this, SLOT( includeID(int) ) );
}

void compile10::dataMenu()
{
    QPopupMenu* menuData = new QPopupMenu( app(this) );
    
    if(radioButton1D->isChecked())
    {  
	menuData->insertItem("get all data", 201);
	menuData->insertSeparator();
	menuData->insertItem("XXX  :  fitted data :: X-vector", 202);
	menuData->insertItem("YYY  :   fitted data :: Y-vector", 203);    
	menuData->insertItem("RESO:  fitted data :: Resolusion-vector", 204);    
	menuData->insertSeparator();
	menuData->insertItem("current Point", 205);
	menuData->insertItem("current Point (first)", 206);    
	menuData->insertItem("current Point (last)", 207);    
	menuData->insertSeparator();    
    }
    else
    {
    	menuData->insertItem("get all data", 211);
	menuData->insertSeparator();
	menuData->insertItem("YYYY        :  fitted data :: Y-matrix", 212);
	menuData->insertItem("MASK       :  masking matrix", 213);    	
	menuData->insertItem("WEIGHT  :  weighting matrix", 214);    
	menuData->insertItem("XXX         :  fitted data :: X-matrix", 215);
	menuData->insertSeparator();
	menuData->insertItem("vector of matrix dimensions : rows", 216);
	menuData->insertItem("vector of matrix dimensions : columnss", 217);
	menuData->insertSeparator();	
	menuData->insertItem("current matrix", 218);
	menuData->insertItem("number matrixes to fit", 219); 
	menuData->insertItem("number x-matrixes", 220);  
	menuData->insertSeparator();
    
    }
    
    menuData->popup( textEditCode->mapToGlobal ( QPoint(0,0) ) );
   
    connect(menuData, SIGNAL( activated ( int ) ), this, SLOT( includeID(int) ) );
}

void compile10::mathMenu()
{
    QPopupMenu* mathFunctions = new QPopupMenu( app(this) );
    
    mathFunctions->insertItem( tr("abs()"),300);
    
    mathFunctions->insertSeparator();
    
    mathFunctions->insertItem( tr("log2()"),301);
    mathFunctions->insertItem( tr("log10()"),302);
    mathFunctions->insertItem( tr("ln()"),303);
    
    mathFunctions->insertSeparator();
    
    mathFunctions->insertItem( tr("sin()"),404);
    mathFunctions->insertItem( tr("cos()"),402);
    mathFunctions->insertItem( tr("tan()"),403);
    mathFunctions->insertItem( tr("asin()"),404);
    mathFunctions->insertItem( tr("acos()"),405);
    mathFunctions->insertItem( tr("atan()"),406);
    mathFunctions->insertItem( tr("sinh()"),407);
    mathFunctions->insertItem( tr("cosh()"),408);
    mathFunctions->insertItem( tr("tanh()"),409);
    mathFunctions->insertItem( tr("asinh()"),410);
    mathFunctions->insertItem( tr("acosh()"),411);
    mathFunctions->insertItem( tr("atanh()"),412);
    
    mathFunctions->insertSeparator();    
    
    mathFunctions->popup( textEditCode->mapToGlobal ( QPoint(0,0) ) );
      
    connect(mathFunctions, SIGNAL( activated ( int ) ), this, SLOT( includeID(int) ) );
}

void compile10::sansMenu()
{
    QPopupMenu* menuSANS = new QPopupMenu( app(this) );
    menuSANS->insertItem("[Polydispersity]:");
    menuSANS->insertSeparator();
    menuSANS->insertSeparator();
    menuSANS->insertItem("[get] all polydispersity parameters", 501);
    menuSANS->insertSeparator();
    menuSANS->insertItem( "[get] (bool) polyYN", 502); 
    menuSANS->insertItem( "[use] (bool) polyYN", 506);
    menuSANS->insertItem( "if (polyYN) {...} else {...}", 503);
    menuSANS->insertSeparator();
    menuSANS->insertItem( " [get] (int) polyFunctionNumber", 504);  
    menuSANS->insertItem( " [use] (int) polyFunctionNumber", 505);   
    
    menuSANS->popup( textEditCode->mapToGlobal ( QPoint(0,0) ) );
    
    connect(menuSANS, SIGNAL( activated ( int ) ), this, SLOT( includeID(int) ) );
}

void compile10::multiMenu()
{
    QPopupMenu* menuSANS = new QPopupMenu( app(this) );
//    menuSANS->insertItem("[Function Multiplication Tools]:");
//    menuSANS->insertSeparator();
    menuSANS->insertItem("[add] in label-table", 601);
    menuSANS->insertSeparator();
    menuSANS->insertItem("[add] in label-table and function-template", 602); 
    
    menuSANS->popup( textEditCode->mapToGlobal ( QPoint(0,0) ) );
    
    connect(menuSANS, SIGNAL( activated ( int ) ), this, SLOT( includeIDmulti(int) ) );
}


void compile10::includeIDmulti(int id)
{
    
    if (id==601 || id==602)
    {
    
	int numberPara=tableParaNames->numRows();
	// get numbet copies
	bool ok;
	int numberCopies = QInputDialog::getInteger(
            "Input number of Multi-Functions ", "Enter a number:", 2, 2, 100, 1, &ok, this );
	if ( ok ) 
	{  
	    spinBoxP->setValue(numberPara*numberCopies );

	    
	    if (id==602)
	    {	
		QString s="\n";
		s+="//++++++++++++++++++++++++++++++++++++++++++\n";    
		s+="//+++  Multiplication-Fuction-Template\n";
		s+="//++++++++++++++++++++++++++++++++++++++++++\n\n";
		s+="double ";
		
		for (int iPara=0;iPara<numberPara-1;iPara++) s+=tableParaNames->text(iPara,0)+", ";
		s+=tableParaNames->text(numberPara-1,0)+";\n\n ";
		
		s+=lineEditY->text()+"=0.0;\n\n";
				
		s+="for (int ii=0; ii<"+QString::number(numberCopies )+";ii++)\n{\n";
		
		for (int iPara=0;iPara<numberPara;iPara++) s+=tableParaNames->text(iPara,0)+"=gsl_vector_get(Para,ii*"+QString::number(numberPara)+"+"+QString::number(iPara)+");\n";  
		
		s+="\n"+lineEditY->text()+"+=function("+lineEditXXX->text();
		for (int iPara=0;iPara<numberPara;iPara++) s+=", "+tableParaNames->text(iPara,0);
		s+=");\n}\n";
		
		textEditCode->insert(s);
	    }
	    
	    
	    for (int iPara=0;iPara<numberPara;iPara++)
	    {
		
		QString curLabel=tableParaNames->text(iPara,0);
		QString curValue=tableParaNames->text(iPara,1);
		QCheckTableItem *curItem = (QCheckTableItem *)tableParaNames->item(iPara,2); //

		QString curInfo=tableParaNames->text(iPara,3);
		
		for (int iFun=0;iFun<numberCopies ;iFun++)
		{
		    tableParaNames->setText(iFun*numberPara+iPara,0, curLabel+QString::number(iFun+1));		    
		    tableParaNames->setText(iFun*numberPara+iPara,1, curValue);
		    if (curItem->isChecked())
		    {
			QCheckTableItem *item = (QCheckTableItem *)tableParaNames->item(iFun*numberPara+iPara,2); //
			item->setChecked(true);
		    }
		    tableParaNames->setText(iFun*numberPara+iPara,3, curInfo +" ["+QString::number(iFun+1)+"]");		    
		}
	    }
	
	}
	
	
	
	
	

    }

    
}


void compile10::includeID(int id)
{
    // parameters
    if (id>2000 && id<3000) 
    {
	textEditCode->insert(tableParaNames->text(id-2000-1,0));
	return;
    }
    // x-variables
    if (id>1000 && id<2000) 
    {
	QStringList lst=QStringList::split(",", lineEditXXX->text().remove(" "));
	textEditCode->insert(lst[id-1000-1]);
	return;
    }
    
    QString s;
    if (id>=200 && id<500) // || id>=600 && id<700)
    {
	s=textEditCode->selectedText();
	if (s=="") s="x";
    }
    

    switch (id)
    {
    case 101:  
	if (radioButton2D->isChecked()) s=  "bool beforeFit=((struct functionND *) ParaM)->beforeFit;\n"; 		else s=  "bool beforeFit=((struct functionT *) ParaM)->beforeFit;\n"; 
	break; 
    case 102:
	if (radioButton2D->isChecked()) s="bool afterFit=((struct functionND *) ParaM)->afterFit;\n";   
	else s="bool afterFit=((struct functionT *) ParaM)->afterFit;\n";   
	break;
    case 103:  
	if (radioButton2D->isChecked()) s="bool beforeIter=((struct functionND *) ParaM)->beforeIter;\n"; 
	else	s="bool beforeIter=((struct functionT *) ParaM)->beforeIter;\n"; 
	break; 
    case 104:  
	if (radioButton2D->isChecked()) s="bool afterIter=((struct functionND *) ParaM)->afterIter;\n"; 
	else s="bool afterIter=((struct functionT *) ParaM)->afterIter;\n"; 
	break; 
    case 111:  
	s=  "beforeFit"; 
	break; 
    case 112:
	s="afterFit";   
	break;
    case 113:  
	s="beforeIter"; 
	break; 
    case 114:  
	s="afterIter"; 
	break; 	
    case 105:  
	s="if (beforeFit)\n {\n\n}\nelse\n{\n\n}\n"; 
	break; 
    case 106:
	s="if (afterFit)\n {\n\n}\nelse\n{\n\n}\n"; 
	break;
    case 107:  
	s="if (beforeIter)\n {\n\n}\nelse\n{\n\n}\n"; 
	break; 
    case 108:  
	s="if (afterIter)\n {\n\n}\nelse\n{\n\n}\n"; 
	break; 
    
    case 201:  
	s="\n";
	s+="//++++++++++++++++++++++++++++++++++++++++++\n";    
	s+="//+++  Current Data Sets\n";
	s+="//+++     XXX  :  fitted data X-vector\n";
	s+="//+++     YYY   :  fitted data Y-vector\n";
	s+="//+++     RESO:  fitted data Reso-vector\n";
	s+="//++++++++++++++++++++++++++++++++++++++++++\n\n";
	s+="double *XXX  =((struct functionT *) ParaM)->Q;\n";
	s+="double *YYY   =((struct functionT *) ParaM)->I;\n";
	s+="double *RESO=((struct functionT *) ParaM)->SIGMA;\n\n";
	s+="//++++++++++++++++++++++++++++++++++++++++++\n";    
	s+="//+++     Current Data Set Limits and Current Data Point : \n";
	s+="//+++     currentFirstPoint <=currentPoint <= currentLastPoint\n";
	s+="//++++++++++++++++++++++++++++++++++++++++++\n\n";
	s+="int currentPoint=((struct functionT *) ParaM)->currentPoint;\n";
	s+="int currentFirstPoint=((struct functionT *) ParaM)->currentFirstPoint;\n";
	s+="int currentLastPoint=((struct functionT *) ParaM)->currentLastPoint;\n";
	break; 
    case 202:  
	s="double *XXX  =((struct functionT *) ParaM)->Q;\n"; 
	break;		    
    case 203:  
	s="double *YYY   =((struct functionT *) ParaM)->I;\n"; 
	break;
    case 204:  
	s="double *RESO=((struct functionT *) ParaM)->SIGMA;\n"; 
	break;	
    case 205:  
	s="int currentPoint=((struct functionT *) ParaM)->currentPoint;\n"; 
	break;		    
    case 206:  
	s="int currentFirstPoint=((struct functionT *) ParaM)->currentFirstPoint;\n"; 
	break;
    case 207:  
	s="int currentLastPoint=((struct functionT *) ParaM)->currentLastPoint;\n"; 
	break;	
   case 211:  
	s="\n";
	s+="//++++++++++++++++++++++++++++++++++++++++++\n";    
	s+="//+++  Current Matrix(s)\n";
	s+="//+++     YYYY        :  fitted Matrix(es)\n";
	s+="//+++     MASK       :  mask Matrix(es)\n";
	s+="//+++     WEIGHT   :  weight Matrix(es)\n";
	s+="//+++     XXXX        :  x-Matrix(es)  [if defined]\n";
	s+="//++++++++++++++++++++++++++++++++++++++++++\n";
	s+="gsl_matrix *YYYY          =((struct functionND *) ParaM)->I;\n";
	s+="gsl_matrix *MASK         =((struct functionND *) ParaM)->mask;\n";
	s+="gsl_matrix *WEIGHT    =((struct functionND *) ParaM)->dI;\n";
	s+="gsl_matrix *XXXX         =((struct functionND *) ParaM)->xMatrix;\n\n";	
	s+="//++++++++++++++++++++++++++++++++++++++++++\n";    
	s+="//+++     Matrix(es) dimensions \n";
	s+="//++++++++++++++++++++++++++++++++++++++++++\n";
	s+="size_t  *Rows=((struct functionND *) ParaM)->Rows;\n";
	s+="size_t  *Columns=((struct functionND *) ParaM)->Columns;\n\n";
	s+="//++++++++++++++++++++++++++++++++++++++++++\n";    
	s+="//+++     Simultanious Fit \n";
	s+="//+++     - yNumber               - number of y-Matrixes to Fit  \n";
	s+="//+++     - xNumber               - number of x-Matrixes  \n";	
	s+="//+++     - yNumberCurrent  - number of current y-Matrixes [1...yNumber]  \n";	
	s+="//++++++++++++++++++++++++++++++++++++++++++\n";
	s+="size_t  yNumber=((struct functionND *) ParaM)->yNumber;\n";
	s+="size_t  xNumber=((struct functionND *) ParaM)->xNumber;\n";	
	s+="size_t  yNumberCurrent =key;\n\n";	
	break; 
    case 212:  
	s="gsl_matrix *YYYY    =((struct functionND *) ParaM)->I;\n"; 
	break;		    
    case 213:  
	s="gsl_matrix *MASK         =((struct functionND *) ParaM)->mask;\n"; 
	break;
    case 214:  
	s="gsl_matrix *WEIGHT    =((struct functionND *) ParaM)->dI;\n"; 
	break;	
    case 215:  
	s="gsl_matrix *XXXX         =((struct functionND *) ParaM)->xMatrix;\n"; 
	break;		    
    case 216:  
	s="size_t  *Rows=((struct functionND *) ParaM)->Rows;\n"; 
	break;
    case 217:  
	s="size_t  *Columns=((struct functionND *) ParaM)->Columns;\n"; 
	break;		
    case 218:  
	s="size_t  yNumberCurrent =key;\n"; 
	break;	
    case 219:  
	s="size_t  yNumber=((struct functionND *) ParaM)->yNumber;\n"; 
	break;		    
    case 220:  
	s="size_t  xNumber=((struct functionND *) ParaM)->xNumber;\n"; 
	break;	
	
    case 300:  
	s="fabs("+s+")"; 
	break; 
    case 301:  
	s="log("+s+")/log(2)"; 
	break;// log2
    case 302:  
	s="log10("+s+")"; 
	break; 
    case 303:  
	s="ln("+s+")"; 
	break; 
 
    case 401:  
	s="sin("+s+")"; 
	break;
    case 402: 
	s="cos("+s+")"; 
	break;
    case 403: 
	s="tan("+s+")"; 
	break;
    case 404:  
	s="asin("+s+")"; 
	break;
    case 405: 
	s="acos("+s+")"; 
	break;
    case 406: 
	s="atan("+s+")"; 
	break;
    case 407:  
	s="sinh("+s+")"; 
	break;
    case 408: 
	s="cosh("+s+")"; 
	break;
    case 409: 
	s="tanh("+s+")"; 
	break;
    case 410: 
	s="log("+s+" + sqrt("+s+" * "+s+" + 1))"; 
	break;// asinh
    case 411: 
	s="log("+s+" + sqrt("+s+" * "+s+" - 1))"; 
	break;// acosh
    case 412:  
	s="(0.5 * log((1 + "+s+") / (1 - "+s+")))"; 
	break;// atanh
    case 501:  
	s="\n";
	s+="//++++++++++++++++++++++++++++++++++++++++++\n";    
	s+="//+++  Polydispersity parameters\n";
	s+="//++++++++++++++++++++++++++++++++++++++++++\n\n";
	s+="// Polydispersity check box is checked?:  (bool) polyYN\n";
	s+="bool polyYN=((struct functionT *) ParaM)->polyYN;\n\n";
	s+="// Number of polydispersity function:\n";
	s+="// (1) Gauss,(2) Schultz, (3) Gamma, (4) Log-Normal, (5) Uniform, (6) Triangular \n";	
	s+="int polyFunctionNumber=((struct functionT *) ParaM)->polyFunction;\n\n";
	
	s+="// Parameters of polydispersity function:\n";
	s+="// (1)-(5) sigmaPoly1, (6) sigmaPoly1 and sigmaPoly2 \n";	
	s+="double sigmaPoly1=0.0, sigmaPoly2=0.0;\n";
	s+="if (polyYN)\n{\n\tsigmaPoly1= gsl_vector_get(Para, Para->size-2);\n\tsigmaPoly2=gsl_vector_get(Para, Para->size-1);\n}\n\n";
	s+="//---------------------------------------------------------------------------------------------------------\n";    
	s+="//---  Polydispersity parameters\n";
	s+="//----------------------------------------------------------------------------------------------------------\n";

	break; 	
  case 502:  
	s="bool polyYN=((struct functionT *) ParaM)->polyYN;\n"; 
	break; 	
  case 503:  
	s="if (polyYN)\n{\n\n}\nelse\n{\n\n}\n"; 
	break; 			
  case 504:  
	s="int polyFunctionNumber=((struct functionT *) ParaM)->polyFunction;\n"; 
	break; 				
 case 505:  
	s="polyFunctionNumber"; 
	break;     
  case 506:  
	s="polyYN"; 
	break;
  case 1000:
      s=lineEditY->text(); 
      break;	
  case 2000:  
      for (int i=0; i<spinBoxP->value();i++) 
      {
	  s+=tableParaNames->text(i,0)+",";
      }
      s=s.left(s.length()-1);
      break;	
	
    }
    textEditCode->insert(s);
}


void compile10::showMenu()
{
    if (pushButtonMenu->text()==QChar(0x226A))
    {
	pushButtonMenu->setText(QChar(0x226B));
	frameMenu->setMaximumWidth(0);
	//frameMenu->setMinimumHeight(2);
    }
    else
    {
      	pushButtonMenu->setText(QChar(0x226A));
	frameMenu->setMaximumWidth(3000);
	//frameMenu->setMinimumHeight(50);

    }
    
}


void compile10::selectRowsTableMultiFit()
{
    int numRows=tableParaNames->numRows();
    int i;
    for (i=0;i<numRows;i++)
    {
	if ( tableParaNames->isSelected(i,2) && !tableParaNames->isSelected(i,3))
	{
	    QCheckTableItem *itS0 = (QCheckTableItem *)tableParaNames->item(i,2); //
	    itS0->setChecked(true);
	}
	if ( tableParaNames->isSelected(i,2) && tableParaNames->isSelected(i,3))
	{
	    QCheckTableItem *itS0 = (QCheckTableItem *)tableParaNames->item(i,2); //
	    itS0->setChecked(false);
	}
    }

}
