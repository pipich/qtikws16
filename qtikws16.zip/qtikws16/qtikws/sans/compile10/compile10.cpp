/****************************************************************************
** Form implementation generated from reading ui file '../qtiKWS/sans/compile10/compile10.ui'
**
** Created: Thu Sep 14 02:31:54 2017
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "compile10.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qtoolbutton.h>
#include <qsplitter.h>
#include <qlabel.h>
#include <qlistbox.h>
#include <qlineedit.h>
#include <qframe.h>
#include <qspinbox.h>
#include <qslider.h>
#include <qtable.h>
#include <qtabwidget.h>
#include <qtextedit.h>
#include <qcombobox.h>
#include <qgroupbox.h>
#include <qcheckbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "compile10.ui.h"
static const unsigned char image0_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x03,
    0x06, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x4d, 0x6c, 0x14,
    0x75, 0x18, 0xc6, 0x7f, 0xf3, 0x9f, 0xe9, 0xce, 0xcc, 0x7e, 0x77, 0x3f,
    0xba, 0x0d, 0x5b, 0x2a, 0xb6, 0x45, 0x8d, 0x31, 0x02, 0x4a, 0x0d, 0x8a,
    0x1e, 0x40, 0x13, 0xc4, 0x8b, 0xe9, 0x45, 0x0f, 0x6a, 0x7a, 0xf0, 0x62,
    0x34, 0x5e, 0xec, 0x05, 0x0d, 0x41, 0x88, 0x17, 0x4f, 0x7a, 0xf0, 0x64,
    0x4c, 0x34, 0x1a, 0x0d, 0x09, 0xf5, 0x20, 0x41, 0x14, 0x13, 0x88, 0xd8,
    0x1a, 0x1a, 0xf9, 0x90, 0x8d, 0x52, 0xb4, 0x6a, 0xb1, 0xb4, 0xb6, 0xa5,
    0xee, 0xce, 0x6e, 0xa7, 0x3b, 0xb3, 0xcc, 0xce, 0xec, 0xcc, 0xdf, 0x93,
    0x1b, 0x7b, 0xf6, 0xbd, 0x3d, 0x87, 0xe7, 0xc9, 0xef, 0x7d, 0x92, 0x47,
    0x91, 0x52, 0xf2, 0x7f, 0x4e, 0xdb, 0xa4, 0x14, 0x45, 0x39, 0x7f, 0x94,
    0x92, 0x17, 0xb0, 0x4f, 0xc4, 0xf5, 0xc7, 0x10, 0x72, 0x57, 0x20, 0x45,
    0x21, 0xe8, 0xc8, 0x6c, 0x73, 0x3d, 0x5a, 0xf5, 0xc3, 0xe0, 0x0a, 0x82,
    0x89, 0x17, 0xdf, 0x91, 0xf5, 0xae, 0xe5, 0xbf, 0x04, 0x17, 0xde, 0x55,
    0x9e, 0xd6, 0x33, 0x89, 0x63, 0xc9, 0xf2, 0xee, 0x1d, 0xf1, 0xc2, 0xfd,
    0xf4, 0x98, 0x39, 0xb4, 0x98, 0x09, 0x04, 0xd8, 0xb7, 0x66, 0xb9, 0x78,
    0xe6, 0x0b, 0xac, 0xaa, 0x37, 0x23, 0xe1, 0x85, 0x57, 0xdf, 0x97, 0xf3,
    0x00, 0xe2, 0x5f, 0xf3, 0x97, 0x87, 0x95, 0xb2, 0x9a, 0xd0, 0x3f, 0x1b,
    0xda, 0xff, 0xd6, 0x8e, 0xbb, 0x0f, 0x7c, 0xce, 0xd6, 0x07, 0x9f, 0x23,
    0xbf, 0x6d, 0x18, 0x33, 0x25, 0xd1, 0x44, 0x9d, 0xe2, 0x96, 0x34, 0x42,
    0xd5, 0x08, 0x3a, 0x3c, 0x1c, 0x74, 0x38, 0xfe, 0xde, 0xf3, 0x4a, 0x7a,
    0xd3, 0x0b, 0x5a, 0x8c, 0x27, 0x93, 0xe5, 0xd1, 0x44, 0xef, 0xb6, 0x57,
    0x80, 0xaf, 0xc1, 0xad, 0x10, 0x39, 0x36, 0xde, 0x86, 0x85, 0xef, 0xda,
    0x08, 0x21, 0x50, 0x35, 0x0d, 0xdd, 0xd0, 0xe9, 0x84, 0x9d, 0xd1, 0x56,
    0x14, 0xbe, 0x0c, 0xbc, 0xdd, 0x0d, 0x90, 0x11, 0xf7, 0xf4, 0x95, 0x46,
    0x91, 0xe1, 0x55, 0xac, 0x8d, 0x29, 0x44, 0x94, 0x20, 0x25, 0x35, 0x7a,
    0x8d, 0x14, 0x76, 0x04, 0x41, 0x24, 0xd9, 0xf3, 0xd4, 0x13, 0x38, 0xd6,
    0x0a, 0x95, 0x0b, 0xb3, 0xdc, 0xf8, 0xdd, 0xd6, 0x37, 0x11, 0x18, 0xb7,
    0x29, 0xae, 0x84, 0x36, 0x17, 0x17, 0x4f, 0xb2, 0xd8, 0x58, 0xa0, 0xea,
    0x78, 0xe0, 0x34, 0x78, 0x24, 0x95, 0xe5, 0xd1, 0xfe, 0x3e, 0x84, 0xe8,
    0x41, 0x2f, 0xa6, 0x89, 0x1b, 0x01, 0xed, 0x76, 0x18, 0x3a, 0x4d, 0xce,
    0x6f, 0xea, 0xe0, 0xa7, 0x02, 0x03, 0xdf, 0x9b, 0x6d, 0xfe, 0x4e, 0x27,
    0x59, 0x2e, 0x0c, 0x30, 0x97, 0x8b, 0x31, 0xa5, 0x6b, 0xbc, 0x54, 0xf9,
    0x81, 0x0f, 0xaf, 0xff, 0x8a, 0xa1, 0xaa, 0x84, 0xbe, 0x4f, 0x75, 0xd5,
    0xa2, 0xd9, 0xf4, 0xec, 0xdb, 0x01, 0x37, 0xbb, 0x01, 0xf7, 0xbd, 0xa6,
    0x8c, 0x2c, 0xef, 0x39, 0xb8, 0x33, 0x33, 0xf2, 0x10, 0xb7, 0x98, 0xa3,
    0x72, 0x6d, 0x06, 0x6b, 0x69, 0x09, 0x35, 0xe7, 0xd2, 0xbe, 0x23, 0xce,
    0xc4, 0x8f, 0x57, 0x38, 0x77, 0x73, 0x89, 0x8c, 0xae, 0xd2, 0xda, 0x70,
    0x09, 0xfc, 0xc8, 0xb1, 0x56, 0xa8, 0x76, 0x03, 0xfa, 0xf7, 0x6e, 0x7f,
    0x7d, 0x60, 0x68, 0x77, 0xfe, 0xbb, 0xab, 0xe7, 0x38, 0x7d, 0xfa, 0x12,
    0xd9, 0xfa, 0x10, 0xe3, 0xc5, 0x09, 0xe6, 0x2e, 0x2d, 0x20, 0xc3, 0x26,
    0x5e, 0x0a, 0x3e, 0xfd, 0xe5, 0x06, 0x61, 0xa4, 0x60, 0xe8, 0x1a, 0x32,
    0x52, 0x32, 0xd9, 0x02, 0xfd, 0xdd, 0x0e, 0xd4, 0xd0, 0x1c, 0x9f, 0x6d,
    0x5d, 0xa6, 0xd1, 0x76, 0x39, 0xf1, 0xf8, 0x34, 0xf1, 0x6c, 0x0f, 0xd9,
    0x44, 0x9a, 0xad, 0xf9, 0x41, 0x8e, 0xcc, 0x1e, 0xa2, 0x9e, 0xaa, 0xf0,
    0x5b, 0xcd, 0xa5, 0x16, 0xc5, 0x28, 0x96, 0xb7, 0x60, 0x26, 0xae, 0xa7,
    0x75, 0xdd, 0xbd, 0x17, 0x98, 0x17, 0x00, 0x55, 0xdb, 0x52, 0xe7, 0xd6,
    0xe6, 0x11, 0x79, 0xf8, 0x4a, 0x7c, 0xcc, 0x99, 0xea, 0x49, 0x5c, 0x5a,
    0xf8, 0xf9, 0x36, 0xbd, 0xb9, 0x02, 0xba, 0x1f, 0x27, 0x9f, 0x48, 0x90,
    0x49, 0x26, 0x30, 0xb2, 0x45, 0xca, 0x83, 0x19, 0x45, 0x37, 0x19, 0xeb,
    0x12, 0x38, 0x0d, 0xef, 0x1b, 0xb3, 0x96, 0x3d, 0x20, 0x53, 0x06, 0x93,
    0x0b, 0x93, 0x64, 0x3b, 0x7d, 0x38, 0xb1, 0x16, 0x67, 0x97, 0xcf, 0xb2,
    0xee, 0x6d, 0xe0, 0xd7, 0x60, 0x67, 0xc1, 0x27, 0x5a, 0xbe, 0x46, 0xa8,
    0x75, 0x18, 0x2c, 0x6b, 0x5c, 0x16, 0x3c, 0x7b, 0xe4, 0x19, 0xe5, 0x03,
    0x0d, 0x20, 0xb0, 0xc5, 0xa1, 0xe6, 0x42, 0xeb, 0x81, 0xa6, 0xd1, 0x29,
    0xf6, 0xf7, 0xdd, 0x89, 0x66, 0xc6, 0x98, 0x5a, 0x9d, 0x66, 0xbd, 0xd1,
    0xe4, 0xcf, 0x9f, 0x17, 0x19, 0xaa, 0xd9, 0x94, 0xd6, 0x1a, 0x1c, 0xff,
    0x63, 0x8d, 0x98, 0xd9, 0x83, 0x0c, 0x7d, 0x84, 0x4a, 0x5c, 0x81, 0xb1,
    0xee, 0x16, 0x46, 0xde, 0x28, 0xed, 0x35, 0x4c, 0xfd, 0xa3, 0x58, 0x21,
    0xb7, 0x5d, 0x8f, 0x1b, 0xb8, 0x4d, 0x17, 0x6b, 0xad, 0x1e, 0xd9, 0x8d,
    0xf5, 0x4f, 0xc6, 0x9c, 0xd6, 0xb7, 0xbb, 0x3c, 0x0a, 0x56, 0xc0, 0x5d,
    0x02, 0x86, 0x85, 0xc6, 0xb0, 0x50, 0x98, 0x51, 0x23, 0x0e, 0x6f, 0x1a,
    0xd3, 0xf0, 0xb8, 0x32, 0x68, 0xe7, 0xf3, 0xfb, 0x50, 0xa2, 0xfd, 0x9e,
    0x17, 0x34, 0xda, 0xae, 0x73, 0xaa, 0xd3, 0x62, 0x5a, 0x4e, 0x12, 0x1c,
    0x3b, 0x8a, 0xb2, 0x72, 0x0a, 0x35, 0x9d, 0x27, 0x96, 0x4c, 0x51, 0x42,
    0xf0, 0xd7, 0x9b, 0x27, 0xa4, 0xff, 0x0f, 0x06, 0x6c, 0x4c, 0x46, 0x6a,
    0x7f, 0xa0, 0xd3, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae,
    0x42, 0x60, 0x82
};

static const unsigned char image1_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x03,
    0x18, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x4b, 0x68, 0x1c,
    0x75, 0x00, 0x87, 0xbf, 0x99, 0xf9, 0xcf, 0x6e, 0x76, 0xf2, 0xda, 0x3c,
    0x36, 0x36, 0x6c, 0x92, 0x96, 0x65, 0x69, 0x4a, 0x1a, 0x69, 0x9b, 0x87,
    0xf5, 0xad, 0x35, 0xc6, 0x52, 0x84, 0x82, 0x85, 0x06, 0x14, 0x45, 0x69,
    0xb1, 0xf5, 0xa8, 0x35, 0x78, 0x93, 0x4d, 0x8e, 0x5e, 0x72, 0x12, 0x3c,
    0x84, 0x5e, 0x72, 0x68, 0x20, 0x42, 0x0f, 0x8a, 0x94, 0x22, 0x48, 0x2a,
    0x4d, 0xb7, 0x6b, 0xd3, 0xd6, 0x98, 0x6e, 0x6d, 0xb3, 0x49, 0x04, 0x6b,
    0x66, 0xeb, 0x26, 0x6b, 0x66, 0x5f, 0x99, 0x9d, 0x99, 0x9d, 0x19, 0x4f,
    0x0d, 0x82, 0xc7, 0x7e, 0xa7, 0xdf, 0xe5, 0x77, 0xfa, 0xf8, 0x24, 0xdf,
    0xf7, 0x79, 0x1a, 0xc4, 0x93, 0x21, 0x49, 0x48, 0x13, 0x13, 0xdf, 0xd6,
    0x17, 0x0a, 0xd5, 0x03, 0xa5, 0x52, 0x79, 0xc0, 0x71, 0x9c, 0xe7, 0x6d,
    0xdb, 0x0d, 0xfb, 0xbe, 0x6f, 0x0a, 0xe1, 0xe9, 0xbe, 0xef, 0xa5, 0x54,
    0x35, 0xb0, 0x58, 0xa9, 0x14, 0xf4, 0xb9, 0xb9, 0x84, 0xbd, 0xfb, 0xf3,
    0x7d, 0x9f, 0x0b, 0x17, 0x2e, 0xb6, 0x3a, 0x8e, 0x78, 0x47, 0x08, 0xf9,
    0xbd, 0x86, 0x86, 0xd0, 0x8b, 0x91, 0x48, 0xb8, 0x2e, 0x1a, 0x6d, 0x26,
    0x1c, 0x0e, 0x62, 0x9a, 0x0e, 0xb9, 0xdc, 0x0e, 0x1b, 0x1b, 0x5b, 0xe4,
    0xb7, 0xb6, 0xfe, 0x34, 0x8a, 0xc5, 0x9f, 0xac, 0x5a, 0x6d, 0xba, 0x33,
    0x12, 0xb8, 0x3b, 0x35, 0xf5, 0x99, 0x29, 0xc6, 0xc7, 0x2f, 0xed, 0xd5,
    0xb4, 0xa6, 0x8b, 0x2d, 0x2d, 0x0d, 0x23, 0xa6, 0x59, 0x65, 0x78, 0xf8,
    0x39, 0x06, 0x07, 0xa3, 0x68, 0x1a, 0x5c, 0x3a, 0x37, 0x0a, 0xc0, 0xc9,
    0xa9, 0x1f, 0x09, 0x85, 0xe0, 0x46, 0x32, 0xdd, 0x93, 0xbc, 0xb6, 0xfc,
    0x51, 0xde, 0x28, 0xbc, 0x5b, 0x2c, 0xec, 0xcc, 0x00, 0xe7, 0x64, 0xcb,
    0xaa, 0x1c, 0xd2, 0xb4, 0xd0, 0xc8, 0xd9, 0xb3, 0xc7, 0x19, 0x18, 0x88,
    0xb3, 0xb8, 0x78, 0x1f, 0xdb, 0x86, 0x72, 0x19, 0x6a, 0x35, 0x70, 0x1c,
    0x90, 0x25, 0xf0, 0xa8, 0x91, 0x4e, 0xaf, 0xf3, 0xe1, 0x6b, 0x6f, 0x32,
    0x3a, 0x38, 0x18, 0xb4, 0x5c, 0xf7, 0x63, 0x00, 0x91, 0xcf, 0x17, 0x6f,
    0x84, 0xc3, 0xe1, 0x3b, 0xeb, 0xeb, 0xf9, 0x81, 0x40, 0xa0, 0x13, 0xc3,
    0x78, 0xc0, 0xd2, 0xd2, 0xef, 0x0c, 0x0d, 0x75, 0xf1, 0xca, 0x97, 0x73,
    0x78, 0x1e, 0x78, 0x14, 0xb9, 0x72, 0x35, 0x8d, 0x6b, 0x78, 0x78, 0x78,
    0x18, 0xa5, 0x22, 0xa6, 0x65, 0x7d, 0x0d, 0xa0, 0x2c, 0x2f, 0x5f, 0xdd,
    0xb9, 0x7c, 0x79, 0xa1, 0xb9, 0x58, 0xac, 0x8e, 0xc6, 0xe3, 0x3d, 0x54,
    0x2a, 0x26, 0x99, 0xcc, 0x2a, 0xba, 0xbe, 0xc3, 0xca, 0xca, 0x06, 0x6b,
    0x6b, 0x7f, 0xf1, 0xeb, 0xd2, 0x1f, 0xac, 0x3d, 0xc8, 0x32, 0x7a, 0xf8,
    0x30, 0x65, 0xbb, 0xca, 0x77, 0xc9, 0x85, 0xbc, 0xed, 0x59, 0x9f, 0x9c,
    0x3e, 0xf5, 0x6a, 0x5e, 0x00, 0x98, 0xa6, 0x73, 0xfd, 0xf1, 0xe3, 0x9c,
    0x63, 0x18, 0x9b, 0x6a, 0x2c, 0xd6, 0x4d, 0x2c, 0xd6, 0xfd, 0x7f, 0x5f,
    0x07, 0x20, 0xaa, 0x35, 0x70, 0xe5, 0xf6, 0x2f, 0x98, 0xb6, 0xbd, 0x70,
    0x30, 0xee, 0x66, 0x76, 0x35, 0x5a, 0x56, 0xe5, 0x51, 0xb9, 0xac, 0x16,
    0x4b, 0xa5, 0x52, 0x5b, 0x7b, 0x7b, 0x27, 0x37, 0x93, 0xbf, 0xe1, 0x63,
    0x51, 0x5f, 0xaf, 0xb1, 0x6d, 0x14, 0x30, 0xb6, 0x0d, 0x7a, 0xbb, 0x7a,
    0x38, 0xf4, 0xf2, 0x30, 0x05, 0xb3, 0x8c, 0x04, 0xd9, 0xf9, 0x79, 0xe4,
    0x44, 0x02, 0x4f, 0x00, 0xb8, 0xae, 0x27, 0xc0, 0x17, 0x42, 0xa8, 0x64,
    0x37, 0x36, 0x30, 0xcd, 0xbf, 0x79, 0xeb, 0xf8, 0x4b, 0x48, 0x52, 0x08,
    0x45, 0xb1, 0x59, 0xc9, 0xe8, 0xdc, 0xb9, 0x95, 0xe6, 0x0d, 0xa7, 0x1f,
    0x55, 0x08, 0xf0, 0x3c, 0x31, 0x3f, 0x3f, 0xe1, 0x42, 0x02, 0x19, 0x20,
    0x18, 0x14, 0x07, 0x5b, 0xc2, 0x4d, 0x8d, 0x91, 0xd6, 0x56, 0xca, 0x85,
    0x0a, 0x47, 0x86, 0x86, 0xb8, 0xbd, 0x98, 0xe1, 0xde, 0xbd, 0x55, 0x8e,
    0x1e, 0xdd, 0xcb, 0x07, 0xef, 0xbf, 0x40, 0x67, 0x57, 0x37, 0xb9, 0xed,
    0x6d, 0xf6, 0xc7, 0xa2, 0x28, 0x42, 0x19, 0x7e, 0xfd, 0xf4, 0x44, 0x3d,
    0x80, 0x7c, 0xec, 0xd8, 0xa4, 0x10, 0x42, 0x1d, 0xe9, 0x88, 0xb4, 0xc9,
    0x1d, 0x4d, 0x2d, 0x04, 0x10, 0xd4, 0x9c, 0x20, 0xd7, 0x17, 0xee, 0x92,
    0x4a, 0xdd, 0x22, 0x95, 0x5c, 0x21, 0xab, 0x5b, 0x3c, 0xd3, 0xb1, 0x87,
    0x42, 0xd1, 0xe4, 0x48, 0x5f, 0x1c, 0xad, 0x2e, 0xd0, 0xbf, 0x47, 0x51,
    0x3f, 0x07, 0x10, 0x91, 0x48, 0x9f, 0x8f, 0x9c, 0xad, 0x6e, 0xe6, 0xb6,
    0x58, 0x5e, 0x7a, 0xc8, 0xa3, 0xac, 0x4e, 0xee, 0xe1, 0x7d, 0xda, 0xda,
    0x1b, 0xb1, 0xcc, 0xaa, 0x35, 0x3d, 0xfd, 0x83, 0xdb, 0x18, 0x6e, 0xd2,
    0x14, 0x49, 0xe1, 0xd9, 0x7d, 0xfb, 0xb8, 0x96, 0x4c, 0x53, 0xb5, 0x1d,
    0x59, 0xa8, 0xca, 0x09, 0x60, 0x52, 0xf2, 0x7d, 0x9f, 0x33, 0x67, 0xa6,
    0xba, 0x55, 0x21, 0xbe, 0x91, 0x65, 0xf9, 0xed, 0x9a, 0xeb, 0xfd, 0xec,
    0x54, 0xcd, 0xef, 0x83, 0x5a, 0xfd, 0xaa, 0xeb, 0x7a, 0xab, 0xba, 0xbe,
    0x69, 0x8a, 0x3a, 0xb9, 0xbf, 0xa5, 0x51, 0x3b, 0x59, 0x17, 0x08, 0x8e,
    0x59, 0xb6, 0xd3, 0xe0, 0xe3, 0xdd, 0xf4, 0x7d, 0xe5, 0xd3, 0x99, 0x99,
    0xf1, 0x94, 0xf4, 0xa4, 0xc6, 0xf3, 0xe7, 0xbf, 0x6a, 0xae, 0x56, 0x95,
    0x3e, 0xc7, 0x91, 0x32, 0xbd, 0xbd, 0xe5, 0x7f, 0x12, 0x89, 0x84, 0xf7,
    0x5f, 0x8b, 0x63, 0x63, 0x93, 0x01, 0x55, 0x15, 0x27, 0x24, 0x49, 0x8a,
    0xbb, 0xae, 0x98, 0x9d, 0x9d, 0xfd, 0x42, 0xdf, 0x8d, 0xe9, 0x69, 0xf8,
    0x17, 0x30, 0xac, 0x74, 0xca, 0x52, 0x48, 0x49, 0xdf, 0x00, 0x00, 0x00,
    0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image2_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xfb, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x4d, 0x68, 0x5c,
    0x65, 0x14, 0x86, 0x9f, 0xef, 0xbb, 0x77, 0xe6, 0xfe, 0xcc, 0x6f, 0x9b,
    0x49, 0xa6, 0x99, 0x49, 0x93, 0xa6, 0x69, 0xb5, 0x54, 0x69, 0xaa, 0xb5,
    0x98, 0x22, 0x42, 0x52, 0x84, 0x4a, 0x37, 0xd2, 0x4d, 0x8b, 0x58, 0x71,
    0x51, 0x57, 0xa2, 0x50, 0x70, 0xa3, 0x50, 0xac, 0x41, 0x10, 0x41, 0xd0,
    0x85, 0xa0, 0xa8, 0xa0, 0x28, 0x88, 0x54, 0x14, 0xa4, 0x15, 0x89, 0x0b,
    0x35, 0xa0, 0xa4, 0x20, 0x36, 0xa4, 0xd4, 0x14, 0x5b, 0xb5, 0x36, 0xb6,
    0xce, 0x4c, 0xc9, 0x24, 0x99, 0xc9, 0xdc, 0x99, 0x7b, 0xef, 0xdc, 0x9f,
    0xcf, 0x95, 0x83, 0xb3, 0xf6, 0xec, 0xce, 0xe2, 0x7d, 0x78, 0xcf, 0x79,
    0x79, 0x85, 0x52, 0x8a, 0xff, 0x33, 0x7a, 0xdf, 0x26, 0x84, 0x98, 0x7f,
    0x99, 0xa2, 0x17, 0x30, 0x23, 0x6d, 0xe3, 0x61, 0xa4, 0xba, 0x2f, 0x50,
    0xb2, 0x10, 0x84, 0x2a, 0xdf, 0x6a, 0xc4, 0xd5, 0x6e, 0x14, 0x5c, 0x42,
    0xf2, 0xfc, 0xa9, 0x37, 0xd4, 0x7a, 0x4f, 0xf2, 0x5f, 0x07, 0x0b, 0x6f,
    0x8a, 0xc7, 0x8c, 0x5c, 0x6a, 0x36, 0x5d, 0x7e, 0x60, 0xd2, 0x2e, 0xec,
    0x23, 0x61, 0x6d, 0x45, 0x4f, 0x5a, 0x40, 0x40, 0xb3, 0xb6, 0xcc, 0x4f,
    0x73, 0x5f, 0xb2, 0xb6, 0xea, 0x5d, 0x54, 0xf0, 0xe4, 0x73, 0xef, 0xaa,
    0x3f, 0x00, 0xe4, 0xbf, 0xe2, 0xaf, 0xce, 0x88, 0xb2, 0x96, 0x32, 0x3e,
    0xd9, 0x79, 0xf8, 0x95, 0xc9, 0xbb, 0x8f, 0x7c, 0xce, 0xf6, 0x03, 0x4f,
    0x50, 0xd8, 0x31, 0x81, 0x95, 0x51, 0xe8, 0xda, 0x3a, 0x83, 0xa5, 0x2c,
    0x52, 0xd3, 0x09, 0x42, 0x0e, 0x05, 0x21, 0x9f, 0xbe, 0x75, 0x52, 0x64,
    0xfb, 0x4e, 0xd0, 0x93, 0x3c, 0x9a, 0x29, 0x1d, 0x4c, 0x6d, 0xd9, 0xf1,
    0x2c, 0x30, 0x47, 0x14, 0x2e, 0xe1, 0x7b, 0x0d, 0xbc, 0xcd, 0x3a, 0xdd,
    0x76, 0x13, 0x29, 0x25, 0x9a, 0xae, 0x63, 0x98, 0x06, 0x61, 0x14, 0x1e,
    0xec, 0xc4, 0xd1, 0x33, 0xc0, 0x6b, 0x3d, 0x80, 0x52, 0xec, 0xc9, 0xee,
    0x9e, 0x22, 0x8e, 0x96, 0x70, 0x2b, 0xf3, 0xa8, 0x44, 0x0a, 0x65, 0x24,
    0x30, 0x0a, 0x59, 0x14, 0xa0, 0x02, 0xc5, 0xd4, 0xd1, 0x47, 0x70, 0xd6,
    0x2a, 0x2c, 0x2d, 0x2c, 0x73, 0xe3, 0xb7, 0xa6, 0xd1, 0xe7, 0xc0, 0x4f,
    0x33, 0xe8, 0x5d, 0xbb, 0xc3, 0xed, 0xb9, 0x0f, 0xd8, 0xb8, 0xbc, 0x88,
    0xdb, 0x0a, 0x88, 0xb2, 0x31, 0xb9, 0x99, 0x22, 0x23, 0xd3, 0x25, 0x62,
    0x5d, 0x23, 0x93, 0xce, 0x62, 0x9b, 0x01, 0xbe, 0x1f, 0x45, 0x4e, 0x8b,
    0xf9, 0xbe, 0x1f, 0x88, 0x1f, 0x19, 0xe9, 0x7e, 0xf4, 0x27, 0xd6, 0xaf,
    0x0e, 0xc3, 0xfe, 0x76, 0x86, 0x57, 0x62, 0xc4, 0xf9, 0x2a, 0x97, 0x4f,
    0x7d, 0xc7, 0x2f, 0xef, 0x5c, 0x41, 0x33, 0x35, 0xa2, 0xa0, 0x4b, 0xbd,
    0xba, 0x46, 0xab, 0xe5, 0x35, 0xdd, 0x80, 0x95, 0x1e, 0xe0, 0xed, 0x9c,
    0xd8, 0x55, 0x5a, 0xd9, 0xb3, 0x7f, 0xfc, 0xc1, 0x69, 0xcc, 0xb2, 0x81,
    0x29, 0x6e, 0xa1, 0x17, 0x25, 0x63, 0xf7, 0x0e, 0x31, 0x6e, 0xd8, 0x2c,
    0xbe, 0x7a, 0x89, 0x95, 0x6f, 0xff, 0xc2, 0xcc, 0xea, 0x38, 0xcd, 0x36,
    0x41, 0x37, 0x76, 0xd6, 0x2a, 0xac, 0xf6, 0x00, 0x63, 0x51, 0xee, 0xc5,
    0xf2, 0x81, 0xc9, 0x81, 0xa8, 0x71, 0x9d, 0xf5, 0xa1, 0x7d, 0x78, 0xd3,
    0x8f, 0x23, 0x4f, 0x9e, 0x26, 0xba, 0x67, 0x12, 0x2b, 0x2f, 0xc9, 0x03,
    0x57, 0xcf, 0xfd, 0x4e, 0x1c, 0x0b, 0x4c, 0x4b, 0x47, 0xc5, 0x22, 0x97,
    0x2f, 0xb0, 0xad, 0x07, 0x90, 0x29, 0xe3, 0x29, 0xa3, 0xbd, 0xca, 0xc6,
    0xc2, 0x22, 0xe6, 0xde, 0xfd, 0x14, 0x9e, 0x3e, 0xcd, 0xf0, 0x89, 0xe3,
    0x78, 0xb1, 0x46, 0x3b, 0x52, 0x6c, 0xb5, 0x6c, 0x1a, 0x37, 0xdb, 0xb8,
    0x9b, 0x09, 0x06, 0x46, 0x4a, 0x58, 0x29, 0x33, 0x6b, 0x18, 0xec, 0xed,
    0x01, 0xda, 0x1d, 0x47, 0xeb, 0x54, 0xee, 0x10, 0xa8, 0x24, 0x89, 0xd0,
    0x45, 0xba, 0xeb, 0xd0, 0xa8, 0x93, 0x9f, 0x9a, 0xc2, 0xde, 0x56, 0x24,
    0x14, 0x09, 0xd2, 0xc5, 0x0c, 0x76, 0x3e, 0x85, 0x95, 0x1b, 0xa4, 0x3c,
    0x9a, 0x13, 0x86, 0xc5, 0xb1, 0x5e, 0x0a, 0xf5, 0x76, 0xe7, 0x9b, 0x5a,
    0x27, 0x3a, 0x32, 0x32, 0x94, 0xc5, 0xfd, 0xfa, 0x0b, 0x6e, 0x9e, 0x3f,
    0x87, 0x39, 0xbe, 0x93, 0x24, 0x8a, 0x84, 0x90, 0xfc, 0x1d, 0xc4, 0x94,
    0x26, 0x42, 0xda, 0xf5, 0x65, 0x92, 0x51, 0xc0, 0x68, 0x59, 0xe7, 0x67,
    0xc9, 0x89, 0x97, 0x8e, 0x8b, 0xf7, 0x75, 0x80, 0x96, 0x9e, 0x78, 0xe1,
    0xea, 0x8d, 0xda, 0xfd, 0x3a, 0x62, 0x70, 0x20, 0x58, 0x42, 0xa1, 0x68,
    0x5f, 0xbf, 0x46, 0xb5, 0xe1, 0x70, 0xa5, 0xda, 0xa0, 0x59, 0xf6, 0x09,
    0xd4, 0x2d, 0x6a, 0xef, 0xd5, 0xb0, 0x8c, 0x04, 0x2a, 0xea, 0x22, 0x35,
    0x6c, 0x01, 0xc7, 0x7a, 0x5d, 0x78, 0xdd, 0xb6, 0x1f, 0xca, 0xe4, 0xad,
    0x0f, 0x0b, 0xa6, 0xb5, 0xdb, 0x32, 0x0d, 0x1c, 0xdf, 0xa7, 0xb6, 0xe1,
    0xc4, 0x8e, 0xeb, 0x7f, 0x2c, 0x0e, 0x79, 0xdf, 0xab, 0x31, 0x0a, 0xde,
    0x26, 0x77, 0x01, 0x13, 0x52, 0x67, 0x42, 0x0a, 0x2e, 0x6a, 0x31, 0x67,
    0xfa, 0xca, 0x34, 0x5b, 0x16, 0xa3, 0xc9, 0x66, 0x6a, 0x46, 0x69, 0xf2,
    0x70, 0x18, 0x84, 0x1b, 0xbe, 0xeb, 0x5e, 0x48, 0xc2, 0x0f, 0x67, 0x15,
    0xc1, 0xec, 0x2c, 0xa2, 0x72, 0x01, 0x2d, 0x3b, 0x40, 0x32, 0x9d, 0xa1,
    0x88, 0xe4, 0xf6, 0xd9, 0xcf, 0x54, 0xf7, 0x1f, 0x44, 0x95, 0x3e, 0x56,
    0xcc, 0xe0, 0x88, 0x6c, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44,
    0xae, 0x42, 0x60, 0x82
};

static const unsigned char image3_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0x31, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0x8d, 0x90, 0xcd, 0x4b, 0x94,
    0x51, 0x14, 0xc6, 0x7f, 0xef, 0xbc, 0xef, 0x8c, 0x8e, 0x61, 0x8a, 0xa5,
    0x12, 0x23, 0x6a, 0x18, 0x9a, 0xd1, 0x42, 0x84, 0xda, 0xd6, 0x22, 0xfa,
    0x0b, 0xac, 0x65, 0xd1, 0xaa, 0x10, 0x0a, 0x0a, 0x93, 0x3e, 0x10, 0x8a,
    0x68, 0xe1, 0x22, 0x08, 0x2c, 0x48, 0xb0, 0x16, 0xb5, 0xcc, 0x4d, 0x46,
    0xe0, 0x22, 0xa1, 0x10, 0x5b, 0x45, 0x88, 0x7d, 0x69, 0x6a, 0x92, 0x93,
    0x9a, 0x91, 0x33, 0x8c, 0xce, 0xcc, 0x9d, 0xfb, 0xf5, 0xbe, 0x2d, 0x46,
    0xc7, 0x4c, 0x0b, 0x1f, 0x38, 0x9c, 0x73, 0xef, 0x39, 0xcf, 0x73, 0x9f,
    0x7b, 0x9c, 0x63, 0x7d, 0x8b, 0x6f, 0x2b, 0xcb, 0x22, 0xad, 0x56, 0xf9,
    0xe4, 0x84, 0x8f, 0xcc, 0x59, 0x64, 0xd6, 0x27, 0x27, 0x2c, 0x52, 0xf8,
    0x88, 0x6c, 0x3e, 0xe7, 0x84, 0x25, 0x95, 0xd0, 0x00, 0x68, 0xe9, 0xe3,
    0xeb, 0x1c, 0x56, 0xc4, 0xdf, 0x79, 0x95, 0x65, 0x91, 0xd6, 0x03, 0x35,
    0xe5, 0x08, 0x01, 0x99, 0x2c, 0x64, 0xb3, 0x90, 0x4e, 0xe7, 0x23, 0x13,
    0x01, 0x37, 0x04, 0x8e, 0x03, 0xc5, 0x25, 0x20, 0x54, 0xfe, 0x9e, 0x22,
    0x20, 0xa4, 0x70, 0x72, 0xa2, 0xd5, 0x8b, 0xed, 0x70, 0x38, 0x54, 0x05,
    0x5a, 0x83, 0xd2, 0xab, 0x59, 0x82, 0x52, 0xf9, 0xb3, 0x94, 0x20, 0x15,
    0x28, 0x19, 0x90, 0x4a, 0x05, 0xac, 0xc1, 0x1a, 0x78, 0x3d, 0xe2, 0xe2,
    0xd5, 0xee, 0x84, 0xe3, 0x7b, 0xd7, 0x1b, 0xff, 0x87, 0x03, 0x80, 0x10,
    0x1a, 0x63, 0x0d, 0x57, 0x92, 0x0e, 0xa1, 0x6d, 0x32, 0x0b, 0x58, 0x23,
    0x2b, 0x69, 0x01, 0xf0, 0x02, 0xdf, 0xdf, 0x36, 0x71, 0x2b, 0x6c, 0xcb,
    0xc1, 0x9f, 0x64, 0x63, 0x4d, 0xa1, 0xd6, 0xc6, 0xe0, 0x19, 0x69, 0xb6,
    0xe2, 0x30, 0x2d, 0xa7, 0x99, 0xd4, 0xe3, 0xf8, 0x16, 0x1a, 0xed, 0x41,
    0xaa, 0x23, 0x55, 0x85, 0x9e, 0x92, 0x16, 0xad, 0xfd, 0x7f, 0x3b, 0xe8,
    0x4f, 0xf5, 0xd3, 0x65, 0xba, 0x98, 0x8f, 0x2c, 0x30, 0xeb, 0xc6, 0xb9,
    0x9a, 0xb9, 0xcc, 0x93, 0x85, 0xc7, 0x28, 0x69, 0x0b, 0x7f, 0xb7, 0xd6,
    0x6e, 0x16, 0x58, 0x49, 0x0b, 0x46, 0x17, 0x46, 0xb9, 0x27, 0xee, 0x33,
    0xe4, 0x0c, 0x31, 0x30, 0xfd, 0x82, 0x9a, 0xe5, 0x3a, 0x4e, 0xbb, 0x67,
    0x58, 0x4a, 0x24, 0xf8, 0x9c, 0xfc, 0x98, 0xb7, 0xae, 0xd7, 0xf7, 0xe6,
    0x6d, 0xb0, 0xbd, 0x32, 0x41, 0xe7, 0xd7, 0x4e, 0xde, 0x34, 0x8f, 0x40,
    0x0e, 0x66, 0x26, 0x66, 0x68, 0x3a, 0xbc, 0x1f, 0xa7, 0x38, 0x44, 0xac,
    0xae, 0x86, 0x5d, 0x54, 0xa1, 0xb5, 0x5f, 0x78, 0x5d, 0x2b, 0xbb, 0x51,
    0xa0, 0x65, 0x4f, 0x0b, 0x17, 0x96, 0x2e, 0x32, 0xf7, 0x65, 0x8e, 0x48,
    0xba, 0x88, 0x5b, 0xfb, 0x6e, 0xf3, 0xd3, 0xf9, 0xc5, 0x23, 0xf3, 0x00,
    0xe5, 0x69, 0xce, 0xe9, 0xf3, 0x34, 0x38, 0x4d, 0xab, 0x2e, 0xf2, 0xbb,
    0xf3, 0x8c, 0x32, 0x08, 0xa1, 0x89, 0x46, 0xc3, 0x08, 0xa1, 0x39, 0x52,
    0x7f, 0x94, 0xee, 0xf1, 0x3b, 0x84, 0xca, 0x5d, 0x1a, 0x4a, 0x1b, 0x68,
    0x9f, 0x3f, 0xcb, 0x87, 0xe6, 0x31, 0xc2, 0x91, 0x30, 0x3f, 0x26, 0x17,
    0xb9, 0xe6, 0xdf, 0xa4, 0xb1, 0xbc, 0x69, 0x5d, 0xe0, 0xe5, 0xfb, 0xd4,
    0xd8, 0x54, 0x7c, 0x19, 0xad, 0x0c, 0x46, 0x1a, 0xe6, 0x97, 0x5f, 0x85,
    0x45, 0x66, 0x29, 0x16, 0xf5, 0xea, 0xb5, 0xf2, 0xc7, 0xcd, 0xa7, 0x58,
    0xa6, 0x22, 0x59, 0x9d, 0x08, 0xbb, 0xdf, 0x4a, 0x93, 0xee, 0xd3, 0xda,
    0xf8, 0x75, 0x31, 0x45, 0xd4, 0x26, 0x10, 0x6e, 0x82, 0xef, 0xb3, 0xc5,
    0x10, 0x04, 0xc1, 0x86, 0xe8, 0x7e, 0xf6, 0xb0, 0xb4, 0xe4, 0x64, 0xc9,
    0x0d, 0x3a, 0x18, 0xa0, 0x87, 0x41, 0x86, 0x49, 0x30, 0xcc, 0x52, 0xf4,
    0x6a, 0xf4, 0xd2, 0xdf, 0xb3, 0x41, 0x10, 0x6c, 0x16, 0x08, 0x82, 0x80,
    0xde, 0xe7, 0xbd, 0xbb, 0x39, 0x41, 0x1b, 0xed, 0xdc, 0xa5, 0x83, 0x1e,
    0xda, 0x38, 0xd5, 0x37, 0xd8, 0x57, 0xb1, 0xd5, 0xec, 0x6f, 0x94, 0x97,
    0x5e, 0xc6, 0xb3, 0xd1, 0x07, 0x1a, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45,
    0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image4_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xe9, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x5d, 0x68, 0x5b,
    0x75, 0x18, 0xc6, 0x7f, 0xff, 0x93, 0x9c, 0x24, 0xa7, 0x5d, 0xd2, 0xa4,
    0x4d, 0x3f, 0xc8, 0x96, 0xea, 0xca, 0xb6, 0xae, 0xba, 0x82, 0x2b, 0xb4,
    0x03, 0xad, 0x30, 0x26, 0x63, 0x57, 0x6e, 0x73, 0x63, 0x37, 0x7a, 0xa3,
    0xde, 0x6c, 0x2a, 0x0c, 0xc5, 0x0b, 0x91, 0x29, 0x6a, 0x11, 0xd9, 0x04,
    0x11, 0x15, 0x87, 0x1f, 0xa8, 0xa0, 0xe0, 0x85, 0x3a, 0x61, 0x55, 0xa6,
    0xe2, 0x45, 0xd9, 0x54, 0x64, 0xb4, 0xab, 0x05, 0xb7, 0x1a, 0x8c, 0x3d,
    0x6d, 0x4f, 0xd6, 0x65, 0x98, 0x2c, 0xc9, 0x49, 0x72, 0x3e, 0xd2, 0xe4,
    0x9c, 0xbf, 0x77, 0x95, 0xce, 0xe9, 0x8d, 0xef, 0xe5, 0xcb, 0xc3, 0x8f,
    0x87, 0xf7, 0x7d, 0x1e, 0x21, 0xa5, 0xe4, 0xff, 0x4c, 0xf0, 0x56, 0x4b,
    0x21, 0x84, 0xe8, 0x7e, 0x87, 0xf1, 0x58, 0x3b, 0xbb, 0x03, 0x2d, 0x65,
    0xa0, 0x59, 0x56, 0x16, 0x02, 0xe5, 0xf6, 0xaf, 0xb3, 0x13, 0x95, 0xb9,
    0x7f, 0x68, 0x6f, 0x76, 0xb0, 0xf3, 0x8c, 0xb8, 0x6b, 0x57, 0xff, 0xbd,
    0x2f, 0x6e, 0x8b, 0x8e, 0x1d, 0xe8, 0xd1, 0x6e, 0xc7, 0xf4, 0x2b, 0xcc,
    0xe5, 0x67, 0xb9, 0x98, 0xfd, 0xd9, 0x29, 0x5f, 0xab, 0x9d, 0xf5, 0x9d,
    0xc0, 0x33, 0x2b, 0x13, 0xa6, 0x71, 0x4b, 0xc0, 0x7d, 0xdf, 0xc6, 0x8e,
    0x1c, 0x1a, 0x3c, 0xfa, 0xd1, 0x78, 0xea, 0xfe, 0xf6, 0x42, 0xc8, 0x20,
    0x5b, 0x9f, 0xe7, 0x5a, 0xe5, 0x3a, 0x6d, 0xc1, 0x24, 0x15, 0xcb, 0xe6,
    0x9b, 0xd9, 0x49, 0xae, 0x67, 0x8b, 0x99, 0x46, 0x4d, 0xee, 0x33, 0x4f,
    0x3a, 0xc6, 0x3a, 0xc0, 0xf0, 0xa7, 0x62, 0xfb, 0x43, 0x23, 0x47, 0x67,
    0x0f, 0x6e, 0x7f, 0x58, 0xfb, 0x81, 0x4f, 0x58, 0x72, 0xb2, 0x9c, 0xff,
    0x2e, 0x43, 0x47, 0x5f, 0x14, 0x25, 0xaa, 0xe0, 0x56, 0x83, 0xa8, 0x22,
    0xc6, 0x2f, 0x97, 0xe7, 0xb0, 0x17, 0xdc, 0xef, 0x2d, 0xcf, 0xdb, 0xdf,
    0x7a, 0xb5, 0xe5, 0x2a, 0x00, 0x22, 0x2d, 0xc4, 0x8e, 0xde, 0xd1, 0x17,
    0x46, 0x53, 0x7b, 0xb5, 0x49, 0xf7, 0x6d, 0xae, 0x36, 0x16, 0xf8, 0x71,
    0x72, 0x91, 0x5d, 0xf6, 0x61, 0x86, 0x13, 0xa3, 0xe4, 0x8d, 0x1b, 0xe4,
    0x4a, 0x39, 0xf4, 0xd2, 0x1f, 0x28, 0x71, 0x15, 0x5f, 0x63, 0x6f, 0xb0,
    0xce, 0x7e, 0x00, 0x05, 0x80, 0x47, 0xd8, 0x31, 0x94, 0x1c, 0x3b, 0x90,
    0x91, 0xd3, 0x2c, 0x57, 0x97, 0x98, 0xfa, 0x42, 0x67, 0xcc, 0x3b, 0xc8,
    0x6b, 0x0f, 0xbe, 0x8e, 0x7e, 0xc1, 0xa4, 0x75, 0x21, 0xc9, 0x56, 0x31,
    0x8c, 0xeb, 0xad, 0xe2, 0xe3, 0xa3, 0x44, 0x03, 0x48, 0xc1, 0xb1, 0xb5,
    0x2f, 0xa4, 0xfb, 0xc4, 0x3e, 0x3f, 0x20, 0xb4, 0x45, 0x27, 0x4b, 0x2e,
    0x63, 0x71, 0xb7, 0xf6, 0x00, 0x2f, 0x1d, 0x9a, 0xc0, 0xc2, 0xe2, 0xe5,
    0x23, 0xa7, 0xe8, 0x0a, 0x75, 0xf1, 0x55, 0xe1, 0x0c, 0x73, 0x33, 0x27,
    0xe8, 0x08, 0x77, 0xd2, 0x8a, 0x94, 0xb1, 0x44, 0x63, 0x7c, 0x0d, 0x10,
    0x12, 0xe1, 0x3b, 0x4b, 0xad, 0x12, 0x66, 0xc5, 0x24, 0xd1, 0x1b, 0xe7,
    0xa9, 0xdd, 0x4f, 0x62, 0xe3, 0xe0, 0xe2, 0x90, 0x8e, 0xf7, 0xa3, 0x11,
    0xa1, 0xee, 0x59, 0x84, 0x15, 0x8d, 0xa4, 0xd6, 0x83, 0x15, 0x70, 0xf1,
    0xbd, 0xb2, 0xfa, 0x77, 0x0e, 0x1a, 0x41, 0x7b, 0xb9, 0x6c, 0x20, 0xe2,
    0x1e, 0xe6, 0x6a, 0x91, 0xd3, 0xfa, 0x2b, 0x3c, 0x36, 0xf0, 0x1c, 0xa6,
    0x5f, 0xe1, 0xd4, 0xfc, 0xf3, 0xcc, 0xe4, 0x67, 0xa9, 0xaf, 0xba, 0xdc,
    0x16, 0x1b, 0x20, 0x12, 0x6a, 0x47, 0x3a, 0x06, 0xb2, 0x29, 0x17, 0xd6,
    0x6e, 0x50, 0x32, 0x9a, 0x53, 0xbd, 0x22, 0x4d, 0x32, 0x92, 0x46, 0xf5,
    0xe2, 0x9c, 0xd5, 0xbf, 0xe4, 0xcd, 0xec, 0x49, 0x0c, 0x7b, 0x99, 0x73,
    0x8b, 0xe7, 0xd0, 0xcd, 0x25, 0x92, 0x91, 0x1e, 0xb6, 0x24, 0xb6, 0xd2,
    0x6a, 0x7a, 0x58, 0x05, 0x0b, 0x7c, 0x3e, 0x5b, 0x73, 0x50, 0xd6, 0x1b,
    0xe7, 0xf5, 0xe5, 0xc5, 0xdf, 0x7b, 0xda, 0xfa, 0xb6, 0x6d, 0x8e, 0x0e,
    0xd1, 0xad, 0xa6, 0xb9, 0x94, 0xbf, 0x44, 0xa1, 0x5e, 0xe6, 0x8e, 0xc4,
    0x4e, 0x12, 0xe1, 0x2e, 0x52, 0x1b, 0x36, 0x52, 0x5c, 0x2d, 0x71, 0x55,
    0xcf, 0x51, 0xbf, 0x61, 0xe5, 0x91, 0xbc, 0xbb, 0x2e, 0x07, 0x7d, 0x27,
    0xa2, 0xc7, 0xfb, 0xb7, 0x6c, 0x7e, 0x63, 0x64, 0x64, 0x94, 0x54, 0x2c,
    0x4d, 0x40, 0x0a, 0x9a, 0xbe, 0x87, 0x16, 0xd4, 0xf0, 0x25, 0xac, 0x54,
    0x57, 0x98, 0xfe, 0x75, 0x9a, 0x2b, 0x33, 0x57, 0xb0, 0x6a, 0xd6, 0x71,
    0xf9, 0x81, 0x7c, 0x6b, 0x1d, 0x40, 0x8c, 0x0b, 0x25, 0xbd, 0xa7, 0xf7,
    0xfd, 0x64, 0xaa, 0xfb, 0xd1, 0xc1, 0xc1, 0x21, 0x36, 0x26, 0x37, 0x11,
    0x56, 0xc3, 0xd4, 0x1c, 0x9b, 0xdc, 0x9f, 0x06, 0xbf, 0xcd, 0x67, 0xc8,
    0xe9, 0x06, 0x76, 0xc3, 0x3e, 0x2d, 0xdf, 0x93, 0x4f, 0xfc, 0x6b, 0x17,
    0x3a, 0x9f, 0x8e, 0x3e, 0xbb, 0xa1, 0xad, 0xe3, 0xf1, 0x58, 0x67, 0xc7,
    0x26, 0x35, 0x14, 0xc2, 0xaa, 0x59, 0x14, 0x8b, 0x45, 0xaa, 0x56, 0xf5,
    0xb2, 0xd7, 0xf0, 0x26, 0xe4, 0x87, 0xf2, 0xf3, 0xff, 0x2c, 0x13, 0x80,
    0x7a, 0x2c, 0xd4, 0xaf, 0x2a, 0x81, 0x3d, 0xbe, 0x94, 0xf7, 0x78, 0xf8,
    0x76, 0xcb, 0x6b, 0x4e, 0xe1, 0xf2, 0x93, 0xfc, 0x58, 0x16, 0x6e, 0xd6,
    0xfe, 0x05, 0x1d, 0x88, 0x5a, 0xca, 0x43, 0x10, 0x01, 0x10, 0x00, 0x00,
    0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image5_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xac, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0xcf, 0x8b, 0x94,
    0x75, 0x1c, 0xc7, 0x5f, 0xdf, 0x1f, 0xcf, 0x3c, 0xf3, 0x7b, 0x66, 0x77,
    0xd6, 0xd5, 0xad, 0x9d, 0xf1, 0xc7, 0x8a, 0x46, 0x10, 0x28, 0x44, 0x20,
    0x28, 0x2c, 0x48, 0x41, 0x60, 0x74, 0xe9, 0x1f, 0xe8, 0x64, 0x3f, 0x08,
    0xba, 0x05, 0x1e, 0x3c, 0x28, 0x7a, 0x51, 0x08, 0xf2, 0x52, 0xa7, 0x8e,
    0x15, 0x74, 0xf0, 0x50, 0x08, 0x92, 0x48, 0x20, 0x2b, 0x6a, 0x21, 0x51,
    0xb2, 0x90, 0x59, 0xe3, 0xae, 0xb3, 0x3b, 0xdb, 0xb0, 0xb3, 0xce, 0xf8,
    0x3c, 0x33, 0xcf, 0xcc, 0xf3, 0xfd, 0xd1, 0x41, 0xcc, 0x9d, 0xb3, 0xef,
    0xdb, 0xe7, 0xf0, 0x7e, 0xf1, 0xe1, 0xfd, 0xe6, 0x2d, 0xbc, 0xf7, 0xbc,
    0x88, 0xf4, 0xf6, 0xe3, 0xe7, 0xb3, 0x62, 0x76, 0x90, 0x70, 0x54, 0x15,
    0xc3, 0xe3, 0x68, 0xf1, 0xba, 0xb3, 0x22, 0x3f, 0x36, 0x7e, 0xf7, 0x20,
    0xf2, 0xab, 0xd1, 0x70, 0xfc, 0xc8, 0x3a, 0x7f, 0xea, 0xe4, 0x25, 0xff,
    0xeb, 0x76, 0x8f, 0x78, 0xf6, 0xc1, 0xd2, 0xe7, 0xe2, 0x44, 0xb6, 0x52,
    0x38, 0x53, 0xaa, 0x1f, 0x39, 0x5c, 0xda, 0x75, 0x08, 0x95, 0xaf, 0xa1,
    0x54, 0x00, 0xa4, 0x0c, 0xfb, 0x2d, 0xee, 0x5e, 0xfd, 0x8e, 0x95, 0x07,
    0x9d, 0x35, 0xeb, 0xf9, 0xf8, 0x93, 0x2f, 0xfd, 0xe5, 0x09, 0xc0, 0x95,
    0x53, 0x62, 0xdf, 0xf4, 0xee, 0xf0, 0xee, 0xc1, 0xb7, 0x2f, 0x96, 0x73,
    0x3b, 0xde, 0xa5, 0xdf, 0xfe, 0x89, 0xb8, 0xfb, 0x27, 0x66, 0xd4, 0x46,
    0xfa, 0x01, 0xa5, 0x6a, 0xc8, 0x1f, 0x4b, 0x37, 0xf9, 0xed, 0xe6, 0x5f,
    0x78, 0xc9, 0xc8, 0x79, 0x71, 0xbc, 0xd7, 0xf3, 0x4b, 0x67, 0xbe, 0xf7,
    0x5e, 0x03, 0xa4, 0x96, 0xf7, 0x2a, 0x8d, 0x37, 0xca, 0xd5, 0xc6, 0x07,
    0xdc, 0xbb, 0xf6, 0x3e, 0x6b, 0xcb, 0x3f, 0xa2, 0x83, 0x02, 0x41, 0xa8,
    0x11, 0x40, 0x37, 0x97, 0x47, 0x87, 0x19, 0x8a, 0xd5, 0x22, 0xa9, 0x19,
    0x85, 0x71, 0x64, 0x2e, 0x38, 0xc7, 0x9b, 0x40, 0xac, 0x01, 0x54, 0x96,
    0xc5, 0x70, 0xea, 0x35, 0xf0, 0xbf, 0x50, 0x99, 0x49, 0x29, 0x1c, 0x39,
    0x01, 0x3e, 0xc5, 0x8e, 0x63, 0xc6, 0x51, 0x1f, 0x9b, 0x1a, 0x66, 0xf7,
    0xee, 0xa0, 0xbe, 0xbf, 0xc1, 0xdf, 0xbf, 0xdf, 0xe3, 0xd6, 0x8d, 0xd5,
    0xbe, 0x73, 0xd8, 0xe7, 0x21, 0x6a, 0x5e, 0x09, 0x0b, 0x35, 0xb6, 0x5a,
    0xb7, 0x78, 0x70, 0xe7, 0x36, 0xce, 0x39, 0x94, 0x14, 0x08, 0x29, 0x11,
    0x80, 0xd0, 0x19, 0x06, 0x71, 0x44, 0x7d, 0x7f, 0x9d, 0x24, 0xf1, 0x18,
    0xc3, 0xf5, 0xf3, 0x97, 0x7d, 0xf2, 0x3f, 0xc0, 0x58, 0xf6, 0x4a, 0xad,
    0x71, 0xa3, 0x36, 0xd3, 0xb3, 0x55, 0x32, 0x85, 0x69, 0x94, 0x12, 0x08,
    0xf1, 0x34, 0x60, 0x11, 0xe4, 0x90, 0x3a, 0xc4, 0x8c, 0x23, 0x36, 0xd6,
    0x1f, 0xe3, 0x2c, 0x0f, 0x27, 0x6a, 0x4c, 0x53, 0xf0, 0x2e, 0xc6, 0x8e,
    0x23, 0x7a, 0x9d, 0x1e, 0x4f, 0xee, 0x37, 0xd1, 0x81, 0x46, 0x69, 0x89,
    0xd6, 0x01, 0x48, 0x4d, 0xae, 0x3c, 0xc5, 0x54, 0x2d, 0x4b, 0x92, 0x38,
    0x9c, 0xa5, 0x3f, 0x09, 0x18, 0xc1, 0x38, 0xd9, 0xc4, 0x25, 0x5d, 0x72,
    0x79, 0x45, 0x75, 0xa6, 0x81, 0x31, 0x16, 0x15, 0x68, 0xa4, 0xce, 0x12,
    0x16, 0xab, 0x04, 0x85, 0x2a, 0xd2, 0x74, 0xc9, 0x64, 0x14, 0x1e, 0xea,
    0xcf, 0x00, 0x12, 0x60, 0x38, 0x64, 0xe3, 0xc9, 0x66, 0x8b, 0xca, 0x4c,
    0x09, 0x84, 0xa0, 0xbb, 0xf1, 0x98, 0xce, 0x5a, 0x87, 0xf6, 0x4a, 0x9b,
    0xf6, 0x4a, 0x8b, 0xf5, 0xe6, 0x0a, 0x9b, 0xad, 0x47, 0xa0, 0x0a, 0xbc,
    0x54, 0xaf, 0x61, 0x1c, 0x47, 0x27, 0x00, 0x49, 0xca, 0xf2, 0xe6, 0xea,
    0x7d, 0xa4, 0x12, 0x44, 0xfd, 0x88, 0x5c, 0x31, 0x64, 0x6e, 0xcf, 0x1c,
    0x8d, 0x85, 0x79, 0x0e, 0x1c, 0x3a, 0xc8, 0xfc, 0xc2, 0x3c, 0xf9, 0x7c,
    0x06, 0xf0, 0xec, 0xd9, 0x37, 0x43, 0xb9, 0xac, 0xde, 0xf9, 0xf4, 0x2d,
    0xf1, 0xea, 0xf6, 0x16, 0xae, 0x36, 0x97, 0xff, 0x59, 0xdc, 0x55, 0xdf,
    0xc9, 0xec, 0xce, 0x22, 0xbd, 0xbe, 0x61, 0xed, 0x61, 0x87, 0xe1, 0xc0,
    0x22, 0x74, 0x9b, 0x62, 0x29, 0x4f, 0x79, 0xaa, 0x84, 0xf4, 0x43, 0xdc,
    0x68, 0x8b, 0x7c, 0x56, 0x54, 0x0a, 0x45, 0xbe, 0x02, 0x8e, 0x69, 0x00,
    0x29, 0xf9, 0x36, 0x8a, 0xdd, 0x87, 0x37, 0xae, 0xdc, 0xae, 0x0b, 0x29,
    0x48, 0x12, 0x3b, 0x4a, 0x53, 0xdf, 0x34, 0xa9, 0x5f, 0xb7, 0x8e, 0xb2,
    0xf7, 0x62, 0xc1, 0x23, 0x2b, 0x28, 0x49, 0x46, 0x7b, 0xe2, 0xd8, 0x10,
    0x04, 0xd4, 0x26, 0xb6, 0xf0, 0xc5, 0x49, 0xf1, 0x91, 0xb3, 0x7c, 0xe6,
    0x3c, 0x5f, 0x7b, 0xc7, 0x0f, 0xd6, 0xf2, 0xef, 0x28, 0x61, 0x4b, 0x28,
    0x72, 0xce, 0x31, 0x67, 0x0c, 0x2f, 0x7b, 0xc1, 0x22, 0x70, 0x58, 0x6b,
    0x9a, 0x42, 0x70, 0xee, 0xf4, 0x37, 0xbe, 0x29, 0x5e, 0x74, 0xce, 0xff,
    0x01, 0x16, 0x90, 0x34, 0x2e, 0x69, 0x04, 0xe5, 0xa9, 0x00, 0x00, 0x00,
    0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image6_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xbe, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0x95, 0x92, 0x4b, 0x68, 0x54,
    0x07, 0x14, 0x86, 0xbf, 0x7b, 0x67, 0x26, 0x93, 0xd4, 0x79, 0xaa, 0x49,
    0x34, 0x9a, 0x90, 0x44, 0x05, 0xad, 0xa6, 0x4e, 0x45, 0x71, 0xa1, 0xe8,
    0x42, 0xa9, 0x1b, 0x4b, 0x1b, 0x4b, 0xa8, 0xd0, 0x0a, 0x82, 0x98, 0x85,
    0x0a, 0x16, 0x4a, 0x17, 0xba, 0x93, 0x76, 0x5b, 0x8a, 0xe2, 0xc2, 0xac,
    0x5c, 0x49, 0xeb, 0x0b, 0xbb, 0x2b, 0x8a, 0x4a, 0xc4, 0xd0, 0x68, 0x30,
    0xa6, 0x3e, 0x48, 0xb0, 0x8a, 0x5a, 0xe3, 0x4c, 0xe2, 0xc4, 0xcc, 0xbd,
    0x77, 0xe6, 0xce, 0x7d, 0xce, 0xbd, 0xa7, 0x8b, 0x62, 0x34, 0xa6, 0x8b,
    0xf6, 0x87, 0xb3, 0x39, 0xf0, 0x7f, 0xe7, 0xc0, 0xff, 0x23, 0x22, 0xfc,
    0x97, 0xa1, 0x0f, 0xe5, 0xdf, 0xf6, 0x8a, 0x88, 0xf0, 0xae, 0xbe, 0xb8,
    0xfc, 0x61, 0x46, 0x44, 0xf6, 0x8a, 0xaa, 0xee, 0xf6, 0x82, 0x70, 0xa3,
    0xed, 0xf8, 0x98, 0x9a, 0xf3, 0xc0, 0xac, 0x78, 0xfd, 0xba, 0xef, 0x7c,
    0x3f, 0x91, 0xaa, 0x94, 0x80, 0x50, 0x7a, 0xff, 0x31, 0xce, 0x02, 0x7c,
    0x79, 0x6d, 0x4d, 0xae, 0x63, 0xd1, 0x8a, 0x2b, 0x9f, 0xb6, 0xef, 0x6b,
    0x5c, 0x10, 0x5f, 0x8a, 0x5e, 0x2b, 0x91, 0x77, 0xc6, 0x79, 0x69, 0x8d,
    0x73, 0xe1, 0xde, 0x19, 0x0a, 0x7f, 0x16, 0x2b, 0x66, 0xc5, 0xed, 0x29,
    0x36, 0x55, 0xaf, 0x49, 0xaf, 0xd4, 0x66, 0x01, 0xba, 0x7f, 0x5b, 0x95,
    0x5b, 0xb7, 0x7c, 0xc3, 0xe0, 0x57, 0xcb, 0xbe, 0xad, 0x1f, 0xa8, 0x9d,
    0x67, 0xcc, 0x1c, 0xc1, 0xb0, 0x6c, 0xf4, 0xaa, 0x85, 0x6d, 0x09, 0x4d,
    0xb1, 0x4e, 0x86, 0xc6, 0x6f, 0x33, 0x79, 0xff, 0x35, 0x96, 0xe5, 0x6e,
    0x2a, 0x2f, 0xf1, 0x06, 0xa5, 0x57, 0x44, 0x7d, 0x73, 0x3d, 0x93, 0x59,
    0x78, 0x79, 0x57, 0xc7, 0xa1, 0xfa, 0x5f, 0xfd, 0x1f, 0x99, 0xe0, 0x11,
    0x9e, 0x1b, 0xf0, 0xe4, 0x8e, 0x8e, 0xbc, 0x4a, 0x60, 0x07, 0x16, 0x77,
    0x8b, 0xb7, 0x08, 0x10, 0x64, 0x11, 0xe0, 0x2b, 0xbf, 0x00, 0x11, 0x00,
    0x15, 0x60, 0xdb, 0xd9, 0xce, 0xc3, 0xdb, 0x97, 0xf5, 0x34, 0x5d, 0x34,
    0x4e, 0x50, 0xb2, 0x35, 0x2a, 0xb6, 0x4b, 0xa1, 0xa0, 0x73, 0x6e, 0xc7,
    0x75, 0x7e, 0xde, 0x72, 0x95, 0x20, 0x08, 0xf0, 0xc3, 0x10, 0xd3, 0xab,
    0xa2, 0x34, 0x44, 0xa1, 0x41, 0x6d, 0x8d, 0x8d, 0x45, 0xba, 0x67, 0x00,
    0xa1, 0xaa, 0xec, 0x8e, 0xd6, 0xd5, 0x93, 0xaf, 0xe6, 0xc9, 0x4f, 0x6a,
    0x78, 0xb7, 0xdb, 0x59, 0x67, 0x7e, 0x46, 0xa6, 0x21, 0x03, 0xc0, 0x27,
    0xfe, 0x1e, 0x56, 0x86, 0x39, 0x22, 0xc4, 0x48, 0xc6, 0x52, 0xc4, 0x92,
    0x75, 0x48, 0x28, 0x6b, 0x01, 0xa2, 0x00, 0xbe, 0x84, 0x6b, 0x9e, 0x9a,
    0x8f, 0xa8, 0xd8, 0x36, 0x13, 0xa3, 0x36, 0xa7, 0x77, 0x9d, 0x98, 0x95,
    0xcc, 0x77, 0x9b, 0x8f, 0xf0, 0x7b, 0x7e, 0x80, 0xfd, 0xc3, 0x7b, 0x99,
    0x17, 0x4f, 0x61, 0xc6, 0x1c, 0x02, 0xdf, 0xf8, 0x68, 0xe6, 0x03, 0xd7,
    0xa9, 0x25, 0xf2, 0x66, 0x1e, 0xd3, 0x72, 0x69, 0xee, 0x48, 0x70, 0xb3,
    0x78, 0x95, 0x17, 0xfa, 0x5f, 0x00, 0x18, 0xae, 0xc1, 0x60, 0x61, 0x80,
    0x21, 0xe3, 0x16, 0xd9, 0xfa, 0x85, 0x24, 0xeb, 0xd2, 0xa8, 0xb5, 0x08,
    0x22, 0x3c, 0x7b, 0x0b, 0xb0, 0x82, 0xfc, 0xab, 0xea, 0x34, 0x9e, 0xaf,
    0x32, 0xe5, 0x1a, 0x1c, 0x7d, 0x7c, 0x00, 0xbd, 0xaa, 0x03, 0x30, 0xa6,
    0x3f, 0xe4, 0xeb, 0xa1, 0x1e, 0x2e, 0xbc, 0x3c, 0x4f, 0x7b, 0xba, 0x13,
    0x50, 0x70, 0xa6, 0x1d, 0x78, 0x17, 0xe0, 0x99, 0x72, 0xbd, 0xa4, 0xe9,
    0x64, 0x23, 0x2d, 0x64, 0x94, 0x16, 0xa2, 0x41, 0x92, 0x62, 0x30, 0x49,
    0xd9, 0x2b, 0xf3, 0xdc, 0x7e, 0xc6, 0xca, 0x6c, 0x17, 0xb9, 0xe6, 0xf5,
    0x24, 0x62, 0x49, 0x5e, 0x4f, 0x4d, 0x53, 0xd1, 0x4c, 0x10, 0x2e, 0xcd,
    0xf4, 0xa0, 0xfd, 0x87, 0xc6, 0x8f, 0xe7, 0x37, 0x2e, 0xb8, 0xdb, 0xb5,
    0x7e, 0x2d, 0x2d, 0x89, 0x56, 0xbc, 0xd0, 0xc3, 0x74, 0x4c, 0x54, 0x25,
    0x42, 0x2a, 0x9e, 0x21, 0x19, 0x4b, 0x52, 0x76, 0x4d, 0x86, 0x9f, 0x0f,
    0x33, 0x32, 0x30, 0x82, 0xa6, 0x69, 0xc7, 0xe5, 0x94, 0x7c, 0x33, 0xab,
    0x48, 0x6d, 0xc7, 0x1a, 0x4f, 0x2e, 0xe9, 0x68, 0x3b, 0xd8, 0xb5, 0x3a,
    0x47, 0x6b, 0xba, 0x8d, 0x78, 0x24, 0x0e, 0x8a, 0x82, 0x1f, 0xf8, 0x14,
    0xca, 0x05, 0x1e, 0x3c, 0x79, 0xc8, 0xe8, 0x1f, 0xa3, 0x68, 0x25, 0xed,
    0x5e, 0x18, 0x86, 0x5b, 0xa5, 0x4f, 0x8c, 0x39, 0x55, 0x6e, 0x3a, 0x9a,
    0x3d, 0x99, 0xcd, 0x64, 0x0f, 0x36, 0x2f, 0x5d, 0x4c, 0x2a, 0x95, 0x46,
    0x04, 0xb4, 0xb2, 0xce, 0xc4, 0x8b, 0x02, 0xc5, 0xe2, 0x14, 0xb6, 0x6d,
    0xf7, 0x8b, 0xc8, 0xe7, 0x6f, 0xcc, 0x73, 0x00, 0x00, 0xd1, 0x03, 0xea,
    0xd6, 0xc4, 0x07, 0x89, 0xfd, 0x75, 0xd1, 0xf8, 0xce, 0x20, 0x0c, 0xd3,
    0x96, 0x63, 0x19, 0x8e, 0xeb, 0xf4, 0x03, 0x3f, 0x49, 0x9f, 0xdc, 0xe0,
    0x3d, 0xcd, 0x01, 0xfc, 0x5f, 0xfd, 0x0d, 0x53, 0x24, 0x9c, 0x3b, 0x0c,
    0x56, 0xcd, 0xe2, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae,
    0x42, 0x60, 0x82
};

static const unsigned char image7_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xb5, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x92, 0x4b, 0x6c, 0x54,
    0x65, 0x18, 0x86, 0x9f, 0xff, 0x5c, 0x66, 0xce, 0x30, 0xf7, 0xa9, 0x6d,
    0xa7, 0x30, 0x5e, 0x5a, 0x4b, 0xb9, 0x04, 0x28, 0xc6, 0x05, 0x48, 0x08,
    0xa4, 0x26, 0x18, 0xed, 0xc2, 0x2d, 0x09, 0x0b, 0xd8, 0x10, 0xab, 0x0b,
    0x20, 0x31, 0x1a, 0x23, 0x9a, 0x82, 0x51, 0x30, 0x69, 0x5c, 0x34, 0x01,
    0x5d, 0xb8, 0x73, 0x41, 0xc0, 0x25, 0x0b, 0xc2, 0x25, 0xec, 0x2a, 0x24,
    0x24, 0x15, 0x34, 0x46, 0xb4, 0x4c, 0x33, 0x86, 0xa1, 0x85, 0x69, 0x67,
    0xa6, 0x63, 0xe7, 0x30, 0x67, 0xe6, 0xdc, 0xfe, 0x9f, 0x5d, 0x43, 0xb5,
    0x1b, 0xe3, 0xbb, 0xfc, 0xf2, 0x7d, 0x4f, 0xbe, 0xbc, 0xef, 0x2b, 0x94,
    0x52, 0xfc, 0x1f, 0x19, 0x6b, 0x0d, 0x7f, 0x14, 0x22, 0xa6, 0x25, 0x93,
    0xfb, 0xe2, 0x52, 0xee, 0x95, 0x61, 0xd8, 0xdf, 0x08, 0x83, 0x52, 0xc5,
    0x0f, 0xae, 0x39, 0xf0, 0xf3, 0x29, 0xa5, 0xdc, 0xe7, 0x77, 0xc5, 0xf3,
    0x1f, 0x7c, 0x21, 0x84, 0xb1, 0xaf, 0xaf, 0x77, 0xa4, 0xb7, 0xbf, 0xf0,
    0xd1, 0xba, 0x6d, 0x5b, 0xde, 0x32, 0xb2, 0x19, 0x54, 0xb3, 0x8e, 0x3d,
    0x53, 0x64, 0xee, 0xf7, 0xd9, 0x4e, 0xb9, 0xd6, 0xbc, 0x51, 0x0f, 0xe5,
    0xe9, 0x4f, 0x94, 0xba, 0xb7, 0x26, 0xe0, 0xa7, 0x9e, 0xae, 0x8f, 0x07,
    0x8e, 0x1e, 0x9e, 0xc8, 0x8f, 0xec, 0x42, 0x9b, 0xff, 0x03, 0xaf, 0x58,
    0xc4, 0x5b, 0xa8, 0x11, 0x04, 0x1a, 0x6e, 0xcb, 0xa5, 0x34, 0x7d, 0x9f,
    0xdf, 0xca, 0xd5, 0xc5, 0xc7, 0x52, 0xbd, 0x7b, 0x5a, 0xa9, 0x3b, 0xab,
    0x00, 0x57, 0x84, 0x38, 0xb0, 0x7d, 0xec, 0xf0, 0x8d, 0x97, 0x0e, 0x8d,
    0xe2, 0x5c, 0x3c, 0x87, 0xbb, 0xd8, 0x40, 0xef, 0xb8, 0x2c, 0x37, 0x3c,
    0x42, 0x27, 0xc0, 0x75, 0x03, 0x58, 0x97, 0xa6, 0x5c, 0x7a, 0xc2, 0x2f,
    0x7f, 0x3b, 0xc5, 0xa6, 0x50, 0x7b, 0xbe, 0x94, 0xaa, 0xa6, 0x01, 0x1c,
    0x12, 0xc2, 0xea, 0x19, 0xde, 0x32, 0xd1, 0xfb, 0xc6, 0x30, 0xf6, 0xb7,
    0x67, 0x28, 0xda, 0x59, 0x5a, 0x07, 0x3f, 0xa3, 0x91, 0x1b, 0xa4, 0xfa,
    0xfa, 0x3b, 0xc4, 0xc6, 0x3e, 0x44, 0x65, 0x72, 0xd4, 0x1f, 0x57, 0x49,
    0x46, 0x74, 0x72, 0x86, 0xbe, 0x51, 0x2a, 0xf1, 0xde, 0x8a, 0x89, 0xfb,
    0x61, 0x24, 0xb9, 0x79, 0x70, 0xa7, 0xf8, 0x75, 0x8a, 0xe5, 0x85, 0x26,
    0x7d, 0xe3, 0xc7, 0xe9, 0x79, 0xf3, 0x00, 0xb5, 0xcd, 0x5b, 0x59, 0xdf,
    0xd7, 0x83, 0xd9, 0xdd, 0x8b, 0x6a, 0xd9, 0x54, 0x26, 0xbe, 0xc1, 0x34,
    0x2c, 0xb2, 0x51, 0x13, 0x33, 0x90, 0x1f, 0x00, 0x67, 0x35, 0x80, 0x2c,
    0x8c, 0xea, 0x9e, 0x83, 0x33, 0x57, 0xc1, 0x8a, 0x44, 0xb0, 0x2f, 0x7e,
    0x8f, 0xf3, 0x70, 0x96, 0x17, 0x76, 0x0c, 0x63, 0xc6, 0x23, 0x78, 0x77,
    0x6f, 0xb3, 0x78, 0xf5, 0x1a, 0xa1, 0x61, 0x62, 0x64, 0x52, 0x44, 0x2d,
    0x0b, 0x4d, 0x88, 0x02, 0x80, 0x06, 0x10, 0x42, 0x77, 0xb0, 0x50, 0xc1,
    0x5f, 0x76, 0x58, 0xaa, 0xd8, 0xf8, 0x85, 0x41, 0xcc, 0xa8, 0x01, 0x9d,
    0x06, 0xa8, 0x00, 0x15, 0xfa, 0x04, 0x89, 0x34, 0x46, 0x3a, 0x45, 0x3c,
    0x9b, 0x42, 0x9a, 0x3a, 0x3e, 0xb8, 0x2b, 0x80, 0x25, 0x98, 0x6e, 0xbb,
    0x01, 0x42, 0x33, 0x91, 0x52, 0x90, 0x2e, 0xac, 0xc7, 0xcc, 0x77, 0xe3,
    0xdc, 0x9e, 0xe2, 0xe9, 0xf4, 0x5d, 0xa2, 0xc3, 0x3b, 0xd9, 0xf4, 0xf9,
    0x49, 0x72, 0x43, 0xfd, 0x58, 0xba, 0x46, 0xcd, 0xf3, 0x09, 0x94, 0xbc,
    0xbe, 0xe2, 0x41, 0x11, 0x2e, 0x0f, 0xd8, 0xed, 0xf1, 0x0d, 0xf9, 0x4c,
    0x32, 0xf1, 0x4a, 0x01, 0xfb, 0xd2, 0x0f, 0xa8, 0x6a, 0x85, 0xda, 0xcd,
    0x9b, 0xc8, 0x64, 0x9a, 0x01, 0x75, 0x0c, 0xf7, 0xde, 0x1d, 0xba, 0xac,
    0x08, 0x7f, 0xd5, 0x6d, 0xe6, 0xed, 0xb6, 0xd4, 0x50, 0x13, 0xab, 0x62,
    0xfc, 0x2e, 0x1e, 0x9b, 0xdc, 0xfa, 0x72, 0xdf, 0x89, 0x6d, 0xaf, 0x0d,
    0x22, 0x4d, 0x9d, 0x8e, 0x17, 0x10, 0x84, 0x12, 0x2d, 0xa2, 0x13, 0xcb,
    0x76, 0xa1, 0xaa, 0x55, 0x1e, 0x95, 0x2a, 0xdc, 0xfa, 0xb3, 0x4c, 0xad,
    0x69, 0x9f, 0xff, 0x4a, 0xa9, 0x63, 0xab, 0xaa, 0x3c, 0xeb, 0x74, 0x4e,
    0x31, 0x5f, 0xdf, 0xd4, 0x86, 0xb7, 0x87, 0x86, 0x5e, 0x24, 0x91, 0x4d,
    0x10, 0x8b, 0x5a, 0x04, 0xae, 0x4b, 0x7d, 0xa6, 0xc4, 0x6c, 0x79, 0x91,
    0x07, 0x73, 0x55, 0x96, 0x5b, 0xed, 0xcb, 0x12, 0x3e, 0x5d, 0xb3, 0x89,
    0xe3, 0xc2, 0x4c, 0x25, 0x2d, 0xf3, 0x64, 0x32, 0x93, 0x38, 0x92, 0x4b,
    0xc5, 0xf3, 0x56, 0x44, 0xa7, 0xd9, 0xf6, 0xa8, 0x35, 0x6c, 0x6c, 0xbb,
    0x35, 0xd3, 0xf1, 0xfd, 0x49, 0x09, 0x17, 0xbe, 0x56, 0xca, 0x5e, 0x13,
    0x00, 0xf0, 0xbe, 0x10, 0x46, 0xde, 0x8c, 0xbc, 0x2a, 0x74, 0x7d, 0x04,
    0xa5, 0x76, 0x23, 0xa5, 0x13, 0xfa, 0xc1, 0x94, 0x87, 0xbc, 0xd5, 0x81,
    0x47, 0x93, 0xff, 0x38, 0xf8, 0x17, 0xe0, 0xbf, 0xea, 0x19, 0x0f, 0x01,
    0x48, 0xa1, 0x67, 0xb1, 0xb5, 0x30, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45,
    0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image8_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00, 0x16,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xc4, 0xb4, 0x6c, 0x3b, 0x00, 0x00, 0x00,
    0x74, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xd5, 0xd4, 0xd1, 0x0a, 0x80,
    0x30, 0x08, 0x05, 0xd0, 0x8c, 0xbe, 0xca, 0xff, 0xe7, 0xfe, 0x56, 0x3d,
    0x05, 0x12, 0x6a, 0x77, 0xb8, 0x91, 0xdd, 0x97, 0xc1, 0xc6, 0x8e, 0xe0,
    0x64, 0x02, 0x60, 0x5b, 0x91, 0x7d, 0x89, 0xfa, 0x4b, 0xf8, 0xf0, 0x36,
    0x55, 0xf5, 0x7c, 0xbb, 0x08, 0x40, 0xb2, 0x73, 0x89, 0x1e, 0xcf, 0xe2,
    0x16, 0x89, 0xf6, 0x9f, 0x19, 0x6e, 0x45, 0x54, 0xa4, 0x0c, 0xb3, 0xe9,
    0x03, 0xb3, 0x3d, 0x76, 0xa7, 0x22, 0xc3, 0x18, 0x94, 0x86, 0xbd, 0x07,
    0xbb, 0xd7, 0xa8, 0x40, 0x69, 0x2a, 0x6c, 0x81, 0x32, 0xec, 0xe1, 0xd3,
    0x60, 0x26, 0xbd, 0x60, 0x66, 0xe4, 0xdc, 0xbf, 0x82, 0xf9, 0x84, 0x32,
    0x34, 0x84, 0x67, 0xa4, 0x57, 0x8f, 0x3f, 0x85, 0x2f, 0x7c, 0x4f, 0x37,
    0xca, 0xa2, 0x25, 0x44, 0xaa, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e,
    0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image9_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00, 0x16,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xc4, 0xb4, 0x6c, 0x3b, 0x00, 0x00, 0x00,
    0x58, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0x63, 0x3c, 0x76, 0xec, 0x18,
    0x03, 0x2d, 0x00, 0x13, 0x4d, 0x4c, 0x1d, 0x92, 0x06, 0xb3, 0x10, 0xab,
    0xd0, 0xca, 0xca, 0xea, 0x3f, 0xba, 0xd8, 0xb1, 0x63, 0xc7, 0x18, 0x71,
    0xa9, 0x27, 0xda, 0xc5, 0xe8, 0x86, 0xe0, 0x33, 0x94, 0x24, 0x83, 0x49,
    0x05, 0xc3, 0xd8, 0x60, 0xe4, 0xc8, 0x23, 0x14, 0xbe, 0x24, 0x19, 0x4c,
    0x2a, 0x18, 0xa6, 0x06, 0x93, 0x1a, 0xbe, 0x44, 0x1b, 0x4c, 0x0e, 0x18,
    0x86, 0x06, 0xa3, 0x17, 0x3e, 0xd8, 0x0a, 0x23, 0x6c, 0x80, 0x71, 0xb4,
    0x06, 0xa1, 0xb9, 0xc1, 0x00, 0xd0, 0x40, 0x18, 0xd1, 0x23, 0xfc, 0x59,
    0x10, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60,
    0x82
};

static const unsigned char image10_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00, 0x16,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xc4, 0xb4, 0x6c, 0x3b, 0x00, 0x00, 0x00,
    0x68, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0x63, 0x3c, 0x76, 0xec, 0x18,
    0x03, 0x2d, 0x00, 0x13, 0x4d, 0x4c, 0x1d, 0x92, 0x06, 0xb3, 0x60, 0x13,
    0xb4, 0xb2, 0xb2, 0xfa, 0x8f, 0x2e, 0x76, 0xec, 0xd8, 0x31, 0x46, 0x5c,
    0xf2, 0xc8, 0x72, 0x30, 0xc0, 0x88, 0x2b, 0xf2, 0x90, 0x35, 0x63, 0xd3,
    0x08, 0x53, 0x83, 0x4b, 0x6e, 0xe8, 0x85, 0xf1, 0xa8, 0xc1, 0xa3, 0x06,
    0x53, 0xd1, 0x60, 0x6c, 0xb9, 0x93, 0x28, 0x83, 0xf1, 0x65, 0x61, 0x18,
    0x1f, 0x57, 0xae, 0x63, 0x60, 0xc0, 0x93, 0xa5, 0x09, 0xb9, 0x0c, 0x9f,
    0xa1, 0x44, 0x19, 0x4c, 0x2e, 0x20, 0xba, 0x74, 0xc3, 0x07, 0x48, 0x2a,
    0xdd, 0x28, 0x05, 0x83, 0x2f, 0xb9, 0x11, 0x02, 0x00, 0x5f, 0x49, 0x2d,
    0x73, 0x88, 0x62, 0x34, 0x9b, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e,
    0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image11_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00, 0x16,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xc4, 0xb4, 0x6c, 0x3b, 0x00, 0x00, 0x00,
    0x4e, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0x63, 0x3c, 0x76, 0xec, 0x18,
    0x03, 0x2d, 0x00, 0x13, 0x4d, 0x4c, 0x65, 0x60, 0x60, 0x60, 0x81, 0x31,
    0xac, 0xac, 0xac, 0xfe, 0x53, 0x6a, 0xd8, 0xb1, 0x63, 0xc7, 0x18, 0x61,
    0x6c, 0x46, 0x5a, 0x05, 0x05, 0x45, 0x2e, 0x46, 0x76, 0x21, 0x3a, 0x18,
    0x9c, 0x2e, 0x46, 0x07, 0xa3, 0x61, 0x8c, 0x15, 0x8c, 0x86, 0x31, 0x1c,
    0x0c, 0x4e, 0x17, 0xa3, 0x83, 0xd1, 0x30, 0xc6, 0x0a, 0x86, 0x5e, 0x18,
    0xd3, 0xac, 0x6a, 0xa2, 0x99, 0xc1, 0x00, 0x10, 0x23, 0x3b, 0x69, 0x74,
    0x72, 0xf9, 0x13, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae,
    0x42, 0x60, 0x82
};

static const unsigned char image12_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00, 0x16,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xc4, 0xb4, 0x6c, 0x3b, 0x00, 0x00, 0x00,
    0x50, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xed, 0x95, 0x31, 0x0a, 0x00,
    0x20, 0x0c, 0x03, 0x53, 0xe9, 0xab, 0xfa, 0x7f, 0xf2, 0x2d, 0x9d, 0x14,
    0x07, 0x71, 0xa8, 0xc4, 0xa9, 0xb7, 0xd5, 0x21, 0x1c, 0xb7, 0x68, 0x24,
    0xa1, 0xa0, 0x49, 0x56, 0x01, 0xf8, 0x7e, 0x44, 0x44, 0x7f, 0x1d, 0x24,
    0x69, 0x00, 0x60, 0xaa, 0x14, 0x7e, 0x7a, 0xcc, 0x98, 0x4f, 0xd3, 0xc9,
    0x1f, 0xe3, 0x6a, 0x9c, 0x95, 0xba, 0x52, 0x8d, 0x17, 0xd5, 0x78, 0x51,
    0x8d, 0xf5, 0x8d, 0x65, 0x5f, 0x93, 0x6c, 0x78, 0x00, 0x00, 0x14, 0x3b,
    0x69, 0x5e, 0xef, 0xf2, 0xc4, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e,
    0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image13_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00, 0x16,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xc4, 0xb4, 0x6c, 0x3b, 0x00, 0x00, 0x00,
    0x4c, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0x63, 0x3c, 0x76, 0xec, 0x18,
    0x03, 0x2d, 0x00, 0x13, 0x4d, 0x4c, 0x65, 0x60, 0x60, 0x60, 0x41, 0xe6,
    0x58, 0x59, 0x59, 0xfd, 0xa7, 0xd4, 0xc0, 0x63, 0xc7, 0x8e, 0x31, 0x32,
    0x30, 0x30, 0x30, 0x30, 0xd2, 0x2a, 0x28, 0x58, 0xf0, 0x49, 0x92, 0xe3,
    0x03, 0xfa, 0xba, 0x78, 0x34, 0x8c, 0xc9, 0x75, 0x14, 0x5e, 0x30, 0x1a,
    0xc6, 0xa3, 0x61, 0x8c, 0x09, 0x46, 0xc3, 0x98, 0xf6, 0x2e, 0xa6, 0x59,
    0xd5, 0x44, 0x33, 0x83, 0x01, 0x80, 0x05, 0x3b, 0x69, 0x3f, 0xb6, 0xbe,
    0x17, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60,
    0x82
};

static const unsigned char image14_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00, 0x16,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xc4, 0xb4, 0x6c, 0x3b, 0x00, 0x00, 0x00,
    0x46, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xed, 0xd5, 0x31, 0x0a, 0x00,
    0x20, 0x0c, 0x04, 0xc1, 0x8d, 0xf8, 0xaa, 0xfc, 0x9f, 0xfb, 0x96, 0x56,
    0x82, 0x68, 0x29, 0x57, 0x99, 0xed, 0x6c, 0x8e, 0x21, 0x8d, 0x21, 0x09,
    0x47, 0xcd, 0xb2, 0x0a, 0xf4, 0xfd, 0x91, 0x99, 0xe3, 0x75, 0x50, 0x52,
    0x00, 0x84, 0xeb, 0x14, 0x25, 0x2e, 0xf1, 0x5d, 0x89, 0x4b, 0x7c, 0xf7,
    0xa1, 0x78, 0x09, 0xcf, 0x6c, 0x62, 0xdb, 0xd7, 0x64, 0x1b, 0x9e, 0x10,
    0x84, 0x3b, 0x69, 0xa9, 0x9b, 0x40, 0x0c, 0x00, 0x00, 0x00, 0x00, 0x49,
    0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image15_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0x79, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0xbd, 0x6b, 0xd4,
    0x70, 0x1c, 0x87, 0x9f, 0xe4, 0x72, 0xb9, 0x24, 0x77, 0xb5, 0x96, 0xb3,
    0x2f, 0x08, 0xbe, 0x50, 0x5f, 0x50, 0xc1, 0xa2, 0x05, 0x71, 0x10, 0x51,
    0x27, 0x71, 0x72, 0x71, 0x74, 0x10, 0x77, 0xff, 0x05, 0x41, 0x74, 0x10,
    0x05, 0x41, 0x10, 0x1d, 0x1d, 0x04, 0x41, 0x17, 0xbb, 0xa8, 0x20, 0x62,
    0xd5, 0xc1, 0x8a, 0xa2, 0x22, 0x5a, 0x5f, 0x6b, 0xab, 0xad, 0x7a, 0xe6,
    0xb8, 0xcb, 0xe5, 0x92, 0x4b, 0x2e, 0xc9, 0xfd, 0xf2, 0xfb, 0x39, 0x14,
    0x0b, 0x82, 0xb8, 0xf4, 0x0b, 0x9f, 0xf1, 0xfb, 0x0c, 0x1f, 0x3e, 0x8f,
    0xa6, 0x94, 0x62, 0x39, 0xa7, 0x2f, 0xeb, 0x1b, 0x30, 0x00, 0x9e, 0x5e,
    0xd4, 0xb6, 0x28, 0x8a, 0x47, 0xcc, 0x95, 0xce, 0x56, 0xad, 0xe8, 0xec,
    0x48, 0xbb, 0xc9, 0x36, 0xdf, 0x6b, 0x9f, 0x99, 0xb8, 0x26, 0x4f, 0x0f,
    0x8f, 0x62, 0xab, 0x82, 0xbe, 0x66, 0x70, 0x58, 0x8e, 0xeb, 0x45, 0x6a,
    0x5e, 0xc0, 0x83, 0x93, 0x57, 0x55, 0xfe, 0x07, 0xa0, 0x29, 0xa5, 0x98,
    0xba, 0x62, 0x4e, 0xae, 0x1e, 0xdb, 0xbb, 0xbf, 0xba, 0x61, 0x3b, 0x8e,
    0x0d, 0x59, 0xe4, 0xf2, 0xe2, 0xf6, 0xe4, 0xd7, 0xb9, 0x8f, 0xde, 0xc3,
    0xb5, 0x9b, 0xad, 0x8d, 0x95, 0x0a, 0x3b, 0xfb, 0x9c, 0xa8, 0x3c, 0x3f,
    0x2f, 0x7f, 0x4d, 0x7f, 0xe2, 0x50, 0xb5, 0xea, 0xcc, 0x97, 0x4a, 0x9a,
    0xee, 0x36, 0x13, 0xcf, 0x00, 0x90, 0x9a, 0x59, 0xac, 0x8e, 0x8e, 0x51,
    0x19, 0x59, 0x07, 0xf1, 0x02, 0xa6, 0x6d, 0xb3, 0x65, 0xd7, 0xc6, 0xf5,
    0x9b, 0xc6, 0x1a, 0xc7, 0x56, 0xf5, 0x0b, 0x74, 0xc3, 0x07, 0x5d, 0xa2,
    0x49, 0x06, 0x83, 0xc4, 0x39, 0x5b, 0x5d, 0xa9, 0x8f, 0x84, 0x9d, 0xa8,
    0x9c, 0x26, 0xea, 0xa8, 0x01, 0x10, 0xf8, 0xe9, 0xab, 0x4e, 0xed, 0xe3,
    0x9e, 0x4a, 0xb5, 0x04, 0x5d, 0x0f, 0x3d, 0xf7, 0x18, 0x18, 0x36, 0x51,
    0x72, 0x88, 0xa4, 0x15, 0xd1, 0xae, 0x59, 0x64, 0x59, 0x99, 0xdc, 0x2c,
    0x14, 0x36, 0x8f, 0xba, 0x07, 0x2d, 0x23, 0xe1, 0x53, 0x98, 0x13, 0xa7,
    0x6a, 0xb7, 0x01, 0xd0, 0x6c, 0xa8, 0x6f, 0x91, 0xef, 0x82, 0x6c, 0x92,
    0x27, 0x75, 0x7c, 0xb7, 0x4b, 0x4f, 0xae, 0xa5, 0xd5, 0x48, 0xc8, 0x72,
    0x9b, 0x34, 0x6e, 0xe3, 0xd7, 0xdf, 0x62, 0xe9, 0x1e, 0x56, 0xb1, 0x49,
    0x98, 0xc1, 0xd7, 0x1f, 0xa8, 0x66, 0xc0, 0x87, 0x45, 0x80, 0x27, 0x3f,
    0x87, 0xad, 0x06, 0x74, 0x17, 0x88, 0x1a, 0x2d, 0xfc, 0x78, 0x1f, 0x6d,
    0xaf, 0x8b, 0x3b, 0x37, 0x4d, 0x1a, 0xbc, 0x24, 0x17, 0x92, 0x92, 0x09,
    0x45, 0x07, 0x4a, 0x36, 0xf8, 0x29, 0xb4, 0x23, 0x5e, 0xa7, 0x19, 0xcf,
    0x0d, 0x80, 0x30, 0x65, 0x21, 0x0e, 0x02, 0x41, 0xb0, 0x60, 0x64, 0x51,
    0x3f, 0x4a, 0xf4, 0x98, 0x7d, 0x76, 0x89, 0x3c, 0x07, 0xbb, 0x0c, 0xa6,
    0x03, 0x96, 0x05, 0x65, 0x07, 0x4a, 0x26, 0x7c, 0x9f, 0x85, 0x4e, 0xcc,
    0xbd, 0xcb, 0x13, 0xaa, 0xa5, 0x03, 0x24, 0x82, 0x4e, 0x18, 0x74, 0xbc,
    0xb4, 0x59, 0xa7, 0x27, 0x0c, 0xdc, 0xb9, 0xfb, 0x14, 0x74, 0x18, 0x18,
    0x04, 0xcb, 0x06, 0xdb, 0x86, 0xbe, 0xca, 0x62, 0xba, 0x19, 0xfc, 0x6a,
    0x42, 0x96, 0xf3, 0x68, 0x69, 0x07, 0x51, 0xaa, 0xda, 0x61, 0x20, 0x7e,
    0x04, 0x5e, 0x34, 0x14, 0x67, 0x21, 0x22, 0x9e, 0xa1, 0xb2, 0x02, 0x1c,
    0x1b, 0xac, 0x12, 0x14, 0x0b, 0x20, 0x25, 0xb4, 0x03, 0x78, 0xff, 0x0d,
    0x82, 0x98, 0x77, 0x22, 0xe7, 0xe9, 0x12, 0x20, 0xe9, 0x11, 0xd6, 0x5b,
    0x5a, 0xa3, 0x13, 0x6b, 0x88, 0xac, 0x86, 0x96, 0x27, 0x0c, 0x55, 0x41,
    0x69, 0xe0, 0x87, 0x50, 0xf7, 0x16, 0x13, 0x74, 0x21, 0x49, 0xa9, 0x4b,
    0xc5, 0x89, 0x0b, 0x37, 0x94, 0xb7, 0x04, 0x10, 0x8a, 0x5e, 0x18, 0xa9,
    0xe6, 0xcf, 0x5a, 0x8f, 0x81, 0x3e, 0x8f, 0x38, 0x85, 0x7a, 0x00, 0xae,
    0x07, 0xed, 0x0e, 0xc4, 0x09, 0x6e, 0x2e, 0x99, 0x14, 0x92, 0x3b, 0x1a,
    0x3c, 0x39, 0x77, 0x5d, 0x7d, 0xf9, 0x6b, 0x89, 0x00, 0xa7, 0x8e, 0x6b,
    0x07, 0x2a, 0x36, 0xb7, 0xca, 0x36, 0xfd, 0x0d, 0x1f, 0x95, 0x09, 0xde,
    0x48, 0xc9, 0x5d, 0x91, 0x33, 0x95, 0xf6, 0x78, 0x61, 0x18, 0xb4, 0xce,
    0x5f, 0x57, 0xd1, 0x3f, 0x5d, 0x58, 0xec, 0x81, 0xc7, 0x9d, 0x98, 0xc3,
    0x9a, 0xce, 0x78, 0xa9, 0xc8, 0x8c, 0x10, 0x4c, 0xa5, 0x3d, 0xfc, 0x0b,
    0x37, 0x95, 0xf8, 0x9f, 0x4c, 0xda, 0x72, 0x75, 0xfe, 0x0d, 0xdd, 0x12,
    0x57, 0xe5, 0x1d, 0x25, 0x08, 0xc4, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45,
    0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image16_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xd4, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x5d, 0x88, 0x54,
    0x65, 0x18, 0xc7, 0x7f, 0xef, 0x7b, 0xce, 0x99, 0x33, 0x67, 0xcf, 0xce,
    0x34, 0x13, 0x4e, 0x7e, 0xec, 0x22, 0x6a, 0x19, 0xab, 0x8d, 0x1a, 0x28,
    0xb6, 0xd1, 0x4a, 0x6b, 0xb2, 0xac, 0x58, 0x68, 0x20, 0x45, 0xb0, 0xd0,
    0x45, 0x10, 0x44, 0x5d, 0x4b, 0x49, 0x66, 0xa2, 0xa9, 0x88, 0x57, 0xf6,
    0x21, 0x08, 0x45, 0x37, 0x41, 0x94, 0x57, 0xd2, 0xe6, 0x07, 0x46, 0xab,
    0x84, 0x37, 0x41, 0xab, 0x0b, 0x82, 0xcb, 0xb6, 0xcb, 0xee, 0x8e, 0xb4,
    0xa3, 0xed, 0xee, 0xcc, 0xce, 0x9c, 0x99, 0xf3, 0x39, 0xe7, 0xbc, 0x5d,
    0x04, 0x2b, 0x2e, 0xda, 0x4d, 0xcf, 0xe5, 0xc3, 0xff, 0xf9, 0xf1, 0xbf,
    0x78, 0x7e, 0x42, 0x29, 0xc5, 0xff, 0x19, 0xfd, 0x51, 0xcb, 0x77, 0x85,
    0x10, 0x97, 0xbb, 0x3f, 0xe8, 0x51, 0x9d, 0x1d, 0xbd, 0x19, 0xd3, 0x58,
    0x97, 0xf7, 0x9a, 0x13, 0x05, 0xbf, 0x31, 0x78, 0xe1, 0xe7, 0xd3, 0xb7,
    0x96, 0x66, 0xc5, 0xd2, 0x06, 0x5d, 0x7d, 0x07, 0x9e, 0x5f, 0xd7, 0xf3,
    0xc2, 0x91, 0x4d, 0x4f, 0x77, 0xee, 0x5b, 0xf9, 0x64, 0x86, 0xbf, 0x43,
    0x8d, 0x89, 0x52, 0x99, 0xf2, 0x9f, 0xe3, 0x9e, 0x31, 0x37, 0x7b, 0xc1,
    0x48, 0x92, 0x0f, 0x2f, 0xff, 0x70, 0xa8, 0xf4, 0x48, 0xc0, 0xd6, 0x81,
    0x93, 0x6f, 0xec, 0x7a, 0xad, 0xf7, 0xdb, 0x6d, 0xdb, 0x8b, 0xf6, 0xef,
    0x7e, 0x9a, 0x3b, 0xf7, 0xeb, 0x84, 0x4e, 0x93, 0x15, 0x86, 0x86, 0xee,
    0x36, 0x99, 0x1e, 0x1e, 0x46, 0x94, 0xa6, 0x47, 0xf5, 0x20, 0xe8, 0xbf,
    0x72, 0xfe, 0x70, 0xe9, 0x21, 0xc0, 0xe6, 0x57, 0x3f, 0xee, 0xda, 0xb1,
    0x7f, 0xf7, 0xf0, 0x8b, 0xbb, 0x7b, 0xac, 0x4f, 0xee, 0x78, 0x4c, 0xcd,
    0x39, 0xd8, 0x41, 0x03, 0xdd, 0x77, 0xb1, 0x9a, 0x35, 0xd6, 0xe8, 0x8a,
    0xe5, 0xba, 0x86, 0x33, 0x36, 0x8a, 0xf8, 0x6b, 0xe6, 0x2a, 0x29, 0x6d,
    0xef, 0x2f, 0xdf, 0x1d, 0xf4, 0x25, 0xc0, 0x1e, 0x21, 0xc4, 0xea, 0xcd,
    0x1b, 0x3e, 0x2d, 0x6e, 0xd9, 0x68, 0x1d, 0x18, 0xae, 0x30, 0x55, 0x69,
    0x92, 0xd1, 0x62, 0x74, 0x01, 0xfd, 0xf1, 0x3c, 0x1f, 0x15, 0xf3, 0x34,
    0xfc, 0x80, 0xb9, 0xf9, 0x39, 0xb4, 0x6c, 0x06, 0xac, 0x74, 0x5f, 0xd2,
    0xf0, 0xf6, 0x02, 0x48, 0x80, 0x9b, 0x5d, 0x6f, 0x15, 0xd7, 0x3f, 0xbb,
    0x76, 0xdf, 0xc5, 0x05, 0xa8, 0x54, 0xeb, 0xe4, 0x63, 0x0f, 0x23, 0x0a,
    0x71, 0x1d, 0x97, 0xe2, 0x33, 0x2b, 0x58, 0xb6, 0x2c, 0x07, 0x51, 0x84,
    0x68, 0x45, 0x28, 0x09, 0xd2, 0x6e, 0x03, 0xe4, 0x7b, 0x8b, 0x80, 0x42,
    0x71, 0x63, 0x7f, 0x20, 0x53, 0x56, 0x69, 0xbe, 0x4e, 0xae, 0xe5, 0x63,
    0x46, 0x01, 0x49, 0xa5, 0xc2, 0x80, 0xba, 0x87, 0x26, 0x25, 0x9f, 0x5d,
    0x9f, 0xc0, 0x52, 0x11, 0xba, 0x26, 0x21, 0x65, 0x82, 0x69, 0x92, 0x48,
    0xd1, 0xf3, 0x00, 0x90, 0xcd, 0x3c, 0xf7, 0xc7, 0x6c, 0x1d, 0xb7, 0x56,
    0xa3, 0x2d, 0xf2, 0x11, 0xcd, 0x06, 0x3b, 0xc3, 0xfb, 0x7c, 0xfd, 0x76,
    0x37, 0x85, 0x9c, 0x4d, 0xab, 0xee, 0x90, 0x6e, 0x45, 0x48, 0x4d, 0x03,
    0xcb, 0x02, 0x5d, 0x03, 0x30, 0x16, 0xff, 0x40, 0x8f, 0x63, 0x37, 0xf6,
    0x9a, 0x18, 0x6d, 0xed, 0xc8, 0x24, 0xc1, 0xac, 0x56, 0x39, 0xfc, 0xfa,
    0x06, 0x46, 0x7c, 0x8d, 0xcf, 0x2f, 0xde, 0xa4, 0x10, 0x07, 0xff, 0xde,
    0xd8, 0x36, 0x18, 0x3a, 0x49, 0x14, 0xa3, 0xa2, 0x78, 0x62, 0xb1, 0x81,
    0x70, 0x9c, 0xa1, 0xb4, 0xe7, 0x62, 0x19, 0x82, 0x94, 0x4a, 0xe8, 0x48,
    0x0b, 0x0a, 0x79, 0x9b, 0xd3, 0xdf, 0xff, 0xc6, 0xce, 0xac, 0x62, 0xc7,
    0xfa, 0xa7, 0xf0, 0xdb, 0x73, 0xc4, 0x4f, 0xe4, 0xa1, 0x15, 0x93, 0x2c,
    0xd4, 0x41, 0xa9, 0x1f, 0x1f, 0x00, 0xea, 0xd5, 0xeb, 0x46, 0xad, 0x36,
    0x66, 0x46, 0x21, 0x56, 0x2e, 0xcb, 0x82, 0x69, 0x73, 0xd7, 0x09, 0x39,
    0x37, 0xd0, 0xcd, 0x9e, 0xbe, 0x6d, 0x8c, 0x88, 0x0c, 0x72, 0xe5, 0x2a,
    0xa4, 0x26, 0x51, 0x33, 0x65, 0xe2, 0xba, 0x53, 0xd6, 0x48, 0xce, 0x2d,
    0x02, 0x2e, 0x5d, 0x3d, 0x33, 0x2b, 0xab, 0xd5, 0xaf, 0xcc, 0xa9, 0x49,
    0x52, 0x49, 0x82, 0x58, 0xd5, 0xc1, 0xd9, 0xbb, 0x09, 0xdf, 0x94, 0x13,
    0x4e, 0x8d, 0x07, 0x54, 0xcd, 0x76, 0x52, 0x49, 0x88, 0x18, 0x1f, 0xa7,
    0x35, 0x59, 0x42, 0x84, 0xad, 0x93, 0xbf, 0x0e, 0x1e, 0x9f, 0x7e, 0xc8,
    0x85, 0xf0, 0xf6, 0xd8, 0x97, 0xba, 0xa6, 0x6f, 0x31, 0xe2, 0x91, 0x77,
    0xf4, 0xb5, 0x6b, 0x18, 0x75, 0xf3, 0xdc, 0x2a, 0xd7, 0xc8, 0x11, 0x63,
    0x57, 0x2b, 0xa8, 0xc9, 0x29, 0xe2, 0x99, 0x7b, 0x88, 0x30, 0x38, 0x7b,
    0x6d, 0xf0, 0xe8, 0x17, 0x8f, 0x75, 0xa1, 0xf7, 0xcd, 0xe3, 0x07, 0x55,
    0x9b, 0xfd, 0xbe, 0xc8, 0x66, 0x3a, 0x49, 0xa5, 0x50, 0xae, 0x07, 0xb5,
    0x1a, 0x78, 0xde, 0x6d, 0x11, 0x45, 0x47, 0xaf, 0xfd, 0x74, 0xec, 0xfc,
    0x7f, 0xca, 0x04, 0xf0, 0xf2, 0xfe, 0x63, 0xab, 0x15, 0xbc, 0x22, 0x94,
    0x7a, 0x09, 0x85, 0x8b, 0x4a, 0x86, 0xa4, 0x17, 0xde, 0x18, 0xba, 0x72,
    0x62, 0x76, 0x69, 0xf6, 0x1f, 0xb1, 0x25, 0x44, 0x79, 0xb4, 0x3a, 0x21,
    0x74, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60,
    0x82
};


/*
 *  Constructs a compile10 as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
compile10::compile10( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    QImage img;
    img.loadFromData( image0_data, sizeof( image0_data ), "PNG" );
    image0 = img;
    img.loadFromData( image1_data, sizeof( image1_data ), "PNG" );
    image1 = img;
    img.loadFromData( image2_data, sizeof( image2_data ), "PNG" );
    image2 = img;
    img.loadFromData( image3_data, sizeof( image3_data ), "PNG" );
    image3 = img;
    img.loadFromData( image4_data, sizeof( image4_data ), "PNG" );
    image4 = img;
    img.loadFromData( image5_data, sizeof( image5_data ), "PNG" );
    image5 = img;
    img.loadFromData( image6_data, sizeof( image6_data ), "PNG" );
    image6 = img;
    img.loadFromData( image7_data, sizeof( image7_data ), "PNG" );
    image7 = img;
    img.loadFromData( image8_data, sizeof( image8_data ), "PNG" );
    image8 = img;
    img.loadFromData( image9_data, sizeof( image9_data ), "PNG" );
    image9 = img;
    img.loadFromData( image10_data, sizeof( image10_data ), "PNG" );
    image10 = img;
    img.loadFromData( image11_data, sizeof( image11_data ), "PNG" );
    image11 = img;
    img.loadFromData( image12_data, sizeof( image12_data ), "PNG" );
    image12 = img;
    img.loadFromData( image13_data, sizeof( image13_data ), "PNG" );
    image13 = img;
    img.loadFromData( image14_data, sizeof( image14_data ), "PNG" );
    image14 = img;
    img.loadFromData( image15_data, sizeof( image15_data ), "PNG" );
    image15 = img;
    img.loadFromData( image16_data, sizeof( image16_data ), "PNG" );
    image16 = img;
    if ( !name )
	setName( "compile10" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 0, 0 ) );
    setMaximumSize( QSize( 5100, 3000 ) );
    setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    setPalette( pal );
    QFont f( font() );
    setFont( f ); 
    setMouseTracking( FALSE );
    compile10Layout = new QHBoxLayout( this, 5, 6, "compile10Layout"); 

    layout49 = new QVBoxLayout( 0, 0, 6, "layout49"); 

    buttonGroup13 = new QButtonGroup( this, "buttonGroup13" );
    buttonGroup13->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, buttonGroup13->sizePolicy().hasHeightForWidth() ) );
    buttonGroup13->setMinimumSize( QSize( 0, 31 ) );
    buttonGroup13->setMaximumSize( QSize( 32767, 31 ) );
    buttonGroup13->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    buttonGroup13->setPalette( pal );
    buttonGroup13->setFrameShape( QButtonGroup::Box );
    buttonGroup13->setFrameShadow( QButtonGroup::Plain );
    buttonGroup13->setLineWidth( 1 );
    buttonGroup13->setMargin( 0 );
    buttonGroup13->setColumnLayout(0, Qt::Vertical );
    buttonGroup13->layout()->setSpacing( 3 );
    buttonGroup13->layout()->setMargin( 5 );
    buttonGroup13Layout = new QHBoxLayout( buttonGroup13->layout() );
    buttonGroup13Layout->setAlignment( Qt::AlignTop );

    radioButton1D = new QRadioButton( buttonGroup13, "radioButton1D" );
    radioButton1D->setMinimumSize( QSize( 0, 20 ) );
    radioButton1D->setMaximumSize( QSize( 32767, 20 ) );
    radioButton1D->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont radioButton1D_font(  radioButton1D->font() );
    radioButton1D_font.setBold( TRUE );
    radioButton1D->setFont( radioButton1D_font ); 
    radioButton1D->setChecked( TRUE );
    buttonGroup13Layout->addWidget( radioButton1D );

    radioButton2D = new QRadioButton( buttonGroup13, "radioButton2D" );
    radioButton2D->setMinimumSize( QSize( 0, 20 ) );
    radioButton2D->setMaximumSize( QSize( 32767, 20 ) );
    radioButton2D->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont radioButton2D_font(  radioButton2D->font() );
    radioButton2D_font.setBold( TRUE );
    radioButton2D->setFont( radioButton2D_font ); 
    buttonGroup13Layout->addWidget( radioButton2D );

    pushButtonNew = new QToolButton( buttonGroup13, "pushButtonNew" );
    pushButtonNew->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonNew->sizePolicy().hasHeightForWidth() ) );
    pushButtonNew->setMinimumSize( QSize( 0, 20 ) );
    pushButtonNew->setMaximumSize( QSize( 32767, 20 ) );
    pushButtonNew->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonNew->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonNew->setPalette( pal );
    QFont pushButtonNew_font(  pushButtonNew->font() );
    pushButtonNew_font.setBold( TRUE );
    pushButtonNew->setFont( pushButtonNew_font ); 
    pushButtonNew->setIconSet( QIconSet( image0 ) );
    pushButtonNew->setUsesBigPixmap( FALSE );
    pushButtonNew->setUsesTextLabel( TRUE );
    pushButtonNew->setTextPosition( QToolButton::BesideIcon );
    buttonGroup13Layout->addWidget( pushButtonNew );

    pushButtonSave = new QToolButton( buttonGroup13, "pushButtonSave" );
    pushButtonSave->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonSave->sizePolicy().hasHeightForWidth() ) );
    pushButtonSave->setMinimumSize( QSize( 0, 20 ) );
    pushButtonSave->setMaximumSize( QSize( 32767, 20 ) );
    pushButtonSave->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonSave->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonSave->setPalette( pal );
    QFont pushButtonSave_font(  pushButtonSave->font() );
    pushButtonSave_font.setBold( TRUE );
    pushButtonSave->setFont( pushButtonSave_font ); 
    pushButtonSave->setIconSet( QIconSet( image1 ) );
    pushButtonSave->setUsesBigPixmap( FALSE );
    pushButtonSave->setUsesTextLabel( TRUE );
    pushButtonSave->setTextPosition( QToolButton::BesideIcon );
    buttonGroup13Layout->addWidget( pushButtonSave );

    pushButtonDelete = new QToolButton( buttonGroup13, "pushButtonDelete" );
    pushButtonDelete->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonDelete->sizePolicy().hasHeightForWidth() ) );
    pushButtonDelete->setMinimumSize( QSize( 0, 20 ) );
    pushButtonDelete->setMaximumSize( QSize( 32767, 20 ) );
    pushButtonDelete->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonDelete->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonDelete->setPalette( pal );
    QFont pushButtonDelete_font(  pushButtonDelete->font() );
    pushButtonDelete_font.setBold( TRUE );
    pushButtonDelete->setFont( pushButtonDelete_font ); 
    pushButtonDelete->setIconSet( QIconSet( image2 ) );
    pushButtonDelete->setUsesBigPixmap( FALSE );
    pushButtonDelete->setUsesTextLabel( TRUE );
    pushButtonDelete->setTextPosition( QToolButton::BesideIcon );
    buttonGroup13Layout->addWidget( pushButtonDelete );

    pushButtonMakeDLL = new QToolButton( buttonGroup13, "pushButtonMakeDLL" );
    pushButtonMakeDLL->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonMakeDLL->sizePolicy().hasHeightForWidth() ) );
    pushButtonMakeDLL->setMinimumSize( QSize( 0, 5 ) );
    pushButtonMakeDLL->setMaximumSize( QSize( 32767, 20 ) );
    pushButtonMakeDLL->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonMakeDLL->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonMakeDLL->setPalette( pal );
    QFont pushButtonMakeDLL_font(  pushButtonMakeDLL->font() );
    pushButtonMakeDLL_font.setBold( TRUE );
    pushButtonMakeDLL->setFont( pushButtonMakeDLL_font ); 
    pushButtonMakeDLL->setIconSet( QIconSet( image3 ) );
    pushButtonMakeDLL->setUsesBigPixmap( FALSE );
    pushButtonMakeDLL->setUsesTextLabel( TRUE );
    pushButtonMakeDLL->setTextPosition( QToolButton::BesideIcon );
    buttonGroup13Layout->addWidget( pushButtonMakeDLL );
    layout49->addWidget( buttonGroup13 );

    splitterMain = new QSplitter( this, "splitterMain" );
    splitterMain->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)7, 0, 0, splitterMain->sizePolicy().hasHeightForWidth() ) );
    splitterMain->setMinimumSize( QSize( 527, 613 ) );
    splitterMain->setLineWidth( 0 );
    splitterMain->setMidLineWidth( 0 );
    splitterMain->setOrientation( QSplitter::Vertical );
    splitterMain->setHandleWidth( 6 );

    buttonGroupExplorer = new QButtonGroup( splitterMain, "buttonGroupExplorer" );
    buttonGroupExplorer->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, buttonGroupExplorer->sizePolicy().hasHeightForWidth() ) );
    buttonGroupExplorer->setMinimumSize( QSize( 0, 0 ) );
    buttonGroupExplorer->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    buttonGroupExplorer->setPalette( pal );
    buttonGroupExplorer->setFrameShape( QButtonGroup::NoFrame );
    buttonGroupExplorer->setFrameShadow( QButtonGroup::Sunken );
    buttonGroupExplorer->setLineWidth( 0 );
    buttonGroupExplorer->setColumnLayout(0, Qt::Vertical );
    buttonGroupExplorer->layout()->setSpacing( 3 );
    buttonGroupExplorer->layout()->setMargin( 0 );
    buttonGroupExplorerLayout = new QHBoxLayout( buttonGroupExplorer->layout() );
    buttonGroupExplorerLayout->setAlignment( Qt::AlignTop );

    splitter7 = new QSplitter( buttonGroupExplorer, "splitter7" );
    splitter7->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, splitter7->sizePolicy().hasHeightForWidth() ) );
    splitter7->setMinimumSize( QSize( 220, 119 ) );
    splitter7->setBackgroundOrigin( QSplitter::ParentOrigin );
    splitter7->setAcceptDrops( FALSE );
    splitter7->setFrameShape( QSplitter::NoFrame );
    splitter7->setLineWidth( 0 );
    splitter7->setMargin( 0 );
    splitter7->setMidLineWidth( 0 );
    splitter7->setOrientation( QSplitter::Horizontal );
    splitter7->setOpaqueResize( TRUE );
    splitter7->setHandleWidth( 6 );

    QWidget* privateLayoutWidget = new QWidget( splitter7, "layout37" );
    layout37 = new QVBoxLayout( privateLayoutWidget, 2, 4, "layout37"); 

    textLabelGroupName_2 = new QLabel( privateLayoutWidget, "textLabelGroupName_2" );
    textLabelGroupName_2->setEnabled( TRUE );
    textLabelGroupName_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelGroupName_2->sizePolicy().hasHeightForWidth() ) );
    textLabelGroupName_2->setBackgroundMode( QLabel::PaletteBackground );
    textLabelGroupName_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout37->addWidget( textLabelGroupName_2 );

    listBoxGroup = new QListBox( privateLayoutWidget, "listBoxGroup" );
    listBoxGroup->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    listBoxGroup->setPalette( pal );
    listBoxGroup->setBackgroundOrigin( QListBox::ParentOrigin );
    listBoxGroup->setLineWidth( 1 );
    layout37->addWidget( listBoxGroup );

    lineEditGroupName = new QLineEdit( privateLayoutWidget, "lineEditGroupName" );
    lineEditGroupName->setMinimumSize( QSize( 0, 20 ) );
    lineEditGroupName->setMaximumSize( QSize( 32767, 20 ) );
    lineEditGroupName->setFrameShape( QLineEdit::LineEditPanel );
    lineEditGroupName->setFrameShadow( QLineEdit::Sunken );
    lineEditGroupName->setCursorPosition( 0 );
    lineEditGroupName->setAlignment( int( QLineEdit::AlignAuto ) );
    layout37->addWidget( lineEditGroupName );

    QWidget* privateLayoutWidget_2 = new QWidget( splitter7, "layout38" );
    layout38 = new QVBoxLayout( privateLayoutWidget_2, 0, 4, "layout38"); 

    textLabelFunctionName_2 = new QLabel( privateLayoutWidget_2, "textLabelFunctionName_2" );
    textLabelFunctionName_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelFunctionName_2->sizePolicy().hasHeightForWidth() ) );
    textLabelFunctionName_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelFunctionName_2->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    textLabelFunctionName_2->setPalette( pal );
    layout38->addWidget( textLabelFunctionName_2 );

    listBoxFunctions = new QListBox( privateLayoutWidget_2, "listBoxFunctions" );
    listBoxFunctions->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    listBoxFunctions->setPalette( pal );
    listBoxFunctions->setLineWidth( 1 );
    layout38->addWidget( listBoxFunctions );

    lineEditFunctionName = new QLineEdit( privateLayoutWidget_2, "lineEditFunctionName" );
    lineEditFunctionName->setMinimumSize( QSize( 0, 20 ) );
    lineEditFunctionName->setMaximumSize( QSize( 32767, 20 ) );
    layout38->addWidget( lineEditFunctionName );
    buttonGroupExplorerLayout->addWidget( splitter7 );

    layout44 = new QVBoxLayout( 0, 2, 0, "layout44"); 

    pushButtonExplDown = new QToolButton( buttonGroupExplorer, "pushButtonExplDown" );
    pushButtonExplDown->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonExplDown->sizePolicy().hasHeightForWidth() ) );
    pushButtonExplDown->setMinimumSize( QSize( 14, 14 ) );
    pushButtonExplDown->setMaximumSize( QSize( 14, 14 ) );
    pushButtonExplDown->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    pushButtonExplDown->setPalette( pal );
    QFont pushButtonExplDown_font(  pushButtonExplDown->font() );
    pushButtonExplDown_font.setBold( TRUE );
    pushButtonExplDown->setFont( pushButtonExplDown_font ); 
    layout44->addWidget( pushButtonExplDown );

    pushButtonExplUp = new QToolButton( buttonGroupExplorer, "pushButtonExplUp" );
    pushButtonExplUp->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonExplUp->sizePolicy().hasHeightForWidth() ) );
    pushButtonExplUp->setMinimumSize( QSize( 14, 14 ) );
    pushButtonExplUp->setMaximumSize( QSize( 14, 14 ) );
    pushButtonExplUp->setPaletteForegroundColor( QColor( 255, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 255, 0, 0) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 255, 0, 0) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 255, 0, 0) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    pushButtonExplUp->setPalette( pal );
    QFont pushButtonExplUp_font(  pushButtonExplUp->font() );
    pushButtonExplUp_font.setBold( TRUE );
    pushButtonExplUp->setFont( pushButtonExplUp_font ); 
    layout44->addWidget( pushButtonExplUp );
    spacer23_2_2 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout44->addItem( spacer23_2_2 );
    buttonGroupExplorerLayout->addLayout( layout44 );

    buttonGroup5 = new QButtonGroup( splitterMain, "buttonGroup5" );
    buttonGroup5->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, buttonGroup5->sizePolicy().hasHeightForWidth() ) );
    buttonGroup5->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    buttonGroup5->setPalette( pal );
    buttonGroup5->setFrameShape( QButtonGroup::NoFrame );
    buttonGroup5->setLineWidth( 0 );
    buttonGroup5->setColumnLayout(0, Qt::Vertical );
    buttonGroup5->layout()->setSpacing( 3 );
    buttonGroup5->layout()->setMargin( 0 );
    buttonGroup5Layout = new QHBoxLayout( buttonGroup5->layout() );
    buttonGroup5Layout->setAlignment( Qt::AlignTop );

    layout100 = new QVBoxLayout( 0, 0, 6, "layout100"); 

    layout99 = new QVBoxLayout( 0, 0, 0, "layout99"); 
    spacer21_2_4_4 = new QSpacerItem( 5, 8, QSizePolicy::Minimum, QSizePolicy::Fixed );
    layout99->addItem( spacer21_2_4_4 );

    framePara_2 = new QFrame( buttonGroup5, "framePara_2" );
    framePara_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, framePara_2->sizePolicy().hasHeightForWidth() ) );
    framePara_2->setMaximumSize( QSize( 32767, 60 ) );
    framePara_2->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    framePara_2->setPalette( pal );
    framePara_2->setFrameShape( QFrame::StyledPanel );
    framePara_2->setFrameShadow( QFrame::Sunken );
    framePara_2->setLineWidth( 0 );
    framePara_2Layout = new QHBoxLayout( framePara_2, 0, 0, "framePara_2Layout"); 

    layout43 = new QVBoxLayout( 0, 0, 6, "layout43"); 

    textLabelNumberParameters_2_2 = new QLabel( framePara_2, "textLabelNumberParameters_2_2" );
    textLabelNumberParameters_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabelNumberParameters_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelNumberParameters_2_2->setMinimumSize( QSize( 130, 0 ) );
    textLabelNumberParameters_2_2->setMaximumSize( QSize( 130, 30 ) );
    textLabelNumberParameters_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout43->addWidget( textLabelNumberParameters_2_2 );

    textLabel1_3 = new QLabel( framePara_2, "textLabel1_3" );
    textLabel1_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout43->addWidget( textLabel1_3 );
    framePara_2Layout->addLayout( layout43 );

    layout45 = new QVBoxLayout( 0, 0, 6, "layout45"); 

    lineEditY = new QLineEdit( framePara_2, "lineEditY" );
    lineEditY->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditY->sizePolicy().hasHeightForWidth() ) );
    lineEditY->setMinimumSize( QSize( 0, 0 ) );
    lineEditY->setMaximumSize( QSize( 32767, 32767 ) );
    layout45->addWidget( lineEditY );

    layout44_2 = new QHBoxLayout( 0, 0, 0, "layout44_2"); 

    lineEditXXX = new QLineEdit( framePara_2, "lineEditXXX" );
    lineEditXXX->setMinimumSize( QSize( 50, 0 ) );
    lineEditXXX->setMaximumSize( QSize( 32767, 32767 ) );
    layout44_2->addWidget( lineEditXXX );

    spinBoxXnumber = new QSpinBox( framePara_2, "spinBoxXnumber" );
    spinBoxXnumber->setEnabled( FALSE );
    spinBoxXnumber->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)7, 0, 0, spinBoxXnumber->sizePolicy().hasHeightForWidth() ) );
    spinBoxXnumber->setButtonSymbols( QSpinBox::PlusMinus );
    spinBoxXnumber->setMaxValue( 10 );
    spinBoxXnumber->setMinValue( 1 );
    spinBoxXnumber->setValue( 1 );
    layout44_2->addWidget( spinBoxXnumber );
    layout45->addLayout( layout44_2 );
    framePara_2Layout->addLayout( layout45 );
    layout99->addWidget( framePara_2 );
    layout100->addLayout( layout99 );

    framePara = new QFrame( buttonGroup5, "framePara" );
    framePara->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, framePara->sizePolicy().hasHeightForWidth() ) );
    framePara->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    framePara->setPalette( pal );
    framePara->setFrameShape( QFrame::StyledPanel );
    framePara->setFrameShadow( QFrame::Sunken );
    framePara->setLineWidth( 0 );
    frameParaLayout = new QHBoxLayout( framePara, 0, 0, "frameParaLayout"); 

    spinBoxP = new QSlider( framePara, "spinBoxP" );
    spinBoxP->setMaxValue( 1000 );
    spinBoxP->setPageStep( 1 );
    spinBoxP->setOrientation( QSlider::Vertical );
    spinBoxP->setTickmarks( QSlider::NoMarks );
    spinBoxP->setTickInterval( 5 );
    frameParaLayout->addWidget( spinBoxP );

    tableParaNames = new QTable( framePara, "tableParaNames" );
    tableParaNames->setNumCols( tableParaNames->numCols() + 1 );
    tableParaNames->horizontalHeader()->setLabel( tableParaNames->numCols() - 1, tr( "Name" ) );
    tableParaNames->setNumCols( tableParaNames->numCols() + 1 );
    tableParaNames->horizontalHeader()->setLabel( tableParaNames->numCols() - 1, tr( "Initial Value[Ran..ge]" ) );
    tableParaNames->setNumCols( tableParaNames->numCols() + 1 );
    tableParaNames->horizontalHeader()->setLabel( tableParaNames->numCols() - 1, tr( "Vary?" ) );
    tableParaNames->setNumCols( tableParaNames->numCols() + 1 );
    tableParaNames->horizontalHeader()->setLabel( tableParaNames->numCols() - 1, tr( "Info" ) );
    tableParaNames->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    tableParaNames->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    tableParaNames->setPalette( pal );
    tableParaNames->setBackgroundOrigin( QTable::WidgetOrigin );
    QFont tableParaNames_font(  tableParaNames->font() );
    tableParaNames->setFont( tableParaNames_font ); 
    tableParaNames->setMouseTracking( FALSE );
    tableParaNames->setFrameShape( QTable::NoFrame );
    tableParaNames->setFrameShadow( QTable::Sunken );
    tableParaNames->setLineWidth( 2 );
    tableParaNames->setMidLineWidth( 0 );
    tableParaNames->setResizePolicy( QTable::Manual );
    tableParaNames->setVScrollBarMode( QTable::Auto );
    tableParaNames->setNumRows( 0 );
    tableParaNames->setNumCols( 4 );
    tableParaNames->setRowMovingEnabled( TRUE );
    tableParaNames->setColumnMovingEnabled( FALSE );
    tableParaNames->setFocusStyle( QTable::FollowStyle );
    frameParaLayout->addWidget( tableParaNames );
    layout100->addWidget( framePara );
    buttonGroup5Layout->addLayout( layout100 );

    layout47 = new QVBoxLayout( 0, 2, 0, "layout47"); 

    pushButtonParaDown = new QToolButton( buttonGroup5, "pushButtonParaDown" );
    pushButtonParaDown->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonParaDown->sizePolicy().hasHeightForWidth() ) );
    pushButtonParaDown->setMinimumSize( QSize( 14, 14 ) );
    pushButtonParaDown->setMaximumSize( QSize( 14, 14 ) );
    pushButtonParaDown->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    pushButtonParaDown->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonParaDown->setPalette( pal );
    QFont pushButtonParaDown_font(  pushButtonParaDown->font() );
    pushButtonParaDown_font.setBold( TRUE );
    pushButtonParaDown->setFont( pushButtonParaDown_font ); 
    layout47->addWidget( pushButtonParaDown );

    pushButtonParaUp = new QToolButton( buttonGroup5, "pushButtonParaUp" );
    pushButtonParaUp->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonParaUp->sizePolicy().hasHeightForWidth() ) );
    pushButtonParaUp->setMinimumSize( QSize( 14, 14 ) );
    pushButtonParaUp->setMaximumSize( QSize( 14, 14 ) );
    pushButtonParaUp->setPaletteForegroundColor( QColor( 255, 0, 0 ) );
    pushButtonParaUp->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 255, 0, 0) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 255, 0, 0) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 255, 0, 0) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonParaUp->setPalette( pal );
    QFont pushButtonParaUp_font(  pushButtonParaUp->font() );
    pushButtonParaUp_font.setBold( TRUE );
    pushButtonParaUp->setFont( pushButtonParaUp_font ); 
    layout47->addWidget( pushButtonParaUp );
    spacer23_2 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout47->addItem( spacer23_2 );
    buttonGroup5Layout->addLayout( layout47 );

    buttonGroup6 = new QButtonGroup( splitterMain, "buttonGroup6" );
    buttonGroup6->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)2, 0, 0, buttonGroup6->sizePolicy().hasHeightForWidth() ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    buttonGroup6->setPalette( pal );
    buttonGroup6->setFrameShape( QButtonGroup::NoFrame );
    buttonGroup6->setLineWidth( 0 );
    buttonGroup6->setColumnLayout(0, Qt::Vertical );
    buttonGroup6->layout()->setSpacing( 3 );
    buttonGroup6->layout()->setMargin( 0 );
    buttonGroup6Layout = new QHBoxLayout( buttonGroup6->layout() );
    buttonGroup6Layout->setAlignment( Qt::AlignTop );

    layout101 = new QVBoxLayout( 0, 0, 0, "layout101"); 

    tabWidgetCode = new QTabWidget( buttonGroup6, "tabWidgetCode" );
    tabWidgetCode->setMinimumSize( QSize( 0, 0 ) );
    tabWidgetCode->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    tabWidgetCode->setPalette( pal );
    tabWidgetCode->setTabPosition( QTabWidget::Top );
    tabWidgetCode->setTabShape( QTabWidget::Rounded );
    tabWidgetCode->setMargin( 0 );

    tab = new QWidget( tabWidgetCode, "tab" );
    tabLayout = new QVBoxLayout( tab, 0, 0, "tabLayout"); 

    layout38_2 = new QHBoxLayout( 0, 0, 0, "layout38_2"); 

    pushButtonMenu = new QToolButton( tab, "pushButtonMenu" );
    pushButtonMenu->setMinimumSize( QSize( 14, 14 ) );
    pushButtonMenu->setMaximumSize( QSize( 14, 14 ) );
    pushButtonMenu->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonMenu_font(  pushButtonMenu->font() );
    pushButtonMenu_font.setBold( TRUE );
    pushButtonMenu->setFont( pushButtonMenu_font ); 
    pushButtonMenu->setIconSet( QIconSet(  ) );
    layout38_2->addWidget( pushButtonMenu );

    frameMenu = new QButtonGroup( tab, "frameMenu" );
    frameMenu->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, frameMenu->sizePolicy().hasHeightForWidth() ) );
    frameMenu->setMinimumSize( QSize( 0, 15 ) );
    frameMenu->setMaximumSize( QSize( 32767, 15 ) );
    frameMenu->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont frameMenu_font(  frameMenu->font() );
    frameMenu_font.setBold( TRUE );
    frameMenu->setFont( frameMenu_font ); 
    frameMenu->setFrameShape( QButtonGroup::NoFrame );
    frameMenu->setFrameShadow( QButtonGroup::Plain );
    frameMenu->setLineWidth( 0 );
    frameMenu->setAlignment( int( QButtonGroup::AlignVCenter ) );
    frameMenu->setColumnLayout(0, Qt::Vertical );
    frameMenu->layout()->setSpacing( 2 );
    frameMenu->layout()->setMargin( 1 );
    frameMenuLayout = new QHBoxLayout( frameMenu->layout() );
    frameMenuLayout->setAlignment( Qt::AlignTop );

    pushButtonMenuSTD = new QToolButton( frameMenu, "pushButtonMenuSTD" );
    pushButtonMenuSTD->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonMenuSTD->sizePolicy().hasHeightForWidth() ) );
    pushButtonMenuSTD->setMinimumSize( QSize( 50, 14 ) );
    pushButtonMenuSTD->setMaximumSize( QSize( 50, 14 ) );
    pushButtonMenuSTD->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonMenuSTD_font(  pushButtonMenuSTD->font() );
    pushButtonMenuSTD_font.setBold( FALSE );
    pushButtonMenuSTD->setFont( pushButtonMenuSTD_font ); 
    pushButtonMenuSTD->setIconSet( QIconSet(  ) );
    frameMenuLayout->addWidget( pushButtonMenuSTD );

    pushButtonMenuFlags = new QToolButton( frameMenu, "pushButtonMenuFlags" );
    pushButtonMenuFlags->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonMenuFlags->sizePolicy().hasHeightForWidth() ) );
    pushButtonMenuFlags->setMinimumSize( QSize( 50, 14 ) );
    pushButtonMenuFlags->setMaximumSize( QSize( 50, 14 ) );
    pushButtonMenuFlags->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonMenuFlags_font(  pushButtonMenuFlags->font() );
    pushButtonMenuFlags_font.setBold( FALSE );
    pushButtonMenuFlags->setFont( pushButtonMenuFlags_font ); 
    pushButtonMenuFlags->setIconSet( QIconSet(  ) );
    frameMenuLayout->addWidget( pushButtonMenuFlags );

    pushButtonMenuData = new QToolButton( frameMenu, "pushButtonMenuData" );
    pushButtonMenuData->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonMenuData->sizePolicy().hasHeightForWidth() ) );
    pushButtonMenuData->setMinimumSize( QSize( 50, 14 ) );
    pushButtonMenuData->setMaximumSize( QSize( 50, 14 ) );
    pushButtonMenuData->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonMenuData_font(  pushButtonMenuData->font() );
    pushButtonMenuData_font.setBold( FALSE );
    pushButtonMenuData->setFont( pushButtonMenuData_font ); 
    pushButtonMenuData->setIconSet( QIconSet(  ) );
    frameMenuLayout->addWidget( pushButtonMenuData );

    pushButtonMenuSANS = new QToolButton( frameMenu, "pushButtonMenuSANS" );
    pushButtonMenuSANS->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonMenuSANS->sizePolicy().hasHeightForWidth() ) );
    pushButtonMenuSANS->setMinimumSize( QSize( 50, 14 ) );
    pushButtonMenuSANS->setMaximumSize( QSize( 50, 14 ) );
    pushButtonMenuSANS->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonMenuSANS_font(  pushButtonMenuSANS->font() );
    pushButtonMenuSANS_font.setBold( FALSE );
    pushButtonMenuSANS->setFont( pushButtonMenuSANS_font ); 
    pushButtonMenuSANS->setIconSet( QIconSet(  ) );
    frameMenuLayout->addWidget( pushButtonMenuSANS );

    pushButtonMenuMath = new QToolButton( frameMenu, "pushButtonMenuMath" );
    pushButtonMenuMath->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonMenuMath->sizePolicy().hasHeightForWidth() ) );
    pushButtonMenuMath->setMinimumSize( QSize( 50, 14 ) );
    pushButtonMenuMath->setMaximumSize( QSize( 50, 14 ) );
    pushButtonMenuMath->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonMenuMath_font(  pushButtonMenuMath->font() );
    pushButtonMenuMath_font.setBold( FALSE );
    pushButtonMenuMath->setFont( pushButtonMenuMath_font ); 
    pushButtonMenuMath->setIconSet( QIconSet(  ) );
    frameMenuLayout->addWidget( pushButtonMenuMath );

    pushButtonMenuMULTI = new QToolButton( frameMenu, "pushButtonMenuMULTI" );
    pushButtonMenuMULTI->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonMenuMULTI->sizePolicy().hasHeightForWidth() ) );
    pushButtonMenuMULTI->setMinimumSize( QSize( 100, 14 ) );
    pushButtonMenuMULTI->setMaximumSize( QSize( 150, 14 ) );
    pushButtonMenuMULTI->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonMenuMULTI_font(  pushButtonMenuMULTI->font() );
    pushButtonMenuMULTI_font.setBold( FALSE );
    pushButtonMenuMULTI->setFont( pushButtonMenuMULTI_font ); 
    pushButtonMenuMULTI->setIconSet( QIconSet(  ) );
    frameMenuLayout->addWidget( pushButtonMenuMULTI );
    layout38_2->addWidget( frameMenu );
    spacer29 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout38_2->addItem( spacer29 );
    tabLayout->addLayout( layout38_2 );

    textEditCode = new QTextEdit( tab, "textEditCode" );
    textEditCode->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, textEditCode->sizePolicy().hasHeightForWidth() ) );
    textEditCode->setMaximumSize( QSize( 32767, 32766 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    textEditCode->setPalette( pal );
    textEditCode->setFrameShape( QTextEdit::NoFrame );
    textEditCode->setFrameShadow( QTextEdit::Plain );
    textEditCode->setLineWidth( 2 );
    textEditCode->setMargin( 0 );
    textEditCode->setTextFormat( QTextEdit::PlainText );
    textEditCode->setWordWrap( QTextEdit::WidgetWidth );
    tabLayout->addWidget( textEditCode );
    tabWidgetCode->insertTab( tab, QString::fromLatin1("") );

    tab_2 = new QWidget( tabWidgetCode, "tab_2" );
    tabLayout_2 = new QVBoxLayout( tab_2, 0, 0, "tabLayout_2"); 
    spacer21_2_2 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Fixed );
    tabLayout_2->addItem( spacer21_2_2 );

    splitterInc = new QSplitter( tab_2, "splitterInc" );
    splitterInc->setOrientation( QSplitter::Vertical );

    splitter6 = new QSplitter( splitterInc, "splitter6" );
    splitter6->setOrientation( QSplitter::Horizontal );

    QWidget* privateLayoutWidget_3 = new QWidget( splitter6, "layout51" );
    layout51 = new QVBoxLayout( privateLayoutWidget_3, 0, 0, "layout51"); 

    textLabel2_2_2 = new QLabel( privateLayoutWidget_3, "textLabel2_2_2" );
    textLabel2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabel2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2_2->setMinimumSize( QSize( 0, 20 ) );
    textLabel2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout51->addWidget( textLabel2_2_2 );

    textEditHFiles = new QTextEdit( privateLayoutWidget_3, "textEditHFiles" );
    textEditHFiles->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, textEditHFiles->sizePolicy().hasHeightForWidth() ) );
    textEditHFiles->setMinimumSize( QSize( 0, 75 ) );
    textEditHFiles->setMaximumSize( QSize( 32767, 750 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    textEditHFiles->setPalette( pal );
    textEditHFiles->setFrameShape( QTextEdit::NoFrame );
    textEditHFiles->setTextFormat( QTextEdit::PlainText );
    layout51->addWidget( textEditHFiles );

    QWidget* privateLayoutWidget_4 = new QWidget( splitter6, "layout37" );
    layout37_2 = new QVBoxLayout( privateLayoutWidget_4, 0, 0, "layout37_2"); 

    layout36 = new QHBoxLayout( 0, 2, 2, "layout36"); 

    textLabel2_2_2_2 = new QLabel( privateLayoutWidget_4, "textLabel2_2_2_2" );
    textLabel2_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabel2_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout36->addWidget( textLabel2_2_2_2 );

    pushButtonAddHeader = new QToolButton( privateLayoutWidget_4, "pushButtonAddHeader" );
    pushButtonAddHeader->setMinimumSize( QSize( 16, 16 ) );
    pushButtonAddHeader->setMaximumSize( QSize( 16, 16 ) );
    pushButtonAddHeader->setIconSet( QIconSet( image4 ) );
    layout36->addWidget( pushButtonAddHeader );

    pushButtonOpenInNote = new QToolButton( privateLayoutWidget_4, "pushButtonOpenInNote" );
    pushButtonOpenInNote->setMinimumSize( QSize( 16, 16 ) );
    pushButtonOpenInNote->setMaximumSize( QSize( 16, 16 ) );
    pushButtonOpenInNote->setIconSet( QIconSet( image5 ) );
    layout36->addWidget( pushButtonOpenInNote );

    pushButtonMakeIncluded = new QToolButton( privateLayoutWidget_4, "pushButtonMakeIncluded" );
    pushButtonMakeIncluded->setMinimumSize( QSize( 16, 16 ) );
    pushButtonMakeIncluded->setMaximumSize( QSize( 16, 16 ) );
    pushButtonMakeIncluded->setIconSet( QIconSet( image6 ) );
    layout36->addWidget( pushButtonMakeIncluded );

    pushButtonIncludedDelete = new QToolButton( privateLayoutWidget_4, "pushButtonIncludedDelete" );
    pushButtonIncludedDelete->setMinimumSize( QSize( 16, 16 ) );
    pushButtonIncludedDelete->setMaximumSize( QSize( 16, 16 ) );
    pushButtonIncludedDelete->setIconSet( QIconSet( image7 ) );
    layout36->addWidget( pushButtonIncludedDelete );
    layout37_2->addLayout( layout36 );

    listBoxIncludeFunctions = new QListBox( privateLayoutWidget_4, "listBoxIncludeFunctions" );
    listBoxIncludeFunctions->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, listBoxIncludeFunctions->sizePolicy().hasHeightForWidth() ) );
    listBoxIncludeFunctions->setMinimumSize( QSize( 0, 75 ) );
    listBoxIncludeFunctions->setMaximumSize( QSize( 32767, 750 ) );
    listBoxIncludeFunctions->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    listBoxIncludeFunctions->setPalette( pal );
    listBoxIncludeFunctions->setMouseTracking( FALSE );
    listBoxIncludeFunctions->setFrameShape( QListBox::NoFrame );
    layout37_2->addWidget( listBoxIncludeFunctions );

    QWidget* privateLayoutWidget_5 = new QWidget( splitterInc, "layout55" );
    layout55 = new QVBoxLayout( privateLayoutWidget_5, 0, 0, "layout55"); 

    textLabel2_2_3_2 = new QLabel( privateLayoutWidget_5, "textLabel2_2_3_2" );
    textLabel2_2_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabel2_2_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout55->addWidget( textLabel2_2_3_2 );

    textEditFunctions = new QTextEdit( privateLayoutWidget_5, "textEditFunctions" );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    textEditFunctions->setPalette( pal );
    textEditFunctions->setFrameShape( QTextEdit::NoFrame );
    textEditFunctions->setTextFormat( QTextEdit::PlainText );
    textEditFunctions->setWordWrap( QTextEdit::WidgetWidth );
    textEditFunctions->setAutoFormatting( int( QTextEdit::AutoAll ) );
    layout55->addWidget( textEditFunctions );
    tabLayout_2->addWidget( splitterInc );
    tabWidgetCode->insertTab( tab_2, QString::fromLatin1("") );

    TabPage = new QWidget( tabWidgetCode, "TabPage" );
    TabPageLayout = new QVBoxLayout( TabPage, 0, 0, "TabPageLayout"); 
    spacer21_2_3 = new QSpacerItem( 5, 10, QSizePolicy::Minimum, QSizePolicy::Fixed );
    TabPageLayout->addItem( spacer21_2_3 );

    layout69 = new QHBoxLayout( 0, 0, 0, "layout69"); 

    textEditDescription = new QTextEdit( TabPage, "textEditDescription" );
    textEditDescription->setFrameShape( QTextEdit::NoFrame );
    textEditDescription->setLineWidth( 0 );
    textEditDescription->setTextFormat( QTextEdit::RichText );
    textEditDescription->setWordWrap( QTextEdit::WidgetWidth );
    textEditDescription->setAutoFormatting( int( QTextEdit::AutoAll ) );
    layout69->addWidget( textEditDescription );

    layout68 = new QVBoxLayout( 0, 0, 0, "layout68"); 

    layout9 = new QVBoxLayout( 0, 0, 2, "layout9"); 

    pushButtonEXP = new QPushButton( TabPage, "pushButtonEXP" );
    pushButtonEXP->setMinimumSize( QSize( 15, 0 ) );
    pushButtonEXP->setMaximumSize( QSize( 25, 25 ) );
    pushButtonEXP->setToggleButton( TRUE );
    layout9->addWidget( pushButtonEXP );

    pushButtonSub = new QPushButton( TabPage, "pushButtonSub" );
    pushButtonSub->setMinimumSize( QSize( 15, 0 ) );
    pushButtonSub->setMaximumSize( QSize( 25, 25 ) );
    pushButtonSub->setToggleButton( TRUE );
    layout9->addWidget( pushButtonSub );

    pushButtonGreek = new QPushButton( TabPage, "pushButtonGreek" );
    pushButtonGreek->setEnabled( TRUE );
    pushButtonGreek->setMinimumSize( QSize( 15, 0 ) );
    pushButtonGreek->setMaximumSize( QSize( 25, 25 ) );
    pushButtonGreek->setToggleButton( TRUE );
    layout9->addWidget( pushButtonGreek );
    layout68->addLayout( layout9 );
    spacer21 = new QSpacerItem( 0, 31, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout68->addItem( spacer21 );
    layout69->addLayout( layout68 );
    TabPageLayout->addLayout( layout69 );

    layout102 = new QHBoxLayout( 0, 5, 2, "layout102"); 

    pushButtonBold = new QToolButton( TabPage, "pushButtonBold" );
    pushButtonBold->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonBold->sizePolicy().hasHeightForWidth() ) );
    pushButtonBold->setMaximumSize( QSize( 25, 25 ) );
    pushButtonBold->setIconSet( QIconSet( image8 ) );
    layout102->addWidget( pushButtonBold );

    pushButtonItal = new QToolButton( TabPage, "pushButtonItal" );
    pushButtonItal->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonItal->sizePolicy().hasHeightForWidth() ) );
    pushButtonItal->setMaximumSize( QSize( 25, 25 ) );
    pushButtonItal->setIconSet( QIconSet( image9 ) );
    layout102->addWidget( pushButtonItal );

    pushButtonUnder = new QToolButton( TabPage, "pushButtonUnder" );
    pushButtonUnder->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonUnder->sizePolicy().hasHeightForWidth() ) );
    pushButtonUnder->setMaximumSize( QSize( 25, 25 ) );
    pushButtonUnder->setIconSet( QIconSet( image10 ) );
    layout102->addWidget( pushButtonUnder );

    comboBoxFont = new QComboBox( FALSE, TabPage, "comboBoxFont" );
    comboBoxFont->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxFont->sizePolicy().hasHeightForWidth() ) );
    comboBoxFont->setMinimumSize( QSize( 0, 25 ) );
    comboBoxFont->setMaximumSize( QSize( 20000, 25 ) );
    layout102->addWidget( comboBoxFont );

    comboBoxFontSize = new QComboBox( FALSE, TabPage, "comboBoxFontSize" );
    comboBoxFontSize->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxFontSize->sizePolicy().hasHeightForWidth() ) );
    comboBoxFontSize->setMinimumSize( QSize( 70, 25 ) );
    comboBoxFontSize->setMaximumSize( QSize( 70, 25 ) );
    comboBoxFontSize->setEditable( FALSE );
    layout102->addWidget( comboBoxFontSize );

    pushButtonLeft = new QToolButton( TabPage, "pushButtonLeft" );
    pushButtonLeft->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonLeft->sizePolicy().hasHeightForWidth() ) );
    pushButtonLeft->setMaximumSize( QSize( 25, 25 ) );
    pushButtonLeft->setIconSet( QIconSet( image11 ) );
    layout102->addWidget( pushButtonLeft );

    pushButtonCenter = new QToolButton( TabPage, "pushButtonCenter" );
    pushButtonCenter->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonCenter->sizePolicy().hasHeightForWidth() ) );
    pushButtonCenter->setMaximumSize( QSize( 25, 25 ) );
    pushButtonCenter->setIconSet( QIconSet( image12 ) );
    layout102->addWidget( pushButtonCenter );

    pushButtonRight = new QToolButton( TabPage, "pushButtonRight" );
    pushButtonRight->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonRight->sizePolicy().hasHeightForWidth() ) );
    pushButtonRight->setMaximumSize( QSize( 25, 25 ) );
    pushButtonRight->setIconSet( QIconSet( image13 ) );
    layout102->addWidget( pushButtonRight );

    pushButtonJust = new QToolButton( TabPage, "pushButtonJust" );
    pushButtonJust->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonJust->sizePolicy().hasHeightForWidth() ) );
    pushButtonJust->setMaximumSize( QSize( 25, 25 ) );
    pushButtonJust->setIconSet( QIconSet( image14 ) );
    layout102->addWidget( pushButtonJust );
    TabPageLayout->addLayout( layout102 );
    tabWidgetCode->insertTab( TabPage, QString::fromLatin1("") );

    TabPage_2 = new QWidget( tabWidgetCode, "TabPage_2" );
    TabPageLayout_2 = new QVBoxLayout( TabPage_2, 11, 6, "TabPageLayout_2"); 
    spacer21_2_4 = new QSpacerItem( 5, 4, QSizePolicy::Minimum, QSizePolicy::Fixed );
    TabPageLayout_2->addItem( spacer21_2_4 );

    layout39 = new QHBoxLayout( 0, 0, 3, "layout39"); 

    groupBoxMinGw = new QGroupBox( TabPage_2, "groupBoxMinGw" );
    groupBoxMinGw->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, groupBoxMinGw->sizePolicy().hasHeightForWidth() ) );
    groupBoxMinGw->setColumnLayout(0, Qt::Vertical );
    groupBoxMinGw->layout()->setSpacing( 6 );
    groupBoxMinGw->layout()->setMargin( 7 );
    groupBoxMinGwLayout = new QVBoxLayout( groupBoxMinGw->layout() );
    groupBoxMinGwLayout->setAlignment( Qt::AlignTop );

    layout106 = new QVBoxLayout( 0, 0, 0, "layout106"); 

    textLabel2_2 = new QLabel( groupBoxMinGw, "textLabel2_2" );
    textLabel2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabel2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout106->addWidget( textLabel2_2 );

    layout97 = new QHBoxLayout( 0, 2, 2, "layout97"); 

    fitPath = new QLineEdit( groupBoxMinGw, "fitPath" );
    fitPath->setEnabled( TRUE );
    fitPath->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, fitPath->sizePolicy().hasHeightForWidth() ) );
    fitPath->setMinimumSize( QSize( 0, 20 ) );
    fitPath->setMaximumSize( QSize( 32767, 20 ) );
    fitPath->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    fitPath->setLineWidth( 1 );
    fitPath->setReadOnly( FALSE );
    layout97->addWidget( fitPath );

    pushButtonPath = new QToolButton( groupBoxMinGw, "pushButtonPath" );
    pushButtonPath->setMaximumSize( QSize( 20, 20 ) );
    pushButtonPath->setIconSet( QIconSet( image15 ) );
    layout97->addWidget( pushButtonPath );
    layout106->addLayout( layout97 );
    groupBoxMinGwLayout->addLayout( layout106 );

    layout37_3 = new QVBoxLayout( 0, 0, 0, "layout37_3"); 

    layout36_2 = new QHBoxLayout( 0, 0, 0, "layout36_2"); 

    checkBoxGSLlocal = new QCheckBox( groupBoxMinGw, "checkBoxGSLlocal" );
    checkBoxGSLlocal->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, checkBoxGSLlocal->sizePolicy().hasHeightForWidth() ) );
    checkBoxGSLlocal->setMinimumSize( QSize( 95, 0 ) );
    checkBoxGSLlocal->setMaximumSize( QSize( 1000, 32767 ) );
    checkBoxGSLlocal->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout36_2->addWidget( checkBoxGSLlocal );

    checkBoxGSLstatic = new QCheckBox( groupBoxMinGw, "checkBoxGSLstatic" );
    checkBoxGSLstatic->setEnabled( TRUE );
    checkBoxGSLstatic->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, checkBoxGSLstatic->sizePolicy().hasHeightForWidth() ) );
    checkBoxGSLstatic->setMinimumSize( QSize( 65, 0 ) );
    checkBoxGSLstatic->setMaximumSize( QSize( 65, 32767 ) );
    checkBoxGSLstatic->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout36_2->addWidget( checkBoxGSLstatic );

    textLabelGSL = new QLabel( groupBoxMinGw, "textLabelGSL" );
    textLabelGSL->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabelGSL->sizePolicy().hasHeightForWidth() ) );
    textLabelGSL->setMinimumSize( QSize( 115, 0 ) );
    textLabelGSL->setMaximumSize( QSize( 115, 32767 ) );
    textLabelGSL->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout36_2->addWidget( textLabelGSL );
    layout37_3->addLayout( layout36_2 );

    layout98 = new QHBoxLayout( 0, 2, 2, "layout98"); 

    gslPathline = new QLineEdit( groupBoxMinGw, "gslPathline" );
    gslPathline->setEnabled( TRUE );
    gslPathline->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, gslPathline->sizePolicy().hasHeightForWidth() ) );
    gslPathline->setMinimumSize( QSize( 0, 20 ) );
    gslPathline->setMaximumSize( QSize( 32767, 20 ) );
    gslPathline->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    gslPathline->setLineWidth( 1 );
    gslPathline->setReadOnly( FALSE );
    layout98->addWidget( gslPathline );

    pushButtonPathGSL = new QToolButton( groupBoxMinGw, "pushButtonPathGSL" );
    pushButtonPathGSL->setMaximumSize( QSize( 20, 20 ) );
    pushButtonPathGSL->setIconSet( QIconSet( image15 ) );
    layout98->addWidget( pushButtonPathGSL );
    layout37_3->addLayout( layout98 );
    groupBoxMinGwLayout->addLayout( layout37_3 );

    layout42 = new QVBoxLayout( 0, 0, 0, "layout42"); 

    layout40 = new QHBoxLayout( 0, 0, 0, "layout40"); 

    checkBoxCompilerLocal = new QCheckBox( groupBoxMinGw, "checkBoxCompilerLocal" );
    checkBoxCompilerLocal->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, checkBoxCompilerLocal->sizePolicy().hasHeightForWidth() ) );
    checkBoxCompilerLocal->setMinimumSize( QSize( 70, 0 ) );
    checkBoxCompilerLocal->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout40->addWidget( checkBoxCompilerLocal );

    textLabelMingw = new QLabel( groupBoxMinGw, "textLabelMingw" );
    textLabelMingw->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelMingw->sizePolicy().hasHeightForWidth() ) );
    textLabelMingw->setMinimumSize( QSize( 70, 0 ) );
    textLabelMingw->setMaximumSize( QSize( 70, 32767 ) );
    textLabelMingw->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout40->addWidget( textLabelMingw );
    layout42->addLayout( layout40 );

    layout99_2 = new QHBoxLayout( 0, 2, 2, "layout99_2"); 

    mingwPathline = new QLineEdit( groupBoxMinGw, "mingwPathline" );
    mingwPathline->setEnabled( TRUE );
    mingwPathline->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, mingwPathline->sizePolicy().hasHeightForWidth() ) );
    mingwPathline->setMinimumSize( QSize( 0, 20 ) );
    mingwPathline->setMaximumSize( QSize( 32767, 20 ) );
    mingwPathline->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    mingwPathline->setLineWidth( 1 );
    mingwPathline->setReadOnly( FALSE );
    layout99_2->addWidget( mingwPathline );

    pushButtonPathMingw = new QToolButton( groupBoxMinGw, "pushButtonPathMingw" );
    pushButtonPathMingw->setMaximumSize( QSize( 20, 20 ) );
    pushButtonPathMingw->setIconSet( QIconSet( image15 ) );
    layout99_2->addWidget( pushButtonPathMingw );
    layout42->addLayout( layout99_2 );
    groupBoxMinGwLayout->addLayout( layout42 );
    layout39->addWidget( groupBoxMinGw );

    buttonGroup12 = new QButtonGroup( TabPage_2, "buttonGroup12" );
    buttonGroup12->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)7, 0, 0, buttonGroup12->sizePolicy().hasHeightForWidth() ) );
    buttonGroup12->setMinimumSize( QSize( 135, 0 ) );
    buttonGroup12->setMaximumSize( QSize( 120, 32767 ) );
    buttonGroup12->setAlignment( int( QButtonGroup::AlignTop ) );
    buttonGroup12->setColumnLayout(0, Qt::Vertical );
    buttonGroup12->layout()->setSpacing( 4 );
    buttonGroup12->layout()->setMargin( 4 );
    buttonGroup12Layout = new QVBoxLayout( buttonGroup12->layout() );
    buttonGroup12Layout->setAlignment( Qt::AlignTop );

    pushButtonOpenFIF = new QToolButton( buttonGroup12, "pushButtonOpenFIF" );
    pushButtonOpenFIF->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonOpenFIF->sizePolicy().hasHeightForWidth() ) );
    pushButtonOpenFIF->setMinimumSize( QSize( 0, 20 ) );
    pushButtonOpenFIF->setMaximumSize( QSize( 32767, 20 ) );
    pushButtonOpenFIF->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonOpenFIF->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonOpenFIF->setPalette( pal );
    QFont pushButtonOpenFIF_font(  pushButtonOpenFIF->font() );
    pushButtonOpenFIF_font.setBold( TRUE );
    pushButtonOpenFIF->setFont( pushButtonOpenFIF_font ); 
    pushButtonOpenFIF->setUsesBigPixmap( FALSE );
    pushButtonOpenFIF->setUsesTextLabel( TRUE );
    pushButtonOpenFIF->setTextPosition( QToolButton::BesideIcon );
    buttonGroup12Layout->addWidget( pushButtonOpenFIF );

    pushButtonSaveAs = new QToolButton( buttonGroup12, "pushButtonSaveAs" );
    pushButtonSaveAs->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonSaveAs->sizePolicy().hasHeightForWidth() ) );
    pushButtonSaveAs->setMinimumSize( QSize( 0, 20 ) );
    pushButtonSaveAs->setMaximumSize( QSize( 32767, 20 ) );
    pushButtonSaveAs->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonSaveAs->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonSaveAs->setPalette( pal );
    QFont pushButtonSaveAs_font(  pushButtonSaveAs->font() );
    pushButtonSaveAs_font.setBold( TRUE );
    pushButtonSaveAs->setFont( pushButtonSaveAs_font ); 
    pushButtonSaveAs->setUsesBigPixmap( FALSE );
    pushButtonSaveAs->setUsesTextLabel( TRUE );
    pushButtonSaveAs->setTextPosition( QToolButton::BesideIcon );
    buttonGroup12Layout->addWidget( pushButtonSaveAs );

    pushButtonCompileAll = new QToolButton( buttonGroup12, "pushButtonCompileAll" );
    pushButtonCompileAll->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonCompileAll->sizePolicy().hasHeightForWidth() ) );
    pushButtonCompileAll->setMinimumSize( QSize( 0, 20 ) );
    pushButtonCompileAll->setMaximumSize( QSize( 32767, 20 ) );
    pushButtonCompileAll->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonCompileAll->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonCompileAll->setPalette( pal );
    QFont pushButtonCompileAll_font(  pushButtonCompileAll->font() );
    pushButtonCompileAll_font.setBold( TRUE );
    pushButtonCompileAll->setFont( pushButtonCompileAll_font ); 
    pushButtonCompileAll->setUsesBigPixmap( FALSE );
    pushButtonCompileAll->setUsesTextLabel( TRUE );
    pushButtonCompileAll->setTextPosition( QToolButton::BesideIcon );
    buttonGroup12Layout->addWidget( pushButtonCompileAll );

    pushButtonDefaultOptions = new QToolButton( buttonGroup12, "pushButtonDefaultOptions" );
    pushButtonDefaultOptions->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonDefaultOptions->sizePolicy().hasHeightForWidth() ) );
    pushButtonDefaultOptions->setMinimumSize( QSize( 0, 20 ) );
    pushButtonDefaultOptions->setMaximumSize( QSize( 32767, 20 ) );
    pushButtonDefaultOptions->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonDefaultOptions->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonDefaultOptions->setPalette( pal );
    QFont pushButtonDefaultOptions_font(  pushButtonDefaultOptions->font() );
    pushButtonDefaultOptions_font.setBold( TRUE );
    pushButtonDefaultOptions->setFont( pushButtonDefaultOptions_font ); 
    pushButtonDefaultOptions->setUsesBigPixmap( FALSE );
    pushButtonDefaultOptions->setUsesTextLabel( TRUE );
    pushButtonDefaultOptions->setTextPosition( QToolButton::BesideIcon );
    buttonGroup12Layout->addWidget( pushButtonDefaultOptions );
    layout39->addWidget( buttonGroup12 );
    TabPageLayout_2->addLayout( layout39 );

    splitter3 = new QSplitter( TabPage_2, "splitter3" );
    splitter3->setOrientation( QSplitter::Horizontal );

    QWidget* privateLayoutWidget_6 = new QWidget( splitter3, "layout32" );
    layout32 = new QVBoxLayout( privateLayoutWidget_6, 0, 0, "layout32"); 

    textLabel1 = new QLabel( privateLayoutWidget_6, "textLabel1" );
    textLabel1->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabel1->setAlignment( int( QLabel::AlignBottom ) );
    layout32->addWidget( textLabel1 );

    lineEditCompileFlags = new QLineEdit( privateLayoutWidget_6, "lineEditCompileFlags" );
    layout32->addWidget( lineEditCompileFlags );

    QWidget* privateLayoutWidget_7 = new QWidget( splitter3, "layout33" );
    layout33 = new QVBoxLayout( privateLayoutWidget_7, 0, 0, "layout33"); 

    textLabel1_2 = new QLabel( privateLayoutWidget_7, "textLabel1_2" );
    textLabel1_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabel1_2->setAlignment( int( QLabel::AlignBottom ) );
    layout33->addWidget( textLabel1_2 );

    lineEditLinkFlags = new QLineEdit( privateLayoutWidget_7, "lineEditLinkFlags" );
    layout33->addWidget( lineEditLinkFlags );
    TabPageLayout_2->addWidget( splitter3 );
    spacer20 = new QSpacerItem( 16, 16, QSizePolicy::Minimum, QSizePolicy::Expanding );
    TabPageLayout_2->addItem( spacer20 );
    tabWidgetCode->insertTab( TabPage_2, QString::fromLatin1("") );

    TabPage_3 = new QWidget( tabWidgetCode, "TabPage_3" );
    TabPageLayout_3 = new QVBoxLayout( TabPage_3, 11, 6, "TabPageLayout_3"); 
    spacer21_2_4_2 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Fixed );
    TabPageLayout_3->addItem( spacer21_2_4_2 );

    layout38_3 = new QVBoxLayout( 0, 2, 2, "layout38_3"); 

    checkBoxAddFortran = new QCheckBox( TabPage_3, "checkBoxAddFortran" );
    checkBoxAddFortran->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout38_3->addWidget( checkBoxAddFortran );

    layout37_4 = new QHBoxLayout( 0, 0, 2, "layout37_4"); 

    fortranFunction = new QLineEdit( TabPage_3, "fortranFunction" );
    fortranFunction->setEnabled( TRUE );
    fortranFunction->setMinimumSize( QSize( 0, 20 ) );
    fortranFunction->setMaximumSize( QSize( 32767, 20 ) );
    fortranFunction->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    fortranFunction->setLineWidth( 1 );
    fortranFunction->setReadOnly( FALSE );
    layout37_4->addWidget( fortranFunction );

    pushButtonFortranFunction = new QToolButton( TabPage_3, "pushButtonFortranFunction" );
    pushButtonFortranFunction->setMaximumSize( QSize( 20, 20 ) );
    pushButtonFortranFunction->setIconSet( QIconSet( image15 ) );
    layout37_4->addWidget( pushButtonFortranFunction );

    pushButtonFortranFunctionView = new QToolButton( TabPage_3, "pushButtonFortranFunctionView" );
    pushButtonFortranFunctionView->setMaximumSize( QSize( 20, 20 ) );
    pushButtonFortranFunctionView->setIconSet( QIconSet( image5 ) );
    layout37_4->addWidget( pushButtonFortranFunctionView );
    layout38_3->addLayout( layout37_4 );
    TabPageLayout_3->addLayout( layout38_3 );

    layout72 = new QVBoxLayout( 0, 2, 2, "layout72"); 

    textLabelFortran_2 = new QLabel( TabPage_3, "textLabelFortran_2" );
    textLabelFortran_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout72->addWidget( textLabelFortran_2 );

    textEditForwardFortran = new QTextEdit( TabPage_3, "textEditForwardFortran" );
    textEditForwardFortran->setFrameShape( QTextEdit::NoFrame );
    textEditForwardFortran->setTextFormat( QTextEdit::PlainText );
    layout72->addWidget( textEditForwardFortran );
    TabPageLayout_3->addLayout( layout72 );
    tabWidgetCode->insertTab( TabPage_3, QString::fromLatin1("") );

    TabPage_4 = new QWidget( tabWidgetCode, "TabPage_4" );
    TabPageLayout_4 = new QVBoxLayout( TabPage_4, 11, 6, "TabPageLayout_4"); 

    groupBox45 = new QGroupBox( TabPage_4, "groupBox45" );
    groupBox45->setCheckable( FALSE );
    groupBox45->setColumnLayout(0, Qt::Vertical );
    groupBox45->layout()->setSpacing( 6 );
    groupBox45->layout()->setMargin( 11 );
    groupBox45Layout = new QVBoxLayout( groupBox45->layout() );
    groupBox45Layout->setAlignment( Qt::AlignTop );

    layout272 = new QHBoxLayout( 0, 0, 6, "layout272"); 

    layout271 = new QGridLayout( 0, 1, 1, 0, 6, "layout271"); 

    layout157 = new QHBoxLayout( 0, 0, 6, "layout157"); 

    spinBoxSubFitNumber = new QSpinBox( groupBox45, "spinBoxSubFitNumber" );
    spinBoxSubFitNumber->setEnabled( TRUE );
    spinBoxSubFitNumber->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxSubFitNumber->sizePolicy().hasHeightForWidth() ) );
    spinBoxSubFitNumber->setMaximumSize( QSize( 200, 25 ) );
    spinBoxSubFitNumber->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    spinBoxSubFitNumber->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxSubFitNumber->setPalette( pal );
    spinBoxSubFitNumber->setMaxValue( 100 );
    spinBoxSubFitNumber->setMinValue( 1 );
    layout157->addWidget( spinBoxSubFitNumber );

    spinBoxSubFitCurrent = new QSpinBox( groupBox45, "spinBoxSubFitCurrent" );
    spinBoxSubFitCurrent->setEnabled( TRUE );
    spinBoxSubFitCurrent->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxSubFitCurrent->sizePolicy().hasHeightForWidth() ) );
    spinBoxSubFitCurrent->setMaximumSize( QSize( 200, 25 ) );
    spinBoxSubFitCurrent->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    spinBoxSubFitCurrent->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxSubFitCurrent->setPalette( pal );
    spinBoxSubFitCurrent->setMaxValue( 100 );
    spinBoxSubFitCurrent->setMinValue( 1 );
    spinBoxSubFitCurrent->setValue( 2 );
    layout157->addWidget( spinBoxSubFitCurrent );

    layout271->addLayout( layout157, 3, 1 );
    spacer125 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout271->addItem( spacer125, 0, 1 );

    checkBoxSuperpositionalFit = new QCheckBox( groupBox45, "checkBoxSuperpositionalFit" );
    checkBoxSuperpositionalFit->setMinimumSize( QSize( 130, 25 ) );
    checkBoxSuperpositionalFit->setMaximumSize( QSize( 32767, 25 ) );
    checkBoxSuperpositionalFit->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxSuperpositionalFit->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );

    layout271->addWidget( checkBoxSuperpositionalFit, 3, 0 );

    checkBoxAlgorithm = new QCheckBox( groupBox45, "checkBoxAlgorithm" );
    checkBoxAlgorithm->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    layout271->addWidget( checkBoxAlgorithm, 2, 0 );

    checkBoxWeight = new QCheckBox( groupBox45, "checkBoxWeight" );
    checkBoxWeight->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    layout271->addWidget( checkBoxWeight, 1, 0 );

    comboBoxWeightingMethod = new QComboBox( FALSE, groupBox45, "comboBoxWeightingMethod" );
    comboBoxWeightingMethod->setEnabled( TRUE );
    comboBoxWeightingMethod->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, comboBoxWeightingMethod->sizePolicy().hasHeightForWidth() ) );
    comboBoxWeightingMethod->setMinimumSize( QSize( 220, 20 ) );
    comboBoxWeightingMethod->setMaximumSize( QSize( 3000, 25 ) );
    comboBoxWeightingMethod->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxWeightingMethod->setPalette( pal );

    layout271->addWidget( comboBoxWeightingMethod, 1, 1 );

    comboBoxFitMethod = new QComboBox( FALSE, groupBox45, "comboBoxFitMethod" );
    comboBoxFitMethod->setEnabled( TRUE );
    comboBoxFitMethod->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, comboBoxFitMethod->sizePolicy().hasHeightForWidth() ) );
    comboBoxFitMethod->setMinimumSize( QSize( 250, 25 ) );
    comboBoxFitMethod->setMaximumSize( QSize( 3000, 20 ) );
    comboBoxFitMethod->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxFitMethod->setPalette( pal );
    comboBoxFitMethod->setAutoMask( FALSE );

    layout271->addWidget( comboBoxFitMethod, 2, 1 );

    checkBoxEfit = new QCheckBox( groupBox45, "checkBoxEfit" );
    checkBoxEfit->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    layout271->addWidget( checkBoxEfit, 0, 0 );
    layout272->addLayout( layout271 );
    spacer126 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout272->addItem( spacer126 );
    groupBox45Layout->addLayout( layout272 );
    spacer127 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    groupBox45Layout->addItem( spacer127 );
    TabPageLayout_4->addWidget( groupBox45 );
    tabWidgetCode->insertTab( TabPage_4, QString::fromLatin1("") );

    TabPage_5 = new QWidget( tabWidgetCode, "TabPage_5" );
    TabPageLayout_5 = new QVBoxLayout( TabPage_5, 2, 2, "TabPageLayout_5"); 
    spacer21_2_4_3 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Fixed );
    TabPageLayout_5->addItem( spacer21_2_4_3 );

    layout77 = new QHBoxLayout( 0, 0, 2, "layout77"); 

    buttonGroup28 = new QButtonGroup( TabPage_5, "buttonGroup28" );
    buttonGroup28->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup28->sizePolicy().hasHeightForWidth() ) );
    buttonGroup28->setMinimumSize( QSize( 0, 25 ) );
    buttonGroup28->setMaximumSize( QSize( 32767, 25 ) );
    buttonGroup28->setAlignment( int( QButtonGroup::AlignVCenter ) );
    buttonGroup28->setColumnLayout(0, Qt::Vertical );
    buttonGroup28->layout()->setSpacing( 4 );
    buttonGroup28->layout()->setMargin( 4 );
    buttonGroup28Layout = new QHBoxLayout( buttonGroup28->layout() );
    buttonGroup28Layout->setAlignment( Qt::AlignTop );

    radioButtonFIF = new QRadioButton( buttonGroup28, "radioButtonFIF" );
    radioButtonFIF->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, radioButtonFIF->sizePolicy().hasHeightForWidth() ) );
    radioButtonFIF->setMinimumSize( QSize( 160, 20 ) );
    radioButtonFIF->setMaximumSize( QSize( 1800, 20 ) );
    radioButtonFIF->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    radioButtonFIF->setAutoMask( FALSE );
    radioButtonFIF->setAutoRepeat( FALSE );
    buttonGroup28Layout->addWidget( radioButtonFIF );

    radioButtonCPP = new QRadioButton( buttonGroup28, "radioButtonCPP" );
    radioButtonCPP->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, radioButtonCPP->sizePolicy().hasHeightForWidth() ) );
    radioButtonCPP->setMinimumSize( QSize( 160, 20 ) );
    radioButtonCPP->setMaximumSize( QSize( 1800, 20 ) );
    radioButtonCPP->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    radioButtonCPP->setChecked( FALSE );
    buttonGroup28Layout->addWidget( radioButtonCPP );

    radioButtonBAT = new QRadioButton( buttonGroup28, "radioButtonBAT" );
    radioButtonBAT->setMinimumSize( QSize( 0, 20 ) );
    radioButtonBAT->setMaximumSize( QSize( 75, 20 ) );
    radioButtonBAT->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    radioButtonBAT->setChecked( TRUE );
    buttonGroup28Layout->addWidget( radioButtonBAT );
    layout77->addWidget( buttonGroup28 );

    pushButtonInNoteFiles = new QToolButton( TabPage_5, "pushButtonInNoteFiles" );
    pushButtonInNoteFiles->setMinimumSize( QSize( 25, 25 ) );
    pushButtonInNoteFiles->setMaximumSize( QSize( 25, 25 ) );
    pushButtonInNoteFiles->setIconSet( QIconSet( image5 ) );
    layout77->addWidget( pushButtonInNoteFiles );

    pushButtonTestSave = new QToolButton( TabPage_5, "pushButtonTestSave" );
    pushButtonTestSave->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonTestSave->sizePolicy().hasHeightForWidth() ) );
    pushButtonTestSave->setMinimumSize( QSize( 25, 25 ) );
    pushButtonTestSave->setMaximumSize( QSize( 25, 25 ) );
    pushButtonTestSave->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonTestSave->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonTestSave->setPalette( pal );
    QFont pushButtonTestSave_font(  pushButtonTestSave->font() );
    pushButtonTestSave_font.setBold( TRUE );
    pushButtonTestSave->setFont( pushButtonTestSave_font ); 
    pushButtonTestSave->setIconSet( QIconSet( image1 ) );
    pushButtonTestSave->setUsesBigPixmap( FALSE );
    pushButtonTestSave->setUsesTextLabel( TRUE );
    pushButtonTestSave->setTextPosition( QToolButton::BesideIcon );
    layout77->addWidget( pushButtonTestSave );

    pushButtonTestCompile = new QToolButton( TabPage_5, "pushButtonTestCompile" );
    pushButtonTestCompile->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonTestCompile->sizePolicy().hasHeightForWidth() ) );
    pushButtonTestCompile->setMinimumSize( QSize( 25, 25 ) );
    pushButtonTestCompile->setMaximumSize( QSize( 20, 25 ) );
    pushButtonTestCompile->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonTestCompile->setPaletteBackgroundColor( QColor( 221, 223, 228 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonTestCompile->setPalette( pal );
    QFont pushButtonTestCompile_font(  pushButtonTestCompile->font() );
    pushButtonTestCompile_font.setBold( TRUE );
    pushButtonTestCompile->setFont( pushButtonTestCompile_font ); 
    pushButtonTestCompile->setIconSet( QIconSet( image3 ) );
    pushButtonTestCompile->setUsesBigPixmap( FALSE );
    pushButtonTestCompile->setUsesTextLabel( TRUE );
    pushButtonTestCompile->setTextPosition( QToolButton::BesideIcon );
    layout77->addWidget( pushButtonTestCompile );
    TabPageLayout_5->addLayout( layout77 );

    tableCPP = new QTable( TabPage_5, "tableCPP" );
    tableCPP->setNumCols( tableCPP->numCols() + 1 );
    tableCPP->horizontalHeader()->setLabel( tableCPP->numCols() - 1, tr( "file content" ) );
    tableCPP->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, tableCPP->sizePolicy().hasHeightForWidth() ) );
    tableCPP->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    tableCPP->setPalette( pal );
    tableCPP->setFrameShape( QTable::NoFrame );
    tableCPP->setResizePolicy( QTable::Default );
    tableCPP->setNumRows( 0 );
    tableCPP->setNumCols( 1 );
    tableCPP->setShowGrid( FALSE );
    tableCPP->setReadOnly( FALSE );
    TabPageLayout_5->addWidget( tableCPP );
    tabWidgetCode->insertTab( TabPage_5, QString::fromLatin1("") );
    layout101->addWidget( tabWidgetCode );
    buttonGroup6Layout->addLayout( layout101 );

    layout48 = new QVBoxLayout( 0, 2, 0, "layout48"); 

    pushButtonCodeDown = new QToolButton( buttonGroup6, "pushButtonCodeDown" );
    pushButtonCodeDown->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonCodeDown->sizePolicy().hasHeightForWidth() ) );
    pushButtonCodeDown->setMinimumSize( QSize( 14, 14 ) );
    pushButtonCodeDown->setMaximumSize( QSize( 14, 14 ) );
    pushButtonCodeDown->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    pushButtonCodeDown->setPaletteBackgroundColor( QColor( 236, 233, 216 ) );
    QFont pushButtonCodeDown_font(  pushButtonCodeDown->font() );
    pushButtonCodeDown_font.setBold( TRUE );
    pushButtonCodeDown->setFont( pushButtonCodeDown_font ); 
    layout48->addWidget( pushButtonCodeDown );

    pushButtonCodeUp = new QToolButton( buttonGroup6, "pushButtonCodeUp" );
    pushButtonCodeUp->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonCodeUp->sizePolicy().hasHeightForWidth() ) );
    pushButtonCodeUp->setMinimumSize( QSize( 14, 14 ) );
    pushButtonCodeUp->setMaximumSize( QSize( 14, 14 ) );
    pushButtonCodeUp->setPaletteForegroundColor( QColor( 255, 0, 0 ) );
    pushButtonCodeUp->setPaletteBackgroundColor( QColor( 236, 233, 216 ) );
    QFont pushButtonCodeUp_font(  pushButtonCodeUp->font() );
    pushButtonCodeUp_font.setBold( TRUE );
    pushButtonCodeUp->setFont( pushButtonCodeUp_font ); 
    layout48->addWidget( pushButtonCodeUp );
    spacer23_2_2_3 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout48->addItem( spacer23_2_2_3 );
    buttonGroup6Layout->addLayout( layout48 );

    QWidget* privateLayoutWidget_8 = new QWidget( splitterMain, "layout50" );
    layout50 = new QHBoxLayout( privateLayoutWidget_8, 0, 3, "layout50"); 

    textLabelInfoSAS = new QLabel( privateLayoutWidget_8, "textLabelInfoSAS" );
    textLabelInfoSAS->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfoSAS->sizePolicy().hasHeightForWidth() ) );
    textLabelInfoSAS->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfoSAS->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabelInfoSAS->setPalette( pal );
    textLabelInfoSAS->setFrameShape( QLabel::Box );
    textLabelInfoSAS->setTextFormat( QLabel::RichText );
    textLabelInfoSAS->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    textLabelInfoSAS->setIndent( 0 );
    layout50->addWidget( textLabelInfoSAS );

    textLabelInfo_2_2 = new QLabel( privateLayoutWidget_8, "textLabelInfo_2_2" );
    textLabelInfo_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo_2_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabelInfo_2_2->setPalette( pal );
    textLabelInfo_2_2->setFrameShape( QLabel::Box );
    textLabelInfo_2_2->setAlignment( int( QLabel::AlignCenter ) );
    layout50->addWidget( textLabelInfo_2_2 );

    textLabelInfo_2 = new QLabel( privateLayoutWidget_8, "textLabelInfo_2" );
    textLabelInfo_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo_2->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo_2->setMinimumSize( QSize( 0, 20 ) );
    textLabelInfo_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabelInfo_2->setPalette( pal );
    textLabelInfo_2->setFrameShape( QLabel::Box );
    textLabelInfo_2->setFrameShadow( QLabel::Plain );
    textLabelInfo_2->setAlignment( int( QLabel::AlignCenter ) );
    layout50->addWidget( textLabelInfo_2 );

    pushButtonHelp = new QPushButton( privateLayoutWidget_8, "pushButtonHelp" );
    pushButtonHelp->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonHelp->sizePolicy().hasHeightForWidth() ) );
    pushButtonHelp->setMinimumSize( QSize( 18, 20 ) );
    pushButtonHelp->setMaximumSize( QSize( 18, 20 ) );
    pushButtonHelp->setPaletteForegroundColor( QColor( 239, 239, 239 ) );
    pushButtonHelp->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 247, 247, 247) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonHelp->setPalette( pal );
    pushButtonHelp->setPixmap( image16 );
    pushButtonHelp->setFlat( TRUE );
    layout50->addWidget( pushButtonHelp );
    layout49->addWidget( splitterMain );
    compile10Layout->addLayout( layout49 );
    languageChange();
    resize( QSize(836, 737).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( lineEditFunctionName, SIGNAL( lostFocus() ), this, SLOT( checkFunctionName() ) );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
compile10::~compile10()
{
    destroy();
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void compile10::languageChange()
{
    setCaption( tr( "QtiKWS::COMPILE" ) );
    buttonGroup13->setTitle( QString::null );
    radioButton1D->setText( tr( "1D f(x)" ) );
    QToolTip::add( radioButton1D, tr( "Function for Fit::Curve interface" ) );
    QWhatsThis::add( radioButton1D, tr( "Function for Fit::Curve interface" ) );
    radioButton2D->setText( tr( "2D f(x,y,...)" ) );
    QToolTip::add( radioButton2D, tr( "Function for Fit::Matrix interface" ) );
    QWhatsThis::add( radioButton2D, tr( "Function for Fit::Matrix interface" ) );
    pushButtonNew->setText( QString::null );
    pushButtonNew->setTextLabel( tr( "new" ) );
    QToolTip::add( pushButtonNew, tr( "Create new function : clear interfaces" ) );
    QWhatsThis::add( pushButtonNew, tr( "Create new function : clear interfaces" ) );
    pushButtonSave->setText( QString::null );
    pushButtonSave->setTextLabel( tr( "save" ) );
    QToolTip::add( pushButtonSave, tr( "Save current or new function" ) );
    pushButtonDelete->setText( QString::null );
    pushButtonDelete->setTextLabel( tr( "delete" ) );
    QToolTip::add( pushButtonDelete, tr( "Delete current function" ) );
    QWhatsThis::add( pushButtonDelete, tr( "Delete current function" ) );
    pushButtonMakeDLL->setText( QString::null );
    pushButtonMakeDLL->setTextLabel( tr( "compile" ) );
    QToolTip::add( pushButtonMakeDLL, tr( "Compile current function" ) );
    QWhatsThis::add( pushButtonMakeDLL, tr( "Compile current function" ) );
    buttonGroupExplorer->setTitle( QString::null );
    textLabelGroupName_2->setText( tr( "Categories" ) );
    QToolTip::add( listBoxGroup, tr( "Select Category of Fit-Function" ) );
    QWhatsThis::add( listBoxGroup, tr( "Select Category of Fit-Function" ) );
    lineEditGroupName->setText( QString::null );
    QToolTip::add( lineEditGroupName, tr( "Current Category || Input Category of a new function" ) );
    QWhatsThis::add( lineEditGroupName, tr( "Current Category || Input Category of a new function" ) );
    textLabelFunctionName_2->setText( tr( "Functions" ) );
    QToolTip::add( listBoxFunctions, tr( "Select a fit-function" ) );
    QWhatsThis::add( listBoxFunctions, tr( "Select a fit-function" ) );
    QToolTip::add( lineEditFunctionName, tr( "Current Function || Input Name of a new function" ) );
    QWhatsThis::add( lineEditFunctionName, tr( "Current Function || Input Name of a new function" ) );
    pushButtonExplDown->setText( tr( "+" ) );
    pushButtonExplUp->setText( tr( "-" ) );
    buttonGroup5->setTitle( QString::null );
    textLabelNumberParameters_2_2->setText( tr( "Dependent variable" ) );
    textLabel1_3->setText( tr( "Independent variable(s)" ) );
    lineEditY->setText( tr( "f" ) );
    QToolTip::add( lineEditY, tr( "[f] :: f=f(x,{p1,p2,...})" ) );
    QWhatsThis::add( lineEditY, tr( "[f] :: f=f(x,{p1, p2, ...})" ) );
    lineEditXXX->setText( QString::null );
    lineEditXXX->setInputMask( tr( "nnnn; " ) );
    QToolTip::add( lineEditXXX, tr( "[y] :: f=f(x,y,{p1,p2,...})" ) );
    QWhatsThis::add( lineEditXXX, tr( "[y] :: f=f(x,y,{p1,p2,...})" ) );
    QToolTip::add( spinBoxXnumber, tr( "Number of independent variables" ) );
    QWhatsThis::add( spinBoxXnumber, tr( "Number of independent variables" ) );
    tableParaNames->horizontalHeader()->setLabel( 0, tr( "Name" ) );
    tableParaNames->horizontalHeader()->setLabel( 1, tr( "Initial Value[Ran..ge]" ) );
    tableParaNames->horizontalHeader()->setLabel( 2, tr( "Vary?" ) );
    tableParaNames->horizontalHeader()->setLabel( 3, tr( "Info" ) );
    pushButtonParaDown->setText( tr( "+" ) );
    pushButtonParaUp->setText( tr( "-" ) );
    buttonGroup6->setTitle( QString::null );
    QToolTip::add( tabWidgetCode, QString::null );
    pushButtonMenu->setText( trUtf8( "\xc2\xbb" ) );
    QToolTip::add( pushButtonMenu, tr( "Menu" ) );
    QWhatsThis::add( pushButtonMenu, tr( "Menu" ) );
    frameMenu->setTitle( QString::null );
    pushButtonMenuSTD->setText( tr( "para" ) );
    QToolTip::add( pushButtonMenuSTD, tr( "Define flags in order to know: Where is called this function now?" ) );
    QWhatsThis::add( pushButtonMenuSTD, tr( "Define flags in order to know: Where is called this function now?" ) );
    pushButtonMenuFlags->setText( tr( "flags" ) );
    QToolTip::add( pushButtonMenuFlags, tr( "Define flags in order to know: Where is called this function now?" ) );
    QWhatsThis::add( pushButtonMenuFlags, tr( "Define flags in order to know: Where is called this function now?" ) );
    pushButtonMenuData->setText( tr( "data" ) );
    QToolTip::add( pushButtonMenuData, tr( "Get data inside of function  " ) );
    QWhatsThis::add( pushButtonMenuData, tr( "Get data inside of function" ) );
    pushButtonMenuSANS->setText( tr( "sa(n)s" ) );
    QToolTip::add( pushButtonMenuSANS, tr( "[SA(N)S] Instrumental Options " ) );
    QWhatsThis::add( pushButtonMenuSANS, tr( "[SA(N)S] Instrumental Options" ) );
    pushButtonMenuMath->setText( tr( "math" ) );
    QToolTip::add( pushButtonMenuMath, tr( "C/C++ standart mathematical functions" ) );
    QWhatsThis::add( pushButtonMenuMath, tr( "C/C++ standart mathematical functions" ) );
    pushButtonMenuMULTI->setText( tr( "multi-function" ) );
    QToolTip::add( pushButtonMenuMULTI, tr( "GSL functions" ) );
    QWhatsThis::add( pushButtonMenuMULTI, tr( "GSL functions" ) );
    textEditCode->setText( QString::null );
    QToolTip::add( textEditCode, QString::null );
    tabWidgetCode->changeTab( tab, tr( "Code" ) );
    textLabel2_2_2->setText( tr( "#include Headers" ) );
    textLabel2_2_2_2->setText( tr( "Select Included Function" ) );
    pushButtonAddHeader->setText( QString::null );
    pushButtonOpenInNote->setText( QString::null );
    pushButtonMakeIncluded->setText( QString::null );
    pushButtonIncludedDelete->setText( QString::null );
    textLabel2_2_3_2->setText( tr( "Included Functions" ) );
    textEditFunctions->setText( QString::null );
    tabWidgetCode->changeTab( tab_2, tr( "Included" ) );
    textEditDescription->setText( QString::null );
    pushButtonEXP->setText( QString::null );
    pushButtonSub->setText( QString::null );
    pushButtonGreek->setText( QString::null );
    pushButtonBold->setText( QString::null );
    pushButtonItal->setText( QString::null );
    pushButtonUnder->setText( QString::null );
    pushButtonLeft->setText( QString::null );
    pushButtonCenter->setText( QString::null );
    pushButtonRight->setText( QString::null );
    pushButtonJust->setText( QString::null );
    tabWidgetCode->changeTab( TabPage, tr( "Info" ) );
    groupBoxMinGw->setTitle( tr( "Path(s)" ) );
    textLabel2_2->setText( tr( "Path: to *.fif functions (privat)" ) );
    fitPath->setText( QString::null );
    pushButtonPath->setText( QString::null );
    checkBoxGSLlocal->setText( tr( "GSL:: Local?" ) );
    checkBoxGSLstatic->setText( tr( "Static?" ) );
    textLabelGSL->setText( tr( "Directory [$GSL]:" ) );
    gslPathline->setText( QString::null );
    pushButtonPathGSL->setText( QString::null );
    checkBoxCompilerLocal->setText( tr( "Compiler:: Local?" ) );
    textLabelMingw->setText( tr( "Directory:" ) );
    mingwPathline->setText( QString::null );
    pushButtonPathMingw->setText( QString::null );
    buttonGroup12->setTitle( tr( "Advanced Buttons" ) );
    pushButtonOpenFIF->setText( QString::null );
    pushButtonOpenFIF->setTextLabel( tr( "open" ) );
    pushButtonSaveAs->setText( QString::null );
    pushButtonSaveAs->setTextLabel( tr( "save as" ) );
    pushButtonCompileAll->setText( QString::null );
    pushButtonCompileAll->setTextLabel( tr( "compile all" ) );
    pushButtonDefaultOptions->setText( QString::null );
    pushButtonDefaultOptions->setTextLabel( tr( "default options" ) );
    textLabel1->setText( tr( "Compile Flags ::" ) );
    lineEditCompileFlags->setText( tr( "-m32 -w" ) );
    textLabel1_2->setText( tr( "Link Flags ::" ) );
    lineEditLinkFlags->setText( tr( "-m32" ) );
    tabWidgetCode->changeTab( TabPage_2, tr( "Options" ) );
    checkBoxAddFortran->setText( tr( "Use FORTRAN functions from file:" ) );
    fortranFunction->setText( QString::null );
    pushButtonFortranFunction->setText( QString::null );
    pushButtonFortranFunctionView->setText( QString::null );
    textLabelFortran_2->setText( tr( "Forward Declaration [FORTRAN functions in CPP]::" ) );
    tabWidgetCode->changeTab( TabPage_3, tr( "+Fortran" ) );
    groupBox45->setTitle( QString::null );
    spinBoxSubFitNumber->setPrefix( tr( "#Functions:  " ) );
    spinBoxSubFitNumber->setSuffix( QString::null );
    QToolTip::add( spinBoxSubFitNumber, tr( "Number of Curves" ) );
    QWhatsThis::add( spinBoxSubFitNumber, tr( "Number of Curves" ) );
    spinBoxSubFitCurrent->setPrefix( tr( "Current Function:  " ) );
    spinBoxSubFitCurrent->setSuffix( QString::null );
    QToolTip::add( spinBoxSubFitCurrent, tr( "Number of Curves" ) );
    QWhatsThis::add( spinBoxSubFitCurrent, tr( "Number of Curves" ) );
    checkBoxSuperpositionalFit->setText( tr( "[Superpositional Fit]" ) );
    QToolTip::add( checkBoxSuperpositionalFit, tr( "Simultanious Fit of Several Datasets" ) );
    QWhatsThis::add( checkBoxSuperpositionalFit, tr( "Simultanious Fit of Several Datasets" ) );
    checkBoxAlgorithm->setText( tr( "[Algorithm]" ) );
    checkBoxWeight->setText( tr( "[Weight]" ) );
    comboBoxWeightingMethod->clear();
    comboBoxWeightingMethod->insertItem( trUtf8( "\x77\x20\x3d\x20\x31\x2f\x64\x59\xc2\xb2\x20\x7c\x20\x49\x6e\x73\x74\x72\x75\x6d\x65"
    "\x6e\x74\x61\x6c\x20\x6f\x72\x20\x41\x72\x62\x69\x74\x72\x61\x72\x79\x20\x44\x61"
    "\x74\x61\x73\x65\x74" ) );
    comboBoxWeightingMethod->insertItem( tr( "w = 1/Y  | Statistical" ) );
    comboBoxWeightingMethod->insertItem( tr( "w = dY   | Direct" ) );
    comboBoxWeightingMethod->insertItem( trUtf8( "\x77\x20\x3d\x20\x31\x2f\x59\xc2\xb2\x20\x7c\x20\x56\x61\x72\x69\x61\x6e\x63\x65" ) );
    comboBoxWeightingMethod->insertItem( tr( "w = 1/Y^a | Variance" ) );
    comboBoxWeightingMethod->insertItem( tr( "w = 1/[c^a+b*Y^a]  | Variance" ) );
    comboBoxWeightingMethod->insertItem( tr( "w = 1/ Y^a / c^|Xmax-X|  | Variance" ) );
    comboBoxWeightingMethod->setCurrentItem( 1 );
    comboBoxFitMethod->clear();
    comboBoxFitMethod->insertItem( tr( "Nelder-Mead Simplex  [nmsimplex2]" ) );
    comboBoxFitMethod->insertItem( tr( "Nelder-Mead Simplex  [nmsimplex2rand]" ) );
    comboBoxFitMethod->insertItem( tr( "Levenberg-Marquardt [Delta, Scaled]" ) );
    comboBoxFitMethod->insertItem( tr( "Levenberg-Marquardt [Delta, Unscaled]" ) );
    comboBoxFitMethod->insertItem( tr( "Levenberg-Marquardt [Gradient, Scaled]" ) );
    comboBoxFitMethod->insertItem( tr( "Levenberg-Marquardt [Gradient, Unscaled]" ) );
    comboBoxFitMethod->insertItem( tr( "[GenMin]" ) );
    comboBoxFitMethod->setCurrentItem( 2 );
    checkBoxEfit->setText( tr( "[eFit]" ) );
    tabWidgetCode->changeTab( TabPage_4, tr( "eFit" ) );
    buttonGroup28->setTitle( QString::null );
    radioButtonFIF->setText( tr( "*.fif" ) );
    radioButtonCPP->setText( tr( "*.cpp" ) );
    radioButtonBAT->setText( tr( "BAT.BAT" ) );
    pushButtonInNoteFiles->setText( QString::null );
    pushButtonTestSave->setText( QString::null );
    pushButtonTestSave->setTextLabel( QString::null );
    QToolTip::add( pushButtonTestSave, tr( "Save current or new function" ) );
    pushButtonTestCompile->setText( QString::null );
    pushButtonTestCompile->setTextLabel( QString::null );
    QToolTip::add( pushButtonTestCompile, tr( "Compile current function" ) );
    QWhatsThis::add( pushButtonTestCompile, tr( "Compile current function" ) );
    tableCPP->horizontalHeader()->setLabel( 0, tr( "file content" ) );
    tabWidgetCode->changeTab( TabPage_5, tr( "Files" ) );
    pushButtonCodeDown->setText( tr( "+" ) );
    pushButtonCodeUp->setText( tr( "-" ) );
    textLabelInfoSAS->setText( tr( "Compile Fit Function" ) );
    textLabelInfo_2_2->setText( tr( "v.10-15.12.2014" ) );
    textLabelInfo_2->setText( tr( "Vitaliy Pipich @ JCNS" ) );
    pushButtonHelp->setText( QString::null );
}

