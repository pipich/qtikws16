#include "dan16.h"

//*******************************************
//+++  RT tools:: Sum [slot]
//*******************************************
void dan16::addfilesConnectSlots()
{
    connect( pushButtonAddUni , SIGNAL( clicked() ), this, SLOT( addSeveralFilesUniSingleFrame() ) );
    connect( pushButtonAddUniInTable  , SIGNAL( clicked() ), this, SLOT( readTableToAddCols()) );
    connect( pushButtonGenerateAddingTable  , SIGNAL( clicked() ), this, SLOT( generateTableToAdd()) );
}

//*******************************************
//+++  Uni:: Add Several Files [slot]
//*******************************************
void dan16::addSeveralFilesUniSingleFrame()
{
    ImportantConstants();
    
    QString dir 	= Dir;
    QString dirOut   = lineEditPathRAD->text();
    
    //+++ select files
    QFileDialog *fd = new QFileDialog(dir, textEditPattern->text(), this,"Add Several (Single) Files");
    fd->setDir(dir);
    fd->setMode( QFileDialog::ExistingFiles );
    fd->setCaption(tr("QtiKWS - Add Several (Single) Files"));
    
    if (!fd->exec() == QDialog::Accepted ) return;
    
    QStringList selectedDat=fd->selectedFiles();
    
    int filesNumber= selectedDat.count();
    
    
    if (!selectedDat[0].contains(dir))
    {
        QMessageBox::warning(this,tr("QtiKWS"), tr("Select data ONLY in INPUT folder!"));
        return;
    }
    
    // convert name to number
    QStringList numberList;
    QString sss;
    for (int i=0; i<filesNumber; i++)
    {
        sss=selectedDat[i];
        QString nameFile=findFileNumberInFileName(wildCard, sss.remove(dir));
        numberList<< nameFile;
    }
    
    QString finalNameIndex=numberList[0];
    
    if (filesNumber>=999) finalNameIndex=finalNameIndex+"0"+QString::number(filesNumber);
    else if (filesNumber>=99) finalNameIndex=finalNameIndex+"00"+QString::number(filesNumber);
    else if (filesNumber>=9) finalNameIndex=finalNameIndex+"000"+QString::number(filesNumber);
    else finalNameIndex=finalNameIndex+"0000"+QString::number(filesNumber);
    
    sss=selectedDat[0];
    sss=sss.replace(dir,dirOut);
    sss=sss.replace(numberList[0],finalNameIndex);
    
    QString file=sss;
    //    file=dirOut+"/"+file;
    //    file=file.replace("//","/");
    
    
    bool ok;
    file = QInputDialog::getText("QtiKWS", "Enter name of Mergrd File [change suffix  and number]:", QLineEdit::Normal, file, &ok, this );
    if ( !ok ) return;
    
    
    addSeveralFilesUniSingleFrame(selectedDat, numberList, file);
}

//*******************************************
//+++  Uni:: Add Several Files [function]
//*******************************************
void dan16::addSeveralFilesUniSingleFrame(QStringList selectedFileList, QStringList selectedNumberList, QString fileName)
{
    if (comboBoxHeaderFormat->currentItem()==0) addNfilesUniASCII(selectedFileList, selectedNumberList, fileName);
    if (comboBoxHeaderFormat->currentItem()==2) addNfilesYaml(selectedFileList, selectedNumberList, fileName);
}

//*******************************************
//+++  Uni:: Add Several Files [function]
//*******************************************
void dan16::addSeveralFilesUniSingleFrame(QStringList selectedNumberList, QString fileNumber)
{
    QString wildCardLocal=lineEditWildCard->text();
    QStringList selectedFileList;
    
    for (int i=0; i<selectedNumberList.count();i++)
    {
        selectedFileList<<fileNameUni(wildCardLocal, selectedNumberList[i]);
    }
    
    QString newFileName;
    
    if (wildCardLocal.contains("#")==1)
    {
        newFileName=fileNameUni(wildCardLocal, selectedNumberList[0]);
        newFileName=newFileName.replace(Dir,lineEditPathRAD->text());
        newFileName=newFileName.replace(selectedNumberList[0],fileNumber);
    }
    else
    {
        newFileName=newFileNameUni(wildCardLocal, fileNumber);
    }
    
    
    addSeveralFilesUniSingleFrame(selectedFileList, selectedNumberList, newFileName);
}

//*******************************************
//+++  Uni:: readTableToAddCols [slot]
//*******************************************
void dan16::readTableToAddCols()
{
    ImportantConstants();
    
    QString wildCardLocal=lineEditWildCard->text();
    
    int mm,nn;
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("Table")) return;
    
    Table* t = (Table*)app(this)->ws->activeWindow();
    
    int N=t->numCols();
    int M=t->numRows();
    
    QString fileNumber, file2add;
    QStringList selectedNumberList;
    QStringList selectedFiles;
    
    //+++ Set Data-Sets List +++
    for(nn=0; nn<N;nn++)
    {
        selectedNumberList.clear();
        selectedFiles.clear();
        
        fileNumber=t->text(0,nn);
        fileNumber=fileNumber.simplifyWhiteSpace();
        fileNumber=fileNumber.replace(" ", "-").replace("/", "-").replace(",", "-").replace(".", "-").remove("%");
        
        
        if (fileNumber=="") continue;
        
        
        for(mm=1; mm<M;mm++)
        {
            file2add=t->text(mm,nn);
            
            file2add=file2add.simplifyWhiteSpace();
            
            if (file2add=="") continue;
            
            if (!checkFileNumber( file2add ) ) continue;
            
            selectedNumberList<<file2add;
            selectedFiles<<fileNameUni( wildCard, file2add);
        }
        
        
        
        
        if (toolBoxAdv->currentIndex()==0) addSeveralFilesUniSingleFrame(selectedNumberList,fileNumber);
        else if (toolBoxAdv->currentIndex()==1)
        {
            fileNumber=lineEditPathRAD->text()+"rt0_"+fileNumber+"_added-"+QString::number(selectedNumberList.count())+".DAT";
            tofrtAddFiles(selectedFiles,fileNumber);
        }
        else if (toolBoxAdv->currentIndex()==2)
        {
            fileNumber=lineEditPathRAD->text()+"tof0_"+fileNumber+"_added-"+QString::number(selectedFiles.count())+".DAT";
            tofrtAddFiles(selectedNumberList,fileNumber);
        }
    }
}

//*******************************************
//+++  Uni:: Add Several Files [slot]
//*******************************************
void dan16::generateTableToAdd()
{
    ImportantConstants();
    
    QString dir 	= Dir;
    QString dirOut   = lineEditPathRAD->text();
    
    //+++ select files
    QFileDialog *fd = new QFileDialog(dir, textEditPattern->text(), this,"Generate ADDING table template");
    fd->setDir(dir);
    fd->setMode( QFileDialog::ExistingFiles );
    fd->setCaption(tr("QtiKWS - Generate ADDING table template"));
    
    if (!fd->exec() == QDialog::Accepted ) return;
    
    QStringList selectedDat=fd->selectedFiles();
    
    int filesNumber= selectedDat.count();
    
    
    if (!selectedDat[0].contains(dir))
    {
        QMessageBox::warning(this,tr("QtiKWS"), tr("Select data ONLY in INPUT folder!"));
        return;
    }
    
    // convert name to number
    QStringList numberList;
    QString sss;
    for (int i=0; i<filesNumber; i++)
    {
        sss=selectedDat[i];
        QString nameFile=findFileNumberInFileName(wildCard, sss.remove(dir));
        numberList<< nameFile;
    }
    
    generateTemplateToAddeFiles(numberList);
}

//*******************************************
//+++  Merging Table Generation [function]
//*******************************************
bool dan16::generateTemplateToAddeFiles(QStringList selectedNumbers )
{
    QString name="adding-template-";
    name=app(this)->generateUniqueName(name);
    Table *t=app(this)->newTable(name, 3, selectedNumbers.count());
    
    t->setWindowLabel("DAN::Adding::Template");
    app(this)->setListViewLabel(t->name(), "DAN::Adding::Template");
    app(this)->updateWindowLists(t);
    
    QStringList selectedNumbersNames;
    int  *skip=new int[selectedNumbers.count()];
    
    for (int i=0; i<selectedNumbers.count();i++ )
    {
        selectedNumbersNames<<configurationPlusSampleName(selectedNumbers[i]);
        skip[i]=0;
    }
    
    QString currentNumberName;
    QStringList currentSelectedNumbers;
    
    int maxNumberRaws=3;
    int maxNumberCols=0;
    QStringList colType;
    
    
    
    for (int i=0; i<selectedNumbers.count(); i++ )
    {
        currentSelectedNumbers.clear();
        
        currentNumberName=selectedNumbersNames[i];
        
        if (currentNumberName=="") continue;
        
        if (skip[i]==1) continue;
        
        for (int ii=i; ii<selectedNumbers.count(); ii++ )
        {
            if (skip[ii]==1) continue;
            
            if (selectedNumbersNames[ii]==currentNumberName)
            {
                currentSelectedNumbers<<selectedNumbers[ii];
                skip[ii]=1;
            }
            
        }
        
        if ( currentSelectedNumbers.count()<1 ) continue;
        
        if (maxNumberRaws<currentSelectedNumbers.count()+1) maxNumberRaws=currentSelectedNumbers.count()+1 ;
        t->setNumRows(maxNumberRaws);
        
        maxNumberCols++;
        
        QString currentLabel;
        if (currentSelectedNumbers.count()>999) currentLabel="0";
        else if (currentSelectedNumbers.count()>99) currentLabel="00";
        else if (currentSelectedNumbers.count()>9) currentLabel="000";
        else  currentLabel="0000";
        
        currentLabel=currentSelectedNumbers[0]+currentLabel+QString::number(currentSelectedNumbers.count());
        
        t->setText(0, maxNumberCols-1,currentLabel);
        
        for (int ii=0; ii<currentSelectedNumbers.count();ii++) t->setText(ii+1, maxNumberCols-1,currentSelectedNumbers[ii]);
        
        t->setColName(maxNumberCols- 1, currentNumberName );
        t->setColPlotDesignation(maxNumberCols-1,Table::None); colType<<"1";
    }
    
    t->setNumCols(maxNumberCols);  
    t->setColumnTypes(colType);
    
    //+++ adjust cols
    for (int tt=0; tt<t->numCols(); tt++)
    {
        t->table()->adjustColumn (tt);
        t->table()->setColumnWidth(tt, t->table()->columnWidth(tt)+30); 
    }
    
    return true;
}

QString dan16::configurationPlusSampleName(QString Number)
{
    QStringList lst;
    int  C;
    double M2, M3;
    double D, lambda, cps,thickness;
    QString beamSize;
    //+++
    int iter;
    
    
    int index=-1;
    if (Number.contains("["))
    {
        index=Number.right(Number.length()-Number.find("[")).remove("[").remove("]").toInt();
    }
    
    readHeaderNumberFull( Number, lst );
    
    D=readDataDinM( lst, index, Number);
    C=readDataIntCinM( lst, index, Number);
    lambda=readLambda( lst, index, Number);
    thickness=readThickness( lst, index, Number);
    beamSize=readCA(lst, index, Number)+"|"+readSA( lst, index, Number);
    
    // check CD conditions
    int Ncond, iC;
    int iMax=tableECnew->numCols();
    
    Ncond=-1;
    
    for(iC=iMax-1; iC>=0;iC--)
    {
        bool condLambda=lambda>(0.95*tableECnew->text(dptWL, iC).toDouble() ) &&
        lambda<(1.05*tableECnew->text(dptWL,iC).toDouble() );
        
        bool condD=D>(0.95*tableECnew->text(dptD,iC).toDouble()) &&
        D<(1.05*tableECnew->text(dptD,iC).toDouble());
        
        bool condC=(C==tableECnew->text(dptC,iC).toInt());
        
        bool condBeamSize = (beamSize==tableECnew->text(dptBSIZE,iC));
        
        bool condSample=compareSamplePositions( Number, tableECnew->text(dptEC,iC) );
        
        bool attenuatorCompare=compareAttenuators( Number, tableECnew->text(dptEC,iC) );
        
        bool beamPosCompare=compareBeamPosition( Number, tableECnew->text(dptEC,iC) );
        
        bool polarizationCompare=comparePolarization( Number, tableECnew->text(dptEC,iC) );
        
        
        if (condC && condD && condLambda && condSample && condBeamSize && attenuatorCompare && beamPosCompare && polarizationCompare)
        {
            Ncond=iC;
            break;
        }
    }
    
    QString colName="C"+QString::number(Ncond+1)+"-"+readInfo( lst, index, Number);
    colName=colName.simplifyWhiteSpace();
    colName=colName.replace(" ", "-").replace("/", "-").replace("_", "-").replace(",", "-").replace(".", "-").remove("%").remove("(").remove(")");
    
    
    if (Ncond>=0 || (iMax == 1 && tableECnew->text(0,0)=="")) return colName;
    
    return "";
}
