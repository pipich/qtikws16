#include "dan16.h"



//+++
QString dan16::readNumberString(QString Number, QString &pos, QString &num)
{
    
    //++++++++++++++++++++++++++++++++++++
    //+++ "" +++++++++++++++++++++++++++++++
    //++++++++++++++++++++++++++++++++++++
    if ( pos=="" ) { pos="0"; num="0";    return "---";} // not defined
    
    //++++++++++++++++++++++++++++++++++++
    //+++ "const" +++++++++++++++++++++++++++++
    //++++++++++++++++++++++++++++++++++++
    if ( pos.contains("const") )
    {
        pos="0";
        return num;
    }
    
    if (comboBoxHeaderFormat->currentItem()==2) return readYAMLentry(Number, pos, num);
    
    if (comboBoxHeaderFormat->currentItem()==1) return readXMLentry(Number, pos);
    
    QString line="";
    
    //++++++++++++++++++++++++++++++++++++
    //+++ "{Flexi Position }" ++++++++++++++++++++++
    //++++++++++++++++++++++++++++++++++++
    if ( pos.contains("{") && pos.contains("}"))
    {
        
        pos=pos.stripWhiteSpace();
        int shiftLine=0;
        
        if (pos.contains("-{"))
        {
            shiftLine--;
            pos=pos.remove("-{");
        }
        if (pos.contains("}+"))
        {
            shiftLine++;
            pos=pos.remove("}+");
        }
        
        
        pos=pos.remove("{").remove("}");
        int posLength=pos.length();
        
        pos=QString::number(readHeaderLineFlexi( Number, pos, line, shiftLine ));
        
        //--- string range ---
        if (num.contains("-"))
        {
            QString sss= line.mid(num.left(num.find("-")).toInt()-1, num.right(num.length()-num.find("-")-1).toInt());
            num=QString::number(num.left (num.find("-")).toInt()+posLength);
            return sss;
        }
        
        //--- separator & position
        if (num.contains("s"))
        {
            QString sep=num.mid(1,1);
            num=num.right(num.length()-2);
            if (num.toInt()>0)
            {
                QString sss=findStringInHeader( line, num.toInt(), sep, num );
                num=QString::number(num.toInt()+posLength);
                return sss;
                
            }
            return "---";
        }
        
        //--- just number position
        QString sss=findNumberInHeader( line, num.toInt(), num);
        num=QString::number(num.toInt()+posLength);
        return sss;
    }
    
    
    int index=0;
    
    //++++++++++++++++++++++++++++++++++++
    //+++ "{Standard reader}" +++++++++++++++++++++
    //++++++++++++++++++++++++++++++++++++
    if (pos.left(1) == "["  && pos.right(1) == "]")
    {
        if (Number.contains("["))
        {
            index=Number.right(Number.length()-Number.find("[")).remove("[").remove("]").toInt();
        }
        pos=pos.remove("[").remove("]");
        index+=pos.toInt();
    }
    else index=pos.toInt();
    
    if (index>0 )
    {
        readHeaderLine( Number, index, line );
        
        if (num.contains("-"))
        {
            QString sss= line.mid(num.left(num.find("-")).toInt()-1, num.right(num.length()-num.find("-")-1).toInt());
            num=num.left(num.find("-")).toInt();
            return sss;
        }
        
        if (num.contains("s"))
        {
            QString sep=num.mid(1,1);
            num=num.right(num.length()-2);
            if (num.toInt()>0)
                return findStringInHeader( line, num.toInt(), sep, num );
            return "---";
        }
        
        return findNumberInHeader( line, num.toInt(), num );
    }
    
    pos="0";
    num="0";
    return "---";
}


//+++
double dan16::readNumberDouble(QString Number, QString pos, QString num)
{
    return readNumberString( Number, pos, num).simplifyWhiteSpace().toDouble();
}


//+++ read f from DAT-files:: Dead Time Correction
double dan16::readDataDeadTime( QString Number )
{
    double deadTime=lineEditDeadTime->text().toDouble();
    
    return deadTimeFaktor( readSum( Number ) / readDuration( Number ), deadTime);
}


//+++ read f from DAT-files:: Dead Time Correction :: DB
double dan16::readDataDeadTimeDB( QString Number )
{
    double deadTime=lineEditDBdeadtime->text().toDouble();
    
    return deadTimeFaktor( readSum( Number ) / readDuration( Number ), deadTime);
}



//+++++FUNCTIONS::Read-DAT-files:: Normalization
double dan16::readDataNormalization( QString Number )
{
    double normConstant=spinBoxNorm->value();
    if ( comboBoxNorm->currentText()=="Monitor2")
    {
        double M2=readMonitor2( Number );
        if (M2>0.0) return normConstant/M2;
    }
    
    if ( comboBoxNorm->currentText()=="Monitor1")
    {
        double M1=readMonitor1( Number );
        if (M1>0.0) return normConstant/M1;
    }
    
    if ( comboBoxNorm->currentText()=="Time")
    {
        double time=readDuration( Number );
        if (time>0.0) return normConstant/time;
    }
    
    //+++
    toResLogAll("DAN",Number+"---> check normalization!",this);
    
    return 0.0;
}



//++++FUNCTIONS::Read-DAT-files:: Normalization
double dan16::readDataNormalizationRT( QString Number )
{
    double timeFactor=readTimefactor( Number );
    if(timeFactor==1.0) return 1.0;
    
    int numberRepetitions= readNumberRepetitions( Number );
    
    return timeFactor/numberRepetitions;
}


//+++++FUNCTIONS::Read-DAT-files:: S3norm
double dan16::readDataM3norm( QString Number )
{
    double norm 	=readDataNormalization( Number );
    double M3 	=readMonitor3( Number );
    
    return M3*norm;
}


//+++
QString dan16::readNumber(QStringList lst, QString &pos, QString &num, int index, QString Number) // [sec]
{
    if (pos.contains("["))
    {
        pos=QString::number(pos.remove("[").remove("]").toInt()+index);
    }
    
    //++++++++++++++++++++++++++++++++++++
    //+++ "" +++++++++++++++++++++++++++++++
    //++++++++++++++++++++++++++++++++++++
    if ( pos=="" ) pos="0"; // not defined
    
    //++++++++++++++++++++++++++++++++++++
    //+++ "const" +++++++++++++++++++++++++++++
    //++++++++++++++++++++++++++++++++++++
    if ( pos.contains("const") ) return num;
    
    if (comboBoxHeaderFormat->currentItem()==2) return readYAMLentry(Number, pos, num);
    
    if (comboBoxHeaderFormat->currentItem()==1) return readXMLentry(Number, pos);
    
    QString line="";
    
    //++++++++++++++++++++++++++++++++++++
    //+++ "{Flexi Position }" ++++++++++++++++++++++
    //++++++++++++++++++++++++++++++++++++
    if ( pos.contains("{") && pos.contains("}"))
    {
        int shiftLine=0;
        
        if (pos.contains("-{"))
        {
            shiftLine--;
            pos=pos.remove("-{");
        }
        if (pos.contains("}+"))
        {
            shiftLine++;
            pos=pos.remove("}+");
        }
        
        pos=pos.remove("{").remove("}");
        readHeaderLineFlexi( Number, pos, line,shiftLine );
        //--- string range ---
        if (num.contains("-"))
        {
            return line.mid(num.left(num.find("-")).toInt()-1, num.right(num.length()-num.find("-")-1).toInt());
        }
        
        //--- separator & position
        if (num.contains("s"))
        {
            QString sep=num.mid(1,1);
            num=num.right(num.length()-2);
            if (num.toInt()>0)
                return findStringInHeader( line, num.toInt(), sep, num );
            return "";
        }
        
        //--- just number position
        return findNumberInHeader( line, num.toInt(), num );
    }
    
    
    
    
    //++++++++++++++++++++++++++++++++++++
    //+++ "{Standard reader}" +++++++++++++++++++++
    //++++++++++++++++++++++++++++++++++++
    
    
    if (pos.toInt()>0)
    {
        QString line=lst[pos.toInt() - 1];
        
        if (num.contains("-"))
        {
            return line.mid(num.left(num.find("-")).toInt()-1, num.right(num.length()-num.find("-")-1).toInt());
        }
        
        if (num.contains("s"))
        {
            QString sep=num.mid(1,1);
            num=num.right(num.length()-2);
            if (num.toInt()>0)
                return findStringInHeader( line, num.toInt(), sep, num);
            return "";
        }
        
        if (num.toInt()>0)
            return findNumberInHeader( line, num.toInt(), num );
    }
    
    return "---";
}


//+++ Sample Number
QString dan16::readInfo( QString Number ) // [sec]
{
    int indexInHeader=listOfHeaders.findIndex("[Sample-Title]");
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumberString( Number, pos, num);
}


//+++ Sample Number
QString dan16::readInfo( QStringList lst, int index, QString Number ) // [sec]
{
    int indexInHeader=listOfHeaders.findIndex("[Sample-Title]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number);
}


//+++ Run Number
QString dan16::readRun( QStringList lst, int index, QString Number ) // [sec]
{
    int indexInHeader=listOfHeaders.findIndex("[Sample-Run-Number]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number);
}


//+++ read from DAT-file:: D=D   [M]
int dan16::readDataIntC( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[C]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double C=readNumberDouble( Number, pos, num);
    
    if (comboBoxUnitsCandD->currentText()=="m") C*=100.0;
    if (comboBoxUnitsCandD->currentText()=="mm") C/=10.0;
    
    return int(C);
}


//+++ read from DAT-file::C=C   [cm]
int dan16::readDataIntC(QStringList lst, int index, QString Number)
{
    int indexInHeader=listOfHeaders.findIndex("[C]");
    double C=0.0;
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    C=readNumber( lst, pos, num, index, Number).toDouble();
    
    if (comboBoxUnitsCandD->currentText()=="m") C*=100.0;
    if (comboBoxUnitsCandD->currentText()=="mm") C/=10.0;
    
    return int(C);
}


int dan16::readDataIntCinM( QString Number )
{
    
    int res=readDataIntC( Number );
    if (comboBoxUnitsCandD->currentText()=="m") res/=100;
    if (comboBoxUnitsCandD->currentText()=="mm") res*=10;
    
    return res;
}


int dan16::readDataIntCinM(QStringList lst, int index, QString Number)
{
    int res=readDataIntC( lst, index, Number );
    
    if (comboBoxUnitsCandD->currentText()=="m") res/=100;
    if (comboBoxUnitsCandD->currentText()=="mm") res*=10;
    
    return res;
}


//+++ read from DAT-file:: D=D+offset + add-Offset   [cm]
double dan16::readDataD( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[D]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double D=readNumberDouble( Number, pos, num);
    
    indexInHeader=listOfHeaders.findIndex("[C,D-Offset]");
    
    pos=tableHeaderPos->text(indexInHeader,0);
    num=tableHeaderPos->text(indexInHeader,1);
    
    D+=readNumberDouble( Number, pos, num);
    
    if (comboBoxUnitsCandD->currentText()=="m") D*=100.0;
    if (comboBoxUnitsCandD->currentText()=="mm") D/=10.0;
    
    return D;
}


//+++ read from DAT-file:: D=D+offset + add-Offset   [cm]
double dan16::readDataD(QStringList lst, int index, QString Number)
{
    double D=0.0;
    
    int indexInHeader=listOfHeaders.findIndex("[D]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    D+=readNumber( lst, pos, num, index, Number ).toDouble();
    
    indexInHeader=listOfHeaders.findIndex("[C,D-Offset]");
    
    pos=tableHeaderPos->text(indexInHeader,0);
    num=tableHeaderPos->text(indexInHeader,1);
    
    D+=readNumber( lst, pos, num, index, Number ).toDouble();
    
    
    if (comboBoxUnitsCandD->currentText()=="m") D*=100.0;
    if (comboBoxUnitsCandD->currentText()=="mm") D/=10.0;
    
    return D;
}



//+++ read from DAT-file:: D=D+offset + add-Offset   [M]
double dan16::readDataDinM( QString Number )
{
    return readDataD( Number )/100.0;
}


//+++ read from DAT-file:: D=D+offset + add-Offset   [M]
double dan16::readDataDinM(QStringList lst, int index, QString Number)
{
    return readDataD(lst, index, Number)/100.0;
}


//+++ read  R1 source aperture [CA-X] x [CA-X]
double dan16::readDataR1( QString Number )
{
    double r1=0.0;
    
    int indexInHeader=listOfHeaders.findIndex("[CA-X]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    r1=readNumberDouble( Number, pos, num);
    indexInHeader=listOfHeaders.findIndex("[CA-Y]");
    
    pos=tableHeaderPos->text(indexInHeader,0);
    num=tableHeaderPos->text(indexInHeader,1);
    
    r1*=readNumberDouble( Number, pos, num);
    
    if (comboBoxUnitsBlends->currentItem()==1) r1*=0.01;
    if (comboBoxUnitsBlends->currentItem()==2) r1*=1e-8;
    
    if (checkBoxResoCAround->isChecked()) return sqrt(r1/4);
    
    return sqrt(r1/M_PI);
}


//+++ read  R1 source aperture [CA-X] x [CA-X]
double dan16::readDataR1( QStringList lst , int index, QString Number)
{
    double r1=0.0;
    int indexInHeader=listOfHeaders.findIndex("[CA-X]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    r1=readNumber( lst, pos, num, index, Number ).toDouble();
    indexInHeader=listOfHeaders.findIndex("[CA-Y]");
    
    pos=tableHeaderPos->text(indexInHeader,0);
    num=tableHeaderPos->text(indexInHeader,1);
    
    r1*=readNumber( lst, pos, num, index, Number ).toDouble();
    
    if (comboBoxUnitsBlends->currentItem()==1) r1*=0.01;
    if (comboBoxUnitsBlends->currentItem()==2) r1*=1e-8;
    
    if (checkBoxResoCAround->isChecked()) return sqrt(r1/4);
    
    return sqrt(r1/M_PI);
}


//+++ read  R2 source aperture [SA-X] x [SA-X]
double dan16::readDataR2( QString Number )
{
    double r2=0.0;
    int indexInHeader=listOfHeaders.findIndex("[SA-X]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    r2=readNumberDouble( Number, pos, num);
    indexInHeader=listOfHeaders.findIndex("[SA-Y]");
    
    pos=tableHeaderPos->text(indexInHeader,0);
    num=tableHeaderPos->text(indexInHeader,1);
    
    r2*=readNumberDouble( Number, pos, num);
    
    if (comboBoxUnitsBlends->currentItem()==1) r2*=0.01;
    if (comboBoxUnitsBlends->currentItem()==2) r2*=1e-8;
    
    if (checkBoxResoSAround->isChecked()) return sqrt(r2/4);
    
    return sqrt(r2/M_PI);
}



//+++ read  R2 SAMPLE aperture [SA-X] x [SA-X]
double dan16::readDataR2( QStringList lst, int index, QString Number)
{
    double r2=0.0;
    int indexInHeader=listOfHeaders.findIndex("[SA-X]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    r2=readNumber( lst, pos, num, index, Number ).toDouble();
    indexInHeader=listOfHeaders.findIndex("[SA-Y]");
    
    pos=tableHeaderPos->text(indexInHeader,0);
    num=tableHeaderPos->text(indexInHeader,1);
    
    r2*=readNumber( lst, pos, num, index, Number ).toDouble();
    
    if (comboBoxUnitsBlends->currentItem()==1) r2*=0.01;
    if (comboBoxUnitsBlends->currentItem()==2) r2*=1e-8;
    
    if (checkBoxResoSAround->isChecked()) return sqrt(r2/4);
    
    return sqrt(r2/M_PI);
}


//+++ read  CA
QString dan16::readCA( QString Number )
{
    QString CA;
    double temp;
    int indexInHeader=listOfHeaders.findIndex("[CA-X]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    
    CA=QString::number(readNumberDouble( Number, pos, num), 'f',1);
    CA+="x";
    
    indexInHeader=listOfHeaders.findIndex("[CA-Y]");
    pos=tableHeaderPos->text(indexInHeader,0);
    num=tableHeaderPos->text(indexInHeader,1);
    
    CA+=QString::number(readNumberDouble( Number, pos, num), 'f',1);
    return CA.remove(".0");
}


//+++ read  CA
QString dan16::readCA(QStringList lst, int index, QString Number)
{
    QString CA;
    double temp;
    int indexInHeader=listOfHeaders.findIndex("[CA-X]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    temp=readNumber( lst, pos, num, index, Number ).toDouble();
    
    if (temp<=0.0) return "x";
    
    CA=QString::number(temp,'f',1);
    CA+="x";
    indexInHeader=listOfHeaders.findIndex("[CA-Y]");
    
    pos=tableHeaderPos->text(indexInHeader,0);
    num=tableHeaderPos->text(indexInHeader,1);
    
    temp=readNumber( lst, pos, num, index, Number ).toDouble();
    
    if (temp<=0.0) return "x";
    
    CA+=QString::number(temp,'f',1);
    
    return CA.remove(".0");
}


//+++ read  SA
QString dan16::readSA( QString Number )
{
    QString SA;
    double temp;
    int indexInHeader=listOfHeaders.findIndex("[SA-X]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    SA=QString::number(readNumberDouble( Number, pos, num), 'f',1);
    SA+="x";
    indexInHeader=listOfHeaders.findIndex("[SA-Y]");
    
    pos=tableHeaderPos->text(indexInHeader,0);
    num=tableHeaderPos->text(indexInHeader,1);
    
    SA+=QString::number(readNumberDouble( Number, pos, num), 'f',1);
    return SA.remove(".0");
}


//+++ read  SA
QString dan16::readSA(QStringList lst, int index, QString Number )
{
    QString SA;
    double temp;
    int indexInHeader=listOfHeaders.findIndex("[SA-X]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    temp=readNumber( lst, pos, num, index, Number ).toDouble();
    
    SA=QString::number(temp,'f',1);
    SA+="x";
    indexInHeader=listOfHeaders.findIndex("[SA-Y]");
    
    pos=tableHeaderPos->text(indexInHeader,0);
    num=tableHeaderPos->text(indexInHeader,1);
    
    temp=readNumber( lst, pos, num, index, Number ).toDouble();
    
    SA+=QString::number(temp,'f',1);
    
    return SA.remove(".0");
}


//+++ read Lambda
double dan16::readLambda( QString Number )
{
    double lambda;
    int indexInHeader=listOfHeaders.findIndex("[Lambda]");
    
    if (radioButtonLambdaHeader->isChecked())
    {
        QString pos=tableHeaderPos->text(indexInHeader,0);
        QString num=tableHeaderPos->text(indexInHeader,1);
        
        lambda = readNumberDouble( Number, pos, num );
    }
    else
    {
        
        double f=readDataF( Number );
        if (f<=0.0) return 0.0;
        
        //+++
        double para1=lineEditSel1->text().toDouble();
        double para2=lineEditSel2->text().toDouble();
        //+++
        lambda = para1/f+para2;
    }
    if (comboBoxUnitsLambda->currentItem()==1) lambda*=10.0;
    
    return lambda;
}


//+++ read Lambda
double dan16::readLambda(QStringList lst, int index, QString Number )
{
    double lambda;
    int indexInHeader=listOfHeaders.findIndex("[Lambda]");
    
    if (radioButtonLambdaHeader->isChecked())
    {
        QString pos=tableHeaderPos->text(indexInHeader,0);
        QString num=tableHeaderPos->text(indexInHeader,1);
        
        lambda = readNumber( lst, pos, num, index, Number ).toDouble();
    }
    else
    {
        
        double f=readDataF( lst, index, Number );
        if (f<=0.0) return 0.0;
        
        //+++
        double para1=lineEditSel1->text().toDouble();
        double para2=lineEditSel2->text().toDouble();
        //+++
        lambda = para1/f+para2;
    }
    if (comboBoxUnitsLambda->currentItem()==1) lambda*=10.0;
    
    return lambda;
}


//+++ read :: [Sum]
double dan16::readSum( QString Number)
{
    int indexInHeader=listOfHeaders.findIndex("[Sum]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumberDouble( Number, pos, num );
}


//+++ read :: [Sum]
double dan16::readSum(QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Sum]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number ).toDouble();
}


//+++ read duration
double dan16::readDuration( QString Number ) // [sec]
{
    int indexInHeader=listOfHeaders.findIndex("[Duration]");
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double duration=readNumberDouble( Number, pos, num );
    
    if (comboBoxUnitsTime->currentItem()==1) duration/=10.0;
    if (comboBoxUnitsTime->currentItem()==2) duration/=1000.0;
    if (comboBoxUnitsTime->currentItem()==3) duration/=1000000.0;
    
    return duration;
}


//+++ read duration
double dan16::readDuration( QStringList lst, int index, QString Number ) // [sec]
{
    int indexInHeader=listOfHeaders.findIndex("[Duration]");
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double duration=readNumber( lst, pos, num, index, Number ).simplifyWhiteSpace().toDouble();
    
    if (comboBoxUnitsTime->currentItem()==1) duration/=10.0;
    if (comboBoxUnitsTime->currentItem()==2) duration/=1000.0;
    if (comboBoxUnitsTime->currentItem()==3) duration/=1000000.0;
    
    return duration;
}


//+++ Sample Number
QString dan16::readSampleNumber( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Sample-Position-Number]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumberString( Number, pos, num );
}


//+++ Sample Number
QString dan16::readSampleNumber( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Sample-Position-Number]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    QString fnum = readNumber( lst, pos, num, index, Number );
    if (fnum=="") return "-";
    return fnum;
}


//+++ read  Thickness
double dan16::readThickness( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Sample-Thickness]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double thickness=readNumberDouble( Number, pos, num );
    
    if (comboBoxThicknessUnits->currentText()=="mm") thickness/=10.0;
    
    return thickness;
}


//+++ read  Thickness
double dan16::readThickness(QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Sample-Thickness]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double thickness=readNumber( lst, pos, num, index, Number ).toDouble();
    
    if (comboBoxThicknessUnits->currentText()=="mm") thickness/=10.0;
    
    return thickness;
}


//+++ read Selector
double dan16::readDataSelector( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Selector]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double selector=readNumberDouble( Number, pos, num );
    
    return selector;
}


//+++ read f
double dan16::readDataF( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Selector]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double f=readNumberDouble( Number, pos, num );
    
    double duration=1.0;
    
    if (comboBoxUnitsSelector->currentItem()==0) duration=readDuration( Number );
    else if (comboBoxUnitsSelector->currentItem()==2) duration=60.0;
    
    if (duration<=0.0) return 0.0;
    
    return f/duration;
}


//+++ read f
double dan16::readDataF(QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Selector]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double f=readNumber( lst, pos, num, index, Number ).toDouble();
    
    double duration=1.0;
    
    if (comboBoxUnitsSelector->currentItem()==0) duration=readDuration(lst, index, Number);
    else if (comboBoxUnitsSelector->currentItem()==2) duration=60.0;
    
    
    if (duration<=0.0) return 0.0;
    
    return f/duration;
}



//+++ read  Monito1
double dan16::readMonitor1( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Monitor-1]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumberDouble( Number, pos, num );
}


//+++ read  Monito1
double dan16::readMonitor1( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Monitor-1]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number ).toDouble();
}


//+++ read  Monito2
double dan16::readMonitor2( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Monitor-2]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumberDouble( Number, pos, num );
}


//+++ read  Monito2
double dan16::readMonitor2( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Monitor-2]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number ).toDouble();
}


//+++ read  Monito3
double dan16::readMonitor3( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Monitor-3|Tr|ROI]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumberDouble( Number, pos, num );
}


//+++ read  Monito3
double dan16::readMonitor3( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Monitor-3|Tr|ROI]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number ).toDouble();
}


//+++ Timefactor
int dan16::readRtCurrentNumber( QString Number ) // [1]
{
    QString line="";
    int indexInHeader=listOfHeaders.findIndex("[RT-Current-Number]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    int currentNumber=int(readNumberDouble( Number, pos, num ));
    
    if (currentNumber<1) currentNumber=1;
    
    return currentNumber;
}


//+++ read  readTimefactor
int dan16::readRtCurrentNumber( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[RT-Current-Number]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    int currentNumber=int(readNumber( lst, pos, num, index, Number ).toDouble());
    
    if (currentNumber<1) currentNumber=1;
    
    return currentNumber;
}


//+++ Timefactor
double dan16::readTimefactor( QString Number ) // [1]
{
    QString line="";
    int indexInHeader=listOfHeaders.findIndex("[RT-Time-Factor]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double readTimefactor=readNumberDouble( Number, pos, num );
    
    if (readTimefactor<=0) readTimefactor=1.0;
    
    return readTimefactor;
}


//+++ read  readTimefactor
double dan16::readTimefactor( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[RT-Time-Factor]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double readTimefactor=readNumber( lst, pos, num, index, Number ).toDouble();
    
    if (readTimefactor<=0) readTimefactor=1.0;
    
    return readTimefactor;
}


//+++ Timefactor numberRepetitions
int dan16::readNumberRepetitions( QString Number ) // [1]
{
    int indexInHeader=listOfHeaders.findIndex("[RT-Number-Repetitions]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    int numberRepetitions= readNumberString( Number, pos, num ).toInt();
    if (numberRepetitions<1) numberRepetitions=1;
    
    return numberRepetitions;
}


//+++ read  readNumberRepetitions
int dan16::readNumberRepetitions( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[RT-Number-Repetitions]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    int numberRepetitions= readNumber( lst, pos, num, index, Number ).toInt();
    if (numberRepetitions<1) numberRepetitions=1;
    
    return numberRepetitions;
}


//+++ read from DAT-file:: Delta Lambda
double dan16::readDeltaLambda( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Delta-Lambda]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumberDouble( Number, pos, num );
}


//+++ read  readDeltaLambda
double dan16::readDeltaLambda( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Delta-Lambda]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number ).toDouble();
}


//+++ read  readExpName
QString dan16::readExpName( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Experiment-Title]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}


//+++ read  Who
QString dan16::readWho( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[User-Name]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}


//+++ read  Time
QString dan16::readTime( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Time]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}


//+++ read  Date
QString dan16::readDate( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Date]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}


//+++ read  Comment1
QString dan16::readComment1( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Comment1]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}


//+++ read  Comment2
QString dan16::readComment2( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Comment2]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}


//+++ read  DetectorX
QString dan16::readDetectorX( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Detector-X || Beamcenter-X]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}


//+++ read  DetectorX
double dan16::readDetectorX( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Detector-X || Beamcenter-X]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumberDouble( Number, pos, num );
}


//+++ read  DetectorY
QString dan16::readDetectorY( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Detector-Y || Beamcenter-Y]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}


//+++ read  DetectorY
double dan16::readDetectorY( QString Number)
{
    int indexInHeader=listOfHeaders.findIndex("[Detector-Y || Beamcenter-Y]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumberDouble( Number, pos, num );
}


//+++ read  Sample-Motor-1
QString dan16::readSMotor1( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Sample-Motor-1]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}


//+++ read  Sample-Motor-2
QString dan16::readSMotor2( QStringList lst, int index , QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Sample-Motor-2]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}


//+++ read  Sample-Motor-3
QString dan16::readSMotor3( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Sample-Motor-3]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}


//+++ read  Sample-Motor-4
QString dan16::readSMotor4( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Sample-Motor-4]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}


//+++ read  Sample-Motor-5
QString dan16::readSMotor5( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Sample-Motor-5]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumber( lst, pos, num, index, Number );
}

//+++ read  Attenuator
QString dan16::readAttenuator( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Attenuator]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumberString( Number, pos, num );
}


//+++ read  Polarization
QString dan16::readPolarization( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Polarization]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumberString( Number, pos, num );
}


//+++ read  Lenses
QString dan16::readLenses( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Lenses]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return readNumberString( Number, pos, num );
}



//+++ read  Slices-Count
QString dan16::readSlicesCount( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Slices-Count]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    return QString::number(readNumber( lst, pos, num, index, Number ).toDouble(),'f',0);
}


//
//+++ read  Slices-Count
int dan16::readSlicesCount( QString Number)
{
    int indexInHeader=listOfHeaders.findIndex("[Slices-Count]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    int slicesCount=int(readNumberDouble( Number, pos, num ));
    
    if (slicesCount<1) slicesCount=1;
    
    return slicesCount;
}



//+++ read  Slices-Duration
QString dan16::readSlicesDuration( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Slices-Duration]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double slicesDuration=readNumber( lst, pos, num, index, Number ).toDouble();
    
    if (comboBoxUnitsTimeRT->currentItem()==1) slicesDuration/=10.0;
    if (comboBoxUnitsTimeRT->currentItem()==2) slicesDuration/=1000.0;
    if (comboBoxUnitsTimeRT->currentItem()==3) slicesDuration/=1000000.0;
    
    return QString::number(slicesDuration);
}


//+++ read  Slices-Duration
double dan16::readSlicesDuration( QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Slices-Duration]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double slicesDuration=readNumberDouble( Number, pos, num );
    
    if (comboBoxUnitsTimeRT->currentItem()==1) slicesDuration/=10.0;
    if (comboBoxUnitsTimeRT->currentItem()==2) slicesDuration/=1000.0;
    if (comboBoxUnitsTimeRT->currentItem()==3) slicesDuration/=1000000.0;
    
    
    if (slicesDuration<0) slicesDuration=0;
    
    return slicesDuration;
}



//+++ read  Slices-Current-Number
int dan16::readSlicesCurrentNumber( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Slices-Current-Number]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    int SlicesCurrentNumber=readNumber( lst, pos, num, index, Number ).toInt();
    
    if (SlicesCurrentNumber<0) SlicesCurrentNumber=0;
    
    return SlicesCurrentNumber;
}



//+++ read  Slices-Current-Duration
double dan16::readSlicesCurrentDuration( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Slices-Current-Duration]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    
    if(num.contains("list"))
    {
        QString pos1=tableHeaderPos->text(indexInHeader,0);
        QString num1=tableHeaderPos->text(indexInHeader,1);
        
    }
    
    double SlicesCurrentDuration=readNumber( lst, pos, num, index, Number ).toDouble();
    
    
    
    
    if (comboBoxUnitsTimeRT->currentItem()==1) SlicesCurrentDuration/=10.0;
    if (comboBoxUnitsTimeRT->currentItem()==2) SlicesCurrentDuration/=1000.0;
    if (comboBoxUnitsTimeRT->currentItem()==3) SlicesCurrentDuration/=1000000.0;
    
    
    if (SlicesCurrentDuration<0) SlicesCurrentDuration=0;
    
    return SlicesCurrentDuration;
}



//+++ read  Slices-Current-Monitor1
double dan16::readSlicesCurrentMonitor1( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Slices-Current-Monitor1]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double SlicesCurrentMonitor1=readNumber( lst, pos, num, index, Number ).toDouble();
    
    
    
    if (SlicesCurrentMonitor1<0) SlicesCurrentMonitor1=0;
    
    return SlicesCurrentMonitor1;
}


//+++ read  Slices-Current-Monitor2
double dan16::readSlicesCurrentMonitor2( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Slices-Current-Monitor2]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double SlicesCurrentMonitor2=readNumber( lst, pos, num, index, Number ).toDouble();
    
    if (SlicesCurrentMonitor2<0) SlicesCurrentMonitor2=0;
    
    return SlicesCurrentMonitor2;
}


//+++ read  Slices-Current-Monitor3
double dan16::readSlicesCurrentMonitor3( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Slices-Current-Monitor3]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double SlicesCurrentMonitor3=readNumber( lst, pos, num, index, Number ).toDouble();
    
    if (SlicesCurrentMonitor3<3) SlicesCurrentMonitor3=0;
    
    return SlicesCurrentMonitor3;
}


//+++ read  Slices-Current-Sum
double dan16::readSlicesCurrentSum( QStringList lst, int index, QString Number )
{
    int indexInHeader=listOfHeaders.findIndex("[Slices-Current-Sum]");
    
    QString pos=tableHeaderPos->text(indexInHeader,0);
    QString num=tableHeaderPos->text(indexInHeader,1);
    
    double SlicesCurrentSum=readNumber( lst, pos, num, index, Number ).toDouble();
    
    if (SlicesCurrentSum<3) SlicesCurrentSum=0;
    
    return SlicesCurrentSum;
}

//+++ calculate Trans
double dan16::readTransmission( QString NumberSample, QString NumberEC, QString mask, double VShift, double HShift )
{
    if (NumberSample==NumberEC) return 1.00;
    if (!checkFileNumber( NumberSample )) return 1.00;
    if (!checkFileNumber( NumberEC ) && comboBoxTransmMethod->currentItem()!=2) return 1.00;
    
    double sample;
    double ec;
    
    // Monitor-3 [dead-time-]
    if (comboBoxTransmMethod->currentItem()==0)
    {
        sample=readDataM3norm( NumberSample );
        ec=readDataM3norm( NumberEC );
    }//Direct Beam  [dead-time+]
    else if (comboBoxTransmMethod->currentItem()==1)
    { 	
        sample=integralVSmaskUniDeadTimeCorrected( NumberSample, mask, VShift,HShift )/readDataDeadTime(NumberSample)*readDataDeadTimeDB(NumberSample);
        
        sample*=readDataNormalization( NumberSample );
        
        ec=integralVSmaskUniDeadTimeCorrected( NumberEC, mask, 0, 0 )/readDataDeadTime(NumberEC)*readDataDeadTimeDB(NumberEC);
        
        ec*=readDataNormalization( NumberEC );
        
    } //Tr in Header  [dead-time -]
    else if (comboBoxTransmMethod->currentItem()==2)
    {
        sample=readMonitor3( NumberSample );
        ec=readMonitor3( NumberEC );
        if (ec==0) ec=1;
    }//	ROI in Header  [dead-time +]
    else if (comboBoxTransmMethod->currentItem()==3)
    {
        sample= readDataM3norm( NumberSample );
        
        sample*=readDataDeadTimeDB( NumberSample );
        
        ec=readDataM3norm( NumberEC );
        
        ec*=readDataDeadTimeDB( NumberEC );
    }
    
    if (ec<=0.0) return 0.0;
    return sample/ec;
}

//*******************************************
//+++  Read Header Full Number
//*******************************************
bool dan16::readHeaderNumberFull( QString Number, QStringList &header )
{
    
    header.clear();
    if (checkBoxYes2ndHeader->isChecked()) readHeaderNumber( wildCard2nd, Number, linesInSeparateHeader, header);
    
    QStringList header1;
    readHeaderNumber( wildCard, Number, linesInHeader+linesInDataHeader, header1);
    
    header+=header1;
    
    
    return true;
}

//*******************************************
//+++  Read Header
//*******************************************
bool dan16::readHeaderNumber( QString wildCardLocal, QString Number, int linesNumber, QStringList &header )
{
    int index=0;
    if (Number.contains("[") && !wildCardLocal.contains("["))
    {
        index=Number.right(Number.length()-Number.find("[")).remove("[").remove("]").toInt();
    }
    
    return readHeaderFile( fileNameUni( wildCardLocal, Number), linesNumber+index, header );
}


bool dan16::readHeaderFile( QString fileName, int linesNumber, QStringList &header )
{
    header.clear();
    
    QFile file(fileName);
    QTextStream t( &file );
    
    
    if (!file.open(IO_ReadOnly)) return false;
    
    
    if (flexiHeader && flexiStop[0]!="")
    {
        QString s;
        int symbolsNumber;
        bool endReached=false;
        
        for (int i=0;i<linesNumber;i++)
        {
            s=t.readLine();
            
            if (removeNonePrintable)
            {
                QString ss=s; s="";
                int smax=ss.length(); if (smax>10000) smax=10000;
                for(int ii=0; ii<smax;ii++) if (ss[ii].isPrint()) s+=ss[ii];
            }
            
            header << s;
            
            for (int iFlex=0; iFlex<flexiStop.count(); iFlex++)
            {
                symbolsNumber=flexiStop[iFlex].length();
                if (s.left(symbolsNumber)==flexiStop[iFlex] || t.atEnd() )
                {
                    endReached=true;
                    break; // skip header
                }
            }
            if (endReached) break;
        }
    }
    else
    {
        QString s="";
        for (int i=0;i<linesNumber;i++)
        {
            s=t.readLine();
            
            if (removeNonePrintable)
            {
                QString ss=s; s="";
                int smax=ss.length(); if (smax>10000) smax=10000;
                for(int ii=0; ii<smax;ii++) if (ss[ii].isPrint()) s+=ss[ii];
            }
            
            
            header << s;
        }
    }
    file.close();
    
    return true;
    
}


//*******************************************
//+++  Read Header :: spetial Line
//*******************************************
bool dan16::readHeaderLine( QString runNumber, int lineNumber, QString &str )
{
    QString wildCardInUse;
    
    int index=0;
    
    if (runNumber.contains("["))
    {
        index=runNumber.right(runNumber.length()-runNumber.find("[")).remove("[").remove("]").toInt();
    }
    
    
    
    if (lineNumber<=(linesInSeparateHeader+index))
    {
        wildCardInUse=wildCard2nd;
    }
    else
    {
        lineNumber-=linesInSeparateHeader;
        wildCardInUse=wildCard;
    }
    
    
    return readHeaderLineFull(fileNameUni(wildCardInUse, runNumber), lineNumber, str );
}


//*******************************************
//+++  Read Header :: spetial Line
//*******************************************
int dan16::readHeaderLineFlexi( QString runNumber, QString pos, QString &str, int shift )
{
    QString wildCardInUse;
    
    if (separateHeaderYes)
    {
        wildCardInUse=wildCard2nd;
        str=pos;
        return readHeaderLineFullIntuitive( fileNameUni(wildCardInUse, runNumber), linesInSeparateHeader, str, shift);
    }
    
    wildCardInUse=wildCard;
    str=pos;
    
    return readHeaderLineFullIntuitive( fileNameUni(wildCardInUse, runNumber), linesInHeader+linesInDataHeader, str, shift);
}


bool dan16::readHeaderLineFull( QString fileName, int linesNumber, QString &str )
{
    QFile file(fileName);
    QTextStream t( &file );
    
    
    if (!file.open(IO_ReadOnly)) return false;
    //+++
    for(int skip=0; skip<linesNumber; skip++) str = t.readLine();
    
    file.close();
    
    return true;
    
}


int dan16::readHeaderLineFullIntuitive( QString fileName, int maxLinesNumber, QString &str, int shift )
{
    QString whatToFind=str;
    if (str=="") return 0;
    
    QFile file(fileName);
    QTextStream t( &file );
    
    
    if (!file.open(IO_ReadOnly)) return false;
    //+++
    int skip=0;
    QString s="";
    
    int position;
    QString lineMinus;
    
    while ( skip < maxLinesNumber )
    {
        lineMinus=s;
        s = t.readLine();
        skip++;
        
        if(s.contains(str))
        {
            
            position = s.find(str);
            QString sss=s.mid(position-1,1);
            
            if (position > 0 && sss!=" " && sss!="," && sss!=";") continue;
            
            if (shift==1)  {str=t.readLine(); file.close(); return skip+1;};
            if (shift==-1) {str=lineMinus; file.close(); return skip-1;};
            
            s=s.right(s.length() - position - str.length());
            str=s;
            
            
            return skip;
            
        }
    }
    
    file.close();
    
    
    
    if (s.contains(str))
    {
        str=s.right(s.length()-s.find(str)-str.length());
    }
    else return 0;
    
    
    return skip;
}

//*******************************************
//+++  Compare Two Headers for Merging
//*******************************************
bool dan16::compareTwoHeadersBeforeMerging(QStringList header1, QStringList header2, int &line )
{
    
    line=-1;
    if (header1.size()!=header2.size() ) return false;
    line=20;
    if (header1[20] != header2[20] ) return false;
    line=27;
    if (header1[27] != header2[27] ) return false;
    line=20;
    if (header1[20] != header2[20] ) return false;
    
    line =-1;
    return true;
}

//*******************************************
//+++  extract and convert real time
//*******************************************
double dan16::extractTime(QString timeStr, QString str)
{
    timeStr=timeStr.stripWhiteSpace();
    double time=timeStr.left(timeStr.find(" ")).toInt();
    QString strAct=timeStr.right(timeStr.length()-timeStr.find(" ")-1).stripWhiteSpace();
    if (str!=strAct)
    {
        if ( str== "usec")
        {
            if ( strAct== "msec")    time*=1000.0;
            else if (strAct== "sec") time*=1000000.0;
            else if (strAct== "min") time*=60000000.0;
            else if (strAct== "h")   time*=3600000000.0;
        }
        else if (str=="msec")
        {
            if (strAct== "sec")      time*=1000.0;
            else if (strAct== "min") time*=60000.0;
            else if (strAct== "h")   time*=3600000.0;
        }
        else if (str=="sec")
        {
            if (strAct== strAct )
            {
                if (strAct== "min")    time*=60.0;
                else if (strAct== "h") time*=3600.0;
            }
        }
        else if (str== "min" && strAct== "h") time*=60.0;
    }
    return time;
}

int dan16::lengthMainHeader(QString fileName)
{
    
    if (!flexiHeader || flexiStop[0]=="") return spinBoxHeaderNumberLines->value();
    
    
    QFile file( fileName );
    QTextStream t( &file );
    
    if (!file.open(IO_ReadOnly) ) return spinBoxHeaderNumberLines->value();
    
    int res=0;
    
    QString sTmp;
    int symbolsNumber;
    bool endReached=false;
    
    for (int i=0;i<spinBoxHeaderNumberLines->value();i++)
    {
        sTmp=t.readLine(); res++;
        
        for (int iFlex=0; iFlex<flexiStop.count(); iFlex++)
        {
            symbolsNumber=flexiStop[iFlex].length();
            if (sTmp.left(symbolsNumber)==flexiStop[iFlex] || t.atEnd() )
            {
                endReached=true;
                break; // skip header
            }
        }
        if (endReached) break;
    }
    
    file.close();
    return res;
}

//+++
QString dan16::findNumberInHeader(QString line, int digitNumber, QString &num)
{
    QString result;
    int posInline=0; num="0";
    int pos=0;
    int currentNumber=0;
    QRegExp rx("((\\-|\\+)?\\d\\d*(\\.\\d*)?((E\\-|E\\+)\\d\\d?\\d?\\d?)?)");
    
    line=line.stripWhiteSpace();
    line.replace(",",".");
    line.replace("e","E");
    line.replace("E","E0");
    line.replace("E0+","E+0");
    line.replace("E0-","E-0");
    line.replace("E0","E+0");
    line.replace("E+00","E+0");
    line.replace("E-00","E-0");
    
    
    while ( pos >= 0 && currentNumber<digitNumber)
    {
        pos = rx.search( line, pos );
        if ( pos <0 ) return "";
        posInline=pos;
        
        result=rx.cap( 1 );
        
        if ( ( pos==0 || line[pos-1]==' ' || line[pos-1]=='\t') && ( line[pos+rx.matchedLength()]==' ' || line[pos+rx.matchedLength()]=='\t' ||  pos+rx.matchedLength() == line.length())) currentNumber++;
        
        pos  += rx.matchedLength();
    }
    
    //    result.replace("E+0","E+");
    posInline++;
    num=QString::number(posInline);
    return result;
}


//+++
QString dan16::findStringInHeader(QString line, int digitNumber, QString sep, QString &num)
{
    QStringList lst;
    
    lst=lst.split(sep, line.stripWhiteSpace());
    
    if (digitNumber==0) num="0";
    else
    {
        
        int sum=1;
        for (int i=0; i<digitNumber-1;i++) sum+=lst[i].length()+1;
        num=QString::number(sum);
    }
    
    if ( digitNumber<=lst.count() ) return lst[digitNumber-1];
    
    return "";
}

QString dan16::readYAMLentry(QString runNumber, QString yamlCode, QString num)
{
    QString res = readYAMLentry(runNumber, yamlCode);
    
    //--- string range ---
    if (num.contains("-"))
    {
        return res.mid(num.left(num.find("-")).toInt()-1, num.right(num.length()-num.find("-")-1).toInt());
    }
    
    //--- separator & position
    if (num.contains("[s"))
    {
        num=num.remove("[").remove("]");
        res=res.mid(res.find("[")+1, res.find("]")-res.find("[")-1);
        
        QString sep=num.mid(1,1);
        num=num.right(num.length()-2);
        if (num.toInt()>0)
            return findStringInHeader( res, num.toInt(), sep, num );
        return "";
    }
    
    //--- separator & position
    if (num.contains("(s"))
    {
        num=num.remove("(").remove(")");
        res=res.mid(res.find("(")+1, res.find(")")-res.find("(")-1);
        QString sep=num.mid(1,1);
        
        num=num.right(num.length()-2);
        if (num.toInt()>0)
            return findStringInHeader( res, num.toInt(), sep, num );
        return "";
    }
    
    //--- separator & position
    if (num.contains("{s"))
    {
        num=num.remove("{").remove("}");
        res=res.mid(res.find("{")+1, res.find("}")-res.find("{")-1);
        QString sep=num.mid(1,1);
        num=num.right(num.length()-2);
        if (num.toInt()>0)
            return findStringInHeader( res, num.toInt(), sep, num );
        return "";
    }
    
    //--- separator & position
    if (num.contains("s"))
    {
        QString sep=num.mid(1,1);
        num=num.right(num.length()-2);
        if (num.toInt()>0)
            return findStringInHeader( res, num.toInt(), sep, num );
        return "";
    }
    
    
    return res;
    
}




QString dan16::readYAMLentry(QString runNumber, QString yamlCode)
{
    // +++
    if (!separateHeaderYes) return "-1";
    // +++
    yamlCode=yamlCode.remove(" ");
    yamlCode=yamlCode.replace("::",":");
    yamlCode=yamlCode.replace("::",":");
    // +++
    QStringList lst=lst.split(":",yamlCode);
    
    // +++
    int countLevels=lst.count();
    
    // +++
    if (countLevels>4) return "-4";
    
    // +++
    std::ifstream fin(fileNameUni(wildCard2nd, runNumber).ascii());
    
    // +++
    try {
        
        YAML::Parser parser(fin);
        YAML::Node doc;

        // +++
        while(parser.GetNextDocument(doc) )
        {
            // first level
            std::string key, value;
            
            for(YAML::Iterator it=doc.begin();it!=doc.end();++it)
            {
                key=""; value="";
                it.first() >> key;
                
                if ( key!=lst[0].ascii() ) continue;
                
                if (countLevels==1)
                {
                    it.second()>>value;
                    return value.c_str();
                }
              
                // second level
                std::string key2, value2;
                
                for(YAML::Iterator it2=it.second().begin();it2!=it.second().end();++it2)
                {
                    key2=""; value2="";
                    it2.first() >> key2;
                    
                    if ( key2!=lst[1].ascii()) continue;
                    
                    if (countLevels==2)
                    {
                        it2.second()>>value2;
                        return value2.c_str();
                    }
                    
                    
                    // third level
                    std::string key3, value3;

                    
                    if (it2.second().Type() == YAML::NodeType::Sequence)
                    {
                        bool foundYN=false;
                        std::string key3a, value3a;
                        std::string tvalue;
                        QStringList sLst=sLst.split("|",lst[2]);

                        
                        if (countLevels>3) return "limit-3-levels";

                        if (sLst.size()==1)
                        {
                            for(unsigned int i = 0 ; i < it2.second().size() ; i++)
                            {
                                it2.second()[i].begin().first() >> key3a;
                                it2.second()[i].begin().second() >> key3;
                               
                                if ( key3a == sLst[0].ascii()) return key3.c_str();
                            }
                               return "not-found";
                        }
                        else
                        {
                           for(unsigned int i = 0 ; i < it2.second().size() ; i++)
                           {
                                tvalue="";
                               for(YAML::Iterator it3=it2.second()[i].begin();it3!=it2.second()[i].end();++it3)
                               {
                                   key3a="";
                                   key3="";

                                   if (it3.second().Type() == YAML::NodeType::Sequence)
                                   {
                                       it3.first() >> key3a;
                                       if ( key3a != sLst[2].ascii()) continue;
                                       if (it3.second()[0].Type()!= YAML::NodeType::Scalar) continue;
                                       
                                       for(unsigned int i = 0 ; i < it3.second().size() ; i++)
                                       {
                                           it3.second()[i]>>key3;
                                           tvalue+=key3+"; ";
                                       }
                                       continue;
                                   }
                                       
                                   if (it3.second().Type() != YAML::NodeType::Scalar) continue;
                                   it3.first() >> key3a;
                                   it3.second() >> key3;
                                   
                                   if ( key3a == sLst[0].ascii() && key3 == sLst[1].ascii()) foundYN=true;
                                   if ( key3a == sLst[2].ascii()) tvalue=key3;
                               }
                               if (foundYN ) return tvalue.c_str();
                           }
                        }
                     
                       }
                       else
                       {
                           
                           
                       for(YAML::Iterator it3=it2.second().begin();it3!=it2.second().end();++it3)
                       {
                           key3=""; value3="";
                           it3.first() >> key3;
                           
                           if ( key3!=lst[2].ascii()) continue;

                           if (countLevels==3)
                           {
                               it3.second()>>value3;
                               return value3.c_str();
                           }
                           
                           // 4th level
                           std::string key4, value4;
                           
                           if (it3.second().Type() == YAML::NodeType::Sequence)
                           {
                           }
                           else
                           {
                               for(YAML::Iterator it4=it3.second().begin();it4!=it3.second().end();++it4)
                               {
                                   if (countLevels>4) return "limit-4-levels";
                                   key4=""; value4="";
                                   it4.first() >> key4;
                               
                                   if ( key4!=lst[3].ascii()) continue;
                               
                                   if (countLevels==4)
                                   {
                                       it4.second()>>value4;
                                       return value4.c_str();
                                   }
                               }
                           }
    
                       }
                       }
                    
                    }
                }

            }

        
        } catch(const YAML::Exception& e) {
        std::cerr << e.what() << "\n";
    }

    
    return "";
}


QString dan16::readXMLentry(QString runNumber,  QString xmlCode)
{
    QString fileName=fileNameUni(wildCard2nd, runNumber);
    QString xmlBase=lineEditXMLbase->text();
    
    xmlBase=xmlBase.remove(" ");
    if (xmlBase!="")
    {
        xmlBase+=":";
        xmlBase=xmlBase.replace("::",":");
        xmlBase=xmlBase.replace("::",":");
    }
    
    xmlCode=xmlBase+xmlCode;
    
    xmlCode=xmlCode.remove(" ");
    xmlCode=xmlCode.replace("::",":");
    xmlCode=xmlCode.replace("::",":");
    
    QStringList lst=lst.split(":",xmlCode);
    
    
    QDomDocument 	doc;
    QDomElement 		root;
    QDomElement 		element;
    
    
    QString 	errorStr;
    int 		errorLine;
    int 		errorColumn;
    
    
    //+++
    QFile *xmlFile= new QFile(fileName);
    if (!xmlFile->open(IO_ReadOnly)) return "";
    if (!doc.setContent(xmlFile, true, &errorStr, &errorLine,&errorColumn)) return "";
    
    root = doc.documentElement();
    readXMLentry(root, lst, element,0);
    xmlFile->close();
    
    return element.text().simplifyWhiteSpace();
}


bool dan16::readXMLentry(QDomElement root, QStringList lst, QDomElement &element, int order)
{
    int number=lst.count();
    if (number<1) return false;
    if (number==1)
    {
        if (root.tagName() != lst[0] ) return false;
        element=root;
        return true;
    }
    int numberCycles=0;
    QValueList<int> positions;
    
    //+++ number of cycles ...
    for (int i=1; i<number;i++)
    {
        if (lst[i].contains("{") && lst[i].contains("}"))
        {
            lst[i]=lst[i].remove("}");
            lst[i]=lst[i].remove("{");
            
            positions<<i;
            numberCycles++;
        }
    }
    
    if (numberCycles>2) return  false;
    
    
    if (numberCycles<=1)
    {
        if (root.tagName() != lst[0])
        {
            qWarning("XML(0-1) file error: level # 0");
            return false;
        }
        
        QDomNode node = root.firstChild();
        bool nodeFound=false;
        
        bool repeatedNote;
        int repeatCounter;
        
        for(int i=1; i<number;i++)
        {
            repeatedNote=false;
            repeatCounter=0;
            
            if (lst[i].contains("{") && lst[i].contains("}"))
            {
                repeatedNote=true;
                lst[i]=lst[i].remove("{");
                lst[i]=lst[i].remove("}");
            }
            
            while (!node.isNull() && !nodeFound )
            {
                
                if (node.toElement().tagName() == lst[i] )
                {
                    if (repeatCounter<order && repeatedNote)
                    {
                        repeatCounter++;
                        node=node.nextSibling();
                    }
                    else
                    {
                        //qWarning("current node %s", node.toElement().tagName());
                        if (i<(number-1)) node = node.firstChild();
                        nodeFound=true;
                    }
                }
                else node = node.nextSibling();
            }
            if (!nodeFound)
            {
                qWarning("XML file error: level # %d, %s", i, lst[i].ascii());
                return false;
            }
            nodeFound=false;
        }
        if (node.toElement().tagName() == lst[number-1]) element=node.toElement();
        else return false;
    }
    
    if (numberCycles==2)
    {
        int i=positions[0];
        
        if (root.tagName() != lst[0])
        {
            return -5;
        }
        
        QDomNode node = root.firstChild();
        
        bool nodeFound=false;	
        bool repeatedNote;
        int repeatCounter2=0;
        
        for(int ii=1; ii<=positions[0];ii++)
        {
            nodeFound=false;
            repeatedNote=false;
            
            if (ii==positions[0]) repeatedNote=true;
            
            while (!node.isNull() && !nodeFound ) 
            {	
                if (node.toElement().tagName() == lst[ii] )
                {	
                    if (repeatedNote) 
                    {			
                        QDomNode node2 = node;
                        bool nodeFound2=false;	
                        bool repeatedNote2;
                        
                        for(int iii=ii; iii<=positions[1];iii++)
                        {
                            nodeFound2=false;
                            repeatedNote2=false;
                            
                            if (iii==positions[1]) repeatedNote2=true;
                            
                            while (!node2.isNull() && !nodeFound2 ) 
                            {	
                                if (node2.toElement().tagName() == lst[iii] )
                                {	
                                    if (repeatedNote2) 
                                    {    	
                                        if (repeatCounter2==order) 
                                        {
                                            if (iii<number-1)
                                            {
                                                for(int iiii=iii+1; iiii<number;iiii++) 
                                                {
                                                    node2 = node2.firstChild();
                                                    while (!node2.isNull() && node2.toElement().tagName() != lst[iiii])
                                                        node2 = node2.nextSibling();
                                                }
                                            }
                                            element=node2.toElement();
                                            return true;
                                        }
                                        
                                        node2 = node2.nextSibling(); 
                                        repeatCounter2++;
                                        if (node2.toElement().tagName() != lst[positions[1]] ) break;
                                        
                                    }
                                    else
                                    {
                                        nodeFound2=true;
                                        if (iii<positions[1]) node2 = node2.firstChild();    
                                    }
                                }
                                else
                                {
                                    node2 = node2.nextSibling();
                                }
                            }
                            nodeFound2=false;
                        }
                        
                        node = node.nextSibling(); 
                        if (node.toElement().tagName() != lst[positions[0]] ) return repeatCounter2;
                    }
                    else
                    {
                        nodeFound=true;
                        if (ii<positions[0]) node = node.firstChild();    
                    }
                }
                else
                {
                    node = node.nextSibling();
                }
            }
            if (!nodeFound) 
            {
                qWarning("XML(2) file error: level # %d, %s", ii, lst[ii].ascii());
                return 0;
            }
            if (repeatedNote) return repeatCounter2;
            nodeFound=false;
        }
        return -5;
    }    
    
    
    return true;
}


