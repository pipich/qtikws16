#include "dan16.h"


//*******************************************
//+++  Read settings
//*******************************************
void dan16::readSettings()
{
#ifdef Q_OS_MAC // Mac
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
    //+++
    settings.setPath("JCNS", "QtiKWS", QSettings::User);
    //+++
    bool ok;
    QString ss;
    //+++
    settings.beginGroup("/DAN");
    //+++
    ss=settings.readEntry("/lineEditPathDAT",0,&ok);
    if (ok && ss.left(4)!="home") lineEditPathDAT->setText(ss);
    //+++
    ss=settings.readEntry("/lineEditPathRAD",0,&ok); 
    if (ok && ss.left(4)!="home") lineEditPathRAD->setText(ss);
    //+++
    ss=settings.readEntry("/instrument",0,&ok);
    //+++
    if (ok)
    {
        QString currentInstrument=ss;
        //+++
        for (int i =0; i<comboBoxSel->count(); i++ )	if (comboBoxSel->text(i)==currentInstrument)
        {
            comboBoxSel->setCurrentItem(i);
            instrumentSelected();
            break;
        }
    }
    //+++
    settings.endGroup();
}

//*******************************************
//+++  Write settings
//*******************************************
void dan16::writeSettings()
{
#ifdef Q_OS_MAC // Mac
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
    settings.setPath ( "JCNS", "QtiKWS", QSettings::User );
    //+++
    settings.beginGroup("/DAN");
    //+++
    if (lineEditPathDAT->text()!="home") settings.writeEntry("/lineEditPathDAT",  lineEditPathDAT->text());
    if (lineEditPathRAD->text()!="home")settings.writeEntry("/lineEditPathRAD",  lineEditPathRAD->text());
    //+++
    settings.writeEntry("/instrument",  comboBoxSel->currentText());
    //+++
    settings.endGroup();
}
