//
//  dan16-easy-dan.cpp
//  
//
//  Created by Vitaliy Pipich on 16.08.17.
//
//

#include "dan16.h"

void dan16::easyDanLight()
{
    ImportantConstants();

    
    QString path = lineEditPathDAT->text();
    QString pathWildcard = textEditPattern->text();
    int minTime = spinBoxEDfiltrationTIME->value();
    int minSum = spinBoxEDfiltrationSUM->value();
    QString fileAcceptWildcard = lineEditEDwildcardFILEACCEPT->text(); fileAcceptWildcard = fileAcceptWildcard.remove(" ");
    QString fileSkipWildcard = lineEditEDwildcardFILESKIP->text(); fileSkipWildcard = fileSkipWildcard.remove(" ");
    QString sampleAcceptWildcard = lineEditEDwildcardSAMPLEACCEPT->text();sampleAcceptWildcard = sampleAcceptWildcard.remove(" ");
    QString sampleSkipWildcard = lineEditEDwildcardSAMPLESKIP->text(); sampleSkipWildcard = sampleSkipWildcard.remove(" ");
    
    
    QStringList files = edReadFiles(path,pathWildcard,minTime,minSum,fileAcceptWildcard,fileSkipWildcard,sampleAcceptWildcard,sampleSkipWildcard );

    //
    files = edFilterFilesTime(files, minTime);
    files = edFilterFilesSum (files, minSum);
    files = edFilterWildcardFileNameAccept(files, fileAcceptWildcard);
    files = edFilterWildcardFileNameSkip(files, fileSkipWildcard);
    files = edFilterWildcardSampleNameAccept(files, sampleAcceptWildcard);
    files = edFilterWildcardSampleNameSkip(files, sampleSkipWildcard);
    
    QStringList numbers=edReadRunNumbers(files, Dir, wildCard);
    
    QValueList<int> durations = edReadDurations(numbers);
    QValueList<int> sums = edReadSums(numbers);
    
    QStringList samples= edReadSamples(numbers);
    
    QStringList collimations= edReadCollimations(numbers);
    
    QStringList distances= edReadDistances(numbers);
    
    for (int i=0;i<files.count();i++) std::cout <<numbers[i]+" - "+samples[i]+" - "+collimations[i] + distances[i] +" - "+ QString::number(durations[i])+"sec - "+ QString::number(sums[i])<<"counts\n";
    
}


QStringList dan16::edReadFiles(QString path, QString pathWildcard, int minTime, int minSum, QString fileAcceptWildcard, QString fileSkipWildcard, QString sampleAcceptWildcard, QString sampleSkipWildcard )
{
    QDir d(path);
    QStringList lst = d.entryList(pathWildcard);

    return lst;
}

QStringList dan16::edReadRunNumbers(QStringList files, QString dir, QString wildcard)
{
    QStringList lst;
    QString str;
    for (int i=0;i<files.count();i++)
    {
        str=files[i];
        str=str.remove(dir);
        lst<<findFileNumberInFileName(wildcard, str);
    }
    return lst;
}

QStringList dan16::edReadCollimations(QStringList numbers)
{
    QStringList lst;
    for (int i=0;i<numbers.count();i++)
    {
        lst<<"C" + QString::number(readDataIntCinM(numbers[i])) + "m";
    }
    return lst;
}

QStringList dan16::edReadDistances(QStringList numbers)
{
    QStringList lst;
    for (int i=0;i<numbers.count();i++)
    {
        lst<<"D" + QString::number(readDataDinM(numbers[i]),'f',0) + "m";
    }
    return lst;
}

QValueList<int> dan16::edReadDurations(QStringList numbers)
{
    QValueList<int> lst;
    for (int i=0;i<numbers.count();i++)
    {
        lst<<int(readDuration(numbers[i]));
    }
    return lst;
}

QValueList<int> dan16::edReadSums(QStringList numbers)
{
    QValueList<int> lst;
    for (int i=0;i<numbers.count();i++)
    {
        lst<<int(readSum(numbers[i]));
    }
    return lst;
}

QStringList dan16::edReadSamples(QStringList numbers)
{
    QStringList lst;
    for (int i=0;i<numbers.count();i++)
    {
        lst<<readInfo(numbers[i]);
    }
    return lst;
}


QStringList dan16::edFilterFilesTime(QStringList files, int minTime)
{
    QStringList numbers=edReadRunNumbers(files, Dir, wildCard);
    QValueList<int> durations = edReadDurations(numbers);
    
    QStringList lst;
    for (int i=0;i<files.count();i++) if (durations[i]>minTime )lst << files[i];
    return lst;
}

QStringList dan16::edFilterFilesSum(QStringList files, int minSum)
{
    QStringList numbers=edReadRunNumbers(files, Dir, wildCard);
    QValueList<int> sums = edReadSums(numbers);
    
    QStringList lst;
    for (int i=0;i<files.count();i++) if (sums[i]>minSum )lst << files[i];
    return lst;
}


QStringList dan16::edFilterWildcardFileNameAccept(QStringList files, QString fileAcceptWildcard)
{
    
    QRegExp rx(fileAcceptWildcard);
    rx.setWildcard( TRUE );

    
    QStringList lst;
    for (int i=0;i<files.count();i++) if ( rx.exactMatch(files[i].remove(Dir))) lst << files[i];
    return lst;
}

QStringList dan16::edFilterWildcardFileNameSkip(QStringList files, QString fileAcceptWildcard)
{
    
    QRegExp rx(fileAcceptWildcard);
    rx.setWildcard( TRUE );
    
    
    QStringList lst;
    for (int i=0;i<files.count();i++) if (!rx.exactMatch(files[i].remove(Dir))) lst << files[i];
    return lst;
}

QStringList dan16::edFilterWildcardSampleNameAccept(QStringList files, QString sampleAcceptWildcard)
{
    QStringList numbers=edReadRunNumbers(files, Dir, wildCard);
    QStringList samples= edReadSamples(numbers);
    
    
    QRegExp rx(sampleAcceptWildcard);
    rx.setWildcard( TRUE );
    
    
    QStringList lst;
    for (int i=0;i<files.count();i++) if ( rx.exactMatch(samples[i].remove(Dir))) lst << files[i];
    return lst;
}

QStringList dan16::edFilterWildcardSampleNameSkip(QStringList files, QString sampleSkipWildcard)
{
    QStringList numbers=edReadRunNumbers(files, Dir, wildCard);
    QStringList samples= edReadSamples(numbers);
    
    
    QRegExp rx(sampleSkipWildcard);
    rx.setWildcard( TRUE );
    
    
    QStringList lst;
    for (int i=0;i<files.count();i++) if ( !rx.exactMatch(samples[i].remove(Dir))) lst << files[i];
    return lst;
}
