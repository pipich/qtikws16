#include "dan16.h"

#include <gsl/gsl_fit.h>
#include <gsl/gsl_spline.h>

//*******************************************
//+++  RT tools:: Sum [slot]
//*******************************************
void dan16::dandanConnectSlots()
{
    connect(pushButtonIQ, SIGNAL( clicked() ), this, SLOT(slotDANbuttonIQ() ) );
    connect(pushButtonPolar, SIGNAL( clicked() ), this, SLOT(slotDANbuttonPolar() ) );
    connect(pushButtonIxy, SIGNAL( clicked() ), this, SLOT(slotDANbuttonIxy() ) );
    connect(pushButtondIxy, SIGNAL( clicked() ), this, SLOT(slotDANbuttonDIxy() ) );
    connect(pushButtonIQx, SIGNAL( clicked() ), this, SLOT(slotDANbuttonIQx() ) );
    connect(pushButtonIQy, SIGNAL( clicked() ), this, SLOT(slotDANbuttonIQy()) );
    connect(pushButtonSigma, SIGNAL( clicked() ), this, SLOT(slotDANbuttonSigma()) );
    connect(pushButtonQxy, SIGNAL( clicked() ), this, SLOT(slotDANbuttonQxy() ) );
    connect(pushButtondQxy, SIGNAL( clicked() ), this, SLOT(slotDANbuttondQxy() ) );
}


//+++
void dan16::slotDANbuttonPolar()    {   danDanMultiButton("I-Polar");   };
void dan16::slotDANbuttonIQ()       {   danDanMultiButton("I-Q");       };
void dan16::slotDANbuttonIxy()      {   danDanMultiButton("I-x-y");     };
void dan16::slotDANbuttonDIxy()     {   danDanMultiButton("dI-x-y");    };
void dan16::slotDANbuttonIQx()      {   danDanMultiButton("I-Qx");      };
void dan16::slotDANbuttonIQy()      {   danDanMultiButton("I-Qy");      };
void dan16::slotDANbuttonSigma()    {   danDanMultiButton("Sigma-x-y"); };
void dan16::slotDANbuttonQxy()      {   danDanMultiButton("Q-x-y");     };
void dan16::slotDANbuttondQxy()     {   danDanMultiButton("dQ-x-y"); };


//*******************************************
//+++ dan
//*******************************************
void dan16::danDanMultiButton(QString button)
{
    //+++ Output data Suffix
    QString dataSuffix;
    switch (comboBoxMode->currentItem())
    {
		case 0:
		    dataSuffix="SM";
		    break;
		case 1:
		    dataSuffix="BS";
		    break;
		case 2:
		    dataSuffix="BS-SENS";
		    break;
		case 3:
		    dataSuffix="SM";
		    break;
		case 4:
		    dataSuffix="SM";
		    break;
		default:
		    dataSuffix="SM";
		    break;
    }
    
    //+++ current folder
    Folder *cf;
    
    // current widget
    myWidget *ww= ( myWidget * ) app(this)->ws->activeWindow();
    bool maximizedWW=false;
    if (ww && ww->status() == myWidget::Maximized )
    {
        maximizedWW=true;
        ww->showNormal();
    }
    
    //+++ skip Tr processing
    bool skipTrProcessing=false;
    
    //+++ Generation of list of Transmission files
    QValueList<int> listTr;
    
    if (checkBoxSkiptransmisionConfigurations->isChecked())
    {
        skipTrProcessing=true;
        
        int numberTrConfigurations=0;
        
        for (int i=0; i<sliderConfigurations->value(); i++)
        {
            QCheckTableItem *active = (QCheckTableItem *)tableECnew->item(dptECTR, i);
            
            if (active->isChecked() )
            {
                numberTrConfigurations++;
                listTr<<(i+1);
            }
        }
        
        if (numberTrConfigurations == sliderConfigurations->value() ) skipTrProcessing=false;
    }
    
    //+++ Update paramters
    ImportantConstants();
    
    //+++ Subtract Bufffer
    bool subtractBuffer= false;
    if (comboBoxMode->currentText().contains("(BS)")) subtractBuffer=true;
    
    //+++ Subtract Bufffer && Correct to own Sensitivity
    bool bufferAsSens= false;
    if (comboBoxMode->currentText().contains("(BS-SENS)")) bufferAsSens=true;
    
    //+++ update mask and sens lists +++
    updateMaskList();
    updateSensList();
    
    //+++ mask gsl matrix
    gsl_matrix *mask = gsl_matrix_alloc(MD,MD);
    
    //+++ sens gsl matrix
    gsl_matrix *sens=gsl_matrix_alloc(MD,MD);
    gsl_matrix *sensErr=gsl_matrix_alloc(MD,MD);
    
    //+++
    gsl_matrix *Sample=gsl_matrix_alloc(MD,MD);
    gsl_matrix *SampleErr=gsl_matrix_alloc(MD,MD);
    
    //+++
    gsl_matrix *Buffer=gsl_matrix_alloc(MD,MD);
    gsl_matrix *BufferErr=gsl_matrix_alloc(MD,MD);
    
    //+++
    gsl_matrix *EC=gsl_matrix_alloc(MD,MD);
    gsl_matrix *ECErr=gsl_matrix_alloc(MD,MD);
    //+++
    gsl_matrix *BC=gsl_matrix_alloc(MD,MD);
    gsl_matrix *BCErr=gsl_matrix_alloc(MD,MD);
    
    //+++ error matrix
    gsl_matrix *ErrMatrix=gsl_matrix_alloc(MD,MD);
    
    //+++ script table
    Table *w;
    
    //+++ loops
    int i, xxx, yyy;
    
    //+++ current row in script table
    int iRow;
    
    //+++ current sample run-number and current condition
    int condition;
    QString Nsample;
    
    //+++ result string info for current row
    QString status;
    QString maskName, sensName, label;
    
    //+++ optional parameter if column "Scale" exist
    double scale;
    
    //+++ optional parameter if column "Background" exist
    double BackgroundConst;
    
    //+++ optional parameter if column "VShift" exist
    double VShift;
    
    //+++ optional parameter if column "HShift" exist
    double HShift;
    
    //+++ Current sample transmission, tichness, factor & center of beam
    double trans, transBuffer, fractionBuffer, thickness, abs, absBuffer, Xcenter, Ycenter;
    
    //+++ table Name +++
    QString tableName=comboBoxMakeScriptTable->currentText();
    
    //+++ check existence of script table w
    if (!checkTableExistence(tableName))
    {
        QMessageBox::critical(0, "QtiKWS", "Table ~"+tableName+"~ does not exist!!! <br><h4>");
        
        //+++ Clean Memory +++
        gsl_matrix_free(Sample);
        gsl_matrix_free(SampleErr);
        gsl_matrix_free(Buffer);
        gsl_matrix_free(BufferErr);
        gsl_matrix_free(EC);
        gsl_matrix_free(ECErr);
        gsl_matrix_free(BC);
        gsl_matrix_free(BCErr);
        gsl_matrix_free(mask);
        gsl_matrix_free(sens);
        gsl_matrix_free(sensErr);
        gsl_matrix_free(ErrMatrix);
        
        return;
    }
    
    //+++ list of all tables in project
    QWidgetList* tableList=app(this)->tableList();
    
    //+++ Find pointer to script  table
    for (i=0;i<(int)tableList->count();i++)
    {
        if (tableList->at(i) && tableList->at(i)->name()==tableName) w=(Table *)tableList->at(i);
    }
    
    //+++ again check existence of table
    if (!w)
    {
        QMessageBox::critical(0, "QtiKWS", "Table ~"+tableName+"~ does not exist!!! <br><h4>");
        
        //+++ Clean Memory +++
        gsl_matrix_free(Sample);
        gsl_matrix_free(SampleErr);
        gsl_matrix_free(Buffer);
        gsl_matrix_free(BufferErr);
        gsl_matrix_free(EC);
        gsl_matrix_free(ECErr);
        gsl_matrix_free(BC);
        gsl_matrix_free(BCErr);
        gsl_matrix_free(mask);
        gsl_matrix_free(sens);
        gsl_matrix_free(sensErr);
        gsl_matrix_free(ErrMatrix);
        
        return;
    }
    
    //+++ Indexing
    QStringList scriptColList=w->colNames();
    
    //+++ Check of script-table-structure
    bool scriptOK=true;
    QString scriptIsNotOK="";
    
    
    int indexInfo=scriptColList.findIndex("Run-info");if (indexInfo<0){ scriptOK=false; scriptIsNotOK="Run-info";};             //+++  Run-info  +++
    int indexSample=scriptColList.findIndex("#-Run"); if (indexSample<0){ scriptOK=false; scriptIsNotOK="#-Run";};              //+++  #-Run +++
    int indexCond=scriptColList.findIndex("#-Condition"); if (indexCond<0){ scriptOK=false; scriptIsNotOK="#-Condition";};      //+++  #-Condition +++
    int indexC=scriptColList.findIndex("C"); if (indexC<0){ scriptOK=false; scriptIsNotOK="C";};                                //+++  C +++
    int indexD=scriptColList.findIndex("D"); if (indexD<0){ scriptOK=false; scriptIsNotOK="D";};                                //+++  D +++
    int indexLam=scriptColList.findIndex("Lambda"); if (indexLam<0){ scriptOK=false; scriptIsNotOK="Lambda";};                  //+++  Lambda +++
    int indexCA=scriptColList.findIndex("Beam Size"); if (indexCA<0){ scriptOK=false; scriptIsNotOK="Beam Size";};              //+++  Beam Size +++
    int indexBC=scriptColList.findIndex("#-BC"); if (indexBC<0){ scriptOK=false; scriptIsNotOK="#-BC";};                        //+++  #-BC +++
    
    int indexEC=scriptColList.findIndex("#-EC [EB]");
    if (indexEC<0){ indexEC=scriptColList.findIndex("#-EC"); if (indexEC<0) {scriptOK=false; scriptIsNotOK="#-EC";}};                       //+++  #-EC [EB] +++
    int indexBuffer=scriptColList.findIndex("#-Buffer"); if (subtractBuffer && indexBuffer<0){ scriptOK=false; scriptIsNotOK="#-Buffer";};  //+++  #-Buffer +++
    int indexThickness=scriptColList.findIndex("Thickness"); if (indexThickness<0){ scriptOK=false; scriptIsNotOK="Thickness";};            //+++  Thickness+++
    
    int indexTr=scriptColList.findIndex("Transmission-Sample");
    if (indexTr<0){ indexTr=scriptColList.findIndex("Transmission"); if (indexTr<0) {scriptOK=false; scriptIsNotOK="Transmission-Sample";}};        //+++  Transmission-Sample +++
    int indexTrBuffer=scriptColList.findIndex("Transmission-Buffer");
    if (subtractBuffer && indexTrBuffer<0){ scriptOK=false; scriptIsNotOK="Transmission-Buffer";};                                                  //+++  Transmission-Buffer +++
    int indexBufferFraction=scriptColList.findIndex("Buffer-Fraction");
    if (subtractBuffer && indexBufferFraction<0){ scriptOK=false; scriptIsNotOK="Buffer-Fraction";};                                                //+++  Buffer-Fraction +++
    
    
    int indexFactor=scriptColList.findIndex("Factor"); if (indexFactor<0){ scriptOK=false; scriptIsNotOK="Factor";};            //+++  Factor +++
    int indexXC=scriptColList.findIndex("X-center"); if (indexXC<0){ scriptOK=false; scriptIsNotOK="X-center";};                //+++  X-center +++
    int indexYC=scriptColList.findIndex("Y-center"); if (indexYC<0){ scriptOK=false; scriptIsNotOK="Y-center";};                //+++  Y-center +++
    int indexMask=scriptColList.findIndex("Mask"); if (indexMask<0){ scriptOK=false; scriptIsNotOK="Mask";};                    //+++  Mask +++
    int indexSens=scriptColList.findIndex("Sens"); if (indexSens<0){ scriptOK=false; scriptIsNotOK="Sens";};                    //+++  Sens +++
    int indexStatus=scriptColList.findIndex("Status"); if (indexStatus<0){ scriptOK=false; scriptIsNotOK="Status";};              //+++  Status +++
    
    if (!scriptOK)
    {
        QMessageBox::critical(0, "QtiKWS", "Table ~"+tableName+" has wrong format [" + scriptIsNotOK + "]. <br> Check table or  generate new one.<h4>");
        
        //+++ Clean Memory +++
        gsl_matrix_free(Sample);
        gsl_matrix_free(SampleErr);
        gsl_matrix_free(Buffer);
        gsl_matrix_free(BufferErr);
        gsl_matrix_free(EC);
        gsl_matrix_free(ECErr);
        gsl_matrix_free(BC);
        gsl_matrix_free(BCErr);
        gsl_matrix_free(mask);
        gsl_matrix_free(sens);
        gsl_matrix_free(sensErr);
        gsl_matrix_free(ErrMatrix);
        
        return;
    }
    //--- Check of script-table-structure
    
    //+++ Scale +++ Hand-made column
    int indexScale=scriptColList.findIndex("Scale");
    
    //+++ BackgroundConst +++ Hand-made column
    int indexBackgroundConst=scriptColList.findIndex("Background");
    
    //+++ VShift +++ Hand-made column
    int indexVShift=scriptColList.findIndex("VShift");
    
    //+++ HShift +++ Hand-made column
    int indexHShift=scriptColList.findIndex("HShift");
    
    //+++ Use sensitivity Local +++
    int indexUseSensBufferLocal=scriptColList.findIndex("Use-Buffer-as-Sensitivity");
    
    //+++ get number of rows
    int Nrows=w->numRows();
    
    //+++ last raw
    int last=Nrows;
    
    //+++ Progress Dialog +++
    QProgressDialog progress( "Data Processing Started...", "Abort Data Processing", last-1 , this, "Progress:", TRUE );
    progress.setActiveWindow();
    
    //+++ Mask & Sens +++
    QStringList listMask, listSens;
    QString winLabelMask="DAN::Mask::"+QString::number(MD);
    QString winLabelSens="DAN::Sensitivity::"+QString::number(MD);
    
    findMatrixListByLabel(winLabelMask, listMask);
    if (!listMask.contains("mask")) listMask.prepend("mask");
    findMatrixListByLabel(winLabelSens, listSens);
    if (!listSens.contains("sens")) listSens.prepend("sens");
    
    //+++ tamplate to merge datasets
    QStringList mergedTemplate;
    
    // +++ iRow corresponds to the number of row
    //+++ row by row data reduction
    //+++ main loop
    
    bool checkSelection=false;
    
    for (iRow=0; iRow<last; iRow++)
    {
        if (w->isRowSelected(iRow,TRUE))
        {
            checkSelection=TRUE;
            break;
        }
    }
    
    app(this)->ws->hide();
    app(this)->ws->blockSignals ( true );
    
    //+++
    if (radioButtonOpenInProject->isChecked() && checkBoxSortOutputToFolders->isChecked())
    {
        cf = ( Folder * ) app(this)->current_folder;
        
        if (button=="I-x-y")	app(this)->changeFolder("DAN :: I [x,y]");
        if (button=="dI-x-y")	app(this)->changeFolder("DAN :: dI [x,y]");
        if (button=="I-Q")	    app(this)->changeFolder("DAN :: I [Q]");
        if (button=="I-Qx")		app(this)->changeFolder("DAN :: I [Qx]");
        if (button=="I-Qy")		app(this)->changeFolder("DAN :: I [Qy]");
        if (button=="I-Polar")	app(this)->changeFolder("DAN :: I [Q,phi]");
        if (button=="Sigma-x-y")app(this)->changeFolder("DAN :: Sigma [x,y]");
        if (button=="Q-x-y")	app(this)->changeFolder("DAN :: Q [x,y]");
        if (button=="dQ-x-y")	app(this)->changeFolder("DAN :: dQ [x,y]");
        
        app(this)->folders->setFocus();
    }
    
    
    //+++ START file-to-file data reduction
    
    for (iRow=0; iRow<last; iRow++)
    {
        if (checkSelection && !w->isRowSelected(iRow,TRUE)) {mergedTemplate<<"-0-"; continue;}
        
        //+++ check number  of condition
        status=">>>  no conditions  "; // status for each file
        
        //+++
        condition=w->text(iRow,indexCond).toInt();
        
        //+++ goto next row
        if(condition<0)
        {
            mergedTemplate<<"-0-";
            
            //+++ Set Status +++
            w->setText(iRow,indexStatus,status);
            
            //+++ Progress +++
            progress.setProgress( iRow );
            if ( progress.wasCanceled() ) break;
            continue;
        }
        
        if(skipTrProcessing && listTr.findIndex(condition)>=0) {mergedTemplate<<"-0-"; continue;}
        
        
        //+++ goto next row
        if (condition==0)
        {
            mergedTemplate<<"-0-";
            
            //+++ Set Status +++
            w->setText(iRow,indexStatus,status);
            
            
            //+++ Progress +++
            progress.setProgress( iRow );
            
            if ( progress.wasCanceled() ) break;
            
            continue;
        }
        
        scale=1.0;
        if (indexScale>0)
        {
            scale=w->text(iRow,indexScale).toDouble();
            if (scale<=0.0) scale=1.0;
        }
        
        BackgroundConst=0.0;
        if (indexBackgroundConst>0)
        {
            BackgroundConst=w->text(iRow,indexBackgroundConst).toDouble();
        }
        
        VShift=0.0;
        if (indexVShift>0)
        {
            VShift=w->text(iRow,indexVShift).toDouble();
        }
        
        HShift=0.0;
        if (indexHShift>0)
        {
            HShift=w->text(iRow,indexHShift).toDouble();
        }
        
        //++++ MASK+  >>>>
        maskName=w->text(iRow,indexMask);
        if ( !listMask.contains(maskName) )
        {
            maskName=comboBoxMaskFor->currentText();
            w->setText(iRow,indexMask,maskName);
        }
        gsl_matrix_set_zero (mask);
        make_GSL_Matrix_Symmetric(maskName, mask, MD);

        
        //+++ SENS+  >>>>
        sensName=w->text(iRow,indexSens);
        if ( !listSens.contains(sensName) )
        {
            sensName=comboBoxSensFor->currentText();
            w->setText(iRow,indexSens,sensName);
        }
        gsl_matrix_set_zero (sens);
        make_GSL_Matrix_Symmetric(sensName, sens, MD);
        
        //+++
        if (subtractBuffer && bufferAsSens)
        {
            if (indexUseSensBufferLocal<0 || w->text(iRow, indexUseSensBufferLocal)=="yes")
            {
            }
            else 	sensAndMaskSynchro(mask, sens, MD);
        }
        else sensAndMaskSynchro(mask, sens, MD );
        
        //+++ I-Qx +  >>>>
        if (button=="I-Qx")
        {
            int from=spinBoxFrom->value();
            int to=spinBoxTo->value();
            if (from <=to && from>0 && to<=MD)
            {
                
                for (xxx=0; xxx<MD; xxx++ )
                    for (int yyy=0; yyy<(from-1); yyy++ ) gsl_matrix_set(mask,yyy,xxx, 0.0 );
                for (int xxx=0; xxx<MD; xxx++ )
                    for (yyy=to; yyy<MD; yyy++ ) gsl_matrix_set(mask,yyy,xxx, 0.0 );
            }
        }
        //--- I-Qx - >>>>
        
        //+++ I-Qy + >>>>
        if (button=="I-Qy")
        {
            int from=spinBoxFrom->value();
            int to=spinBoxTo->value();
            if (from <=to && from>0 && to<=MD)
            {
                for (yyy=0; yyy<MD; yyy++ )
                    for (xxx=0; xxx<(from-1); xxx++ ) gsl_matrix_set(mask,yyy,xxx, 0.0 );
                for (int yyy=0; yyy<MD; yyy++ )
                    for (xxx=to; xxx<MD; xxx++ ) gsl_matrix_set(mask,yyy,xxx, 0.0 );
            }
        }
        //---- I-Qy -  >>>>
        
        
        //+++ Sensetivty Error Matrix
        QString sensFile=getSensitivityNumber(sensName);
        
        gsl_matrix_set_zero (sensErr);
        
        if (checkFileNumber(sensFile))
            readErrorMatrix( sensFile, sensErr);
        
        label=w->text(iRow,indexInfo);
        
        Nsample=w->text(iRow,indexSample);
        
        //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        //+++ All actions only in case Sample Exists                   !!!!!!!!!!!!!!!!
        //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        if (!checkFileNumber( Nsample ))
        {
            //+++ if file is skipted +++
            if (Nsample.toInt() !=0) w->setText(i,indexSample,w->text(i,indexSample)+"  >>>  not exist!!!");
            status=">>> file "+Nsample+" not found; output:: no ";
            
            //+++ Set Status +++
            w->setText(iRow,indexStatus,status);
            
            //+++ Progress +++
            progress.setProgress( iRow );
            if ( progress.wasCanceled() ) break;
            continue;
        }
        
        //+++
        gsl_matrix_set_zero (Sample);
        gsl_matrix_set_zero (SampleErr);
        
        gsl_matrix_set_zero (ErrMatrix);
        
        //+++
        gsl_matrix_set_zero (Buffer);
        gsl_matrix_set_zero (BufferErr);
        
        //+++
        gsl_matrix_set_zero (EC);
        gsl_matrix_set_zero (ECErr);
        //
        gsl_matrix_set_zero (BC);
        gsl_matrix_set_zero (BCErr);
        
        //+++
        readMatrixCor( Nsample, Sample);
        readErrorMatrix( Nsample, SampleErr);
        
        gslMatrixShift(Sample, MD, HShift, VShift );
        gslMatrixShift(SampleErr, MD, HShift, VShift );
        
        //+++
        status=">>>  sample#="+Nsample+": OK  ";
        
        
        QString Nbuffer;
        
        if (subtractBuffer)
        {
            
            Nbuffer=w->text( iRow, indexBuffer );
            
            //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            //+++ All actions only in case Sample Exists  !!!!!!!!!!!!!!!!!
            //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            if (!checkFileNumber( Nbuffer ))
            {
                //+++ if file is skipted +++
                if ( Nbuffer.toInt() !=0 ) w->setText(i,indexBuffer, Nbuffer + "  >>>  not exist!!!");
                status=">>> file "+Nbuffer+"BUFFER not found; output:: no ";
                
                //+++ Set Status +++
                w->setText(iRow,indexStatus,status);
                
                //+++ Progress +++
                progress.setProgress( iRow );
                if ( progress.wasCanceled() ) break;
                continue;
            }
            //+++
            readMatrixCor( Nbuffer, Buffer);
            readErrorMatrix( Nbuffer, BufferErr);
        }
        
        //+++ If BC exist but EC not !!! +++
        bool ECexist=false;
        
        //+++ EC +++
        QString NEC=w->text(iRow,indexEC);
        
        if ( checkFileNumber( NEC ) )
        {
            readMatrixCor( NEC,EC);
            readErrorMatrix( NEC, ECErr);
            status+=">>>  EC#=" + NEC + ": OK  ";
            //+++
            ECexist=true;
        }
        else status+=">>>  EC: no correction  ";
        
        //+++ BC +++
        QString NBC=w->text(iRow,indexBC);
        
        if (checkFileNumber( NBC ))
        {
            // read BC matrix 2012
            if (checkBoxBCTimeNormalization->isChecked())
            {
                readMatrixCorTimeNormalizationOnly( NBC, BC );
                
                //Normalization constant
                double TimeSample=spinBoxNorm->value();
                double ttime=readDuration( Nsample );
                if (ttime>0.0) TimeSample/=ttime; else TimeSample=0.0;
                
                double NormSample=readDataNormalization(Nsample);
                
                if (TimeSample>0) NormSample/=TimeSample; else NormSample=0;
                
                gsl_matrix_scale(BC,NormSample);      // EB=T*EB
            }
            else readMatrixCor( NBC, BC );
            
            readErrorMatrix( NBC, BCErr);
            status+=">>>  BC#=" + NBC + ": OK  ";
        }
        else status+=">>>  BC: no correction  ";
        
        //+++ transmission check
        trans=w->text(iRow,indexTr).toDouble();
        if (trans<=0.0 || trans>2.0)
        {
            w->setText(iRow,indexTr,"Check!!!");
            QMessageBox::warning(this,tr("QtiKWS"), tr("Line # "+QString::number(iRow+1)+": check transmission!"));
            
            //+++ Progress +++
            progress.setProgress( iRow );
            if ( progress.wasCanceled() ) break;
            continue;
            
        }
        else status=status+">>>  Transmission="+QString::number(trans,'f',3)+"  ";
        
        
        //+++ transmission-Buffer check
        transBuffer=1.0;
        if (indexTrBuffer>=0)
        {
            if (subtractBuffer)
            {
                //+++ transmission check
                transBuffer=w->text(iRow,indexTrBuffer).toDouble();
                if (transBuffer<=0.0 || transBuffer>2.0)
                {
                    w->setText(iRow,indexTrBuffer,"Check!!!");
                    QMessageBox::warning(this,tr("QtiKWS"), tr("Line # "+QString::number(iRow+1)+": check Buffer!"));
                    //+++ Progress +++
                    progress.setProgress( iRow );
                    if ( progress.wasCanceled() ) break;
                    continue;
                }
            }
        }
        
        //+++ fraction buffer
        fractionBuffer=0.0;
        if (indexBufferFraction>=0)
        {
            if (subtractBuffer)
            {
                //+++ transmission check
                fractionBuffer=w->text(iRow,indexBufferFraction).toDouble();
                if (fractionBuffer<0.0)
                {
                    toResLogAll("DAN", "Fraction of Buffer is negative :: "+QString::number(iRow+1),this);
                }
            }
        }
        
        //+++ thickness check
        thickness=w->text(iRow,indexThickness).toDouble();
        if (thickness<=0.0 || thickness>100.0)
        {
            thickness=0.1;
            w->setText(iRow,indexThickness,"Check!!!");
            QMessageBox::warning(this,tr("QtiKWS"), tr("Line # "+QString::number(iRow+1)+": check Thickness!"));
            //+++ Progress +++
            progress.setProgress( iRow );
            if ( progress.wasCanceled() ) break;
            continue;
        }
        else status=status+">>>  Thickness="+QString::number(thickness,'f',3)+"  ";
        
        //+++ absolute factor check
        double abs0=scale*w->text(iRow,indexFactor).toDouble();
        if(thickness!=0) abs0/=thickness;
        
        if (abs0<=0)
        {
            w->setText(iRow,indexFactor,"check!!!");
            QMessageBox::warning(this,tr("QtiKWS"), tr("Line # "+QString::number(iRow+1)+": check Abs.Factor!"));
            //+++ Progress +++
            progress.setProgress( iRow );
            if ( progress.wasCanceled() ) break;
            continue;
        }
        else status=status+">>>  Abs.Factor="+QString::number(abs0,'e',4)+"  ";
        
        //+++
        if (trans!=0.0) abs=abs0/trans;
        if (transBuffer!=0.0) absBuffer=abs0/transBuffer;
        
        //+++ X-center check
        Xcenter=w->text(iRow,indexXC).toDouble();
        status=status+">>>  X-center="+QString::number(Xcenter,'e',4)+"  "; // 2013-09-18
        
        Xcenter-=1;
        
        Ycenter=w->text(iRow,indexYC).toDouble();
        
        //+++ Y-center check
        status=status+">>>  Y-center="+QString::number(Ycenter,'e',4)+"  "; // 2013-09-18
        Ycenter-=1;
        
        //+++ Sensitivity Error
        gsl_matrix_add(ErrMatrix, sensErr);
        
        int iii,jjj;
        double err2, Isample, Ibc, Iec;
        for (iii=0;iii<MD;iii++) for (jjj=0;jjj<MD;jjj++)
        {
            //+++
            Isample=gsl_matrix_get(Sample,iii,jjj);
            err2=Isample;       //+++
            Isample*=Isample;
            Isample*=gsl_matrix_get(SampleErr,iii,jjj);
            //+++
            Iec=gsl_matrix_get(EC,iii,jjj);
            err2 -= (trans*Iec);        //+++
            Iec*=Iec;
            Iec*=trans*trans;
            Iec*=gsl_matrix_get(ECErr,iii,jjj);
            //+++
            Ibc=gsl_matrix_get(BC,iii,jjj);
            if (Iec>0.0) err2 -= ( (1.0-trans) * Ibc ); else err2 -= Ibc;   //+++
            Ibc*=Ibc;
            if (Iec>0.0) Ibc*=(1.0-trans)*(1.0-trans);
            Ibc*=gsl_matrix_get(BCErr,iii,jjj);
            
            if ( err2 != 0.0 ) err2=1.0/err2; else err2=0.0;
            err2=err2*err2;
            err2*=(Isample+Iec+Ibc);
            
            gsl_matrix_set(ErrMatrix, iii, jjj, sqrt(
                                                     gsl_matrix_get(ErrMatrix,iii,jjj) + err2 ) );
            gsl_matrix_set(SampleErr, iii, jjj,
                           gsl_matrix_get(ErrMatrix,iii,jjj) * gsl_matrix_get(ErrMatrix,iii,jjj)
                           );
        }
        
        
        
        gsl_matrix_mul_elements(ErrMatrix,mask);
        gsl_matrix_mul_elements(SampleErr,mask);
        
        //+++ TODO :: Error of BUFFER
        
        
        //+++ Matrix-to-Matrix actions +++
        gsl_matrix_sub(Sample,BC);                      // Sample=Sample - BC
        
        // 2012 Time normalization BC
        if (checkFileNumber( NBC ) && checkBoxBCTimeNormalization->isChecked() &&  ECexist )
        {
            readMatrixCorTimeNormalizationOnly( NBC, BC );
            
            //Normalization constant
            double TimeSample=spinBoxNorm->value();
            double ttime=readDuration( NEC );
            if (ttime>0.0) TimeSample/=ttime; else TimeSample=0.0;
            
            double NormSample=readDataNormalization(NEC);
            
            if (TimeSample>0) NormSample/=TimeSample; else NormSample=0;
            
            gsl_matrix_scale(BC,NormSample);      // EB=T*EB
        }
        
        gsl_matrix_sub(EC,BC);                          // EC=EC - BC
        
        
        if (subtractBuffer)
        {
            if (checkFileNumber( NBC ) && checkBoxBCTimeNormalization->isChecked() &&  ECexist )
            {
                readMatrixCorTimeNormalizationOnly( NBC, BC );
                
                //Normalization constant
                double TimeSample=spinBoxNorm->value();
                double ttime=readDuration( Nbuffer );
                if (ttime>0.0) TimeSample/=ttime; else TimeSample=0.0;
                
                double NormSample=readDataNormalization(Nbuffer);
                
                if (TimeSample>0) NormSample/=TimeSample; else NormSample=0;
                
                gsl_matrix_scale(BC,NormSample);      // EB=T*EB
            }
            gsl_matrix_sub(Buffer,BC);    //Buffer=Buffer - BC
        }
        
        double Xc, Yc;
        readCenterfromMaskName( maskName, Xc, Yc, MD );
        
        
        if (trans<1.0 && trans>0.0 && checkBoxParallaxTr->isChecked())
        {
            double Detector=readDataD( w->text(iRow,indexSample)); // [cm]
            transmissionThetaDependenceTrEC(EC, Xc, Yc, Detector, trans);
        }
        
        gsl_matrix_scale(EC,trans);                             // EC=T*EC
        if (ECexist) gsl_matrix_sub(Sample,EC);         // Sample=Sample  - EC
        
        if (subtractBuffer)
        {
            gsl_matrix_scale(EC,transBuffer/trans);    // EC=Tbuffer*EC
            if (ECexist) gsl_matrix_sub(Buffer,EC);    // Buffer=Buffer  - EC
        }
        
        
        gsl_matrix_mul_elements(Sample,mask);
        if (subtractBuffer) gsl_matrix_mul_elements(Buffer,mask);
        
        
        
        //+++ Paralax Correction
        if (checkBoxParallax->isChecked() || checkBoxParallaxTr->isChecked())
        {
            double Detector=readDataD( w->text(iRow,indexSample)); // [cm]
            
            parallaxCorrection(Sample, Xc, Yc, Detector, trans);
            
            if (subtractBuffer)
            {
                double Detector=readDataD( w->text(iRow,indexBuffer)); // [cm]
                parallaxCorrection(Buffer, Xc, Yc, Detector, transBuffer);
                
            }
        }
        
        if (subtractBuffer)
        {
            gsl_matrix_scale(Buffer,fractionBuffer*absBuffer/abs);
            gsl_matrix_sub(Sample,Buffer);
        }
        
        
        if (comboBoxACmethod->currentItem()==3)
        {
            double normalization=readDataNormalization( w->text(iRow,indexSample) );
            if (normalization>0) gsl_matrix_scale(Sample,1/normalization);
        }
        else
        {
            gsl_matrix_scale(Sample,abs);
        }
        
        
        
        //+++ Sensitivity correction
        if (subtractBuffer && bufferAsSens)
        {
            if (indexUseSensBufferLocal<0 || w->text(iRow, indexUseSensBufferLocal)=="yes")
            {
                double Isample, Ibuffer;
                int numberPixels=0;
                double summBufferSens=0;
                
                
                for (iii=0;iii<MD;iii++) for (jjj=0;jjj<MD;jjj++)
                {
                    if (gsl_matrix_get(mask,iii,jjj)>0)
                    {
                        numberPixels++;
                        Isample= gsl_matrix_get(Sample,iii,jjj);
                        Ibuffer= gsl_matrix_get(Buffer,iii,jjj);
                        if (Ibuffer>0)
                        {
                            Isample/=Ibuffer;
                        }
                        summBufferSens+=Ibuffer*gsl_matrix_get(sens,iii,jjj);
                        gsl_matrix_set(Sample,iii,jjj,Isample);
                    }
                }
                gsl_matrix_scale(Sample,summBufferSens/numberPixels);
            }
            else gsl_matrix_mul_elements(Sample,sens);
        }
        else gsl_matrix_mul_elements(Sample,sens);
        
        
        if (indexBackgroundConst>0)
        {
            for (iii=0;iii<MD;iii++) for (jjj=0;jjj<MD;jjj++)
            {
                if (gsl_matrix_get(mask,iii,jjj)>0)
                {
                    gsl_matrix_set(Sample,iii,jjj,gsl_matrix_get(Sample,iii,jjj)-BackgroundConst);
                }
            }
        }
        
        //+++ Masking of  Negative Points +++
        if (checkBoxMaskNegative->isChecked())
        {
            for (iii=0;iii<MD;iii++) for (jjj=0;jjj<MD;jjj++)
            {
                if (gsl_matrix_get(Sample,iii,jjj)<=0)
                {
                    gsl_matrix_set(Sample,iii,jjj,0.0);
                    gsl_matrix_set(mask,iii,jjj,0.0);
                    gsl_matrix_set(sens,iii,jjj,0.0);
                    
                }
            }
        }
        
        // 2017 ...
        matrixConvolusion(Sample,mask,MD);
        
        QString nameQI = w->text(iRow,indexSample);  //  file number or name as name
        if(lineEditWildCard->text().contains("#")) nameQI=nameQI+"-"+w->text(iRow,indexInfo);  // plus info
        
        if (checkBoxNameAsTableName->isChecked())
        {
            nameQI=w->text(iRow,indexInfo);  // label as name
            if(lineEditWildCard->text().contains("#")) nameQI=nameQI+"-"+Nsample;  // label as name
            else nameQI+="-c"+w->text(iRow,indexCond);
            
        }
        
        //nameQI=nameQI.replace("_", "-");
        nameQI=nameQI.simplifyWhiteSpace();
        nameQI=nameQI.replace(" ", "-").replace("/", "-").replace("_", "-").replace(",", "-").replace(".", "-").remove("%");
        
        nameQI=dataSuffix+"-"+nameQI;
        
        
        //+++ Ext
        QString currentExt=lineEditFileExt->text().remove(" ");
        if(currentExt!="") currentExt+="-";
        
        
        //+++   Open Reduced Matrix in Project
        if (radioButtonOpenInProject->isChecked() && button=="I-x-y")
        {
            QString matrixOutName="I-"+currentExt+nameQI;
            if (!checkBoxRewriteOutput->isChecked())
            {
                matrixOutName+="-v-";
                matrixOutName=app(this)->generateUniqueName(matrixOutName);
            }
            
            
            if (radioButtonXYdimQ->isChecked())
            {
                double detdist  = 100.0*w->text(iRow,indexD).toDouble();  //sample-to-detector distance
                double lambda = w->text(iRow,indexLam).toDouble();
                double pixel  = lineEditPS->text().toDouble();
                double pixelAsymetry  = lineEditAsymetry->text().toDouble();
                if (pixelAsymetry<=0) pixelAsymetry=1.0;
                
                if(detdist!=0)
                {
                    
                    double xs=4.0*M_PI/lambda*sin(0.5*atan((0.5-Xcenter)*pixel/detdist));
                    double xe=4.0*M_PI/lambda*sin(0.5*atan(((MD+0.5)-Xcenter)*pixel/detdist));
                    double ys=4.0*M_PI/lambda*sin(0.5*atan((0.5-Ycenter)*pixel*pixelAsymetry/detdist));
                    double ye=4.0*M_PI/lambda*sin(0.5*atan(((MD+0.5)-Ycenter)*pixelAsymetry*pixel/detdist));
                    
                    makeMatrixSymmetric(Sample,matrixOutName, label, MD, xs, xe, ys,ye);
                }
                else makeMatrixSymmetric(Sample,matrixOutName, label, MD);
                
            }
            else makeMatrixSymmetric(Sample,matrixOutName, label, MD);
        }
        
        //+++ Open Error Matrix in Project
        if (radioButtonOpenInProject->isChecked() && button=="dI-x-y")
        {
            makeMatrixSymmetric(ErrMatrix,"dI-"+currentExt+nameQI,label, MD);
        }
        
        //+++   Save Reduced Matrix to File
        if (!radioButtonOpenInProject->isChecked() && button=="I-x-y")
        {
            if (checkBoxSortOutputToFolders->isChecked())
            {
                QDir dd;
                if (!dd.cd(lineEditPathRAD->text()+"/ASCII-I"))
                {
                    dd.mkdir(lineEditPathRAD->text()+"/ASCII-I");
                }
                if (comboBoxIxyFormat->currentText().contains("Matrix")) saveMatrixToFile(lineEditPathRAD->text()+"/ASCII-I/I-"+currentExt+nameQI+"-"+comboBoxSel->currentText()+".DAT",Sample, MD);
                else
                {
                    double pixel  = lineEditPS->text().toDouble();
                    double pixelAsymetry  = lineEditAsymetry->text().toDouble();
                    double detdist  = 100.0*w->text(iRow,indexD).toDouble();  //sample-to-detector distance
                    double lambda = w->text(iRow,indexLam).toDouble();
                    
                    saveMatrixAsTableToFile(lineEditPathRAD->text()+"/ASCII-I/I-"+currentExt+nameQI+"-"+comboBoxSel->currentText()+".DAT", Sample,ErrMatrix, mask, MD, Xcenter, Ycenter, lambda, detdist, pixel, pixel*pixelAsymetry );
                }
            }
            else 
            {
                if (comboBoxIxyFormat->currentText().contains("Matrix")) saveMatrixToFile(lineEditPathRAD->text()+"/I-"+currentExt+nameQI+"-"+comboBoxSel->currentText()+".DAT",Sample, MD);
                else
                {
                    double pixel  = lineEditPS->text().toDouble();
                    double pixelAsymetry  = lineEditAsymetry->text().toDouble();
                    double detdist  = 100.0*w->text(iRow,indexD).toDouble();  //sample-to-detector distance
                    double lambda = w->text(iRow,indexLam).toDouble();
                    
                    saveMatrixAsTableToFile(lineEditPathRAD->text()+"/I-"+currentExt+nameQI+"-"+comboBoxSel->currentText()+".DAT", Sample,ErrMatrix, mask, MD, Xcenter, Ycenter, lambda, detdist, pixel, pixel*pixelAsymetry );
                }
            }
            
        }	
        
        //+++   Save Error Matrix to File				
        if (!radioButtonOpenInProject->isChecked() && button=="dI-x-y")
        {
            if (checkBoxSortOutputToFolders->isChecked())	
            {	QDir dd;
                if (!dd.cd(lineEditPathRAD->text()+"/ASCII-dI")) 
                {	
                    dd.mkdir(lineEditPathRAD->text()+"/ASCII-dI"); 			
                }
                saveMatrixToFile(lineEditPathRAD->text()+"/ASCII-dI/dI-"+currentExt+nameQI+"-"+comboBoxSel->currentText()+".DAT",ErrMatrix, MD);
            }
            else saveMatrixToFile(lineEditPathRAD->text()+"/dI-"+currentExt+nameQI+"-"+comboBoxSel->currentText()+".DAT",ErrMatrix, MD);
        }
        
        //+++++++++++++++RAD +++++++++++++++++
        // +++  Reading of some parameters +++
        Nsample=w->text(iRow,indexSample);
        
        double detdist  = 100.0*w->text(iRow,indexD).toDouble();  //sample-to-detector distance
        double C = 100.0*w->text(iRow,indexC).toDouble();
        double lambda = w->text(iRow,indexLam).toDouble();
        double deltaLambda = readDeltaLambda( Nsample );
        
        double pixel  = lineEditResoPixelSize->text().toDouble();
        double binning=comboBoxBinning->currentText().toDouble();
        
        double pixelAsymetry  = lineEditAsymetry->text().toDouble();
        if (pixelAsymetry<=0) pixelAsymetry=1.0;
        
        double r2=readDataR2( Nsample );
        double r1=readDataR1( Nsample );	
        
        
        //+++ Standart radial averiging +++
        if ( button=="I-Q" && radioButtonRadStd->isChecked())
        {
            if (comboBoxMode->currentText().contains("(MS)")) 
            {
                double angle=double(spinBoxMCshiftAngle->value())/180.0*M_PI;
                radUniStandartLogMSmode ( MD, Sample, SampleErr, mask, Xcenter, Ycenter, nameQI, C,  lambda, deltaLambda, detdist, pixel*binning, r1, r2, label, readDataF( Nsample ),pixelAsymetry,angle);
            }
            else radUniStandartLog ( MD, Sample, SampleErr, mask, Xcenter, Ycenter,
                                    nameQI, C,  lambda, deltaLambda, detdist, pixel*binning, r1, r2, label, readDataF( Nsample ), pixelAsymetry);	
            mergedTemplate<<nameQI;
        }
        
        //+++ HF radial averiging +++
        if (button=="I-Q" && radioButtonRadHF->isChecked())
        {
            if (comboBoxMode->currentText().contains("(MS)")) 
            {
                double angle=double(spinBoxMCshiftAngle->value())/180.0*M_PI;
                radUniStandartLogMSmode ( MD, Sample, SampleErr, mask, Xcenter, Ycenter, nameQI, C,  lambda, deltaLambda, detdist, pixel*binning, r1, r2, label, readDataF( Nsample ),pixelAsymetry,angle);
            }
            else radUniHF ( MD, Sample, SampleErr, mask, Xcenter, Ycenter,
                           nameQI, C,  lambda, deltaLambda, detdist, pixel*binning, r1, r2, label, readDataF( Nsample ),pixelAsymetry);  
            mergedTemplate<<nameQI;
        }
        
        //+++ Hosisontal Slice +++		
        if (button=="I-Qx")
        {
            horizontalSlice( MD, Sample, SampleErr, mask, Xcenter, Ycenter,
                            nameQI, C,  lambda, deltaLambda, detdist, pixel*binning, r1, r2, label);
        }
        
        //+++ Vertical Slice +++						
        if (button=="I-Qy")
        {
            verticalSlice( MD, Sample, SampleErr, mask, Xcenter, Ycenter,
                          nameQI, C,  lambda, deltaLambda, detdist, pixel*binning*pixelAsymetry, r1, r2, label);
        }
        
        //+++ Polarv Coordinates
        if (button=="I-Polar")
        {
            radUniPolar(MD, Sample, mask, Xcenter, Ycenter, nameQI, lambda, detdist, pixel*binning, pixelAsymetry );
        }
        
        //+++ SIGMA [x,y]
        if (button=="Sigma-x-y")
        {
            sigmaMatrix(MD, mask, Xcenter, Ycenter, "Sigma-"+currentExt+nameQI, lambda, deltaLambda, C, detdist, pixel*binning, r1,r2 );
        }
        
        //+++ Q [x,y]
        if (button=="Q-x-y")
        {
            MatrixQ(MD, mask, Xcenter, Ycenter, "Q-"+currentExt+nameQI, lambda, detdist, pixel*binning );
        }
        //+++ dQ [x,y]
        if (button=="dQ-x-y")
        {
            dQmatrix(MD, mask, Xcenter, Ycenter, "dQ-"+currentExt+nameQI, lambda, detdist, pixel*binning );
        }
        
        //+++ Set Status +++
        w->setText(iRow,indexStatus,status);
        
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        toResLogAll("DAN",status,this);
        
        //+++ Progress +++
        progress.setProgress( iRow );
        if ( progress.wasCanceled() ) break;   		
    }
    
    
    saveSettingsSlot();
    
    if ( button=="I-Q" && checkBoxMergingTable->isChecked() ) //&& !checkSelection)
    {
        generateMergingTable(w, mergedTemplate);
    }	
    
    //+++ Clean Memory +++
    gsl_matrix_free(Sample);
    gsl_matrix_free(SampleErr);
    gsl_matrix_free(Buffer);
    gsl_matrix_free(BufferErr);
    gsl_matrix_free(EC);
    gsl_matrix_free(ECErr);
    gsl_matrix_free(BC);
    gsl_matrix_free(BCErr);
    gsl_matrix_free(mask);
    gsl_matrix_free(sens);
    gsl_matrix_free(sensErr);
    gsl_matrix_free(ErrMatrix);
    
    
    scriptColList.clear();
    mergedTemplate.clear();
    listMask.clear();
    listSens.clear();
    
    
    QString wwName="";
    if (ww) wwName=ww->name();
    
    if (radioButtonOpenInProject->isChecked() && checkBoxSortOutputToFolders->isChecked())
    {
        app(this)->folders->setCurrentItem ( cf->folderListItem() );
        app(this)->changeFolder(cf,true);	
        app(this)->folders->setFocus();
        
        if ( button=="I-Q" && checkBoxMergingTable->isChecked() && wwName==w->name())
        {
            app(this)->activateWindow(w);
            if (maximizedWW)  w->showMaximized();
        }
        else
        {
            if (ww && wwName!="") app(this)->activateWindow(ww);
            if (maximizedWW && ww) ww->showMaximized();
        }
    }
    
    app(this)->ws->blockSignals ( false );    
    app(this)->ws->show();    
}


//+++ SD:: RAD-UniStd-log
void dan16::radUniStandartLogMSmode
(
 int md,
 gsl_matrix *Sample, gsl_matrix *SampleErr, gsl_matrix *mask,
 double Xcenter, double Ycenter,
 QString &sampleMatrix,
 double C, double lambda, double deltaLambda, double detdist, double detelem, double r1, double r2,
 QString label, double numberF, double pixelAsymetry, double angle
 )
{
    //+++
    int numRowsOut=0;
    int numAllQ=0;
    QValueList<int> negativeNumbersPosition;
    
    //+++ Presentation
    QString CurrentLabel=comboBoxSelectPresentation->currentText();
    
    //+++ Ext
    QString currentExt=lineEditFileExt->text().remove(" ");
    if(currentExt!="") currentExt+="-";
    
    //+++ Table Name
    QString tableOUT;
    tableOUT="QI-MS-NC-";
    if (CurrentLabel!="QI")tableOUT=tableOUT+CurrentLabel+"-";
    tableOUT=tableOUT+sampleMatrix;
    tableOUT=tableOUT.remove("-SM");
    tableOUT=tableOUT.replace("QI-","QI-"+currentExt);
    
    QString tableOUTms=tableOUT;
    tableOUTms=tableOUTms.replace("-MS-NC-","-MS-MC-");
    tableOUTms.remove("-SM");
    
    
    
    if (!checkBoxRewriteOutput->isChecked())
    {
        tableOUT+="-";
        tableOUT=app(this)->generateUniqueName(tableOUT);
        tableOUTms+="-";
        tableOUTms=app(this)->generateUniqueName(tableOUTms);
    }
    
    if (sansTab->currentPageIndex()==1 && comboBoxCheck->currentText().contains("raw-QI"))
    {
        tableOUT=  "raw-QI---MS-NC";
        tableOUTms="raw-QI---MS-MC";
    }
    else if (sansTab->currentPageIndex()==1 )
    {
        tableOUT= "raw-"+tableOUT;
        tableOUTms="raw-"+tableOUTms;
    }
    
    //+++ RAD-table
    Table *wOut;
    Table *wOutms;
    
    bool tableExist=checkTableExistence(tableOUT);
    bool tableExistms=checkTableExistence(tableOUTms);
    
    if (radioButtonOpenInProject->isChecked())
    {
        int colnumberInc=0;
        if (comboBox4thCol->currentItem()<2)  colnumberInc=1;
        if (comboBox4thCol->currentItem()==3)  colnumberInc=2;
        
        QWidgetList* tableList=app(this)->tableList();
        
        
        if (tableExist && checkBoxRewriteOutput->isChecked())
        {
            //+++ Find table
            for (int i=0;i<(int)tableList->count();i++)
            {
                if (tableList->at(i) && tableList->at(i)->name()==tableOUT) wOut=(Table *)tableList->at(i);
            }
            wOut->setNumRows(0);
            wOut->setNumCols(3+colnumberInc);
        }
        else
        {
            wOut=app(this)->newHiddenTable(tableOUT,CurrentLabel, 0, 3+colnumberInc);
        }
        
        
        
        if (tableExistms && checkBoxRewriteOutput->isChecked())
        {
            //+++ Find table
            for (int i=0;i<(int)tableList->count();i++)
            {
                if (tableList->at(i) && tableList->at(i)->name()==tableOUTms) wOutms=(Table *)tableList->at(i);
            }
            wOutms->setNumRows(0);
            wOutms->setNumCols(3+colnumberInc);
        }
        else
        {
            wOutms=app(this)->newHiddenTable(tableOUTms,CurrentLabel, 0, 3+colnumberInc);
        }
        
        
        app(this)->setListViewLabel(wOut->name(), label);
        app(this)->updateWindowLists(wOut);
        
        app(this)->setListViewLabel(wOutms->name(), label);
        app(this)->updateWindowLists(wOutms);
        
        wOut->setColName(0,"Q");
        wOut->setColName(1,"I"); wOut->setColComment(1, label);
        wOut->setColName(2,"dI");
        wOut->setWindowLabel(label);
        
        wOut->setColPlotDesignation(2,Table::yErr);
        wOut->setHeaderColType();
        
        wOut->setNumericFormat(2, 8, true);
        
        wOutms->setColName(0,"Q");
        wOutms->setColName(1,"I"); wOutms->setColComment(1, label);
        wOutms->setColName(2,"dI");
        wOutms->setWindowLabel(label);
        
        wOutms->setColPlotDesignation(2,Table::yErr);
        wOutms->setHeaderColType();
        
        wOutms->setNumericFormat(2, 8, true);
        
        
        if (comboBox4thCol->currentItem()==0)
        {
            wOut->setColName(3,"Sigma");
            wOut->setColPlotDesignation(3,Table::xErr);
            wOutms->setColName(3,"Sigma");
            wOutms->setColPlotDesignation(3,Table::xErr);
        }
        else if (comboBox4thCol->currentItem()==1)
        {
            wOut->setColName(3,"dQ");
            wOut->setColPlotDesignation(3,Table::xErr);
            wOutms->setColName(3,"dQ");
            wOutms->setColPlotDesignation(3,Table::xErr);
            
        }
        else if (comboBox4thCol->currentItem()==3)
        {
            wOut->setColName(3,"dQ");
            wOut->setColPlotDesignation(3,Table::xErr);
            wOut->setColName(4,"Sigma");
            wOut->setColPlotDesignation(4,Table::xErr);
            wOut->setColPlotDesignation(4,Table::xErr);
            
            wOutms->setColName(3,"dQ");
            wOutms->setColPlotDesignation(3,Table::xErr);
            wOutms->setColName(4,"Sigma");
            wOutms->setColPlotDesignation(4,Table::xErr);
            wOutms->setColPlotDesignation(4,Table::xErr);
        }
        
        wOut->setHeaderColType();
        wOutms->setHeaderColType();
        
    }
    
    //------------------------------------
    // calculation of radial averaging
    //------------------------------------
    
    
    //+++ MAXIMAL RADIUS
    double rmax =  sqrt( (Xcenter)*(Xcenter) + pixelAsymetry*pixelAsymetry*( Ycenter)*(Ycenter));
    rmax = GSL_MAX(rmax, (sqrt((md - 1 -
                                Xcenter)*(md - 1 - Xcenter) + pixelAsymetry*pixelAsymetry*(Ycenter)*(Ycenter))));
    rmax = GSL_MAX(rmax,sqrt((md - 1 -
                              Xcenter)*(md - 1 - Xcenter) + pixelAsymetry*pixelAsymetry*(md - 1 - Ycenter)*(md - 1 - Ycenter)));
    rmax = GSL_MAX(rmax,sqrt(( Xcenter)*(Xcenter) + pixelAsymetry*pixelAsymetry*(md - 1 - Ycenter)*(md - 1 - Ycenter)));
    
    int iii,jjj;
    
    int nTotal=(int)(rmax+0.5);
    
    double *II=new double[nTotal];
    double *dII=new double[nTotal];
    
    double *IIms=new double[nTotal];
    double *dIIms=new double[nTotal];
    
    int *nn=new int[nTotal];
    
    double offsetCh;
    
    int ir;
    
    //+++ cleanning
    for(ir=0;ir<nTotal;ir++)
    {
        II[ir]= 0;
        dII[ir]= 0;
        IIms[ir]= 0;
        dIIms[ir]= 0;
        nn[ir]=0;
    }
    
    int nShift=0;
    
    
    for(ir=0;ir<nTotal;ir++)
    {
        
        //    double length=2*M_PI*ir;
        
        double length=2*M_PI*ir;
        if (pixelAsymetry<1.0 && pixelAsymetry>0.0)
        {
            length= M_PI*ir*( 3* (1 + 1/pixelAsymetry) - sqrt((3+1/pixelAsymetry)*(1+3/pixelAsymetry))); // 2015-10 :: Ramanujan approach
        }
        int numPhiSteps=(int)(length+0.5);
        
        double phiSteps=1.0;
        if (numPhiSteps>1) phiSteps=2*M_PI/numPhiSteps;
        int xPhi, yPhi;
        
        int realNumPhiSteps=0;
        
        for(int iPhi=0;iPhi<numPhiSteps;iPhi++)
        {
            xPhi=(int)(ir*cos(-iPhi*phiSteps+M_PI/2.0+angle)+Xcenter+0.5);
            yPhi=(int)(ir/pixelAsymetry*sin(-iPhi*phiSteps+M_PI/2.0+angle)+Ycenter+0.5);
            
            if (xPhi>=0 && xPhi<md && yPhi>=0 && yPhi<md && gsl_matrix_get(mask,yPhi,xPhi)>0)  realNumPhiSteps++;
        }
        
        if (realNumPhiSteps<4) {nShift++;continue;}
        
        if (ir==nShift+spinBoxMCcheckQ->value())
        {
            std::cout<<"\n MS-mode cross-check :: file: "<<tableOUTms<<"--- #: "<<ir-nShift<<"\n\n";
            std::cout<<"xPhi"<<"\t\t"<<"yPhi"<<"\t\t""sin2phi"<<"\t\t"<<"Intensity"<<"\n";
        }
        
        double *sin2phi=new double[realNumPhiSteps];
        double *intensityPhi=new double[realNumPhiSteps];
        double *dIntensityPhi=new double[realNumPhiSteps];
        
        realNumPhiSteps=0;
        
        for(int iPhi=0; iPhi<numPhiSteps; iPhi++)
        {
            xPhi=(int)(ir*cos(-iPhi*phiSteps+M_PI/2.0+angle)+Xcenter+0.5);
            yPhi=(int)(ir/pixelAsymetry*sin(-iPhi*phiSteps+M_PI/2.0+angle)+Ycenter+0.5);
            
            if (xPhi>=0 && xPhi<md && yPhi>=0 && yPhi<md && gsl_matrix_get(mask,yPhi,xPhi)>0)
            {
                sin2phi[realNumPhiSteps]=sin(-iPhi*phiSteps)*sin(-iPhi*phiSteps);
                intensityPhi[realNumPhiSteps]=gsl_matrix_get(Sample,yPhi,xPhi);
                
                dIntensityPhi[realNumPhiSteps]=1;//sqrt(gsl_matrix_get(SampleErr,yPhi,xPhi))*fabs(gsl_matrix_get(Sample,yPhi,xPhi));
                
                if (ir==nShift+spinBoxMCcheckQ->value()) std::cout<<"\n"<<QString::number(xPhi,'E',8)<<"\t"<<QString::number(yPhi,'E',8)<<"\t"<<QString::number(sin2phi[realNumPhiSteps],'E',8)<<"\t"<<QString::number(intensityPhi[realNumPhiSteps],'E',8);
                
                realNumPhiSteps++;
            }
        }
        if (ir==nShift+spinBoxMCcheckQ->value()) std::cout<<"\n";
        double c0, c1, cov00, cov01, cov11, chisq;
        gsl_fit_wlinear (sin2phi, 1, dIntensityPhi, 1, intensityPhi, 1, realNumPhiSteps,
                         &c0, &c1, &cov00, &cov01, &cov11,
                         &chisq);
        
        nn[ir]=1;
        II[ir]=c0;
        dII[ir]=chisq/(realNumPhiSteps-2)*cov00;
        IIms[ir]=c1;
        dIIms[ir]=chisq/(realNumPhiSteps-2)*cov11;
        
        delete[] sin2phi;
        delete[] intensityPhi;
        delete[] dIntensityPhi;
    }
    
    
    // new log scale
    double stepProg=lineEditCommonRatio->text().toDouble();
    
//    int mergeLinear=int(stepProg); if (mergeLinear<1) mergeLinear=1; // 2017
    
//    stepProg=stepProg-double(mergeLinear)+1.0; // 2017
    
     if (stepProg<1.0) stepProg=1.0;
     if (stepProg>1.2) stepProg=1.2;
    
    double IIlocal, dIIlocal, IIlocalms, dIIlocalms;
    int nnLocal;
    
    int *mergedPoints=new int[nTotal];
    
    int i=0;
    while(i<nTotal)
    {
        double tm=pow(stepProg,i);
        int plusPoints=int(tm);
        if (tm-int(tm)>0.5) plusPoints++;
        
        if (i+plusPoints>=nTotal) plusPoints=nTotal-i;
        
        
        IIlocal=0.0;
        dIIlocal=0.0;
        IIlocalms=0.0;
        dIIlocalms=0.0;
        nnLocal=0;
        for (int ii=0;ii<plusPoints;ii++)
        {
            nnLocal+=nn[i+ii];
            IIlocal+=II[i+ii];
            dIIlocal+=dII[i+ii];
            IIlocalms+=IIms[i+ii];
            dIIlocalms+=dIIms[i+ii];
            
            mergedPoints[i+ii]=plusPoints;
            II[i+ii]=0.0;
            dII[i+ii]=0;
            IIms[i+ii]=0.0;
            dIIms[i+ii]=0;
        }
        
        mergedPoints[i]=plusPoints;
        nn[i]=nnLocal;
        II[i]=IIlocal;
        dII[i]=dIIlocal;
        IIms[i]=IIlocalms;
        dIIms[i]=dIIlocalms;
        
        i=i+plusPoints;
    }
    
    
    // +++ rad
    
    double qr, avg, avge,avgms, avgems, sig, dq;
    
    QString streamSTR="";
    QString streamSTRms="";
    
    //+++ new Skip Points
    int skipFirst=spinBoxRemoveFirst->value();
    int skipLast=spinBoxRemoveLast->value();
    
    for(ir=0;ir<nTotal;ir++)
    {
        if (nn[ir]>=1)
        {
            qr  = 4.0*M_PI/lambda *
            sin(0.5*atan((2*ir+mergedPoints[ir]-1)/2.0*detelem/detdist));  // test
            
            
            avg = II[ir] / nn[ir];
            avge=dII[ir] / nn[ir];
            
            avgms = IIms[ir] / nn[ir];
            avgems=dIIms[ir] / nn[ir];
            
            sig= sigmaQmerged( qr, detdist, C, lambda, deltaLambda, r1, r2, mergedPoints[ir]);
            dq=dQ(qr, numberF, mergedPoints[ir]*ir*(pixelAsymetry+1)/2*detelem, detdist, detelem );
            
            //
            double Q,I,dI,Ims,dIms;
            double QQQ, III, dIII, IIIms, dIIIms;
            
            Q=qr;
            I=avg;
            dI=avge;
            
            Ims=avgms;
            dIms=avgems;
            
            
            QQQ=qr;
            III=avg;
            dIII=avge;
            IIIms=avgms;
            dIIIms=avgems;
            
            // * ****** Change of Presentation  *****************************
            if (CurrentLabel!="QI")
            {
                if (CurrentLabel=="Guinier")
                {
                    QQQ=Q*Q;
                    III=log(fabs(I));
                    if (I!=0) dIII=dI/fabs(I);
                    IIIms=log(fabs(Ims));
                    if (Ims!=0) dIIIms=dIms/fabs(Ims);
                }
                else if (CurrentLabel=="Zimm")
                {
                    QQQ=Q*Q;
                    if (I!=0) III=1/I; else III=0;
                    if (I!=0) dIII=dI/I/I; else dIII=0;
                    
                    if (Ims!=0) IIIms=1/Ims; else IIIms=0;
                    if (Ims!=0) dIIIms=dIms/Ims/Ims; else dIIIms=0;
                }
                else if (CurrentLabel=="Porod")
                {
                    QQQ=log10(Q);
                    III=log10(fabs(I));
                    if (I!=0) dIII=dI/fabs(I)/log(10.0);
                    IIIms=log10(fabs(Ims));
                    if (Ims!=0) dIII=dI/fabs(Ims)/log(10.0);
                }
                else if (CurrentLabel=="Porod2")
                {
                    QQQ=Q*Q;
                    III=I*pow(Q,4);
                    dIII=dI*pow(Q,4);
                    IIIms=Ims*pow(Q,4);
                    dIIIms=dIms*pow(Q,4);
                }
                else if (CurrentLabel=="logQ")
                {
                    QQQ=log10(Q);
                }
                else if (CurrentLabel=="logI")
                {
                    III=log10(fabs(I));
                    if (I!=0) dIII=dI/fabs(I)/log(10.0);
                    IIIms=log10(fabs(Ims));
                    if (Ims!=0) dIIIms=dIms/fabs(Ims)/log(10.0);
                }
                else if (CurrentLabel=="Debye")
                {
                    QQQ=Q*Q;
                    if (I!=0) III=1/sqrt(fabs(I)); else III=0;
                    if (I!=0) dIII=dI/pow(fabs(I),1.5); else dIII=0;
                    if (Ims!=0) IIIms=1/sqrt(fabs(Ims)); else IIIms=0;
                    if (Ims!=0) dIIIms=dIms/pow(fabs(Ims),1.5); else dIIIms=0;
                }
                else if (CurrentLabel=="1Moment")
                {
                    III=Q*I;
                    dIII=Q*dI;
                    IIIms=Q*Ims;
                    dIIIms=Q*dIms;
                }
                else if (CurrentLabel=="2Moment")
                {
                    III=Q*Q*I;
                    dIII=Q*Q*dI;
                    IIIms=Q*Q*Ims;
                    dIIIms=Q*Q*dIms;
                }
                else if (CurrentLabel=="Kratky")
                {
                    III=Q*Q*I;
                    dIII=Q*Q*dI;
                    IIIms=Q*Q*Ims;
                    dIIIms=Q*Q*dIms;
                }
                else if (CurrentLabel=="GuinierRod")
                {
                    QQQ=Q*Q;
                    III=log(fabs(I*Q));
                    if (I!=0) dIII=Q*fabs((dI/I)); else III=0;
                    IIIms=log(fabs(Ims*Q));
                    if (Ims!=0) dIIIms=Q*fabs((dIms/Ims)); else IIIms=0;
                }
                else if (CurrentLabel=="GuinierPlate")
                {
                    QQQ=Q*Q;
                    III=log(fabs(I*Q*Q));
                    if (I!=0) dIII=Q*Q*fabs(dI/I); else III=0;
                    IIIms=log(fabs(Ims*Q*Q));
                    if (Ims!=0) dIIIms=Q*Q*fabs(dIms/Ims); else IIIms=0;
                }
                
            }
            
            //+++  To File Q-I-dI-?
            if (radioButtonFile->isChecked())
            {
                
                if (numAllQ>=skipFirst)
                {
                    if ( !( (avg<=0 || avgms<=0) && checkBoxMaskNegativeQ->isChecked()) )
                    {
                        if (comboBox4thCol->currentItem()==0)
                        {
                            streamSTR    +=      QString::number(QQQ,'E',8)
                            +"   "+QString::number(III,'E',8)
                            +"   "+QString::number(dIII,'E',8)
                            +"   "+QString::number(sig,'E',8)+"\n";
                            streamSTRms    +=      QString::number(QQQ,'E',8)
                            +"   "+QString::number(IIIms,'E',8)
                            +"   "+QString::number(dIIIms,'E',8)
                            +"   "+QString::number(sig,'E',8)+"\n";
                        }
                        else if (comboBox4thCol->currentItem()==1)
                        {
                            streamSTR    +=      QString::number(QQQ,'E',8)
                            +"   "+QString::number(III,'E',8)
                            +"   "+QString::number(dIII,'E',8)
                            +"   "+QString::number(dq,'E',8)+"\n";
                            streamSTRms    +=      QString::number(QQQ,'E',8)
                            +"   "+QString::number(IIIms,'E',8)
                            +"   "+QString::number(dIIIms,'E',8)
                            +"   "+QString::number(dq,'E',8)+"\n";
                        }
                        else if (comboBox4thCol->currentItem()==2)
                        {
                            streamSTR	+=      QString::number(QQQ,'E',8)
                            +"   "+QString::number(III,'E',8)
                            +"   "+QString::number(dIII,'E',8)+"\n" ;
                            streamSTRms	+=      QString::number(QQQ,'E',8)
                            +"   "+QString::number(IIIms,'E',8)
                            +"   "+QString::number(dIIIms,'E',8)+"\n" ;
                        }
                        else
                        {
                            streamSTR+=QString::number(QQQ,'E',8)
                            +"   "+QString::number(III,'E',8)
                            +"   "+QString::number(dIII,'E',8)
                            +"   "+QString::number(dq,'E',8)
                            +"   "+QString::number(sig,'E',8)+"\n";
                            streamSTRms	+=QString::number(QQQ,'E',8)
                            +"   "+QString::number(IIIms,'E',8)
                            +"   "+QString::number(dIIIms,'E',8)
                            +"   "+QString::number(dq,'E',8)
                            +"   "+QString::number(sig,'E',8)+"\n";
                        }
                        
                        numRowsOut++;
                    }
                    else negativeNumbersPosition<<numAllQ;
                }
                
                numAllQ++;
                
            }
            else
            {
                if (numAllQ>=skipFirst)
                {
                    if ( !((avg<=0 || avgms<=0) && checkBoxMaskNegativeQ->isChecked()) )
                    {
                        wOut->setNumRows(numRowsOut+1);
                        wOut->setText(numRowsOut,0,QString::number(QQQ,'E',8));
                        wOut->setText(numRowsOut,1,QString::number(III,'E',8));
                        wOut->setText(numRowsOut,2,QString::number(dIII,'E',8));
                        
                        wOutms->setNumRows(numRowsOut+1);
                        wOutms->setText(numRowsOut,0,QString::number(QQQ,'E',8));
                        wOutms->setText(numRowsOut,1,QString::number(IIIms,'E',8));
                        wOutms->setText(numRowsOut,2,QString::number(dIIIms,'E',8));
                        
                        
                        //+++ Sigma output +++
                        if (comboBox4thCol->currentItem()==0) {
                            wOut->setText(numRowsOut,3, QString::number(sig,'E',8));
                            wOutms->setText(numRowsOut,3, QString::number(sig,'E',8));
                        }
                        else if (comboBox4thCol->currentItem()==1){
                            wOut->setText(numRowsOut,3, QString::number(dq,'E',8));
                            wOutms->setText(numRowsOut,3, QString::number(dq,'E',8));
                        }
                        else if (comboBox4thCol->currentItem()==3){
                            wOut->setText(numRowsOut,3, QString::number(dq,'E',8));
                            wOut->setText(numRowsOut,4, QString::number(sig,'E',8));
                            wOutms->setText(numRowsOut,3, QString::number(dq,'E',8));
                            wOutms->setText(numRowsOut,4, QString::number(sig,'E',8));
                            
                        }
                        
                        numRowsOut++;
                    }
                    else negativeNumbersPosition<<numAllQ;
                }
                numAllQ++;
                
            }
        }
    }
    
    //+++ Calculate number last points 
    int scipLastReal=skipLast;
    
    if (skipLast>0) for (int i=1; i<=skipLast; i++)
    {
        if ( negativeNumbersPosition.findIndex( numAllQ-i )>=0 ) scipLastReal--;
    }
    
    //+++ remove last Points
    if (radioButtonOpenInProject->isChecked())
    {
        if (wOut->numRows()>=scipLastReal) wOut->setNumRows( wOut->numRows() - scipLastReal ); else wOut->setNumRows(0);
        if (wOutms->numRows()>=scipLastReal) wOutms->setNumRows( wOutms->numRows() -scipLastReal ); else wOutms->setNumRows(0);
        
        
        if (tableExist) wOut->notifyChanges();
        if (tableExistms) wOutms->notifyChanges();
        
        //+++ adjust cols
        for (int tt=0; tt<wOut->numCols(); tt++)
        {
            wOut->table()->adjustColumn (tt);
            wOut->table()->setColumnWidth(tt, wOut->table()->columnWidth(tt)+10); 
            wOutms->table()->adjustColumn (tt);
            wOutms->table()->setColumnWidth(tt, wOutms->table()->columnWidth(tt)+10); 
            
        }
        
        wOut->hide();
        wOutms->hide();
    }
    
    
    int findN, tempI;
    
    
    for (findN=0;findN<scipLastReal;findN++) {
        tempI=streamSTR.findRev("\n",-3);
        streamSTR.remove(tempI+1,streamSTR.length()-tempI+2);};  
    
    for (findN=0;findN<scipLastReal;findN++) {
        tempI=streamSTRms.findRev("\n",-3);
        streamSTRms.remove(tempI+1,streamSTRms.length()-tempI+2);};  
    
    if (!radioButtonOpenInProject->isChecked())
    {
        QFile f;
        
        QDir dd;
        
        QString asciiPath=lineEditPathRAD->text();
        
        if (checkBoxSortOutputToFolders->isChecked())	
        {	
            asciiPath+="/ASCII-QI-MS";
            asciiPath=asciiPath.replace("//","/");
            if (!dd.cd(asciiPath)) 
            {
                dd.mkdir(asciiPath); 	
                
            };
        }
        
        QString fname="QI-MS-NC-";
        if (CurrentLabel!="QI") fname=fname+CurrentLabel+"-";
        fname=fname+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT";
        fname=fname.remove("-SM");
        fname=fname.replace("QI-","QI-"+currentExt);
        
        fname=asciiPath+"/"+fname;
        
        f.setName( fname );
        if ( f.open( IO_WriteOnly ) )
        {
            QTextStream stream( &f );
            
            if(comboBoxSelectPresentation->currentItem()==0 && checkBoxASCIIheader->isChecked())
            {
                QString header;
                if (comboBox4thCol->currentItem()==0)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]       Sigma[1/A]\n";
                }
                else if (comboBox4thCol->currentItem()==1)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]          dQ[1/A]\n";
                }				
                else if (comboBox4thCol->currentItem()==2)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]\n";
                }
                else if (comboBox4thCol->currentItem()==3)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]          dQ[1/A]       Sigma[1/A]\n";
                }
                
                stream<<header;
            }
            stream<<streamSTR;
            
            f.close();
        }
    }
    
    if (!radioButtonOpenInProject->isChecked())
    {
        QFile f;
        
        QDir dd;
        
        QString asciiPath=lineEditPathRAD->text();
        
        if (checkBoxSortOutputToFolders->isChecked())	
        {	
            asciiPath+="/ASCII-QI-MS";
            asciiPath=asciiPath.replace("//","/");
            if (!dd.cd(asciiPath)) 
            {
                dd.mkdir(asciiPath); 	
                
            };
        }
        
        QString fname="QI-MS-MC-";
        if (CurrentLabel!="QI") fname=fname+CurrentLabel+"-";
        fname=fname+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT";
        fname=fname.remove("-SM");
        fname=fname.replace("QI-","QI-"+currentExt);
        fname=asciiPath+"/"+fname;
        
        f.setName( fname );
        if ( f.open( IO_WriteOnly ) )
        {
            QTextStream stream( &f );
            
            if(comboBoxSelectPresentation->currentItem()==0 && checkBoxASCIIheader->isChecked())
            {
                QString header;
                if (comboBox4thCol->currentItem()==0)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]       Sigma[1/A]\n";
                }
                else if (comboBox4thCol->currentItem()==1)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]          dQ[1/A]\n";
                }				
                else if (comboBox4thCol->currentItem()==2)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]\n";
                }
                else if (comboBox4thCol->currentItem()==3)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]          dQ[1/A]       Sigma[1/A]\n";
                }
                
                stream<<header;
            }
            stream<<streamSTRms;
            
            f.close();
        }
    }
    
    delete[] II;
    delete[] dII;
    delete[] IIms;
    delete[] dIIms;
    
    delete[] nn;
    delete[] mergedPoints;
    
    sampleMatrix=tableOUT;
}

//+++ SD:: RAD-UniStd-log
void dan16::radUniStandartLog
(
 int md,
 gsl_matrix *Sample, gsl_matrix *SampleErr, gsl_matrix *mask,
 double Xcenter, double Ycenter,
 QString &sampleMatrix,
 double C, double lambda, double deltaLambda, double detdist, double detelem, double r1, double r2,
 QString label, double numberF, double pixelAsymetry
 )
{
    //+++
    int numRowsOut=0;
    int numAllQ=0;
    QValueList<int> negativeNumbersPosition;
    
    //+++ Presentation
    QString CurrentLabel=comboBoxSelectPresentation->currentText();
    //+++ Ext
    QString currentExt=lineEditFileExt->text().remove(" ");
    if(currentExt!="") currentExt+="-";
    
    //+++ Table Name
    QString tableOUT;
    tableOUT="QI-";
    if (CurrentLabel!="QI")tableOUT=tableOUT+CurrentLabel+"-";
    tableOUT=tableOUT+sampleMatrix;
    tableOUT=tableOUT.replace("QI-", "QI-"+currentExt);
    
    if (!checkBoxRewriteOutput->isChecked())
    {
        tableOUT+="-";
        tableOUT=app(this)->generateUniqueName(tableOUT);
    }
    
    if (sansTab->currentPageIndex()==1 && comboBoxCheck->currentText().contains("raw-QI"))
    {
        tableOUT=  "raw-QI";
    }
    else if (sansTab->currentPageIndex()==1 )
    {
        tableOUT= "raw-"+tableOUT;
    }
    
    //+++ RAD-table
    Table *wOut;
    
    bool tableExist=checkTableExistence(tableOUT);
    
    if (radioButtonOpenInProject->isChecked())
    {
        int colnumberInc=0;
        if (comboBox4thCol->currentItem()<2)  colnumberInc=1;
        if (comboBox4thCol->currentItem()==3)  colnumberInc=2;
        
        
        if (tableExist && checkBoxRewriteOutput->isChecked())
        {
            QWidgetList* tableList=app(this)->tableList();
            
            
            //+++ Find table
            for (int i=0;i<(int)tableList->count();i++)
            {
                if (tableList->at(i) && tableList->at(i)->name()==tableOUT) wOut=(Table *)tableList->at(i);
            }
            wOut->setNumRows(0);
            wOut->setNumCols(3+colnumberInc);
        }
        else
        {
            wOut=app(this)->newHiddenTable(tableOUT,CurrentLabel, 0, 3+colnumberInc);
        }
        
        
        app(this)->setListViewLabel(wOut->name(), label);
        app(this)->updateWindowLists(wOut);
        
        wOut->setColName(0,"Q");
        wOut->setColName(1,"I"); wOut->setColComment(1, label);
        wOut->setColName(2,"dI");
        wOut->setWindowLabel(label);
        
        wOut->setColPlotDesignation(2,Table::yErr);
        wOut->setHeaderColType();
        
        wOut->setNumericFormat(2, 8, true);
        
        if (comboBox4thCol->currentItem()==0)
        {
            wOut->setColName(3,"Sigma");
            wOut->setColPlotDesignation(3,Table::xErr);
        }
        else if (comboBox4thCol->currentItem()==1)
        {
            wOut->setColName(3,"dQ");
            wOut->setColPlotDesignation(3,Table::xErr);
        }
        else if (comboBox4thCol->currentItem()==3)
        {
            wOut->setColName(3,"dQ");
            wOut->setColPlotDesignation(3,Table::xErr);
            wOut->setColName(4,"Sigma");
            wOut->setColPlotDesignation(4,Table::xErr);
            wOut->setColPlotDesignation(4,Table::xErr);
        }
        
        wOut->setHeaderColType();
        
    }
    
    //------------------------------------
    // calculation of radial averaging
    //------------------------------------
    
    
    //+++ MAXIMAL RADIUS
    double rmax =  sqrt( (Xcenter)*(Xcenter) + pixelAsymetry*pixelAsymetry*( Ycenter)*(Ycenter));
    rmax = GSL_MAX(rmax, (sqrt((md - 1 -
                                Xcenter)*(md - 1 - Xcenter) + pixelAsymetry*pixelAsymetry*(Ycenter)*(Ycenter))));
    rmax = GSL_MAX(rmax,sqrt((md - 1 -
                              Xcenter)*(md - 1 - Xcenter) + pixelAsymetry*pixelAsymetry*(md - 1 - Ycenter)*(md - 1 - Ycenter)));
    rmax = GSL_MAX(rmax,sqrt(( Xcenter)*(Xcenter) + pixelAsymetry*pixelAsymetry*(md - 1 - Ycenter)*(md - 1 - Ycenter)));
    
    int iii,jjj;
    
    double minPixel=1.0;
    
    //    if (pixelAsymetry<1 && pixelAsymetry>0) minPixel=pixelAsymetry; // TEST 2015
    
    int nTotal=int(rmax/minPixel+0.5);
    double *II=new double[nTotal];
    double *dII=new double[nTotal];
    int *nn=new int[nTotal];
    double offsetCh;
    
    int ir;
    
    for(ir=0;ir<nTotal;ir++)
    {
        II[ir]= 0;
        dII[ir]= 0;
        nn[ir]=0;
    }
    
    for (iii=0;iii<md;iii++) for (jjj=0;jjj<md;jjj++)
    {
        if (gsl_matrix_get(mask,iii,jjj)>0)
        {
            offsetCh=sqrt((Xcenter-jjj)*(Xcenter-jjj)+pixelAsymetry*pixelAsymetry*(Ycenter-iii)*(Ycenter-iii))/minPixel;
            II[int(offsetCh+0.5)]+=gsl_matrix_get(Sample,iii,jjj);
            dII[int(offsetCh+0.5)]+=gsl_matrix_get(SampleErr,iii,jjj)*gsl_matrix_get(Sample,iii,jjj)*gsl_matrix_get(Sample,iii,jjj);
            nn[int(offsetCh+0.5)]+=1;
        }
    }
    
    // new log scale
    double stepProg=lineEditCommonRatio->text().toDouble();
    
    if (stepProg<1.0) stepProg=1.0;
    if (stepProg>1.2) stepProg=1.2;
    
    double IIlocal, dIIlocal;
    int nnLocal;
    
    int *mergedPoints=new int[nTotal];
    
    int i=0;
    while(i<nTotal)
    {
        double tm=pow(stepProg,i);
        int plusPoints=int(tm);
        if (tm-int(tm)>0.5) plusPoints++;
        
        if (i+plusPoints>=nTotal) plusPoints=nTotal-i;
        
        
        IIlocal=0.0;
        dIIlocal=0.0;
        nnLocal=0;
        for (int ii=0;ii<plusPoints;ii++)
        {
            nnLocal+=nn[i+ii];
            IIlocal+=II[i+ii];
            dIIlocal+=dII[i+ii];
            
            nn[i+ii]=0;
            mergedPoints[i+ii]=plusPoints;
            II[i+ii]=0.0;
            dII[i+ii]=0;
        }
        
        mergedPoints[i]=plusPoints;
        nn[i]=nnLocal;
        II[i]=IIlocal;
        dII[i]=dIIlocal;
        
        i=i+plusPoints;
    }
    
    
    
    double qr, avg, avge, sig, dq;
    
    QString streamSTR="";
    
    //+++ new Skip Points
    int skipFirst=spinBoxRemoveFirst->value();
    int skipLast=spinBoxRemoveLast->value();
    
    for(ir=0;ir<nTotal;ir++)
    {
        if (nn[ir]>=1)
        {
            //      qr  = 2.0*M_PI/lambda *  (ir*detelem/detdist);
            qr  = 4.0*M_PI/lambda *
            sin(0.5*atan((2*ir*minPixel+mergedPoints[ir]-1)/2.0*detelem/detdist));  // test
            avg = II[ir] / nn[ir];
            avge=sqrt(dII[ir]) / nn[ir];
            
            sig= sigmaQmerged( qr, detdist, C, lambda, deltaLambda, r1, r2, mergedPoints[ir]);
            dq=dQ(qr, numberF, mergedPoints[ir]*ir*minPixel*(pixelAsymetry+1)/2*detelem, detdist, detelem );
            
            //
            double Q,I,dI;
            double QQQ, III, dIII;
            Q=qr;
            I=avg;
            dI=avge;
            
            QQQ=qr;
            III=avg;
            dIII=avge;
            
            
            // * ****** Change of Presentation  *****************************
            if (CurrentLabel!="QI")
            {
                if (CurrentLabel=="Guinier")
                {
                    QQQ=Q*Q;
                    III=log(fabs(I));
                    if (I!=0) dIII=dI/fabs(I);
                }
                else if (CurrentLabel=="Zimm")
                {
                    QQQ=Q*Q;
                    if (I!=0) III=1/I; else III=0;
                    if (I!=0) dIII=dI/I/I; else dIII=0;
                }
                else if (CurrentLabel=="Porod")
                {
                    QQQ=log10(Q);
                    III=log10(fabs(I));
                    if (I!=0) dIII=dI/fabs(I)/log(10.0);
                }
                else if (CurrentLabel=="Porod2")
                {
                    QQQ=Q*Q;
                    III=I*pow(Q,4);
                    dIII=dI*pow(Q,4);
                }
                else if (CurrentLabel=="logQ")
                {
                    QQQ=log10(Q);
                }
                else if (CurrentLabel=="logI")
                {
                    
                    III=log10(fabs(I));
                    if (I!=0) dIII=dI/fabs(I)/log(10.0);
                }
                else if (CurrentLabel=="Debye")
                {
                    QQQ=Q*Q;
                    if (I!=0) III=1/sqrt(fabs(I)); else III=0;
                    if (I!=0) dIII=dI/pow(fabs(I),1.5); else dIII=0;
                }
                else if (CurrentLabel=="1Moment")
                {
                    III=Q*I;
                    dIII=Q*dI;
                }
                else if (CurrentLabel=="2Moment")
                {
                    III=Q*Q*I;
                    dIII=Q*Q*dI;
                }
                else if (CurrentLabel=="Kratky")
                {
                    III=Q*Q*I;
                    dIII=Q*Q*dI;
                }
                else if (CurrentLabel=="GuinierRod")
                {
                    QQQ=Q*Q;
                    III=log(fabs(I*Q));
                    if (I!=0) dIII=Q*fabs((dI/I)); else III=0;
                }
                else if (CurrentLabel=="GuinierPlate")
                {
                    QQQ=Q*Q;
                    III=log(fabs(I*Q*Q));
                    if (I!=0) dIII=Q*Q*fabs(dI/I); else III=0;
                }
                
            }
            
            //+++  To File Q-I-dI-?
            if (radioButtonFile->isChecked())
            {
                
                if (numAllQ>=skipFirst)
                {
                    if ( !(avg<=0 && checkBoxMaskNegativeQ->isChecked()) )
                    {
                        if (comboBox4thCol->currentItem()==0)
                        {
                            streamSTR    +=      QString::number(QQQ,'E',8)
                            +"   "+QString::number(III,'E',8)
                            +"   "+QString::number(dIII,'E',8)
                            +"   "+QString::number(sig,'E',8)+"\n";
                        }
                        else if (comboBox4thCol->currentItem()==1)
                        {
                            streamSTR    +=      QString::number(QQQ,'E',8)
                            +"   "+QString::number(III,'E',8)
                            +"   "+QString::number(dIII,'E',8)
                            +"   "+QString::number(dq,'E',8)+"\n";
                        }
                        else if (comboBox4thCol->currentItem()==2)
                        {
                            streamSTR	+=      QString::number(QQQ,'E',8)
                            +"   "+QString::number(III,'E',8)
                            +"   "+QString::number(dIII,'E',8)+"\n" ;
                        }
                        else if (comboBox4thCol->currentItem()==3)
                        {
                            streamSTR    +=      QString::number(QQQ,'E',8)
                            +"   "+QString::number(III,'E',8)
                            +"   "+QString::number(dIII,'E',8)
                            +"   "+QString::number(dq,'E',8)
                            +"   "+QString::number(sig,'E',8)+"\n";
                        }
                        
                        numRowsOut++;
                    }
                    else negativeNumbersPosition<<numAllQ;
                }
                
                numAllQ++;
                
            }
            else
            {
                if (numAllQ>=skipFirst)
                {
                    if ( !(avg<=0 && checkBoxMaskNegativeQ->isChecked()) )
                    {
                        wOut->setNumRows(numRowsOut+1);
                        wOut->setText(numRowsOut,0,QString::number(QQQ,'E',8));
                        wOut->setText(numRowsOut,1,QString::number(III,'E',8));
                        wOut->setText(numRowsOut,2,QString::number(dIII,'E',8));
                        
                        //+++ Sigma output +++
                        if (comboBox4thCol->currentItem()==0) {
                            wOut->setText(numRowsOut,3, QString::number(sig,'E',8));
                        }
                        else if (comboBox4thCol->currentItem()==1){ 
                            wOut->setText(numRowsOut,3, QString::number(dq,'E',8));
                        }
                        else if (comboBox4thCol->currentItem()==3){ 
                            wOut->setText(numRowsOut,3, QString::number(dq,'E',8));
                            wOut->setText(numRowsOut,4, QString::number(sig,'E',8));
                        }
                        
                        numRowsOut++;
                    }
                    else negativeNumbersPosition<<numAllQ;
                }
                numAllQ++;
                
            }
        }
    }
    
    //+++ Calculate number last points 
    int scipLastReal=skipLast;
    
    if (skipLast>0) for (int i=1; i<=skipLast; i++)
    {
        if ( negativeNumbersPosition.findIndex( numAllQ-i )>=0 ) scipLastReal--;
    }
    
    //+++ remove last Points
    if (radioButtonOpenInProject->isChecked())
    {
        if (wOut->numRows()>=scipLastReal) wOut->setNumRows( wOut->numRows() -
                                                            scipLastReal ); else wOut->setNumRows(0);
        if (tableExist) wOut->notifyChanges();
        
        //+++ adjust cols
        for (int tt=0; tt<wOut->numCols(); tt++)
        {
            wOut->table()->adjustColumn (tt);
            wOut->table()->setColumnWidth(tt, wOut->table()->columnWidth(tt)+10); 
        }
        
        wOut->hide();
        
    }
    
    
    int findN, tempI;
    
    for (findN=0;findN<scipLastReal;findN++) {
        tempI=streamSTR.findRev("\n",-3);
        streamSTR.remove(tempI+1,streamSTR.length()-tempI+2);};   
    
    if (!radioButtonOpenInProject->isChecked())
    {
        QFile f;
        
        QDir dd;
        
        QString asciiPath=lineEditPathRAD->text();
        
        if (checkBoxSortOutputToFolders->isChecked())	
        {	
            asciiPath+="/ASCII-QI";
            asciiPath=asciiPath.replace("//","/");
            if (!dd.cd(asciiPath)) 
            {
                dd.mkdir(asciiPath); 	
                
            };
        }
        
        QString fname="QI-";
        if (CurrentLabel!="QI") fname=fname+CurrentLabel+"-";
        fname=fname+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT";
        fname=fname.replace("QI-", "QI-"+currentExt);
        fname=asciiPath+"/"+fname;
        
        f.setName( fname );
        if ( f.open( IO_WriteOnly ) )
        {
            QTextStream stream( &f );
            
            if(comboBoxSelectPresentation->currentItem()==0  && checkBoxASCIIheader->isChecked())
            {
                QString header;
                if (comboBox4thCol->currentItem()==0)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]       Sigma[1/A]\n";
                }
                else if (comboBox4thCol->currentItem()==1)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]          dQ[1/A]\n";
                }				
                else if (comboBox4thCol->currentItem()==2)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]\n";
                }
                else if (comboBox4thCol->currentItem()==3)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]          dQ[1/A]       Sigma[1/A]\n";
                }
                
                stream<<header;
            }
            stream<<streamSTR;
            
            f.close();
        }
    }
    
    delete[] II;
    delete[] dII;
    delete[] nn;
    delete[] mergedPoints;
    
    
    sampleMatrix=tableOUT;
}


//+++ SD:: RAD-UniStd
void dan16::radUniHF
(
 int md,
 gsl_matrix *Sample, gsl_matrix *SampleErr, gsl_matrix *mask,
 double XYcenter, double YXcenter,
 QString &sampleMatrix,
 double C, double lambda, double deltaLambda, double detdist, double detelem, double r1, double r2,
 QString label, double numberF, double pixelAsymetry
 )
{
    
    double Xcenter=XYcenter;
    double Ycenter=YXcenter;
    
    //+++
    int numRowsOut=0;
    int numAllQ=0;
    
    //+++ mapping of negative points
    QValueList<int> negativeNumbersPosition;
    
    //+++ Presentation
    QString CurrentLabel=comboBoxSelectPresentation->currentText();
    //+++ Ext
    QString currentExt=lineEditFileExt->text().remove(" ");
    if(currentExt!="") currentExt+="-";
    
    //+++ Table Name
    QString tableOUT;
    
    tableOUT="QI-";
    
    if (CurrentLabel!="QI") tableOUT=tableOUT+CurrentLabel+"-";
    tableOUT=tableOUT+sampleMatrix;
    tableOUT=tableOUT.replace("QI-","QI-"+currentExt);
    
    
    if (!checkBoxRewriteOutput->isChecked())
    {
        tableOUT+="-";
        tableOUT=app(this)->generateUniqueName(tableOUT);
    }
    
    if (sansTab->currentPageIndex()==1 && comboBoxCheck->currentText().contains("raw-QI"))
    {
        tableOUT=  "raw-QI";
    }
    else if (sansTab->currentPageIndex()==1 )
    {
        tableOUT= "raw-"+tableOUT;
    }
    
    //+++ RAD-table
    Table *wOut;
    
    bool tableExist=checkTableExistence(tableOUT);
    
    
    if (radioButtonOpenInProject->isChecked())
    {
        int colnumberInc=0;
        if (comboBox4thCol->currentItem()<2)  colnumberInc=1;
        else if (comboBox4thCol->currentItem()==3)  colnumberInc=2;
        
        
        if (tableExist && checkBoxRewriteOutput->isChecked())
        {
            QWidgetList* tableList=app(this)->tableList();
            
            
            //+++ Find table
            for (int i=0;i<(int)tableList->count();i++)
            {
                if (tableList->at(i) && tableList->at(i)->name()==tableOUT) wOut=(Table *)tableList->at(i);
            }
            wOut->setNumRows(0);
            wOut->setNumCols(3+colnumberInc);
        }
        else
        {
            wOut=app(this)->newHiddenTable(tableOUT,CurrentLabel, 0, 3+colnumberInc);
        }
        
        
        app(this)->setListViewLabel(wOut->name(), label);
        app(this)->updateWindowLists(wOut);
        
        wOut->setColName(0,"Q");
        wOut->setColName(1,"I"); wOut->setColComment(1, label);
        wOut->setColName(2,"dI");
        wOut->setWindowLabel(label);
        
        wOut->setColPlotDesignation(2,Table::yErr);
        wOut->setHeaderColType();
        
        wOut->setNumericFormat(2, 8, true);
        
        if (comboBox4thCol->currentItem()==0)
        {
            wOut->setColName(3,"Sigma");
            wOut->setColPlotDesignation(3,Table::xErr);
        }
        else if (comboBox4thCol->currentItem()==1)
        {
            wOut->setColName(3,"dQ");
            wOut->setColPlotDesignation(3,Table::xErr);
        }
        else if (comboBox4thCol->currentItem()==3)
        {
            wOut->setColName(3,"dQ");
            wOut->setColPlotDesignation(3,Table::xErr);
            wOut->setColName(4,"Sigma");
            wOut->setColPlotDesignation(4,Table::xErr);
            wOut->setColPlotDesignation(4,Table::xErr);
        }
        wOut->setHeaderColType();
    }
    
    //------------------------------------
    // calculation of radial averaging
    //------------------------------------
    
    //+++ Xc & Yc center of detector
    double Xc=(double(md)-1.0)/2.0;
    double Yc=(double(md)-1.0)/2.0;
    
    double R;
    double rmaxLocal;
    
    //+++  maximal distance from center to corner
    double rmax =  sqrt( (Xcenter)*(Xcenter) + pixelAsymetry*pixelAsymetry*( Ycenter)*(Ycenter));
    //+
    rmaxLocal = sqrt( ( (md-1) -Xcenter ) * ( (md-1) - Xcenter) + pixelAsymetry*pixelAsymetry*Ycenter * Ycenter );
    if (rmaxLocal>rmax) rmax = rmaxLocal;
    //+
    rmaxLocal = sqrt( ( (md-1) - Xcenter )*( (md-1) - Xcenter ) + pixelAsymetry*pixelAsymetry*( (md-1) - Ycenter )*( (md-1) - Ycenter) );
    if (rmaxLocal>rmax) rmax = rmaxLocal;
    //+
    rmaxLocal = sqrt( Xcenter*Xcenter + pixelAsymetry*pixelAsymetry*( (md-1) - Ycenter)*( (md-1) - Ycenter) );
    if (rmaxLocal>rmax) rmax = rmaxLocal;
    
    
    int ir,ii;                  //iR iPhi...
    int ix1,iy1,ix1old,iy1old,ix2,iy2;                //...
    int msk, phisteps;          //mask &
    
    double qr,phi,xs,ys,rex,rey;
    double wt,rad;
    
    double pi=M_PI;
    double  twt ;                       // totales Gewicht    >>>RESET<<<
    double avg;                 // Mittel
    double avge;                        //Fehler
    
    double sigmaErr;
    
    double sig, dq;
    
    QString streamSTR="";
    
    //+++ new Skip Points
    int skipFirst=spinBoxRemoveFirst->value();
    int skipLast=spinBoxRemoveLast->value();
    
    
    for(ir=0;ir<=int(rmax+0.5);ir++)
    {
        //      qr  = 2.*pi/lambda *  (ir*detelem/detdist);
        qr  = 4.0*M_PI/lambda *
        sin(0.5*atan(ir*detelem/detdist));  // test
        
        //+++ 09.09.10+++ rad =  detdist / detelem * tan (2.0*asin(0.5*ir*detelem/detdist) );  // echter rad
        rad=ir; //+++ 09.09.10+++
        
        
        
        //+++ 09.09.10+++ phisteps =int( GSL_MAX( int(4*pi*rad+0.5), 4) );
        phisteps =int( GSL_MAX( int(4*pi*rad+0.5), 1) );
        
        twt = 0.0;      //      ! totales Gewicht    >>>RESET<<<
        avg = 0.0;      //      ! Mittel
        avge= 0.0;      //      ! Fehler
        
        sig= sigma( qr, detdist, C, lambda, deltaLambda, r1, r2 );
        dq=dQ(qr, numberF, ir*(pixelAsymetry+1)/2*detelem, detdist, detelem );
        
        ix1old=-1000;
        iy1old=-1000;
        
        for(ii=0; ii< phisteps; ii++)
        {
            //+++ Phi
            phi = 2.*pi*ii/phisteps;
            
            //+++
            xs  = Xcenter + rad * cos(phi);
            ys  = Ycenter + rad/pixelAsymetry * sin(phi);
            
            //+++
            R=detelem*sqrt((xs-Xc)*(xs-Xc)+(ys-Yc)*(ys-Yc));
            
            //+++
            ix1 = int(xs);      //         ! Eckpunkte
            iy1 = int(ys);
            if (ix1<0) ix1=ix1-1;
            if (iy1<0) iy1=iy1-1;
            
            
            ix1old=ix1;
            iy1old=iy1;
            
            ix2 = ix1 + 1;
            iy2 = iy1 + 1;
            
            
            rex = xs - ix1;     //        ! Reste f"ur Gewichtung sp"ater
            rey = ys - iy1;
            
            msk = 0;    //        ! linker unterer Punkt
            
            
            if (ix1>=0 && ix1<md && iy1>=0 && iy1<md)
            {
                //+++
                msk = int( gsl_matrix_get(mask,iy1,ix1) );
                wt  = msk*(1.0-rex)*(1.0-rey);
                twt += wt;
                avg += wt *gsl_matrix_get(Sample,iy1,ix1);
                
                //+++err
                sigmaErr=gsl_matrix_get(SampleErr,iy1,ix1);
                
                //+++
                avge += wt*wt*sigmaErr*gsl_matrix_get(Sample,iy1,ix1)*gsl_matrix_get(Sample,iy1,ix1);
                
            }
            
            msk = 0;    //              ! rechter unterer Punkt
            
            if (ix2>=0 && ix2<md && iy1>=0 && iy1<md)
            {
                msk =int( gsl_matrix_get(mask,iy1,ix2)  );
                wt  = msk*(rex)*(1.0-rey);
                twt +=  wt;
                avg += wt*gsl_matrix_get(Sample,iy1,ix2);
                
                //+++err
                sigmaErr=gsl_matrix_get(SampleErr,iy1, ix2);
                avge += wt*wt*sigmaErr*gsl_matrix_get(Sample,iy1,
                                                      ix2)*gsl_matrix_get(Sample,iy1, ix2);
                
            }
            
            msk = 0;//               ! linker oberer Punkt
            
            if (ix1>=0 && ix1<md && iy2>=0 && iy2<md)
            {
                msk =int( gsl_matrix_get(mask,iy2,ix1) );
                wt  = msk*(1.0-rex)*(rey);
                twt += wt;
                avg += wt*gsl_matrix_get(Sample,iy2,ix1);
                
                //+++err
                sigmaErr = gsl_matrix_get(SampleErr,iy2,ix1);
                avge += wt*wt*sigmaErr*gsl_matrix_get(Sample,iy2,ix1)*gsl_matrix_get(Sample,iy2,ix1);
                
            }
            
            msk = 0;//               ! rechter oberer Punkt
            
            if (ix2>=0 && ix2<md && iy2>=0 && iy2<md)
            {
                msk =int( gsl_matrix_get(mask,iy2,ix2));
                wt  = msk*(rex)*(rey);
                twt += wt;
                avg += wt * gsl_matrix_get(Sample,iy2,ix2);
                
                //+++erri
                sigmaErr=gsl_matrix_get(SampleErr,iy2,ix2);
                
                avge += wt*wt*sigmaErr*gsl_matrix_get(Sample,iy2,ix2)*gsl_matrix_get(Sample,iy2,ix2);
                
            }
            
            
        }
        
        //+++  Mean Value
        if (twt>0.0)
        {
            avge=sqrt(avge)  / twt;
            avg = avg / twt;
        }
        
        if (twt>0.0)
        {
            
            //
            double Q,I,dI;
            double QQ, II, dII;
            Q=qr;
            I=avg;
            dI=avge;
            
            QQ=qr;
            II=avg;
            dII=avge;
            
            
            // * ****** Change of Presentation  *****************************
            if (CurrentLabel!="QI")
            {
                if (CurrentLabel=="Guinier")
                {
                    QQ=Q*Q;
                    II=log(fabs(I));
                    if (I!=0) dII=dI/fabs(I);
                }
                else if (CurrentLabel=="Zimm")
                {
                    QQ=Q*Q;
                    if (I!=0) II=1/I; else II=0;
                    if (I!=0) dII=dI/I/I;
                }
                else if (CurrentLabel=="Porod")
                {
                    QQ=log10(Q);
                    II=log10(fabs(I));
                    if (I!=0) dII=dI/fabs(I)/log(10.0);
                }
                else if (CurrentLabel=="Porod2")
                {
                    QQ=Q*Q;
                    II=I*pow(Q,4);
                    dII=dI*pow(Q,4);
                }
                else if (CurrentLabel=="logQ")
                {
                    QQ=log10(Q);
                }
                else if (CurrentLabel=="logI")
                {
                    
                    II=log10(fabs(I));
                    if (I!=0) dII=dI/fabs(I)/log(10.0);
                }
                else if (CurrentLabel=="Debye")
                {
                    QQ=Q*Q;
                    if (I!=0) II=1/sqrt(fabs(I)); else II=0;
                    if (I!=0) dII=dI/pow(fabs(I),1.5); else II=0;
                }
                else if (CurrentLabel=="1Moment")
                {
                    II=Q*I;
                    dII=Q*dI;
                }
                else if (CurrentLabel=="2Moment")
                {
                    II=Q*Q*I;
                    dII=Q*Q*dI;
                }
                else if (CurrentLabel=="Kratky")
                {
                    II=Q*Q*I;
                    dII=Q*Q*dI;
                }
                else if (CurrentLabel=="GuinierRod")
                {
                    QQ=Q*Q;
                    II=log(fabs(I*Q));
                    if (I!=0) dII=Q*fabs((dI/I)); else II=0;
                }
                else if (CurrentLabel=="GuinierPlate")
                {
                    QQ=Q*Q;
                    II=log(fabs(I*Q*Q));
                    if (I!=0) dII=Q*Q*fabs(dI/I); else II=0;
                }
            }
            
            
            //+++  To File Q-I-dI-?
            if (radioButtonFile->isChecked())
            {
                if (numAllQ>=skipFirst)
                {
                    if ( !(avg<=0 && checkBoxMaskNegativeQ->isChecked()) )
                    {
                        
                        if (comboBox4thCol->currentItem()==0)
                        {
                            streamSTR    +=      QString::number(QQ,'E',8)
                            +"   "+QString::number(II,'E',8)
                            +"   "+QString::number(dII,'E',8)
                            +"   "+QString::number(sig,'E',8)+"\n";
                        }
                        else if (comboBox4thCol->currentItem()==1)
                        {
                            streamSTR    +=      QString::number(QQ,'E',8)
                            +"   "+QString::number(II,'E',8)
                            +"   "+QString::number(dII,'E',8)
                            +"   "+QString::number(dq,'E',8)+"\n";
                        }
                        else if (comboBox4thCol->currentItem()==2)
                        {
                            streamSTR    +=      QString::number(QQ,'E',8)
                            +"   "+QString::number(II,'E',8)
                            +"   "+QString::number(dII,'E',8)+"\n" ;
                        }
                        else if (comboBox4thCol->currentItem()==3)
                        {
                            streamSTR    +=      QString::number(QQ,'E',8)
                            +"   "+QString::number(II,'E',8)
                            +"   "+QString::number(dII,'E',8)
                            +"   "+QString::number(dq,'E',8)
                            +"   "+QString::number(sig,'E',8)+"\n";
                        }
                        
                        numRowsOut++;
                    }
                    else negativeNumbersPosition<<numAllQ;
                }
                numAllQ++;
            }
            else
            {
                if (numAllQ>=skipFirst)
                {
                    if ( !(avg<=0 && checkBoxMaskNegativeQ->isChecked()) )
                    {
                        wOut->setNumRows(numRowsOut+1);
                        wOut->setText(numRowsOut,0,QString::number(QQ,'E',8));
                        wOut->setText(numRowsOut,1,QString::number(II,'E',8));
                        wOut->setText(numRowsOut,2,QString::number(dII,'E',8));
                        
                        //+++ Sigma output +++
                        if (comboBox4thCol->currentItem()==0) 
                            wOut->setText(numRowsOut,3, QString::number(sig,'E',8));
                        else if (comboBox4thCol->currentItem()==1) 
                            wOut->setText(numRowsOut,3, QString::number(dq,'E',8));
                        else if (comboBox4thCol->currentItem()==3){ 
                            wOut->setText(numRowsOut,3, QString::number(dq,'E',8));	
                            wOut->setText(numRowsOut,4, QString::number(sig,'E',8));
                        }
                        
                        numRowsOut++;
                    }
                    else negativeNumbersPosition<<numAllQ;
                }
                numAllQ++;
                
            }
        }
    }
    
    //+++ Calculate number last points 
    int scipLastReal=skipLast;
    
    if (skipLast>0) for (int i=1; i<=skipLast; i++)
    {
        if ( negativeNumbersPosition.findIndex( numAllQ-i )>=0 ) scipLastReal--;
    }
    
    //+++ remove last Points
    if (radioButtonOpenInProject->isChecked())
    {
        if (wOut->numRows()>=scipLastReal) wOut->setNumRows( wOut->numRows() -
                                                            scipLastReal ); else wOut->setNumRows(0);
        if (tableExist) wOut->notifyChanges();
        
        //+++ adjust cols
        for (int tt=0; tt<wOut->numCols(); tt++)
        {
            wOut->table()->adjustColumn (tt);
            wOut->table()->setColumnWidth(tt, wOut->table()->columnWidth(tt)+10); 
        }
        
        wOut->hide();
    }
    
    
    
    int findN, tempI;
    
    for (findN=0;findN<scipLastReal;findN++) {
        tempI=streamSTR.findRev("\n",-3);
        streamSTR.remove(tempI+1,streamSTR.length()-tempI+2);};
    
    //+++ Export to RAD-File
    if (!radioButtonOpenInProject->isChecked())
    {
        QFile f;
        
        QDir dd;
        
        QString asciiPath=lineEditPathRAD->text();
        
        if (checkBoxSortOutputToFolders->isChecked())	
        {
            if (CurrentLabel=="QI") asciiPath+="/ASCII-QI";
            else asciiPath+="/ASCII-QI-"+CurrentLabel;
            asciiPath=asciiPath.replace("//","/");
            if (!dd.cd(asciiPath)) 
            {
                dd.mkdir(asciiPath); 	
                
            };
        }
        
        QString fname="QI-";
        if (CurrentLabel!="QI") fname=fname+CurrentLabel+"-";
        fname=fname+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT";
        fname=fname.replace("QI-","QI-"+currentExt);
        fname=asciiPath+"/"+fname;
        
        f.setName( fname );
        if ( f.open( IO_WriteOnly ) )
        {
            QTextStream stream( &f );
            
            if(comboBoxSelectPresentation->currentItem()==0 && checkBoxASCIIheader->isChecked())
            {
                QString header;
                if (comboBox4thCol->currentItem()==0)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]       Sigma[1/A]\n";
                }
                else if (comboBox4thCol->currentItem()==1)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]          dQ[1/A]\n";
                }				
                else if (comboBox4thCol->currentItem()==2)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]\n";
                }
                else if (comboBox4thCol->currentItem()==3)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]          dQ[1/A]       Sigma[1/A]\n";
                }
                
                if (!checkBoxASCIIheader->isChecked()) header=""; //2013-09
                
                
                stream<<header;
            }
            stream<<streamSTR;
            
            f.close();
        }
    }
    sampleMatrix=tableOUT;    
}

//+++ Horizontal Slice
void dan16::horizontalSlice
(
 int md,
 gsl_matrix *Sample, gsl_matrix *SampleErr, gsl_matrix *mask,
 double Xcenter, double Ycenter,
 QString sampleMatrix,
 double C, double lambda, double deltaLambda, double detdist, double detelem, double r1, double r2,
 QString label
 )
{
    //+++
    int numRowsOut=0;
    double qr;
    //+++ Presentation
    QString CurrentLabel=comboBoxSelectPresentation->currentText();
    //+++ Ext
    QString currentExt=lineEditFileExt->text().remove(" ");
    if(currentExt!="") currentExt+="-";
    
    //+++ Table Name
    QString tableOUT;
    tableOUT="QXI-";
    
    if(CurrentLabel!="QI") tableOUT=tableOUT+CurrentLabel+"-";
    tableOUT=tableOUT+sampleMatrix;
    tableOUT=tableOUT.replace("QXI-","QXI-"+currentExt);
    
    
    if (!checkBoxRewriteOutput->isChecked())
    {
        tableOUT=tableOUT+"-";
        tableOUT=app(this)->generateUniqueName(tableOUT);
    }
    
    
    
    //+++ RAD-table
    Table *wOut;
    
    
    if (radioButtonOpenInProject->isChecked())
    {
        
        bool tableExist=checkTableExistence(tableOUT);
        
        
        if (tableExist)
        {
            QWidgetList* tableList=app(this)->tableList();
            
            
            //+++ Find table
            for (int i=0;i<(int)tableList->count();i++)
            {
                if (tableList->at(i) && tableList->at(i)->name()==tableOUT) wOut=(Table *)tableList->at(i);
            }
            wOut->setNumRows(0);
            
            if (comboBox4thCol->currentItem()==0) wOut->setNumCols(4);
            else wOut->setNumCols(3);
            
        }
        else
        {
            if (comboBox4thCol->currentItem()==0)
            {
                wOut=app(this)->newHiddenTable(tableOUT,CurrentLabel, 0, 4);
                
                wOut->setColName(3,"Sigma");
                wOut->setColPlotDesignation(3,Table::xErr);
            }
            else
                wOut=app(this)->newHiddenTable(tableOUT,CurrentLabel, 0, 3);
            
            wOut->setColName(0,"Q");
            wOut->setColName(1,"I"); wOut->table()->horizontalHeader()->setLabel(1, label);
            wOut->setColName(2,"dI");
            
            wOut->setWindowLabel(label);
            app(this)->setListViewLabel(wOut->name(), label);
            app(this)->updateWindowLists(wOut);
            
            wOut->setColPlotDesignation(2,Table::yErr);
            wOut->setHeaderColType();
        }
    }
    
    int nTotal=md;
    
    int xxx,yyy;
    
    double *II=new double[nTotal];
    double *dII=new double[nTotal];
    double *sigmaM=new double[nTotal];
    int *nn=new int[nTotal];
    
    for(xxx=0;xxx<nTotal;xxx++)
    {
        II[xxx]= 0;
        dII[xxx]= 0;
        nn[xxx]=0;
    }
    
    for (xxx=0;xxx<md;xxx++) for (yyy=0;yyy<md;yyy++)
    {
        if (gsl_matrix_get(mask,yyy,xxx)>0)
        {
            II  [xxx] += gsl_matrix_get(Sample,yyy,xxx);
            dII[xxx] += gsl_matrix_get(SampleErr,yyy,xxx)*gsl_matrix_get(Sample,yyy,xxx)*gsl_matrix_get(Sample,yyy,xxx);
            nn[xxx]+=1;
            
            qr  = 4.0*M_PI/lambda *
            sin(0.5*atan(sqrt( (Xcenter-xxx)*(Xcenter-xxx)+(Ycenter-yyy)*(Ycenter-yyy) )*detelem/detdist));
            sigmaM[xxx]+=sigma( qr, detdist, C, lambda, deltaLambda, r1, r2 );
        }
    }
    
    double avg, avge, sig;
    
    QString streamSTR="";
    
    //+++ new Skip Points
    int skipFirst=spinBoxRemoveFirst->value();
    int skipLast=spinBoxRemoveLast->value();
    
    for(xxx=0;xxx<nTotal;xxx++)
    {
        if (nn[xxx]>=1)
        {
            qr  = 4.0*M_PI/lambda * sin(0.5*atan((xxx-Xcenter)*detelem/detdist));
            avg = II[xxx] / nn[xxx];
            avge=sqrt(dII[xxx]) / nn[xxx];
            sig= sigmaM[xxx] / nn[xxx];
            
            
            //
            double Q,I,dI;
            double QQQ, III, dIII;
            Q=qr;
            I=avg;
            dI=avge;
            
            QQQ=qr;
            III=avg;
            dIII=avge;
            
            
            // * ****** Change of Presentation  *****************************
            if (CurrentLabel!="QI")
            {
                if (CurrentLabel=="Guinier")
                {
                    QQQ=Q*Q;
                    III=log(fabs(I));
                    if (I!=0) dIII=dI/fabs(I);
                }
                else if (CurrentLabel=="Zimm")
                {
                    QQQ=Q*Q;
                    if (I!=0) III=1/I; else III=0;
                    if (I!=0) dIII=dI/I/I; else dIII=0;
                }
                else if (CurrentLabel=="Porod")
                {
                    QQQ=log10(Q);
                    III=log10(fabs(I));
                    if (I!=0) dIII=dI/fabs(I)/log(10.0);
                }
                else if (CurrentLabel=="Porod2")
                {
                    QQQ=Q*Q;
                    III=I*pow(Q,4);
                    dIII=dI*pow(Q,4);
                }
                else if (CurrentLabel=="logQ")
                {
                    QQQ=log10(Q);
                }
                else if (CurrentLabel=="logI")
                {
                    
                    III=log10(fabs(I));
                    if (I!=0) dIII=dI/fabs(I)/log(10.0);
                }
                else if (CurrentLabel=="Debye")
                {
                    QQQ=Q*Q;
                    if (I!=0) III=1/sqrt(fabs(I)); else III=0;
                    if (I!=0) dIII=dI/pow(fabs(I),1.5); else dIII=0;
                }
                else if (CurrentLabel=="1Moment")
                {
                    III=Q*I;
                    dIII=Q*dI;
                }
                else if (CurrentLabel=="2Moment")
                {
                    III=Q*Q*I;
                    dIII=Q*Q*dI;
                }
                else if (CurrentLabel=="Kratky")
                {
                    III=Q*Q*I;
                    dIII=Q*Q*dI;
                }
                else if (CurrentLabel=="GuinierRod")
                {
                    QQQ=Q*Q;
                    III=log(fabs(I*Q));
                    if (I!=0) dIII=Q*fabs((dI/I)); else III=0;
                }
                else if (CurrentLabel=="GuinierPlate")
                {
                    QQQ=Q*Q;
                    III=log(fabs(I*Q*Q));
                    if (I!=0) dIII=Q*Q*fabs(dI/I); else III=0;
                }
            }
            
            if ( !(avg<=0 && checkBoxMaskNegativeQ->isChecked()) )
            {
                if (comboBox4thCol->currentItem()==0)
                {
                    streamSTR+=QString::number(QQQ,'E',8)
                    +"   "+QString::number(III,'E',8)
                    +"   "+QString::number(dIII,'E',8)
                    +"   "+QString::number(sig,'E',8)+"\n";
                }
                else
                {
                    streamSTR +=QString::number(QQQ,'E',8)
                    +"   "+QString::number(III,'E',8)
                    +"   "+QString::number(dIII,'E',8)+"\n" ;
                }
            }
            
            //+++  to Table  +++
            if ( !(avg<=0 && checkBoxMaskNegativeQ->isChecked()) )
                if (radioButtonOpenInProject->isChecked())
                {
                    if (numRowsOut>=skipFirst)
                    {
                        wOut->setNumRows(numRowsOut-skipFirst+1);
                        wOut->setText(numRowsOut-skipFirst,0,QString::number(QQQ,'E',8));
                        wOut->setText(numRowsOut-skipFirst,1,QString::number(III,'E',8));
                        wOut->setText(numRowsOut-skipFirst,2,QString::number(dIII,'E',8));
                        if (comboBox4thCol->currentItem()==0)
                        {
                            wOut->setText(numRowsOut-skipFirst,3,QString::number(sig,'E',8));
                        }
                    }
                    numRowsOut++;
                }
        }
    }
    
    //+++ remove last Points
    if (radioButtonOpenInProject->isChecked())
    {
        if (wOut->numRows()>=skipLast) wOut->setNumRows( wOut->numRows() -
                                                        skipLast ); else wOut->setNumRows(0);
        if (wOut) wOut->notifyChanges();
    }
    
    int findN, tempI;
    for (findN=0;findN<skipFirst;findN++) {
        tempI=streamSTR.find("\n"); streamSTR.remove(0,tempI+1);};
    for (findN=0;findN<skipLast;findN++) {
        tempI=streamSTR.findRev("\n",-3);
        streamSTR.remove(tempI+1,streamSTR.length()-tempI+2);};
    
    if (!radioButtonOpenInProject->isChecked())
    {
        QFile f;
        QString fname;
        
        if (checkBoxSortOutputToFolders->isChecked())	
        {	
            QDir dd;
            if (!dd.cd(lineEditPathRAD->text()+"/ASCII-QXI")) 
            {	
                dd.mkdir(lineEditPathRAD->text()+"/ASCII-QXI"); 			
            }
            fname=lineEditPathRAD->text()+"/ASCII-QXI/QXI-";
        }
        else fname=lineEditPathRAD->text()+"/QXI-";
        
        
        if (CurrentLabel!="QI") fname=fname+CurrentLabel+"-";
        
        fname=fname+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT";		fname=fname.replace("QXI-","QXI-"+currentExt);
        
        
        f.setName( fname );
        if ( f.open( IO_WriteOnly ) )
        {
            QTextStream stream( &f );
            
            if(comboBoxSelectPresentation->currentItem()==0 && checkBoxASCIIheader->isChecked())
            {
                QString header;
                if (comboBox4thCol->currentItem()==0)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]       Sigma[1/A]\n";
                }
                else 
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]\n";
                }
                
                stream<<header;
            }
            
            
            stream<<streamSTR;
            
            f.close();
        }
    }
    
    delete[] II;
    delete[] dII;
    delete[] nn;
    delete[] sigmaM;
}



//+++ Vertical Slice
void dan16::verticalSlice
(
 int md,
 gsl_matrix *Sample, gsl_matrix *SampleErr, gsl_matrix *mask,
 double Xcenter, double Ycenter,
 QString sampleMatrix,
 double C, double lambda, double deltaLambda, double detdist, double detelem, double r1, double r2,
 QString label
 )
{
    //+++
    int numRowsOut=0;
    double qr;
    //+++ Presentation
    QString CurrentLabel=comboBoxSelectPresentation->currentText();
    
    //+++ Ext
    QString currentExt=lineEditFileExt->text().remove(" ");
    if(currentExt!="") currentExt+="-";
    
    //+++ Table Name
    QString tableOUT;
    tableOUT="QYI-";
    
    if(CurrentLabel!="QI")tableOUT=tableOUT+CurrentLabel+"-";
    tableOUT=tableOUT+sampleMatrix;
    tableOUT=tableOUT.replace("QYI-","QYI-"+currentExt);
    
    
    if (!checkBoxRewriteOutput->isChecked())
    {
        tableOUT=tableOUT+"-";
        tableOUT=app(this)->generateUniqueName(tableOUT);
    }
    
    
    //+++ RAD-table
    Table *wOut;
    
    
    if (radioButtonOpenInProject->isChecked())
    {
        
        bool tableExist=checkTableExistence(tableOUT);
        
        
        if (tableExist)
        {
            QWidgetList* tableList=app(this)->tableList();
            
            
            //+++ Find table
            for (int i=0;i<(int)tableList->count();i++)
            {
                if (tableList->at(i) && tableList->at(i)->name()==tableOUT) wOut=(Table *)tableList->at(i);
            }
            wOut->setNumRows(0);
            
            if (comboBox4thCol->currentItem()==0) wOut->setNumCols(4);
            else wOut->setNumCols(3);
            
        }
        else
        {
            if (comboBox4thCol->currentItem()==0)
            {
                wOut=app(this)->newHiddenTable(tableOUT,CurrentLabel, 0, 4);
                
                wOut->setColName(3,"Sigma");
                wOut->setColPlotDesignation(3,Table::xErr);
            }
            else
                wOut=app(this)->newHiddenTable(tableOUT,CurrentLabel, 0, 3);
            
            wOut->setColName(0,"Q");
            wOut->setColName(1,"I"); wOut->table()->horizontalHeader()->setLabel(1, label);
            wOut->setColName(2,"dI");
            
            wOut->setWindowLabel(label);
            app(this)->setListViewLabel(wOut->name(), label);
            app(this)->updateWindowLists(wOut);
            
            wOut->setColPlotDesignation(2,Table::yErr);
            wOut->setHeaderColType();
        }
    }
    
    int nTotal=md;
    
    int xxx,yyy;
    
    double *II=new double[nTotal];
    double *dII=new double[nTotal];
    double *sigmaM=new double[nTotal];
    int *nn=new int[nTotal];
    
    int ir;
    
    for(ir=0;ir<nTotal;ir++)
    {
        II[ir]= 0;
        dII[ir]= 0;
        nn[ir]=0;
    }
    
    for (yyy=0;yyy<md;yyy++) for (xxx=0;xxx<md;xxx++)
    {
        if (gsl_matrix_get(mask,yyy,xxx)>0)
        {
            II  [yyy] += gsl_matrix_get(Sample,yyy,xxx);
            dII[yyy] += gsl_matrix_get(SampleErr,yyy,xxx)*gsl_matrix_get(Sample,yyy,xxx)*gsl_matrix_get(Sample,yyy,xxx);
            nn[yyy]+=1;
            
            
            
            qr  = 4.0*M_PI/lambda *
            sin(0.5*atan(sqrt( (Xcenter-xxx)*(Xcenter-xxx)+(Ycenter-yyy)*(Ycenter-yyy) )*detelem/detdist));
            sigmaM[yyy]+=sigma( qr, detdist, C, lambda, deltaLambda, r1, r2 );
        }
    }
    
    double avg, avge, sig;
    
    QString streamSTR="";
    
    //+++ new Skip Points
    int skipFirst=spinBoxRemoveFirst->value();
    int skipLast=spinBoxRemoveLast->value();
    
    for(yyy=0;yyy<nTotal;yyy++)
    {
        if (nn[yyy]>=1)
        {
            qr  = 4.0*M_PI/lambda * sin(0.5*atan((yyy-Ycenter)*detelem/detdist));
            avg = II[yyy] / nn[yyy];
            avge=sqrt(dII[yyy]) / nn[yyy];
            sig= sigmaM[yyy] / nn[yyy];
            
            
            //
            double Q,I,dI;
            double QQQ, III, dIII;
            Q=qr;
            I=avg;
            dI=avge;
            
            QQQ=qr;
            III=avg;
            dIII=avge;
            
            
            // * ****** Change of Presentation  *****************************
            if (CurrentLabel!="QI")
            {
                if (CurrentLabel=="Guinier")
                {
                    QQQ=Q*Q;
                    III=log(fabs(I));
                    if (I!=0) dIII=dI/fabs(I);
                }
                else if (CurrentLabel=="Zimm")
                {
                    QQQ=Q*Q;
                    if (I!=0) III=1/I; else III=0;
                    if (I!=0) dIII=dI/I/I; else dIII=0;
                }
                else if (CurrentLabel=="Porod")
                {
                    QQQ=log10(Q);
                    III=log10(fabs(I));
                    if (I!=0) dIII=dI/fabs(I)/log(10.0);
                }
                else if (CurrentLabel=="Porod2")
                {
                    QQQ=Q*Q;
                    III=I*pow(Q,4);
                    dIII=dI*pow(Q,4);
                }
                else if (CurrentLabel=="logQ")
                {
                    QQQ=log10(Q);
                }
                else if (CurrentLabel=="logI")
                {
                    
                    III=log10(fabs(I));
                    if (I!=0) dIII=dI/fabs(I)/log(10.0);
                }
                else if (CurrentLabel=="Debye")
                {
                    QQQ=Q*Q;
                    if (I!=0) III=1/sqrt(fabs(I)); else III=0;
                    if (I!=0) dIII=dI/pow(fabs(I),1.5); else dIII=0;
                }
                else if (CurrentLabel=="1Moment")
                {
                    III=Q*I;
                    dIII=Q*dI;
                }
                else if (CurrentLabel=="2Moment")
                {
                    III=Q*Q*I;
                    dIII=Q*Q*dI;
                }
                else if (CurrentLabel=="Kratky")
                {
                    III=Q*Q*I;
                    dIII=Q*Q*dI;
                }
                else if (CurrentLabel=="GuinierRod")
                {
                    QQQ=Q*Q;
                    III=log(fabs(I*Q));
                    if (I!=0) dIII=Q*fabs((dI/I)); else III=0;
                }
                else if (CurrentLabel=="GuinierPlate")
                {
                    QQQ=Q*Q;
                    III=log(fabs(I*Q*Q));
                    if (I!=0) dIII=Q*Q*fabs(dI/I); else III=0;
                }
            }
            
            if ( !(avg<=0 && checkBoxMaskNegativeQ->isChecked()) )
            {
                if (comboBox4thCol->currentItem()==0)
                {
                    streamSTR+=QString::number(QQQ,'E',8)
                    +"   "+QString::number(III,'E',8)
                    +"   "+QString::number(dIII,'E',8)
                    +"   "+QString::number(sig,'E',8)+"\n";
                }
                else
                {
                    streamSTR +=QString::number(QQQ,'E',8)
                    +"   "+QString::number(III,'E',8)
                    +"   "+QString::number(dIII,'E',8)+"\n" ;
                }
            }
            //+++  to Table  +++
            if ( !(avg<=0 && checkBoxMaskNegativeQ->isChecked()) )
                if (radioButtonOpenInProject->isChecked())
                {
                    if (numRowsOut>=skipFirst)
                    {
                        wOut->setNumRows(numRowsOut-skipFirst+1);
                        wOut->setText(numRowsOut-skipFirst,0,QString::number(QQQ,'E',8));
                        wOut->setText(numRowsOut-skipFirst,1,QString::number(III,'E',8));
                        wOut->setText(numRowsOut-skipFirst,2,QString::number(dIII,'E',8));
                        if (comboBox4thCol->currentItem()==0)
                        {
                            wOut->setText(numRowsOut-skipFirst,3,QString::number(sig,'E',8));
                        }
                    }
                    numRowsOut++;
                }
        }
    }
    
    //+++ remove last Points
    if (radioButtonOpenInProject->isChecked())
    {
        if (wOut->numRows()>=skipLast) wOut->setNumRows( wOut->numRows() -
                                                        skipLast ); else wOut->setNumRows(0);
        if (wOut) wOut->notifyChanges();
    }
    
    int findN, tempI;
    for (findN=0;findN<skipFirst;findN++) {
        tempI=streamSTR.find("\n"); streamSTR.remove(0,tempI+1);};
    for (findN=0;findN<skipLast;findN++) {
        tempI=streamSTR.findRev("\n",-3);
        streamSTR.remove(tempI+1,streamSTR.length()-tempI+2);};
    
    if (!radioButtonOpenInProject->isChecked())
    {
        QFile f;
        
        QString fname;
        
        if (checkBoxSortOutputToFolders->isChecked())	
        {	
            QDir dd;
            if (!dd.cd(lineEditPathRAD->text()+"/ASCII-QYI")) 
            {	
                dd.mkdir(lineEditPathRAD->text()+"/ASCII-QYI"); 			
            }
            fname=lineEditPathRAD->text()+"/ASCII-QYI/QYI-";
        }
        else fname=lineEditPathRAD->text()+"/QYI-";
        
        
        if (CurrentLabel!="QI") fname=fname+CurrentLabel+"-";
        
        fname=fname+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT";
        fname=fname.replace("QYI-","QYI-"+currentExt);
        
        f.setName( fname );
        if ( f.open( IO_WriteOnly ) )
        {
            QTextStream stream( &f );
            
            
            
            if(comboBoxSelectPresentation->currentItem()==0 && checkBoxASCIIheader->isChecked())
            {
                QString header;
                if (comboBox4thCol->currentItem()==0)
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]       Sigma[1/A]\n";
                }
                else 
                {
                    header    =  "###     Q[1/A]          I[1/cm]         dI[1/cm]\n";
                }
                
                stream<<header;
            }
            
            
            stream<<streamSTR;
            
            f.close();
        }
    }
    
    delete[] II;
    delete[] dII;
    delete[] nn;
    delete[] sigmaM;
}

//+++ SD:: RAD-UniPolar
void dan16::radUniPolar
(
 int md,
 gsl_matrix *Sample, gsl_matrix *mask,
 double Xcenter, double Ycenter,
 QString sampleMatrix,
 double lambda, double detdist, double detelem, double pixelAsymetry
 ) //+++ TODOAsymetry
{
    
    //------------------------------------
    // calculation of radial averaging
    //------------------------------------
    
    double Xc=(double(md)-1.0)/2.0;
    double Yc=(double(md)-1.0)/2.0;
    
    double R;
    
    double rmax =  sqrt( (Xcenter)*(Xcenter) + ( Ycenter)*(Ycenter));
    rmax = GSL_MAX(
                   rmax,
                   sqrt(   ( (md-1) - Xcenter ) * ( (md-1) -
                                                   Xcenter ) + (Ycenter)*(Ycenter)   )
                   );
    rmax = GSL_MAX(
                   rmax,
                   sqrt( ( (md-1) - Xcenter ) * ( (md-1) - Xcenter ) + ( (md-1) - Ycenter)*((md-1) - Ycenter)  ) );
    rmax = GSL_MAX(
                   rmax,
                   sqrt( ( Xcenter ) * ( Xcenter ) + ( ( md-1 ) - Ycenter ) * ( (md - 1 ) - Ycenter )  ) );
    
    int ir,ii;                  //iR iPhi...
    int ix1,iy1,ix2,iy2;                //...
    int msk, phisteps;          //mask &
    
    double qr,phi,xs,ys,rex,rey;
    double wt,rad;
    
    double pi=M_PI;
    
    double Iphi, twtPhi;
    
    //+++ Ext
    QString currentExt=lineEditFileExt->text().remove(" ");
    if(currentExt!="") currentExt+="-";
    
    //+++ Table Name (Phi)
    QString tablePhi;
    tablePhi="Polar-"+currentExt+sampleMatrix+"-Phi";
    
    if (!checkBoxRewriteOutput->isChecked())
    {
        tablePhi+="-";
        tablePhi=app(this)->generateUniqueName(tablePhi);
    }
    
    
    //+++ Phi steps
    phisteps = spinBoxPolar->value();
    
    //+++ skip 1st row and column
    bool skipFirst = checkBoxSkipPolar->isChecked();
    
    int addColRow=1;
    if (skipFirst) addColRow=0;
    //+++ matrix Definition
    gsl_matrix *matrixPolar=gsl_matrix_alloc( phisteps,  int(
                                                             rmax + 0.5 ) + addColRow  );
    
    double qs, qe, phis=0, phie;
    
    
    //+++ R-scan
    for(ir=1-addColRow;ir<=int(rmax+0.5);ir++)
    {
        qr  = 2.*pi/lambda *  (ir*detelem/detdist);
        rad =  detdist / detelem * tan (
                                        2.0*asin(0.5*ir*detelem/detdist) );  // echter rad
        
        //+++
        for(ii=0;ii<phisteps;ii++)
        {
            //+++ Phi
            phi = 2.*pi*ii/phisteps;
            
            //+++
            xs  = Xcenter + rad * cos(phi-pi/2);
            ys  = Ycenter + rad * sin(phi-pi/2);
            
            //+++
            R=detelem*sqrt((xs-Xc)*(xs-Xc)+(ys-Yc)*(ys-Yc));
            
            //+++
            ix1 = int(xs);      //         ! Eckpunkte
            iy1 = int(ys);
            ix2 = ix1 + 1;
            iy2 = iy1 + 1;
            
            rex = xs - ix1;     //        ! Reste f"ur Gewichtung sp"ater
            rey = ys - iy1;
            
            msk = 0;    //        ! linker unterer Punkt
            Iphi=0;
            twtPhi=0;
            
            if (ix1>=0 && ix1<md && iy1>=0 && iy1<md)
            {
                //+++
                msk = int( gsl_matrix_get(mask,iy1,ix1) );
                wt  = msk*(1.0-rex)*(1.0-rey);
                //+++
                Iphi+=wt *gsl_matrix_get(Sample,iy1,ix1);
                twtPhi+=wt;
            }
            
            msk = 0;    //              ! rechter unterer Punkt
            
            if (ix2>=0 && ix2<md && iy1>=0 && iy1<md)
            {
                msk =int( gsl_matrix_get(mask,iy1,ix2)  );
                wt  = msk*(rex)*(1.0-rey);
                //+++ I vs Phi
                Iphi+=wt *gsl_matrix_get(Sample,iy1,ix2);
                twtPhi += wt;
            }
            
            msk = 0;//               ! linker oberer Punkt
            
            if (ix1>=0 && ix1<md && iy2>=0 && iy2<md)
            {
                msk =int( gsl_matrix_get(mask,iy2,ix1) );
                wt  = msk*(1.0-rex)*(rey);
                //+++ I vs Phi
                Iphi += wt *gsl_matrix_get(Sample,iy2,ix1);
                twtPhi += wt;
            }
            
            msk = 0;//               ! rechter oberer Punkt
            
            if (ix2>=0 && ix2<md && iy2>=0 && iy2<md)
            {
                msk =int( gsl_matrix_get(mask,iy2,ix2));
                wt  = msk*(rex)*(rey);
                //+++ I vs Phi
                Iphi += wt *gsl_matrix_get(Sample,iy2,ix2);
                twtPhi += wt;
            }
            
            
            if (twtPhi>0)
            {
                int shiftAngle=ii+int( double(0.5 * double(phisteps)));
                if (shiftAngle>=phisteps) shiftAngle-=phisteps;
                
                shiftAngle+=int( double(spinBoxPolarShift->value()) / 360.0 * double(phisteps));
                if (shiftAngle>=phisteps) shiftAngle-=phisteps;
                shiftAngle=phisteps-1-shiftAngle;
                
                gsl_matrix_set(matrixPolar,shiftAngle,ir-1+addColRow,Iphi/twtPhi);
            }
            else
                gsl_matrix_set(matrixPolar,ii,ir-1+addColRow,0);
            if (ii==0 && !skipFirst) gsl_matrix_set(matrixPolar,ii,ir-1+addColRow,qr);
            if (ir==0 && !skipFirst) gsl_matrix_set(matrixPolar,ii,ir-1+addColRow,phi);
            if (ii==0 && ir==1-addColRow) qs=qr;
            
            if (ii==phisteps-1 && ir==int(rmax + 0.5 ) + addColRow-1)
            {
                qe=qr; phie=phi;
            }
            
        }
    }
    
    if (radioButtonOpenInProject->isChecked())     
    {
        if(!checkBoxSkipPolar->isChecked())
        {
            makeMatrixUni( matrixPolar, tablePhi, int(rmax+0.5)+addColRow, phisteps, 0.5,int(rmax+0.5)+addColRow+0.5,0.5,phisteps+0.5);
        }
        else
        {
            makeMatrixUni( matrixPolar, tablePhi, int(rmax+0.5)+addColRow, phisteps, qs, qe, (phie-2*M_PI)/2.0/M_PI*180 , ( phie+2*M_PI)/2.0/M_PI*180 );
        }
    }
    else
    {
        if (checkBoxSortOutputToFolders->isChecked())	
        {	
            QDir dd;
            if (!dd.cd(lineEditPathRAD->text()+"/ASCII-POLAR")) 
            {	
                dd.mkdir(lineEditPathRAD->text()+"/ASCII-POLAR"); 			
            }
            saveMatrixToFile(lineEditPathRAD->text()+"/ASCII-POLAR/Polar-"+currentExt+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT",matrixPolar, phisteps,1+int(rmax+0.5));
        }
        else saveMatrixToFile(lineEditPathRAD->text()+"/Polar-"+currentExt+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT",matrixPolar, phisteps,1+int(rmax+0.5));
        
    }
    
    
    gsl_matrix_free(matrixPolar);
}


//+++
void dan16::sigmaMatrix
(
 int md, gsl_matrix *mask,
 double Xcenter, double Ycenter,
 QString sampleMatrix,
 double lambda, double deltaLambda, double C, double detdist, double detelem, double r1, double r2
 )
{
    //+++
    
    //------------------------------------
    // calculation of radial averaging
    //------------------------------------
    double R, Q;
    
    gsl_matrix* sigmaMa=gsl_matrix_alloc(md,md);
    
    for (int xxx=0;xxx<md;xxx++)    for (int yyy=0;yyy<md;yyy++)
    {
        //+++
        R=detelem*sqrt((xxx-Xcenter)*(xxx-Xcenter)+(yyy-Ycenter)*(yyy-Ycenter));
        Q  = 4.0*M_PI/lambda * sin(0.5*atan(R/detdist));
        gsl_matrix_set(sigmaMa,yyy,xxx, sigma( Q, detdist, C, lambda, deltaLambda,  r1, r2 ));
    }
    
    gsl_matrix_mul_elements(sigmaMa,mask);
    
    
    if (radioButtonOpenInProject->isChecked()) makeMatrixSymmetric(sigmaMa,sampleMatrix,"SIGMA::Matrix",md);
    else
    {
        if (checkBoxSortOutputToFolders->isChecked())
        {
            QDir dd;
            if (!dd.cd(lineEditPathRAD->text()+"/ASCII-Sigma"))
            {
                dd.mkdir(lineEditPathRAD->text()+"/ASCII-Sigma");
            }
            saveMatrixToFile(lineEditPathRAD->text()+"/ASCII-Sigma/"+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT",sigmaMa, md);
        }
        else saveMatrixToFile(lineEditPathRAD->text()+"/"+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT",sigmaMa, md);
        
    }
    
    gsl_matrix_free(sigmaMa);
}


//+++
void dan16::MatrixQ
(
 int md, gsl_matrix *mask,
 double Xcenter, double Ycenter,
 QString sampleMatrix,
 double lambda, double detdist, double detelem
 )
{
    //------------------------------------
    // calculation of radial averaging
    //------------------------------------
    double R, Q;
    
    gsl_matrix* matrixQ=gsl_matrix_alloc(md, md);
    
    for (int xxx=0;xxx<md;xxx++)    for (int yyy=0;yyy<md;yyy++)
    {
        //+++
        R=detelem*sqrt((xxx-Xcenter)*(xxx-Xcenter)+(yyy-Ycenter)*(yyy-Ycenter));
        Q  = 4.0*M_PI/lambda * sin(0.5*atan(R/detdist));
        gsl_matrix_set(matrixQ,yyy,xxx, Q);
    }
    
    gsl_matrix_mul_elements(matrixQ,mask);
    
    if (radioButtonOpenInProject->isChecked()) makeMatrixSymmetric(matrixQ,sampleMatrix,"Q::Matrix", md);
    else
    {
        if (checkBoxSortOutputToFolders->isChecked())
        {	QDir dd;
            if (!dd.cd(lineEditPathRAD->text()+"/ASCII-Q"))
            {
                dd.mkdir(lineEditPathRAD->text()+"/ASCII-Q");
            }
            saveMatrixToFile(lineEditPathRAD->text()+"/ASCII-Q/"+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT",matrixQ, md);
        }
        else saveMatrixToFile(lineEditPathRAD->text()+"/"+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT",matrixQ, md);
        
    }
    
    gsl_matrix_free(matrixQ);
}

//+++
void dan16::dQmatrix
(
 int md, gsl_matrix *mask,
 double Xcenter, double Ycenter,
 QString sampleMatrix,
 double lambda, double detdist, double detelem )
{
    //+++
    
    //------------------------------------
    // calculation of radial averaging
    //------------------------------------
    double R, Q;
    double epsilonR;
    double epsilonLambda=0.01;
    double epsilonD=1.0/detdist;
    gsl_matrix* matrixQ=gsl_matrix_alloc(md, md);
    
    for (int xxx=0;xxx<md;xxx++)    for (int yyy=0;yyy<md;yyy++)
    {
        //+++
        R=detelem*sqrt((xxx-Xcenter)*(xxx-Xcenter)+(yyy-Ycenter)*(yyy-Ycenter));
        Q  = 4.0*M_PI/lambda * sin(0.5*atan(R/detdist));
        epsilonR=2.0*M_PI*detelem/Q/lambda/detdist;
        gsl_matrix_set(matrixQ,yyy,xxx, Q*sqrt(epsilonR*epsilonR+epsilonLambda*epsilonLambda+epsilonD*epsilonD));
    }
    
    gsl_matrix_mul_elements(matrixQ,mask);
    
    if (radioButtonOpenInProject->isChecked()) makeMatrixSymmetric(matrixQ,sampleMatrix,"dQ::Matrix", md);
    else
    {
        if (checkBoxSortOutputToFolders->isChecked())
        {	QDir dd;
            if (!dd.cd(lineEditPathRAD->text()+"/ASCII-dQ"))
            {
                dd.mkdir(lineEditPathRAD->text()+"/ASCII-dQ");
            }
            saveMatrixToFile(lineEditPathRAD->text()+"/ASCII-dQ/"+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT",matrixQ, md);
        }
        else saveMatrixToFile(lineEditPathRAD->text()+"/"+sampleMatrix+"-"+comboBoxSel->currentText()+".DAT",matrixQ, md);
        
    }    
    gsl_matrix_free(matrixQ);
}

//*******************************************
//+++ Structure to Find Center
//*******************************************
struct structCenter
{
    gsl_matrix * corund;
    gsl_matrix * mask;
    int dim;
};


//+++ Xc function Int
double functionToFindXcenterInt (int Xc, void * params)
{
    gsl_matrix *corund  = ((struct structCenter *)params)->corund;
    gsl_matrix *mask    = ((struct structCenter *)params)->mask;
    int dim             = ((struct structCenter *)params)->dim;
    
    double result=0;
    int pixels=0;
    double temp;
    double left,right;
    
    int maxPoints=GSL_MIN( (dim-1-Xc) , Xc) - 10; //+++
    
    for (int yy=10; yy<(dim-10);yy++)
    {
        for (int xx=0; xx<maxPoints;xx++)
        {
            left=gsl_matrix_get(corund, yy, Xc-1.0-xx);
            right=gsl_matrix_get(corund, yy, Xc+1.0+xx);
            
            temp=gsl_matrix_get(mask, yy, Xc-xx-1)*gsl_matrix_get(mask, yy, Xc+xx+1);
            
            pixels+=int(temp);
            
            temp*=(right-left)*(right-left);
            
            result+=temp;
        }
    }
    return result/pixels;
}


//+++ Yc function Int
double functionToFindYcenterInt (int Yc, void * params)
{
    gsl_matrix *corund  = ((struct structCenter *)params)->corund;
    gsl_matrix *mask    = ((struct structCenter *)params)->mask;
    int dim             = ((struct structCenter *)params)->dim;
    
    double result=0;
    int pixels=0;
    double temp;
    double left,right;
    
    int maxPoints=GSL_MIN( (dim-1-Yc), Yc) - 10; //+++
    
    for (int xx=10; xx<(dim-10);xx++)
    {
        for (int yy=0; yy<maxPoints;yy++)
        {
            left=gsl_matrix_get(corund, Yc-1-yy, xx);
            right=gsl_matrix_get(corund, Yc+1+yy, xx);
            
            temp=gsl_matrix_get(mask, Yc-yy-1,xx)*gsl_matrix_get(mask, Yc+yy+1,xx);
            
            pixels+=temp;
            
            temp*=(right-left)*(right-left);
            
            result+=temp;
        }
    }
    return result/pixels;
}


//+++ Xc function
double functionToFindXcenter (double Xc, void * params)
{
    gsl_matrix *corund  = ((struct structCenter *)params)->corund;
    gsl_matrix *mask    = ((struct structCenter *)params)->mask;
    int dim             = ((struct structCenter *)params)->dim;
    
    double result=0;
    int pixels=0;
    double temp;
    double left,right;
    double delta=Xc-(int)Xc;
    int maxPoints=30;//GSL_MIN((dim-1-(int)Xc), (int)Xc) - 15; //+++
    
    for (int yy=15; yy<(dim-15);yy++)
    {
        for (int xx=0; xx<maxPoints;xx++)
        {
            left=(1-delta)*gsl_matrix_get(corund, yy, (int)(Xc)-xx-1)+
            (delta)*gsl_matrix_get(corund, yy, (int)(Xc)-xx);
            right=(1-delta)*gsl_matrix_get(corund, yy, (int)(Xc)+xx+1)+
            (delta)*gsl_matrix_get(corund, yy, (int)(Xc)+xx+2);
            
            temp=gsl_matrix_get(mask, yy, (int)(Xc)-xx-1);
            temp*=gsl_matrix_get(mask, yy, (int)(Xc)-xx);
            temp*=gsl_matrix_get(mask, yy, (int)(Xc)+xx+1);
            temp*=gsl_matrix_get(mask, yy, (int)(Xc)+xx+2);
            
            pixels+=temp;
            
            temp*=fabs(right);
            
            result+=temp;
        }
    }
    return result/pixels;
}

double functionToFindYcenter (double Yc, void * params)
{
    gsl_matrix *corund  = ((struct structCenter *)params)->corund;
    gsl_matrix *mask    = ((struct structCenter *)params)->mask;
    int dim             = ((struct structCenter *)params)->dim;
    
    double result=0.0;
    int pixels=0;
    double temp;
    double left,right;
    double delta=Yc-(int)(Yc);
    int maxPoints=GSL_MIN((dim-1-(int)Yc), (int)Yc )-15; //+++
    
    for (int xx=15; xx<(dim-15);xx++)
    {
        for (int yy=0; yy<maxPoints;yy++)
        {
            left=(1-delta)*gsl_matrix_get(corund, (int)(Yc)-yy-1, xx)+
            (delta)*gsl_matrix_get(corund, (int)(Yc)-yy,xx);
            right=(1-delta)*gsl_matrix_get(corund, (int)(Yc)+yy+1,xx)+
            (delta)*gsl_matrix_get(corund, (int)(Yc)+yy+2,xx);
            
            
            temp=gsl_matrix_get(mask, (int)(Yc)-yy-1, xx);
            temp*=gsl_matrix_get(mask, (int)(Yc)-yy,xx);
            temp*=gsl_matrix_get(mask, (int)(Yc)+yy+1, xx);
            temp*=gsl_matrix_get(mask, (int)(Yc)+yy+2,xx);
            pixels+=temp;
            temp*=(right-left)*(right-left);
            result+=temp;
        }
    }
    return result/pixels;
}


//+++++SLOT::calculate centere+++++++++++++++++++++++++++++++++++++++++++++++++++++
void dan16::calcCenterNew()
{
    int i;
    
    // Number of C-D conditionws
    int Nconditions=tableECnew->numCols();
    
    // find center for each C-D condition
    for(i=0;i<Nconditions;i++)
    {
        calcCenterNew(i);
    }
}


//+++++SLOT::calculate centere+++++++++++++++++++++++++++++++++++++++++++++++++++++
void dan16::calcCenterNew(int col)
{
    //Variables definitin
    QString D;
    double Xc, Yc;
    double XcErr=0.0, YcErr=0.0;
    QString sampleFile=tableECnew->text(dptCENTER,col);
    
    
    if (radioButtonCenterReadFromHeader->isChecked())
    {
        Xc=readDetectorX( sampleFile );
        Yc=readDetectorY( sampleFile );
    }
    else
    {
        ImportantConstants();
        
        
        // find center for each C-D condition
        Xc=tableECnew->text(dptCENTERX,col).left(tableECnew->text(dptCENTERX,col).find(QChar(177))).toDouble();
        
        if (Xc<(MD/20.0) || Xc>(19.0*MD/20.0)) Xc=(MD+1.0)/2.0;
        Yc=tableECnew->text(dptCENTERY,col).left(tableECnew->text(dptCENTERY,col).find(QChar(177))).toDouble();
        if (Yc<(MD/20.0) || Yc>(19.0*MD/20.0)) Yc=(MD+1.0)/2.0;
        
        D=tableECnew->text(dptD,col);
        
        QString maskName=comboBoxMaskFor->currentText();
        QString sensName=comboBoxSensFor->currentText();
        
        //+++ Mask & Sens +++
        QStringList listMask, listSens;
        QString winLabelMask="DAN::Mask::"+QString::number(MD);
        QString winLabelSens="DAN::Sensitivity::"+QString::number(MD);
        
        findMatrixListByLabel(winLabelMask, listMask);
        if (!listMask.contains("mask")) listMask.prepend("mask");
        findMatrixListByLabel(winLabelSens, listSens);
        if (!listSens.contains("sens")) listSens.prepend("sens");
        
        //+++ mask reading +++
        if (listMask.contains(tableECnew->text(dptMASK,col)) )
        {
            maskName=tableECnew->text(dptMASK,col);
        }
        
        //+++ mask reading +++
        if (listSens.contains(tableECnew->text(dptSENS,col)) )
        {
            sensName=tableECnew->text(dptSENS,col);
        }
        
        calcCenterNew(sampleFile, col, Xc, Yc, XcErr, YcErr, maskName, sensName);
    }
    
    tableECnew->setText(dptCENTERX,col, QString::number(Xc,'f',3) +QChar(177)+QString::number(XcErr,'f',3));
    tableECnew->setText(dptCENTERY,col, QString::number(Yc,'f',3)+QChar(177)+QString::number(YcErr,'f',3));
}


//+++++SLOT::calculate centere+++++++++++++++++++++++++++++++++++++++++++++++++++++
void dan16::calcCenterNew(QString sampleFile, int col, double &Xc, double &Yc, double &XcErr,
                          double &YcErr, QString maskName, QString sensName)
{
    //+++ mask gsl matrix
    gsl_matrix *mask=gsl_matrix_alloc(MD,MD);
    gsl_matrix_set_all(mask, 1.0);
    make_GSL_Matrix_Symmetric( maskName, mask, MD);
    
    //+++ sens gsl matrix
    gsl_matrix *sens=gsl_matrix_alloc(MD,MD);
    gsl_matrix_set_all(sens, 1.0);
    make_GSL_Matrix_Symmetric( sensName, sens, MD);
    
    //Variables definitin
    bool existCorund;
    
    //Matrix allocation
    gsl_matrix *corund=gsl_matrix_alloc(MD,MD);
    gsl_matrix_set_zero(corund);
    
    //Check existence of Corund File
    existCorund=checkFileNumber( sampleFile );
    
    if (!existCorund)
    {
        QMessageBox::warning(this,tr("QtiKWS"), tr("C-D-Lambda condition # "+QString::number(col+1)+":: corund-file does not exist!"));
        toResLogAll("DAN","C-D-Lambda condition # "+QString::number(col+1)+":: corund-file does not exist!",this);
        gsl_matrix_free(mask);
        gsl_matrix_free(sens);
        gsl_matrix_free(corund);
        
        return;
    }
    
    // read corund matrix
    readMatrixCor( sampleFile, corund );
    
    
    //fileNumber=BCFile.toInt();
    gsl_matrix_mul_elements(corund,mask);
    gsl_matrix_mul_elements(corund,sens);
    
    if (radioButtonRadStdSymm->isChecked())
    {
        
        calcCenterUniSymmetryX(MD, corund, mask, Xc, XcErr);
        calcCenterUniSymmetryY(MD, corund, mask, Yc, YcErr);
    }
    else
    {
        calcCenterUniHF(MD, corund, mask, Xc, Yc, XcErr, YcErr );
    }
    
    gsl_matrix_free(mask);
    gsl_matrix_free(sens);
    
    gsl_matrix_free(corund);
}


//+++++SLOT::calculate X centere Uni Symmetry++++++++++++
void dan16::calcCenterUniSymmetryX
(
 int md, gsl_matrix *corund, gsl_matrix *mask, double &Xc,
 double &XcErr
 )
{
    
    const int numberPoints=2;
    
    int i;
    const int nnnnnnnn=2*numberPoints+1;
    double xi, x[nnnnnnnn], y[nnnnnnnn];
    
    structCenter stct={corund,mask,md};
    
    double min=0.0;
    int imin=0;
    double fun;
    
    int old35=int(md/4.0)+3;
    
    for (i = old35; i <= (md-old35); i++)
    {
        
        fun= functionToFindXcenterInt(i, &stct);
        
        if (i==old35 ||  fun < min ) {imin=i; min=fun;};
    }
    
    if (imin<=(old35+numberPoints) || imin >md-old35-numberPoints)
    {
        Xc=(md+1.0)/2.0;
        XcErr=50.000;
    }
    else
    {
        for (i = 0; i <= (2*numberPoints); i++)
        {
            x[i]=imin-numberPoints+i;
            y[i]=functionToFindXcenterInt(imin-numberPoints+i, &stct);
        }
        
        
        gsl_interp_accel    *acc    = gsl_interp_accel_alloc();
        gsl_spline          *spline = gsl_spline_alloc(gsl_interp_cspline, 2*numberPoints+1);
        
        gsl_spline_init (spline, x, y, 2*numberPoints+1);
        
        double xMin = x[numberPoints-1];
        min=y[numberPoints-1];
        
        for (xi = x[numberPoints-1]; xi <= x[numberPoints+1]; xi += 0.01)
        {
            if ( gsl_spline_eval (spline, xi, acc) < min ) { xMin=xi; min =
                gsl_spline_eval (spline, xi, acc);};
        }
        
        Xc=xMin+1.0;
        
        if ( imin==(int)Xc )
            XcErr= fabs( fabs( (y[numberPoints+1]-min)/
                              (y[numberPoints+2]-y[numberPoints+1]) ) + fabs (
                                                                              (y[numberPoints]-min)/ (y[numberPoints-1]-y[numberPoints]) ) )/10.0;
        else
            XcErr= fabs ( fabs( (y[numberPoints]-min)/
                               (y[numberPoints+1]-y[numberPoints]) ) + fabs (
                                                                             (y[numberPoints-1]-min)/ (y[numberPoints-2]-y[numberPoints-1]) ) )/10.0;
        
        gsl_spline_free(spline);
        gsl_interp_accel_free(acc);
    }
}


//+++++SLOT::calculate X centere Uni Symmetry++++++++++++++++
void dan16::calcCenterUniSymmetryY
(
 int md, gsl_matrix *corund, gsl_matrix *mask, double &Yc,
 double &YcErr
 )
{
    
    
    const int numberPoints=2;
    
    int i;
    const int nnnnnnnn=2*numberPoints+1;
    double xi, x[nnnnnnnn], y[nnnnnnnn];
    
    structCenter stct={corund,mask,md};
    
    double min=0.0;
    int imin=0;
    double fun;
    
    int old35=int(md/4.0)+3;
    
    for (i = old35; i <= (md-old35); i++)
    {
        fun= functionToFindYcenterInt(i, &stct);
        if (i==old35 || fun < min ) {imin=i; min=fun;};
    }
    
    if (imin<=(old35+numberPoints) || imin >md-old35-numberPoints)
    {
        Yc=(md+1.0)/2.0;
        YcErr=50.000;
    }
    else
    {
        for (i = 0; i <= (2*numberPoints); i++)
        {
            x[i]=imin-numberPoints+i;
            y[i]=functionToFindYcenterInt(imin-numberPoints+i, &stct);
        }
        
        gsl_interp_accel    *acc    = gsl_interp_accel_alloc();
        gsl_spline          *spline = gsl_spline_alloc(gsl_interp_cspline, 2*numberPoints+1);
        
        gsl_spline_init (spline, x, y, 2*numberPoints+1);
        
        double xMin = x[numberPoints-1];
        
        min=y[numberPoints-1];
        
        for (xi = x[numberPoints-1]; xi <= x[numberPoints+1]; xi += 0.01)
        {
            // printf ("%4.2f %E\n", xi, gsl_spline_eval (spline, xi, acc));
            if ( gsl_spline_eval (spline, xi, acc) < min ) { xMin=xi; min =
                gsl_spline_eval (spline, xi, acc);};
        }
        
        Yc=xMin+1.0;
        
        if ( imin==(int)xMin )
            YcErr= fabs( fabs( (y[numberPoints+1]-min)/
                              (y[numberPoints+2]-y[numberPoints+1]))  + fabs (
                                                                              (y[numberPoints]-min)/ (y[numberPoints-1]-y[numberPoints]) ) )/10.0;
        else
            YcErr= fabs ( fabs ((y[numberPoints]-min)/
                                (y[numberPoints+1]-y[numberPoints]) ) + fabs( (y[numberPoints-1]-min)/
                                                                             (y[numberPoints-2]-y[numberPoints-1]) ) )/10.0;
        
        gsl_spline_free(spline);
        gsl_interp_accel_free(acc);
    }
    
    
}



//+++ Resolution Function: Sigma +++
double dan16::sigma( double Q, double D, double C, double Lambda, double deltaLambda,
                    double r1, double r2)
{
    return sigmaQmerged(Q, D, C, Lambda, deltaLambda, r1, r2, 1);
}

double dan16::sigmaQmerged( double Q, double D, double C, double Lambda, double deltaLambda,
                           double r1, double r2, int numberMergedQ)
{
    double PI =M_PI;
    double pixel=lineEditResoPixelSize->text().toDouble();
    double pixelAsymetry  = lineEditAsymetry->text().toDouble();
    
    double binning=comboBoxBinning->currentText().toDouble();
    double Rdet    =numberMergedQ*binning*(1.0+pixelAsymetry)/2.0*pixel/M_SQRTPI;      //[cm]
    
    //+++ new
    double RdetReso=lineEditDetReso->text().toDouble()/M_SQRTPI;
    if (RdetReso>Rdet) Rdet=RdetReso;
    //---
    
    double SigQ2,SigQ;
    
    if (checkBoxResoFocus->isChecked())
    {
        C=D;
        double f=D/2.0;
        SigQ2=PI*PI/Lambda/Lambda/3.0*(3.0*r1*r1/C/C+2.0*r2*r2/f/f*deltaLambda*deltaLambda+Rdet*Rdet/D/D+Lambda*Lambda/2.0/2.0/PI/PI*Q*Q*deltaLambda*deltaLambda);
        
        SigQ=2*0.4246609*sqrt(SigQ2);
        return SigQ;
    }
    
    
    
    double Theta0,cos2Theta02, a1, a2, beta1;
    double K0                 = 2.0*PI/Lambda;   //[A-1]
    
    //
    Theta0          = asin(Q/2.0/K0);
    cos2Theta02     = cos(2.0*Theta0)*cos(2.0*Theta0);
    
    //+++ Sigma-D1  +++
    double SigmaDetector      = K0*cos(Theta0)*cos2Theta02*Rdet/D;       //[A-1]
    
    //
    if (cos2Theta02!=0.0) a1 = r1/(C+D/cos2Theta02); else a1 =0.0;
    a2 = r2*cos2Theta02/D;
    
    //
    if (a2>a1)
    {
        beta1   =2.0*r2*(1.0/C+cos2Theta02/D)-r1*r1*D/(2.0*r2*cos2Theta02*C*(C+D/cos2Theta02));
    }
    else
    {
        beta1   =2.0*r1/C-0.5*r2*r2/r1*cos2Theta02*cos2Theta02*(C+D/cos2Theta02)*(C+D/cos2Theta02)/C/D/D;
    }
    
    //+++ Sigma-W  +++
    SigQ2        =Q*Q*deltaLambda*deltaLambda;
    //+++ Sigma-D1  +++
    SigQ2       +=SigmaDetector*SigmaDetector;
    //+++ Sigma-C1  +++
    SigQ2       +=K0*K0*cos(Theta0)*cos(Theta0)*beta1*beta1;
    //+++  Sigma-AV  +++
    SigQ2       +=K0*K0*cos(Theta0)*cos(Theta0)*cos2Theta02*cos2Theta02*Rdet/D*Rdet/D;
    //
    SigQ         =0.4246609*sqrt(SigQ2); //[A-1];
    
    return SigQ;
}


//+++ Q-error +++
double dan16::dQ( double Q, int numberF , double d, double D, double pixel )
{
    double deltaLambda=0;
    if (numberF>100) deltaLambda=1/sqrt(double(numberF));
    else deltaLambda=0.01;
    
    double deltaSmalD=0;
    if (d>0) deltaSmalD=0.5*pixel/d;
    
    double deltaD=0;
    if (D<50.0) deltaD=1.0/D;
    else if (D<400.0) deltaD=2.0/D;
    else deltaD=5.0/D;
    
    
    return Q * sqrt ( deltaLambda*deltaLambda + deltaD*deltaD + deltaSmalD*deltaSmalD );
}

//+++++SLOT::calculate centere/Uni-HF+++++++++++++++++++++++++++++++++++++++++++++++++++++
void dan16::calcCenterUniHF(int md, gsl_matrix *corund,
                            gsl_matrix *mask, double &Xc, double &Yc, double &XcErr, double &YcErr
                            )
{
    // Henrich code
    double Xcenter=Xc-1.0;         //Initial Value
    double Ycenter=Yc-1.0;
    int MinX=0;                         // maximum range for center value (hard to define)
    int MinY=0;
    int MaxX=md-1;
    int MaxY=md-1;
    
    double Xstep=100.0;
    double Ystep=100.0;
    int totStep=0;
    
    double MinStep=0.001;       // Constant, smallest step when loop ends
    int ix,iy;
    
    while(totStep<=50 && (fabs(Xstep)>=MinStep || fabs(Ystep)>=MinStep))
    {
        double MomX=0.0;
        double MomY=0.0;
        double Norm=0.0;
        
        int mask1, mask2, imx, imy;
        
        
        for(ix=0;ix<md;ix++) for(iy=0;iy<md;iy++)
        {
            
            mask1=int( gsl_matrix_get(mask, iy, ix) );
            
            mask2=0;
            imx=int(2.0*Xcenter-ix+0.5);
            imy=int(2.0*Ycenter-iy+0.5);
            
            if ( imx>=0 && imx<md && imy>=0 && imy<md)
                mask2 = int( gsl_matrix_get(mask,imy,imx) );
            
            if ((mask1*mask2) != 0)
            {
                MomX += (ix-Xcenter)*gsl_matrix_get(corund,iy,ix);
                MomY += (iy-Ycenter)*gsl_matrix_get(corund,iy,ix);
                Norm +=gsl_matrix_get(corund,iy,ix);
            }
        }
        
        
        
        if (Norm>0.0)
        {
            Xstep = MomX / Norm;
            Ystep = MomY / Norm;
        }
        else
        {
            Xstep = 0.0;
            Ystep = 0.0;
        }
        
        if ((Xcenter+Xstep)>MaxX)
        {
            Xstep  = MaxX - Xcenter;
            Xcenter = MaxX;
        }
        else if ((Xcenter+Xstep)< MinX)
        {
            Xstep   = MinX - Xcenter;
            Xcenter = MinX;
        }
        else
        {
            Xcenter = Xcenter + Xstep;
        }
        
        if ((Ycenter+Ystep) > MaxY)
        {
            Ystep   = MaxY - Ycenter;
            Ycenter = MaxY;
        }
        else  if ((Ycenter+Ystep)<MinY)
        {
            Ystep   = MinY - Ycenter;
            Ycenter = MinY;
        }
        else
        {
            Ycenter = Ycenter + Ystep;
        }
        
        totStep = totStep + 1;
    }
    Xc=Xcenter+1.0;
    Yc=Ycenter+1.0;
    
    // !!!!!! Error-bar calculation for Xc
    int loop_test=15;
    int loop_PM=int(loop_test/2);
    int ii;
    
    gsl_vector *XcNear=gsl_vector_alloc(loop_test);
    gsl_vector *YcNear=gsl_vector_alloc(loop_test);
    
    gsl_vector *M1Xc=gsl_vector_alloc(loop_test);
    gsl_vector *M1Yc=gsl_vector_alloc(loop_test);
    
    for (ii=0; ii<loop_test;ii++)
    {
        Xcenter=Xc-1+(ii-loop_PM)*0.5;
        gsl_vector_set(XcNear,ii,Xcenter);
        Ycenter=Yc-1+(ii-loop_PM)*0.5;
        gsl_vector_set(YcNear,ii,Ycenter);
    }
    
    double ys=0.0, xs=0.0,yys=0.0, xxs=0.0,xys=0.0;
    
    for (ii=0; ii<loop_test;ii++)
    {
        Xcenter=Xc-1+(ii-loop_PM)*0.5;
        Ycenter=Yc-1;
        
        double MomX=0.0;
        double MomY=0.0;
        double Norm=0.0;
        
        int mask1, mask2, imx, imy;
        for(ix=0;ix<md;ix++) for(iy=0;iy<md;iy++)
        {
            mask1=int ( gsl_matrix_get(mask,iy,ix) );
            mask2=0;
            imx=int(2.0*Xcenter-ix+0.5);
            imy=int(2.0*Ycenter-iy+0.5);
            
            if ( imx>=0 && imx<md && imy>=0 && imy<md)
                mask2 = int( gsl_matrix_get(mask,imy,imx) );
            
            if ((mask1*mask2) != 0)
            {
                MomX += (ix-Xcenter)*gsl_matrix_get(corund,iy,ix);
                MomY += (iy-Ycenter)*gsl_matrix_get(corund,iy,ix);
                Norm +=gsl_matrix_get(corund,iy,ix);
            }
        }
        if (Norm>0.0)
        {
            MomX = MomX / Norm;
            MomY = MomY / Norm;
        }
        
        gsl_vector_set(M1Xc,ii, MomX);
        
        ys+=  Xcenter;
        xs+=  MomX;
        yys+= Xcenter*Xcenter;
        xxs+= MomX*MomX;
        xys+= MomX*Xcenter;
    }
    
    
    double Delta = loop_test*xxs - xs*xs;
    double Aordi = (xxs*ys-xs*xys)/Delta;
    double Bslop = (loop_test*xys-xs*ys )/Delta;
    
    double  ssig=0.0;
    for (ii=0; ii<loop_test;ii++)
    {
        ssig += pow( (gsl_vector_get(XcNear,ii) - Aordi -
                      Bslop*gsl_vector_get(M1Xc,ii)), 2);
    }
    
    //+++
    XcErr=sqrt(ssig*xxs/Delta);
    
    ys=0.0; xs=0.0; yys=0.0; xxs=0.0; xys=0.0;
    
    for (ii=0; ii<loop_test;ii++)
    {
        Ycenter=Yc-1+(ii-loop_PM)*0.5;
        Xcenter=Xc-1;
        
        double MomX=0.0;
        double MomY=0.0;
        double Norm=0.0;
        
        int mask1, mask2, imx, imy;
        
        for(ix=0;ix<md;ix++) for(iy=0;iy<md;iy++)
        {
            mask1=int( gsl_matrix_get(mask,iy,ix) );
            mask2=0;
            imx=int(2.0*Xcenter-ix+0.5);
            imy=int(2.0*Ycenter-iy+0.5);
            
            
            if ( imx>=0 && imx<md && imy>=0 && imy<md)
                mask2 = int( gsl_matrix_get(mask,imy,imx) );
            
            if ((mask1*mask2) != 0)
            {
                MomX += (ix-Xcenter)*gsl_matrix_get(corund,iy,ix);
                MomY += (iy-Ycenter)*gsl_matrix_get(corund,iy,ix);
                Norm +=gsl_matrix_get(corund,iy,ix);
            }
        }
        if (Norm>0.0)
        {
            MomX = MomX / Norm;
            MomY = MomY / Norm;
        }
        
        gsl_vector_set(M1Yc,ii, MomY);
        
        ys+=  Ycenter;
        xs+=  MomY;
        yys+= Ycenter*Ycenter;
        xxs+= MomY*MomY;
        xys+= MomY*Ycenter;
    }
    
    Delta = loop_test*xxs - xs*xs;
    Aordi = (xxs*ys-xs*xys)/Delta;
    Bslop = (loop_test*xys-xs*ys )/Delta;
    
    ssig=0.0;
    for (ii=0; ii<loop_test;ii++)
    {
        ssig += pow( (gsl_vector_get(YcNear,ii) - Aordi -
                      Bslop*gsl_vector_get(M1Yc,ii)), 2);
    }
    
    //+++
    YcErr=sqrt(ssig*xxs/Delta);
    
    
    gsl_vector_free(XcNear);
    gsl_vector_free(YcNear);
    gsl_vector_free(M1Xc);
    gsl_vector_free(M1Yc);
    
}

//*******************************************
//+++ dan
//*******************************************
bool dan16::danDanMultiButtonSingleLine(    QString button,
                                            QString label, QString Nsample,QString NEC, QString NBC, QString Nbuffer, QString maskName, QString sensName,
                                            double Detector, double C, double Lambda,
                                            double trans, double transBuffer, double fractionBuffer, double thickness,
                                            double abs0, double Xcenter, double Ycenter,
                                            double scale, double BackgroundConst,double VShift,double HShift
                                        )
{
    //+++ Update paramters
    ImportantConstants();
    
    //+++ Output data Suffix
    QString dataSuffix;
    switch (comboBoxMode->currentItem())
    {
        case 0:
            dataSuffix="SM";
            break;
        case 1:
            dataSuffix="BS";
            break;
        case 2:
            dataSuffix="BS-SENS";
            break;
        case 3:
            dataSuffix="SM";
            break;
        case 4:
            dataSuffix="SM";
            break;
        default:
            dataSuffix="SM";
            break;
    }
    
    //+++ Subtract Bufffer
    bool subtractBuffer= false;
    if (comboBoxMode->currentText().contains("(BS)")) subtractBuffer=true;
    
    if (fractionBuffer==0.0) subtractBuffer= false;
    
    //+++ result string info for current row
    QString status="... "+Nsample+" ";
    
    //+++ mask gsl matrix
    gsl_matrix *mask = gsl_matrix_calloc(MD,MD);
    if (!make_GSL_Matrix_Symmetric(maskName, mask, MD))
    {
//        gsl_matrix_free(mask);
//        status+=">>> no mask [e01]";
                gsl_matrix_set_all(mask,1.0);
//        toResLogAll("DAN",status,this);
//        return false;
    }
    
    //+++ sens gsl matrix
    gsl_matrix *sens=gsl_matrix_calloc(MD,MD);
    gsl_matrix *sensErr=gsl_matrix_calloc(MD,MD);
    
    if (!make_GSL_Matrix_Symmetric(sensName, sens, MD))
    {
//        gsl_matrix_free(mask);
//        gsl_matrix_free(sens);
//        gsl_matrix_free(sensErr);
//        status+=">>> no sens [e02]";
        gsl_matrix_set_all(sens,1.0);
        gsl_matrix_set_all(sensErr,1.0);
//        toResLogAll("DAN",status,this);
//        return false;
    }
    
    //+++
    sensAndMaskSynchro(mask, sens, MD );
    
    //+++ I-Qx +  >>>>
    if (button=="I-Qx")
    {
        int from=spinBoxFrom->value();
        int to=spinBoxTo->value();
        if (from <=to && from>0 && to<=MD)
        {
            for (int xxx=0; xxx<MD; xxx++ ) for (int yyy=0; yyy<(from-1); yyy++ ) gsl_matrix_set(mask,yyy,xxx, 0.0 );
            for (int xxx=0; xxx<MD; xxx++ ) for (int yyy=to; yyy<MD; yyy++ ) gsl_matrix_set(mask,yyy,xxx, 0.0 );
        }
    }
    //--- I-Qx - >>>>
    
    //+++ I-Qy + >>>>
    if (button=="I-Qy")
    {
        int from=spinBoxFrom->value();
        int to=spinBoxTo->value();
        if (from <=to && from>0 && to<=MD)
        {
            for (int yyy=0; yyy<MD; yyy++ ) for (int xxx=0; xxx<(from-1); xxx++ ) gsl_matrix_set(mask,yyy,xxx, 0.0 );
            for (int yyy=0; yyy<MD; yyy++ ) for (int xxx=to; xxx<MD; xxx++ ) gsl_matrix_set(mask,yyy,xxx, 0.0 );
        }
    }
    //---- I-Qy -  >>>>
    
    
    //+++ Sensetivty Error Matrix
    QString sensFile=getSensitivityNumber(sensName);
    if (checkFileNumber(sensFile)) readErrorMatrix( sensFile, sensErr);
    
    
    
    //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    //+++ All actions only in case Sample Exists                   !!!!!!!!!!!!!!!!
    //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    if (!checkFileNumber( Nsample ))
    {
        gsl_matrix_free(mask);
        gsl_matrix_free(sens);
        gsl_matrix_free(sensErr);
        status+=">>> file "+Nsample+" not found; output:: no [e03]";
        toResLogAll("DAN",status,this);
        return false;
    }
    
    //+++ sample matrixes
    gsl_matrix *Sample=gsl_matrix_calloc(MD,MD);
    gsl_matrix *SampleErr=gsl_matrix_calloc(MD,MD);
    
    //+++
    readMatrixCor( Nsample, Sample);
    readErrorMatrix( Nsample, SampleErr);
    
    gslMatrixShift(Sample, MD, HShift, VShift );
    gslMatrixShift(SampleErr, MD, HShift, VShift );
    
    //+++
    status=">>>  sample#="+Nsample+": OK  ";
    
    
    
    //+++ buffer matrixes
    gsl_matrix *Buffer=gsl_matrix_calloc(MD,MD);
    gsl_matrix *BufferErr=gsl_matrix_calloc(MD,MD);
    
    if (subtractBuffer)
    {
        if (!checkFileNumber( Nbuffer ))
        {
            gsl_matrix_set_all(Buffer,0.0);
            gsl_matrix_set_all(BufferErr,0.0);
            subtractBuffer=false;
            status+=">>> no buffer [e04]";
        }
        //+++
        readMatrixCor( Nbuffer, Buffer);
        readErrorMatrix( Nbuffer, BufferErr);
    }
    
    
    //+++ EC +++
    bool ECexist=false;
    
    //+++ ec matrixes
    gsl_matrix *EC=gsl_matrix_calloc(MD,MD);
    gsl_matrix *ECErr=gsl_matrix_calloc(MD,MD);
    
    if ( checkFileNumber( NEC ) )
    {
        readMatrixCor( NEC,EC);
        readErrorMatrix( NEC, ECErr);
        status+=">>>  EC#=" + NEC + ": OK  ";
        //+++
        ECexist=true;
    }
    else status+=">>>  EC: no correction  ";
    
    //+++ BC +++
    
    //+++ bc matrixes
    gsl_matrix *BC=gsl_matrix_alloc(MD,MD);
    gsl_matrix *BCErr=gsl_matrix_alloc(MD,MD);
    
    
    if (checkFileNumber( NBC ))
    {
        // read BC matrix 2012
        if (checkBoxBCTimeNormalization->isChecked())
        {
            readMatrixCorTimeNormalizationOnly( NBC, BC );
            
            //Normalization constant
            double TimeSample=spinBoxNorm->value();
            double ttime=readDuration( Nsample );
            if (ttime>0.0) TimeSample/=ttime; else TimeSample=0.0;
            
            double NormSample=readDataNormalization(Nsample);
            
            if (TimeSample>0) NormSample/=TimeSample; else NormSample=0;
            
            gsl_matrix_scale(BC,NormSample);      // EB=T*EB
        }
        else readMatrixCor( NBC, BC );
        
        readErrorMatrix( NBC, BCErr);
        status+=">>>  BC#=" + NBC + ": OK  ";
    }
    else status+=">>>  BC: no correction  ";
    
    
    //+++ transmission check
    if (trans<=0.0 || trans>2.0)
    {
        gsl_matrix_free(mask);
        gsl_matrix_free(sens);
        gsl_matrix_free(sensErr);
        gsl_matrix_free(Sample);
        gsl_matrix_free(SampleErr);
        gsl_matrix_free(Buffer);
        gsl_matrix_free(BufferErr);
        status+=">>> transmission is out 0..2 range check it [e05]: "+QString::number(trans,'f',3);
        toResLogAll("DAN",status,this);
        return false;
        
    }
    else status=status+">>>  Transmission="+QString::number(trans,'f',3)+"  ";
    
    
    //+++ transmission-Buffer check
    if (subtractBuffer)
    {
        //+++ transmission check
        if (transBuffer<=0.0 || transBuffer>2.0)
        {
            gsl_matrix_free(mask);
            gsl_matrix_free(sens);
            gsl_matrix_free(sensErr);
            gsl_matrix_free(Sample);
            gsl_matrix_free(SampleErr);
            gsl_matrix_free(Buffer);
            gsl_matrix_free(BufferErr);
            status+=">>> transmission of buffer is out 0..2 range check it [e06] : "+QString::number(trans,'f',3);
            toResLogAll("DAN",status,this);
            return false;
        }
    } else  transBuffer=1.0;
    
    
    
    //+++ absolute factor check
    status=status+">>>  Abs.Factor="+QString::number(abs0,'e',4)+"  ";
    
    if(thickness!=0) abs0/=thickness;

    double abs=abs0;
    double absBuffer=abs0;

    
    if (trans!=0.0) abs=abs0/trans;
    if (transBuffer!=0.0) absBuffer=abs0/transBuffer;
    
    //+++ X-center check
    status=status+">>>  X-center="+QString::number(Xcenter,'e',4)+"  "; // 2013-09-18
    Xcenter-=1;
    
    //+++ Y-center check
    status=status+">>>  Y-center="+QString::number(Ycenter,'e',4)+"  "; // 2013-09-18
    Ycenter-=1;
    
    
    //+++ error matrix
    gsl_matrix *ErrMatrix=gsl_matrix_calloc(MD,MD);
    
    //+++ Sensitivity Error
    gsl_matrix_add(ErrMatrix, sensErr);
    
    int iii,jjj;
    double err2, Isample, Ibc, Iec;
    
    for (iii=0;iii<MD;iii++) for (jjj=0;jjj<MD;jjj++)
    {
        //+++
        Isample=gsl_matrix_get(Sample,iii,jjj);
        err2=Isample;       //+++
        Isample*=Isample;
        Isample*=gsl_matrix_get(SampleErr,iii,jjj);
        //+++
        Iec=gsl_matrix_get(EC,iii,jjj);
        err2 -= (trans*Iec);        //+++
        Iec*=Iec;
        Iec*=trans*trans;
        Iec*=gsl_matrix_get(ECErr,iii,jjj);
        //+++
        Ibc=gsl_matrix_get(BC,iii,jjj);
        if (Iec>0.0) err2 -= ( (1.0-trans) * Ibc ); else err2 -= Ibc;   //+++
        Ibc*=Ibc;
        if (Iec>0.0) Ibc*=(1.0-trans)*(1.0-trans);
        Ibc*=gsl_matrix_get(BCErr,iii,jjj);
        
        if ( err2 != 0.0 ) err2=1.0/err2; else err2=0.0;
        err2=err2*err2;
        err2*=(Isample+Iec+Ibc);
        
        gsl_matrix_set(ErrMatrix, iii, jjj, sqrt(gsl_matrix_get(ErrMatrix,iii,jjj) + err2 ) );
        gsl_matrix_set(SampleErr, iii, jjj, gsl_matrix_get(ErrMatrix,iii,jjj) * gsl_matrix_get(ErrMatrix,iii,jjj));
    }
    
    
    
    gsl_matrix_mul_elements(ErrMatrix,mask);
    gsl_matrix_mul_elements(SampleErr,mask);
    
    //+++ TODO :: Error of BUFFER
    
    
    //+++ Matrix-to-Matrix actions +++
    gsl_matrix_sub(Sample,BC);                      // Sample=Sample - BC
    
    // 2012 Time normalization BC
    if (checkFileNumber( NBC ) && checkBoxBCTimeNormalization->isChecked() &&  ECexist )
    {
        readMatrixCorTimeNormalizationOnly( NBC, BC );
        
        //Normalization constant
        double TimeSample=spinBoxNorm->value();
        double ttime=readDuration( NEC );
        if (ttime>0.0) TimeSample/=ttime; else TimeSample=0.0;
        
        double NormSample=readDataNormalization(NEC);
        
        if (TimeSample>0) NormSample/=TimeSample; else NormSample=0;
        
        gsl_matrix_scale(BC,NormSample);      // EB=T*EB
    }
    
    gsl_matrix_sub(EC,BC);                          // EC=EC - BC
    
    
    if (subtractBuffer)
    {
        if (checkFileNumber( NBC ) && checkBoxBCTimeNormalization->isChecked() &&  ECexist )
        {
            readMatrixCorTimeNormalizationOnly( NBC, BC );
            
            //Normalization constant
            double TimeSample=spinBoxNorm->value();
            double ttime=readDuration( Nbuffer );
            if (ttime>0.0) TimeSample/=ttime; else TimeSample=0.0;
            
            double NormSample=readDataNormalization(Nbuffer);
            
            if (TimeSample>0) NormSample/=TimeSample; else NormSample=0;
            
            gsl_matrix_scale(BC,NormSample);      // EB=T*EB
        }
        gsl_matrix_sub(Buffer,BC);    //Buffer=Buffer - BC
    }
    
    
    if (trans<1.0 && trans>0.0 && checkBoxParallaxTr->isChecked()) transmissionThetaDependenceTrEC(EC, Xcenter, Ycenter, Detector, trans);
    gsl_matrix_scale(EC,trans);                             // EC=T*EC
    
    if (ECexist) gsl_matrix_sub(Sample,EC);         // Sample=Sample  - EC
    
    if (subtractBuffer)
    {
        gsl_matrix_scale(EC,transBuffer/trans);    // EC=Tbuffer*EC
        if (ECexist) gsl_matrix_sub(Buffer,EC);    // Buffer=Buffer  - EC
    }
    
    
    gsl_matrix_mul_elements(Sample,mask);
    if (subtractBuffer) gsl_matrix_mul_elements(Buffer,mask);
    
    
    
    //+++ Paralax Correction
    if (checkBoxParallax->isChecked() || checkBoxParallaxTr->isChecked())
    {
        parallaxCorrection(Sample, Xcenter, Ycenter, Detector, trans);
        
        if (subtractBuffer) parallaxCorrection(Buffer, Xcenter, Ycenter, Detector, transBuffer);
    }
    
    if (subtractBuffer)
    {
        gsl_matrix_scale(Buffer,fractionBuffer*absBuffer/abs);
        gsl_matrix_sub(Sample,Buffer);
    }
    
    
    if (comboBoxACmethod->currentItem()==3)
    {
        double normalization=readDataNormalization(Nsample);
        if (normalization>0) gsl_matrix_scale(Sample,1/normalization);
    }
    else
    {
        gsl_matrix_scale(Sample,abs);
    }
    
    
    
    //+++ Sensitivity correction
    gsl_matrix_mul_elements(Sample,sens);
    
    
    if (BackgroundConst!=0)
    {
        for (iii=0;iii<MD;iii++) for (jjj=0;jjj<MD;jjj++)
        {
            if (gsl_matrix_get(mask,iii,jjj)>0)
            {
                gsl_matrix_set(Sample,iii,jjj,gsl_matrix_get(Sample,iii,jjj)-BackgroundConst);
            }
        }
    }
    
    //+++ Masking of  Negative Points +++
    if (checkBoxMaskNegative->isChecked())
    {
        for (iii=0;iii<MD;iii++) for (jjj=0;jjj<MD;jjj++)
        {
            if (gsl_matrix_get(Sample,iii,jjj)<=0)
            {
                gsl_matrix_set(Sample,iii,jjj,0.0);
                gsl_matrix_set(mask,iii,jjj,0.0);
                gsl_matrix_set(sens,iii,jjj,0.0);
            }
        }
    }
    
    
    // 2017 ...
    matrixConvolusion(Sample,mask,MD);
    gsl_matrix_scale(Sample,scale);
    
    
    QString nameQI = Nsample;  //  file number or name as name
    
    
    if (checkBoxNameAsTableName->isChecked())
    {
        nameQI=label;
        if(lineEditWildCard->text().contains("#")) nameQI=nameQI+"-"+Nsample;  // label as name
    }
    
    //nameQI=nameQI.replace("_", "-");
    nameQI=nameQI.simplifyWhiteSpace();
    nameQI=nameQI.replace(" ", "-").replace("/", "-").replace("_", "-").replace(",", "-").replace(".", "-").remove("%");
    
    nameQI=dataSuffix+"-"+nameQI;
    
    
    //+++ Ext
    QString currentExt=lineEditFileExt->text().remove(" ");
    if(currentExt!="") currentExt+="-";
    
    
    //+++   Open Reduced Matrix in Project
    if (radioButtonOpenInProject->isChecked() && button=="I-x-y")
    {
        QString matrixOutName="I-"+currentExt+nameQI;
        if (!checkBoxRewriteOutput->isChecked())
        {
            matrixOutName+="-v-";
            matrixOutName=app(this)->generateUniqueName(matrixOutName);
        }
        
        if (radioButtonXYdimQ->isChecked())
        {
            double pixel  = lineEditPS->text().toDouble();
            double pixelAsymetry  = lineEditAsymetry->text().toDouble();
            if (pixelAsymetry<=0) pixelAsymetry=1.0;
            
            if(Detector!=0)
            {
                
                double xs=4.0*M_PI/Lambda*sin(0.5*atan((0.5-Xcenter)*pixel/Detector));
                double xe=4.0*M_PI/Lambda*sin(0.5*atan(((MD+0.5)-Xcenter)*pixel/Detector));
                double ys=4.0*M_PI/Lambda*sin(0.5*atan((0.5-Ycenter)*pixel*pixelAsymetry/Detector));
                double ye=4.0*M_PI/Lambda*sin(0.5*atan(((MD+0.5)-Ycenter)*pixelAsymetry*pixel/Detector));
                
                makeMatrixSymmetric(Sample,matrixOutName, label, MD, xs, xe, ys,ye);
            }
            else makeMatrixSymmetric(Sample,matrixOutName, label, MD);
            
        }
        else makeMatrixSymmetric(Sample,matrixOutName, label, MD);
    }
    
    //+++ Open Error Matrix in Project
    if (radioButtonOpenInProject->isChecked() && button=="dI-x-y")
    {
        makeMatrixSymmetric(ErrMatrix,"dI-"+currentExt+nameQI,label, MD);
    }
    
    //+++   Save Reduced Matrix to File
    if (!radioButtonOpenInProject->isChecked() && button=="I-x-y")
    {
        if (checkBoxSortOutputToFolders->isChecked())
        {
            QDir dd;
            if (!dd.cd(lineEditPathRAD->text()+"/ASCII-I"))
            {
                dd.mkdir(lineEditPathRAD->text()+"/ASCII-I");
            }
            if (comboBoxIxyFormat->currentText().contains("Matrix")) saveMatrixToFile(lineEditPathRAD->text()+"/ASCII-I/I-"+currentExt+nameQI+"-"+comboBoxSel->currentText()+".DAT",Sample, MD);
            else
            {
                double pixel  = lineEditPS->text().toDouble();
                double pixelAsymetry  = lineEditAsymetry->text().toDouble();
                
                saveMatrixAsTableToFile(lineEditPathRAD->text()+"/ASCII-I/I-"+currentExt+nameQI+"-"+comboBoxSel->currentText()+".DAT", Sample,ErrMatrix, mask, MD, Xcenter, Ycenter, Lambda, Detector, pixel, pixel*pixelAsymetry );
            }
        }
        else
        {
            if (comboBoxIxyFormat->currentText().contains("Matrix")) saveMatrixToFile(lineEditPathRAD->text()+"/I-"+currentExt+nameQI+"-"+comboBoxSel->currentText()+".DAT",Sample, MD);
            else
            {
                double pixel  = lineEditPS->text().toDouble();
                double pixelAsymetry  = lineEditAsymetry->text().toDouble();
                
                saveMatrixAsTableToFile(lineEditPathRAD->text()+"/I-"+currentExt+nameQI+"-"+comboBoxSel->currentText()+".DAT", Sample,ErrMatrix, mask, MD, Xcenter, Ycenter, Lambda, Detector, pixel, pixel*pixelAsymetry );
            }
        }
        
    }
    
    //+++   Save Error Matrix to File
    if (!radioButtonOpenInProject->isChecked() && button=="dI-x-y")
    {
        if (checkBoxSortOutputToFolders->isChecked())
        {	QDir dd;
            if (!dd.cd(lineEditPathRAD->text()+"/ASCII-dI"))
            {
                dd.mkdir(lineEditPathRAD->text()+"/ASCII-dI");
            }
            saveMatrixToFile(lineEditPathRAD->text()+"/ASCII-dI/dI-"+currentExt+nameQI+"-"+comboBoxSel->currentText()+".DAT",ErrMatrix, MD);
        }
        else saveMatrixToFile(lineEditPathRAD->text()+"/dI-"+currentExt+nameQI+"-"+comboBoxSel->currentText()+".DAT",ErrMatrix, MD);
    }
    
    //+++++++++++++++RAD +++++++++++++++++
    // +++  Reading of some parameters +++
    double deltaLambda = readDeltaLambda( Nsample );
    
    double pixel  = lineEditResoPixelSize->text().toDouble();
    double binning=comboBoxBinning->currentText().toDouble();
    
    double pixelAsymetry  = lineEditAsymetry->text().toDouble();
    if (pixelAsymetry<=0) pixelAsymetry=1.0;
    
    double r2=readDataR2( Nsample );
    double r1=readDataR1( Nsample );
    
    
    //+++ Standart radial averiging +++
    if ( button=="I-Q" && radioButtonRadStd->isChecked())
    {
        if (comboBoxMode->currentText().contains("(MS)"))
        {
            double angle=double(spinBoxMCshiftAngle->value())/180.0*M_PI;
            radUniStandartLogMSmode ( MD, Sample, SampleErr, mask, Xcenter, Ycenter, nameQI, C,  Lambda, deltaLambda, Detector, pixel*binning, r1, r2, label, readDataF( Nsample ),pixelAsymetry,angle);
        }
        else radUniStandartLog ( MD, Sample, SampleErr, mask, Xcenter, Ycenter,
                                nameQI, C,  Lambda, deltaLambda, Detector, pixel*binning, r1, r2, label, readDataF( Nsample ), pixelAsymetry);
    }
    
    //+++ HF radial averiging +++
    if (button=="I-Q" && radioButtonRadHF->isChecked())
    {
        if (comboBoxMode->currentText().contains("(MS)"))
        {
            double angle=double(spinBoxMCshiftAngle->value())/180.0*M_PI;
            radUniStandartLogMSmode ( MD, Sample, SampleErr, mask, Xcenter, Ycenter, nameQI, C,  Lambda, deltaLambda, Detector, pixel*binning, r1, r2, label, readDataF( Nsample ),pixelAsymetry,angle);
        }
        else radUniHF ( MD, Sample, SampleErr, mask, Xcenter, Ycenter,
                       nameQI, C,  Lambda, deltaLambda, Detector, pixel*binning, r1, r2, label, readDataF( Nsample ),pixelAsymetry);
    }
    
    //+++ Hosisontal Slice +++
    if (button=="I-Qx")
    {
        horizontalSlice( MD, Sample, SampleErr, mask, Xcenter, Ycenter,
                        nameQI, C,  Lambda, deltaLambda, Detector, pixel*binning, r1, r2, label);
    }
    
    //+++ Vertical Slice +++
    if (button=="I-Qy")
    {
        verticalSlice( MD, Sample, SampleErr, mask, Xcenter, Ycenter,
                      nameQI, C,  Lambda, deltaLambda, Detector, pixel*binning*pixelAsymetry, r1, r2, label);
    }
    
    //+++ Polarv Coordinates
    if (button=="I-Polar")
    {
        radUniPolar(MD, Sample, mask, Xcenter, Ycenter, nameQI, Lambda, Detector, pixel*binning, pixelAsymetry );
    }
    
    //+++ SIGMA [x,y]
    if (button=="Sigma-x-y")
    {
        sigmaMatrix(MD, mask, Xcenter, Ycenter, "Sigma-"+currentExt+nameQI, Lambda, deltaLambda, C, Detector, pixel*binning, r1,r2 );
    }
    
    //+++ Q [x,y]
    if (button=="Q-x-y")
    {
        MatrixQ(MD, mask, Xcenter, Ycenter, "Q-"+currentExt+nameQI, Lambda, Detector, pixel*binning );
    }
    //+++ dQ [x,y]
    if (button=="dQ-x-y")
    {
        dQmatrix(MD, mask, Xcenter, Ycenter, "dQ-"+currentExt+nameQI, Lambda, Detector, pixel*binning );
    }
    
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    toResLogAll("DAN",status,this);
    
    
    //+++ Clean Memory +++
    gsl_matrix_free(Sample);
    gsl_matrix_free(SampleErr);
    gsl_matrix_free(Buffer);
    gsl_matrix_free(BufferErr);
    gsl_matrix_free(EC);
    gsl_matrix_free(ECErr);
    gsl_matrix_free(BC);
    gsl_matrix_free(BCErr);
    gsl_matrix_free(mask);
    gsl_matrix_free(sens);
    gsl_matrix_free(sensErr);
    gsl_matrix_free(ErrMatrix);
    
    return true;
}

