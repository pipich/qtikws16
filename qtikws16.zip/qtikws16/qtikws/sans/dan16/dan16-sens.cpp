#include "dan16.h"

//+++ connect Slots
void dan16::sensConnectSlot()
{
    connect( pushButtonCreateSens,      SIGNAL( clicked() ), this, SLOT( createSens()       ));
    connect( pushButtonCreateSensAs,    SIGNAL( clicked() ), this, SLOT( saveSensAs()       ));
    connect( pushButtonSaveSens,        SIGNAL( clicked() ), this, SLOT( saveSensFul()      ));
    connect( pushButtonOpenSens,        SIGNAL( clicked() ), this, SLOT( loadSensFul()      ));
    
    connect( pushButtonAnyPlexi,        SIGNAL( clicked() ), this, SLOT( selectAnyPlexy()   ));
    connect( pushButtonAnyEB,           SIGNAL( clicked() ), this, SLOT( selectAnyEB()      ));
    connect( pushButtonAnyBC,           SIGNAL( clicked() ), this, SLOT( selectAnyBC()      ));
    connect( pushButtonAnyTr,           SIGNAL( clicked() ), this, SLOT( calculateAnyTr()   ));
    connect( pushButtonTrHiden,         SIGNAL( clicked() ), this, SLOT( calculateTrHidden()));
    

    
    connect( lineEditTransAnyD,         SIGNAL( lostFocus() ), this, SLOT(SensitivityLineEditCheck()    ));
    connect( lineEditPlexiAnyD,         SIGNAL( lostFocus() ), this, SLOT(SensitivityLineEditCheck()    ));
    connect( lineEditEBAnyD,            SIGNAL( lostFocus() ), this, SLOT(SensitivityLineEditCheck()    ));
    connect( lineEditBcAnyD,            SIGNAL( lostFocus() ), this, SLOT(SensitivityLineEditCheck()    ));
    
    connect( spinBoxErrLeftLimit,       SIGNAL( valueChanged(int) ), this, SLOT( checkErrorLimits()     ));
    connect( spinBoxErrRightLimit,      SIGNAL( valueChanged(int) ), this, SLOT( checkErrorLimits()     ));
    
    connect( buttonGroupLimits,         SIGNAL( toggled(bool) ), this, SLOT( setOptionsSensHight()      ));
    
    connect( comboBoxSensFor, SIGNAL( activated(const QString&) ), this, SLOT( readFileNumbersFromSensitivityMatrix(const QString&) ) );
}

//+++++SLOT::MASK create standart mask
void dan16::createSens()
{
    ImportantConstants();
    
    QString maskName=comboBoxMaskFor->currentText();
    if (!checkExistenceOfMask(lineEditMD->text(), maskName)) return;
    
    updateSensList();
    
    QString sensmatrixName=comboBoxSensFor->currentText();
    bool exist=existWindow(sensmatrixName);
    
    createSensFul( sensmatrixName );
    if (spinBoxErrLeftLimit->value()>0 || spinBoxErrRightLimit->value()<1000) createSensFul(sensmatrixName);
    
    if (!exist )
    {
        maximizeWindow(sensmatrixName);
        if (checkBoxSortOutputToFolders->isChecked()) app(this)->changeFolder("DAN :: mask, sens");
        Folder *cf = ( Folder * ) app(this)->current_folder;
        app(this)->folders->setCurrentItem ( cf->folderListItem() );
        app(this)->folders->setFocus();
    }
}

//+++++SLOT::Save mask as
void dan16::saveSensAs()
{
    ImportantConstants();
    
    QString maskName=comboBoxMaskFor->currentText();
    if (!checkExistenceOfMask(lineEditMD->text(), maskName)) return;
    
    
    QString oldName=comboBoxSensFor->currentText();
    
    bool ok;
    QString sensName = QInputDialog::getText(
                                             "QtiKWS", "Input matrix name for sensitivity:", QLineEdit::Normal,
                                             oldName, &ok, this );
    
    if ( !ok ||  sensName.isEmpty() )
    {
        return;
    }
    
    
    //+++
    QWidgetList* windows=app(this)->windowsList();
    
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
        if (windows->at(mm)->name()==sensName  )
        {
            myWidget* mmm=(myWidget*) windows->at(mm);
            if (!mmm->windowLabel() .contains( "DAN::Sensitivity::"+QString::number(MD))) ok=false;
        }
    }
    
    if ( !ok ||  sensName.isEmpty() )
    {
        return;
    }
    bool exist=existWindow(sensName);
    
    createSensFul( sensName );
    if (spinBoxErrLeftLimit->value()>0 || spinBoxErrRightLimit->value()<1000) createSensFul(sensName);
    
    if (!exist )
    {
        maximizeWindow(sensName);
        if (checkBoxSortOutputToFolders->isChecked()) app(this)->changeFolder("DAN :: mask, sens");
        Folder *cf = ( Folder * ) app(this)->current_folder;
        app(this)->folders->setCurrentItem ( cf->folderListItem() );
        app(this)->folders->setFocus();
    }
    //    statusShow();
    updateSensList();
    
    comboBoxSensFor->setCurrentText(sensName);
}


//+++++SLOT::save Sens+++++++++++
void dan16::saveSensFul()
{
    ImportantConstants();
    
    QString sensName=comboBoxSensFor->currentText();
    
    //+++
    gsl_matrix *sens=gsl_matrix_alloc(MD,MD);  // allocate sens matrix
    gsl_matrix_set_zero(sens);
    
    if ( make_GSL_Matrix_Symmetric(sensName, sens, MD) ) saveMatrixToFile(Dir+sensName+".sens",sens, MD);
    
    gsl_matrix_free(sens);
}


//+++++SLOT::load Sens+++++++++++
void dan16::loadSensFul()
{
    ImportantConstants();
    QString sensName = comboBoxSensFor->currentText();
    
    QString sensFileName = QFileDialog::getOpenFileName(
                                                        Dir,
                                                        "*.sens",
                                                        this,
                                                        "open file dialog",
                                                        "Choose a Sensitivity file");
    
    if (sensFileName!="") loadSensFul(sensName, sensFileName);
}

void dan16::selectAnyPlexy()
{
    QString fileNumber="";
    if (selectFile(fileNumber))
    {
        lineEditPlexiAnyD->setText(fileNumber);
        lineEditPlexiAnyD->setPaletteBackgroundColor(QColor(green));
    }
}

void dan16::selectAnyEB()
{
    QString fileNumber="";
    if (selectFile(fileNumber))
    {
        lineEditEBAnyD->setText(fileNumber);
        lineEditEBAnyD->setPaletteBackgroundColor(QColor(green));
    }
}


void dan16::selectAnyBC()
{
    QString fileNumber="";
    if (selectFile(fileNumber))
    {
        lineEditBcAnyD->setText(fileNumber);
        lineEditBcAnyD->setPaletteBackgroundColor(QColor(green));
    }
}


void dan16::calculateTrHidden()
{
    ImportantConstants();
    
    if (lineEditPlexiAnyD->paletteBackgroundColor()!=QColor(green)  ||
        lineEditEBAnyD->paletteBackgroundColor()!=QColor(green))
    {
        lineEditTransAnyD->setText("0.000");
        return;
    }
    
    double Tr=readTransmission( lineEditPlexiAnyD->text(), lineEditEBAnyD->text(), comboBoxMaskFor->currentText(), 0, 0);
    
    lineEditTransAnyD->setText(QString::number(Tr,'f',3));
}

void dan16::calculateAnyTr()
{
    ImportantConstants();
    
    if (lineEditPlexiAnyD->paletteBackgroundColor()==QColor(green) && checkBoxSensTr->isChecked())
    {
        double lambda=readLambda(lineEditPlexiAnyD->text());
        lineEditTransAnyD->setText(QString::number(tCalc(lambda),'f',3));
        return;
    }
    
    
    if (lineEditPlexiAnyD->paletteBackgroundColor()!=QColor(green)  ||
        lineEditEBAnyD->paletteBackgroundColor()!=QColor(green))
    {
        lineEditTransAnyD->setText("0.000");
        return;
    }
    
    double Tr=readTransmission( lineEditPlexiAnyD->text(), lineEditEBAnyD->text(), comboBoxMaskFor->currentText(),0,0);
    
    lineEditTransAnyD->setText(QString::number(Tr,'f',3));
}

//*******************************************
//+++  SENS:: Sensitivities limits
//*******************************************
void dan16::checkErrorLimits()
{
    if ( spinBoxErrLeftLimit->value() >= spinBoxErrRightLimit->value() )
    {
        spinBoxErrLeftLimit->setValue(0);
        spinBoxErrRightLimit->setValue(1000);
    }
}


//+++++SLOT::MASK slot Mask to table ++++++++++++++++++++++++++++++++++++++++
void dan16::createSensFul(QString sensName)
{
    app(this)->ws->hide();
    app(this)->ws->blockSignals ( true );
    
    if (checkBoxSortOutputToFolders->isChecked()  && !checkExistenceOfSensNoMessage(QString::number(MD), sensName))
    {
        app(this)->changeFolder("DAN :: mask, sens");
    }
    
    ImportantConstants();
    
    //+++ mask gsl matrix
    gsl_matrix *mask=gsl_matrix_alloc(MD,MD);  // allocate mask matrix
    gsl_matrix_set_zero(mask);
    gsl_matrix *sens=gsl_matrix_alloc(MD,MD);  // allocate sens matrix
    gsl_matrix_set_zero(sens);
    // error matrix
    gsl_matrix *sensErr=gsl_matrix_alloc(MD,MD);  // allocate sens matrix
    gsl_matrix_set_zero(sensErr);
    
    QString maskName=comboBoxMaskFor->currentText();
    
    make_GSL_Matrix_Symmetric( maskName, mask, MD);
    //+++
    gsl_matrix_memcpy(sens,mask);
    
    
    if (!buttonGroupSensanyD->isChecked() || lineEditPlexiAnyD->paletteBackgroundColor()!=QColor(green))
    {
        
        QString label="DAN::Sensitivity::"+QString::number(MD)+"::Plexi::No";
        label+="::EB::No";
        label+="::BC::No";
        label+="::Tr::No";
        
        makeMatrixSymmetric(sens, sensName,label, MD);
        
        gsl_matrix_free(mask);
        gsl_matrix_free(sens);
        gsl_matrix_free(sensErr);
        
        
        app(this)->ws->show();
        app(this)->ws->blockSignals ( false );
        
        return;
    }
    
    
    if (lineEditPlexiAnyD->paletteBackgroundColor()==QColor(green))
    {
        // numberof  "active" pixels  Nmask
        double Nmask=0;
        double sum=0.0;
        double sum2=0.0;
        int ii,jj;
        QString info="\n\nSensitivity matrix: \""+sensName+"\".\n";
        info+="Mask matrix: \""+maskName+"\".\n\n";
        // +++
        gsl_matrix *PLEXI=gsl_matrix_alloc(MD,MD);
        gsl_matrix_set_zero(PLEXI);
        gsl_matrix *EB=gsl_matrix_alloc(MD,MD);
        gsl_matrix_set_zero(EB);
        gsl_matrix *BC=gsl_matrix_alloc(MD,MD);
        gsl_matrix_set_zero(BC);
        
        double transmision=0.0;
        
        //+++
        QString PlexiFileNumber=lineEditPlexiAnyD->text();
        
        double D=readDataDinM( PlexiFileNumber );
        
        readErrorMatrixRel( PlexiFileNumber, sensErr );
        gsl_matrix_mul_elements(sensErr,mask);
        
        double counts;
        
        //***spinBoxErrLeftLimit
        if ( spinBoxErrLeftLimit->value() > 0 ||  spinBoxErrRightLimit->value() < 1000 )
            for(ii=0;ii<MD;ii++) for(jj=0;jj<MD;jj++)
            {
                if (gsl_matrix_get(mask,ii,jj)>0)
                {
                    counts=gsl_matrix_get(sensErr,ii,jj)*100;
                    if ( counts < spinBoxErrLeftLimit->value()*0.1 || counts > spinBoxErrRightLimit->value()*0.1 )
                    {
                        gsl_matrix_set(mask,ii,jj, 0);
                        gsl_matrix_set(sensErr,ii,jj, 0);
                    }
                }
            }
        
        
        
        //+++
        if ( checkFileNumber( PlexiFileNumber ) )
        {
            readMatrixCor( PlexiFileNumber, PLEXI);
            info+="| Plexi-run-#:: "+  PlexiFileNumber;
        }
        //
        QString EBfileNumber=lineEditEBAnyD->text();
        
        bool EBexistYN=false;
        if ( checkFileNumber( EBfileNumber ) )
        {
            readMatrixCor( EBfileNumber, EB);
            info+=" | EB-run-#:: "+ EBfileNumber;
            EBexistYN=true;
        }
        else
        {
            info+=" | EB-run:: ...not used...";
        }
        
        //
        QString BCfileNumber=lineEditBcAnyD->text();
        
        if ( checkFileNumber( BCfileNumber ) )
        {
            // read BC matrix 2012
            if (checkBoxBCTimeNormalization->isChecked())
            {
                readMatrixCorTimeNormalizationOnly( BCfileNumber, BC );
                
                //Normalization constant
                double TimeSample=spinBoxNorm->value();
                double ttime=readDuration( PlexiFileNumber );
                if (ttime>0.0) TimeSample/=ttime; else TimeSample=0.0;
                
                double NormSample=readDataNormalization(PlexiFileNumber);
                
                if (TimeSample>0) NormSample/=TimeSample; else NormSample=0;
                
                gsl_matrix_scale(BC,NormSample);      // EB=T*EB
            }
            else readMatrixCor( BCfileNumber, BC );
            
            
            info+=" | BC-run-#:: "+ BCfileNumber;
        }
        else
        {
            info+=" | BC-run:: ...not used...";
        }
        
        
        //+++
        gsl_matrix_sub(PLEXI,BC);       // Plexi-BC
        
        
        if ( checkFileNumber( BCfileNumber ) && checkBoxBCTimeNormalization->isChecked() && EBexistYN)
        {
            readMatrixCorTimeNormalizationOnly( BCfileNumber, BC );
            
            //Normalization constant
            double TimeSample=spinBoxNorm->value();
            double ttime=readDuration( EBfileNumber );
            if (ttime>0.0) TimeSample/=ttime; else TimeSample=0.0;
            
            double NormSample=readDataNormalization(EBfileNumber);
            
            if (TimeSample>0) NormSample/=TimeSample; else NormSample=0;
            
            gsl_matrix_scale(BC,NormSample);      // EB=T*EB
        }
        
        
        gsl_matrix_sub(EB,BC);  // EB-BC
        
        //+++ Transmision selection
        transmision=lineEditTransAnyD->text().toDouble() ;
        info+=" | Tr : "+QString::number(transmision, 'f', 4);
        
        double Xc, Yc;
        readCenterfromMaskName( maskName, Xc, Yc, MD );
        
        
        if (transmision<1.0 && transmision>0.0 && checkBoxParallaxTr->isChecked())
        {
            
            transmissionThetaDependenceTrEC(EB, Xc, Yc, D*100, transmision);
        }
        
        //+++
        gsl_matrix_scale(EB,transmision);
        if(EBexistYN) gsl_matrix_sub(PLEXI,EB);
        gsl_matrix_mul_elements(PLEXI,mask);
        

        
        //+++
        if (checkBoxParallax->isChecked() || checkBoxParallaxTr->isChecked() )
        {
            parallaxCorrection(PLEXI, Xc, Yc, D*100, transmision);
        }
        

        
        double sum0=0;
        bool maskPixel=false;
        //+++
        for(ii=0;ii<MD;ii++) for(jj=0;jj<MD;jj++)
        {
            //+++
            counts=gsl_matrix_get(PLEXI,ii,jj);
            if (gsl_matrix_get(mask,ii,jj)>0 && counts<=0 && checkBoxMaskNegative->isChecked())
            {
                gsl_matrix_set(PLEXI,ii,jj,0.0);
                gsl_matrix_set(mask,ii,jj,0.0);
                gsl_matrix_set(sens,ii,jj,0.0);
                counts=0;
                maskPixel=true;
            }
            else maskPixel=false;
            //+++
            if ( !maskPixel )
            {
                sum0+=counts;
                sum2+=counts*counts;
                
                sum+=1/counts;
                Nmask+=gsl_matrix_get(mask,ii,jj);
            }
            
        }
        
        //+++
        for(ii=0;ii<MD;ii++) for(jj=0;jj<MD;jj++)
        {
            if (gsl_matrix_get(mask,ii,jj)>0)
            {
                counts=gsl_matrix_get(PLEXI,ii,jj);
                
                if (Nmask!=0 && counts>0)
                    gsl_matrix_set(sens,ii,jj, sum0/Nmask/counts);
                else
                {
                    gsl_matrix_set(mask,ii,jj,0.0);
                    gsl_matrix_set(sens,ii,jj,0);
                }
            }
        }
        
        matrixConvolusion(PLEXI,mask,MD);
        
        
        // +++ to res log
        
        info+=    " | Number of used pixels : N : "+ QString::number(Nmask) +
        "  |\n| Normalized Mean Intensity : "+
        QString::number(sum0/Nmask)+" "+QChar(177)+" " +
        QString::number(sqrt(fabs(sum2-sum0*sum0)/Nmask)/Nmask);
        
        info+=" | Normalization : "+comboBoxNorm->currentText()+" : "+QString::number( 1.0/readDataNormalization( lineEditPlexiAnyD->text() ) )+" |\n";
        
        
        info+="| Dead-time correction : "+ QString::number(
                                                           readDataDeadTime( lineEditPlexiAnyD->text()) )+" | ";
        info+="High Q Corrections : ";
        if (checkBoxParallax->isChecked())
        {
            info+="Yes : Center : "+QString::number(Xc+1,'f',2)+"x"+ QString::number(Yc+1,'f',2) +" |\n";
        }
        else info+="No |\n";
        
        
        
        
        toResLogAll("DAN",info,this);
        if (checkBoxSensError->isChecked())
            makeMatrixSymmetric(sensErr, sensName+"Error", "DAN::Sensitivity::Error::"+QString::number(MD), MD);
        
        
        
        QString label="DAN::Sensitivity::"+QString::number(MD)+"::Plexi::"+lineEditPlexiAnyD->text();
        label+="::EB::"+lineEditEBAnyD->text();
        label+="::BC::"+lineEditBcAnyD->text();
        label+="::Tr::"+lineEditTransAnyD->text();
        
        
        makeMatrixSymmetric(sens, sensName,label, MD);
        
        
        
        QString maskRange;
        maskRange ="|"+QString::number(spinBoxLTx->value());
        maskRange+="|"+QString::number(spinBoxRBx->value());
        maskRange+="|"+QString::number(spinBoxLTy->value());
        maskRange+="|"+QString::number(spinBoxRBy->value());
        maskRange+="|"+QString::number(spinBoxLTxBS->value());
        maskRange+="|"+QString::number(spinBoxRBxBS->value());		
        maskRange+="|"+QString::number(spinBoxLTyBS->value());
        maskRange+="|"+QString::number(spinBoxRByBS->value());		
        
        //+++2014-11
        maskRange+="| "+lineEditDeadRows->text();
        maskRange+="| "+lineEditDeadCols->text();
        maskRange+="| "+lineEditMaskPolygons->text();
        maskRange+="|";
        
        makeMatrixSymmetric(mask, maskName, "DAN::Mask::"+QString::number(MD)+maskRange, MD);
        
        gsl_matrix_free(PLEXI);
        gsl_matrix_free(EB);
        gsl_matrix_free(BC);	
    }   
    
    gsl_matrix_free(mask);
    gsl_matrix_free(sens);
    gsl_matrix_free(sensErr);
    
    app(this)->ws->show();
    app(this)->ws->blockSignals ( false );    
}


//+++++SLOT::load Sens+++++++++++
void dan16::loadSensFul( QString sensName, QString sensFileName)
{
    app(this)->ws->hide();
    app(this)->ws->blockSignals ( true );
    
    if (checkBoxSortOutputToFolders->isChecked() && !checkExistenceOfSensNoMessage(QString::number(MD), sensName))
    {
        app(this)->changeFolder("DAN :: mask, sens");
    }
    
    //+++ 
    gsl_matrix *sens=gsl_matrix_alloc(MD,MD);  // allocate sens matrix
    gsl_matrix_set_zero(sens);
    
    
    readMatrixByNameGSL (sensFileName, sens);
    
    
    for (int i=0;i<MD;i++) for (int j=0; j<MD; j++) 
    {
        if (gsl_matrix_get(sens,i,j) <0.0 ) gsl_matrix_set(sens,i,j,0.0);
    }
    
    QString label="DAN::Sensitivity::"+QString::number(MD)+" Sens file: "+sensFileName;
    
    makeMatrixSymmetric(sens, sensName, label, MD);
    
    gsl_matrix_free(sens);
    
    app(this)->ws->show();
    app(this)->ws->blockSignals ( false );    
}

//+++
void dan16::setOptionsSensHight()
{
    
    if ( buttonGroupLimits->isChecked() )
    {
        buttonGroupLimits->setMinimumHeight(0);
        buttonGroupLimits->setMaximumHeight(3000);
        
        buttonGroupLimits->setLineWidth(0);
    }
    else
    {
        buttonGroupLimits->setMinimumHeight(20);
        buttonGroupLimits->setMaximumHeight(20);
        
        buttonGroupLimits->setLineWidth(0);
    }
}

//+++
void dan16::readFileNumbersFromSensitivityMatrix( const QString &name )
{
    MD=lineEditMD->text().toInt();
    //+++
    QWidgetList* windows=app(this)->windowsList();
    //+++
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
        if ( windows->at(mm)->isA("Matrix") && windows->at(mm)->name()==name)
        {
            myWidget* mmm=(myWidget*) windows->at(mm);
            if (mmm->windowLabel().contains("DAN::Sensitivity::"+QString::number(MD)))
            {
                QString s=mmm->windowLabel().remove("DAN::Sensitivity::"+QString::number(MD)+"::Plexi::");
                if ( s.contains("::EB::") )
                {
                    
                    lineEditPlexiAnyD->setText(s.left(s.find("::EB::")));
                    lineEditEBAnyD->setText(s.mid(s.find("::EB::")+6,s.find("::BC::")-s.find("::EB::")-6 ));
                    lineEditBcAnyD->setText(s.mid(s.find("::BC::")+6,s.find("::Tr::")-s.find("::BC::")-6 ));
                    lineEditTransAnyD->setText(s.mid(s.find("::Tr::")+6,s.length()-s.find("::Tr::")-6 ));
                    SensitivityLineEditCheck();
                }
                else
                {
                    lineEditPlexiAnyD->setText(s);
                }
                
            }
        }
    }
    
}



//+++++SENSITIVITY-enable-check++++++++++++
void dan16::SensitivityLineEditCheck()
{
    ImportantConstants();
    
    double change;
    
    change = lineEditTransAnyD->text().toDouble();
    if (change<0.|| change>1.0)
    {
        lineEditTransAnyD->setText( QString::number( 0.0, 'f', 3 ) );
    }
    else lineEditTransAnyD->setText( QString::number(change, 'f', 3 ) );
    
    //Plexi
    if (checkFileNumber( lineEditPlexiAnyD->text() ))
        lineEditPlexiAnyD->setPaletteBackgroundColor(QColor(green));
    else
        lineEditPlexiAnyD->setPaletteBackgroundColor(QColor(red));
    
    //EB
    if (checkFileNumber( lineEditEBAnyD->text() ) )
        lineEditEBAnyD->setPaletteBackgroundColor(QColor(green));
    else
        lineEditEBAnyD->setPaletteBackgroundColor(QColor(red));
    //BC
    if (checkFileNumber( lineEditBcAnyD->text() ) )
        lineEditBcAnyD->setPaletteBackgroundColor(QColor(green));
    else
        lineEditBcAnyD->setPaletteBackgroundColor(QColor(red));
}

//+++ check existence of mask and sensitivity matrixes
bool dan16::checkExistenceOfSens(QString MaDe, QString sensToCheck)
{
    QStringList lst;
    findMatrixListByLabel("DAN::Sensitivity::"+MaDe,lst);
    if (!lst.contains(sensToCheck))
    {
        QMessageBox::critical(0, "QtiKWS", "<b>"+sensToCheck+"</b> does not exist!");
        return false;
    }
    return true;
}

bool dan16::checkExistenceOfSensNoMessage(QString MaDe, QString sensToCheck)
{
    QStringList lst;
    findMatrixListByLabel("DAN::Sensitivity::"+MaDe,lst);
    if (!lst.contains(sensToCheck))
    {
        return false;
    }
    return true;
}

void dan16::updateSensList()
{
    ImportantConstants();
    
    //sens
    QStringList lst;
    findMatrixListByLabel("DAN::Sensitivity::"+QString::number(MD),lst);
    if (!lst.contains("sens")) lst.prepend("sens");
    QString currentSens;
    
    currentSens=comboBoxSensFor->currentText();
    comboBoxSensFor->clear();
    comboBoxSensFor->insertStringList(lst);
    if (lst.contains(currentSens)) comboBoxSensFor->setCurrentText(currentSens);
}

//*******************************************
//+++  new-daDan:: get-Sensitivity-Number
//*******************************************
QString dan16::getSensitivityNumber(QString sensName)
{
    QString res;
    MD=lineEditMD->text().toInt();
    //+++
    QWidgetList* windows=app(this)->windowsList();
    //+++
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
        if ( windows->at(mm)->isA("Matrix") && windows->at(mm)->name()==sensName)
        {
            myWidget* mmm=(myWidget*) windows->at(mm);
            if (mmm->windowLabel().contains("DAN::Sensitivity::"+QString::number(MD)))
            {
                QString s=mmm->windowLabel().remove("DAN::Sensitivity::"+QString::number(MD)+"::Plexi::");
                if (s.contains("::EB::")) s=s.left(s.find("::EB::"));
                
                res=s;
            }
        }
    }
    return res;
}
