/****************************************************************************
** Form implementation generated from reading ui file '..\qtiKWS\sans\dan16\dan.ui'
**
** Created: Do 14. Sep 02:02:22 2017
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.4   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "dan.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qbuttongroup.h>
#include <qtoolbutton.h>
#include <qlabel.h>
#include <qtabwidget.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qcombobox.h>
#include <qtoolbox.h>
#include <qlineedit.h>
#include <qtextedit.h>
#include <qcheckbox.h>
#include <qspinbox.h>
#include <qtable.h>
#include <qradiobutton.h>
#include <qsplitter.h>
#include <qlcdnumber.h>
#include <qslider.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

static const unsigned char image0_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0x90, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0xbd, 0x8b, 0x1d,
    0x65, 0x14, 0xc6, 0x7f, 0xe7, 0x9d, 0x79, 0x67, 0xe6, 0x7e, 0xcd, 0xcd,
    0xba, 0x71, 0x35, 0x89, 0xeb, 0xe6, 0x03, 0x34, 0x28, 0x22, 0x2b, 0xd1,
    0x42, 0x13, 0x58, 0x88, 0x06, 0x0b, 0xed, 0x04, 0xfd, 0x03, 0x44, 0x58,
    0x0d, 0xa9, 0x84, 0x10, 0x9b, 0xa0, 0xa0, 0x4d, 0xaa, 0x2d, 0x53, 0x59,
    0x89, 0x29, 0x14, 0x2d, 0x4c, 0x8a, 0x10, 0x48, 0x21, 0x28, 0x08, 0x8a,
    0x85, 0xa2, 0x12, 0x84, 0x9b, 0x18, 0xbf, 0xb2, 0x09, 0xb9, 0x3b, 0xb9,
    0x73, 0xe7, 0xbe, 0xf3, 0x7e, 0x59, 0x65, 0xcd, 0xad, 0x73, 0xba, 0x53,
    0x9c, 0x1f, 0xcf, 0xe1, 0x79, 0x1e, 0x89, 0x31, 0x72, 0x3f, 0x93, 0xde,
    0xbb, 0x7c, 0xf3, 0xbe, 0x2c, 0x55, 0x86, 0xc3, 0xaa, 0x9f, 0x1f, 0x45,
    0xcb, 0x21, 0xef, 0xe8, 0x5a, 0xcf, 0x4a, 0x3d, 0x89, 0x7f, 0x4c, 0x9a,
    0xf6, 0xba, 0x23, 0xbe, 0xb7, 0xbe, 0x11, 0xbf, 0xbf, 0xf7, 0x46, 0xee,
    0x2a, 0xf8, 0x76, 0x43, 0x5e, 0xc9, 0x06, 0xbd, 0x0f, 0x06, 0xbb, 0x9f,
    0x5d, 0xed, 0x2e, 0x3d, 0x8d, 0xee, 0xed, 0x24, 0x49, 0x33, 0xc0, 0x31,
    0xbb, 0x73, 0x9d, 0x1f, 0x2f, 0x7d, 0xc6, 0xb5, 0xdf, 0x37, 0xff, 0x0a,
    0x81, 0x77, 0x8e, 0x9f, 0x8d, 0x5f, 0xde, 0x05, 0x28, 0x80, 0xf3, 0xa7,
    0x64, 0xbf, 0x2a, 0xf2, 0x4f, 0xf6, 0x1f, 0xfd, 0x68, 0xf5, 0xb1, 0x97,
    0x3f, 0xe7, 0x91, 0x67, 0xde, 0x60, 0xe7, 0xca, 0x3e, 0xba, 0xa5, 0x27,
    0x51, 0x9b, 0xf4, 0x07, 0x96, 0x5e, 0x59, 0xd2, 0x1a, 0x76, 0x5b, 0xcf,
    0xb9, 0x33, 0x6f, 0xca, 0x0b, 0x22, 0x22, 0xdb, 0x2f, 0xf8, 0xc8, 0x6b,
    0xe5, 0xa3, 0x87, 0xca, 0x85, 0x95, 0x75, 0x62, 0xf8, 0x02, 0x3b, 0xfd,
    0x19, 0x33, 0xd9, 0xc2, 0xd6, 0x5b, 0xb8, 0xe9, 0x84, 0x18, 0x1c, 0x4a,
    0x25, 0xf4, 0xca, 0x1e, 0x2e, 0xb4, 0x79, 0x3d, 0x71, 0x67, 0xde, 0x3d,
    0x16, 0x5f, 0x02, 0x6a, 0x05, 0xa0, 0x72, 0xd6, 0x8a, 0x85, 0xa7, 0x80,
    0x1f, 0x68, 0xeb, 0x9f, 0x08, 0x3e, 0x43, 0xc8, 0x10, 0xc9, 0x91, 0xb4,
    0x83, 0xca, 0xfa, 0x1c, 0x7c, 0xfe, 0x39, 0x8e, 0xbd, 0x7e, 0x84, 0xc7,
    0x9f, 0x7c, 0x18, 0xdb, 0xc6, 0xaa, 0xdf, 0xe2, 0xb7, 0x15, 0x48, 0xca,
    0xc1, 0xac, 0x78, 0x00, 0xd7, 0x5c, 0xc1, 0x54, 0x5b, 0x80, 0xc2, 0x9b,
    0x06, 0x6f, 0x1a, 0x62, 0x70, 0x48, 0x9a, 0x91, 0xe7, 0x1d, 0x72, 0x1d,
    0xa8, 0x6b, 0x87, 0xf7, 0x5c, 0x3e, 0x7d, 0x39, 0xce, 0xb6, 0x01, 0xce,
    0xb3, 0x4f, 0x65, 0x1a, 0x53, 0x5d, 0xc3, 0x54, 0x37, 0x40, 0x34, 0xc1,
    0x1a, 0x82, 0x35, 0x20, 0x42, 0xa2, 0x34, 0xde, 0x05, 0x4c, 0x55, 0xb1,
    0xf9, 0xcf, 0x1d, 0xbc, 0xe3, 0xea, 0x9c, 0x8d, 0xd6, 0x42, 0x08, 0x53,
    0xec, 0x74, 0x8b, 0xb6, 0xba, 0x05, 0x4a, 0x13, 0xbc, 0x05, 0xef, 0x90,
    0x44, 0x23, 0xba, 0x20, 0xd1, 0x39, 0xc1, 0xb5, 0x34, 0x53, 0x0b, 0x91,
    0x6a, 0x1e, 0x60, 0xc0, 0x36, 0xb7, 0x70, 0x89, 0xc3, 0xcd, 0x6a, 0x94,
    0x2e, 0x00, 0x88, 0x08, 0xa2, 0x12, 0x54, 0x92, 0x22, 0x69, 0x46, 0xa2,
    0x33, 0xb2, 0x42, 0xe3, 0xa2, 0x59, 0x9e, 0xb3, 0xb1, 0x69, 0xf8, 0x77,
    0x72, 0xfb, 0x4f, 0x12, 0x15, 0x41, 0x65, 0xa8, 0xbc, 0x47, 0xda, 0xd9,
    0x41, 0x36, 0x58, 0x24, 0xeb, 0x3f, 0x88, 0xee, 0x2e, 0xa2, 0x3b, 0x43,
    0x8a, 0xe1, 0x43, 0xec, 0x59, 0x5e, 0xc0, 0x05, 0x0e, 0xcf, 0x01, 0x8c,
    0xe5, 0x97, 0x9b, 0x57, 0xaf, 0x90, 0x66, 0x9a, 0x54, 0xa7, 0xe8, 0x54,
    0xa1, 0x13, 0x4f, 0xa6, 0x5a, 0xb4, 0x9a, 0x91, 0xca, 0x94, 0x04, 0x43,
    0xde, 0xed, 0xb2, 0xf7, 0xc0, 0x12, 0x65, 0xa9, 0x5e, 0x3d, 0xf1, 0xa2,
    0x3c, 0xf1, 0x7f, 0x94, 0x53, 0x2e, 0x8e, 0x7e, 0x1b, 0xad, 0xed, 0xda,
    0xfb, 0x2b, 0x61, 0x7a, 0x93, 0xf1, 0xb8, 0x65, 0x3c, 0x9e, 0xd1, 0xd4,
    0x1e, 0x49, 0x14, 0xfd, 0xb2, 0xcb, 0x70, 0x71, 0xc8, 0x70, 0x47, 0x01,
    0xed, 0x98, 0x6e, 0x21, 0xc3, 0x41, 0xc9, 0x59, 0xe0, 0x48, 0x0a, 0xa0,
    0x13, 0xce, 0xd5, 0x75, 0x58, 0xff, 0xfa, 0xc2, 0x77, 0xcb, 0x42, 0x64,
    0x66, 0x82, 0x71, 0x36, 0x8e, 0xac, 0xe5, 0xef, 0x00, 0x65, 0x8c, 0x1c,
    0x08, 0x41, 0x0d, 0x49, 0x14, 0xb9, 0x86, 0xba, 0xf6, 0x64, 0x9a, 0xc5,
    0xb9, 0x2e, 0x6c, 0xbc, 0x25, 0x6f, 0xc7, 0xc0, 0xc9, 0x10, 0xf9, 0x58,
    0xe0, 0xab, 0xd6, 0x71, 0x43, 0xc6, 0xdc, 0x6e, 0x86, 0x74, 0x54, 0xcb,
    0xae, 0xd6, 0xb1, 0x07, 0x58, 0x03, 0x56, 0xd3, 0x94, 0x11, 0xc2, 0x87,
    0xa7, 0x3f, 0x8d, 0x23, 0xb9, 0xdf, 0x3a, 0xff, 0x07, 0x4d, 0x9d, 0x1e,
    0x7f, 0x3a, 0x77, 0x4e, 0x32, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e,
    0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image1_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xcc, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x5d, 0x68, 0x53,
    0x77, 0x18, 0x87, 0x9f, 0x37, 0xe7, 0xe4, 0x9c, 0xa4, 0xc9, 0x69, 0x3b,
    0xd6, 0xda, 0x26, 0x0d, 0x6d, 0x7a, 0x61, 0xb7, 0x75, 0x63, 0xcc, 0x15,
    0x3f, 0xa8, 0x76, 0x37, 0xf3, 0x0b, 0x36, 0xc5, 0x0f, 0x04, 0x57, 0x29,
    0x8c, 0x5d, 0x6c, 0x83, 0x31, 0xd9, 0x26, 0xe2, 0x8d, 0xbb, 0xf2, 0x46,
    0x05, 0x65, 0x32, 0xbc, 0x90, 0x6a, 0x2f, 0x76, 0x51, 0x1c, 0x13, 0x36,
    0x9c, 0x38, 0x10, 0xc4, 0xe9, 0x84, 0x46, 0x04, 0xb5, 0x8a, 0x45, 0x4b,
    0xa1, 0x4b, 0xd7, 0xd2, 0x90, 0x36, 0x1f, 0xa7, 0x49, 0x73, 0x72, 0xd2,
    0x93, 0xfc, 0x77, 0x31, 0xbb, 0x8b, 0x2d, 0x77, 0xfe, 0xe0, 0xbd, 0x7c,
    0x1f, 0xf8, 0xfd, 0xe0, 0x11, 0xa5, 0x14, 0x2f, 0x13, 0x1f, 0x80, 0x88,
    0x88, 0x39, 0x64, 0xee, 0xef, 0x3c, 0xd9, 0x99, 0xdc, 0x34, 0xbc, 0x49,
    0xc5, 0xce, 0x75, 0x8c, 0x85, 0xbf, 0x08, 0xef, 0x14, 0x11, 0x0d, 0x40,
    0x0e, 0x8b, 0x29, 0x23, 0x62, 0xd5, 0x03, 0x88, 0x52, 0x0a, 0xff, 0x01,
    0xff, 0xf6, 0xbe, 0xed, 0xef, 0xfe, 0x34, 0xd0, 0xdf, 0xdf, 0x58, 0xd3,
    0x1c, 0xc2, 0x12, 0x62, 0x62, 0x7a, 0xaa, 0x72, 0xf7, 0x71, 0xe2, 0xb8,
    0xb5, 0xd2, 0x74, 0x2f, 0xdb, 0x9e, 0x39, 0x9c, 0xf7, 0xec, 0x11, 0xef,
    0x33, 0xef, 0xfa, 0x7f, 0x01, 0xba, 0x88, 0x34, 0xc4, 0x4f, 0x74, 0x9d,
    0x7a, 0x63, 0x5d, 0x4f, 0xe3, 0xf5, 0xe9, 0x2b, 0xa4, 0x92, 0x69, 0x5e,
    0x8b, 0x75, 0xf3, 0xe1, 0x86, 0xad, 0x46, 0x77, 0x5b, 0xf4, 0xb4, 0x5e,
    0x0e, 0x11, 0x7a, 0x15, 0x8e, 0xff, 0x72, 0xe6, 0xb7, 0xfa, 0x15, 0xb6,
    0xf0, 0x5e, 0x7b, 0xb4, 0xfd, 0x9d, 0x89, 0xd2, 0x03, 0xe6, 0x9e, 0xa6,
    0xc9, 0x3e, 0xac, 0x5c, 0x1e, 0xbb, 0xf6, 0x7c, 0xf4, 0xbb, 0x2b, 0x17,
    0xab, 0x8d, 0x11, 0x8f, 0xde, 0xf5, 0x16, 0x66, 0x40, 0x61, 0xb8, 0xc1,
    0xd6, 0x7a, 0x00, 0x9d, 0x38, 0xef, 0x67, 0x6a, 0x69, 0x5a, 0x6b, 0x01,
    0xbc, 0x9c, 0x54, 0xb9, 0xc4, 0x10, 0x07, 0xd9, 0xe3, 0x2c, 0xca, 0xe0,
    0xad, 0xa9, 0xbb, 0x34, 0x64, 0x85, 0x86, 0x42, 0x07, 0x52, 0xac, 0xfd,
    0x0b, 0x10, 0x11, 0x53, 0x29, 0xe5, 0xfe, 0x03, 0x30, 0xe8, 0x28, 0x48,
    0x96, 0x78, 0xb8, 0x93, 0x86, 0xb0, 0xe9, 0x2d, 0x7f, 0xe0, 0xae, 0x25,
    0xc4, 0x21, 0x4d, 0xf9, 0x9e, 0x4c, 0xde, 0x5f, 0x68, 0xc1, 0x47, 0x4b,
    0xd1, 0x49, 0xfa, 0x2b, 0x4b, 0x6e, 0x97, 0x1c, 0x95, 0x90, 0x8e, 0xfe,
    0xad, 0xf6, 0x95, 0xaf, 0x55, 0x3e, 0x91, 0x1f, 0xd4, 0x88, 0xba, 0xad,
    0x53, 0x66, 0xb2, 0x62, 0x57, 0xd1, 0x2d, 0x8d, 0x40, 0xb3, 0xdf, 0xc4,
    0x62, 0x40, 0x5d, 0x54, 0x7b, 0x45, 0xc4, 0xb0, 0x29, 0x75, 0xb1, 0x9e,
    0x4e, 0x5a, 0x89, 0x62, 0xf1, 0x8c, 0x00, 0xbb, 0x9b, 0xe2, 0xc1, 0x63,
    0x2d, 0x31, 0x8b, 0x99, 0x87, 0x99, 0x03, 0xb2, 0x4b, 0x06, 0x74, 0xaa,
    0xfc, 0x5c, 0x98, 0x71, 0xbe, 0x79, 0xf4, 0x7b, 0xd2, 0x2a, 0x2e, 0x96,
    0x41, 0xb1, 0x24, 0xc3, 0xd2, 0xcf, 0x39, 0x7a, 0x09, 0x92, 0x63, 0x85,
    0x79, 0xda, 0xb9, 0x43, 0x96, 0x2a, 0x13, 0xf4, 0x85, 0x2c, 0x83, 0xd7,
    0xdf, 0x8a, 0x92, 0x4b, 0x97, 0x2c, 0x67, 0xce, 0xdd, 0xab, 0xab, 0xcb,
    0x6a, 0x5c, 0x06, 0x65, 0xd7, 0x7c, 0x3e, 0x37, 0x84, 0x9f, 0x05, 0x72,
    0xfc, 0xea, 0x73, 0xb5, 0xe1, 0xd8, 0x9a, 0xb6, 0x8f, 0xf0, 0x97, 0xd1,
    0xc5, 0x58, 0x5e, 0xc8, 0xd8, 0x76, 0x21, 0xe3, 0xdc, 0x60, 0x99, 0xa3,
    0x05, 0xbb, 0x7c, 0xde, 0xce, 0x38, 0x3e, 0xcd, 0x14, 0x08, 0xd0, 0xa3,
    0x03, 0xa8, 0x51, 0x75, 0x5b, 0x44, 0x12, 0xab, 0xc3, 0x04, 0xcf, 0x06,
    0x6b, 0xbd, 0xd1, 0x38, 0xda, 0x2b, 0x4b, 0x14, 0xed, 0x95, 0xd0, 0xf4,
    0x54, 0x2a, 0xc4, 0x2c, 0xdf, 0xab, 0x0b, 0x6a, 0x31, 0x7c, 0x32, 0x28,
    0xb9, 0x52, 0x11, 0xa7, 0xe8, 0x82, 0xcb, 0x9c, 0xbe, 0xba, 0xec, 0xea,
    0x33, 0x80, 0x2a, 0xa8, 0xf9, 0x8d, 0xd1, 0x3e, 0x62, 0xcd, 0x11, 0xec,
    0x48, 0x9a, 0x7c, 0x76, 0xd9, 0x1b, 0xcf, 0xcf, 0x1e, 0x91, 0x2f, 0xc5,
    0xdf, 0xf6, 0x76, 0x58, 0x0a, 0x15, 0x87, 0x62, 0xb6, 0x0c, 0x79, 0x6e,
    0xea, 0xd4, 0x89, 0x5b, 0x70, 0x33, 0xb3, 0xd3, 0x8b, 0x24, 0xfe, 0x9a,
    0xac, 0x59, 0xcd, 0x9a, 0xef, 0xeb, 0x6d, 0x9f, 0xeb, 0x7f, 0x74, 0x27,
    0x06, 0x67, 0x52, 0xf3, 0xf8, 0x9b, 0x4c, 0x12, 0x4f, 0x9f, 0xe0, 0xa5,
    0x6a, 0x8f, 0xf0, 0xb8, 0x53, 0x17, 0x40, 0x89, 0xfc, 0x8f, 0xd7, 0xae,
    0x8e, 0x96, 0xb3, 0xb5, 0xf3, 0xa6, 0xee, 0xdb, 0xfc, 0x67, 0x72, 0xf6,
    0xc4, 0xb6, 0x8d, 0x5b, 0xcd, 0x48, 0xa4, 0x87, 0x54, 0x26, 0x47, 0xe5,
    0xf9, 0xf8, 0x12, 0x79, 0x8e, 0xa9, 0xab, 0xaa, 0x84, 0x52, 0xea, 0x7f,
    0xc7, 0x21, 0x1a, 0x79, 0x13, 0xe3, 0x85, 0xa9, 0x1a, 0x3b, 0xd9, 0x11,
    0xf8, 0x38, 0x30, 0x66, 0x1d, 0x09, 0x2b, 0xe3, 0x53, 0x23, 0xa9, 0x0d,
    0x6a, 0xfb, 0x56, 0x3d, 0x92, 0x97, 0xd5, 0xf9, 0x6f, 0x23, 0x6e, 0x3d,
    0xf2, 0xfe, 0x0c, 0x03, 0x64, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e,
    0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image2_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xfe, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x5f, 0x68, 0x5b,
    0x65, 0x18, 0xc6, 0x7f, 0xdf, 0x77, 0x4e, 0x9a, 0x34, 0xcb, 0xbf, 0xd3,
    0x76, 0xfd, 0x93, 0x36, 0xdd, 0x52, 0xe9, 0x36, 0x59, 0x5d, 0xd8, 0xbc,
    0x50, 0x98, 0xde, 0x08, 0xdd, 0x60, 0x48, 0x61, 0xe2, 0xe5, 0x6e, 0x26,
    0x5b, 0x61, 0xc8, 0x06, 0x5e, 0xb8, 0xeb, 0x56, 0x07, 0x75, 0x0a, 0x0a,
    0x32, 0x70, 0x77, 0x82, 0xe0, 0x40, 0xed, 0xd0, 0x0a, 0x8e, 0x4d, 0x74,
    0x6c, 0xba, 0x56, 0x86, 0x8e, 0x8e, 0xd5, 0xb1, 0xa6, 0xb5, 0xda, 0x76,
    0x6d, 0x47, 0x9a, 0x36, 0x69, 0x92, 0x93, 0xe4, 0xe4, 0xe4, 0x9c, 0xf3,
    0x79, 0xd5, 0xb9, 0x5c, 0xfb, 0x5e, 0x3d, 0xef, 0xcd, 0xf3, 0xf2, 0xe3,
    0x7d, 0x1e, 0xa1, 0x94, 0xe2, 0xff, 0x8c, 0xfe, 0xec, 0x72, 0x6b, 0x54,
    0xe8, 0x35, 0x97, 0xfd, 0x4a, 0xc8, 0xd7, 0xb4, 0xa0, 0x7e, 0xd4, 0xf1,
    0x64, 0xab, 0xab, 0xe8, 0xab, 0x56, 0x54, 0xce, 0x34, 0x9d, 0x0d, 0xc7,
    0x75, 0xdf, 0x3b, 0x7d, 0x89, 0xeb, 0x3c, 0x73, 0x55, 0x6c, 0xeb, 0x6f,
    0x46, 0x45, 0xd3, 0x73, 0xed, 0xf2, 0xc2, 0x8e, 0x8e, 0xae, 0x53, 0xe1,
    0xae, 0xc3, 0x46, 0xc0, 0x48, 0x82, 0x1e, 0x06, 0x29, 0xa9, 0x59, 0x79,
    0x1e, 0xdd, 0x99, 0x20, 0x3d, 0x3d, 0x57, 0x70, 0x14, 0xe7, 0xce, 0x5e,
    0x56, 0x5f, 0x6c, 0x1b, 0xc8, 0x6d, 0xd1, 0xe3, 0xe3, 0x44, 0x4b, 0x62,
    0xcf, 0xbb, 0xc6, 0xe0, 0xb8, 0x51, 0x79, 0x7e, 0x0c, 0xb3, 0xed, 0x15,
    0x9a, 0x3a, 0x42, 0x44, 0x83, 0x5b, 0x84, 0x76, 0xd4, 0x88, 0xb5, 0xc5,
    0x70, 0x1c, 0xa2, 0xae, 0xc3, 0xe7, 0x1f, 0x9d, 0x14, 0xaf, 0x0a, 0x21,
    0x44, 0x03, 0x82, 0xd7, 0xa4, 0xbf, 0x7e, 0x4d, 0x9c, 0x66, 0xea, 0xe7,
    0xdd, 0x2c, 0x3d, 0xfe, 0x03, 0xbb, 0x9a, 0x67, 0x5f, 0xb0, 0xc0, 0xf0,
    0xc0, 0x63, 0x0e, 0xc5, 0x4d, 0x9c, 0x7a, 0x0d, 0x7f, 0x73, 0x33, 0x8e,
    0xe7, 0x48, 0xb7, 0xe2, 0x7c, 0x78, 0x7e, 0x48, 0x1d, 0x01, 0x4a, 0x3a,
    0xc0, 0xcc, 0x07, 0xc2, 0xf8, 0xc4, 0x1b, 0x1e, 0xb0, 0xcd, 0xe3, 0x1c,
    0x4b, 0x36, 0x73, 0xa0, 0x6d, 0x90, 0x7b, 0x19, 0x87, 0xf1, 0x87, 0x2b,
    0xdc, 0xb8, 0x7a, 0x83, 0xf1, 0x37, 0xa7, 0x49, 0x1d, 0x0c, 0x63, 0x74,
    0x76, 0xb0, 0x36, 0x9f, 0xe6, 0xee, 0x9d, 0x25, 0xd5, 0x80, 0x30, 0xb4,
    0xf4, 0x7e, 0xea, 0x2f, 0xe3, 0x4c, 0xff, 0xd8, 0x60, 0x92, 0xee, 0x48,
    0x98, 0x85, 0x8d, 0x22, 0xf9, 0xe2, 0x3a, 0xa9, 0xfe, 0x08, 0x19, 0xe3,
    0x65, 0x46, 0x6e, 0xf6, 0xe0, 0x0b, 0x04, 0xe9, 0xe9, 0x8b, 0xe3, 0x29,
    0x49, 0xdd, 0xe6, 0xd7, 0x8b, 0x13, 0xaa, 0xf4, 0xd4, 0x60, 0xd1, 0x7d,
    0x61, 0xe8, 0x70, 0xa2, 0x9d, 0x7b, 0xcb, 0x0e, 0x5f, 0x3d, 0xc8, 0xb1,
    0x59, 0xb2, 0xc8, 0x97, 0x2d, 0x0a, 0x75, 0x8b, 0x81, 0x97, 0x76, 0x33,
    0x9d, 0x6d, 0x65, 0x66, 0x45, 0xe2, 0x59, 0x26, 0xeb, 0x4f, 0x0a, 0xb8,
    0x36, 0xcb, 0x8d, 0x6f, 0xac, 0x97, 0x22, 0xc5, 0x9a, 0xcb, 0xcd, 0xe5,
    0x02, 0x9b, 0x15, 0x13, 0xb3, 0x5a, 0xa3, 0x22, 0xa1, 0xa3, 0x37, 0x8a,
    0xad, 0xf9, 0x59, 0x74, 0x35, 0xaa, 0xae, 0x06, 0xae, 0x4d, 0xb9, 0x5c,
    0xc7, 0xae, 0xb3, 0xde, 0x80, 0xe0, 0x37, 0xd3, 0xdf, 0xdd, 0x9e, 0x5d,
    0xc0, 0x8d, 0x84, 0xa8, 0xef, 0x6c, 0x46, 0x8b, 0x07, 0xd9, 0x75, 0xb0,
    0x9b, 0xd6, 0x44, 0x0b, 0xb3, 0xf7, 0x17, 0xe8, 0x0b, 0x64, 0x38, 0xb0,
    0x4b, 0xa7, 0xae, 0x7c, 0x68, 0x52, 0x22, 0x24, 0x9d, 0x0d, 0x06, 0x3f,
    0xf5, 0x5e, 0x98, 0xeb, 0x5c, 0xfd, 0xd2, 0xfa, 0x33, 0x9d, 0x61, 0xc5,
    0x72, 0x51, 0xad, 0x06, 0x35, 0x29, 0xb9, 0x7b, 0x7b, 0x96, 0xcd, 0xc9,
    0x5f, 0x38, 0xa2, 0xc6, 0xb1, 0x56, 0x1f, 0xe2, 0x8b, 0xc6, 0x69, 0xef,
    0x8c, 0xa2, 0x24, 0xa9, 0x06, 0x84, 0xb8, 0x0f, 0xeb, 0x14, 0x57, 0xb2,
    0x13, 0xab, 0xb1, 0xc4, 0x8f, 0xf7, 0x53, 0xcc, 0x87, 0x63, 0x78, 0x55,
    0x13, 0x7d, 0x6d, 0x86, 0x37, 0xfc, 0xd7, 0x79, 0x31, 0x90, 0xe6, 0xc1,
    0xd4, 0x32, 0xa9, 0x70, 0x37, 0xc9, 0x7d, 0xbd, 0x4c, 0xff, 0xbe, 0x72,
    0xf4, 0xdc, 0x31, 0xb1, 0xf3, 0xd3, 0x6b, 0x2a, 0xab, 0x03, 0xfc, 0x50,
    0x21, 0x13, 0x53, 0x95, 0xbf, 0xdf, 0xd9, 0x7b, 0x35, 0x31, 0x7c, 0x68,
    0x91, 0xa9, 0x47, 0x65, 0xd6, 0x72, 0x39, 0xc2, 0xce, 0x2c, 0xfd, 0xa1,
    0x02, 0x05, 0xcb, 0xcf, 0xe6, 0x7c, 0x95, 0x70, 0xdb, 0x24, 0xc9, 0xfe,
    0x76, 0x62, 0x31, 0xad, 0xa7, 0x64, 0x7a, 0x23, 0xc0, 0xdb, 0x4f, 0xa3,
    0x7c, 0xe9, 0x8c, 0xb8, 0x18, 0x0b, 0xc9, 0xf3, 0x5d, 0xf1, 0x20, 0xc5,
    0x2d, 0x8b, 0xad, 0xbc, 0x4b, 0x36, 0xab, 0x70, 0x00, 0x17, 0x81, 0x14,
    0x8a, 0x96, 0x16, 0x41, 0x30, 0x12, 0x22, 0xb3, 0x56, 0xa6, 0x5c, 0xf1,
    0x18, 0xfd, 0x5a, 0x89, 0xff, 0xca, 0xe4, 0x70, 0x39, 0x57, 0xf0, 0x86,
    0x72, 0x45, 0x53, 0xf8, 0xe0, 0x7b, 0x60, 0xce, 0xd1, 0xb1, 0x1d, 0x9b,
    0x11, 0x85, 0x4a, 0x4a, 0x0d, 0x37, 0xbb, 0xa1, 0x26, 0xed, 0x4c, 0x29,
    0xa6, 0x4b, 0x8a, 0xba, 0xc6, 0x67, 0x0d, 0x65, 0x02, 0xf8, 0xf8, 0x2d,
    0x91, 0x00, 0x28, 0xfd, 0xc3, 0x93, 0x91, 0x5b, 0xb8, 0x0a, 0x18, 0x3d,
    0xce, 0x7e, 0xa5, 0x73, 0xd6, 0x83, 0xdf, 0xec, 0x3c, 0xdf, 0x6a, 0x11,
    0x82, 0x5e, 0x00, 0x6b, 0xec, 0x0a, 0x5b, 0x28, 0xa5, 0xfe, 0x05, 0x0d,
    0xd0, 0x5d, 0x86, 0xf4, 0xf2, 0xeb, 0xaa, 0x00, 0x00, 0x00, 0x00, 0x49,
    0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image3_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x03,
    0x15, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x4d, 0x4c, 0x1c,
    0x65, 0x00, 0x86, 0x9f, 0x99, 0xf9, 0x66, 0x17, 0x66, 0x17, 0x58, 0x7e,
    0x16, 0x4b, 0xb6, 0xd0, 0x86, 0x6c, 0xa4, 0xa1, 0x98, 0xb6, 0x50, 0xac,
    0x7f, 0x51, 0x2b, 0x62, 0xd3, 0x98, 0x98, 0xb4, 0x49, 0x49, 0x34, 0x1a,
    0x4d, 0x1b, 0xad, 0x47, 0xad, 0xc4, 0xeb, 0xc2, 0xd1, 0x0b, 0x27, 0x13,
    0x0f, 0xa4, 0x17, 0x0e, 0x92, 0xd4, 0xa4, 0x07, 0x8d, 0x69, 0x7a, 0x31,
    0xd4, 0x94, 0x6e, 0x11, 0xda, 0x8a, 0x74, 0xab, 0x65, 0x01, 0x13, 0x2b,
    0xbb, 0x65, 0xd9, 0x75, 0x67, 0xff, 0xf8, 0x76, 0x66, 0x98, 0x19, 0x4f,
    0x25, 0x26, 0x1e, 0xfb, 0x9c, 0xde, 0xcb, 0x7b, 0x7a, 0xf2, 0x28, 0xbe,
    0xef, 0xf3, 0x34, 0x88, 0x27, 0x43, 0x51, 0x50, 0x26, 0x26, 0xbe, 0x0b,
    0x95, 0x4a, 0xf5, 0x43, 0x95, 0x4a, 0x75, 0xd0, 0x71, 0x9c, 0x17, 0x6c,
    0xdb, 0x8d, 0xf8, 0xbe, 0x2f, 0x85, 0xf0, 0x32, 0xbe, 0xef, 0x2d, 0xe8,
    0x7a, 0x60, 0xa9, 0x56, 0x2b, 0x65, 0xae, 0x5c, 0x49, 0xd8, 0x7b, 0x3f,
    0xdf, 0xf7, 0xb9, 0x74, 0xe9, 0x72, 0x9b, 0xe3, 0x88, 0x33, 0x42, 0xa8,
    0xef, 0x85, 0xc3, 0x8d, 0x2f, 0x45, 0xa3, 0x91, 0x86, 0x58, 0xac, 0x85,
    0x48, 0x24, 0x88, 0x94, 0x0e, 0xb9, 0xdc, 0x0e, 0x9b, 0x9b, 0x79, 0x0a,
    0xf9, 0xfc, 0x5f, 0x66, 0xb9, 0xfc, 0x93, 0xb5, 0xbb, 0x3b, 0xdd, 0x15,
    0x0d, 0xdc, 0x9b, 0x9a, 0xfa, 0x5c, 0x8a, 0xf1, 0xf1, 0x6f, 0x0f, 0x18,
    0x46, 0xf3, 0xe5, 0xd6, 0xd6, 0xf0, 0x88, 0x94, 0x75, 0x86, 0x87, 0x9f,
    0x67, 0x68, 0x28, 0x86, 0x61, 0x80, 0x61, 0x80, 0xe7, 0x41, 0x3e, 0x0f,
    0x8d, 0x8d, 0x70, 0x2b, 0x99, 0xea, 0x49, 0xde, 0x58, 0xf9, 0xa8, 0x60,
    0x96, 0xde, 0x2d, 0x97, 0x76, 0x66, 0x80, 0x4f, 0x54, 0xcb, 0xaa, 0x1d,
    0x31, 0x8c, 0xc6, 0x91, 0x0b, 0x17, 0x4e, 0x31, 0x38, 0x18, 0x67, 0x69,
    0xe9, 0x01, 0xb6, 0x0d, 0xd5, 0x2a, 0xe4, 0x72, 0xb0, 0xb5, 0x05, 0xaa,
    0x02, 0x1e, 0xbb, 0xa4, 0x52, 0x1b, 0x7c, 0xf8, 0xda, 0x9b, 0x8c, 0x0e,
    0x0d, 0x05, 0x2d, 0xd7, 0xfd, 0x18, 0x40, 0x2d, 0x14, 0xca, 0xb7, 0xa4,
    0x94, 0x77, 0x37, 0x36, 0x0a, 0x04, 0x02, 0x5d, 0x98, 0xa6, 0xc9, 0xf2,
    0xf2, 0xef, 0x28, 0x4a, 0x85, 0xed, 0xed, 0x22, 0xf9, 0x7c, 0x11, 0x8f,
    0x32, 0xd7, 0xae, 0x2f, 0xe2, 0x9a, 0x1e, 0x1e, 0x1e, 0x66, 0xa5, 0x8c,
    0xb4, 0xac, 0xaf, 0x01, 0xb4, 0x95, 0x95, 0xeb, 0x3b, 0x57, 0xaf, 0xce,
    0xb7, 0x94, 0xcb, 0xf5, 0xd1, 0x78, 0xbc, 0x87, 0x5a, 0x4d, 0x92, 0x4e,
    0xaf, 0x91, 0xc9, 0xec, 0xb0, 0xba, 0xba, 0xc9, 0xfa, 0xfa, 0xdf, 0xfc,
    0xba, 0xfc, 0x27, 0xeb, 0x7f, 0x64, 0x19, 0x3d, 0x7a, 0x94, 0xaa, 0x5d,
    0xe7, 0xfb, 0xe4, 0x7c, 0xc1, 0xf6, 0xac, 0x4f, 0xcf, 0x9d, 0x7d, 0xb5,
    0x20, 0x00, 0xa4, 0x74, 0x6e, 0x3e, 0x7e, 0x9c, 0x73, 0x4c, 0x73, 0x5b,
    0xef, 0xed, 0xed, 0xa6, 0xb7, 0xb7, 0xfb, 0xff, 0xbe, 0x0e, 0x41, 0xcc,
    0x08, 0x73, 0xed, 0xce, 0x2f, 0x48, 0xdb, 0x9e, 0x3f, 0x1c, 0x77, 0xd3,
    0x7b, 0x1a, 0x2d, 0xab, 0xf6, 0xa8, 0x5a, 0xd5, 0xcb, 0x95, 0x4a, 0xa5,
    0xbd, 0xa3, 0xa3, 0x8b, 0xdb, 0xc9, 0xdf, 0xf0, 0xb1, 0x08, 0x85, 0x0c,
    0x8a, 0x66, 0x09, 0xb3, 0x68, 0xd2, 0xb7, 0xbf, 0x87, 0x23, 0xaf, 0x0c,
    0x53, 0x92, 0x55, 0x14, 0xc8, 0xce, 0xcd, 0xa1, 0x26, 0x12, 0x78, 0x02,
    0xc0, 0x75, 0x3d, 0x01, 0xbe, 0x10, 0x42, 0x27, 0xbb, 0xb9, 0x89, 0x94,
    0x5b, 0xbc, 0x75, 0xea, 0x65, 0x14, 0xa5, 0x11, 0x4d, 0xb3, 0x59, 0x4d,
    0x67, 0xb8, 0xbb, 0x98, 0xe2, 0x0d, 0x67, 0x00, 0x5d, 0x08, 0xf0, 0x3c,
    0x31, 0x37, 0x37, 0xe1, 0x42, 0x02, 0x15, 0x20, 0x18, 0x14, 0x87, 0x5b,
    0x23, 0xcd, 0x4d, 0xd1, 0xb6, 0x36, 0xaa, 0xa5, 0x1a, 0xc7, 0x8e, 0x1f,
    0xe7, 0xce, 0x52, 0x9a, 0xfb, 0xf7, 0xd7, 0x38, 0x71, 0xe2, 0x00, 0x1f,
    0xbc, 0xff, 0x22, 0x5d, 0xfb, 0xbb, 0xc9, 0x15, 0x8b, 0x3c, 0xdb, 0x1b,
    0x43, 0x13, 0xda, 0xf0, 0xeb, 0xe7, 0x26, 0x42, 0x00, 0xea, 0xc9, 0x93,
    0x93, 0x42, 0x08, 0x7d, 0xa4, 0x33, 0xda, 0xae, 0x76, 0x36, 0xb7, 0x12,
    0x40, 0xb0, 0xeb, 0x04, 0xb9, 0x39, 0x7f, 0x8f, 0x85, 0x85, 0x45, 0x16,
    0x92, 0xab, 0x64, 0x33, 0x16, 0xcf, 0x74, 0xee, 0xa3, 0x54, 0x96, 0x1c,
    0xeb, 0x8f, 0x63, 0x34, 0x04, 0x06, 0xf6, 0x69, 0xfa, 0x17, 0x00, 0x22,
    0x1a, 0xed, 0xf7, 0x51, 0xb3, 0xf5, 0xed, 0x5c, 0x9e, 0x95, 0xe5, 0x87,
    0x3c, 0xca, 0x66, 0xc8, 0x3d, 0x7c, 0x40, 0x7b, 0x47, 0x13, 0x96, 0xac,
    0x5b, 0xd3, 0xd3, 0x3f, 0xba, 0x4d, 0x91, 0x66, 0x43, 0x53, 0x34, 0x9e,
    0x3b, 0x78, 0x90, 0x1b, 0xc9, 0x14, 0x75, 0xdb, 0x51, 0x85, 0xae, 0x9d,
    0x06, 0x26, 0x15, 0xdf, 0xf7, 0x39, 0x7f, 0x7e, 0xaa, 0x5b, 0x17, 0xe2,
    0x1b, 0x55, 0x55, 0xdf, 0xde, 0x75, 0xbd, 0x9f, 0x9d, 0xba, 0xfc, 0x21,
    0x68, 0x84, 0xd6, 0x5c, 0xd7, 0x5b, 0xcb, 0x64, 0xb6, 0xa5, 0x68, 0x50,
    0x07, 0x5a, 0x9b, 0x8c, 0x77, 0x1a, 0x02, 0xc1, 0x31, 0xcb, 0x76, 0xc2,
    0x3e, 0xde, 0x6d, 0xdf, 0xd7, 0x3e, 0x9b, 0x99, 0x19, 0x5f, 0x50, 0x9e,
    0xd4, 0x78, 0xf1, 0xe2, 0x57, 0x2d, 0xf5, 0xba, 0xd6, 0xef, 0x38, 0x4a,
    0xba, 0xaf, 0xaf, 0xfa, 0x4f, 0x22, 0x91, 0xf0, 0xfe, 0x6b, 0x71, 0x6c,
    0x6c, 0x32, 0xa0, 0xeb, 0xe2, 0xb4, 0xa2, 0x28, 0x71, 0xd7, 0x15, 0xb3,
    0xb3, 0xb3, 0x5f, 0x66, 0xf6, 0x62, 0x7a, 0x1a, 0xfe, 0x05, 0x98, 0x94,
    0x7a, 0xae, 0x23, 0xd7, 0xcb, 0x47, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45,
    0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image4_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xae, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x4b, 0x68, 0x54,
    0x77, 0x14, 0xc6, 0x7f, 0xf7, 0x35, 0x73, 0x27, 0x99, 0xcc, 0x4b, 0x93,
    0x8c, 0x31, 0x8a, 0x36, 0x69, 0x7c, 0x10, 0x8c, 0xd2, 0x85, 0x0f, 0x44,
    0x88, 0x60, 0x69, 0x5d, 0x74, 0x5b, 0xe8, 0x42, 0x29, 0x05, 0xa5, 0x8b,
    0x28, 0x94, 0x0a, 0xbe, 0xf0, 0x85, 0x0a, 0x06, 0x17, 0x82, 0xd6, 0x85,
    0x3b, 0x17, 0xa2, 0xe0, 0xca, 0x8d, 0x2f, 0xdc, 0x05, 0x05, 0x21, 0xbe,
    0x28, 0x7d, 0xa4, 0x23, 0x23, 0x9d, 0x24, 0x75, 0x92, 0x99, 0x71, 0xcc,
    0xdc, 0xce, 0x9d, 0xdc, 0x7b, 0xff, 0x73, 0x4f, 0x57, 0x0d, 0x46, 0xd3,
    0x45, 0xf1, 0x5b, 0x1e, 0xce, 0xf9, 0x71, 0xf8, 0xce, 0x77, 0x34, 0x11,
    0xe1, 0x63, 0x64, 0x2e, 0x54, 0xbc, 0xa9, 0x69, 0x31, 0x49, 0x24, 0xb6,
    0xc5, 0xc3, 0x70, 0x6b, 0xa8, 0xd4, 0xca, 0xb7, 0xa1, 0xca, 0x4f, 0xfa,
    0xea, 0x6e, 0x0b, 0x3c, 0x19, 0x12, 0xf1, 0xde, 0xed, 0xd5, 0xde, 0xdd,
    0xe0, 0xa4, 0xa6, 0x99, 0x5b, 0xbb, 0x3a, 0x06, 0xbb, 0x56, 0x2c, 0xfb,
    0x31, 0xd6, 0xbf, 0xe6, 0x73, 0x33, 0x9d, 0x42, 0x6a, 0x15, 0x9c, 0xb1,
    0x1c, 0x13, 0xbf, 0xe4, 0x66, 0xc7, 0xcb, 0xb5, 0xfb, 0xa5, 0xa6, 0x9c,
    0x38, 0x28, 0xf2, 0x6c, 0x41, 0xc0, 0x48, 0x67, 0xe6, 0x40, 0xcf, 0x77,
    0xbb, 0x87, 0xb3, 0x83, 0x1b, 0xd1, 0x27, 0x7f, 0xc3, 0xcf, 0xe5, 0xf0,
    0xa7, 0xca, 0x28, 0xa5, 0xe3, 0xd5, 0x3d, 0xf2, 0xa3, 0xbf, 0xf2, 0x73,
    0xa1, 0x34, 0x3d, 0x11, 0xca, 0x57, 0xa7, 0x44, 0x1e, 0xcf, 0x03, 0xdc,
    0xd6, 0xb4, 0x1d, 0xfd, 0x7b, 0x77, 0xdd, 0x5f, 0xfe, 0xcd, 0x4e, 0xdc,
    0xeb, 0x17, 0xf1, 0xa6, 0xab, 0x18, 0xb3, 0x1e, 0x33, 0x55, 0x9f, 0xa6,
    0xab, 0xf0, 0x3c, 0x05, 0x2d, 0x49, 0x0a, 0xf9, 0xd7, 0x3c, 0x7f, 0xeb,
    0xe6, 0x5c, 0x64, 0xcb, 0x71, 0x91, 0xb2, 0x0e, 0xf0, 0xad, 0xa6, 0xd9,
    0xed, 0x03, 0x6b, 0x86, 0x3b, 0x37, 0x0f, 0xe0, 0xfc, 0x74, 0x86, 0x9c,
    0x93, 0xa6, 0xfe, 0xf5, 0x11, 0xaa, 0x99, 0x5e, 0x4a, 0x9f, 0x7d, 0x49,
    0x6c, 0xef, 0x0f, 0x48, 0x2a, 0x43, 0xe5, 0xaf, 0x12, 0x6d, 0x11, 0x83,
    0x8c, 0x69, 0x7c, 0xea, 0xc1, 0x9e, 0x39, 0x13, 0xb7, 0xc0, 0x60, 0xdb,
    0xea, 0xde, 0xf5, 0xda, 0x8b, 0x11, 0x66, 0xa6, 0x6a, 0x2c, 0x39, 0xb6,
    0x8f, 0x8e, 0xed, 0x3b, 0x28, 0xaf, 0x5e, 0x4b, 0xd7, 0x92, 0x0e, 0xac,
    0xf6, 0x4e, 0xa4, 0xee, 0x50, 0x1c, 0x3e, 0x8f, 0x65, 0xda, 0xa4, 0xa3,
    0x16, 0x11, 0x15, 0x7e, 0x0f, 0x9c, 0xd5, 0x01, 0x12, 0xb0, 0xd3, 0xf0,
    0x5d, 0xdc, 0x89, 0x22, 0x76, 0x24, 0x82, 0x73, 0xfd, 0x0a, 0xee, 0x9f,
    0x2f, 0x59, 0xbc, 0x6e, 0x00, 0xab, 0x35, 0x82, 0xff, 0xf4, 0x11, 0xd3,
    0x77, 0xee, 0xd2, 0x34, 0x2d, 0xcc, 0x54, 0x82, 0xa8, 0x6d, 0xa3, 0x6b,
    0x5a, 0x37, 0x80, 0x0e, 0xd0, 0x84, 0x76, 0x35, 0x55, 0x24, 0x98, 0x71,
    0x79, 0x53, 0x74, 0x08, 0xba, 0x7b, 0xb1, 0xa2, 0x26, 0xcc, 0x56, 0x41,
    0x14, 0xd2, 0x0c, 0x50, 0xf1, 0x24, 0x66, 0x32, 0x41, 0x6b, 0x3a, 0x41,
    0x68, 0x19, 0x04, 0xe0, 0xcd, 0x01, 0xde, 0xc0, 0x68, 0xc3, 0x53, 0x68,
    0xba, 0x45, 0x18, 0x6a, 0x24, 0xbb, 0xbb, 0xb0, 0xb2, 0xed, 0xb8, 0x8f,
    0x46, 0xf8, 0x7b, 0xf4, 0x29, 0xd1, 0x81, 0xf5, 0xac, 0x3a, 0x7a, 0x98,
    0x4c, 0xdf, 0x4a, 0x6c, 0x43, 0xa7, 0xec, 0x07, 0x28, 0x09, 0xef, 0xcd,
    0x79, 0x90, 0x83, 0x5b, 0x3d, 0x4e, 0xe3, 0xd8, 0xd2, 0x6c, 0xaa, 0x2d,
    0xbe, 0xa2, 0x1b, 0xe7, 0xc6, 0x55, 0xa4, 0x54, 0xa4, 0xfc, 0xe0, 0x01,
    0x61, 0x5b, 0x92, 0x4f, 0x64, 0x08, 0xef, 0xd9, 0x63, 0x16, 0xd9, 0x11,
    0x5e, 0x55, 0x1c, 0x26, 0x9d, 0x46, 0xa8, 0x21, 0xc3, 0xf3, 0xce, 0x78,
    0x39, 0xde, 0x72, 0x61, 0xed, 0xf2, 0xec, 0xfe, 0xfe, 0x0d, 0xbd, 0x84,
    0x96, 0xc1, 0xac, 0xaf, 0x50, 0xcd, 0x10, 0x3d, 0x62, 0x10, 0x4b, 0x2f,
    0x42, 0x4a, 0x25, 0xc6, 0xf3, 0x45, 0x1e, 0xfe, 0x5e, 0xa0, 0x5c, 0x73,
    0x2e, 0x9d, 0x16, 0x19, 0x9a, 0x17, 0xe5, 0x42, 0xbd, 0x71, 0x9c, 0xc9,
    0xca, 0xaa, 0x06, 0x7c, 0xd1, 0xd7, 0xb7, 0x8c, 0x78, 0x3a, 0x4e, 0x2c,
    0x6a, 0xa3, 0x3c, 0x8f, 0xca, 0x58, 0x9e, 0x97, 0x85, 0x69, 0xfe, 0x98,
    0x28, 0x51, 0xab, 0xbb, 0xb7, 0x2c, 0x38, 0xf4, 0x5f, 0x51, 0x4e, 0xb4,
    0xda, 0xb1, 0xc3, 0xf1, 0x54, 0x7c, 0x77, 0x26, 0xd1, 0x9a, 0xb5, 0x23,
    0x06, 0xb5, 0x86, 0x4f, 0xb9, 0xea, 0xe0, 0x38, 0xf5, 0x31, 0x2f, 0x08,
    0x2e, 0x04, 0x70, 0xed, 0x9c, 0x88, 0xb3, 0x20, 0xe0, 0xdf, 0x7f, 0x50,
    0xd1, 0x68, 0x8f, 0x89, 0x31, 0x88, 0x84, 0x9b, 0x10, 0x71, 0xc3, 0x40,
    0x8d, 0x78, 0x34, 0x1f, 0x9e, 0x83, 0x71, 0x79, 0x6f, 0xe0, 0x03, 0xc0,
    0xff, 0xd5, 0x3f, 0x2b, 0x61, 0x47, 0xa6, 0x4f, 0xbb, 0x88, 0xee, 0x00,
    0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image5_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x03,
    0x0d, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0xd3, 0x5d, 0x6c, 0x53,
    0x75, 0x18, 0xc7, 0xf1, 0xef, 0x69, 0x4f, 0xdb, 0xd3, 0x76, 0x6c, 0xed,
    0x56, 0x58, 0x37, 0x46, 0x5d, 0x47, 0x98, 0x6b, 0x1d, 0x08, 0x71, 0x4b,
    0x66, 0xb6, 0x5e, 0xcc, 0x18, 0x43, 0x24, 0xb8, 0x60, 0x32, 0x7c, 0x49,
    0x34, 0x78, 0x43, 0xbc, 0x90, 0xa9, 0x31, 0x7a, 0x61, 0x8c, 0x88, 0x31,
    0x11, 0x8d, 0x28, 0x17, 0xca, 0x8d, 0x9a, 0x78, 0xe3, 0x42, 0xa6, 0xa8,
    0x11, 0x50, 0xc9, 0x46, 0x80, 0x1a, 0x9d, 0xc0, 0x60, 0x8e, 0x75, 0x2c,
    0x71, 0xe2, 0xba, 0xcd, 0x59, 0xc6, 0xec, 0x7b, 0x7b, 0xce, 0x59, 0xdb,
    0x73, 0xfe, 0x5e, 0xb9, 0xb0, 0xe8, 0x95, 0xfe, 0xee, 0x9e, 0x8b, 0xe7,
    0x93, 0x27, 0x4f, 0x9e, 0x47, 0x12, 0x42, 0xf0, 0x7f, 0x22, 0xdf, 0x5e,
    0x9c, 0x3f, 0x24, 0x29, 0x39, 0x9d, 0x90, 0x5e, 0xb1, 0x44, 0xf4, 0x92,
    0xb4, 0xbd, 0xa4, 0x5b, 0x1c, 0xaa, 0x2e, 0x66, 0xf4, 0x72, 0xe5, 0x07,
    0x4d, 0xe3, 0x32, 0x5f, 0x91, 0x3b, 0x28, 0x84, 0x79, 0x7b, 0x8f, 0xf4,
    0xf7, 0x04, 0xd1, 0x37, 0xa4, 0xa0, 0x70, 0xd9, 0x5f, 0xb3, 0xfb, 0x1a,
    0xf7, 0x38, 0xeb, 0xc3, 0xeb, 0x6c, 0x76, 0x0f, 0x15, 0x4d, 0xa3, 0x98,
    0x5f, 0x22, 0x11, 0xff, 0x95, 0x44, 0xbc, 0x30, 0x91, 0x5a, 0x52, 0x3f,
    0xbc, 0x95, 0xe3, 0xf8, 0xfb, 0x23, 0x22, 0xb9, 0x06, 0x88, 0xbe, 0x2d,
    0x85, 0xec, 0x35, 0xeb, 0x3e, 0x6f, 0xec, 0xd8, 0x17, 0x56, 0xac, 0xbd,
    0x68, 0xf3, 0x49, 0xbc, 0xdb, 0xad, 0x38, 0xd6, 0x67, 0xd1, 0xb2, 0x4b,
    0x54, 0x4a, 0x79, 0x32, 0x8b, 0x73, 0x5c, 0x3d, 0xfb, 0x33, 0x33, 0x53,
    0x89, 0xb3, 0xa9, 0x94, 0xf1, 0xd4, 0x91, 0x33, 0x62, 0x61, 0x15, 0x18,
    0x39, 0x2c, 0x47, 0x5b, 0x77, 0x3e, 0x13, 0xf1, 0xf9, 0x5e, 0x64, 0x7c,
    0xdf, 0x4e, 0xcc, 0xd9, 0x18, 0x74, 0x34, 0xe2, 0x3f, 0xd0, 0x49, 0x76,
    0xc4, 0x41, 0xfe, 0x4a, 0x89, 0xa6, 0xc7, 0x54, 0x3c, 0xdb, 0x04, 0xa3,
    0xc3, 0xbf, 0x30, 0x39, 0xbe, 0xf4, 0xcd, 0x1f, 0x0b, 0xfa, 0x23, 0x1f,
    0x9c, 0x13, 0x05, 0x0b, 0x40, 0x45, 0xb2, 0x45, 0xaa, 0x1a, 0xbb, 0x58,
    0x1e, 0xff, 0x8c, 0xf2, 0x64, 0x8c, 0xb6, 0x90, 0x07, 0x11, 0x4f, 0x10,
    0x3f, 0x9e, 0x61, 0xe3, 0x68, 0x1f, 0xdd, 0xb1, 0x97, 0x49, 0x7f, 0x54,
    0x4d, 0x21, 0xb1, 0x4c, 0xf7, 0xfd, 0x5b, 0x08, 0x04, 0x7d, 0x0f, 0x7a,
    0xbc, 0xb6, 0xbd, 0x00, 0x16, 0x00, 0xad, 0x60, 0xec, 0x9f, 0xfa, 0xee,
    0xbd, 0x1b, 0xa9, 0xca, 0x29, 0x6c, 0x3d, 0x5b, 0x98, 0x9c, 0x32, 0xb1,
    0xdf, 0x17, 0x62, 0x43, 0x77, 0x1d, 0x99, 0xec, 0x75, 0x92, 0xa9, 0x31,
    0x3c, 0x1b, 0x74, 0x14, 0x8b, 0x42, 0x5d, 0x8d, 0x9f, 0xcd, 0x77, 0xd6,
    0xe3, 0x74, 0xcb, 0x4f, 0xac, 0x59, 0xe2, 0x27, 0x4f, 0x4b, 0x67, 0xda,
    0x77, 0x3f, 0xf4, 0x40, 0x38, 0xd2, 0x4f, 0xfc, 0xdc, 0x09, 0x6a, 0xb7,
    0xf9, 0x30, 0xca, 0x69, 0x16, 0x4e, 0xde, 0x44, 0x8a, 0x6b, 0xfc, 0x76,
    0x4f, 0x96, 0x11, 0xc5, 0x60, 0x77, 0x20, 0x4c, 0x6b, 0x56, 0x65, 0xf8,
    0xe4, 0xd5, 0xdc, 0xb3, 0xc7, 0xb2, 0x35, 0x32, 0xc0, 0xc7, 0x03, 0xf2,
    0xb1, 0xce, 0x87, 0x9f, 0x8c, 0x04, 0x77, 0xec, 0x35, 0xa6, 0x2f, 0x0e,
    0xa6, 0x57, 0xac, 0x8b, 0x56, 0x25, 0x69, 0xf5, 0xda, 0x8c, 0x15, 0xba,
    0xf6, 0xa8, 0x14, 0x56, 0xd2, 0xbc, 0x34, 0x96, 0x23, 0x5a, 0xcc, 0x73,
    0x62, 0x22, 0xc9, 0x85, 0x96, 0x0e, 0x1c, 0xb2, 0xa5, 0x7a, 0xf5, 0x0e,
    0x8c, 0xb2, 0xdc, 0xe7, 0xdb, 0x14, 0x74, 0xaa, 0xe9, 0x0b, 0xe6, 0xe9,
    0xa3, 0x83, 0xc3, 0x37, 0x17, 0x19, 0x7b, 0xf4, 0xf9, 0xe2, 0x3b, 0x6d,
    0xe1, 0x06, 0xe9, 0xd2, 0x15, 0x17, 0x2e, 0x53, 0x62, 0xab, 0x50, 0xf9,
    0xb1, 0x68, 0xd0, 0xe3, 0x6f, 0xc0, 0x2c, 0x9b, 0xe8, 0xba, 0x59, 0x58,
    0x05, 0x72, 0x79, 0x63, 0xe8, 0xda, 0xf9, 0x2f, 0x9f, 0xeb, 0xec, 0xdd,
    0x6a, 0xd9, 0xb5, 0xbf, 0xfb, 0xde, 0xc5, 0xd9, 0x54, 0x53, 0xa0, 0x8e,
    0xca, 0xe8, 0x82, 0xd7, 0x36, 0x30, 0x33, 0x40, 0x9d, 0x25, 0xc7, 0x91,
    0x1d, 0x9f, 0xf2, 0xf8, 0xdd, 0x82, 0xb6, 0xf5, 0xb5, 0x8c, 0x7d, 0xfd,
    0x3d, 0xd9, 0x42, 0xe9, 0xdb, 0x55, 0x60, 0x45, 0xab, 0x1c, 0xbd, 0x7e,
    0x69, 0xb2, 0x4f, 0xc2, 0x0c, 0xb6, 0x77, 0x85, 0x9b, 0x83, 0xa1, 0x60,
    0x73, 0xad, 0xb3, 0x68, 0x5e, 0x9b, 0xae, 0x67, 0x7e, 0xb9, 0x81, 0x79,
    0xa5, 0x96, 0x8d, 0xcd, 0x61, 0x5a, 0x37, 0xe7, 0x99, 0x8d, 0xc6, 0x98,
    0x8e, 0xfd, 0xae, 0xea, 0x9a, 0xfe, 0xd6, 0x9a, 0x25, 0xbe, 0xda, 0x2f,
    0x45, 0x5c, 0x8a, 0x3c, 0x58, 0xbf, 0xc9, 0xdf, 0xd4, 0xd2, 0xde, 0x4c,
    0xa0, 0xc5, 0x87, 0xac, 0xb8, 0xf8, 0x29, 0xee, 0xc5, 0x61, 0x13, 0xdc,
    0xe5, 0xbb, 0xc5, 0xdc, 0xf4, 0x1c, 0xb1, 0xcb, 0x37, 0xf8, 0x73, 0x39,
    0xf3, 0xc2, 0xeb, 0x43, 0xc6, 0xbb, 0x6b, 0x00, 0x80, 0x57, 0x76, 0x49,
    0x77, 0x48, 0x0a, 0x07, 0xdc, 0x55, 0xce, 0xfe, 0x2a, 0x4f, 0x75, 0xc0,
    0x5d, 0xed, 0xc4, 0x6d, 0x17, 0x54, 0x0c, 0x93, 0x74, 0x46, 0x27, 0x93,
    0x2c, 0x4c, 0xa8, 0x45, 0xed, 0xb0, 0x5d, 0xe6, 0x8b, 0x83, 0x43, 0xa2,
    0xf4, 0x0f, 0x00, 0xe0, 0x50, 0xaf, 0x24, 0xab, 0x4e, 0xfc, 0x2e, 0x37,
    0x3d, 0x56, 0xbb, 0xad, 0x07, 0xf0, 0x22, 0xc4, 0x5c, 0xd9, 0x14, 0x17,
    0x4b, 0x05, 0x23, 0xfa, 0xe6, 0x29, 0x91, 0xfe, 0xd7, 0x67, 0xfa, 0xaf,
    0xf9, 0x0b, 0xde, 0xf6, 0x67, 0xde, 0x4c, 0xa4, 0x1d, 0xe7, 0x00, 0x00,
    0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image6_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0x72, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0xcd, 0x8f, 0x0b,
    0x71, 0x00, 0x86, 0x9f, 0x99, 0x4e, 0xdb, 0x99, 0x4e, 0x6b, 0x35, 0xa5,
    0x2c, 0xb1, 0x64, 0x7d, 0x64, 0x49, 0x6c, 0x90, 0x88, 0x83, 0x08, 0x4e,
    0xe2, 0xe4, 0xc2, 0xcd, 0x41, 0xe2, 0xec, 0x9f, 0xc0, 0x41, 0x48, 0x9c,
    0x36, 0x5c, 0x71, 0x12, 0x17, 0x17, 0x1f, 0x89, 0x88, 0xe2, 0xa0, 0x42,
    0x10, 0xf1, 0xb9, 0x8b, 0xfd, 0x2a, 0x5b, 0x53, 0xed, 0x74, 0x3a, 0xd3,
    0xf9, 0xec, 0xcc, 0xfc, 0x1c, 0xb0, 0x89, 0x44, 0x5c, 0xf6, 0x4d, 0xde,
    0xe3, 0xfb, 0x9c, 0xde, 0x47, 0x12, 0x42, 0xb0, 0x94, 0xc8, 0x4b, 0x5a,
    0x03, 0x0a, 0x40, 0x7d, 0x42, 0x1a, 0x13, 0x89, 0x72, 0x34, 0x5f, 0xd6,
    0xb7, 0x4a, 0x4a, 0x61, 0x47, 0xe8, 0x07, 0xdb, 0xba, 0x66, 0xef, 0xec,
    0x95, 0xab, 0xe9, 0x99, 0xd1, 0x6d, 0x68, 0x99, 0x98, 0x75, 0xd5, 0x61,
    0x76, 0x29, 0x59, 0x9a, 0xd5, 0x05, 0x1e, 0x1c, 0xbb, 0x21, 0x92, 0x3f,
    0x00, 0x49, 0x08, 0x41, 0xfd, 0x72, 0xae, 0xb6, 0x66, 0x7c, 0xdf, 0x81,
    0xca, 0xc6, 0xed, 0x14, 0x34, 0x88, 0x5c, 0x83, 0x17, 0xb7, 0x6b, 0xb3,
    0xb3, 0x93, 0xe6, 0xc3, 0x91, 0x2d, 0xea, 0x26, 0xbd, 0xc8, 0xce, 0x52,
    0xc1, 0xd5, 0xe7, 0xe7, 0xd3, 0xef, 0x6f, 0x26, 0x39, 0xbc, 0xb6, 0xba,
    0x6c, 0x3e, 0x46, 0xc8, 0x53, 0x38, 0xa6, 0x02, 0x90, 0x4a, 0xd9, 0x6c,
    0x65, 0x74, 0x9c, 0xe2, 0xea, 0xf5, 0xe0, 0x35, 0xc8, 0x69, 0x1a, 0x63,
    0xbb, 0x37, 0x6d, 0xd8, 0x3c, 0xde, 0x3e, 0xb1, 0x62, 0x28, 0x46, 0x56,
    0x2c, 0x90, 0x53, 0xa4, 0x94, 0x95, 0x4e, 0x50, 0x38, 0x57, 0x5e, 0x2e,
    0xaf, 0xee, 0xf7, 0x5d, 0x5d, 0x9f, 0xe6, 0xb8, 0x02, 0x60, 0x5b, 0xe1,
    0xab, 0x7e, 0x73, 0x72, 0x6f, 0xb1, 0x92, 0x07, 0xdf, 0x44, 0x4e, 0x4c,
    0xca, 0xab, 0x72, 0x88, 0xb4, 0x4a, 0xd0, 0x75, 0xe9, 0x35, 0x55, 0xa2,
    0x48, 0x27, 0xc9, 0x65, 0x32, 0x9b, 0x47, 0x8d, 0x43, 0xaa, 0x12, 0x30,
    0xe5, 0x24, 0x84, 0x21, 0x7b, 0x14, 0x80, 0xce, 0x0f, 0x31, 0xe7, 0x5a,
    0x06, 0xa4, 0x1d, 0x92, 0xa0, 0x85, 0x65, 0xf8, 0x0c, 0xd2, 0x11, 0xba,
    0xed, 0x80, 0x28, 0xd1, 0x08, 0xbd, 0x1e, 0x56, 0xeb, 0x2d, 0xaa, 0x6c,
    0xa2, 0x66, 0x3b, 0x38, 0x11, 0xcc, 0x7e, 0x43, 0x74, 0x2c, 0x3e, 0x2a,
    0x00, 0x66, 0x37, 0xfd, 0xe4, 0x74, 0xdb, 0xe0, 0x37, 0x70, 0xdb, 0x5d,
    0x2c, 0x6f, 0x3f, 0x3d, 0xd3, 0xc7, 0x98, 0x79, 0x47, 0x68, 0xbf, 0x24,
    0x89, 0x53, 0xf2, 0x39, 0xc8, 0x16, 0x20, 0xaf, 0x81, 0x15, 0x82, 0xed,
    0xf2, 0x3a, 0xf0, 0x79, 0xae, 0x00, 0xf4, 0x07, 0x34, 0x3c, 0xdb, 0x8e,
    0xb1, 0x1b, 0x4a, 0xe4, 0x0e, 0x21, 0xe2, 0x01, 0xd3, 0xcf, 0x26, 0x48,
    0x12, 0xd0, 0x74, 0xc8, 0x15, 0x40, 0x55, 0x41, 0x2f, 0x40, 0x3e, 0x07,
    0x5f, 0xa7, 0xc1, 0x71, 0xb9, 0x77, 0xe9, 0x96, 0xe8, 0xca, 0xbf, 0x01,
    0x7d, 0xc7, 0xee, 0x9b, 0x61, 0xa7, 0xc5, 0x20, 0x56, 0x30, 0x66, 0xee,
    0x93, 0x91, 0xa1, 0xbc, 0x12, 0x54, 0x0d, 0x34, 0x0d, 0x4a, 0xc5, 0x5f,
    0xf5, 0x23, 0xf8, 0xde, 0x81, 0x48, 0xf0, 0x68, 0xf1, 0x07, 0x9e, 0x4f,
    0xcf, 0xb1, 0xe3, 0x6f, 0xb6, 0xe9, 0x56, 0xbd, 0xc8, 0x21, 0xf6, 0x3e,
    0x53, 0x5c, 0x06, 0x05, 0x0d, 0xd4, 0x3c, 0x64, 0x33, 0x90, 0xa6, 0xd0,
    0xb3, 0xe1, 0xc3, 0x1c, 0xd8, 0x1e, 0xef, 0xe3, 0x01, 0x4f, 0x17, 0x01,
    0xbe, 0xc0, 0x69, 0x99, 0x52, 0xbb, 0xef, 0x49, 0xc4, 0x51, 0x13, 0x29,
    0x09, 0xa8, 0x56, 0x40, 0x48, 0x60, 0x39, 0xd0, 0x32, 0x7f, 0xd5, 0xf6,
    0x21, 0x08, 0x69, 0x09, 0xc1, 0xa9, 0x8b, 0x37, 0x84, 0xb9, 0x08, 0x60,
    0x81, 0x81, 0x33, 0x2c, 0x3a, 0x0b, 0xcd, 0x01, 0xe5, 0x92, 0x89, 0x17,
    0x42, 0xcb, 0x06, 0xc3, 0x84, 0x5e, 0x1f, 0xbc, 0x00, 0x23, 0x15, 0xd4,
    0xa2, 0x98, 0x3b, 0xb2, 0xe0, 0xc9, 0xf9, 0xeb, 0xe2, 0xcb, 0x5f, 0x4f,
    0x04, 0x38, 0x7d, 0x52, 0x3a, 0xa8, 0xab, 0xdc, 0xd4, 0x35, 0x86, 0xda,
    0x16, 0x22, 0x8c, 0x79, 0x83, 0xe0, 0xee, 0x20, 0xa6, 0xee, 0x05, 0xbc,
    0xc8, 0xeb, 0x74, 0x2f, 0x5c, 0x13, 0xee, 0x3f, 0x5d, 0x00, 0x78, 0xeb,
    0xf0, 0x78, 0x83, 0xc3, 0x11, 0x32, 0xec, 0xca, 0x65, 0xf9, 0x1c, 0xc4,
    0xd4, 0x4b, 0x4d, 0xac, 0x33, 0x35, 0x11, 0xff, 0x4f, 0x26, 0x69, 0xa9,
    0x3a, 0xff, 0x04, 0x4b, 0x8d, 0x4f, 0xed, 0xbd, 0xdc, 0x21, 0x42, 0x00,
    0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image7_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x03,
    0x18, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x4b, 0x68, 0x1c,
    0x75, 0x00, 0x87, 0xbf, 0x99, 0xf9, 0xcf, 0x6e, 0x76, 0xf2, 0xda, 0x3c,
    0x36, 0x36, 0x6c, 0x92, 0x96, 0x65, 0x69, 0x4a, 0x1a, 0x69, 0x9b, 0x87,
    0xf5, 0xad, 0x35, 0xc6, 0x52, 0x84, 0x82, 0x85, 0x06, 0x14, 0x45, 0x69,
    0xb1, 0xf5, 0xa8, 0x35, 0x78, 0x93, 0x4d, 0x8e, 0x5e, 0x72, 0x12, 0x3c,
    0x84, 0x5e, 0x72, 0x68, 0x20, 0x42, 0x0f, 0x8a, 0x94, 0x22, 0x48, 0x2a,
    0x4d, 0xb7, 0x6b, 0xd3, 0xd6, 0x98, 0x6e, 0x6d, 0xb3, 0x49, 0x04, 0x6b,
    0x66, 0xeb, 0x26, 0x6b, 0x66, 0x5f, 0x99, 0x9d, 0x99, 0x9d, 0x19, 0x4f,
    0x0d, 0x82, 0xc7, 0x7e, 0xa7, 0xdf, 0xe5, 0x77, 0xfa, 0xf8, 0x24, 0xdf,
    0xf7, 0x79, 0x1a, 0xc4, 0x93, 0x21, 0x49, 0x48, 0x13, 0x13, 0xdf, 0xd6,
    0x17, 0x0a, 0xd5, 0x03, 0xa5, 0x52, 0x79, 0xc0, 0x71, 0x9c, 0xe7, 0x6d,
    0xdb, 0x0d, 0xfb, 0xbe, 0x6f, 0x0a, 0xe1, 0xe9, 0xbe, 0xef, 0xa5, 0x54,
    0x35, 0xb0, 0x58, 0xa9, 0x14, 0xf4, 0xb9, 0xb9, 0x84, 0xbd, 0xfb, 0xf3,
    0x7d, 0x9f, 0x0b, 0x17, 0x2e, 0xb6, 0x3a, 0x8e, 0x78, 0x47, 0x08, 0xf9,
    0xbd, 0x86, 0x86, 0xd0, 0x8b, 0x91, 0x48, 0xb8, 0x2e, 0x1a, 0x6d, 0x26,
    0x1c, 0x0e, 0x62, 0x9a, 0x0e, 0xb9, 0xdc, 0x0e, 0x1b, 0x1b, 0x5b, 0xe4,
    0xb7, 0xb6, 0xfe, 0x34, 0x8a, 0xc5, 0x9f, 0xac, 0x5a, 0x6d, 0xba, 0x33,
    0x12, 0xb8, 0x3b, 0x35, 0xf5, 0x99, 0x29, 0xc6, 0xc7, 0x2f, 0xed, 0xd5,
    0xb4, 0xa6, 0x8b, 0x2d, 0x2d, 0x0d, 0x23, 0xa6, 0x59, 0x65, 0x78, 0xf8,
    0x39, 0x06, 0x07, 0xa3, 0x68, 0x1a, 0x5c, 0x3a, 0x37, 0x0a, 0xc0, 0xc9,
    0xa9, 0x1f, 0x09, 0x85, 0xe0, 0x46, 0x32, 0xdd, 0x93, 0xbc, 0xb6, 0xfc,
    0x51, 0xde, 0x28, 0xbc, 0x5b, 0x2c, 0xec, 0xcc, 0x00, 0xe7, 0x64, 0xcb,
    0xaa, 0x1c, 0xd2, 0xb4, 0xd0, 0xc8, 0xd9, 0xb3, 0xc7, 0x19, 0x18, 0x88,
    0xb3, 0xb8, 0x78, 0x1f, 0xdb, 0x86, 0x72, 0x19, 0x6a, 0x35, 0x70, 0x1c,
    0x90, 0x25, 0xf0, 0xa8, 0x91, 0x4e, 0xaf, 0xf3, 0xe1, 0x6b, 0x6f, 0x32,
    0x3a, 0x38, 0x18, 0xb4, 0x5c, 0xf7, 0x63, 0x00, 0x91, 0xcf, 0x17, 0x6f,
    0x84, 0xc3, 0xe1, 0x3b, 0xeb, 0xeb, 0xf9, 0x81, 0x40, 0xa0, 0x13, 0xc3,
    0x78, 0xc0, 0xd2, 0xd2, 0xef, 0x0c, 0x0d, 0x75, 0xf1, 0xca, 0x97, 0x73,
    0x78, 0x1e, 0x78, 0x14, 0xb9, 0x72, 0x35, 0x8d, 0x6b, 0x78, 0x78, 0x78,
    0x18, 0xa5, 0x22, 0xa6, 0x65, 0x7d, 0x0d, 0xa0, 0x2c, 0x2f, 0x5f, 0xdd,
    0xb9, 0x7c, 0x79, 0xa1, 0xb9, 0x58, 0xac, 0x8e, 0xc6, 0xe3, 0x3d, 0x54,
    0x2a, 0x26, 0x99, 0xcc, 0x2a, 0xba, 0xbe, 0xc3, 0xca, 0xca, 0x06, 0x6b,
    0x6b, 0x7f, 0xf1, 0xeb, 0xd2, 0x1f, 0xac, 0x3d, 0xc8, 0x32, 0x7a, 0xf8,
    0x30, 0x65, 0xbb, 0xca, 0x77, 0xc9, 0x85, 0xbc, 0xed, 0x59, 0x9f, 0x9c,
    0x3e, 0xf5, 0x6a, 0x5e, 0x00, 0x98, 0xa6, 0x73, 0xfd, 0xf1, 0xe3, 0x9c,
    0x63, 0x18, 0x9b, 0x6a, 0x2c, 0xd6, 0x4d, 0x2c, 0xd6, 0xfd, 0x7f, 0x5f,
    0x07, 0x20, 0xaa, 0x35, 0x70, 0xe5, 0xf6, 0x2f, 0x98, 0xb6, 0xbd, 0x70,
    0x30, 0xee, 0x66, 0x76, 0x35, 0x5a, 0x56, 0xe5, 0x51, 0xb9, 0xac, 0x16,
    0x4b, 0xa5, 0x52, 0x5b, 0x7b, 0x7b, 0x27, 0x37, 0x93, 0xbf, 0xe1, 0x63,
    0x51, 0x5f, 0xaf, 0xb1, 0x6d, 0x14, 0x30, 0xb6, 0x0d, 0x7a, 0xbb, 0x7a,
    0x38, 0xf4, 0xf2, 0x30, 0x05, 0xb3, 0x8c, 0x04, 0xd9, 0xf9, 0x79, 0xe4,
    0x44, 0x02, 0x4f, 0x00, 0xb8, 0xae, 0x27, 0xc0, 0x17, 0x42, 0xa8, 0x64,
    0x37, 0x36, 0x30, 0xcd, 0xbf, 0x79, 0xeb, 0xf8, 0x4b, 0x48, 0x52, 0x08,
    0x45, 0xb1, 0x59, 0xc9, 0xe8, 0xdc, 0xb9, 0x95, 0xe6, 0x0d, 0xa7, 0x1f,
    0x55, 0x08, 0xf0, 0x3c, 0x31, 0x3f, 0x3f, 0xe1, 0x42, 0x02, 0x19, 0x20,
    0x18, 0x14, 0x07, 0x5b, 0xc2, 0x4d, 0x8d, 0x91, 0xd6, 0x56, 0xca, 0x85,
    0x0a, 0x47, 0x86, 0x86, 0xb8, 0xbd, 0x98, 0xe1, 0xde, 0xbd, 0x55, 0x8e,
    0x1e, 0xdd, 0xcb, 0x07, 0xef, 0xbf, 0x40, 0x67, 0x57, 0x37, 0xb9, 0xed,
    0x6d, 0xf6, 0xc7, 0xa2, 0x28, 0x42, 0x19, 0x7e, 0xfd, 0xf4, 0x44, 0x3d,
    0x80, 0x7c, 0xec, 0xd8, 0xa4, 0x10, 0x42, 0x1d, 0xe9, 0x88, 0xb4, 0xc9,
    0x1d, 0x4d, 0x2d, 0x04, 0x10, 0xd4, 0x9c, 0x20, 0xd7, 0x17, 0xee, 0x92,
    0x4a, 0xdd, 0x22, 0x95, 0x5c, 0x21, 0xab, 0x5b, 0x3c, 0xd3, 0xb1, 0x87,
    0x42, 0xd1, 0xe4, 0x48, 0x5f, 0x1c, 0xad, 0x2e, 0xd0, 0xbf, 0x47, 0x51,
    0x3f, 0x07, 0x10, 0x91, 0x48, 0x9f, 0x8f, 0x9c, 0xad, 0x6e, 0xe6, 0xb6,
    0x58, 0x5e, 0x7a, 0xc8, 0xa3, 0xac, 0x4e, 0xee, 0xe1, 0x7d, 0xda, 0xda,
    0x1b, 0xb1, 0xcc, 0xaa, 0x35, 0x3d, 0xfd, 0x83, 0xdb, 0x18, 0x6e, 0xd2,
    0x14, 0x49, 0xe1, 0xd9, 0x7d, 0xfb, 0xb8, 0x96, 0x4c, 0x53, 0xb5, 0x1d,
    0x59, 0xa8, 0xca, 0x09, 0x60, 0x52, 0xf2, 0x7d, 0x9f, 0x33, 0x67, 0xa6,
    0xba, 0x55, 0x21, 0xbe, 0x91, 0x65, 0xf9, 0xed, 0x9a, 0xeb, 0xfd, 0xec,
    0x54, 0xcd, 0xef, 0x83, 0x5a, 0xfd, 0xaa, 0xeb, 0x7a, 0xab, 0xba, 0xbe,
    0x69, 0x8a, 0x3a, 0xb9, 0xbf, 0xa5, 0x51, 0x3b, 0x59, 0x17, 0x08, 0x8e,
    0x59, 0xb6, 0xd3, 0xe0, 0xe3, 0xdd, 0xf4, 0x7d, 0xe5, 0xd3, 0x99, 0x99,
    0xf1, 0x94, 0xf4, 0xa4, 0xc6, 0xf3, 0xe7, 0xbf, 0x6a, 0xae, 0x56, 0x95,
    0x3e, 0xc7, 0x91, 0x32, 0xbd, 0xbd, 0xe5, 0x7f, 0x12, 0x89, 0x84, 0xf7,
    0x5f, 0x8b, 0x63, 0x63, 0x93, 0x01, 0x55, 0x15, 0x27, 0x24, 0x49, 0x8a,
    0xbb, 0xae, 0x98, 0x9d, 0x9d, 0xfd, 0x42, 0xdf, 0x8d, 0xe9, 0x69, 0xf8,
    0x17, 0x30, 0xac, 0x74, 0xca, 0x52, 0x48, 0x49, 0xdf, 0x00, 0x00, 0x00,
    0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image8_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xe0, 0x77, 0x3d, 0xf8, 0x00, 0x00, 0x05,
    0xc6, 0x49, 0x44, 0x41, 0x54, 0x48, 0x89, 0xb5, 0x95, 0x7b, 0x68, 0x9d,
    0x67, 0x1d, 0xc7, 0x3f, 0xcf, 0xfb, 0xbc, 0xef, 0x79, 0xcf, 0x3d, 0x97,
    0x93, 0x4b, 0x93, 0x34, 0xcd, 0x92, 0x25, 0x6d, 0xb3, 0xb4, 0x8a, 0x73,
    0xd2, 0xb2, 0xe1, 0xec, 0xa8, 0x0c, 0x75, 0x65, 0xfb, 0x6b, 0xda, 0xa1,
    0xa8, 0x6c, 0xff, 0x0c, 0x04, 0x37, 0xa5, 0x56, 0x98, 0x4a, 0xb1, 0x38,
    0x51, 0x18, 0x0e, 0x15, 0x26, 0x74, 0x4e, 0x19, 0xc2, 0xec, 0x06, 0x52,
    0xd4, 0x5d, 0x90, 0xad, 0x9a, 0x0d, 0xdb, 0x2d, 0xab, 0x2b, 0x4d, 0x93,
    0x76, 0x6d, 0x42, 0xda, 0x34, 0x6b, 0x73, 0x69, 0x4e, 0xce, 0xc9, 0xb9,
    0xe5, 0x7d, 0xcf, 0x79, 0x9f, 0x8b, 0x7f, 0xa8, 0xa5, 0x21, 0xdd, 0x9f,
    0x7e, 0xff, 0xfc, 0x3d, 0xf0, 0xfb, 0xf0, 0xfd, 0xdd, 0x1e, 0x61, 0xad,
    0xe5, 0xff, 0x29, 0xf7, 0xe3, 0x1e, 0xc6, 0x7e, 0x23, 0xc4, 0xea, 0x02,
    0x52, 0x26, 0xe8, 0x08, 0xaa, 0xe4, 0x34, 0xec, 0x50, 0x9a, 0x01, 0x6d,
    0xe9, 0x8d, 0x14, 0x2a, 0x52, 0x38, 0x5a, 0x53, 0x74, 0x3c, 0x26, 0x31,
    0xbc, 0xfe, 0xe8, 0x2f, 0x6d, 0xe9, 0x56, 0x79, 0xc4, 0xad, 0x1c, 0x7c,
    0x70, 0x44, 0x64, 0xa2, 0x06, 0xfb, 0xea, 0x21, 0xf7, 0x69, 0x23, 0xf7,
    0xc8, 0xb8, 0xdb, 0x8f, 0x17, 0x73, 0x85, 0xf0, 0x88, 0x22, 0x8d, 0x56,
    0x1a, 0xa5, 0x2d, 0xf5, 0x50, 0x53, 0x5c, 0xa9, 0xa3, 0xb4, 0x1d, 0x55,
    0x8a, 0xef, 0x2a, 0xc5, 0x99, 0x6f, 0x1f, 0x59, 0x9f, 0x70, 0x83, 0x83,
    0xb1, 0xe7, 0xc4, 0x88, 0x03, 0x2f, 0xb8, 0xbe, 0xbf, 0xab, 0xb9, 0x7f,
    0x1b, 0xa9, 0x8e, 0x61, 0x92, 0xad, 0x23, 0xf8, 0x99, 0x1e, 0x5c, 0x3f,
    0x81, 0xc0, 0xc3, 0x9a, 0x35, 0xac, 0xad, 0x51, 0x5d, 0x9a, 0x60, 0xec,
    0xd5, 0x97, 0xb9, 0x7a, 0xa5, 0xb0, 0x07, 0x38, 0x0e, 0x3c, 0x02, 0xfc,
    0xed, 0x63, 0x1d, 0x8c, 0x3e, 0x2b, 0x1c, 0x09, 0x6f, 0xa4, 0x9a, 0x92,
    0xf7, 0xf7, 0xdf, 0xf7, 0x24, 0x2d, 0xfd, 0x5f, 0x07, 0x3a, 0x81, 0x55,
    0xac, 0x59, 0x41, 0x87, 0xd7, 0x50, 0x8d, 0x02, 0x2a, 0x58, 0x42, 0x37,
    0x56, 0x71, 0x5d, 0xc9, 0xf8, 0xe8, 0x5f, 0x19, 0x3f, 0x71, 0x16, 0x0b,
    0x28, 0xc5, 0x62, 0xc3, 0xb0, 0xf7, 0xc0, 0x6f, 0xed, 0xf9, 0x5b, 0x3a,
    0xb0, 0x8a, 0x4f, 0x5a, 0x97, 0xbd, 0x1d, 0x3b, 0x1e, 0xa0, 0xa5, 0xff,
    0x69, 0x20, 0x44, 0x37, 0x8e, 0xd3, 0x08, 0xc6, 0x89, 0x6a, 0x8b, 0xe8,
    0x70, 0x0d, 0x55, 0xaf, 0xa2, 0x1a, 0x01, 0xa6, 0x51, 0x47, 0x00, 0x41,
    0xb5, 0x8c, 0x31, 0x60, 0x2c, 0x68, 0xc3, 0x26, 0x01, 0xcf, 0xff, 0xfc,
    0x1b, 0xe2, 0x0b, 0xdf, 0x7f, 0xd1, 0x56, 0x36, 0x00, 0x8c, 0xe1, 0x4b,
    0x31, 0xdf, 0x91, 0xb9, 0xad, 0x0f, 0x03, 0x11, 0x5a, 0xbf, 0x82, 0x36,
    0x97, 0x10, 0xc2, 0xc1, 0xf1, 0x32, 0x58, 0x2d, 0x90, 0x46, 0x80, 0x75,
    0x31, 0x22, 0x06, 0x02, 0xdc, 0x98, 0x8f, 0x94, 0x2e, 0xc2, 0x82, 0x15,
    0x06, 0x13, 0xd9, 0xbb, 0xb1, 0x76, 0x3f, 0xf0, 0xfc, 0x06, 0x80, 0xb6,
    0xec, 0x70, 0x53, 0xed, 0x24, 0x9a, 0x86, 0xc1, 0x4c, 0x20, 0xcd, 0x3c,
    0x52, 0xb6, 0x82, 0x1b, 0xa0, 0xa3, 0x88, 0x00, 0x88, 0xac, 0x01, 0x2c,
    0x08, 0x89, 0x70, 0x24, 0xdd, 0xb7, 0x0f, 0x10, 0x4f, 0x66, 0x30, 0x2a,
    0xa0, 0xb4, 0xbc, 0xcc, 0xb9, 0xf1, 0x65, 0x2c, 0xb4, 0x6e, 0x28, 0xd1,
    0x5f, 0x9e, 0x16, 0x4e, 0x0c, 0xba, 0xe3, 0x99, 0x6e, 0x10, 0x1d, 0xd0,
    0x78, 0x87, 0x6a, 0xb5, 0x44, 0x68, 0xd6, 0x10, 0x36, 0x22, 0xae, 0x23,
    0x92, 0xc2, 0xe2, 0xbb, 0x92, 0xd5, 0x08, 0x70, 0x24, 0x38, 0x2e, 0xb9,
    0x9e, 0x1e, 0x3a, 0x7b, 0xbb, 0x50, 0xb5, 0x02, 0x53, 0xa7, 0x03, 0xb4,
    0xbd, 0xae, 0xad, 0xe5, 0xe4, 0x06, 0x80, 0x96, 0xb4, 0x8b, 0x90, 0x8e,
    0x94, 0x97, 0xe5, 0x4a, 0x75, 0x82, 0x77, 0x2f, 0x1d, 0x63, 0x22, 0x3f,
    0xc9, 0x7c, 0x10, 0x61, 0x42, 0x43, 0x2b, 0x09, 0x76, 0xb7, 0xb6, 0xb1,
    0x2b, 0x97, 0xa3, 0xd3, 0x8f, 0xb1, 0x66, 0x0c, 0xc6, 0x91, 0x58, 0x2b,
    0x68, 0x34, 0x0c, 0x8d, 0x20, 0xe4, 0xda, 0x47, 0x65, 0xb4, 0x61, 0x4e,
    0x29, 0x66, 0x36, 0x00, 0xfa, 0x56, 0xf0, 0x97, 0x93, 0x24, 0x46, 0xd5,
    0x2c, 0x97, 0x67, 0x7e, 0x4d, 0xbd, 0x1e, 0xc7, 0x6b, 0xfe, 0x1c, 0xb1,
    0xa6, 0x32, 0xe5, 0x6a, 0x8d, 0x13, 0x8b, 0x17, 0xf8, 0xd3, 0xd9, 0x31,
    0x46, 0x64, 0x96, 0x83, 0x3b, 0x47, 0xd8, 0xdd, 0xd5, 0x45, 0x20, 0x24,
    0x56, 0x38, 0x58, 0x0b, 0x98, 0x06, 0xc5, 0x62, 0x80, 0x35, 0xcc, 0xfc,
    0xe8, 0x8f, 0x76, 0x7e, 0x03, 0xa0, 0xa3, 0xee, 0xc7, 0x8e, 0x0d, 0xd9,
    0x6c, 0xb1, 0x77, 0x90, 0xcf, 0x77, 0x3d, 0x48, 0x53, 0x6b, 0x13, 0x6b,
    0xb2, 0x44, 0xc5, 0xe6, 0x59, 0x2a, 0x95, 0x18, 0xb8, 0xad, 0x93, 0xf7,
    0x2f, 0x8d, 0xf3, 0xf7, 0x53, 0x63, 0xcc, 0xfe, 0xb3, 0xca, 0xaf, 0xee,
    0xde, 0xc5, 0x9e, 0xfe, 0x01, 0xca, 0xca, 0x82, 0x30, 0x04, 0xb5, 0x90,
    0x30, 0x88, 0x00, 0xf2, 0x37, 0xf7, 0xf5, 0x06, 0xe0, 0x7b, 0x77, 0xc6,
    0xef, 0x89, 0x0d, 0x6c, 0x6d, 0x79, 0x6c, 0xe7, 0x01, 0x3c, 0xbf, 0xc0,
    0xbf, 0xec, 0xeb, 0x9c, 0xbd, 0x7e, 0x86, 0x89, 0xe9, 0x59, 0x84, 0x74,
    0xd8, 0x94, 0x18, 0xa2, 0xa5, 0x25, 0xc3, 0xe0, 0x1d, 0xdd, 0x9c, 0x3f,
    0x75, 0x85, 0x83, 0x27, 0x3f, 0xe0, 0x58, 0xae, 0x9d, 0xce, 0x6c, 0x13,
    0x35, 0x05, 0xf5, 0xa0, 0x8e, 0x31, 0x06, 0x6b, 0xa8, 0x6c, 0x00, 0xdc,
    0xfb, 0x62, 0x77, 0x5a, 0x65, 0xbd, 0x27, 0x1e, 0x1b, 0xf8, 0x32, 0x55,
    0x6f, 0x8e, 0x77, 0xea, 0x2f, 0x51, 0xae, 0x97, 0x58, 0x9a, 0x32, 0x7c,
    0xd3, 0x3b, 0x4c, 0x3d, 0x5d, 0xe4, 0xc8, 0xf2, 0x33, 0x14, 0x2a, 0x21,
    0x59, 0xd9, 0x4e, 0xcb, 0x96, 0x14, 0x67, 0x4e, 0xaf, 0xf0, 0xc6, 0xec,
    0x55, 0x1e, 0xbf, 0xb3, 0x95, 0xb5, 0x1b, 0x63, 0xee, 0x60, 0x0c, 0x99,
    0x9b, 0x01, 0x0e, 0x40, 0xbe, 0x96, 0xdf, 0xbb, 0x25, 0x35, 0xf4, 0xa9,
    0x74, 0x26, 0xcd, 0xdb, 0xab, 0x7f, 0x66, 0x76, 0xa6, 0xc4, 0xc2, 0x89,
    0x34, 0xdb, 0xc3, 0x7b, 0x79, 0x7c, 0xd7, 0xb7, 0x78, 0xa0, 0x73, 0x3f,
    0x3b, 0xd5, 0x67, 0x69, 0x26, 0x47, 0x39, 0xa8, 0xe0, 0x25, 0x63, 0x90,
    0x76, 0x78, 0x7b, 0x6e, 0x91, 0x52, 0xa4, 0x71, 0xa4, 0x47, 0x22, 0xe5,
    0xe3, 0x38, 0x0e, 0xc6, 0xb2, 0xe9, 0xc9, 0x87, 0x84, 0xb3, 0x0e, 0xa0,
    0x94, 0xd8, 0xd7, 0xe6, 0xf7, 0x32, 0xd3, 0x38, 0xc7, 0xb9, 0x85, 0x0b,
    0xe4, 0xf2, 0xc3, 0xfc, 0x74, 0xc7, 0xef, 0x79, 0x6a, 0xf7, 0x4f, 0x08,
    0xc4, 0x1a, 0x9b, 0x5a, 0xba, 0x78, 0xf6, 0x33, 0x47, 0xf8, 0xce, 0xb6,
    0x1f, 0x50, 0x53, 0x21, 0x71, 0x37, 0x81, 0x9f, 0x89, 0x33, 0xbe, 0x90,
    0xa7, 0xac, 0x05, 0x5e, 0x3c, 0x43, 0x22, 0xdb, 0x4c, 0xae, 0x3d, 0x81,
    0x85, 0x3b, 0xb2, 0x3e, 0x9b, 0xd7, 0x01, 0x50, 0xde, 0xf6, 0x72, 0xbd,
    0xca, 0x4c, 0xe9, 0x32, 0xd7, 0x2b, 0x15, 0x32, 0x2d, 0x69, 0xb2, 0x5d,
    0x92, 0x5a, 0xac, 0x42, 0xc1, 0x14, 0x29, 0x51, 0xc0, 0x4d, 0x49, 0x56,
    0x54, 0x81, 0x0e, 0xbf, 0x93, 0x4c, 0xac, 0x19, 0xa1, 0x05, 0x9e, 0x23,
    0x71, 0xfd, 0x24, 0xd2, 0x4f, 0xe2, 0x26, 0x73, 0xf4, 0xf6, 0xb7, 0x60,
    0xad, 0xe8, 0x10, 0x70, 0xd7, 0x3a, 0x80, 0x6e, 0xc8, 0x6b, 0x57, 0x2b,
    0x1f, 0xe1, 0x9a, 0x24, 0x6d, 0xce, 0x16, 0x26, 0xa3, 0xd3, 0x7c, 0xf5,
    0xcd, 0x07, 0x99, 0x2e, 0x5e, 0xa4, 0xcb, 0xe9, 0xe6, 0xc8, 0xf4, 0x73,
    0x3c, 0x74, 0xfc, 0x8b, 0xbc, 0xb5, 0xf8, 0x26, 0xdb, 0x73, 0x23, 0xf8,
    0xc2, 0xa7, 0x9e, 0x6f, 0x30, 0xd8, 0x9e, 0x23, 0xeb, 0xc7, 0x30, 0xd6,
    0xe2, 0x48, 0x9f, 0xb6, 0xf6, 0x26, 0x92, 0x49, 0x0f, 0xe0, 0xd1, 0x75,
    0x00, 0x13, 0x31, 0x7a, 0x75, 0xe1, 0x1a, 0x3d, 0x72, 0x90, 0xbe, 0xd4,
    0x30, 0xa6, 0xe1, 0x93, 0xd7, 0xab, 0xcc, 0xaa, 0xcb, 0xfc, 0xa3, 0xf4,
    0x16, 0x17, 0x56, 0x2f, 0xa2, 0xb0, 0xf4, 0x64, 0x7a, 0x49, 0xfa, 0x69,
    0x6a, 0x0b, 0x35, 0xec, 0x9a, 0xe2, 0x9e, 0xee, 0x04, 0x69, 0xbd, 0x8c,
    0x09, 0x96, 0xd0, 0x8d, 0x32, 0x89, 0x84, 0xa4, 0xbb, 0xcb, 0x43, 0x6b,
    0xee, 0xff, 0xf1, 0xc3, 0xe2, 0x2e, 0xf8, 0xef, 0xb9, 0xee, 0x38, 0x98,
    0xcc, 0xa5, 0xb2, 0xc9, 0x77, 0xb7, 0x0c, 0xf6, 0x0d, 0xdd, 0x36, 0x3c,
    0x44, 0xd6, 0x6d, 0x42, 0x69, 0x85, 0x23, 0x24, 0x58, 0x70, 0x90, 0xc4,
    0xdd, 0x14, 0x65, 0x5d, 0xe1, 0xc3, 0x8b, 0xe7, 0x79, 0xef, 0xfd, 0x49,
    0xd2, 0x95, 0x32, 0xbf, 0xd8, 0xdc, 0xc6, 0xed, 0x6d, 0x19, 0x62, 0x59,
    0x9f, 0xa6, 0x26, 0x97, 0xb8, 0xa8, 0xf2, 0xde, 0xc9, 0x79, 0x26, 0xce,
    0x87, 0xc4, 0x3c, 0x5e, 0x3b, 0x74, 0xd4, 0xee, 0xbb, 0xf1, 0x1f, 0x6c,
    0xfa, 0x61, 0xf3, 0xd7, 0x12, 0xf1, 0xd8, 0x1f, 0xfa, 0x87, 0x87, 0x18,
    0x1c, 0xd8, 0x46, 0x47, 0xba, 0x13, 0xa4, 0xc0, 0x18, 0x83, 0x52, 0x9a,
    0x7c, 0x79, 0x85, 0xe9, 0x99, 0x29, 0x2e, 0x4c, 0x4e, 0xb1, 0x96, 0x5f,
    0x61, 0x7f, 0x64, 0xd8, 0xa1, 0x04, 0xa1, 0x05, 0xd7, 0x93, 0xc4, 0x7c,
    0x17, 0x57, 0x5a, 0x2a, 0x95, 0x88, 0x30, 0x34, 0x08, 0x01, 0x87, 0x8e,
    0x5a, 0x71, 0x63, 0xd1, 0x8a, 0x61, 0xed, 0x65, 0xa5, 0x74, 0xff, 0xf4,
    0xf8, 0xd4, 0xe1, 0x95, 0xf9, 0x32, 0x5d, 0x3d, 0x5d, 0xa4, 0x52, 0x29,
    0x94, 0x32, 0x14, 0x0a, 0x45, 0x16, 0x17, 0x16, 0x59, 0x5a, 0x5c, 0xa4,
    0x1a, 0xd4, 0x8a, 0x9f, 0x56, 0xe6, 0x95, 0x4f, 0x68, 0x92, 0x35, 0x63,
    0xbb, 0x95, 0x66, 0x6b, 0xd8, 0x50, 0xbd, 0x54, 0xd5, 0x7f, 0x6a, 0xee,
    0x80, 0x10, 0xac, 0x01, 0x07, 0xd6, 0x6d, 0x72, 0xfd, 0x99, 0x28, 0x8a,
    0x3f, 0x21, 0x7f, 0x66, 0xab, 0xc1, 0x19, 0x55, 0xaa, 0x3e, 0xb5, 0x38,
    0x77, 0x6d, 0xb7, 0xe3, 0xc5, 0x30, 0xda, 0x50, 0x0d, 0x6b, 0x04, 0xf5,
    0xb0, 0x60, 0x8d, 0x79, 0x09, 0xc3, 0xef, 0xba, 0x2d, 0x1f, 0xb6, 0x58,
    0x44, 0xc5, 0xc1, 0xb1, 0x8a, 0x1e, 0x07, 0xfa, 0x70, 0xe8, 0x01, 0xb6,
    0x01, 0x25, 0x60, 0x14, 0x38, 0x75, 0xa3, 0x07, 0x37, 0x2b, 0xfe, 0x15,
    0x21, 0xfa, 0x24, 0xad, 0x97, 0x12, 0x62, 0xb3, 0x96, 0x8c, 0x60, 0x89,
    0x5b, 0x6b, 0x97, 0x89, 0x38, 0x87, 0xcb, 0x9c, 0x7d, 0xc1, 0x2a, 0x6e,
    0xa1, 0xc3, 0x8f, 0x08, 0xc7, 0x5a, 0x04, 0xc0, 0xa1, 0xa3, 0x56, 0xff,
    0x2f, 0xfe, 0x6f, 0x82, 0x37, 0xca, 0x31, 0x97, 0x05, 0x22, 0x0e, 0x00,
    0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image9_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xbb, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0x95, 0x93, 0x4b, 0x8c, 0x4c,
    0x79, 0x14, 0xc6, 0x7f, 0xb7, 0x6e, 0x55, 0x57, 0xb5, 0xa9, 0x5b, 0x0f,
    0x8f, 0x6a, 0x9a, 0xa2, 0x9b, 0x91, 0xc8, 0xe8, 0xa6, 0x74, 0x24, 0x16,
    0x84, 0x8d, 0x98, 0x0d, 0xf1, 0x48, 0x5a, 0x24, 0x63, 0x12, 0xc9, 0xc4,
    0x86, 0x49, 0x46, 0x22, 0xb3, 0x18, 0x9b, 0x89, 0x58, 0x8b, 0x10, 0x0b,
    0x6c, 0xac, 0x84, 0x19, 0x84, 0xc5, 0x44, 0xbc, 0xd3, 0xa2, 0x33, 0x8d,
    0x68, 0xed, 0x95, 0x16, 0x46, 0x30, 0xa8, 0xea, 0x56, 0xad, 0xeb, 0xde,
    0x5b, 0x75, 0xab, 0xfe, 0xf7, 0x51, 0xf7, 0xfe, 0xad, 0xba, 0x68, 0x24,
    0xf8, 0xd6, 0xe7, 0xfc, 0xce, 0xc9, 0x39, 0xdf, 0xa7, 0x48, 0x29, 0xf9,
    0x1a, 0x29, 0x28, 0x8a, 0xe4, 0xd3, 0x62, 0xe5, 0x63, 0xc0, 0xfa, 0x9e,
    0x45, 0xa9, 0x90, 0x70, 0xb6, 0x04, 0xaa, 0xb2, 0xc9, 0xf5, 0x83, 0x25,
    0xc2, 0xf6, 0xb0, 0x74, 0xfb, 0x41, 0xa5, 0xec, 0xf6, 0x18, 0x42, 0xec,
    0x19, 0xfe, 0xde, 0x2a, 0xd1, 0x4d, 0x30, 0x06, 0x1b, 0x07, 0xd8, 0x78,
    0xa9, 0x23, 0x37, 0x7b, 0xfa, 0xdc, 0x8b, 0x6b, 0x66, 0xfd, 0x32, 0x65,
    0x52, 0x74, 0x06, 0x46, 0xbd, 0x44, 0xde, 0x7e, 0xc5, 0xeb, 0xda, 0x2b,
    0x4e, 0xdd, 0x3b, 0x46, 0xe1, 0x49, 0xb1, 0x62, 0x99, 0x4e, 0x77, 0x51,
    0x56, 0xaf, 0xc8, 0x3f, 0x65, 0x1d, 0x20, 0xdc, 0x98, 0x7c, 0xae, 0x23,
    0xd7, 0x35, 0xb7, 0xab, 0xef, 0xa7, 0x39, 0x3b, 0x63, 0xbd, 0xf5, 0x93,
    0xfc, 0x53, 0x1e, 0xc0, 0xac, 0x09, 0x8c, 0x6a, 0x0d, 0x51, 0x93, 0xfc,
    0x90, 0xcd, 0x61, 0x71, 0x53, 0xab, 0xdd, 0x7f, 0x7b, 0x5e, 0xb3, 0xc3,
    0x4b, 0x15, 0x94, 0x3e, 0x89, 0x94, 0xa1, 0x31, 0x40, 0x2a, 0x9d, 0xbe,
    0xb0, 0xa1, 0xfd, 0xd7, 0xd8, 0x59, 0x6f, 0x2f, 0x43, 0x3c, 0xc6, 0x75,
    0x7c, 0x9e, 0xde, 0x36, 0x90, 0x6f, 0xe2, 0x08, 0xbf, 0xc6, 0x9d, 0xe2,
    0x0d, 0x7c, 0x24, 0x72, 0x2a, 0x28, 0x8e, 0x7a, 0x82, 0xdd, 0xa8, 0x00,
    0x21, 0x80, 0x95, 0x7f, 0xb5, 0xff, 0xb6, 0x72, 0x4e, 0x77, 0xe6, 0xb4,
    0x79, 0x80, 0x92, 0xd0, 0xa9, 0x08, 0x87, 0x42, 0xc1, 0xe0, 0xef, 0x1f,
    0xaf, 0x72, 0x7c, 0xf9, 0x65, 0x7c, 0xdf, 0xc7, 0x0b, 0x02, 0x2c, 0xb7,
    0x8a, 0xd2, 0x1c, 0x86, 0xe6, 0x50, 0xb6, 0x49, 0x57, 0xd7, 0x37, 0x00,
    0x7e, 0x48, 0xdd, 0x14, 0x6e, 0x8a, 0x91, 0xaf, 0xe6, 0xc9, 0x0f, 0xeb,
    0xb8, 0x37, 0xdb, 0xe8, 0xb2, 0xd6, 0x92, 0x6a, 0x4e, 0x01, 0xb0, 0xca,
    0xfb, 0x99, 0x79, 0x41, 0x0e, 0x95, 0x08, 0x5a, 0x24, 0x41, 0x44, 0x6b,
    0x22, 0x90, 0x72, 0x61, 0xe3, 0x06, 0x9e, 0xac, 0x77, 0x3c, 0xb3, 0x1e,
    0x53, 0x11, 0x82, 0xa1, 0x41, 0xc1, 0xd1, 0x0d, 0x07, 0xc6, 0x7d, 0xe6,
    0xf7, 0x65, 0x7f, 0xf0, 0x6f, 0xbe, 0x97, 0xad, 0xfd, 0x5b, 0xf8, 0x2e,
    0x9a, 0xc0, 0x8a, 0xd8, 0xf8, 0x9e, 0xb9, 0xa0, 0xb1, 0x81, 0x63, 0xfb,
    0xf1, 0xbc, 0x95, 0xc7, 0xaa, 0x39, 0xb4, 0xb4, 0xc7, 0xb9, 0x5e, 0xbc,
    0xcc, 0x4b, 0xe3, 0x7f, 0x00, 0x4c, 0xc7, 0xa4, 0xaf, 0xd0, 0xcb, 0x2d,
    0xf3, 0x06, 0xe9, 0xd8, 0x64, 0xb4, 0xa6, 0x24, 0xa1, 0xba, 0x8a, 0x94,
    0x3c, 0x7f, 0x0f, 0xa8, 0xf9, 0xf9, 0x37, 0xd5, 0x51, 0x5c, 0x2f, 0xc4,
    0x88, 0x63, 0xb2, 0xeb, 0xbf, 0x6d, 0x18, 0x55, 0x03, 0x80, 0x47, 0xc6,
    0x43, 0x36, 0xdf, 0xea, 0xe6, 0xd4, 0xeb, 0x93, 0xb4, 0x25, 0x67, 0x03,
    0x0a, 0xf6, 0xa8, 0x0d, 0xc1, 0x07, 0x00, 0xd7, 0x92, 0x57, 0x4b, 0xba,
    0x41, 0x5a, 0x6d, 0x25, 0xa5, 0xb4, 0x12, 0xf6, 0x35, 0x8a, 0xfe, 0x30,
    0x65, 0xb7, 0xcc, 0x0b, 0xf1, 0x9c, 0x79, 0xe9, 0x4e, 0x72, 0x2d, 0x8b,
    0x89, 0x47, 0x34, 0xde, 0x8e, 0x8c, 0x52, 0xd1, 0x2d, 0xf0, 0x39, 0xd3,
    0x30, 0x52, 0xdb, 0x9e, 0xcc, 0xa2, 0x89, 0x99, 0x89, 0x77, 0x3a, 0x17,
    0x2f, 0xa4, 0x35, 0x9e, 0xc5, 0x0d, 0x5c, 0x2c, 0xdb, 0x22, 0xa4, 0xa8,
    0x24, 0xa2, 0x29, 0xb4, 0x88, 0x46, 0xd9, 0xb1, 0xe8, 0x7f, 0xd1, 0xcf,
    0x40, 0xef, 0x00, 0xba, 0xae, 0xef, 0x97, 0x87, 0xe4, 0x8e, 0x71, 0x4e,
    0x9c, 0xb9, 0x3b, 0x73, 0x70, 0x7a, 0x7b, 0x76, 0x7b, 0xe7, 0xfc, 0x1c,
    0xd9, 0xe4, 0x4c, 0xa2, 0x6a, 0x14, 0x14, 0x05, 0xcf, 0xf7, 0x28, 0x94,
    0x0b, 0x3c, 0x78, 0xfa, 0x90, 0xc1, 0xbb, 0x83, 0xe8, 0x25, 0xfd, 0x5e,
    0x10, 0x04, 0x2b, 0xe4, 0x61, 0x69, 0x7e, 0x62, 0xe5, 0xcc, 0xae, 0xf4,
    0xc1, 0x74, 0x2a, 0xbd, 0xbd, 0x65, 0xc6, 0x34, 0x12, 0x89, 0x24, 0x52,
    0x82, 0x5e, 0x36, 0x18, 0x7a, 0x59, 0xa0, 0x58, 0x1c, 0x41, 0x08, 0xd1,
    0x23, 0xa5, 0x5c, 0x37, 0xd6, 0xfc, 0xd9, 0x30, 0x45, 0xb6, 0x29, 0x2b,
    0xe2, 0x13, 0xe2, 0x5b, 0x23, 0xe1, 0xd8, 0x6a, 0x3f, 0x08, 0x92, 0xc2,
    0x16, 0xa6, 0xb0, 0x45, 0x0f, 0xb0, 0x4f, 0x1e, 0x91, 0xd7, 0xbe, 0x98,
    0xc6, 0x6f, 0xd5, 0x3b, 0xf0, 0xc6, 0x6e, 0x50, 0xb4, 0xaf, 0x2c, 0xef,
    0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image10_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xde, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x4d, 0x68, 0x1c,
    0x05, 0x14, 0xc7, 0xff, 0x6f, 0x3e, 0x76, 0x36, 0xfb, 0x91, 0xa4, 0x24,
    0x4b, 0x76, 0x37, 0x4b, 0x3e, 0x0e, 0x46, 0x9b, 0x8a, 0xa8, 0xd1, 0xa4,
    0x44, 0xd2, 0x4b, 0x13, 0xb1, 0xd0, 0xd6, 0xa6, 0x50, 0xa1, 0x35, 0x3d,
    0x58, 0x28, 0x04, 0x44, 0x31, 0x8a, 0xd4, 0x83, 0x01, 0xc5, 0x8b, 0xed,
    0xa1, 0x4a, 0x25, 0x07, 0x31, 0x51, 0x28, 0x25, 0x34, 0xb4, 0x10, 0x35,
    0xb4, 0x85, 0x8a, 0xd4, 0x24, 0x42, 0xb6, 0x14, 0x6c, 0xd3, 0x92, 0x60,
    0xd2, 0xda, 0x74, 0x93, 0x5d, 0x36, 0x6e, 0xf7, 0x6b, 0x76, 0x26, 0x3b,
    0xb3, 0x93, 0xd9, 0x79, 0x1e, 0x24, 0xa5, 0xe8, 0x5e, 0x4a, 0x7f, 0xf7,
    0xf7, 0xe3, 0xbd, 0x1f, 0x3c, 0x62, 0x66, 0x3c, 0x0d, 0x12, 0x00, 0x10,
    0x11, 0xc9, 0x03, 0xf2, 0xc1, 0xe0, 0x8e, 0xe0, 0xe9, 0x70, 0x5d, 0xb8,
    0x29, 0x5e, 0x5c, 0x8b, 0x66, 0x97, 0xf2, 0x9f, 0x1b, 0x3f, 0x15, 0x7f,
    0xe1, 0x04, 0x97, 0x69, 0x88, 0x14, 0xa1, 0x9d, 0x5c, 0xe5, 0xe3, 0x8e,
    0xf6, 0x5f, 0x01, 0x31, 0x33, 0xa4, 0xb7, 0xa4, 0xd7, 0x5f, 0xe9, 0xeb,
    0xb8, 0xd0, 0xd3, 0xdd, 0x5d, 0xed, 0x88, 0x06, 0x7c, 0xe4, 0xc5, 0xe2,
    0xca, 0x3d, 0x6b, 0xf6, 0x76, 0xf4, 0x53, 0x5f, 0xa9, 0xe6, 0x7a, 0x3e,
    0x9c, 0x79, 0x3f, 0xbf, 0x99, 0xff, 0xde, 0x1e, 0x2c, 0x5f, 0xfe, 0xdf,
    0x06, 0xe4, 0x25, 0x4f, 0xcb, 0x27, 0xcd, 0x27, 0xb7, 0xbf, 0xd4, 0x56,
    0x7d, 0x79, 0xe5, 0x22, 0xd6, 0x63, 0x29, 0x3c, 0x1b, 0x69, 0xc5, 0xde,
    0xce, 0x5e, 0x57, 0x6b, 0x43, 0xf8, 0x94, 0x64, 0x7a, 0xe1, 0xad, 0x03,
    0x86, 0x7f, 0x3c, 0x7d, 0xa5, 0xd2, 0x09, 0x02, 0x5e, 0xc6, 0xae, 0x60,
    0x63, 0xf0, 0xc5, 0xc5, 0xe2, 0x1f, 0x48, 0x2c, 0xa4, 0x90, 0xbd, 0x69,
    0x9d, 0x9f, 0xbb, 0xb4, 0x34, 0xfe, 0xf5, 0xc5, 0xd1, 0x72, 0x75, 0xc8,
    0x46, 0xfb, 0xab, 0x7e, 0x28, 0x6e, 0x86, 0xcb, 0x74, 0x07, 0x2a, 0x37,
    0x68, 0xc6, 0xee, 0x8c, 0x93, 0x42, 0xc0, 0x71, 0xc3, 0xce, 0x51, 0x19,
    0x63, 0x38, 0x8a, 0xc3, 0x38, 0x60, 0xa4, 0xe9, 0xc8, 0xb5, 0x7b, 0xbf,
    0xc3, 0x93, 0x25, 0x78, 0xb4, 0x46, 0x40, 0xe7, 0x47, 0x02, 0x22, 0x52,
    0x98, 0xb9, 0xf4, 0xaf, 0x40, 0x41, 0xa3, 0x46, 0x59, 0xb4, 0xf8, 0x9a,
    0xe0, 0xf1, 0x29, 0xf6, 0xc6, 0x9e, 0xd2, 0x33, 0xf0, 0xe0, 0x6d, 0x91,
    0x85, 0x3b, 0xcb, 0x37, 0x1e, 0xd6, 0x43, 0x40, 0xbd, 0x6e, 0xc4, 0x64,
    0x4b, 0x33, 0x9b, 0xe9, 0x5d, 0xf2, 0x4a, 0x1e, 0x71, 0x58, 0xfc, 0x40,
    0x08, 0xd0, 0x3b, 0x74, 0x96, 0x7f, 0xe0, 0x69, 0x09, 0x26, 0x96, 0x2d,
    0xb5, 0x0c, 0xc9, 0x2f, 0xc2, 0x5d, 0x2b, 0x2b, 0xa8, 0x41, 0x0f, 0x8f,
    0x72, 0x3f, 0x11, 0xb9, 0x54, 0x14, 0x9b, 0xd1, 0x89, 0x26, 0x04, 0x10,
    0x86, 0x0f, 0x7f, 0x22, 0x88, 0xfd, 0x35, 0x11, 0xcf, 0x89, 0xfa, 0x88,
    0x1f, 0xab, 0x37, 0x33, 0x87, 0xe8, 0x4d, 0xea, 0x91, 0x60, 0x63, 0x52,
    0x5b, 0x35, 0x3e, 0xbc, 0xf5, 0x5b, 0xcc, 0xaf, 0xa7, 0x4d, 0x00, 0x28,
    0xd0, 0xb7, 0xd4, 0x8d, 0x33, 0x68, 0x87, 0x82, 0x1c, 0x1c, 0x24, 0x51,
    0x47, 0x33, 0xd8, 0xe0, 0x32, 0x6e, 0xa3, 0xc3, 0xeb, 0x77, 0xe1, 0xb9,
    0xe7, 0xc3, 0xc8, 0xa5, 0x8a, 0x7e, 0x23, 0x5e, 0xea, 0x97, 0x78, 0x82,
    0xe7, 0x69, 0x80, 0xf6, 0x25, 0xe7, 0x72, 0x47, 0xe1, 0xc2, 0x43, 0xe8,
    0x98, 0x12, 0x36, 0xc5, 0xef, 0x22, 0x81, 0x86, 0xc3, 0x90, 0x4d, 0xc8,
    0x82, 0x6b, 0x23, 0x95, 0x56, 0x55, 0x2d, 0x6d, 0x5c, 0x85, 0x8a, 0x8f,
    0x35, 0xd5, 0x1c, 0x51, 0x33, 0x86, 0x20, 0x2a, 0x04, 0x54, 0xa1, 0x4d,
    0x02, 0x00, 0x3e, 0xc7, 0xd3, 0x44, 0x14, 0xdd, 0x0a, 0xe3, 0xfe, 0xaa,
    0xca, 0x69, 0x0f, 0xb7, 0x40, 0xdc, 0x56, 0x80, 0xae, 0x6e, 0x7a, 0xef,
    0xdf, 0x5d, 0xf7, 0x22, 0x81, 0x6f, 0x78, 0x8c, 0xd3, 0xbe, 0x2f, 0xab,
    0x28, 0x57, 0xd4, 0x61, 0xe8, 0x25, 0xa0, 0x84, 0x84, 0xb4, 0x55, 0x76,
    0x6b, 0x18, 0x00, 0x50, 0xe0, 0x64, 0x57, 0xb8, 0x03, 0x91, 0xda, 0x10,
    0xd4, 0x50, 0x0a, 0xf9, 0xec, 0x86, 0x3d, 0x9f, 0x8b, 0x7f, 0x44, 0xef,
    0x91, 0xdc, 0xf0, 0x82, 0x8f, 0x34, 0xcb, 0x80, 0x9e, 0x35, 0x81, 0x02,
    0x7e, 0x7d, 0x24, 0x78, 0x1c, 0x4b, 0xb3, 0x32, 0xf1, 0x95, 0x34, 0xa2,
    0x6b, 0xcb, 0x8e, 0xbf, 0x56, 0x14, 0x86, 0xfa, 0x06, 0xa5, 0xd9, 0xd6,
    0xe8, 0x91, 0xd5, 0xf5, 0x24, 0xe4, 0x1a, 0x05, 0xd1, 0x85, 0x3b, 0xb0,
    0xff, 0x76, 0x6e, 0xa1, 0x80, 0x99, 0x8a, 0x02, 0x36, 0x38, 0x3f, 0x31,
    0xf5, 0xf3, 0xb8, 0x95, 0x77, 0x46, 0x24, 0x81, 0x5e, 0x7b, 0x10, 0x8b,
    0x7f, 0xd1, 0xd7, 0xd5, 0xab, 0x84, 0x42, 0x6d, 0x58, 0xcf, 0xe4, 0x60,
    0x2d, 0xcd, 0x17, 0x90, 0xc3, 0x09, 0xbe, 0xca, 0x45, 0xaa, 0xf4, 0x8d,
    0x74, 0x8c, 0xaa, 0xb1, 0x08, 0x93, 0xa3, 0x6c, 0x11, 0x91, 0x88, 0x37,
    0xd0, 0xeb, 0x0e, 0xba, 0x3f, 0x93, 0xeb, 0xa4, 0x9d, 0x25, 0xcd, 0x5a,
    0xb5, 0x75, 0x7b, 0xc8, 0xf9, 0xcb, 0x99, 0xe4, 0x28, 0x73, 0x45, 0xc1,
    0x93, 0xf0, 0x0f, 0xc3, 0x06, 0x48, 0xfb, 0x63, 0x27, 0x90, 0x4d, 0x00,
    0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image11_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xbe, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0x95, 0x92, 0x4b, 0x68, 0x54,
    0x07, 0x14, 0x86, 0xbf, 0x7b, 0x67, 0x26, 0x93, 0xd4, 0x79, 0xaa, 0x49,
    0x34, 0x9a, 0x90, 0x44, 0x05, 0xad, 0xa6, 0x4e, 0x45, 0x71, 0xa1, 0xe8,
    0x42, 0xa9, 0x1b, 0x4b, 0x1b, 0x4b, 0xa8, 0xd0, 0x0a, 0x82, 0x98, 0x85,
    0x0a, 0x16, 0x4a, 0x17, 0xba, 0x93, 0x76, 0x5b, 0x8a, 0xe2, 0xc2, 0xac,
    0x5c, 0x49, 0xeb, 0x0b, 0xbb, 0x2b, 0x8a, 0x4a, 0xc4, 0xd0, 0x68, 0x30,
    0xa6, 0x3e, 0x48, 0xb0, 0x8a, 0x5a, 0xe3, 0x4c, 0xe2, 0xc4, 0xcc, 0xbd,
    0x77, 0xe6, 0xce, 0x7d, 0xce, 0xbd, 0xa7, 0x8b, 0x62, 0x34, 0xa6, 0x8b,
    0xf6, 0x87, 0xb3, 0x39, 0xf0, 0x7f, 0xe7, 0xc0, 0xff, 0x23, 0x22, 0xfc,
    0x97, 0xa1, 0x0f, 0xe5, 0xdf, 0xf6, 0x8a, 0x88, 0xf0, 0xae, 0xbe, 0xb8,
    0xfc, 0x61, 0x46, 0x44, 0xf6, 0x8a, 0xaa, 0xee, 0xf6, 0x82, 0x70, 0xa3,
    0xed, 0xf8, 0x98, 0x9a, 0xf3, 0xc0, 0xac, 0x78, 0xfd, 0xba, 0xef, 0x7c,
    0x3f, 0x91, 0xaa, 0x94, 0x80, 0x50, 0x7a, 0xff, 0x31, 0xce, 0x02, 0x7c,
    0x79, 0x6d, 0x4d, 0xae, 0x63, 0xd1, 0x8a, 0x2b, 0x9f, 0xb6, 0xef, 0x6b,
    0x5c, 0x10, 0x5f, 0x8a, 0x5e, 0x2b, 0x91, 0x77, 0xc6, 0x79, 0x69, 0x8d,
    0x73, 0xe1, 0xde, 0x19, 0x0a, 0x7f, 0x16, 0x2b, 0x66, 0xc5, 0xed, 0x29,
    0x36, 0x55, 0xaf, 0x49, 0xaf, 0xd4, 0x66, 0x01, 0xba, 0x7f, 0x5b, 0x95,
    0x5b, 0xb7, 0x7c, 0xc3, 0xe0, 0x57, 0xcb, 0xbe, 0xad, 0x1f, 0xa8, 0x9d,
    0x67, 0xcc, 0x1c, 0xc1, 0xb0, 0x6c, 0xf4, 0xaa, 0x85, 0x6d, 0x09, 0x4d,
    0xb1, 0x4e, 0x86, 0xc6, 0x6f, 0x33, 0x79, 0xff, 0x35, 0x96, 0xe5, 0x6e,
    0x2a, 0x2f, 0xf1, 0x06, 0xa5, 0x57, 0x44, 0x7d, 0x73, 0x3d, 0x93, 0x59,
    0x78, 0x79, 0x57, 0xc7, 0xa1, 0xfa, 0x5f, 0xfd, 0x1f, 0x99, 0xe0, 0x11,
    0x9e, 0x1b, 0xf0, 0xe4, 0x8e, 0x8e, 0xbc, 0x4a, 0x60, 0x07, 0x16, 0x77,
    0x8b, 0xb7, 0x08, 0x10, 0x64, 0x11, 0xe0, 0x2b, 0xbf, 0x00, 0x11, 0x00,
    0x15, 0x60, 0xdb, 0xd9, 0xce, 0xc3, 0xdb, 0x97, 0xf5, 0x34, 0x5d, 0x34,
    0x4e, 0x50, 0xb2, 0x35, 0x2a, 0xb6, 0x4b, 0xa1, 0xa0, 0x73, 0x6e, 0xc7,
    0x75, 0x7e, 0xde, 0x72, 0x95, 0x20, 0x08, 0xf0, 0xc3, 0x10, 0xd3, 0xab,
    0xa2, 0x34, 0x44, 0xa1, 0x41, 0x6d, 0x8d, 0x8d, 0x45, 0xba, 0x67, 0x00,
    0xa1, 0xaa, 0xec, 0x8e, 0xd6, 0xd5, 0x93, 0xaf, 0xe6, 0xc9, 0x4f, 0x6a,
    0x78, 0xb7, 0xdb, 0x59, 0x67, 0x7e, 0x46, 0xa6, 0x21, 0x03, 0xc0, 0x27,
    0xfe, 0x1e, 0x56, 0x86, 0x39, 0x22, 0xc4, 0x48, 0xc6, 0x52, 0xc4, 0x92,
    0x75, 0x48, 0x28, 0x6b, 0x01, 0xa2, 0x00, 0xbe, 0x84, 0x6b, 0x9e, 0x9a,
    0x8f, 0xa8, 0xd8, 0x36, 0x13, 0xa3, 0x36, 0xa7, 0x77, 0x9d, 0x98, 0x95,
    0xcc, 0x77, 0x9b, 0x8f, 0xf0, 0x7b, 0x7e, 0x80, 0xfd, 0xc3, 0x7b, 0x99,
    0x17, 0x4f, 0x61, 0xc6, 0x1c, 0x02, 0xdf, 0xf8, 0x68, 0xe6, 0x03, 0xd7,
    0xa9, 0x25, 0xf2, 0x66, 0x1e, 0xd3, 0x72, 0x69, 0xee, 0x48, 0x70, 0xb3,
    0x78, 0x95, 0x17, 0xfa, 0x5f, 0x00, 0x18, 0xae, 0xc1, 0x60, 0x61, 0x80,
    0x21, 0xe3, 0x16, 0xd9, 0xfa, 0x85, 0x24, 0xeb, 0xd2, 0xa8, 0xb5, 0x08,
    0x22, 0x3c, 0x7b, 0x0b, 0xb0, 0x82, 0xfc, 0xab, 0xea, 0x34, 0x9e, 0xaf,
    0x32, 0xe5, 0x1a, 0x1c, 0x7d, 0x7c, 0x00, 0xbd, 0xaa, 0x03, 0x30, 0xa6,
    0x3f, 0xe4, 0xeb, 0xa1, 0x1e, 0x2e, 0xbc, 0x3c, 0x4f, 0x7b, 0xba, 0x13,
    0x50, 0x70, 0xa6, 0x1d, 0x78, 0x17, 0xe0, 0x99, 0x72, 0xbd, 0xa4, 0xe9,
    0x64, 0x23, 0x2d, 0x64, 0x94, 0x16, 0xa2, 0x41, 0x92, 0x62, 0x30, 0x49,
    0xd9, 0x2b, 0xf3, 0xdc, 0x7e, 0xc6, 0xca, 0x6c, 0x17, 0xb9, 0xe6, 0xf5,
    0x24, 0x62, 0x49, 0x5e, 0x4f, 0x4d, 0x53, 0xd1, 0x4c, 0x10, 0x2e, 0xcd,
    0xf4, 0xa0, 0xfd, 0x87, 0xc6, 0x8f, 0xe7, 0x37, 0x2e, 0xb8, 0xdb, 0xb5,
    0x7e, 0x2d, 0x2d, 0x89, 0x56, 0xbc, 0xd0, 0xc3, 0x74, 0x4c, 0x54, 0x25,
    0x42, 0x2a, 0x9e, 0x21, 0x19, 0x4b, 0x52, 0x76, 0x4d, 0x86, 0x9f, 0x0f,
    0x33, 0x32, 0x30, 0x82, 0xa6, 0x69, 0xc7, 0xe5, 0x94, 0x7c, 0x33, 0xab,
    0x48, 0x6d, 0xc7, 0x1a, 0x4f, 0x2e, 0xe9, 0x68, 0x3b, 0xd8, 0xb5, 0x3a,
    0x47, 0x6b, 0xba, 0x8d, 0x78, 0x24, 0x0e, 0x8a, 0x82, 0x1f, 0xf8, 0x14,
    0xca, 0x05, 0x1e, 0x3c, 0x79, 0xc8, 0xe8, 0x1f, 0xa3, 0x68, 0x25, 0xed,
    0x5e, 0x18, 0x86, 0x5b, 0xa5, 0x4f, 0x8c, 0x39, 0x55, 0x6e, 0x3a, 0x9a,
    0x3d, 0x99, 0xcd, 0x64, 0x0f, 0x36, 0x2f, 0x5d, 0x4c, 0x2a, 0x95, 0x46,
    0x04, 0xb4, 0xb2, 0xce, 0xc4, 0x8b, 0x02, 0xc5, 0xe2, 0x14, 0xb6, 0x6d,
    0xf7, 0x8b, 0xc8, 0xe7, 0x6f, 0xcc, 0x73, 0x00, 0x00, 0xd1, 0x03, 0xea,
    0xd6, 0xc4, 0x07, 0x89, 0xfd, 0x75, 0xd1, 0xf8, 0xce, 0x20, 0x0c, 0xd3,
    0x96, 0x63, 0x19, 0x8e, 0xeb, 0xf4, 0x03, 0x3f, 0x49, 0x9f, 0xdc, 0xe0,
    0x3d, 0xcd, 0x01, 0xfc, 0x5f, 0xfd, 0x0d, 0x53, 0x24, 0x9c, 0x3b, 0x0c,
    0x56, 0xcd, 0xe2, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae,
    0x42, 0x60, 0x82
};

static const unsigned char image12_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x20,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x73, 0x7a, 0x7a, 0xf4, 0x00, 0x00, 0x08,
    0x48, 0x49, 0x44, 0x41, 0x54, 0x58, 0x85, 0xc5, 0x97, 0x5b, 0x8c, 0x5d,
    0x55, 0x19, 0x80, 0xbf, 0xb5, 0xf7, 0x3e, 0xf7, 0x73, 0x66, 0xce, 0x99,
    0xe9, 0xb4, 0xe3, 0x74, 0x5a, 0xe8, 0xbd, 0x34, 0x34, 0xa5, 0xa5, 0x88,
    0x5c, 0x9a, 0x26, 0x1a, 0xd4, 0x50, 0x2e, 0x62, 0xb8, 0x44, 0xac, 0x9a,
    0xa8, 0x11, 0x83, 0xca, 0x4d, 0x1f, 0x10, 0x09, 0x84, 0x10, 0xb0, 0x46,
    0x05, 0x45, 0x13, 0xa1, 0x81, 0x18, 0x05, 0x85, 0x88, 0x82, 0x10, 0xd0,
    0x62, 0x44, 0x8b, 0x40, 0x91, 0x8b, 0x48, 0x0b, 0x6d, 0xe9, 0x74, 0x7a,
    0x99, 0xc6, 0x4e, 0x3b, 0xd3, 0xce, 0xe5, 0xcc, 0x39, 0x67, 0xdf, 0xd6,
    0xe5, 0xf7, 0x61, 0xa0, 0x58, 0x07, 0x6b, 0x8d, 0x1a, 0xd6, 0x7a, 0xd8,
    0x2f, 0x6b, 0xaf, 0xef, 0xdb, 0xff, 0xfa, 0xf7, 0xbf, 0xd6, 0x52, 0x22,
    0xc2, 0x7b, 0xd9, 0xbc, 0xf7, 0x94, 0x0e, 0x04, 0xff, 0xc9, 0xe0, 0x0b,
    0x1f, 0x5f, 0x5c, 0x51, 0x22, 0xa7, 0xc7, 0xa9, 0x39, 0x4f, 0x6b, 0x77,
    0xa6, 0xb5, 0x6e, 0xa9, 0x31, 0x2e, 0x6f, 0x8c, 0x4b, 0x8d, 0x91, 0x9d,
    0xd6, 0xc9, 0x9f, 0xb4, 0xb8, 0xc7, 0x1a, 0xcd, 0xe4, 0xa5, 0x81, 0xeb,
    0xc7, 0xc7, 0x8e, 0x67, 0x4e, 0x75, 0x3c, 0x4b, 0x70, 0xc1, 0x13, 0x2b,
    0x8b, 0xf8, 0x63, 0x5f, 0xb0, 0x4e, 0x7f, 0x1c, 0xcf, 0x5f, 0xe5, 0x67,
    0x33, 0x88, 0xaf, 0xb0, 0x08, 0xda, 0x58, 0xe2, 0xd8, 0x10, 0x35, 0x13,
    0x74, 0xc3, 0xe1, 0x42, 0x25, 0xa9, 0x71, 0x2f, 0x5b, 0xa3, 0x7f, 0x65,
    0x73, 0x6a, 0xfd, 0x9e, 0x6b, 0xc6, 0xc6, 0xff, 0x2b, 0x81, 0xb5, 0x1b,
    0x97, 0x5d, 0x1c, 0xba, 0xc6, 0xed, 0xa5, 0x62, 0x65, 0xc1, 0xdc, 0x69,
    0x4b, 0x59, 0xd6, 0xb9, 0x8a, 0x39, 0xc5, 0xa5, 0x54, 0x73, 0xd3, 0x09,
    0xc8, 0x32, 0x2e, 0x23, 0xec, 0x6c, 0x6e, 0xe5, 0x95, 0x43, 0x9b, 0x78,
    0xf9, 0xc0, 0x73, 0xec, 0x1f, 0xde, 0x8f, 0x1c, 0xf2, 0x49, 0xeb, 0x06,
    0xad, 0xdd, 0x4e, 0xed, 0xf4, 0x35, 0x07, 0x6e, 0x6c, 0xfd, 0x46, 0xa1,
    0x94, 0x30, 0x15, 0x76, 0x4c, 0x81, 0x4b, 0xfe, 0xb8, 0xe0, 0xb6, 0x20,
    0xaf, 0x6e, 0x58, 0xde, 0x73, 0x36, 0x17, 0xcc, 0xbc, 0x92, 0xc5, 0xc1,
    0x4a, 0x9a, 0xb4, 0xd8, 0xa1, 0xff, 0xc2, 0x60, 0xba, 0x97, 0xba, 0x1e,
    0x23, 0xb5, 0x86, 0x8a, 0xdf, 0x41, 0x6f, 0x61, 0x3e, 0x1a, 0xcd, 0xd3,
    0x07, 0x9e, 0xe4, 0xd1, 0xfe, 0x87, 0x68, 0x0c, 0x85, 0xb8, 0x41, 0x41,
    0x47, 0x0e, 0x2d, 0xee, 0xda, 0x43, 0x37, 0x37, 0xbf, 0x77, 0xdc, 0x11,
    0xb8, 0x85, 0x5b, 0xbc, 0xcd, 0x4f, 0xdf, 0x7f, 0x47, 0xa9, 0x5c, 0xb8,
    0xfa, 0xb2, 0xc5, 0x5f, 0xe6, 0xbc, 0xf6, 0x2b, 0x68, 0x32, 0xc1, 0x33,
    0xe9, 0x83, 0x6c, 0x89, 0x9e, 0x63, 0x38, 0x39, 0xc8, 0x44, 0xd2, 0xa0,
    0x99, 0xb4, 0x88, 0x53, 0x83, 0x33, 0x3e, 0xb8, 0x0c, 0x5d, 0xc1, 0x6c,
    0x56, 0xcf, 0x58, 0x43, 0x68, 0x42, 0xd6, 0x6f, 0xfb, 0x01, 0x43, 0x87,
    0x87, 0x91, 0x7d, 0x1e, 0xb6, 0x61, 0xb0, 0x22, 0xd7, 0x8d, 0xdc, 0x1a,
    0xde, 0x79, 0x5c, 0x02, 0x17, 0x6d, 0x98, 0x77, 0x7b, 0xae, 0x9c, 0xfd,
    0xfa, 0x97, 0x96, 0xdf, 0xce, 0xaa, 0xd2, 0x45, 0xbc, 0xc1, 0x46, 0x9e,
    0x36, 0x3f, 0x66, 0x38, 0x3d, 0x80, 0xd3, 0x3e, 0x49, 0x6a, 0xd1, 0xda,
    0xa1, 0x9d, 0x21, 0x4e, 0x0d, 0xad, 0x38, 0xa6, 0x15, 0x27, 0x34, 0xe2,
    0x90, 0x7a, 0xd4, 0x64, 0x59, 0xed, 0x0c, 0x4e, 0xa8, 0x2c, 0xe0, 0xe1,
    0xbe, 0x07, 0x19, 0x1b, 0xaf, 0xc3, 0x6e, 0x87, 0x89, 0x9c, 0x4d, 0x9d,
    0xac, 0x69, 0xae, 0x8b, 0x9f, 0x3a, 0xa6, 0xc0, 0x05, 0x4f, 0x2c, 0xfa,
    0x98, 0x64, 0xd3, 0x47, 0xd7, 0x9e, 0x7a, 0x35, 0x97, 0x75, 0x5e, 0xc3,
    0x53, 0xe6, 0x5e, 0x5e, 0xe1, 0x31, 0x94, 0xf3, 0x30, 0xda, 0x27, 0xd1,
    0x9a, 0xd4, 0x1a, 0x92, 0xd4, 0x30, 0x34, 0x32, 0xca, 0x44, 0x14, 0x12,
    0x64, 0x7d, 0x90, 0x80, 0x28, 0x4e, 0x69, 0xa5, 0x29, 0xc3, 0xcd, 0x11,
    0x66, 0x15, 0xe6, 0x51, 0xcb, 0x4d, 0x67, 0xd3, 0x81, 0xe7, 0x31, 0x87,
    0x0d, 0x6e, 0xc0, 0x61, 0xac, 0xf4, 0x35, 0x49, 0x56, 0xca, 0xb7, 0xa4,
    0xf1, 0x36, 0xef, 0xa8, 0x3a, 0x70, 0xce, 0xc3, 0xf3, 0xda, 0x43, 0xdd,
    0xfa, 0xee, 0x49, 0x3d, 0x2b, 0x38, 0xbf, 0xf3, 0x8b, 0xfc, 0x3e, 0xfd,
    0x39, 0x1b, 0xe3, 0x87, 0xb0, 0xa9, 0x87, 0xd5, 0x3e, 0xc6, 0x5a, 0x04,
    0xc1, 0x68, 0xcb, 0x1f, 0x36, 0xbc, 0xc1, 0xc0, 0x33, 0x42, 0xf7, 0xc0,
    0x0a, 0xda, 0x0f, 0xce, 0xc5, 0x39, 0xc1, 0x29, 0x41, 0x44, 0x28, 0x79,
    0x65, 0xf6, 0x4e, 0xec, 0x61, 0xfb, 0xc8, 0x56, 0x72, 0x2a, 0x8f, 0xa9,
    0x08, 0xb6, 0x4d, 0x10, 0xeb, 0x16, 0x16, 0xd2, 0xcc, 0xe7, 0xfe, 0x91,
    0x79, 0x94, 0x80, 0xc3, 0x7e, 0x2a, 0x9b, 0xcf, 0xcd, 0x3d, 0x7f, 0xde,
    0xe7, 0xf9, 0x9b, 0xed, 0xe3, 0xa9, 0xc6, 0x4f, 0x40, 0x67, 0xd1, 0x5a,
    0x48, 0xb4, 0x46, 0x1b, 0x03, 0x1e, 0xf4, 0xf5, 0xef, 0x67, 0x56, 0xeb,
    0x14, 0x7e, 0xfb, 0xe9, 0x8d, 0xdc, 0x7b, 0xe1, 0x03, 0xac, 0x5f, 0xfd,
    0x0b, 0xce, 0xed, 0xbc, 0x94, 0xd0, 0x34, 0x71, 0x22, 0x38, 0x04, 0x1f,
    0x9f, 0xf1, 0x78, 0x9c, 0x28, 0x8d, 0xf0, 0x3c, 0x85, 0x54, 0x26, 0x69,
    0xce, 0xd9, 0xcf, 0xa8, 0xab, 0x54, 0xdb, 0x14, 0x81, 0x8f, 0xdc, 0xdf,
    0x5d, 0x4a, 0x53, 0xbd, 0x76, 0xf6, 0xf4, 0x85, 0x2c, 0x2c, 0x2c, 0xe7,
    0x91, 0xb1, 0x1f, 0xd1, 0xd2, 0x21, 0xda, 0x08, 0xa9, 0x35, 0x58, 0x1c,
    0x91, 0x49, 0x68, 0xe9, 0x16, 0xfd, 0xfb, 0xf7, 0x71, 0xf9, 0xf2, 0xb5,
    0xd4, 0x2a, 0x6d, 0xf8, 0x19, 0x45, 0x31, 0x9f, 0xa7, 0x92, 0x6d, 0x47,
    0x8b, 0xc1, 0xa0, 0xb1, 0x38, 0x9c, 0x08, 0x1e, 0x1e, 0xa0, 0xf0, 0x25,
    0x40, 0x95, 0x3c, 0x54, 0xd6, 0x43, 0xc4, 0x5b, 0x16, 0x24, 0x7c, 0xe0,
    0x6d, 0xee, 0x91, 0x4a, 0x18, 0xbb, 0xec, 0x59, 0x12, 0x98, 0xd3, 0x97,
    0xcd, 0x38, 0x9b, 0xdd, 0xe9, 0x36, 0x76, 0x34, 0x5f, 0x23, 0xe7, 0x67,
    0x49, 0xc5, 0x80, 0x16, 0x5e, 0x78, 0x61, 0x07, 0xa6, 0x91, 0xa1, 0xbb,
    0xbd, 0x0b, 0xef, 0x40, 0x07, 0x73, 0x4e, 0x3b, 0x01, 0x80, 0x44, 0x12,
    0x72, 0x2a, 0xc7, 0x96, 0x5d, 0xdb, 0x18, 0x78, 0xfd, 0x30, 0x6d, 0x85,
    0x2a, 0x71, 0x39, 0x24, 0xf0, 0xf3, 0x78, 0xe2, 0x93, 0xf5, 0x32, 0x88,
    0x28, 0x5c, 0x16, 0x74, 0x5e, 0x43, 0xdd, 0x28, 0x03, 0x97, 0x03, 0xbf,
    0x3b, 0x4a, 0x20, 0x4d, 0xdd, 0x47, 0x83, 0xb2, 0x47, 0x6f, 0x65, 0x3e,
    0x5b, 0x26, 0x5e, 0xa0, 0x91, 0x34, 0xf0, 0x73, 0x9d, 0x64, 0x73, 0xc2,
    0xab, 0xaf, 0xec, 0xa2, 0xba, 0x6f, 0x09, 0x37, 0xad, 0xb9, 0x89, 0xae,
    0xb6, 0x2e, 0xcc, 0x99, 0x9a, 0x9e, 0x5a, 0x37, 0x91, 0x44, 0x18, 0x31,
    0x38, 0x1c, 0x9f, 0x38, 0xf1, 0xb3, 0xac, 0xae, 0x9e, 0x4b, 0x5b, 0xa6,
    0xc2, 0xab, 0xe9, 0x9f, 0xf9, 0x4e, 0xdf, 0x3a, 0x50, 0x19, 0xf2, 0x5e,
    0x1e, 0xa5, 0x02, 0x9c, 0x08, 0x36, 0xe7, 0x26, 0x4b, 0x91, 0xe2, 0xe4,
    0x29, 0x11, 0xb0, 0x56, 0x56, 0xf9, 0xbe, 0x4f, 0x29, 0xdb, 0xce, 0x9e,
    0xb1, 0x3e, 0x70, 0x19, 0x12, 0xad, 0xb1, 0xa1, 0x65, 0x60, 0xef, 0x30,
    0xf7, 0x9e, 0xb3, 0x9e, 0x55, 0x0b, 0xcf, 0xc2, 0xbd, 0xd5, 0x43, 0x69,
    0x11, 0x4a, 0x0b, 0x50, 0x24, 0x92, 0x70, 0x72, 0xef, 0x52, 0x4e, 0xed,
    0x5d, 0x09, 0xc0, 0x0a, 0xb7, 0x82, 0xc7, 0x07, 0x1f, 0x63, 0xfb, 0xf8,
    0x0e, 0x8a, 0xd9, 0x12, 0xbe, 0x97, 0xc1, 0x88, 0x25, 0x0d, 0xd2, 0x49,
    0x01, 0xc7, 0xf2, 0x29, 0x02, 0xc6, 0xda, 0x93, 0x32, 0x2a, 0xa0, 0xe1,
    0xea, 0xec, 0x6a, 0xf4, 0xe1, 0x94, 0x47, 0x82, 0xa1, 0x1e, 0x45, 0xcc,
    0x2e, 0x2d, 0x64, 0xde, 0xf4, 0x79, 0x58, 0x0c, 0x13, 0x6e, 0xe2, 0xc8,
    0x57, 0xcb, 0x5b, 0x5d, 0xa1, 0xa8, 0xdb, 0x71, 0x3c, 0x7c, 0x2a, 0x7e,
    0x85, 0xc1, 0x70, 0x3f, 0xe3, 0x69, 0x9d, 0x62, 0x50, 0xa2, 0x9c, 0xad,
    0xe0, 0x29, 0x9f, 0xd0, 0x44, 0x78, 0xe2, 0x23, 0x4e, 0x8e, 0xca, 0xbd,
    0x77, 0x04, 0x8c, 0x94, 0xb4, 0x75, 0x68, 0xd1, 0x34, 0xd3, 0x16, 0xbe,
    0xf2, 0x30, 0x9e, 0xc3, 0xe0, 0xe8, 0x5d, 0xdc, 0x8e, 0xce, 0x87, 0xf8,
    0x04, 0x94, 0xbc, 0x36, 0xea, 0x8c, 0x12, 0x9b, 0x18, 0x00, 0x41, 0xc8,
    0xa8, 0x0c, 0x45, 0xbf, 0x44, 0x40, 0x40, 0x8e, 0x1c, 0xa3, 0xe9, 0x08,
    0x23, 0xc9, 0x28, 0x9d, 0xf9, 0x2e, 0x2a, 0xd9, 0x76, 0xac, 0x58, 0x02,
    0x2f, 0x83, 0x68, 0x98, 0xe4, 0xd3, 0x9a, 0x22, 0xe0, 0x8c, 0x38, 0x93,
    0x3a, 0x6f, 0x38, 0x1c, 0xc2, 0x58, 0xc1, 0xe1, 0x50, 0x0a, 0x50, 0x1e,
    0xa3, 0xc1, 0x41, 0xd6, 0xed, 0xfb, 0x2a, 0xbd, 0xc5, 0x39, 0xec, 0xdf,
    0x3d, 0xca, 0x9a, 0x59, 0x17, 0x73, 0xc6, 0xc2, 0x33, 0x88, 0x4c, 0x44,
    0xd6, 0xcb, 0xb1, 0x37, 0xdc, 0xcd, 0x93, 0xfb, 0x7e, 0x8d, 0xd8, 0xc9,
    0x8c, 0x7f, 0xfe, 0xe0, 0x26, 0x72, 0x5e, 0x9e, 0x69, 0x85, 0x2e, 0xda,
    0xf3, 0x6d, 0x34, 0x92, 0xe6, 0x24, 0xa3, 0xe5, 0x40, 0x04, 0x84, 0xed,
    0x53, 0x73, 0xc0, 0xc9, 0x5f, 0x6d, 0xc4, 0xa9, 0xdb, 0x0e, 0x6f, 0x21,
    0xa7, 0xca, 0x24, 0x36, 0xc4, 0x89, 0xc3, 0x89, 0x41, 0x80, 0x1d, 0xe1,
    0x9b, 0xbc, 0x3e, 0xb1, 0x99, 0x3d, 0x9b, 0x47, 0xf8, 0x60, 0xf7, 0x79,
    0x68, 0xa5, 0x49, 0x49, 0x28, 0xfa, 0x05, 0xfa, 0x1b, 0x7d, 0x7c, 0xfb,
    0xb5, 0x3b, 0x29, 0xa8, 0x00, 0x11, 0x8f, 0x6a, 0xb6, 0x83, 0x05, 0xb5,
    0xc5, 0x74, 0x15, 0xa7, 0x93, 0xf1, 0xb2, 0x34, 0xd2, 0x16, 0x26, 0x32,
    0x98, 0xc8, 0x20, 0x22, 0xa0, 0x78, 0x76, 0x4a, 0x1d, 0xb0, 0xd6, 0xbd,
    0x61, 0x9a, 0x42, 0xdf, 0xe1, 0xed, 0xb4, 0x65, 0x3a, 0xc8, 0x48, 0x81,
    0x80, 0x02, 0xe2, 0x02, 0x12, 0x6d, 0xb1, 0xc6, 0xc3, 0x33, 0x59, 0xda,
    0x99, 0xc6, 0x92, 0x59, 0x4b, 0x68, 0xe8, 0x06, 0xa9, 0xa4, 0x44, 0x12,
    0x32, 0x14, 0x1e, 0x24, 0x87, 0x47, 0x25, 0xa8, 0xd1, 0x53, 0x9c, 0xc5,
    0xfc, 0xea, 0x42, 0x7a, 0xcb, 0xbd, 0x74, 0x16, 0xa6, 0x11, 0xa8, 0x80,
    0x44, 0x12, 0xe2, 0x91, 0x98, 0x34, 0x4c, 0x41, 0x01, 0x8a, 0x0d, 0x53,
    0x04, 0x8c, 0xb3, 0x3f, 0xb3, 0x91, 0x95, 0xe6, 0x78, 0x48, 0xa8, 0x13,
    0x2a, 0x41, 0x8d, 0xb6, 0xa0, 0x93, 0x92, 0x5f, 0x25, 0x4b, 0x71, 0xf2,
    0xaf, 0x88, 0x85, 0x72, 0x6f, 0x0e, 0xb2, 0x42, 0xe0, 0xfb, 0x28, 0x5f,
    0x61, 0x95, 0x63, 0xe7, 0x58, 0x3f, 0xd5, 0xec, 0x34, 0xba, 0x4b, 0x3d,
    0xcc, 0xa9, 0xce, 0x65, 0x5e, 0x6d, 0x3e, 0x3d, 0x95, 0x99, 0xe4, 0x82,
    0x1c, 0xa1, 0x0b, 0xa9, 0x4f, 0xd4, 0x69, 0x1d, 0x68, 0x61, 0x8c, 0x01,
    0xe1, 0x45, 0x22, 0x9e, 0x9f, 0xb2, 0x04, 0x75, 0x5d, 0x7f, 0xb1, 0x4a,
    0xd7, 0xe6, 0xe8, 0x40, 0x7c, 0x4a, 0xda, 0xa9, 0x69, 0x2f, 0xd4, 0xc8,
    0x07, 0x05, 0x2a, 0x41, 0x95, 0x82, 0x9a, 0xa0, 0xa1, 0xea, 0x34, 0xa5,
    0x45, 0xda, 0x99, 0x70, 0xc7, 0x96, 0x75, 0xcc, 0xaf, 0x2e, 0xa2, 0x9c,
    0x29, 0x33, 0xd8, 0x18, 0x64, 0xeb, 0xc8, 0x36, 0x96, 0x74, 0x9e, 0x4c,
    0x57, 0x71, 0x3a, 0x33, 0x4a, 0x33, 0x68, 0xcf, 0xd7, 0x10, 0x11, 0x86,
    0x5a, 0x43, 0x1c, 0x8a, 0x0e, 0x31, 0x3a, 0x30, 0x4a, 0x34, 0x1e, 0x21,
    0x4a, 0x00, 0x1e, 0x90, 0x9f, 0xca, 0x91, 0x24, 0x3c, 0x6a, 0x37, 0x9c,
    0x75, 0x6b, 0xed, 0xaa, 0x42, 0xa6, 0xf0, 0xfd, 0x19, 0x0b, 0x7a, 0xe8,
    0x3d, 0x71, 0x36, 0xd3, 0xf3, 0x33, 0x28, 0xfa, 0x25, 0xac, 0x18, 0x5a,
    0xba, 0x45, 0x23, 0x6d, 0x4c, 0x3e, 0xe3, 0x06, 0x0e, 0x21, 0xa3, 0xb2,
    0x64, 0xfd, 0x1c, 0xd3, 0x0a, 0x5d, 0x74, 0xe4, 0x3b, 0xa9, 0xe6, 0xab,
    0x14, 0x32, 0x05, 0x52, 0xab, 0x19, 0x6e, 0x0d, 0xd3, 0x3f, 0xde, 0x4f,
    0xff, 0xce, 0x7e, 0x06, 0xb7, 0x0e, 0xd2, 0x08, 0x1b, 0x38, 0xe7, 0x76,
    0x03, 0x2b, 0xe4, 0x1e, 0xa9, 0x4f, 0x89, 0x00, 0x80, 0x9e, 0xc8, 0xdd,
    0x47, 0x39, 0xb9, 0x72, 0x74, 0xef, 0xc8, 0xa2, 0x42, 0xb1, 0x44, 0xb1,
    0xa7, 0x4c, 0x39, 0xd3, 0x46, 0x35, 0x5b, 0xa3, 0xab, 0xd0, 0x8d, 0x11,
    0x8b, 0xb6, 0x29, 0xd6, 0x59, 0x40, 0xe1, 0x2b, 0x9f, 0xac, 0x9f, 0x23,
    0x1f, 0xe4, 0xc9, 0x78, 0x59, 0x00, 0x9a, 0x69, 0x93, 0xa1, 0xd6, 0x10,
    0x7b, 0xea, 0x7b, 0xd8, 0xbb, 0x6b, 0x2f, 0xc3, 0x6f, 0x0e, 0x13, 0x46,
    0x21, 0xce, 0x39, 0x50, 0x5c, 0x27, 0x77, 0xbf, 0x03, 0x9f, 0x12, 0x01,
    0x80, 0xee, 0x6f, 0x54, 0x3f, 0x14, 0xf8, 0xfe, 0x86, 0x5a, 0xb5, 0x23,
    0xe8, 0x59, 0x3c, 0x8b, 0x59, 0x33, 0x67, 0xd3, 0x53, 0x9c, 0x49, 0x35,
    0x57, 0xa3, 0x10, 0x14, 0x09, 0x3c, 0x1f, 0x85, 0x8f, 0xa7, 0xd4, 0x91,
    0x77, 0x8c, 0xb5, 0xc4, 0x36, 0x66, 0x3c, 0x1e, 0x67, 0x30, 0x1c, 0x64,
    0xe0, 0xd0, 0x00, 0xfb, 0x76, 0xee, 0x63, 0x78, 0xf7, 0x30, 0x13, 0xe1,
    0x04, 0xa9, 0x4d, 0x01, 0xbe, 0x29, 0x77, 0xcb, 0x0d, 0xfc, 0x53, 0x7b,
    0xd7, 0x13, 0xd1, 0xb4, 0xeb, 0x2b, 0x5f, 0x09, 0xfc, 0xe0, 0xae, 0x5a,
    0x7b, 0x07, 0x5d, 0xb3, 0xbb, 0x79, 0x5f, 0x6f, 0x0f, 0x33, 0xaa, 0x33,
    0xe8, 0x2c, 0x74, 0x52, 0x0a, 0xca, 0x64, 0xfd, 0x1c, 0x3e, 0x0a, 0x23,
    0x8e, 0xc4, 0x26, 0x34, 0x74, 0x83, 0xd1, 0x68, 0x94, 0xa1, 0xf1, 0x21,
    0x06, 0x07, 0x07, 0x39, 0xb8, 0xe7, 0x20, 0x63, 0x87, 0xc7, 0x68, 0xc5,
    0x2d, 0x8c, 0x35, 0x88, 0xc8, 0x5d, 0xf4, 0x70, 0xad, 0xdc, 0x2c, 0xee,
    0xb8, 0x04, 0x00, 0xda, 0xbf, 0x56, 0xba, 0x32, 0xf0, 0xfc, 0x1f, 0x96,
    0x72, 0x25, 0x55, 0xed, 0xa8, 0x51, 0xeb, 0xee, 0xa0, 0xbd, 0xa3, 0x46,
    0xa5, 0x5c, 0x21, 0x9f, 0x2f, 0xe0, 0x79, 0x1e, 0xc6, 0x68, 0xc2, 0x28,
    0x62, 0x62, 0x62, 0x82, 0xb1, 0x91, 0x31, 0x46, 0x87, 0x46, 0xa9, 0x8f,
    0xd4, 0x69, 0x86, 0x4d, 0x62, 0x1b, 0xe3, 0xac, 0x03, 0xb8, 0x4d, 0xee,
    0x91, 0x1b, 0xdf, 0x15, 0x72, 0x2c, 0x01, 0x80, 0xf2, 0x55, 0xf9, 0x0f,
    0xe3, 0xa9, 0xbb, 0x82, 0x20, 0x58, 0x54, 0x08, 0x0a, 0x14, 0x4a, 0x45,
    0xf2, 0x85, 0x3c, 0x99, 0x4c, 0x06, 0x94, 0xc2, 0x5a, 0x4b, 0x12, 0xa7,
    0xc4, 0xad, 0x98, 0x28, 0x8e, 0x88, 0xd3, 0x98, 0xd4, 0xa4, 0x18, 0x67,
    0x10, 0x91, 0x9d, 0x28, 0x6e, 0x90, 0xbb, 0xe5, 0x97, 0xff, 0x12, 0xf0,
    0xef, 0x04, 0x00, 0xd4, 0xa5, 0xaa, 0xec, 0x75, 0x72, 0x85, 0xef, 0x05,
    0x97, 0x78, 0xca, 0x7f, 0x7f, 0xc6, 0x0b, 0x94, 0xe7, 0xf9, 0x28, 0xa5,
    0x26, 0xb7, 0x58, 0x6b, 0xd0, 0x4e, 0xe3, 0x9c, 0x9b, 0x4c, 0x4e, 0xe1,
    0x59, 0x14, 0x8f, 0x00, 0xeb, 0xe5, 0x1e, 0x09, 0x8f, 0x39, 0xf9, 0xf1,
    0x08, 0x1c, 0x19, 0xf8, 0x49, 0x55, 0xa3, 0xcc, 0x69, 0x9e, 0xf2, 0x2e,
    0x04, 0x56, 0x03, 0x0b, 0x80, 0xac, 0x20, 0xb1, 0x38, 0xd9, 0x82, 0x62,
    0x13, 0x8a, 0x27, 0xd0, 0xbc, 0x24, 0xf7, 0xbd, 0x73, 0xe8, 0xfc, 0x9f,
    0x09, 0xfc, 0xbf, 0xda, 0x7b, 0x7e, 0x3b, 0xfe, 0x3b, 0x00, 0x99, 0x9f,
    0x8e, 0x66, 0x1f, 0xb0, 0x6c, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e,
    0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image13_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x20,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x73, 0x7a, 0x7a, 0xf4, 0x00, 0x00, 0x08,
    0x28, 0x49, 0x44, 0x41, 0x54, 0x58, 0x85, 0xc5, 0x97, 0x69, 0x8c, 0x5e,
    0x55, 0x19, 0xc7, 0x7f, 0xe7, 0xde, 0xfb, 0xee, 0xef, 0xdb, 0x79, 0xdf,
    0x59, 0xdb, 0xe9, 0x6a, 0xf7, 0x2a, 0xa5, 0x56, 0xaa, 0x20, 0x8a, 0x24,
    0x12, 0xb7, 0xb0, 0x89, 0x11, 0x49, 0x14, 0xf1, 0x03, 0x44, 0x4c, 0x55,
    0x96, 0xc6, 0x0f, 0x88, 0x2c, 0x02, 0x01, 0x34, 0xae, 0x54, 0x13, 0xa0,
    0x91, 0xa0, 0x02, 0x96, 0x88, 0x42, 0x20, 0xa0, 0x85, 0xd0, 0x58, 0x65,
    0x5f, 0x8c, 0xb4, 0x81, 0x16, 0xa6, 0x30, 0xd3, 0x96, 0x76, 0xa6, 0xb3,
    0xbe, 0xfb, 0x5d, 0xcf, 0x39, 0x8f, 0x1f, 0xa6, 0x2c, 0x65, 0xb0, 0xd6,
    0xa8, 0xe1, 0xb9, 0xb9, 0xc9, 0xc9, 0xb9, 0xe7, 0x9e, 0xff, 0x2f, 0xf7,
    0x59, 0xce, 0x73, 0x95, 0x88, 0xf0, 0x5e, 0x9a, 0xf3, 0x9e, 0xaa, 0x03,
    0xde, 0x7f, 0xb2, 0xf8, 0xcc, 0x07, 0x56, 0x96, 0x94, 0xc8, 0xf1, 0x61,
    0xac, 0x4f, 0x4b, 0x12, 0x7b, 0xa2, 0x31, 0x76, 0xb5, 0xd6, 0x36, 0xab,
    0xb5, 0x8d, 0xb5, 0x96, 0xdd, 0xc6, 0xca, 0xdf, 0x12, 0xb1, 0xf7, 0x37,
    0x5b, 0xd1, 0xb3, 0x7b, 0x2f, 0xab, 0x55, 0x8f, 0x66, 0x4f, 0x75, 0x34,
    0x2e, 0x38, 0xe3, 0xc1, 0x75, 0x79, 0xdc, 0xea, 0xd7, 0x8d, 0x4d, 0xbe,
    0x80, 0xe3, 0x9e, 0xe4, 0xa6, 0x53, 0x88, 0xab, 0x30, 0x08, 0x89, 0x36,
    0x84, 0xa1, 0x26, 0x68, 0x45, 0x24, 0x4d, 0x8b, 0xf5, 0x95, 0xc4, 0xda,
    0x3e, 0x67, 0x74, 0xf2, 0x47, 0x93, 0x51, 0x9b, 0x86, 0x2e, 0xa9, 0xd6,
    0xfe, 0x2b, 0x80, 0x73, 0xb7, 0xad, 0xf9, 0xa2, 0x6f, 0x9b, 0x37, 0x14,
    0xf2, 0xa5, 0x65, 0x8b, 0xbb, 0x57, 0xb3, 0xa6, 0xeb, 0x24, 0xde, 0x97,
    0x5f, 0x4d, 0x39, 0xd3, 0x8b, 0x47, 0x9a, 0x9a, 0x4c, 0xb2, 0xbb, 0xf5,
    0x12, 0xcf, 0x8f, 0x3f, 0xc9, 0x73, 0x23, 0x8f, 0x73, 0x60, 0xec, 0x00,
    0x32, 0xee, 0x12, 0xd7, 0x35, 0x49, 0x62, 0x77, 0x27, 0x36, 0xb9, 0x64,
    0xe4, 0x8a, 0xf6, 0x9f, 0x14, 0x4a, 0x09, 0x33, 0xc5, 0x8e, 0x08, 0x70,
    0xf6, 0x5f, 0x96, 0x5d, 0xef, 0x65, 0xd5, 0xe5, 0x6b, 0xfb, 0x3f, 0xce,
    0x19, 0x73, 0xd7, 0xb3, 0xd2, 0x5b, 0x47, 0x8b, 0x36, 0xaf, 0x24, 0x7f,
    0x67, 0x38, 0xde, 0x43, 0x3d, 0xa9, 0x12, 0x1b, 0x4d, 0xc9, 0xed, 0x64,
    0x5e, 0x6e, 0x29, 0x09, 0x09, 0x5b, 0x47, 0x1e, 0xe2, 0xbe, 0x57, 0xef,
    0xa6, 0x39, 0xea, 0x63, 0x87, 0x85, 0x24, 0xb0, 0x24, 0x62, 0x2f, 0x1d,
    0xbf, 0xba, 0xf5, 0xf3, 0xa3, 0xfe, 0x02, 0xd7, 0x70, 0x8d, 0xb3, 0x7d,
    0xeb, 0x1d, 0x3f, 0x2d, 0x14, 0x73, 0x17, 0x9f, 0xb3, 0xf2, 0x5b, 0x9c,
    0xd6, 0x71, 0x21, 0x2d, 0x1a, 0xfc, 0x35, 0xde, 0xcc, 0x8e, 0xe0, 0x71,
    0xc6, 0xa2, 0x83, 0x34, 0xa2, 0x26, 0xad, 0xa8, 0x4d, 0x18, 0x6b, 0xac,
    0x76, 0xc1, 0xa6, 0xe8, 0xf1, 0x16, 0x70, 0x72, 0xdf, 0xa9, 0xf8, 0xda,
    0x67, 0xd3, 0xce, 0x5f, 0x30, 0x3a, 0x31, 0x86, 0xec, 0x73, 0x30, 0x4d,
    0x8d, 0x11, 0xd9, 0x30, 0x79, 0x9d, 0xff, 0xb3, 0xa3, 0x02, 0x38, 0x6b,
    0xcb, 0x92, 0x1b, 0x32, 0xc5, 0xf4, 0x77, 0xbf, 0xb9, 0xf6, 0x06, 0x4e,
    0x2a, 0x9c, 0xc5, 0x8b, 0x6c, 0x63, 0xab, 0xbe, 0x9d, 0xb1, 0x78, 0x04,
    0x9b, 0xb8, 0x44, 0xb1, 0x21, 0x4e, 0x2c, 0x51, 0x1c, 0x13, 0x26, 0x9a,
    0x20, 0x8e, 0xf1, 0xa3, 0x88, 0x66, 0xe8, 0x53, 0x0f, 0x5a, 0xac, 0xa9,
    0x7c, 0x94, 0x85, 0xa5, 0x65, 0xdc, 0x33, 0xb0, 0x99, 0x6a, 0xad, 0x0e,
    0x83, 0x16, 0x1d, 0x58, 0x13, 0x5b, 0x39, 0xb5, 0xf5, 0x83, 0xf0, 0xe1,
    0x23, 0x02, 0x9c, 0xf1, 0xe0, 0x8a, 0xcf, 0x4b, 0x3a, 0xbe, 0xef, 0xdc,
    0xe3, 0x2e, 0xe6, 0x9c, 0xae, 0x4b, 0x78, 0x58, 0xff, 0x8a, 0xe7, 0xb9,
    0x1f, 0x65, 0x1d, 0x74, 0xe2, 0x12, 0x25, 0x09, 0x61, 0x92, 0x10, 0x6b,
    0x43, 0xa4, 0x63, 0xfc, 0x20, 0x99, 0x9e, 0x8b, 0x13, 0x82, 0x28, 0xa6,
    0x1d, 0xc7, 0x8c, 0xb5, 0x26, 0x99, 0x9f, 0x5b, 0x42, 0x25, 0xd3, 0xcb,
    0x93, 0x23, 0x4f, 0xa0, 0x27, 0x34, 0x76, 0xaf, 0x45, 0x1b, 0x19, 0x68,
    0x11, 0xad, 0x93, 0x1f, 0x4a, 0xf3, 0x0d, 0xbd, 0xc3, 0xea, 0xc0, 0xa7,
    0xee, 0x59, 0xd2, 0xe1, 0x27, 0xed, 0x9f, 0xac, 0xea, 0xff, 0x10, 0xa7,
    0x77, 0x7d, 0x83, 0x47, 0xe3, 0xdf, 0xb1, 0x2d, 0xbc, 0x1b, 0x13, 0x3b,
    0x98, 0xc4, 0x45, 0x1b, 0x83, 0xb1, 0x16, 0xd7, 0x53, 0xec, 0x7c, 0xfa,
    0x00, 0xfb, 0x07, 0x27, 0xd1, 0x4e, 0x8c, 0x88, 0x4c, 0xdf, 0x80, 0x88,
    0x50, 0x70, 0x8a, 0xec, 0x69, 0x0c, 0xb1, 0x6b, 0xf2, 0x25, 0x32, 0x2a,
    0x8b, 0x2e, 0x09, 0x66, 0x96, 0x20, 0xc6, 0x2e, 0xcf, 0xc5, 0xa9, 0xf3,
    0xdf, 0xae, 0x79, 0x18, 0x80, 0xc5, 0x7c, 0x35, 0x9d, 0xcd, 0x2c, 0x3e,
    0x7d, 0xc9, 0x05, 0xec, 0x37, 0x03, 0x3c, 0xdc, 0xfc, 0x0d, 0xe8, 0x34,
    0x16, 0x85, 0xc6, 0x60, 0xc4, 0xa0, 0x8d, 0x01, 0x4f, 0x18, 0x19, 0x68,
    0xb2, 0xfc, 0xf5, 0x4f, 0x92, 0xaf, 0xf6, 0xe2, 0xd3, 0x7e, 0x0b, 0x42,
    0xc0, 0x22, 0xb8, 0xb8, 0xd4, 0xc2, 0x1a, 0x41, 0x1c, 0xe0, 0x38, 0x0a,
    0x29, 0x4d, 0xab, 0x59, 0x6b, 0xbe, 0xa6, 0x2e, 0x52, 0xb3, 0x66, 0x00,
    0x7c, 0xe6, 0x8e, 0xd9, 0x85, 0x38, 0x4e, 0xce, 0x5d, 0xd0, 0xbb, 0x9c,
    0xe5, 0xb9, 0xb5, 0xdc, 0x5b, 0xbd, 0x99, 0x76, 0xe2, 0x93, 0xc4, 0x96,
    0xbd, 0x03, 0x53, 0xbc, 0xfc, 0xd2, 0x01, 0x76, 0xbf, 0xb6, 0x9f, 0x89,
    0x7a, 0x95, 0xf1, 0xc9, 0x3a, 0x41, 0x14, 0x70, 0xf2, 0xd2, 0x53, 0xf8,
    0xfe, 0xd2, 0x9b, 0xe9, 0xa9, 0x2e, 0xa6, 0xa6, 0xeb, 0x68, 0x0c, 0xd6,
    0x5a, 0xac, 0x58, 0xac, 0x08, 0x0e, 0x0e, 0xa0, 0x70, 0xc5, 0x43, 0x15,
    0x1c, 0x54, 0xda, 0x41, 0xc4, 0x59, 0xe3, 0x45, 0x9c, 0x30, 0x03, 0x20,
    0xb4, 0xe9, 0x8f, 0x89, 0x23, 0xc7, 0xaf, 0xe9, 0xfb, 0x38, 0x83, 0xf1,
    0x4e, 0x5e, 0x69, 0xbd, 0x80, 0x18, 0x97, 0x28, 0xd1, 0x3c, 0xfb, 0xe8,
    0x20, 0xd9, 0xed, 0xef, 0x27, 0xf7, 0xc2, 0x31, 0x4c, 0x6c, 0xe9, 0x60,
    0xfb, 0xe6, 0x26, 0x41, 0x4d, 0x68, 0x52, 0x65, 0x41, 0x65, 0x21, 0x3f,
    0x5a, 0xf3, 0x6b, 0x4e, 0x74, 0x3e, 0x47, 0xb5, 0x5d, 0x43, 0xdb, 0x69,
    0x37, 0x19, 0xb1, 0x28, 0x71, 0x49, 0x3b, 0x19, 0xd2, 0x4e, 0x16, 0x2f,
    0x9d, 0x82, 0xac, 0x03, 0x22, 0x4a, 0xc3, 0x97, 0xdf, 0xd0, 0x7d, 0xb3,
    0x14, 0xc7, 0xb1, 0xfd, 0xac, 0x57, 0x74, 0x98, 0x57, 0x5a, 0xca, 0x8e,
    0xc6, 0x53, 0x34, 0xa3, 0x26, 0x9e, 0x4a, 0x63, 0x24, 0x21, 0xd4, 0x11,
    0x17, 0x9e, 0xb2, 0x9e, 0x13, 0x17, 0x9f, 0x40, 0x4d, 0xd7, 0x19, 0x1a,
    0x1f, 0x64, 0xb4, 0x71, 0x90, 0x45, 0xbd, 0x8b, 0xf0, 0xf1, 0xe9, 0x98,
    0x35, 0x8b, 0xab, 0x8e, 0xfd, 0x31, 0x9d, 0x3b, 0x7b, 0xd9, 0xf4, 0xfa,
    0x46, 0x12, 0x2b, 0x28, 0x93, 0xc2, 0x75, 0x3c, 0x52, 0x2a, 0x8d, 0x52,
    0x1e, 0x56, 0x04, 0x93, 0xb1, 0xd3, 0xa5, 0x48, 0x71, 0xcc, 0x0c, 0x00,
    0x63, 0xe4, 0x24, 0xd7, 0x75, 0x29, 0xa4, 0x3b, 0x18, 0xaa, 0x0e, 0x80,
    0x4d, 0x11, 0xc6, 0x09, 0x0a, 0x45, 0x26, 0x9d, 0xa5, 0xa5, 0x9b, 0x68,
    0x0c, 0x8e, 0xa7, 0x58, 0x35, 0x67, 0x15, 0xab, 0xe7, 0x1c, 0x4b, 0x48,
    0x80, 0x8f, 0x8f, 0x42, 0x91, 0xca, 0xa4, 0xd8, 0xb0, 0xf6, 0x4a, 0x7a,
    0xf2, 0xfd, 0x5c, 0xb7, 0xfd, 0x4a, 0x02, 0x22, 0x4a, 0x5e, 0x81, 0xbc,
    0x9b, 0xc7, 0x75, 0x52, 0x68, 0x31, 0xc4, 0x5e, 0x3c, 0x0d, 0x60, 0x59,
    0x3b, 0x03, 0x40, 0x1b, 0xb3, 0x2a, 0xa5, 0x3c, 0x9a, 0xb6, 0xce, 0x6b,
    0xcd, 0x01, 0xac, 0x72, 0x08, 0x49, 0x70, 0x50, 0x78, 0x4e, 0x0a, 0xc7,
    0x75, 0xd0, 0x24, 0x04, 0x87, 0xae, 0x77, 0x5a, 0x72, 0xe8, 0xd9, 0x79,
    0x2b, 0xce, 0x67, 0x6e, 0xc7, 0x7c, 0x36, 0x3c, 0x7d, 0x11, 0x89, 0x35,
    0x14, 0xd3, 0x25, 0x1c, 0xe5, 0xe2, 0xeb, 0x00, 0x47, 0x5c, 0xc4, 0xca,
    0x61, 0xae, 0x7f, 0x0b, 0x40, 0x4b, 0x21, 0x31, 0x96, 0x44, 0x12, 0x5a,
    0x71, 0x1b, 0x57, 0x39, 0x38, 0x8e, 0x41, 0xa1, 0x48, 0x67, 0xd2, 0xc4,
    0x26, 0x46, 0x63, 0x29, 0x50, 0x42, 0xa3, 0x01, 0x21, 0x24, 0x38, 0x34,
    0x06, 0x39, 0x14, 0xf9, 0x21, 0x01, 0x93, 0x76, 0x92, 0xb4, 0x93, 0x25,
    0xe5, 0x2a, 0x4a, 0xe9, 0x0e, 0x8c, 0x18, 0x3c, 0x27, 0x85, 0x24, 0x30,
    0xad, 0x4f, 0x7b, 0x06, 0x80, 0xd5, 0x62, 0x75, 0x6c, 0x9d, 0x31, 0x7f,
    0x14, 0x6d, 0x04, 0x8b, 0x45, 0x29, 0x10, 0x65, 0x29, 0x7f, 0xc0, 0x63,
    0x73, 0xfd, 0x26, 0xfe, 0xfc, 0xf2, 0x9d, 0xe4, 0xdc, 0x1c, 0xe5, 0x54,
    0x37, 0xd9, 0xa4, 0xc8, 0xba, 0xf2, 0x27, 0x58, 0xdc, 0xb3, 0x98, 0x98,
    0x98, 0x02, 0x05, 0x42, 0x42, 0xae, 0xd9, 0x71, 0x25, 0xb7, 0xbf, 0x78,
    0x1b, 0xbd, 0xf9, 0xd9, 0xcc, 0x2f, 0x2d, 0xa4, 0x23, 0x3b, 0x8b, 0x66,
    0xd4, 0x9a, 0xd6, 0x68, 0x5b, 0x10, 0x01, 0x61, 0xd7, 0xcc, 0x18, 0xb0,
    0xf2, 0x0f, 0x13, 0x70, 0xdc, 0xce, 0x89, 0x1d, 0x64, 0x54, 0x91, 0xc8,
    0xf8, 0x87, 0xd2, 0xc9, 0x40, 0x46, 0x78, 0x35, 0xde, 0x45, 0x32, 0xa6,
    0x31, 0xd6, 0x20, 0x0a, 0x4c, 0xd5, 0x45, 0xcd, 0xc9, 0xb3, 0xb4, 0x67,
    0x29, 0x39, 0xf2, 0xec, 0x0f, 0xf7, 0x71, 0xed, 0x73, 0x57, 0xf1, 0xc8,
    0x9e, 0x47, 0xe8, 0xcf, 0xcf, 0xa3, 0xbf, 0x38, 0x8f, 0x9e, 0x7c, 0x2f,
    0x29, 0x27, 0x4d, 0x33, 0x6e, 0xa3, 0x03, 0x8d, 0x0e, 0x34, 0x22, 0x02,
    0x8a, 0xc7, 0x66, 0xa4, 0xa1, 0x31, 0xf6, 0x45, 0xdd, 0x12, 0x06, 0x26,
    0x76, 0x31, 0x2b, 0xd5, 0x49, 0x4a, 0x72, 0x78, 0xe4, 0x10, 0xeb, 0x11,
    0x86, 0x06, 0x1d, 0x3b, 0xa0, 0x53, 0x28, 0x9d, 0xc1, 0xc6, 0xd3, 0x87,
    0x4f, 0x3a, 0x95, 0x26, 0x47, 0x81, 0xa7, 0x27, 0x1f, 0xe7, 0x82, 0xad,
    0xe7, 0xb1, 0x6d, 0xdf, 0x36, 0x16, 0x16, 0x17, 0xb3, 0x60, 0xd6, 0x22,
    0xe6, 0x15, 0xe7, 0xd3, 0x95, 0xeb, 0xc6, 0x53, 0x1e, 0x91, 0x44, 0x84,
    0x93, 0x21, 0xb1, 0x1f, 0x83, 0x02, 0x14, 0x5b, 0x66, 0xc6, 0x80, 0x35,
    0x77, 0x39, 0x81, 0x39, 0xaf, 0x55, 0xf3, 0x55, 0x3e, 0x17, 0x51, 0xf2,
    0x2a, 0x58, 0xc0, 0xa7, 0x85, 0x98, 0x06, 0xda, 0x06, 0x68, 0x13, 0x91,
    0x18, 0x43, 0x6c, 0x0c, 0x88, 0xa5, 0x91, 0xad, 0xf2, 0xfb, 0x91, 0xbb,
    0xb8, 0xf1, 0xa9, 0x6b, 0xd1, 0xc6, 0xb2, 0xb4, 0xbc, 0x82, 0xde, 0x7c,
    0x1f, 0x73, 0x4b, 0xf3, 0xe8, 0xce, 0xf5, 0xa0, 0x45, 0x33, 0x11, 0x4e,
    0x50, 0x6f, 0xd4, 0x69, 0x8f, 0xb4, 0xd1, 0x5a, 0x83, 0xf0, 0x0c, 0x21,
    0x4f, 0xcc, 0x00, 0xa8, 0x27, 0xf5, 0x67, 0xca, 0xf4, 0x6c, 0x0f, 0x46,
    0xc2, 0x0f, 0xc6, 0x5d, 0x09, 0x1d, 0xb9, 0x0a, 0x59, 0x2f, 0x47, 0xc9,
    0x2b, 0x93, 0x53, 0x0d, 0x9a, 0xaa, 0x8e, 0x8f, 0x4f, 0x28, 0x21, 0x29,
    0x31, 0xe8, 0xac, 0xe6, 0xa1, 0xe1, 0x07, 0x68, 0x0e, 0xb6, 0xe8, 0xce,
    0xcc, 0xa6, 0x2b, 0xd7, 0x4d, 0x77, 0xbe, 0x87, 0xbe, 0x42, 0x1f, 0x1d,
    0xd9, 0x0a, 0x22, 0xc2, 0x68, 0x7b, 0x94, 0xf1, 0x60, 0x9c, 0xa9, 0xbd,
    0x53, 0x04, 0xb5, 0x00, 0x51, 0x02, 0x70, 0xa7, 0xfc, 0x56, 0x66, 0x06,
    0xe1, 0xe4, 0xd5, 0xd2, 0x98, 0x7f, 0x5d, 0xe5, 0xf6, 0x76, 0xd5, 0xbf,
    0xa9, 0x79, 0xb0, 0x4d, 0xc7, 0x22, 0x43, 0xd9, 0x2d, 0xd0, 0x99, 0x2e,
    0xd0, 0x9d, 0xed, 0xa3, 0x9d, 0xb4, 0x69, 0x46, 0x4d, 0xda, 0xba, 0x4d,
    0xa2, 0x35, 0x56, 0x04, 0x2b, 0xc2, 0x9c, 0xfc, 0x02, 0x2a, 0x99, 0x0a,
    0x1d, 0x99, 0x32, 0xe5, 0x6c, 0x99, 0x5c, 0x2a, 0x47, 0x6c, 0x12, 0xc6,
    0xda, 0x63, 0x1c, 0x68, 0x1d, 0x60, 0x78, 0x68, 0x98, 0xda, 0xbe, 0x1a,
    0x91, 0x89, 0x10, 0x91, 0x41, 0xe0, 0x8e, 0xb7, 0xa7, 0xef, 0x61, 0x4d,
    0x69, 0xd2, 0xc8, 0xdc, 0x46, 0x31, 0x5a, 0x3f, 0xb5, 0x67, 0x72, 0x45,
    0x2e, 0x5f, 0x20, 0xdf, 0x5f, 0xa4, 0x98, 0x9a, 0x45, 0x39, 0x5d, 0xa1,
    0x27, 0x37, 0x1b, 0x2d, 0x86, 0xc4, 0xc4, 0x18, 0x6b, 0x00, 0x85, 0xeb,
    0x78, 0xa4, 0x9d, 0x34, 0x59, 0x2f, 0x4b, 0xca, 0x49, 0x03, 0xd0, 0x8a,
    0x5b, 0x8c, 0xb6, 0x47, 0x19, 0xaa, 0x0f, 0xb1, 0xe7, 0xb5, 0x3d, 0x8c,
    0xbd, 0x3c, 0x86, 0x1f, 0xf8, 0x58, 0x6b, 0x41, 0xb1, 0x41, 0x6e, 0x91,
    0xfa, 0xdb, 0x35, 0x67, 0xf4, 0x03, 0xb3, 0xbf, 0x57, 0x3e, 0xc5, 0x73,
    0xdd, 0x2d, 0x95, 0x72, 0xa7, 0xd7, 0xbf, 0x72, 0x3e, 0xf3, 0xe7, 0x2e,
    0xa0, 0x3f, 0x3f, 0x97, 0x72, 0xa6, 0x42, 0xce, 0xcb, 0xe3, 0x39, 0x2e,
    0x0a, 0x17, 0x47, 0xa9, 0x37, 0xdf, 0xd1, 0xc6, 0x10, 0x9a, 0x90, 0x5a,
    0x58, 0x63, 0xd8, 0x1f, 0x66, 0xef, 0xf8, 0x5e, 0xf6, 0xed, 0xde, 0xc7,
    0xd8, 0xe0, 0x18, 0x0d, 0xbf, 0x41, 0x6c, 0x62, 0x80, 0x1b, 0xe5, 0x16,
    0xb9, 0x9c, 0x77, 0xd8, 0xbb, 0x76, 0x44, 0xdd, 0x97, 0x95, 0xbe, 0xed,
    0xb9, 0xde, 0xc6, 0x4a, 0x47, 0x27, 0x3d, 0x0b, 0x66, 0x33, 0x67, 0x5e,
    0x3f, 0x7d, 0xe5, 0x3e, 0xba, 0x72, 0x5d, 0x14, 0xbc, 0x22, 0x69, 0x37,
    0x83, 0x8b, 0x42, 0x8b, 0x25, 0x32, 0x11, 0xcd, 0xa4, 0xc9, 0x54, 0x30,
    0xc5, 0x68, 0x6d, 0x94, 0xe1, 0xe1, 0x61, 0x0e, 0x0e, 0x1d, 0xa4, 0x3a,
    0x51, 0xa5, 0x1d, 0xb6, 0xd1, 0x46, 0x23, 0x22, 0x1b, 0xe9, 0xe7, 0x52,
    0xb9, 0x5a, 0xec, 0x51, 0x01, 0x00, 0x74, 0x7c, 0xa7, 0xb0, 0xde, 0x73,
    0xdc, 0x5f, 0x16, 0x32, 0x05, 0x55, 0xee, 0xac, 0x50, 0x99, 0xdd, 0x49,
    0x47, 0x67, 0x85, 0x52, 0xb1, 0x44, 0x36, 0x9b, 0xc3, 0x71, 0x1c, 0xb4,
    0x4e, 0xf0, 0x83, 0x80, 0x46, 0xa3, 0x41, 0x75, 0xb2, 0xca, 0xd4, 0xe8,
    0x14, 0xf5, 0xc9, 0x3a, 0x2d, 0xbf, 0x45, 0x68, 0x42, 0xac, 0xb1, 0x00,
    0xd7, 0xcb, 0xad, 0x72, 0xc5, 0xbb, 0x8a, 0x1c, 0x09, 0x00, 0xa0, 0x78,
    0x51, 0xf6, 0xd3, 0x38, 0x6a, 0xa3, 0xe7, 0x79, 0x2b, 0x72, 0x5e, 0x8e,
    0x5c, 0x21, 0x4f, 0x36, 0x97, 0x25, 0x95, 0x4a, 0x81, 0x52, 0x18, 0x63,
    0x88, 0xc2, 0x98, 0xb0, 0x1d, 0x12, 0x84, 0x01, 0x61, 0x1c, 0x12, 0xeb,
    0x18, 0x6d, 0x35, 0x22, 0xb2, 0x1b, 0xc5, 0xe5, 0x72, 0x8b, 0xfc, 0xe1,
    0x5f, 0x0a, 0xfc, 0x3b, 0x00, 0x00, 0xf5, 0x25, 0x55, 0x74, 0xba, 0xb8,
    0xd0, 0x75, 0xbc, 0xb3, 0x1d, 0xe5, 0x7e, 0x24, 0xe5, 0x78, 0xca, 0x71,
    0x5c, 0x94, 0x52, 0xd3, 0x47, 0xac, 0xd1, 0x24, 0x36, 0xc1, 0x5a, 0x3b,
    0x1d, 0x9c, 0xc2, 0x63, 0x28, 0xee, 0x05, 0x36, 0xc9, 0xad, 0xe2, 0x1f,
    0x71, 0xf3, 0xa3, 0x01, 0x78, 0x73, 0xe1, 0x57, 0x54, 0x85, 0x22, 0x1f,
    0x76, 0x94, 0x73, 0x26, 0x70, 0x32, 0xb0, 0x0c, 0x48, 0x0b, 0x12, 0x8a,
    0x95, 0x1d, 0x28, 0x9e, 0x44, 0xf1, 0x20, 0x09, 0xcf, 0xca, 0x6d, 0x6f,
    0x35, 0x9d, 0xff, 0x33, 0x80, 0xff, 0x97, 0xbd, 0xe7, 0x7f, 0xc7, 0xff,
    0x04, 0xfe, 0x5e, 0xb1, 0xaf, 0x80, 0xc3, 0x03, 0x51, 0x00, 0x00, 0x00,
    0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image14_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xb7, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x92, 0x4d, 0x68, 0x14,
    0x77, 0x1c, 0x86, 0x9f, 0xff, 0xec, 0xcc, 0x6c, 0x76, 0x77, 0xb2, 0xc9,
    0x26, 0x7e, 0xc4, 0x5a, 0x1b, 0x8c, 0xf1, 0x03, 0x4c, 0x88, 0x98, 0xa2,
    0x85, 0xd6, 0x8a, 0xf6, 0xd2, 0x4a, 0x6f, 0x4a, 0x0e, 0x5e, 0x4c, 0x15,
    0xa9, 0xc4, 0x8f, 0x8b, 0x8a, 0x82, 0x68, 0xf0, 0xa2, 0xf8, 0x41, 0xbd,
    0x14, 0xb4, 0x2d, 0x2d, 0xe4, 0xd0, 0x5a, 0xb6, 0x14, 0x0b, 0x6d, 0xa1,
    0x36, 0xd5, 0x22, 0xa2, 0xd1, 0x7e, 0x24, 0x58, 0x13, 0xb2, 0xd5, 0xc4,
    0x98, 0xb8, 0xae, 0x1b, 0x92, 0x35, 0xab, 0x93, 0x99, 0x9d, 0x99, 0xcd,
    0xcc, 0xbf, 0x87, 0x22, 0x26, 0x26, 0xd2, 0x43, 0xdf, 0xdb, 0xef, 0xf2,
    0xf0, 0xf0, 0xfe, 0x5e, 0x21, 0xa5, 0xe4, 0xff, 0x44, 0x9d, 0x7c, 0x88,
    0x5d, 0x17, 0x2a, 0x41, 0xf9, 0x50, 0xd7, 0xc4, 0x56, 0xe4, 0xc4, 0x22,
    0xdf, 0x1a, 0xeb, 0xf7, 0x0b, 0xe6, 0xb7, 0x78, 0xc5, 0x33, 0x32, 0xb9,
    0x3f, 0x3b, 0x13, 0x40, 0x3c, 0x33, 0x10, 0x07, 0x7e, 0x5d, 0x1a, 0x8d,
    0x95, 0xb4, 0xad, 0x5f, 0x54, 0xbe, 0xba, 0xf1, 0x95, 0x32, 0x8a, 0x41,
    0x88, 0xee, 0x4c, 0x9e, 0x8e, 0xd4, 0x5d, 0x72, 0xe9, 0xbe, 0x5b, 0x81,
    0xe7, 0x7c, 0x20, 0xcf, 0x1f, 0xec, 0x9a, 0x11, 0x20, 0x0e, 0x5d, 0x9a,
    0xab, 0x87, 0x8d, 0xf6, 0xc3, 0xeb, 0x6b, 0xeb, 0x77, 0xaf, 0xaa, 0xe4,
    0x5a, 0x1a, 0xae, 0xa5, 0x6d, 0x06, 0xc6, 0x8b, 0x8c, 0x79, 0x3e, 0x5d,
    0x3d, 0x9d, 0x8c, 0xfc, 0x7d, 0x2b, 0x1b, 0x38, 0xe3, 0xab, 0x65, 0xb2,
    0x75, 0x68, 0x32, 0x40, 0x01, 0xc0, 0x72, 0x8f, 0xbc, 0xbd, 0x30, 0x51,
    0xbf, 0x7d, 0x65, 0x25, 0xdf, 0xf4, 0x4e, 0xf0, 0x5d, 0xca, 0xa4, 0x77,
    0xc4, 0x62, 0xf0, 0xb1, 0x49, 0xda, 0xb2, 0x31, 0x6a, 0x97, 0x63, 0x54,
    0xcd, 0xab, 0x0a, 0x29, 0xec, 0x7f, 0xd1, 0xe0, 0x5f, 0x80, 0x22, 0xb7,
    0xac, 0xad, 0x2e, 0xe7, 0xe2, 0xbd, 0x22, 0xd7, 0xd3, 0x36, 0x01, 0x3e,
    0x01, 0x12, 0x5f, 0x4a, 0x94, 0x90, 0xa4, 0xb4, 0x4c, 0x27, 0xbe, 0xe0,
    0x35, 0x42, 0x8a, 0xba, 0x46, 0xd4, 0x35, 0xe9, 0xd3, 0x4b, 0x2c, 0x16,
    0x62, 0x85, 0x22, 0xfc, 0x31, 0xec, 0x90, 0x77, 0x1c, 0x8a, 0x7e, 0x40,
    0xde, 0xf3, 0x29, 0xc8, 0x80, 0xb0, 0x11, 0x26, 0x1a, 0x0f, 0x63, 0xea,
    0x2a, 0x5e, 0x10, 0xf6, 0xb1, 0x96, 0x2b, 0xd3, 0x0d, 0xec, 0xfc, 0x5f,
    0x57, 0xfb, 0x33, 0xd8, 0x21, 0x8d, 0xbc, 0x08, 0x78, 0x22, 0x02, 0x5c,
    0x1d, 0x22, 0x95, 0x25, 0x54, 0xcc, 0x89, 0x21, 0x34, 0x95, 0xa7, 0x8f,
    0xb2, 0xe0, 0x5a, 0xa3, 0x72, 0xa0, 0xd5, 0x99, 0x0e, 0x98, 0xb0, 0x8e,
    0xdd, 0xec, 0xe9, 0x61, 0x20, 0x37, 0x8a, 0x4c, 0x18, 0xa8, 0x73, 0x4a,
    0x89, 0xbf, 0x5a, 0x4e, 0xc5, 0xfc, 0x04, 0x52, 0x2f, 0x21, 0xdd, 0x7b,
    0x97, 0x91, 0xdb, 0x43, 0x6c, 0x8e, 0xb4, 0x35, 0x5c, 0xd8, 0x2b, 0xf6,
    0xcd, 0xfc, 0xc6, 0x2d, 0x67, 0x3e, 0x35, 0x66, 0xcd, 0xde, 0x3e, 0xbf,
    0xae, 0x1e, 0x63, 0x5e, 0x15, 0x7a, 0x49, 0x98, 0x09, 0xc7, 0xe6, 0x61,
    0xea, 0x3e, 0x99, 0x2b, 0x5d, 0xbc, 0xd7, 0x90, 0xe1, 0x44, 0xfd, 0x97,
    0xdc, 0xf9, 0x7d, 0x10, 0x37, 0xa0, 0x65, 0xf3, 0x49, 0x79, 0x76, 0x2a,
    0xa0, 0xe9, 0xa8, 0x41, 0x48, 0x3b, 0xa5, 0x45, 0xa2, 0x3b, 0x22, 0xf1,
    0x52, 0x54, 0x4d, 0xe5, 0xb1, 0xad, 0xc2, 0xc8, 0x30, 0x1b, 0x97, 0x65,
    0xf9, 0xb8, 0xf9, 0x06, 0x55, 0x35, 0xaf, 0xd3, 0x99, 0xfc, 0x9e, 0xd4,
    0xcd, 0x3e, 0xdb, 0x93, 0xbc, 0xd1, 0xfc, 0x91, 0xbc, 0x2d, 0x26, 0x4f,
    0x59, 0xd4, 0x35, 0xe9, 0x2c, 0xa8, 0x59, 0x87, 0xae, 0xbc, 0x15, 0xc6,
    0x59, 0xd1, 0xa8, 0x74, 0xbd, 0xff, 0xe6, 0x92, 0x28, 0x07, 0x9a, 0x6b,
    0x48, 0x94, 0xf5, 0x52, 0x50, 0x0b, 0xb8, 0xe6, 0x42, 0xda, 0x3f, 0xff,
    0x8a, 0xd1, 0x9c, 0xfc, 0x62, 0xe7, 0x27, 0x72, 0xdb, 0x94, 0x29, 0xcb,
    0xee, 0xa4, 0x07, 0x5c, 0x14, 0xe2, 0x68, 0xbb, 0xfe, 0xce, 0xc3, 0xc4,
    0xbb, 0x15, 0x57, 0x4f, 0xcf, 0x1e, 0x2f, 0x6b, 0xce, 0xf6, 0x6b, 0x84,
    0x6a, 0xab, 0xb1, 0xf3, 0x1d, 0x68, 0xd1, 0x18, 0x6a, 0x24, 0x8a, 0x69,
    0x5a, 0x8d, 0xcf, 0x4b, 0x7c, 0x21, 0x52, 0xb6, 0x06, 0x4f, 0x7f, 0x69,
    0xcb, 0x35, 0xb8, 0xfe, 0x9e, 0xe1, 0x5c, 0xbe, 0xf3, 0xf2, 0xcf, 0x7f,
    0xd2, 0xfd, 0xdb, 0x1d, 0xec, 0xb1, 0x52, 0x1e, 0xa4, 0x32, 0x3c, 0x18,
    0x72, 0x70, 0x8b, 0xfc, 0x34, 0xa5, 0x83, 0x97, 0xe5, 0xf0, 0x26, 0xb1,
    0x58, 0xd5, 0xd4, 0xcf, 0x22, 0xd1, 0xd8, 0xda, 0x58, 0x34, 0x84, 0x65,
    0x8e, 0x63, 0x9b, 0xde, 0xd7, 0xae, 0x4b, 0xcb, 0xf1, 0x1f, 0xe4, 0xd8,
    0x7f, 0x02, 0x00, 0xf6, 0x6c, 0x10, 0xf1, 0x72, 0x83, 0x16, 0x02, 0xb1,
    0x2e, 0x40, 0xfe, 0xa8, 0x29, 0x9c, 0x6b, 0x4d, 0x4a, 0x0f, 0xe0, 0x1f,
    0xc2, 0x4e, 0x37, 0x3c, 0x6f, 0xe5, 0x7d, 0x0a, 0x00, 0x00, 0x00, 0x00,
    0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image15_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x0e, 0x00, 0x00, 0x00, 0x0e,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0x48, 0x2d, 0xd1, 0x00, 0x00, 0x02,
    0x3d, 0x49, 0x44, 0x41, 0x54, 0x28, 0x91, 0x6d, 0x92, 0xcb, 0x4b, 0x94,
    0x61, 0x1c, 0x85, 0x9f, 0xdf, 0xfb, 0x8d, 0x17, 0x9c, 0x28, 0x30, 0x47,
    0x27, 0x08, 0x17, 0xa2, 0x11, 0xa6, 0x6e, 0x82, 0x92, 0x8c, 0x40, 0x24,
    0xcc, 0x4d, 0xd9, 0x42, 0xa2, 0x0b, 0x39, 0xda, 0xa2, 0x85, 0x9b, 0xfe,
    0x80, 0x68, 0xfa, 0x20, 0x82, 0xf6, 0x41, 0x20, 0xa2, 0xa3, 0x52, 0x11,
    0xb6, 0xe8, 0x02, 0x51, 0xbb, 0xee, 0x11, 0x64, 0xd1, 0x78, 0x09, 0x52,
    0x68, 0x63, 0x90, 0x8e, 0x98, 0x51, 0x91, 0x39, 0xf3, 0xbd, 0xa7, 0x85,
    0xdd, 0x16, 0x3e, 0x70, 0x56, 0x87, 0x87, 0xb3, 0x39, 0x86, 0x64, 0x84,
    0x98, 0xd2, 0xf8, 0xcd, 0x57, 0x67, 0x37, 0xc6, 0x56, 0x7f, 0x1c, 0x95,
    0xd1, 0x8c, 0xd9, 0x26, 0x00, 0xb0, 0x2f, 0x26, 0xbd, 0xcc, 0xc7, 0xcb,
    0xae, 0x2f, 0x75, 0xd5, 0x7c, 0xb1, 0x30, 0x74, 0xa4, 0xd3, 0x32, 0xce,
    0xcb, 0x29, 0x8d, 0xaf, 0x1c, 0x9d, 0xde, 0x4b, 0x14, 0x5d, 0x00, 0x5b,
    0x14, 0xf6, 0x00, 0xf2, 0x33, 0x04, 0x81, 0x90, 0xab, 0xb3, 0xc8, 0xb7,
    0x63, 0x54, 0x4a, 0x9c, 0xcb, 0xf5, 0x34, 0x3e, 0xb2, 0x30, 0x74, 0x48,
    0x22, 0x91, 0xc9, 0xee, 0x4b, 0x0c, 0x4d, 0x64, 0x13, 0x43, 0x13, 0xbd,
    0x92, 0x58, 0x2f, 0x89, 0xc1, 0xb7, 0xdd, 0x89, 0xc1, 0xec, 0x44, 0xc5,
    0xf0, 0x64, 0xab, 0x24, 0x6c, 0xe3, 0xc0, 0x54, 0x79, 0x49, 0xcc, 0xdf,
    0xc6, 0xfb, 0x81, 0x85, 0x9e, 0xa6, 0x61, 0x80, 0x8a, 0x91, 0xe9, 0x5d,
    0x81, 0x8f, 0x8e, 0x08, 0x97, 0x97, 0xd7, 0xcd, 0x5c, 0x6f, 0xc3, 0x2b,
    0x80, 0x64, 0x66, 0xfa, 0x98, 0xc7, 0xf7, 0x15, 0x95, 0x14, 0x1f, 0x72,
    0xc5, 0x41, 0xe1, 0x24, 0x62, 0xee, 0x8f, 0x54, 0x95, 0x99, 0xe8, 0x74,
    0x51, 0xf4, 0x14, 0xd4, 0x8e, 0x74, 0xd0, 0x9c, 0xee, 0x25, 0x46, 0xa6,
    0x5a, 0x01, 0x3e, 0xa5, 0xea, 0xaf, 0x19, 0x7c, 0x28, 0xac, 0xac, 0xa4,
    0x9c, 0xe1, 0x76, 0x4b, 0xfe, 0x0e, 0xbf, 0x91, 0x68, 0xc3, 0x98, 0x9b,
    0x4f, 0x35, 0x35, 0xe0, 0xa3, 0xe3, 0x41, 0xc5, 0xd6, 0x04, 0x3e, 0xea,
    0xf8, 0xd7, 0xfb, 0x5b, 0x32, 0xdb, 0xe5, 0x30, 0x36, 0x10, 0x73, 0x33,
    0x00, 0x36, 0x46, 0x50, 0x54, 0x5a, 0x12, 0xe6, 0xe2, 0xc1, 0xf6, 0xe4,
    0x68, 0x36, 0x4e, 0xe0, 0x2e, 0x45, 0xb9, 0xb9, 0x15, 0x23, 0x76, 0xf7,
    0x8f, 0x88, 0xc5, 0x66, 0xc1, 0xca, 0x1c, 0xff, 0xf3, 0x79, 0xdc, 0x7d,
    0x3c, 0xba, 0x6d, 0x51, 0x5d, 0xf5, 0xab, 0xbe, 0x60, 0x63, 0x98, 0xdb,
    0x6f, 0x58, 0xdb, 0x42, 0xaa, 0xfe, 0x89, 0xf5, 0x8f, 0x17, 0x01, 0x10,
    0xe5, 0x0d, 0xc0, 0x21, 0xbe, 0xe1, 0xad, 0x0e, 0xa0, 0xf6, 0xe7, 0x26,
    0x07, 0x60, 0xe1, 0xc3, 0x18, 0x2e, 0x78, 0x6d, 0xf8, 0x13, 0xf3, 0x3d,
    0x0d, 0xcf, 0xd7, 0xba, 0x85, 0xb5, 0x91, 0xc0, 0xd5, 0x22, 0x7d, 0x77,
    0x18, 0x2f, 0x0c, 0x75, 0x02, 0xcc, 0x26, 0xdf, 0x14, 0x00, 0x6a, 0xcb,
    0x7f, 0x04, 0x52, 0xa1, 0x5a, 0x52, 0x05, 0x80, 0xf5, 0x8f, 0x17, 0xcd,
    0x2e, 0x75, 0xe4, 0x01, 0xcc, 0x38, 0x2c, 0xe3, 0xa5, 0xcb, 0xab, 0x30,
    0x82, 0xb4, 0xa5, 0x32, 0x33, 0xd9, 0xab, 0xae, 0xae, 0x08, 0x60, 0x39,
    0x5e, 0x53, 0xec, 0x64, 0x31, 0xc3, 0x15, 0x03, 0x70, 0x7a, 0x67, 0x41,
    0x69, 0x7c, 0xd5, 0x60, 0xf6, 0xa4, 0x64, 0xd5, 0xa5, 0x51, 0x90, 0x31,
    0x49, 0x54, 0x0d, 0x4f, 0xb5, 0x48, 0xfe, 0x8a, 0x8c, 0xcb, 0xb9, 0xee,
    0xc6, 0x7e, 0xd6, 0xa1, 0x72, 0x78, 0xf2, 0x14, 0x5e, 0x67, 0x70, 0xf4,
    0x2d, 0x74, 0x37, 0x3e, 0xfe, 0x7b, 0xb9, 0x64, 0xe6, 0x5d, 0xb3, 0x57,
    0x74, 0x11, 0xc7, 0xb2, 0xd0, 0x7d, 0x14, 0xbd, 0x87, 0x18, 0xa0, 0x3a,
    0xc3, 0x0e, 0x80, 0xca, 0xcd, 0xdc, 0xd9, 0xf9, 0xee, 0x1d, 0xcf, 0x2c,
    0xc4, 0xd9, 0xff, 0x27, 0x4f, 0x8e, 0xce, 0xc7, 0xbd, 0x72, 0x47, 0xf0,
    0xec, 0x41, 0x2a, 0xc7, 0x4c, 0xa0, 0x65, 0xc9, 0xbd, 0x40, 0xcb, 0x37,
    0x72, 0xbd, 0x2d, 0x5f, 0x2d, 0xc4, 0x91, 0x46, 0xbf, 0x00, 0xa9, 0xd7,
    0x27, 0x55, 0xa9, 0xad, 0x8a, 0x7a, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45,
    0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image16_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0x57, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x4b, 0x48, 0x54,
    0x51, 0x18, 0x80, 0xbf, 0x73, 0xef, 0x98, 0x63, 0xe3, 0x68, 0x62, 0xd6,
    0x4c, 0x3e, 0xc2, 0x91, 0x2c, 0xa9, 0xac, 0x34, 0xb5, 0x56, 0x66, 0x0b,
    0xa5, 0x04, 0xad, 0x6c, 0x91, 0x84, 0x1a, 0x09, 0x21, 0x51, 0x8b, 0x16,
    0x46, 0xd4, 0x42, 0x8a, 0x28, 0xb2, 0x07, 0x82, 0xb4, 0xc8, 0x85, 0xad,
    0xc4, 0xca, 0x5a, 0x84, 0x0b, 0x75, 0x9b, 0x51, 0x68, 0xa8, 0x4d, 0x54,
    0x3a, 0x69, 0xbe, 0xd3, 0x70, 0xcc, 0x19, 0x9d, 0xf2, 0x36, 0xe3, 0xcc,
    0x3d, 0x2d, 0x42, 0xd1, 0xd0, 0x12, 0xfa, 0xb7, 0xe7, 0x7c, 0x1f, 0xff,
    0x53, 0x48, 0x29, 0xf9, 0x9f, 0x30, 0xac, 0xe6, 0xd3, 0xfd, 0x73, 0x22,
    0x52, 0x73, 0x73, 0x46, 0x2a, 0xd8, 0x67, 0x13, 0x68, 0xae, 0xa8, 0x90,
    0xfa, 0xfc, 0x9b, 0xf2, 0x2f, 0xf8, 0x4e, 0x8e, 0x30, 0x85, 0x06, 0xab,
    0xb7, 0xd2, 0x0f, 0x64, 0xdf, 0x88, 0x8d, 0xb3, 0x3d, 0x0b, 0xea, 0xe3,
    0xb8, 0x10, 0x42, 0xac, 0x2a, 0x83, 0xca, 0x7c, 0x61, 0xde, 0x98, 0x18,
    0xf4, 0x60, 0xfb, 0xfe, 0x82, 0xc2, 0xbd, 0xc9, 0x75, 0x38, 0x4d, 0x2f,
    0x8d, 0x9e, 0xa9, 0xa2, 0xfa, 0x8b, 0x27, 0x86, 0x75, 0xe0, 0xe9, 0x5f,
    0x33, 0xa8, 0xcd, 0x17, 0xe6, 0x04, 0x1b, 0xd5, 0x49, 0x99, 0xfb, 0x0a,
    0x77, 0x1d, 0xac, 0x41, 0x0e, 0x28, 0x44, 0xfd, 0x48, 0x23, 0x6b, 0xfd,
    0x65, 0x65, 0x93, 0x62, 0xad, 0xbd, 0x54, 0x60, 0xc8, 0x5d, 0x51, 0xd0,
    0x20, 0x84, 0x1a, 0xbd, 0xc3, 0x58, 0x19, 0x9f, 0x9e, 0x51, 0xb2, 0x27,
    0x6f, 0x1b, 0x86, 0x88, 0x46, 0xb4, 0xf8, 0x9f, 0x4c, 0x4e, 0xf4, 0x10,
    0x33, 0x92, 0x41, 0xf2, 0x5c, 0xae, 0x79, 0x8d, 0xc2, 0xe3, 0x15, 0x05,
    0xa1, 0xe5, 0x5c, 0xb1, 0xee, 0x4c, 0x29, 0x4b, 0x3e, 0x96, 0x86, 0x4a,
    0x3d, 0xba, 0xe3, 0x24, 0x9a, 0xf1, 0x1a, 0xd3, 0x29, 0x61, 0x0c, 0xeb,
    0x7d, 0x8c, 0x05, 0x1c, 0x08, 0x21, 0xbd, 0xcb, 0xf6, 0xe0, 0x51, 0x99,
    0x28, 0xb5, 0xa5, 0xef, 0xbe, 0xba, 0x35, 0x37, 0x09, 0x55, 0x6d, 0x20,
    0xe0, 0xf8, 0x8e, 0x3e, 0x0e, 0x3e, 0xcf, 0x4d, 0x5c, 0x26, 0x37, 0x1d,
    0x96, 0x1e, 0x06, 0x3e, 0xb7, 0x76, 0xab, 0x92, 0xf3, 0x00, 0x62, 0xf1,
    0x1e, 0x3c, 0x2c, 0x16, 0x99, 0xf1, 0x19, 0x71, 0x8d, 0x69, 0x85, 0x59,
    0xe6, 0xb5, 0xe1, 0xad, 0xc8, 0x4f, 0xfd, 0x04, 0x9c, 0x30, 0xe9, 0x82,
    0xa9, 0x09, 0x78, 0xf5, 0x16, 0x7a, 0x27, 0x70, 0x04, 0x7c, 0x14, 0xde,
    0x7d, 0x2e, 0xbb, 0x96, 0x94, 0x50, 0x7d, 0x58, 0x44, 0x85, 0xc7, 0xaf,
    0xab, 0x49, 0xcc, 0x4e, 0x35, 0x9b, 0x22, 0x5a, 0x90, 0xbd, 0xfd, 0xf8,
    0x9d, 0xe0, 0x74, 0x81, 0xcb, 0x0d, 0x6d, 0x1f, 0xa0, 0x6f, 0x88, 0x3e,
    0x39, 0x43, 0xc9, 0x3c, 0xbc, 0x44, 0x10, 0xb2, 0x99, 0xd2, 0xf0, 0x18,
    0x5b, 0xa2, 0x75, 0xcb, 0x11, 0xb4, 0xc1, 0x70, 0xbc, 0xa3, 0xbf, 0x41,
    0xb7, 0x0b, 0xda, 0xbb, 0xa0, 0x77, 0x80, 0x11, 0xe9, 0xe7, 0xf4, 0xed,
    0x16, 0xd9, 0xb6, 0xb8, 0x64, 0x05, 0xa0, 0xaa, 0x48, 0x58, 0xd5, 0xe0,
    0xe0, 0xb3, 0x69, 0x87, 0xb2, 0x10, 0x44, 0x31, 0x67, 0xc8, 0xc3, 0xe5,
    0xb7, 0xe2, 0x9a, 0x84, 0x76, 0x3b, 0x38, 0xfa, 0x19, 0xf1, 0xfb, 0x28,
    0xae, 0x6c, 0x96, 0xad, 0x7f, 0xf6, 0xcc, 0x00, 0xa0, 0x0b, 0x72, 0x3c,
    0x7a, 0x44, 0xec, 0x98, 0xc7, 0x42, 0x98, 0xaf, 0x03, 0xa9, 0x0d, 0x31,
    0x34, 0xae, 0xd0, 0xf9, 0x1a, 0xc6, 0x9c, 0x7c, 0xd4, 0xe6, 0x38, 0x55,
    0xd5, 0x24, 0xdf, 0x2c, 0x37, 0x31, 0x03, 0x80, 0xa2, 0xab, 0x99, 0xa3,
    0xd3, 0x56, 0x2e, 0x94, 0xbf, 0xe0, 0x68, 0x7a, 0x37, 0x96, 0xa0, 0x6f,
    0xbc, 0xb3, 0xcf, 0x30, 0xab, 0x61, 0x97, 0x01, 0x4a, 0xab, 0x9a, 0x64,
    0xc7, 0x72, 0xf0, 0x82, 0x40, 0xd3, 0xe5, 0xd7, 0x80, 0x36, 0x48, 0xb4,
    0xb7, 0x87, 0xa1, 0x4e, 0x2d, 0x30, 0x6e, 0xa0, 0xcb, 0xeb, 0xa3, 0x4e,
    0x31, 0xd2, 0x70, 0xfd, 0x89, 0xfc, 0xb2, 0x12, 0xbc, 0x20, 0xf0, 0xf8,
    0xf5, 0x7b, 0x91, 0xaa, 0xcb, 0x61, 0xd9, 0x40, 0x88, 0xc7, 0xc7, 0x7b,
    0x8f, 0x97, 0x6e, 0x73, 0x2a, 0x53, 0x8b, 0xaf, 0x6e, 0xa5, 0xf8, 0x05,
    0xb5, 0xd4, 0xf3, 0xa6, 0xcb, 0x14, 0x73, 0xa0, 0x00, 0x00, 0x00, 0x00,
    0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image17_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xe0, 0x77, 0x3d, 0xf8, 0x00, 0x00, 0x05,
    0x5a, 0x49, 0x44, 0x41, 0x54, 0x48, 0x89, 0xb5, 0x96, 0x7b, 0x6c, 0xd5,
    0x07, 0x15, 0xc7, 0x3f, 0xe7, 0xf7, 0xba, 0x8f, 0xde, 0xdb, 0xcb, 0xbd,
    0x40, 0x1f, 0xb4, 0x50, 0xf7, 0xd0, 0x42, 0xd8, 0xd6, 0x3a, 0x34, 0x8b,
    0x33, 0xba, 0x80, 0xc0, 0xdc, 0xc3, 0x84, 0xb8, 0xa9, 0x01, 0x4c, 0xb6,
    0xba, 0xb0, 0x11, 0x19, 0x4d, 0x0c, 0xba, 0xec, 0x8f, 0x99, 0x58, 0xfd,
    0xcb, 0xa0, 0x2e, 0x99, 0x4e, 0x37, 0x16, 0x5e, 0xcb, 0x80, 0x3f, 0x34,
    0xdb, 0xb2, 0x64, 0x1a, 0xd0, 0x0c, 0xdd, 0x20, 0x3a, 0x81, 0xae, 0x2b,
    0x5d, 0x28, 0x30, 0x56, 0xa0, 0xf4, 0x16, 0xda, 0xd2, 0xfb, 0xbe, 0xf7,
    0x77, 0xef, 0xef, 0x71, 0xfc, 0x63, 0xb2, 0xec, 0x91, 0xd9, 0xc4, 0x64,
    0x27, 0x39, 0x7f, 0x9c, 0xe4, 0xe4, 0x7c, 0xf2, 0xfd, 0xfe, 0x71, 0xce,
    0x11, 0x55, 0xe5, 0xb3, 0x0c, 0xeb, 0xc3, 0x85, 0xdc, 0x2f, 0x16, 0x4d,
    0xdc, 0x6b, 0x59, 0xd6, 0x1a, 0xa2, 0xdc, 0x82, 0xc1, 0x29, 0xdf, 0xf7,
    0x0f, 0x12, 0x70, 0x50, 0x77, 0x68, 0xf9, 0xff, 0x01, 0xc8, 0x35, 0x05,
    0xf2, 0x90, 0x24, 0x05, 0xf9, 0x6d, 0xaa, 0x2b, 0xf5, 0xc0, 0xca, 0x9e,
    0x55, 0xcc, 0x8f, 0xcc, 0xa7, 0x1a, 0x54, 0x18, 0x9c, 0x3c, 0xc6, 0xc5,
    0xf1, 0x89, 0x43, 0xd5, 0xa0, 0xba, 0x9d, 0x31, 0x5e, 0xd3, 0x7d, 0x1a,
    0x4a, 0xbf, 0x38, 0xdc, 0xc8, 0x72, 0x62, 0x84, 0xba, 0x49, 0xdf, 0x9e,
    0x13, 0x20, 0xfd, 0x62, 0x51, 0xe4, 0xb9, 0x9b, 0x7a, 0x6e, 0x7a, 0xb0,
    0xff, 0x7b, 0x5b, 0xc1, 0xf1, 0xb0, 0x24, 0x44, 0x4d, 0x9f, 0x24, 0x69,
    0x06, 0xdf, 0x1d, 0x61, 0xe7, 0x9b, 0xbb, 0x82, 0xe9, 0xc9, 0x5c, 0x1f,
    0x57, 0x38, 0xd8, 0x72, 0x6b, 0xeb, 0xb6, 0xb2, 0x59, 0xda, 0x54, 0xf5,
    0xab, 0x07, 0xf4, 0x87, 0xba, 0x65, 0x6e, 0x8b, 0xf2, 0x7c, 0x2d, 0xb6,
    0x20, 0xf6, 0xe0, 0x0f, 0xd6, 0xf5, 0xf1, 0x97, 0x4b, 0x2f, 0x71, 0x26,
    0x37, 0x84, 0xfa, 0x21, 0x4d, 0x76, 0x84, 0x9b, 0xbb, 0x96, 0xb2, 0x72,
    0xf9, 0x2a, 0x7e, 0xd5, 0x39, 0x60, 0xfe, 0xfc, 0xcf, 0xdb, 0x9f, 0xcf,
    0x45, 0x2a, 0x17, 0x06, 0xbe, 0x32, 0xd0, 0xf5, 0xa6, 0x7b, 0x90, 0x3d,
    0xff, 0x78, 0xa9, 0x36, 0x97, 0x45, 0x96, 0x6c, 0x13, 0x83, 0x0a, 0x1b,
    0x56, 0xdf, 0xbb, 0x9a, 0x53, 0x95, 0x61, 0x86, 0xa6, 0xff, 0x85, 0x95,
    0x8f, 0x72, 0xe9, 0x9d, 0x3c, 0xbe, 0xfa, 0x5c, 0xe9, 0x2a, 0x93, 0xbd,
    0xf5, 0x12, 0x6b, 0x97, 0x7d, 0x83, 0x81, 0xbb, 0x7f, 0x42, 0xf6, 0x72,
    0xa1, 0x6b, 0x7d, 0xef, 0xdd, 0x9c, 0x1d, 0x3e, 0x0a, 0x0d, 0x3a, 0xe7,
    0x04, 0x90, 0x65, 0xbe, 0x24, 0xe4, 0x5b, 0x99, 0x05, 0x69, 0x46, 0x8b,
    0x6f, 0x91, 0x0c, 0x9a, 0x19, 0x3d, 0x31, 0x49, 0xa3, 0xec, 0x8d, 0x12,
    0xe5, 0xec, 0xc5, 0xa1, 0xdc, 0xe2, 0xe9, 0xf1, 0xea, 0xf2, 0xa9, 0x2b,
    0x05, 0x7b, 0xe3, 0xed, 0xf7, 0xb1, 0xa8, 0xbb, 0x8d, 0x27, 0x67, 0x1e,
    0xc7, 0x32, 0x62, 0x10, 0xc8, 0xc2, 0xb9, 0x01, 0x55, 0x6e, 0x6c, 0xea,
    0x8c, 0xb7, 0x9e, 0x73, 0x47, 0x89, 0xce, 0x13, 0x1a, 0xf9, 0x80, 0x46,
    0xc1, 0x83, 0x90, 0xef, 0xe8, 0x0e, 0x1d, 0x91, 0x47, 0x64, 0x85, 0x9b,
    0xab, 0x1f, 0xce, 0x4f, 0x84, 0xf6, 0x60, 0xee, 0xdf, 0x50, 0x0c, 0x30,
    0xbc, 0x38, 0x56, 0x25, 0x8d, 0xe9, 0x1a, 0xa6, 0x6c, 0x16, 0x53, 0x9f,
    0xd1, 0xe0, 0xd3, 0x00, 0x06, 0x11, 0x96, 0x1a, 0x8e, 0xc9, 0x4c, 0x30,
    0x49, 0xcc, 0x31, 0x31, 0x30, 0x20, 0x44, 0x75, 0xb7, 0x8e, 0xc8, 0xc3,
    0xd2, 0x4e, 0xc0, 0x13, 0x99, 0xae, 0x44, 0xb2, 0xbb, 0xb7, 0x8d, 0x98,
    0x95, 0xc0, 0x0c, 0x9a, 0xb8, 0x5a, 0xcb, 0x93, 0x6e, 0x5e, 0x88, 0x13,
    0x38, 0x29, 0x6a, 0xd8, 0xd7, 0x86, 0xc9, 0x2d, 0x12, 0x17, 0x11, 0xf9,
    0xa8, 0x02, 0x1b, 0xaf, 0xe8, 0x16, 0x69, 0x97, 0x04, 0x99, 0x78, 0x92,
    0x6c, 0x3c, 0x0f, 0x16, 0x2a, 0x1b, 0x24, 0x43, 0x92, 0x87, 0x30, 0x58,
    0x57, 0x2f, 0xf8, 0x0c, 0xbd, 0x71, 0x81, 0xd1, 0x68, 0x16, 0x2b, 0x62,
    0x50, 0xc3, 0xa5, 0xe3, 0xba, 0x2f, 0x61, 0x78, 0x46, 0x86, 0x10, 0x07,
    0x70, 0x65, 0xb3, 0xac, 0xe1, 0x36, 0xd6, 0xf3, 0x45, 0xb2, 0xb2, 0x41,
    0x0e, 0xe9, 0x7e, 0x7d, 0xfd, 0x7d, 0x80, 0x89, 0x21, 0x01, 0x98, 0xa1,
    0xd0, 0x14, 0x89, 0x92, 0x59, 0x98, 0xc0, 0x49, 0x58, 0xd2, 0xa8, 0xfa,
    0x2b, 0x80, 0xa3, 0x08, 0x1b, 0xcb, 0xe7, 0xdd, 0x96, 0xf2, 0x19, 0xb7,
    0x13, 0x9b, 0x36, 0x2c, 0x5a, 0xb1, 0x68, 0x39, 0x70, 0xe2, 0x8f, 0x2d,
    0x35, 0x6a, 0x49, 0x1c, 0x32, 0xb2, 0x4d, 0x56, 0xd8, 0xcd, 0xe6, 0x8b,
    0xf3, 0x3a, 0x9b, 0x12, 0xa1, 0xaf, 0xe4, 0xc6, 0xca, 0x8f, 0x4a, 0x9f,
    0x6c, 0xd1, 0xdd, 0xba, 0xcf, 0x42, 0xb9, 0x48, 0x03, 0xaa, 0xae, 0x47,
    0x60, 0x04, 0x64, 0x5a, 0x93, 0xc4, 0x52, 0xb6, 0x34, 0x66, 0xfc, 0xdb,
    0xf5, 0x59, 0x1d, 0xf8, 0xb8, 0xa7, 0x12, 0x95, 0x38, 0xdf, 0xa4, 0xab,
    0x5c, 0x2f, 0x2d, 0xa2, 0x83, 0x34, 0xca, 0x0c, 0xc2, 0x93, 0xd1, 0x8c,
    0x9d, 0xf8, 0xf2, 0xd7, 0x6f, 0xc0, 0xb2, 0x4d, 0x8e, 0x1e, 0x3e, 0x9d,
    0xba, 0x3a, 0x52, 0x7a, 0x4a, 0xbe, 0x2d, 0xaf, 0x5a, 0x98, 0x0c, 0x69,
    0x83, 0xd9, 0xe9, 0x53, 0xc5, 0xcc, 0x60, 0xf3, 0x18, 0x86, 0x65, 0xe0,
    0xd5, 0x03, 0x30, 0xe9, 0x91, 0x1d, 0x12, 0xa3, 0xc0, 0x5d, 0xf8, 0x14,
    0x69, 0x90, 0xe5, 0x1d, 0x2e, 0xa8, 0xab, 0x15, 0xe0, 0xd4, 0x7f, 0xf3,
    0x7d, 0xe8, 0x63, 0x32, 0xa4, 0x06, 0xeb, 0x62, 0x38, 0xb4, 0xa7, 0xd3,
    0x9c, 0x5e, 0x92, 0x65, 0xf6, 0x5c, 0x29, 0xa3, 0x4d, 0xf4, 0x5a, 0xba,
    0x47, 0xf3, 0xb2, 0x49, 0xfa, 0x2b, 0xe3, 0xee, 0xd3, 0x83, 0x85, 0xf3,
    0x29, 0xd3, 0x12, 0xbc, 0x62, 0x50, 0xc6, 0xe7, 0x29, 0x5c, 0xba, 0xb0,
    0xd8, 0x4b, 0x84, 0xb2, 0x93, 0xb1, 0xa7, 0x8d, 0x36, 0xa6, 0xec, 0xdf,
    0x59, 0x57, 0xd4, 0x0b, 0x2f, 0x8b, 0x1a, 0xe3, 0x7e, 0x23, 0x98, 0xc6,
    0x67, 0x12, 0x93, 0x7f, 0xd6, 0x6a, 0x0d, 0x9d, 0x9a, 0x29, 0x4a, 0x26,
    0x9d, 0xc4, 0x34, 0x05, 0x75, 0x00, 0x93, 0x25, 0x16, 0x80, 0x3e, 0xa7,
    0xfb, 0xa4, 0x4f, 0xc6, 0x83, 0xa9, 0x60, 0x4d, 0x60, 0xb0, 0x08, 0x8b,
    0x03, 0xfa, 0x82, 0xfe, 0x5d, 0x7e, 0x2d, 0x37, 0x18, 0xb6, 0xe1, 0x7f,
    0x61, 0xc9, 0xe7, 0xda, 0xc4, 0x69, 0xb4, 0xa5, 0xa2, 0x71, 0x2c, 0xc3,
    0xa4, 0xe4, 0x56, 0x39, 0x3f, 0x31, 0x4d, 0x61, 0xba, 0x0a, 0xc2, 0x13,
    0xf8, 0xfc, 0x21, 0xa8, 0x87, 0x5a, 0x28, 0x55, 0xa5, 0x52, 0x77, 0x09,
    0x14, 0x44, 0x04, 0x55, 0x0d, 0x8d, 0x6b, 0x32, 0x75, 0xb7, 0xbe, 0xae,
    0x2f, 0xe8, 0x4f, 0x81, 0xad, 0xba, 0x4b, 0xff, 0x06, 0x40, 0x89, 0xac,
    0xa5, 0xd6, 0x58, 0x4f, 0xdb, 0x32, 0x5a, 0xe6, 0x25, 0x58, 0xdc, 0x92,
    0xe2, 0xba, 0x45, 0x0b, 0x70, 0xc4, 0xc6, 0x2d, 0x7b, 0xa0, 0xbc, 0x8c,
    0xc1, 0x4e, 0xdd, 0xae, 0xb3, 0x84, 0x88, 0x57, 0x0f, 0xc8, 0x55, 0xca,
    0xa8, 0x67, 0x90, 0x30, 0x13, 0x10, 0x60, 0x7f, 0x64, 0x5d, 0x03, 0xe8,
    0xf3, 0x5a, 0xfd, 0xa0, 0xa8, 0x81, 0x17, 0x0b, 0x8c, 0x66, 0xbb, 0x99,
    0x9a, 0x15, 0xc7, 0x72, 0x2c, 0x6a, 0x0d, 0x97, 0x6c, 0x76, 0x86, 0xfa,
    0xa4, 0x57, 0x22, 0xcf, 0x2f, 0xf4, 0x19, 0xbd, 0x2c, 0xfd, 0x72, 0x33,
    0x31, 0xc4, 0x74, 0x0c, 0x66, 0x2b, 0x25, 0x24, 0x74, 0x88, 0x10, 0xa1,
    0x54, 0x2e, 0x8d, 0x7e, 0x02, 0xf0, 0xb1, 0x08, 0xd5, 0x0d, 0x90, 0x20,
    0xe0, 0xbe, 0xcf, 0x7f, 0x97, 0xb4, 0x74, 0x50, 0x35, 0x66, 0xf0, 0xfd,
    0xdd, 0xc4, 0x4c, 0x3b, 0x7a, 0xee, 0xf4, 0xcc, 0x4e, 0xd9, 0x2c, 0xe3,
    0x08, 0xdd, 0x0b, 0x97, 0x34, 0x13, 0x49, 0x9a, 0x14, 0xab, 0x1e, 0xd7,
    0xdb, 0xcb, 0x78, 0x2f, 0xfb, 0xda, 0x14, 0x71, 0xde, 0xfd, 0x9f, 0x00,
    0xfd, 0xa5, 0xd6, 0xe5, 0xc7, 0x32, 0x6b, 0x86, 0x26, 0x77, 0x38, 0xf7,
    0xf3, 0xc8, 0xbe, 0x2d, 0xf4, 0x2e, 0xed, 0xe6, 0x47, 0x5f, 0x7d, 0x9c,
    0x3f, 0x2d, 0xd8, 0x6b, 0x1f, 0x6f, 0x39, 0xdd, 0x9b, 0xbd, 0x50, 0xe8,
    0x15, 0xd3, 0x24, 0xb3, 0x38, 0x46, 0xae, 0x91, 0x67, 0x55, 0xc7, 0x3a,
    0x4e, 0x1c, 0x19, 0xc2, 0x73, 0xbd, 0x57, 0xe8, 0xe6, 0xea, 0x5c, 0x0a,
    0x20, 0xc0, 0x3d, 0x36, 0xf2, 0x36, 0xdf, 0x3f, 0xde, 0xc7, 0xd1, 0x93,
    0x47, 0xde, 0x3b, 0x32, 0xfc, 0xc6, 0xf5, 0xb5, 0x5a, 0x8d, 0x0d, 0xab,
    0xb7, 0xd2, 0x3b, 0xff, 0x2d, 0x8e, 0x4d, 0x1c, 0x63, 0xb6, 0x96, 0x43,
    0x7d, 0x8b, 0xdb, 0x5a, 0xd7, 0x72, 0xe6, 0xcc, 0x18, 0x27, 0x87, 0x4f,
    0x42, 0x82, 0xfd, 0xfa, 0x33, 0x0d, 0x65, 0xae, 0x9b, 0x2c, 0x5b, 0xe4,
    0xb8, 0x85, 0xd9, 0xe1, 0xfb, 0xc1, 0xd3, 0x54, 0x78, 0x96, 0x08, 0x77,
    0x45, 0x4c, 0x67, 0x57, 0x4f, 0xcf, 0x72, 0x73, 0xe3, 0x1d, 0xeb, 0x59,
    0xdc, 0xde, 0x89, 0x11, 0x31, 0xa8, 0xbb, 0x01, 0x87, 0x86, 0x0f, 0x73,
    0xe0, 0xe5, 0xfd, 0x54, 0x4b, 0xd5, 0x3d, 0xa4, 0xd9, 0xa4, 0xbf, 0x51,
    0x7f, 0x6e, 0xc0, 0xc3, 0x72, 0x0f, 0x0d, 0xc6, 0x98, 0xe5, 0xac, 0xbe,
    0xa2, 0x9e, 0x3c, 0x2a, 0x06, 0x55, 0x56, 0xe2, 0xf1, 0x58, 0x3c, 0x1a,
    0x5b, 0x9b, 0xea, 0x4c, 0xd0, 0x9a, 0x6a, 0xe7, 0x62, 0xee, 0x12, 0xa5,
    0x89, 0x32, 0x5e, 0xd8, 0xd8, 0x4b, 0x94, 0xad, 0xfa, 0x7b, 0x2d, 0xc1,
    0x87, 0x6e, 0xf2, 0xa7, 0x02, 0x1e, 0x10, 0xd1, 0xbd, 0x9f, 0x6c, 0x92,
    0x3e, 0x49, 0x10, 0xb2, 0x16, 0x9f, 0x3b, 0x51, 0x96, 0x21, 0x0c, 0xe3,
    0xf0, 0x57, 0x84, 0x57, 0x75, 0x97, 0xfa, 0x1f, 0xf4, 0x7d, 0xd6, 0x6f,
    0xcb, 0x7f, 0x00, 0x9f, 0x63, 0x74, 0x85, 0x37, 0xcd, 0x6a, 0x76, 0x00,
    0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};


/*
 *  Constructs a dan as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
dan::dan( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    QImage img;
    img.loadFromData( image0_data, sizeof( image0_data ), "PNG" );
    image0 = img;
    img.loadFromData( image1_data, sizeof( image1_data ), "PNG" );
    image1 = img;
    img.loadFromData( image2_data, sizeof( image2_data ), "PNG" );
    image2 = img;
    img.loadFromData( image3_data, sizeof( image3_data ), "PNG" );
    image3 = img;
    img.loadFromData( image4_data, sizeof( image4_data ), "PNG" );
    image4 = img;
    img.loadFromData( image5_data, sizeof( image5_data ), "PNG" );
    image5 = img;
    img.loadFromData( image6_data, sizeof( image6_data ), "PNG" );
    image6 = img;
    img.loadFromData( image7_data, sizeof( image7_data ), "PNG" );
    image7 = img;
    img.loadFromData( image8_data, sizeof( image8_data ), "PNG" );
    image8 = img;
    img.loadFromData( image9_data, sizeof( image9_data ), "PNG" );
    image9 = img;
    img.loadFromData( image10_data, sizeof( image10_data ), "PNG" );
    image10 = img;
    img.loadFromData( image11_data, sizeof( image11_data ), "PNG" );
    image11 = img;
    img.loadFromData( image12_data, sizeof( image12_data ), "PNG" );
    image12 = img;
    img.loadFromData( image13_data, sizeof( image13_data ), "PNG" );
    image13 = img;
    img.loadFromData( image14_data, sizeof( image14_data ), "PNG" );
    image14 = img;
    img.loadFromData( image15_data, sizeof( image15_data ), "PNG" );
    image15 = img;
    img.loadFromData( image16_data, sizeof( image16_data ), "PNG" );
    image16 = img;
    img.loadFromData( image17_data, sizeof( image17_data ), "PNG" );
    image17 = img;
    if ( !name )
	setName( "dan" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 0, 0 ) );
    setMaximumSize( QSize( 1500, 3000 ) );
    setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    setPalette( pal );
    setBackgroundOrigin( QWidget::WidgetOrigin );
    QFont f( font() );
    setFont( f ); 
    danLayout = new QVBoxLayout( this, 5, 6, "danLayout"); 

    buttonGroupMode0 = new QButtonGroup( this, "buttonGroupMode0" );
    buttonGroupMode0->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroupMode0->sizePolicy().hasHeightForWidth() ) );
    buttonGroupMode0->setMinimumSize( QSize( 0, 25 ) );
    buttonGroupMode0->setMaximumSize( QSize( 32767, 35 ) );
    buttonGroupMode0->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    buttonGroupMode0->setPalette( pal );
    buttonGroupMode0->setLineWidth( 0 );
    buttonGroupMode0->setColumnLayout(0, Qt::Vertical );
    buttonGroupMode0->layout()->setSpacing( 4 );
    buttonGroupMode0->layout()->setMargin( 0 );
    buttonGroupMode0Layout = new QHBoxLayout( buttonGroupMode0->layout() );
    buttonGroupMode0Layout->setAlignment( Qt::AlignTop );

    pushButtonNewSession = new QToolButton( buttonGroupMode0, "pushButtonNewSession" );
    pushButtonNewSession->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, pushButtonNewSession->sizePolicy().hasHeightForWidth() ) );
    pushButtonNewSession->setMinimumSize( QSize( 23, 0 ) );
    pushButtonNewSession->setMaximumSize( QSize( 2300, 25 ) );
    pushButtonNewSession->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    pushButtonNewSession->setPaletteBackgroundColor( QColor( 220, 220, 220 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonNewSession->setPalette( pal );
    pushButtonNewSession->setBackgroundOrigin( QToolButton::WindowOrigin );
    QFont pushButtonNewSession_font(  pushButtonNewSession->font() );
    pushButtonNewSession->setFont( pushButtonNewSession_font ); 
    pushButtonNewSession->setIconSet( QIconSet( image0 ) );
    pushButtonNewSession->setUsesBigPixmap( FALSE );
    pushButtonNewSession->setUsesTextLabel( TRUE );
    pushButtonNewSession->setTextPosition( QToolButton::BesideIcon );
    buttonGroupMode0->insert( pushButtonNewSession, 2 );
    buttonGroupMode0Layout->addWidget( pushButtonNewSession );

    pushButtonInstrLabel = new QToolButton( buttonGroupMode0, "pushButtonInstrLabel" );
    pushButtonInstrLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, pushButtonInstrLabel->sizePolicy().hasHeightForWidth() ) );
    pushButtonInstrLabel->setMinimumSize( QSize( 100, 0 ) );
    pushButtonInstrLabel->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonInstrLabel->setBackgroundMode( QToolButton::PaletteButton );
    pushButtonInstrLabel->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    pushButtonInstrLabel->setPaletteBackgroundColor( QColor( 0, 0, 255 ) );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonInstrLabel->setPalette( pal );
    pushButtonInstrLabel->setBackgroundOrigin( QToolButton::WindowOrigin );
    QFont pushButtonInstrLabel_font(  pushButtonInstrLabel->font() );
    pushButtonInstrLabel_font.setBold( TRUE );
    pushButtonInstrLabel->setFont( pushButtonInstrLabel_font ); 
    pushButtonInstrLabel->setToggleButton( FALSE );
    pushButtonInstrLabel->setOn( FALSE );
    pushButtonInstrLabel->setIconSet( QIconSet( image1 ) );
    pushButtonInstrLabel->setUsesBigPixmap( FALSE );
    pushButtonInstrLabel->setUsesTextLabel( TRUE );
    pushButtonInstrLabel->setTextPosition( QToolButton::BesideIcon );
    buttonGroupMode0->insert( pushButtonInstrLabel, 2 );
    buttonGroupMode0Layout->addWidget( pushButtonInstrLabel );

    pushButtonOpenSession = new QToolButton( buttonGroupMode0, "pushButtonOpenSession" );
    pushButtonOpenSession->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, pushButtonOpenSession->sizePolicy().hasHeightForWidth() ) );
    pushButtonOpenSession->setMinimumSize( QSize( 23, 0 ) );
    pushButtonOpenSession->setMaximumSize( QSize( 2300, 25 ) );
    pushButtonOpenSession->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    pushButtonOpenSession->setPaletteBackgroundColor( QColor( 220, 220, 220 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonOpenSession->setPalette( pal );
    pushButtonOpenSession->setBackgroundOrigin( QToolButton::WindowOrigin );
    QFont pushButtonOpenSession_font(  pushButtonOpenSession->font() );
    pushButtonOpenSession->setFont( pushButtonOpenSession_font ); 
    pushButtonOpenSession->setIconSet( QIconSet( image2 ) );
    pushButtonOpenSession->setUsesBigPixmap( FALSE );
    pushButtonOpenSession->setUsesTextLabel( TRUE );
    pushButtonOpenSession->setTextPosition( QToolButton::BesideIcon );
    buttonGroupMode0->insert( pushButtonOpenSession, 2 );
    buttonGroupMode0Layout->addWidget( pushButtonOpenSession );
    danLayout->addWidget( buttonGroupMode0 );

    buttonGroupMode = new QButtonGroup( this, "buttonGroupMode" );
    buttonGroupMode->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)2, 0, 0, buttonGroupMode->sizePolicy().hasHeightForWidth() ) );
    buttonGroupMode->setMinimumSize( QSize( 0, 0 ) );
    buttonGroupMode->setMaximumSize( QSize( 32767, 0 ) );
    buttonGroupMode->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    buttonGroupMode->setColumnLayout(0, Qt::Vertical );
    buttonGroupMode->layout()->setSpacing( 6 );
    buttonGroupMode->layout()->setMargin( 11 );
    buttonGroupModeLayout = new QHBoxLayout( buttonGroupMode->layout() );
    buttonGroupModeLayout->setAlignment( Qt::AlignTop );
    spacer57 = new QSpacerItem( 16, 16, QSizePolicy::Fixed, QSizePolicy::Minimum );
    buttonGroupModeLayout->addItem( spacer57 );

    layout80 = new QVBoxLayout( 0, 0, 6, "layout80"); 
    spacer54 = new QSpacerItem( 20, 16, QSizePolicy::Minimum, QSizePolicy::Fixed );
    layout80->addItem( spacer54 );

    textLabel1_12_4_2 = new QLabel( buttonGroupMode, "textLabel1_12_4_2" );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    textLabel1_12_4_2->setPalette( pal );
    QFont textLabel1_12_4_2_font(  textLabel1_12_4_2->font() );
    textLabel1_12_4_2_font.setFamily( "Lucida Grande" );
    textLabel1_12_4_2->setFont( textLabel1_12_4_2_font ); 
    textLabel1_12_4_2->setAlignment( int( QLabel::WordBreak | QLabel::AlignTop ) );
    layout80->addWidget( textLabel1_12_4_2 );
    spacer55 = new QSpacerItem( 20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed );
    layout80->addItem( spacer55 );

    textLabelInfo2 = new QLabel( buttonGroupMode, "textLabelInfo2" );
    QFont textLabelInfo2_font(  textLabelInfo2->font() );
    textLabelInfo2->setFont( textLabelInfo2_font ); 
    layout80->addWidget( textLabelInfo2 );
    spacer56 = new QSpacerItem( 21, 30, QSizePolicy::Minimum, QSizePolicy::Minimum );
    layout80->addItem( spacer56 );
    buttonGroupModeLayout->addLayout( layout80 );
    spacer57_2 = new QSpacerItem( 16, 16, QSizePolicy::Fixed, QSizePolicy::Minimum );
    buttonGroupModeLayout->addItem( spacer57_2 );
    danLayout->addWidget( buttonGroupMode );

    sansTab = new QTabWidget( this, "sansTab" );
    sansTab->setEnabled( TRUE );
    sansTab->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, sansTab->sizePolicy().hasHeightForWidth() ) );
    sansTab->setMinimumSize( QSize( 530, 300 ) );
    sansTab->setMaximumSize( QSize( 4850, 4400 ) );
    sansTab->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    sansTab->setPalette( pal );
    sansTab->setBackgroundOrigin( QTabWidget::WidgetOrigin );
    sansTab->setAcceptDrops( FALSE );
    sansTab->setAutoMask( FALSE );
    sansTab->setTabPosition( QTabWidget::Top );
    sansTab->setTabShape( QTabWidget::Rounded );
    sansTab->setMargin( 0 );

    TabPage = new QWidget( sansTab, "TabPage" );
    TabPageLayout = new QVBoxLayout( TabPage, 11, 6, "TabPageLayout"); 

    line1_2_3_11_5_10_2 = new QFrame( TabPage, "line1_2_3_11_5_10_2" );
    line1_2_3_11_5_10_2->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_3_11_5_10_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2->setFrameShape( QFrame::HLine );
    line1_2_3_11_5_10_2->setFrameShadow( QFrame::Plain );
    line1_2_3_11_5_10_2->setLineWidth( 1 );
    line1_2_3_11_5_10_2->setFrameShape( QFrame::HLine );
    TabPageLayout->addWidget( line1_2_3_11_5_10_2 );

    groupBox25 = new QGroupBox( TabPage, "groupBox25" );
    groupBox25->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, groupBox25->sizePolicy().hasHeightForWidth() ) );
    groupBox25->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBox25->setBackgroundOrigin( QGroupBox::AncestorOrigin );
    QFont groupBox25_font(  groupBox25->font() );
    groupBox25_font.setBold( TRUE );
    groupBox25->setFont( groupBox25_font ); 
    groupBox25->setFrameShape( QGroupBox::Box );
    groupBox25->setFrameShadow( QGroupBox::Plain );
    groupBox25->setLineWidth( 0 );
    groupBox25->setMidLineWidth( 0 );
    groupBox25->setColumnLayout(0, Qt::Vertical );
    groupBox25->layout()->setSpacing( 4 );
    groupBox25->layout()->setMargin( 11 );
    groupBox25Layout = new QHBoxLayout( groupBox25->layout() );
    groupBox25Layout->setAlignment( Qt::AlignTop );

    comboBoxSel = new QComboBox( FALSE, groupBox25, "comboBoxSel" );
    comboBoxSel->setEnabled( TRUE );
    comboBoxSel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)4, (QSizePolicy::SizeType)0, 0, 0, comboBoxSel->sizePolicy().hasHeightForWidth() ) );
    comboBoxSel->setMinimumSize( QSize( 140, 25 ) );
    comboBoxSel->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxSel->setPalette( pal );
    QFont comboBoxSel_font(  comboBoxSel->font() );
    comboBoxSel_font.setBold( FALSE );
    comboBoxSel->setFont( comboBoxSel_font ); 
    comboBoxSel->setSizeLimit( 15 );
    comboBoxSel->setDuplicatesEnabled( FALSE );
    groupBox25Layout->addWidget( comboBoxSel );

    comboBoxMode = new QComboBox( FALSE, groupBox25, "comboBoxMode" );
    comboBoxMode->setEnabled( TRUE );
    comboBoxMode->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxMode->sizePolicy().hasHeightForWidth() ) );
    comboBoxMode->setMinimumSize( QSize( 0, 25 ) );
    comboBoxMode->setMaximumSize( QSize( 32767, 25 ) );
    comboBoxMode->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    comboBoxMode->setPalette( pal );
    QFont comboBoxMode_font(  comboBoxMode->font() );
    comboBoxMode_font.setBold( FALSE );
    comboBoxMode->setFont( comboBoxMode_font ); 
    groupBox25Layout->addWidget( comboBoxMode );

    pushButtonsaveCurrentSaveInstr = new QToolButton( groupBox25, "pushButtonsaveCurrentSaveInstr" );
    pushButtonsaveCurrentSaveInstr->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonsaveCurrentSaveInstr->sizePolicy().hasHeightForWidth() ) );
    pushButtonsaveCurrentSaveInstr->setMinimumSize( QSize( 25, 25 ) );
    pushButtonsaveCurrentSaveInstr->setMaximumSize( QSize( 25, 25 ) );
    pushButtonsaveCurrentSaveInstr->setIconSet( QIconSet( image3 ) );
    groupBox25Layout->addWidget( pushButtonsaveCurrentSaveInstr );

    pushButtonDeleteCurrentInstr = new QToolButton( groupBox25, "pushButtonDeleteCurrentInstr" );
    pushButtonDeleteCurrentInstr->setEnabled( FALSE );
    pushButtonDeleteCurrentInstr->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonDeleteCurrentInstr->sizePolicy().hasHeightForWidth() ) );
    pushButtonDeleteCurrentInstr->setMinimumSize( QSize( 25, 25 ) );
    pushButtonDeleteCurrentInstr->setMaximumSize( QSize( 25, 25 ) );
    pushButtonDeleteCurrentInstr->setIconSet( QIconSet( image4 ) );
    groupBox25Layout->addWidget( pushButtonDeleteCurrentInstr );

    pushButtonInstrColor = new QToolButton( groupBox25, "pushButtonInstrColor" );
    pushButtonInstrColor->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, pushButtonInstrColor->sizePolicy().hasHeightForWidth() ) );
    pushButtonInstrColor->setMinimumSize( QSize( 25, 25 ) );
    pushButtonInstrColor->setMaximumSize( QSize( 25, 25 ) );
    pushButtonInstrColor->setBackgroundMode( QToolButton::PaletteButton );
    pushButtonInstrColor->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    pushButtonInstrColor->setPaletteBackgroundColor( QColor( 0, 0, 255 ) );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonInstrColor->setPalette( pal );
    pushButtonInstrColor->setBackgroundOrigin( QToolButton::WindowOrigin );
    QFont pushButtonInstrColor_font(  pushButtonInstrColor->font() );
    pushButtonInstrColor->setFont( pushButtonInstrColor_font ); 
    pushButtonInstrColor->setToggleButton( FALSE );
    pushButtonInstrColor->setOn( FALSE );
    pushButtonInstrColor->setIconSet( QIconSet( image5 ) );
    pushButtonInstrColor->setUsesBigPixmap( FALSE );
    pushButtonInstrColor->setUsesTextLabel( TRUE );
    pushButtonInstrColor->setTextPosition( QToolButton::BesideIcon );
    groupBox25Layout->addWidget( pushButtonInstrColor );
    TabPageLayout->addWidget( groupBox25 );

    line1_2_3_11_5_10_3 = new QFrame( TabPage, "line1_2_3_11_5_10_3" );
    line1_2_3_11_5_10_3->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_3_11_5_10_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_3->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_3->setFrameShape( QFrame::HLine );
    line1_2_3_11_5_10_3->setFrameShadow( QFrame::Plain );
    line1_2_3_11_5_10_3->setLineWidth( 1 );
    line1_2_3_11_5_10_3->setFrameShape( QFrame::HLine );
    TabPageLayout->addWidget( line1_2_3_11_5_10_3 );

    buttonGroupOptions = new QButtonGroup( TabPage, "buttonGroupOptions" );
    buttonGroupOptions->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, buttonGroupOptions->sizePolicy().hasHeightForWidth() ) );
    buttonGroupOptions->setMinimumSize( QSize( 0, 0 ) );
    buttonGroupOptions->setMaximumSize( QSize( 32767, 3270 ) );
    buttonGroupOptions->setLineWidth( 0 );
    buttonGroupOptions->setCheckable( FALSE );
    buttonGroupOptions->setColumnLayout(0, Qt::Vertical );
    buttonGroupOptions->layout()->setSpacing( 6 );
    buttonGroupOptions->layout()->setMargin( 0 );
    buttonGroupOptionsLayout = new QVBoxLayout( buttonGroupOptions->layout() );
    buttonGroupOptionsLayout->setAlignment( Qt::AlignTop );

    toolBox7 = new QToolBox( buttonGroupOptions, "toolBox7" );
    toolBox7->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, toolBox7->sizePolicy().hasHeightForWidth() ) );
    toolBox7->setMaximumSize( QSize( 32767, 32000 ) );
    toolBox7->setPaletteBackgroundColor( QColor( 220, 220, 220 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    toolBox7->setPalette( pal );
    toolBox7->setFrameShape( QToolBox::ToolBarPanel );
    toolBox7->setFrameShadow( QToolBox::Sunken );
    toolBox7->setLineWidth( 1 );
    toolBox7->setMargin( 0 );
    toolBox7->setMidLineWidth( 0 );
    toolBox7->setCurrentIndex( 3 );

    page1 = new QWidget( toolBox7, "page1" );
    page1->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout = new QVBoxLayout( page1, 11, 6, "page1Layout"); 

    line1_2_3_11_6 = new QFrame( page1, "line1_2_3_11_6" );
    line1_2_3_11_6->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_3_11_6->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_6->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_6->setFrameShape( QFrame::HLine );
    line1_2_3_11_6->setFrameShadow( QFrame::Plain );
    line1_2_3_11_6->setLineWidth( 1 );
    line1_2_3_11_6->setFrameShape( QFrame::HLine );
    page1Layout->addWidget( line1_2_3_11_6 );

    buttonGroup19 = new QButtonGroup( page1, "buttonGroup19" );
    buttonGroup19->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup19->sizePolicy().hasHeightForWidth() ) );
    buttonGroup19->setMinimumSize( QSize( 0, 60 ) );
    buttonGroup19->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont buttonGroup19_font(  buttonGroup19->font() );
    buttonGroup19_font.setBold( TRUE );
    buttonGroup19->setFont( buttonGroup19_font ); 
    buttonGroup19->setFrameShape( QButtonGroup::NoFrame );
    buttonGroup19->setFrameShadow( QButtonGroup::Plain );
    buttonGroup19->setLineWidth( 0 );
    buttonGroup19->setColumnLayout(0, Qt::Vertical );
    buttonGroup19->layout()->setSpacing( 1 );
    buttonGroup19->layout()->setMargin( 5 );
    buttonGroup19Layout = new QVBoxLayout( buttonGroup19->layout() );
    buttonGroup19Layout->setAlignment( Qt::AlignTop );

    layout109 = new QHBoxLayout( 0, 0, 4, "layout109"); 

    lineEditPathDAT = new QLineEdit( buttonGroup19, "lineEditPathDAT" );
    lineEditPathDAT->setEnabled( TRUE );
    lineEditPathDAT->setMinimumSize( QSize( 0, 25 ) );
    lineEditPathDAT->setMaximumSize( QSize( 3000, 25 ) );
    lineEditPathDAT->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    lineEditPathDAT->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont lineEditPathDAT_font(  lineEditPathDAT->font() );
    lineEditPathDAT_font.setBold( FALSE );
    lineEditPathDAT->setFont( lineEditPathDAT_font ); 
    lineEditPathDAT->setFrameShape( QLineEdit::Box );
    lineEditPathDAT->setFrameShadow( QLineEdit::Sunken );
    lineEditPathDAT->setLineWidth( 1 );
    lineEditPathDAT->setReadOnly( FALSE );
    layout109->addWidget( lineEditPathDAT );

    textEditPattern = new QTextEdit( buttonGroup19, "textEditPattern" );
    textEditPattern->setEnabled( TRUE );
    textEditPattern->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)7, 0, 0, textEditPattern->sizePolicy().hasHeightForWidth() ) );
    textEditPattern->setMinimumSize( QSize( 80, 0 ) );
    textEditPattern->setMaximumSize( QSize( 80, 25 ) );
    textEditPattern->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    textEditPattern->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont textEditPattern_font(  textEditPattern->font() );
    textEditPattern_font.setBold( FALSE );
    textEditPattern->setFont( textEditPattern_font ); 
    textEditPattern->setCursor( QCursor( 2 ) );
    textEditPattern->setFrameShape( QTextEdit::Box );
    textEditPattern->setFrameShadow( QTextEdit::Sunken );
    textEditPattern->setLineWidth( 1 );
    textEditPattern->setVScrollBarMode( QTextEdit::AlwaysOff );
    textEditPattern->setHScrollBarMode( QTextEdit::AlwaysOff );
    textEditPattern->setWordWrap( QTextEdit::WidgetWidth );
    textEditPattern->setUndoRedoEnabled( FALSE );
    layout109->addWidget( textEditPattern );

    pushButtonDATpath = new QToolButton( buttonGroup19, "pushButtonDATpath" );
    pushButtonDATpath->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonDATpath->sizePolicy().hasHeightForWidth() ) );
    pushButtonDATpath->setMinimumSize( QSize( 25, 25 ) );
    pushButtonDATpath->setMaximumSize( QSize( 25, 25 ) );
    pushButtonDATpath->setIconSet( QIconSet( image6 ) );
    layout109->addWidget( pushButtonDATpath );
    buttonGroup19Layout->addLayout( layout109 );

    checkBoxDirsIndir = new QCheckBox( buttonGroup19, "checkBoxDirsIndir" );
    checkBoxDirsIndir->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxDirsIndir->setPalette( pal );
    QFont checkBoxDirsIndir_font(  checkBoxDirsIndir->font() );
    checkBoxDirsIndir_font.setBold( FALSE );
    checkBoxDirsIndir->setFont( checkBoxDirsIndir_font ); 
    buttonGroup19Layout->addWidget( checkBoxDirsIndir );
    page1Layout->addWidget( buttonGroup19 );

    line1_2_3_11_7 = new QFrame( page1, "line1_2_3_11_7" );
    line1_2_3_11_7->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_3_11_7->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_7->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_7->setFrameShape( QFrame::HLine );
    line1_2_3_11_7->setFrameShadow( QFrame::Plain );
    line1_2_3_11_7->setLineWidth( 1 );
    line1_2_3_11_7->setFrameShape( QFrame::HLine );
    page1Layout->addWidget( line1_2_3_11_7 );

    buttonGroup20_2 = new QButtonGroup( page1, "buttonGroup20_2" );
    buttonGroup20_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup20_2->sizePolicy().hasHeightForWidth() ) );
    buttonGroup20_2->setMinimumSize( QSize( 0, 60 ) );
    buttonGroup20_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont buttonGroup20_2_font(  buttonGroup20_2->font() );
    buttonGroup20_2_font.setBold( TRUE );
    buttonGroup20_2->setFont( buttonGroup20_2_font ); 
    buttonGroup20_2->setFrameShape( QButtonGroup::NoFrame );
    buttonGroup20_2->setFrameShadow( QButtonGroup::Plain );
    buttonGroup20_2->setLineWidth( 0 );
    buttonGroup20_2->setColumnLayout(0, Qt::Vertical );
    buttonGroup20_2->layout()->setSpacing( 6 );
    buttonGroup20_2->layout()->setMargin( 5 );
    buttonGroup20_2Layout = new QHBoxLayout( buttonGroup20_2->layout() );
    buttonGroup20_2Layout->setAlignment( Qt::AlignTop );

    lineEditPathRAD = new QLineEdit( buttonGroup20_2, "lineEditPathRAD" );
    lineEditPathRAD->setEnabled( TRUE );
    lineEditPathRAD->setMinimumSize( QSize( 0, 25 ) );
    lineEditPathRAD->setMaximumSize( QSize( 3000, 25 ) );
    lineEditPathRAD->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    lineEditPathRAD->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont lineEditPathRAD_font(  lineEditPathRAD->font() );
    lineEditPathRAD_font.setBold( FALSE );
    lineEditPathRAD->setFont( lineEditPathRAD_font ); 
    lineEditPathRAD->setFrameShape( QLineEdit::Box );
    lineEditPathRAD->setFrameShadow( QLineEdit::Sunken );
    lineEditPathRAD->setLineWidth( 1 );
    lineEditPathRAD->setReadOnly( FALSE );
    buttonGroup20_2Layout->addWidget( lineEditPathRAD );

    pushButtonRADpath = new QToolButton( buttonGroup20_2, "pushButtonRADpath" );
    pushButtonRADpath->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonRADpath->sizePolicy().hasHeightForWidth() ) );
    pushButtonRADpath->setMinimumSize( QSize( 25, 25 ) );
    pushButtonRADpath->setMaximumSize( QSize( 25, 25 ) );
    pushButtonRADpath->setIconSet( QIconSet( image6 ) );
    buttonGroup20_2Layout->addWidget( pushButtonRADpath );
    page1Layout->addWidget( buttonGroup20_2 );
    spacer53 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page1Layout->addItem( spacer53 );
    toolBox7->addItem( page1, QString::fromLatin1("") );

    page2 = new QWidget( toolBox7, "page2" );
    page2->setBackgroundMode( QWidget::PaletteBackground );
    page2Layout = new QVBoxLayout( page2, 11, 0, "page2Layout"); 

    lineEditMD_2_2 = new QLineEdit( page2, "lineEditMD_2_2" );
    lineEditMD_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditMD_2_2->sizePolicy().hasHeightForWidth() ) );
    lineEditMD_2_2->setMinimumSize( QSize( 15, 5 ) );
    lineEditMD_2_2->setMaximumSize( QSize( 15000, 5 ) );
    lineEditMD_2_2->setPaletteForegroundColor( QColor( 255, 255, 195 ) );
    lineEditMD_2_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 173, 173, 219) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    lineEditMD_2_2->setPalette( pal );
    lineEditMD_2_2->setBackgroundOrigin( QLineEdit::WidgetOrigin );
    QFont lineEditMD_2_2_font(  lineEditMD_2_2->font() );
    lineEditMD_2_2->setFont( lineEditMD_2_2_font ); 
    lineEditMD_2_2->setFrameShape( QLineEdit::Box );
    lineEditMD_2_2->setFrameShadow( QLineEdit::Plain );
    lineEditMD_2_2->setLineWidth( 1 );
    lineEditMD_2_2->setMargin( 0 );
    lineEditMD_2_2->setAlignment( int( QLineEdit::AlignHCenter ) );
    lineEditMD_2_2->setReadOnly( TRUE );
    page2Layout->addWidget( lineEditMD_2_2 );

    layout137 = new QHBoxLayout( 0, 0, 0, "layout137"); 

    lineEditMD_2 = new QLineEdit( page2, "lineEditMD_2" );
    lineEditMD_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditMD_2->sizePolicy().hasHeightForWidth() ) );
    lineEditMD_2->setMinimumSize( QSize( 5, 25 ) );
    lineEditMD_2->setMaximumSize( QSize( 5, 3200 ) );
    lineEditMD_2->setPaletteForegroundColor( QColor( 255, 255, 195 ) );
    lineEditMD_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 173, 173, 219) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    lineEditMD_2->setPalette( pal );
    lineEditMD_2->setBackgroundOrigin( QLineEdit::WidgetOrigin );
    QFont lineEditMD_2_font(  lineEditMD_2->font() );
    lineEditMD_2->setFont( lineEditMD_2_font ); 
    lineEditMD_2->setFrameShape( QLineEdit::Box );
    lineEditMD_2->setFrameShadow( QLineEdit::Plain );
    lineEditMD_2->setLineWidth( 1 );
    lineEditMD_2->setMargin( 0 );
    lineEditMD_2->setAlignment( int( QLineEdit::AlignHCenter ) );
    lineEditMD_2->setReadOnly( TRUE );
    layout137->addWidget( lineEditMD_2 );

    toolBoxCONFIG = new QToolBox( page2, "toolBoxCONFIG" );
    toolBoxCONFIG->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, toolBoxCONFIG->sizePolicy().hasHeightForWidth() ) );
    toolBoxCONFIG->setMinimumSize( QSize( 0, 0 ) );
    toolBoxCONFIG->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 173, 173, 219) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    toolBoxCONFIG->setPalette( pal );
    toolBoxCONFIG->setCurrentIndex( 4 );

    page1_2 = new QWidget( toolBoxCONFIG, "page1_2" );
    page1_2->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout_2 = new QVBoxLayout( page1_2, 0, 0, "page1Layout_2"); 

    buttonGroupColim = new QButtonGroup( page1_2, "buttonGroupColim" );
    buttonGroupColim->setEnabled( TRUE );
    buttonGroupColim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroupColim->sizePolicy().hasHeightForWidth() ) );
    buttonGroupColim->setMinimumSize( QSize( 0, 20 ) );
    buttonGroupColim->setMaximumSize( QSize( 3000, 2000 ) );
    buttonGroupColim->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroupColim->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    buttonGroupColim->setPalette( pal );
    buttonGroupColim->setBackgroundOrigin( QButtonGroup::WidgetOrigin );
    QFont buttonGroupColim_font(  buttonGroupColim->font() );
    buttonGroupColim_font.setBold( TRUE );
    buttonGroupColim->setFont( buttonGroupColim_font ); 
    buttonGroupColim->setFrameShape( QButtonGroup::NoFrame );
    buttonGroupColim->setFrameShadow( QButtonGroup::Plain );
    buttonGroupColim->setLineWidth( 0 );
    buttonGroupColim->setFlat( FALSE );
    buttonGroupColim->setCheckable( FALSE );
    buttonGroupColim->setChecked( FALSE );
    buttonGroupColim->setExclusive( FALSE );
    buttonGroupColim->setColumnLayout(0, Qt::Vertical );
    buttonGroupColim->layout()->setSpacing( 2 );
    buttonGroupColim->layout()->setMargin( 11 );
    buttonGroupColimLayout = new QVBoxLayout( buttonGroupColim->layout() );
    buttonGroupColimLayout->setAlignment( Qt::AlignTop );

    layout58 = new QHBoxLayout( 0, 0, 1, "layout58"); 

    textLabel3_2 = new QLabel( buttonGroupColim, "textLabel3_2" );
    textLabel3_2->setEnabled( TRUE );
    textLabel3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel3_2->sizePolicy().hasHeightForWidth() ) );
    textLabel3_2->setMinimumSize( QSize( 100, 0 ) );
    textLabel3_2->setMaximumSize( QSize( 100, 32767 ) );
    textLabel3_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel3_2_font(  textLabel3_2->font() );
    textLabel3_2_font.setFamily( "Lucida Grande" );
    textLabel3_2_font.setBold( FALSE );
    textLabel3_2->setFont( textLabel3_2_font ); 
    layout58->addWidget( textLabel3_2 );

    comboBoxUnitsLambda = new QComboBox( FALSE, buttonGroupColim, "comboBoxUnitsLambda" );
    comboBoxUnitsLambda->setEnabled( TRUE );
    comboBoxUnitsLambda->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, comboBoxUnitsLambda->sizePolicy().hasHeightForWidth() ) );
    comboBoxUnitsLambda->setMinimumSize( QSize( 0, 22 ) );
    comboBoxUnitsLambda->setMaximumSize( QSize( 32767, 22 ) );
    comboBoxUnitsLambda->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxUnitsLambda_font(  comboBoxUnitsLambda->font() );
    comboBoxUnitsLambda_font.setBold( FALSE );
    comboBoxUnitsLambda->setFont( comboBoxUnitsLambda_font ); 
    layout58->addWidget( comboBoxUnitsLambda );
    buttonGroupColimLayout->addLayout( layout58 );

    layout173_3 = new QHBoxLayout( 0, 0, 1, "layout173_3"); 

    textLabelOutput = new QLabel( buttonGroupColim, "textLabelOutput" );
    textLabelOutput->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabelOutput->sizePolicy().hasHeightForWidth() ) );
    textLabelOutput->setMinimumSize( QSize( 100, 0 ) );
    textLabelOutput->setMaximumSize( QSize( 100, 32767 ) );
    textLabelOutput->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabelOutput_font(  textLabelOutput->font() );
    textLabelOutput_font.setFamily( "Lucida Grande" );
    textLabelOutput_font.setBold( FALSE );
    textLabelOutput->setFont( textLabelOutput_font ); 
    layout173_3->addWidget( textLabelOutput );

    comboBoxUnitsOutput = new QComboBox( FALSE, buttonGroupColim, "comboBoxUnitsOutput" );
    comboBoxUnitsOutput->setEnabled( FALSE );
    comboBoxUnitsOutput->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, comboBoxUnitsOutput->sizePolicy().hasHeightForWidth() ) );
    comboBoxUnitsOutput->setMinimumSize( QSize( 0, 22 ) );
    comboBoxUnitsOutput->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxUnitsOutput->setPalette( pal );
    QFont comboBoxUnitsOutput_font(  comboBoxUnitsOutput->font() );
    comboBoxUnitsOutput_font.setBold( FALSE );
    comboBoxUnitsOutput->setFont( comboBoxUnitsOutput_font ); 
    layout173_3->addWidget( comboBoxUnitsOutput );
    buttonGroupColimLayout->addLayout( layout173_3 );

    layout173_2 = new QHBoxLayout( 0, 0, 1, "layout173_2"); 

    textLabel3_2_2 = new QLabel( buttonGroupColim, "textLabel3_2_2" );
    textLabel3_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel3_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel3_2_2->setMinimumSize( QSize( 100, 0 ) );
    textLabel3_2_2->setMaximumSize( QSize( 100, 32767 ) );
    textLabel3_2_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel3_2_2_font(  textLabel3_2_2->font() );
    textLabel3_2_2_font.setFamily( "Lucida Grande" );
    textLabel3_2_2_font.setBold( FALSE );
    textLabel3_2_2->setFont( textLabel3_2_2_font ); 
    layout173_2->addWidget( textLabel3_2_2 );

    comboBoxUnitsBlends = new QComboBox( FALSE, buttonGroupColim, "comboBoxUnitsBlends" );
    comboBoxUnitsBlends->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, comboBoxUnitsBlends->sizePolicy().hasHeightForWidth() ) );
    comboBoxUnitsBlends->setMinimumSize( QSize( 0, 22 ) );
    comboBoxUnitsBlends->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxUnitsBlends_font(  comboBoxUnitsBlends->font() );
    comboBoxUnitsBlends_font.setBold( FALSE );
    comboBoxUnitsBlends->setFont( comboBoxUnitsBlends_font ); 
    layout173_2->addWidget( comboBoxUnitsBlends );
    buttonGroupColimLayout->addLayout( layout173_2 );

    layout173_2_2 = new QHBoxLayout( 0, 0, 1, "layout173_2_2"); 

    textLabel3_2_2_3 = new QLabel( buttonGroupColim, "textLabel3_2_2_3" );
    textLabel3_2_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel3_2_2_3->sizePolicy().hasHeightForWidth() ) );
    textLabel3_2_2_3->setMinimumSize( QSize( 100, 0 ) );
    textLabel3_2_2_3->setMaximumSize( QSize( 100, 32767 ) );
    textLabel3_2_2_3->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel3_2_2_3_font(  textLabel3_2_2_3->font() );
    textLabel3_2_2_3_font.setFamily( "Lucida Grande" );
    textLabel3_2_2_3_font.setBold( FALSE );
    textLabel3_2_2_3->setFont( textLabel3_2_2_3_font ); 
    layout173_2_2->addWidget( textLabel3_2_2_3 );

    comboBoxThicknessUnits = new QComboBox( FALSE, buttonGroupColim, "comboBoxThicknessUnits" );
    comboBoxThicknessUnits->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, comboBoxThicknessUnits->sizePolicy().hasHeightForWidth() ) );
    comboBoxThicknessUnits->setMinimumSize( QSize( 0, 22 ) );
    comboBoxThicknessUnits->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxThicknessUnits_font(  comboBoxThicknessUnits->font() );
    comboBoxThicknessUnits_font.setBold( FALSE );
    comboBoxThicknessUnits->setFont( comboBoxThicknessUnits_font ); 
    layout173_2_2->addWidget( comboBoxThicknessUnits );
    buttonGroupColimLayout->addLayout( layout173_2_2 );

    layout35 = new QHBoxLayout( 0, 0, 1, "layout35"); 

    textLabel3_2_2_2 = new QLabel( buttonGroupColim, "textLabel3_2_2_2" );
    textLabel3_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel3_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel3_2_2_2->setMinimumSize( QSize( 100, 22 ) );
    textLabel3_2_2_2->setMaximumSize( QSize( 100, 32767 ) );
    textLabel3_2_2_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel3_2_2_2_font(  textLabel3_2_2_2->font() );
    textLabel3_2_2_2_font.setFamily( "Lucida Grande" );
    textLabel3_2_2_2_font.setBold( FALSE );
    textLabel3_2_2_2->setFont( textLabel3_2_2_2_font ); 
    layout35->addWidget( textLabel3_2_2_2 );

    comboBoxUnitsCandD = new QComboBox( FALSE, buttonGroupColim, "comboBoxUnitsCandD" );
    comboBoxUnitsCandD->setEnabled( TRUE );
    comboBoxUnitsCandD->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, comboBoxUnitsCandD->sizePolicy().hasHeightForWidth() ) );
    comboBoxUnitsCandD->setMinimumSize( QSize( 0, 22 ) );
    comboBoxUnitsCandD->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxUnitsCandD_font(  comboBoxUnitsCandD->font() );
    comboBoxUnitsCandD_font.setBold( FALSE );
    comboBoxUnitsCandD->setFont( comboBoxUnitsCandD_font ); 
    layout35->addWidget( comboBoxUnitsCandD );
    buttonGroupColimLayout->addLayout( layout35 );

    layout35_2 = new QHBoxLayout( 0, 0, 1, "layout35_2"); 

    textLabel3_2_2_2_2 = new QLabel( buttonGroupColim, "textLabel3_2_2_2_2" );
    textLabel3_2_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel3_2_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel3_2_2_2_2->setMinimumSize( QSize( 100, 22 ) );
    textLabel3_2_2_2_2->setMaximumSize( QSize( 100, 32767 ) );
    textLabel3_2_2_2_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel3_2_2_2_2_font(  textLabel3_2_2_2_2->font() );
    textLabel3_2_2_2_2_font.setFamily( "Lucida Grande" );
    textLabel3_2_2_2_2_font.setBold( FALSE );
    textLabel3_2_2_2_2->setFont( textLabel3_2_2_2_2_font ); 
    layout35_2->addWidget( textLabel3_2_2_2_2 );

    comboBoxUnitsTime = new QComboBox( FALSE, buttonGroupColim, "comboBoxUnitsTime" );
    comboBoxUnitsTime->setEnabled( TRUE );
    comboBoxUnitsTime->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, comboBoxUnitsTime->sizePolicy().hasHeightForWidth() ) );
    comboBoxUnitsTime->setMinimumSize( QSize( 0, 22 ) );
    comboBoxUnitsTime->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxUnitsTime_font(  comboBoxUnitsTime->font() );
    comboBoxUnitsTime_font.setBold( FALSE );
    comboBoxUnitsTime->setFont( comboBoxUnitsTime_font ); 
    layout35_2->addWidget( comboBoxUnitsTime );
    buttonGroupColimLayout->addLayout( layout35_2 );

    layout35_2_2 = new QHBoxLayout( 0, 0, 1, "layout35_2_2"); 

    textLabel3_2_2_2_2_2 = new QLabel( buttonGroupColim, "textLabel3_2_2_2_2_2" );
    textLabel3_2_2_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel3_2_2_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel3_2_2_2_2_2->setMinimumSize( QSize( 100, 22 ) );
    textLabel3_2_2_2_2_2->setMaximumSize( QSize( 100, 32767 ) );
    textLabel3_2_2_2_2_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel3_2_2_2_2_2_font(  textLabel3_2_2_2_2_2->font() );
    textLabel3_2_2_2_2_2_font.setFamily( "Lucida Grande" );
    textLabel3_2_2_2_2_2_font.setBold( FALSE );
    textLabel3_2_2_2_2_2->setFont( textLabel3_2_2_2_2_2_font ); 
    layout35_2_2->addWidget( textLabel3_2_2_2_2_2 );

    comboBoxUnitsTimeRT = new QComboBox( FALSE, buttonGroupColim, "comboBoxUnitsTimeRT" );
    comboBoxUnitsTimeRT->setEnabled( TRUE );
    comboBoxUnitsTimeRT->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, comboBoxUnitsTimeRT->sizePolicy().hasHeightForWidth() ) );
    comboBoxUnitsTimeRT->setMinimumSize( QSize( 0, 22 ) );
    comboBoxUnitsTimeRT->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxUnitsTimeRT_font(  comboBoxUnitsTimeRT->font() );
    comboBoxUnitsTimeRT_font.setBold( FALSE );
    comboBoxUnitsTimeRT->setFont( comboBoxUnitsTimeRT_font ); 
    layout35_2_2->addWidget( comboBoxUnitsTimeRT );
    buttonGroupColimLayout->addLayout( layout35_2_2 );

    layout58_2 = new QHBoxLayout( 0, 0, 1, "layout58_2"); 

    textLabel3_2_3 = new QLabel( buttonGroupColim, "textLabel3_2_3" );
    textLabel3_2_3->setEnabled( TRUE );
    textLabel3_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel3_2_3->sizePolicy().hasHeightForWidth() ) );
    textLabel3_2_3->setMinimumSize( QSize( 100, 0 ) );
    textLabel3_2_3->setMaximumSize( QSize( 100, 32767 ) );
    textLabel3_2_3->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel3_2_3_font(  textLabel3_2_3->font() );
    textLabel3_2_3_font.setFamily( "Lucida Grande" );
    textLabel3_2_3_font.setBold( FALSE );
    textLabel3_2_3->setFont( textLabel3_2_3_font ); 
    layout58_2->addWidget( textLabel3_2_3 );

    comboBoxUnitsSelector = new QComboBox( FALSE, buttonGroupColim, "comboBoxUnitsSelector" );
    comboBoxUnitsSelector->setEnabled( TRUE );
    comboBoxUnitsSelector->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, comboBoxUnitsSelector->sizePolicy().hasHeightForWidth() ) );
    comboBoxUnitsSelector->setMinimumSize( QSize( 0, 22 ) );
    comboBoxUnitsSelector->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxUnitsSelector_font(  comboBoxUnitsSelector->font() );
    comboBoxUnitsSelector_font.setBold( FALSE );
    comboBoxUnitsSelector->setFont( comboBoxUnitsSelector_font ); 
    layout58_2->addWidget( comboBoxUnitsSelector );
    buttonGroupColimLayout->addLayout( layout58_2 );
    page1Layout_2->addWidget( buttonGroupColim );
    spacer83 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page1Layout_2->addItem( spacer83 );
    toolBoxCONFIG->addItem( page1_2, QString::fromLatin1("") );

    page2_2 = new QWidget( toolBoxCONFIG, "page2_2" );
    page2_2->setBackgroundMode( QWidget::PaletteBackground );
    page2Layout_2 = new QVBoxLayout( page2_2, 11, 6, "page2Layout_2"); 

    buttonGroup2ndHeader = new QButtonGroup( page2_2, "buttonGroup2ndHeader" );
    buttonGroup2ndHeader->setEnabled( TRUE );
    buttonGroup2ndHeader->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroup2ndHeader->sizePolicy().hasHeightForWidth() ) );
    buttonGroup2ndHeader->setMinimumSize( QSize( 0, 20 ) );
    buttonGroup2ndHeader->setMaximumSize( QSize( 10000, 200 ) );
    buttonGroup2ndHeader->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroup2ndHeader->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 246, 246, 246) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    buttonGroup2ndHeader->setPalette( pal );
    QFont buttonGroup2ndHeader_font(  buttonGroup2ndHeader->font() );
    buttonGroup2ndHeader_font.setBold( TRUE );
    buttonGroup2ndHeader->setFont( buttonGroup2ndHeader_font ); 
    buttonGroup2ndHeader->setFrameShape( QButtonGroup::NoFrame );
    buttonGroup2ndHeader->setFrameShadow( QButtonGroup::Plain );
    buttonGroup2ndHeader->setLineWidth( 0 );
    buttonGroup2ndHeader->setCheckable( FALSE );
    buttonGroup2ndHeader->setChecked( FALSE );
    buttonGroup2ndHeader->setColumnLayout(0, Qt::Vertical );
    buttonGroup2ndHeader->layout()->setSpacing( 0 );
    buttonGroup2ndHeader->layout()->setMargin( 0 );
    buttonGroup2ndHeaderLayout = new QVBoxLayout( buttonGroup2ndHeader->layout() );
    buttonGroup2ndHeaderLayout->setAlignment( Qt::AlignTop );

    layout93 = new QHBoxLayout( 0, 0, 6, "layout93"); 

    layout92 = new QVBoxLayout( 0, 0, 6, "layout92"); 
    spacer40_2_2_2_2 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout92->addItem( spacer40_2_2_2_2 );

    textLabel1_12_2_3_2_2 = new QLabel( buttonGroup2ndHeader, "textLabel1_12_2_3_2_2" );
    textLabel1_12_2_3_2_2->setEnabled( TRUE );
    textLabel1_12_2_3_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel1_12_2_3_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_12_2_3_2_2->setMinimumSize( QSize( 0, 22 ) );
    textLabel1_12_2_3_2_2->setMaximumSize( QSize( 32767, 22 ) );
    textLabel1_12_2_3_2_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel1_12_2_3_2_2_font(  textLabel1_12_2_3_2_2->font() );
    textLabel1_12_2_3_2_2_font.setFamily( "Lucida Grande" );
    textLabel1_12_2_3_2_2_font.setBold( FALSE );
    textLabel1_12_2_3_2_2->setFont( textLabel1_12_2_3_2_2_font ); 
    layout92->addWidget( textLabel1_12_2_3_2_2 );

    textLabel2_3_3_2_2 = new QLabel( buttonGroup2ndHeader, "textLabel2_3_3_2_2" );
    textLabel2_3_3_2_2->setEnabled( TRUE );
    textLabel2_3_3_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel2_3_3_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_3_3_2_2->setMinimumSize( QSize( 0, 22 ) );
    textLabel2_3_3_2_2->setMaximumSize( QSize( 32767, 22 ) );
    textLabel2_3_3_2_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel2_3_3_2_2_font(  textLabel2_3_3_2_2->font() );
    textLabel2_3_3_2_2_font.setFamily( "Lucida Grande" );
    textLabel2_3_3_2_2_font.setBold( FALSE );
    textLabel2_3_3_2_2->setFont( textLabel2_3_3_2_2_font ); 
    layout92->addWidget( textLabel2_3_3_2_2 );

    textLabel2_3_3_2_2_2 = new QLabel( buttonGroup2ndHeader, "textLabel2_3_3_2_2_2" );
    textLabel2_3_3_2_2_2->setEnabled( TRUE );
    textLabel2_3_3_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel2_3_3_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_3_3_2_2_2->setMinimumSize( QSize( 0, 22 ) );
    textLabel2_3_3_2_2_2->setMaximumSize( QSize( 32767, 22 ) );
    textLabel2_3_3_2_2_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel2_3_3_2_2_2_font(  textLabel2_3_3_2_2_2->font() );
    textLabel2_3_3_2_2_2_font.setFamily( "Lucida Grande" );
    textLabel2_3_3_2_2_2_font.setBold( FALSE );
    textLabel2_3_3_2_2_2->setFont( textLabel2_3_3_2_2_2_font ); 
    layout92->addWidget( textLabel2_3_3_2_2_2 );

    textLabel2_3_3_2_2_2_2 = new QLabel( buttonGroup2ndHeader, "textLabel2_3_3_2_2_2_2" );
    textLabel2_3_3_2_2_2_2->setEnabled( TRUE );
    textLabel2_3_3_2_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel2_3_3_2_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_3_3_2_2_2_2->setMinimumSize( QSize( 0, 22 ) );
    textLabel2_3_3_2_2_2_2->setMaximumSize( QSize( 32767, 22 ) );
    textLabel2_3_3_2_2_2_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel2_3_3_2_2_2_2_font(  textLabel2_3_3_2_2_2_2->font() );
    textLabel2_3_3_2_2_2_2_font.setFamily( "Lucida Grande" );
    textLabel2_3_3_2_2_2_2_font.setBold( FALSE );
    textLabel2_3_3_2_2_2_2->setFont( textLabel2_3_3_2_2_2_2_font ); 
    layout92->addWidget( textLabel2_3_3_2_2_2_2 );
    layout93->addLayout( layout92 );

    checkBoxYes2ndHeader = new QButtonGroup( buttonGroup2ndHeader, "checkBoxYes2ndHeader" );
    checkBoxYes2ndHeader->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, checkBoxYes2ndHeader->sizePolicy().hasHeightForWidth() ) );
    checkBoxYes2ndHeader->setMaximumSize( QSize( 160, 32767 ) );
    checkBoxYes2ndHeader->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 246, 246, 246) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxYes2ndHeader->setPalette( pal );
    QFont checkBoxYes2ndHeader_font(  checkBoxYes2ndHeader->font() );
    checkBoxYes2ndHeader_font.setBold( FALSE );
    checkBoxYes2ndHeader->setFont( checkBoxYes2ndHeader_font ); 
    checkBoxYes2ndHeader->setLineWidth( 1 );
    checkBoxYes2ndHeader->setCheckable( TRUE );
    checkBoxYes2ndHeader->setColumnLayout(0, Qt::Vertical );
    checkBoxYes2ndHeader->layout()->setSpacing( 4 );
    checkBoxYes2ndHeader->layout()->setMargin( 3 );
    checkBoxYes2ndHeaderLayout = new QVBoxLayout( checkBoxYes2ndHeader->layout() );
    checkBoxYes2ndHeaderLayout->setAlignment( Qt::AlignTop );
    spacer40_2_2_2 = new QSpacerItem( 5, 0, QSizePolicy::Minimum, QSizePolicy::Expanding );
    checkBoxYes2ndHeaderLayout->addItem( spacer40_2_2_2 );

    lineEditWildCard2ndHeader = new QLineEdit( checkBoxYes2ndHeader, "lineEditWildCard2ndHeader" );
    lineEditWildCard2ndHeader->setEnabled( TRUE );
    lineEditWildCard2ndHeader->setMinimumSize( QSize( 0, 22 ) );
    lineEditWildCard2ndHeader->setMaximumSize( QSize( 32767, 22 ) );
    lineEditWildCard2ndHeader->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditWildCard2ndHeader->setFrameShape( QLineEdit::LineEditPanel );
    lineEditWildCard2ndHeader->setLineWidth( 1 );
    checkBoxYes2ndHeaderLayout->addWidget( lineEditWildCard2ndHeader );

    spinBoxHeaderNumberLines2ndHeader = new QSpinBox( checkBoxYes2ndHeader, "spinBoxHeaderNumberLines2ndHeader" );
    spinBoxHeaderNumberLines2ndHeader->setEnabled( TRUE );
    spinBoxHeaderNumberLines2ndHeader->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxHeaderNumberLines2ndHeader->sizePolicy().hasHeightForWidth() ) );
    spinBoxHeaderNumberLines2ndHeader->setMinimumSize( QSize( 0, 22 ) );
    spinBoxHeaderNumberLines2ndHeader->setMaximumSize( QSize( 32767, 22 ) );
    spinBoxHeaderNumberLines2ndHeader->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxHeaderNumberLines2ndHeader->setMaxValue( 2147483647 );
    spinBoxHeaderNumberLines2ndHeader->setValue( 0 );
    checkBoxYes2ndHeaderLayout->addWidget( spinBoxHeaderNumberLines2ndHeader );
    spacer47 = new QSpacerItem( 5, 22, QSizePolicy::Expanding, QSizePolicy::Minimum );
    checkBoxYes2ndHeaderLayout->addItem( spacer47 );
    spacer48_2 = new QSpacerItem( 5, 22, QSizePolicy::Expanding, QSizePolicy::Minimum );
    checkBoxYes2ndHeaderLayout->addItem( spacer48_2 );
    layout93->addWidget( checkBoxYes2ndHeader );

    checkBoxYes2ndHeader_2 = new QButtonGroup( buttonGroup2ndHeader, "checkBoxYes2ndHeader_2" );
    checkBoxYes2ndHeader_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, checkBoxYes2ndHeader_2->sizePolicy().hasHeightForWidth() ) );
    checkBoxYes2ndHeader_2->setMaximumSize( QSize( 160, 32767 ) );
    checkBoxYes2ndHeader_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont checkBoxYes2ndHeader_2_font(  checkBoxYes2ndHeader_2->font() );
    checkBoxYes2ndHeader_2_font.setBold( FALSE );
    checkBoxYes2ndHeader_2->setFont( checkBoxYes2ndHeader_2_font ); 
    checkBoxYes2ndHeader_2->setLineWidth( 1 );
    checkBoxYes2ndHeader_2->setMargin( 0 );
    checkBoxYes2ndHeader_2->setCheckable( FALSE );
    checkBoxYes2ndHeader_2->setExclusive( FALSE );
    checkBoxYes2ndHeader_2->setRadioButtonExclusive( TRUE );
    checkBoxYes2ndHeader_2->setColumnLayout(0, Qt::Vertical );
    checkBoxYes2ndHeader_2->layout()->setSpacing( 3 );
    checkBoxYes2ndHeader_2->layout()->setMargin( 4 );
    checkBoxYes2ndHeader_2Layout = new QVBoxLayout( checkBoxYes2ndHeader_2->layout() );
    checkBoxYes2ndHeader_2Layout->setAlignment( Qt::AlignTop );
    spacer40_2_2 = new QSpacerItem( 5, 0, QSizePolicy::Minimum, QSizePolicy::Expanding );
    checkBoxYes2ndHeader_2Layout->addItem( spacer40_2_2 );

    lineEditWildCard = new QLineEdit( checkBoxYes2ndHeader_2, "lineEditWildCard" );
    lineEditWildCard->setEnabled( TRUE );
    lineEditWildCard->setMinimumSize( QSize( 0, 22 ) );
    lineEditWildCard->setMaximumSize( QSize( 32767, 22 ) );
    lineEditWildCard->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditWildCard->setFrameShape( QLineEdit::LineEditPanel );
    lineEditWildCard->setLineWidth( 1 );
    checkBoxYes2ndHeader_2Layout->addWidget( lineEditWildCard );

    spinBoxHeaderNumberLines = new QSpinBox( checkBoxYes2ndHeader_2, "spinBoxHeaderNumberLines" );
    spinBoxHeaderNumberLines->setEnabled( TRUE );
    spinBoxHeaderNumberLines->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxHeaderNumberLines->sizePolicy().hasHeightForWidth() ) );
    spinBoxHeaderNumberLines->setMinimumSize( QSize( 0, 22 ) );
    spinBoxHeaderNumberLines->setMaximumSize( QSize( 32767, 22 ) );
    spinBoxHeaderNumberLines->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxHeaderNumberLines->setMaxValue( 2147483647 );
    spinBoxHeaderNumberLines->setValue( 70 );
    checkBoxYes2ndHeader_2Layout->addWidget( spinBoxHeaderNumberLines );

    spinBoxDataHeaderNumberLines = new QSpinBox( checkBoxYes2ndHeader_2, "spinBoxDataHeaderNumberLines" );
    spinBoxDataHeaderNumberLines->setEnabled( TRUE );
    spinBoxDataHeaderNumberLines->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxDataHeaderNumberLines->sizePolicy().hasHeightForWidth() ) );
    spinBoxDataHeaderNumberLines->setMinimumSize( QSize( 0, 22 ) );
    spinBoxDataHeaderNumberLines->setMaximumSize( QSize( 32767, 22 ) );
    spinBoxDataHeaderNumberLines->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxDataHeaderNumberLines->setMaxValue( 2147483647 );
    spinBoxDataHeaderNumberLines->setValue( 0 );
    checkBoxYes2ndHeader_2Layout->addWidget( spinBoxDataHeaderNumberLines );

    spinBoxDataLinesBetweenFrames = new QSpinBox( checkBoxYes2ndHeader_2, "spinBoxDataLinesBetweenFrames" );
    spinBoxDataLinesBetweenFrames->setEnabled( TRUE );
    spinBoxDataLinesBetweenFrames->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxDataLinesBetweenFrames->sizePolicy().hasHeightForWidth() ) );
    spinBoxDataLinesBetweenFrames->setMinimumSize( QSize( 0, 22 ) );
    spinBoxDataLinesBetweenFrames->setMaximumSize( QSize( 32767, 22 ) );
    spinBoxDataLinesBetweenFrames->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxDataLinesBetweenFrames->setMaxValue( 2147483647 );
    spinBoxDataLinesBetweenFrames->setValue( 0 );
    checkBoxYes2ndHeader_2Layout->addWidget( spinBoxDataLinesBetweenFrames );
    layout93->addWidget( checkBoxYes2ndHeader_2 );
    buttonGroup2ndHeaderLayout->addLayout( layout93 );

    layout132 = new QHBoxLayout( 0, 0, 6, "layout132"); 
    spacer79 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout132->addItem( spacer79 );

    checkBoxTiff = new QCheckBox( buttonGroup2ndHeader, "checkBoxTiff" );
    checkBoxTiff->setEnabled( TRUE );
    checkBoxTiff->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, checkBoxTiff->sizePolicy().hasHeightForWidth() ) );
    checkBoxTiff->setMinimumSize( QSize( 160, 20 ) );
    checkBoxTiff->setMaximumSize( QSize( 32767, 20 ) );
    checkBoxTiff->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxTiff->setPalette( pal );
    QFont checkBoxTiff_font(  checkBoxTiff->font() );
    checkBoxTiff_font.setBold( FALSE );
    checkBoxTiff->setFont( checkBoxTiff_font ); 
    layout132->addWidget( checkBoxTiff );
    buttonGroup2ndHeaderLayout->addLayout( layout132 );

    checkBoxRemoveNonePrint = new QCheckBox( buttonGroup2ndHeader, "checkBoxRemoveNonePrint" );
    checkBoxRemoveNonePrint->setEnabled( TRUE );
    checkBoxRemoveNonePrint->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, checkBoxRemoveNonePrint->sizePolicy().hasHeightForWidth() ) );
    checkBoxRemoveNonePrint->setMinimumSize( QSize( 0, 20 ) );
    checkBoxRemoveNonePrint->setMaximumSize( QSize( 32767, 20 ) );
    checkBoxRemoveNonePrint->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxRemoveNonePrint->setPalette( pal );
    QFont checkBoxRemoveNonePrint_font(  checkBoxRemoveNonePrint->font() );
    checkBoxRemoveNonePrint_font.setBold( FALSE );
    checkBoxRemoveNonePrint->setFont( checkBoxRemoveNonePrint_font ); 
    buttonGroup2ndHeaderLayout->addWidget( checkBoxRemoveNonePrint );
    spacer72 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    buttonGroup2ndHeaderLayout->addItem( spacer72 );
    page2Layout_2->addWidget( buttonGroup2ndHeader );
    spacer82 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page2Layout_2->addItem( spacer82 );
    toolBoxCONFIG->addItem( page2_2, QString::fromLatin1("") );

    page = new QWidget( toolBoxCONFIG, "page" );
    page->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout = new QVBoxLayout( page, 11, 6, "pageLayout"); 

    comboBoxHeaderFormat = new QComboBox( FALSE, page, "comboBoxHeaderFormat" );
    comboBoxHeaderFormat->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxHeaderFormat->sizePolicy().hasHeightForWidth() ) );
    comboBoxHeaderFormat->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    comboBoxHeaderFormat->setPalette( pal );
    QFont comboBoxHeaderFormat_font(  comboBoxHeaderFormat->font() );
    comboBoxHeaderFormat_font.setBold( TRUE );
    comboBoxHeaderFormat->setFont( comboBoxHeaderFormat_font ); 
    pageLayout->addWidget( comboBoxHeaderFormat );

    buttonGroupXMLbase = new QButtonGroup( page, "buttonGroupXMLbase" );
    buttonGroupXMLbase->setLineWidth( 0 );
    buttonGroupXMLbase->setColumnLayout(0, Qt::Vertical );
    buttonGroupXMLbase->layout()->setSpacing( 0 );
    buttonGroupXMLbase->layout()->setMargin( 0 );
    buttonGroupXMLbaseLayout = new QHBoxLayout( buttonGroupXMLbase->layout() );
    buttonGroupXMLbaseLayout->setAlignment( Qt::AlignTop );

    textLabel1_11_3 = new QLabel( buttonGroupXMLbase, "textLabel1_11_3" );
    textLabel1_11_3->setMinimumSize( QSize( 0, 20 ) );
    textLabel1_11_3->setMaximumSize( QSize( 32767, 20 ) );
    textLabel1_11_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabel1_11_3_font(  textLabel1_11_3->font() );
    textLabel1_11_3_font.setBold( TRUE );
    textLabel1_11_3->setFont( textLabel1_11_3_font ); 
    buttonGroupXMLbaseLayout->addWidget( textLabel1_11_3 );

    lineEditXMLbase = new QLineEdit( buttonGroupXMLbase, "lineEditXMLbase" );
    lineEditXMLbase->setMinimumSize( QSize( 0, 20 ) );
    lineEditXMLbase->setMaximumSize( QSize( 32767, 20 ) );
    lineEditXMLbase->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont lineEditXMLbase_font(  lineEditXMLbase->font() );
    lineEditXMLbase->setFont( lineEditXMLbase_font ); 
    buttonGroupXMLbaseLayout->addWidget( lineEditXMLbase );
    pageLayout->addWidget( buttonGroupXMLbase );

    buttonGroupFlexibleHeader = new QButtonGroup( page, "buttonGroupFlexibleHeader" );
    buttonGroupFlexibleHeader->setLineWidth( 0 );
    buttonGroupFlexibleHeader->setColumnLayout(0, Qt::Vertical );
    buttonGroupFlexibleHeader->layout()->setSpacing( 2 );
    buttonGroupFlexibleHeader->layout()->setMargin( 0 );
    buttonGroupFlexibleHeaderLayout = new QHBoxLayout( buttonGroupFlexibleHeader->layout() );
    buttonGroupFlexibleHeaderLayout->setAlignment( Qt::AlignTop );

    checkBoxHeaderFlexibility = new QCheckBox( buttonGroupFlexibleHeader, "checkBoxHeaderFlexibility" );
    checkBoxHeaderFlexibility->setEnabled( TRUE );
    checkBoxHeaderFlexibility->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, checkBoxHeaderFlexibility->sizePolicy().hasHeightForWidth() ) );
    checkBoxHeaderFlexibility->setMinimumSize( QSize( 0, 20 ) );
    checkBoxHeaderFlexibility->setMaximumSize( QSize( 32767, 20 ) );
    checkBoxHeaderFlexibility->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxHeaderFlexibility->setPalette( pal );
    QFont checkBoxHeaderFlexibility_font(  checkBoxHeaderFlexibility->font() );
    checkBoxHeaderFlexibility->setFont( checkBoxHeaderFlexibility_font ); 
    buttonGroupFlexibleHeaderLayout->addWidget( checkBoxHeaderFlexibility );

    textLabel1_8 = new QLabel( buttonGroupFlexibleHeader, "textLabel1_8" );
    textLabel1_8->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel1_8->sizePolicy().hasHeightForWidth() ) );
    textLabel1_8->setMinimumSize( QSize( 0, 20 ) );
    textLabel1_8->setMaximumSize( QSize( 130, 20 ) );
    textLabel1_8->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabel1_8_font(  textLabel1_8->font() );
    textLabel1_8_font.setBold( TRUE );
    textLabel1_8->setFont( textLabel1_8_font ); 
    textLabel1_8->setAlignment( int( QLabel::AlignVCenter ) );
    buttonGroupFlexibleHeaderLayout->addWidget( textLabel1_8 );

    lineEditFlexiStop = new QLineEdit( buttonGroupFlexibleHeader, "lineEditFlexiStop" );
    lineEditFlexiStop->setEnabled( TRUE );
    lineEditFlexiStop->setMinimumSize( QSize( 0, 20 ) );
    lineEditFlexiStop->setMaximumSize( QSize( 1400, 20 ) );
    lineEditFlexiStop->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont lineEditFlexiStop_font(  lineEditFlexiStop->font() );
    lineEditFlexiStop->setFont( lineEditFlexiStop_font ); 
    lineEditFlexiStop->setFrameShape( QLineEdit::LineEditPanel );
    lineEditFlexiStop->setLineWidth( 1 );
    buttonGroupFlexibleHeaderLayout->addWidget( lineEditFlexiStop );
    pageLayout->addWidget( buttonGroupFlexibleHeader );

    tableHeaderPos = new QTable( page, "tableHeaderPos" );
    tableHeaderPos->setNumCols( tableHeaderPos->numCols() + 1 );
    tableHeaderPos->horizontalHeader()->setLabel( tableHeaderPos->numCols() - 1, tr( "#-Line" ) );
    tableHeaderPos->setNumCols( tableHeaderPos->numCols() + 1 );
    tableHeaderPos->horizontalHeader()->setLabel( tableHeaderPos->numCols() - 1, tr( "#-Pos" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Experiment-Title]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[User-Name]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Sample-Run-Number]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Sample-Title]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Sample-Thickness]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Sample-Position-Number]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Date]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Time]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[C]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[D]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[D-TOF]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[C,D-Offset]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[CA-X]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[CA-Y]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[SA-X]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[SA-Y]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Sum]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Selector]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Lambda]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Delta-Lambda]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Duration]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Duration-Factor]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Monitor-1]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Monitor-2]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Monitor-3|Tr|ROI]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Comment1]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Comment2]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Detector-X || Beamcenter-X]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Detector-Y || Beamcenter-Y]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Sample-Motor-1]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Sample-Motor-2]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Sample-Motor-3]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Sample-Motor-4]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Sample-Motor-5]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[SA-Pos-X]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[SA-Pos-Y]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Field-1]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Field-2]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Field-3]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Field-4]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[RT-Number-Repetitions]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[RT-Time-Factor]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[RT-Current-Number]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Attenuator]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Polarization]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Lenses]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Slices-Count]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Slices-Duration]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Slices-Current-Number]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Slices-Current-Duration]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Slices-Current-Monitor1]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Slices-Current-Monitor2]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Slices-Current-Monitor3]" ) );
    tableHeaderPos->setNumRows( tableHeaderPos->numRows() + 1 );
    tableHeaderPos->verticalHeader()->setLabel( tableHeaderPos->numRows() - 1, tr( "[Slices-Current-Sum]" ) );
    tableHeaderPos->setEnabled( TRUE );
    tableHeaderPos->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, tableHeaderPos->sizePolicy().hasHeightForWidth() ) );
    tableHeaderPos->setMinimumSize( QSize( 0, 1200 ) );
    tableHeaderPos->setMaximumSize( QSize( 32767, 32000 ) );
    tableHeaderPos->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    tableHeaderPos->setPalette( pal );
    QFont tableHeaderPos_font(  tableHeaderPos->font() );
    tableHeaderPos->setFont( tableHeaderPos_font ); 
    tableHeaderPos->setLineWidth( 1 );
    tableHeaderPos->setResizePolicy( QTable::Default );
    tableHeaderPos->setVScrollBarMode( QTable::AlwaysOff );
    tableHeaderPos->setNumRows( 54 );
    tableHeaderPos->setNumCols( 2 );
    pageLayout->addWidget( tableHeaderPos );
    toolBoxCONFIG->addItem( page, QString::fromLatin1("") );

    page_2 = new QWidget( toolBoxCONFIG, "page_2" );
    page_2->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_2 = new QVBoxLayout( page_2, 11, 6, "pageLayout_2"); 

    buttonGroupSel = new QButtonGroup( page_2, "buttonGroupSel" );
    buttonGroupSel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroupSel->sizePolicy().hasHeightForWidth() ) );
    buttonGroupSel->setMinimumSize( QSize( 0, 20 ) );
    buttonGroupSel->setMaximumSize( QSize( 32767, 80 ) );
    buttonGroupSel->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroupSel->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 246, 246, 246) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    buttonGroupSel->setPalette( pal );
    QFont buttonGroupSel_font(  buttonGroupSel->font() );
    buttonGroupSel_font.setBold( TRUE );
    buttonGroupSel->setFont( buttonGroupSel_font ); 
    buttonGroupSel->setFrameShape( QButtonGroup::NoFrame );
    buttonGroupSel->setFrameShadow( QButtonGroup::Plain );
    buttonGroupSel->setLineWidth( 0 );
    buttonGroupSel->setCheckable( FALSE );
    buttonGroupSel->setChecked( FALSE );
    buttonGroupSel->setColumnLayout(0, Qt::Vertical );
    buttonGroupSel->layout()->setSpacing( 2 );
    buttonGroupSel->layout()->setMargin( 11 );
    buttonGroupSelLayout = new QHBoxLayout( buttonGroupSel->layout() );
    buttonGroupSelLayout->setAlignment( Qt::AlignTop );

    radioButtonLambdaF = new QRadioButton( buttonGroupSel, "radioButtonLambdaF" );
    radioButtonLambdaF->setEnabled( TRUE );
    radioButtonLambdaF->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, radioButtonLambdaF->sizePolicy().hasHeightForWidth() ) );
    radioButtonLambdaF->setMinimumSize( QSize( 20, 0 ) );
    radioButtonLambdaF->setMaximumSize( QSize( 50, 32767 ) );
    radioButtonLambdaF->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 246, 246, 246) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    radioButtonLambdaF->setPalette( pal );
    QFont radioButtonLambdaF_font(  radioButtonLambdaF->font() );
    radioButtonLambdaF_font.setBold( FALSE );
    radioButtonLambdaF->setFont( radioButtonLambdaF_font ); 
    radioButtonLambdaF->setChecked( TRUE );
    buttonGroupSelLayout->addWidget( radioButtonLambdaF );

    lineEditSel1 = new QLineEdit( buttonGroupSel, "lineEditSel1" );
    lineEditSel1->setEnabled( TRUE );
    lineEditSel1->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, lineEditSel1->sizePolicy().hasHeightForWidth() ) );
    lineEditSel1->setMaximumSize( QSize( 80, 25 ) );
    lineEditSel1->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    lineEditSel1->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    lineEditSel1->setPalette( pal );
    QFont lineEditSel1_font(  lineEditSel1->font() );
    lineEditSel1_font.setBold( FALSE );
    lineEditSel1->setFont( lineEditSel1_font ); 
    lineEditSel1->setFrameShape( QLineEdit::Box );
    lineEditSel1->setLineWidth( 1 );
    buttonGroupSelLayout->addWidget( lineEditSel1 );

    textLabel2_5_2 = new QLabel( buttonGroupSel, "textLabel2_5_2" );
    textLabel2_5_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel2_5_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_5_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel2_5_2_font(  textLabel2_5_2->font() );
    textLabel2_5_2_font.setFamily( "Lucida Grande" );
    textLabel2_5_2_font.setPointSize( 13 );
    textLabel2_5_2_font.setBold( FALSE );
    textLabel2_5_2->setFont( textLabel2_5_2_font ); 
    buttonGroupSelLayout->addWidget( textLabel2_5_2 );

    lineEditSel2 = new QLineEdit( buttonGroupSel, "lineEditSel2" );
    lineEditSel2->setEnabled( TRUE );
    lineEditSel2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, lineEditSel2->sizePolicy().hasHeightForWidth() ) );
    lineEditSel2->setMaximumSize( QSize( 80, 25 ) );
    lineEditSel2->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont lineEditSel2_font(  lineEditSel2->font() );
    lineEditSel2_font.setBold( FALSE );
    lineEditSel2->setFont( lineEditSel2_font ); 
    lineEditSel2->setFrameShape( QLineEdit::Box );
    lineEditSel2->setLineWidth( 1 );
    buttonGroupSelLayout->addWidget( lineEditSel2 );

    radioButtonLambdaHeader = new QRadioButton( buttonGroupSel, "radioButtonLambdaHeader" );
    radioButtonLambdaHeader->setEnabled( TRUE );
    radioButtonLambdaHeader->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, radioButtonLambdaHeader->sizePolicy().hasHeightForWidth() ) );
    radioButtonLambdaHeader->setMinimumSize( QSize( 30, 0 ) );
    radioButtonLambdaHeader->setMaximumSize( QSize( 1850, 32767 ) );
    radioButtonLambdaHeader->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 246, 246, 246) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    radioButtonLambdaHeader->setPalette( pal );
    QFont radioButtonLambdaHeader_font(  radioButtonLambdaHeader->font() );
    radioButtonLambdaHeader_font.setBold( FALSE );
    radioButtonLambdaHeader->setFont( radioButtonLambdaHeader_font ); 
    buttonGroupSelLayout->addWidget( radioButtonLambdaHeader );
    pageLayout_2->addWidget( buttonGroupSel );
    spacer80_2 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_2->addItem( spacer80_2 );
    toolBoxCONFIG->addItem( page_2, QString::fromLatin1("") );

    page_3 = new QWidget( toolBoxCONFIG, "page_3" );
    page_3->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_3 = new QVBoxLayout( page_3, 0, 0, "pageLayout_3"); 

    buttonGroupDetectorImage = new QButtonGroup( page_3, "buttonGroupDetectorImage" );
    buttonGroupDetectorImage->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, buttonGroupDetectorImage->sizePolicy().hasHeightForWidth() ) );
    buttonGroupDetectorImage->setMinimumSize( QSize( 0, 300 ) );
    buttonGroupDetectorImage->setMaximumSize( QSize( 15000, 300 ) );
    buttonGroupDetectorImage->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroupDetectorImage->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    buttonGroupDetectorImage->setPalette( pal );
    QFont buttonGroupDetectorImage_font(  buttonGroupDetectorImage->font() );
    buttonGroupDetectorImage_font.setBold( TRUE );
    buttonGroupDetectorImage->setFont( buttonGroupDetectorImage_font ); 
    buttonGroupDetectorImage->setFrameShape( QButtonGroup::NoFrame );
    buttonGroupDetectorImage->setFrameShadow( QButtonGroup::Plain );
    buttonGroupDetectorImage->setLineWidth( 0 );
    buttonGroupDetectorImage->setCheckable( FALSE );
    buttonGroupDetectorImage->setColumnLayout(0, Qt::Vertical );
    buttonGroupDetectorImage->layout()->setSpacing( 2 );
    buttonGroupDetectorImage->layout()->setMargin( 11 );
    buttonGroupDetectorImageLayout = new QVBoxLayout( buttonGroupDetectorImage->layout() );
    buttonGroupDetectorImageLayout->setAlignment( Qt::AlignTop );

    layout94 = new QHBoxLayout( 0, 0, 6, "layout94"); 

    layout79 = new QVBoxLayout( 0, 0, 2, "layout79"); 
    spacer27_2 = new QSpacerItem( 20, 22, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout79->addItem( spacer27_2 );

    line3 = new QFrame( buttonGroupDetectorImage, "line3" );
    line3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, line3->sizePolicy().hasHeightForWidth() ) );
    line3->setFrameShape( QFrame::HLine );
    line3->setFrameShadow( QFrame::Plain );
    line3->setFrameShape( QFrame::HLine );
    layout79->addWidget( line3 );

    textLabel2_3_2_2 = new QLabel( buttonGroupDetectorImage, "textLabel2_3_2_2" );
    textLabel2_3_2_2->setEnabled( TRUE );
    textLabel2_3_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel2_3_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_3_2_2->setMinimumSize( QSize( 50, 25 ) );
    textLabel2_3_2_2->setMaximumSize( QSize( 1250, 25 ) );
    textLabel2_3_2_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel2_3_2_2_font(  textLabel2_3_2_2->font() );
    textLabel2_3_2_2_font.setFamily( "Lucida Grande" );
    textLabel2_3_2_2_font.setPointSize( 13 );
    textLabel2_3_2_2_font.setBold( FALSE );
    textLabel2_3_2_2->setFont( textLabel2_3_2_2_font ); 
    layout79->addWidget( textLabel2_3_2_2 );

    textLabel2_3_2 = new QLabel( buttonGroupDetectorImage, "textLabel2_3_2" );
    textLabel2_3_2->setEnabled( TRUE );
    textLabel2_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel2_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_3_2->setMinimumSize( QSize( 0, 25 ) );
    textLabel2_3_2->setMaximumSize( QSize( 125, 25 ) );
    textLabel2_3_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel2_3_2_font(  textLabel2_3_2->font() );
    textLabel2_3_2_font.setFamily( "Lucida Grande" );
    textLabel2_3_2_font.setPointSize( 13 );
    textLabel2_3_2_font.setBold( FALSE );
    textLabel2_3_2->setFont( textLabel2_3_2_font ); 
    layout79->addWidget( textLabel2_3_2 );

    textLabel1_3_2_3 = new QLabel( buttonGroupDetectorImage, "textLabel1_3_2_3" );
    textLabel1_3_2_3->setEnabled( TRUE );
    textLabel1_3_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_3_2_3->sizePolicy().hasHeightForWidth() ) );
    textLabel1_3_2_3->setMinimumSize( QSize( 50, 25 ) );
    textLabel1_3_2_3->setMaximumSize( QSize( 1700, 25 ) );
    textLabel1_3_2_3->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel1_3_2_3_font(  textLabel1_3_2_3->font() );
    textLabel1_3_2_3_font.setFamily( "Lucida Grande" );
    textLabel1_3_2_3_font.setBold( FALSE );
    textLabel1_3_2_3->setFont( textLabel1_3_2_3_font ); 
    layout79->addWidget( textLabel1_3_2_3 );

    textLabel2_3 = new QLabel( buttonGroupDetectorImage, "textLabel2_3" );
    textLabel2_3->setEnabled( TRUE );
    textLabel2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, textLabel2_3->sizePolicy().hasHeightForWidth() ) );
    textLabel2_3->setMinimumSize( QSize( 50, 25 ) );
    textLabel2_3->setMaximumSize( QSize( 125, 25 ) );
    textLabel2_3->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel2_3_font(  textLabel2_3->font() );
    textLabel2_3_font.setFamily( "Lucida Grande" );
    textLabel2_3_font.setBold( FALSE );
    textLabel2_3->setFont( textLabel2_3_font ); 
    layout79->addWidget( textLabel2_3 );

    textLabelResoPixelSize = new QLabel( buttonGroupDetectorImage, "textLabelResoPixelSize" );
    textLabelResoPixelSize->setEnabled( TRUE );
    textLabelResoPixelSize->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabelResoPixelSize->sizePolicy().hasHeightForWidth() ) );
    textLabelResoPixelSize->setMinimumSize( QSize( 12, 25 ) );
    textLabelResoPixelSize->setMaximumSize( QSize( 135, 25 ) );
    textLabelResoPixelSize->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabelResoPixelSize_font(  textLabelResoPixelSize->font() );
    textLabelResoPixelSize_font.setFamily( "Lucida Grande" );
    textLabelResoPixelSize_font.setBold( FALSE );
    textLabelResoPixelSize->setFont( textLabelResoPixelSize_font ); 
    layout79->addWidget( textLabelResoPixelSize );

    textLabelResoPixelSize_2_2 = new QLabel( buttonGroupDetectorImage, "textLabelResoPixelSize_2_2" );
    textLabelResoPixelSize_2_2->setEnabled( TRUE );
    textLabelResoPixelSize_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelResoPixelSize_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelResoPixelSize_2_2->setMinimumSize( QSize( 50, 25 ) );
    textLabelResoPixelSize_2_2->setMaximumSize( QSize( 140, 25 ) );
    textLabelResoPixelSize_2_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabelResoPixelSize_2_2_font(  textLabelResoPixelSize_2_2->font() );
    textLabelResoPixelSize_2_2_font.setFamily( "Lucida Grande" );
    textLabelResoPixelSize_2_2_font.setBold( FALSE );
    textLabelResoPixelSize_2_2->setFont( textLabelResoPixelSize_2_2_font ); 
    layout79->addWidget( textLabelResoPixelSize_2_2 );

    textLabel1_3 = new QLabel( buttonGroupDetectorImage, "textLabel1_3" );
    textLabel1_3->setEnabled( TRUE );
    textLabel1_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel1_3->sizePolicy().hasHeightForWidth() ) );
    textLabel1_3->setMinimumSize( QSize( 0, 25 ) );
    textLabel1_3->setMaximumSize( QSize( 1250, 25 ) );
    textLabel1_3->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel1_3_font(  textLabel1_3->font() );
    textLabel1_3_font.setFamily( "Lucida Grande" );
    textLabel1_3_font.setBold( FALSE );
    textLabel1_3->setFont( textLabel1_3_font ); 
    textLabel1_3->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );
    layout79->addWidget( textLabel1_3 );

    textLabel1_3_2 = new QLabel( buttonGroupDetectorImage, "textLabel1_3_2" );
    textLabel1_3_2->setEnabled( TRUE );
    textLabel1_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel1_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_3_2->setMinimumSize( QSize( 0, 25 ) );
    textLabel1_3_2->setMaximumSize( QSize( 1250, 25 ) );
    textLabel1_3_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel1_3_2_font(  textLabel1_3_2->font() );
    textLabel1_3_2_font.setFamily( "Lucida Grande" );
    textLabel1_3_2_font.setBold( FALSE );
    textLabel1_3_2->setFont( textLabel1_3_2_font ); 
    textLabel1_3_2->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );
    layout79->addWidget( textLabel1_3_2 );
    layout94->addLayout( layout79 );

    line2 = new QFrame( buttonGroupDetectorImage, "line2" );
    line2->setFrameShape( QFrame::VLine );
    line2->setFrameShadow( QFrame::Plain );
    line2->setLineWidth( 1 );
    line2->setFrameShape( QFrame::VLine );
    layout94->addWidget( line2 );

    layout58_3 = new QVBoxLayout( 0, 0, 2, "layout58_3"); 

    textLabel3_3 = new QLabel( buttonGroupDetectorImage, "textLabel3_3" );
    textLabel3_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, textLabel3_3->sizePolicy().hasHeightForWidth() ) );
    textLabel3_3->setMinimumSize( QSize( 0, 22 ) );
    textLabel3_3->setMaximumSize( QSize( 32767, 22 ) );
    textLabel3_3->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel3_3_font(  textLabel3_3->font() );
    textLabel3_3_font.setFamily( "Lucida Grande" );
    textLabel3_3_font.setBold( FALSE );
    textLabel3_3->setFont( textLabel3_3_font ); 
    textLabel3_3->setAlignment( int( QLabel::AlignCenter ) );
    layout58_3->addWidget( textLabel3_3 );

    line4 = new QFrame( buttonGroupDetectorImage, "line4" );
    line4->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, line4->sizePolicy().hasHeightForWidth() ) );
    line4->setFrameShape( QFrame::HLine );
    line4->setFrameShadow( QFrame::Plain );
    line4->setFrameShape( QFrame::HLine );
    layout58_3->addWidget( line4 );
    spacer30_2 = new QSpacerItem( 20, 22, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout58_3->addItem( spacer30_2 );
    spacer30 = new QSpacerItem( 20, 22, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout58_3->addItem( spacer30 );

    spinBoxReadMatrixNumberPerLine = new QSpinBox( buttonGroupDetectorImage, "spinBoxReadMatrixNumberPerLine" );
    spinBoxReadMatrixNumberPerLine->setEnabled( TRUE );
    spinBoxReadMatrixNumberPerLine->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxReadMatrixNumberPerLine->sizePolicy().hasHeightForWidth() ) );
    spinBoxReadMatrixNumberPerLine->setMinimumSize( QSize( 30, 25 ) );
    spinBoxReadMatrixNumberPerLine->setMaximumSize( QSize( 1000, 25 ) );
    spinBoxReadMatrixNumberPerLine->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxReadMatrixNumberPerLine->setPalette( pal );
    spinBoxReadMatrixNumberPerLine->setBackgroundOrigin( QSpinBox::WidgetOrigin );
    QFont spinBoxReadMatrixNumberPerLine_font(  spinBoxReadMatrixNumberPerLine->font() );
    spinBoxReadMatrixNumberPerLine_font.setBold( FALSE );
    spinBoxReadMatrixNumberPerLine->setFont( spinBoxReadMatrixNumberPerLine_font ); 
    spinBoxReadMatrixNumberPerLine->setButtonSymbols( QSpinBox::UpDownArrows );
    spinBoxReadMatrixNumberPerLine->setMaxValue( 10000 );
    spinBoxReadMatrixNumberPerLine->setMinValue( 1 );
    spinBoxReadMatrixNumberPerLine->setValue( 8 );
    layout58_3->addWidget( spinBoxReadMatrixNumberPerLine );

    comboBoxMDdata = new QComboBox( FALSE, buttonGroupDetectorImage, "comboBoxMDdata" );
    comboBoxMDdata->setEnabled( TRUE );
    comboBoxMDdata->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxMDdata->sizePolicy().hasHeightForWidth() ) );
    comboBoxMDdata->setMinimumSize( QSize( 30, 25 ) );
    comboBoxMDdata->setMaximumSize( QSize( 1000, 25 ) );
    comboBoxMDdata->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxMDdata->setPalette( pal );
    QFont comboBoxMDdata_font(  comboBoxMDdata->font() );
    comboBoxMDdata_font.setBold( FALSE );
    comboBoxMDdata->setFont( comboBoxMDdata_font ); 
    layout58_3->addWidget( comboBoxMDdata );

    lineEditResoPixelSize = new QLineEdit( buttonGroupDetectorImage, "lineEditResoPixelSize" );
    lineEditResoPixelSize->setEnabled( TRUE );
    lineEditResoPixelSize->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, lineEditResoPixelSize->sizePolicy().hasHeightForWidth() ) );
    lineEditResoPixelSize->setMinimumSize( QSize( 30, 25 ) );
    lineEditResoPixelSize->setMaximumSize( QSize( 1000, 25 ) );
    lineEditResoPixelSize->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    lineEditResoPixelSize->setPalette( pal );
    QFont lineEditResoPixelSize_font(  lineEditResoPixelSize->font() );
    lineEditResoPixelSize_font.setBold( FALSE );
    lineEditResoPixelSize->setFont( lineEditResoPixelSize_font ); 
    lineEditResoPixelSize->setFrameShape( QLineEdit::LineEditPanel );
    lineEditResoPixelSize->setLineWidth( 1 );
    layout58_3->addWidget( lineEditResoPixelSize );

    lineEditAsymetry = new QLineEdit( buttonGroupDetectorImage, "lineEditAsymetry" );
    lineEditAsymetry->setEnabled( TRUE );
    lineEditAsymetry->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, lineEditAsymetry->sizePolicy().hasHeightForWidth() ) );
    lineEditAsymetry->setMinimumSize( QSize( 30, 25 ) );
    lineEditAsymetry->setMaximumSize( QSize( 3000, 25 ) );
    lineEditAsymetry->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    lineEditAsymetry->setPalette( pal );
    QFont lineEditAsymetry_font(  lineEditAsymetry->font() );
    lineEditAsymetry_font.setBold( FALSE );
    lineEditAsymetry->setFont( lineEditAsymetry_font ); 
    lineEditAsymetry->setFrameShape( QLineEdit::LineEditPanel );
    lineEditAsymetry->setLineWidth( 1 );
    layout58_3->addWidget( lineEditAsymetry );

    spinBoxRegionOfInteres = new QSpinBox( buttonGroupDetectorImage, "spinBoxRegionOfInteres" );
    spinBoxRegionOfInteres->setEnabled( TRUE );
    spinBoxRegionOfInteres->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxRegionOfInteres->sizePolicy().hasHeightForWidth() ) );
    spinBoxRegionOfInteres->setMinimumSize( QSize( 45, 25 ) );
    spinBoxRegionOfInteres->setMaximumSize( QSize( 32767, 25 ) );
    spinBoxRegionOfInteres->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxRegionOfInteres->setPalette( pal );
    QFont spinBoxRegionOfInteres_font(  spinBoxRegionOfInteres->font() );
    spinBoxRegionOfInteres_font.setBold( FALSE );
    spinBoxRegionOfInteres->setFont( spinBoxRegionOfInteres_font ); 
    spinBoxRegionOfInteres->setMaxValue( 128 );
    spinBoxRegionOfInteres->setMinValue( 2 );
    spinBoxRegionOfInteres->setLineStep( 2 );
    spinBoxRegionOfInteres->setValue( 128 );
    layout58_3->addWidget( spinBoxRegionOfInteres );

    comboBoxBinning = new QComboBox( FALSE, buttonGroupDetectorImage, "comboBoxBinning" );
    comboBoxBinning->setEnabled( TRUE );
    comboBoxBinning->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxBinning->sizePolicy().hasHeightForWidth() ) );
    comboBoxBinning->setMinimumSize( QSize( 30, 25 ) );
    comboBoxBinning->setMaximumSize( QSize( 32767, 25 ) );
    comboBoxBinning->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxBinning->setPalette( pal );
    QFont comboBoxBinning_font(  comboBoxBinning->font() );
    comboBoxBinning_font.setBold( FALSE );
    comboBoxBinning->setFont( comboBoxBinning_font ); 
    layout58_3->addWidget( comboBoxBinning );
    layout94->addLayout( layout58_3 );

    line1 = new QFrame( buttonGroupDetectorImage, "line1" );
    line1->setFrameShape( QFrame::VLine );
    line1->setFrameShadow( QFrame::Plain );
    line1->setLineWidth( 1 );
    line1->setFrameShape( QFrame::VLine );
    layout94->addWidget( line1 );

    layout57 = new QVBoxLayout( 0, 0, 1, "layout57"); 

    textLabel4_2 = new QLabel( buttonGroupDetectorImage, "textLabel4_2" );
    textLabel4_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, textLabel4_2->sizePolicy().hasHeightForWidth() ) );
    textLabel4_2->setMinimumSize( QSize( 0, 22 ) );
    textLabel4_2->setMaximumSize( QSize( 32767, 22 ) );
    textLabel4_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabel4_2->setPalette( pal );
    QFont textLabel4_2_font(  textLabel4_2->font() );
    textLabel4_2_font.setFamily( "Lucida Grande" );
    textLabel4_2_font.setBold( FALSE );
    textLabel4_2->setFont( textLabel4_2_font ); 
    textLabel4_2->setAlignment( int( QLabel::AlignCenter ) );
    layout57->addWidget( textLabel4_2 );

    line5 = new QFrame( buttonGroupDetectorImage, "line5" );
    line5->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, line5->sizePolicy().hasHeightForWidth() ) );
    line5->setFrameShape( QFrame::HLine );
    line5->setFrameShadow( QFrame::Plain );
    line5->setFrameShape( QFrame::HLine );
    layout57->addWidget( line5 );

    checkBoxMatrixX2mX = new QCheckBox( buttonGroupDetectorImage, "checkBoxMatrixX2mX" );
    checkBoxMatrixX2mX->setEnabled( TRUE );
    checkBoxMatrixX2mX->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxMatrixX2mX->sizePolicy().hasHeightForWidth() ) );
    checkBoxMatrixX2mX->setMinimumSize( QSize( 30, 25 ) );
    checkBoxMatrixX2mX->setMaximumSize( QSize( 1000, 25 ) );
    checkBoxMatrixX2mX->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxMatrixX2mX->setPalette( pal );
    QFont checkBoxMatrixX2mX_font(  checkBoxMatrixX2mX->font() );
    checkBoxMatrixX2mX_font.setBold( FALSE );
    checkBoxMatrixX2mX->setFont( checkBoxMatrixX2mX_font ); 
    layout57->addWidget( checkBoxMatrixX2mX );

    checkBoxMatrixY2mY = new QCheckBox( buttonGroupDetectorImage, "checkBoxMatrixY2mY" );
    checkBoxMatrixY2mY->setEnabled( TRUE );
    checkBoxMatrixY2mY->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxMatrixY2mY->sizePolicy().hasHeightForWidth() ) );
    checkBoxMatrixY2mY->setMinimumSize( QSize( 30, 25 ) );
    checkBoxMatrixY2mY->setMaximumSize( QSize( 1000, 25 ) );
    checkBoxMatrixY2mY->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxMatrixY2mY->setPalette( pal );
    QFont checkBoxMatrixY2mY_font(  checkBoxMatrixY2mY->font() );
    checkBoxMatrixY2mY_font.setBold( FALSE );
    checkBoxMatrixY2mY->setFont( checkBoxMatrixY2mY_font ); 
    layout57->addWidget( checkBoxMatrixY2mY );

    checkBoxTranspose = new QCheckBox( buttonGroupDetectorImage, "checkBoxTranspose" );
    checkBoxTranspose->setEnabled( TRUE );
    checkBoxTranspose->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxTranspose->sizePolicy().hasHeightForWidth() ) );
    checkBoxTranspose->setMinimumSize( QSize( 30, 25 ) );
    checkBoxTranspose->setMaximumSize( QSize( 1000, 25 ) );
    checkBoxTranspose->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxTranspose->setPalette( pal );
    QFont checkBoxTranspose_font(  checkBoxTranspose->font() );
    checkBoxTranspose_font.setBold( FALSE );
    checkBoxTranspose->setFont( checkBoxTranspose_font ); 
    layout57->addWidget( checkBoxTranspose );

    lineEditMD = new QLineEdit( buttonGroupDetectorImage, "lineEditMD" );
    lineEditMD->setMinimumSize( QSize( 30, 25 ) );
    lineEditMD->setMaximumSize( QSize( 3000, 25 ) );
    lineEditMD->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    lineEditMD->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 63, 63, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 38, 38, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 38, 38, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    lineEditMD->setPalette( pal );
    lineEditMD->setBackgroundOrigin( QLineEdit::WidgetOrigin );
    QFont lineEditMD_font(  lineEditMD->font() );
    lineEditMD->setFont( lineEditMD_font ); 
    lineEditMD->setFrameShape( QLineEdit::Box );
    lineEditMD->setFrameShadow( QLineEdit::Raised );
    lineEditMD->setLineWidth( 1 );
    lineEditMD->setMargin( 0 );
    lineEditMD->setAlignment( int( QLineEdit::AlignHCenter ) );
    lineEditMD->setReadOnly( TRUE );
    layout57->addWidget( lineEditMD );

    lineEditPS = new QLineEdit( buttonGroupDetectorImage, "lineEditPS" );
    lineEditPS->setMinimumSize( QSize( 30, 25 ) );
    lineEditPS->setMaximumSize( QSize( 3000, 25 ) );
    lineEditPS->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    lineEditPS->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 63, 63, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 38, 38, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 38, 38, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    lineEditPS->setPalette( pal );
    lineEditPS->setBackgroundOrigin( QLineEdit::WidgetOrigin );
    QFont lineEditPS_font(  lineEditPS->font() );
    lineEditPS->setFont( lineEditPS_font ); 
    lineEditPS->setFrameShape( QLineEdit::Box );
    lineEditPS->setFrameShadow( QLineEdit::Raised );
    lineEditPS->setLineWidth( 1 );
    lineEditPS->setMargin( 0 );
    lineEditPS->setAlignment( int( QLineEdit::AlignHCenter ) );
    lineEditPS->setReadOnly( TRUE );
    layout57->addWidget( lineEditPS );

    lineEditAsymetryMatrix = new QLineEdit( buttonGroupDetectorImage, "lineEditAsymetryMatrix" );
    lineEditAsymetryMatrix->setMinimumSize( QSize( 30, 25 ) );
    lineEditAsymetryMatrix->setMaximumSize( QSize( 3000, 25 ) );
    lineEditAsymetryMatrix->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    lineEditAsymetryMatrix->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 63, 63, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 38, 38, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 38, 38, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    lineEditAsymetryMatrix->setPalette( pal );
    lineEditAsymetryMatrix->setBackgroundOrigin( QLineEdit::WidgetOrigin );
    QFont lineEditAsymetryMatrix_font(  lineEditAsymetryMatrix->font() );
    lineEditAsymetryMatrix->setFont( lineEditAsymetryMatrix_font ); 
    lineEditAsymetryMatrix->setFrameShape( QLineEdit::Box );
    lineEditAsymetryMatrix->setFrameShadow( QLineEdit::Raised );
    lineEditAsymetryMatrix->setLineWidth( 1 );
    lineEditAsymetryMatrix->setMargin( 0 );
    lineEditAsymetryMatrix->setAlignment( int( QLineEdit::AlignHCenter ) );
    lineEditAsymetryMatrix->setReadOnly( TRUE );
    layout57->addWidget( lineEditAsymetryMatrix );
    spacer32 = new QSpacerItem( 20, 22, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout57->addItem( spacer32 );
    spacer33 = new QSpacerItem( 20, 22, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout57->addItem( spacer33 );
    layout94->addLayout( layout57 );
    buttonGroupDetectorImageLayout->addLayout( layout94 );

    line2_2 = new QFrame( buttonGroupDetectorImage, "line2_2" );
    line2_2->setFrameShape( QFrame::HLine );
    line2_2->setFrameShadow( QFrame::Plain );
    line2_2->setLineWidth( 1 );
    line2_2->setFrameShape( QFrame::HLine );
    buttonGroupDetectorImageLayout->addWidget( line2_2 );

    layout95 = new QHBoxLayout( 0, 0, 6, "layout95"); 

    textLabel1_3_2_3_2 = new QLabel( buttonGroupDetectorImage, "textLabel1_3_2_3_2" );
    textLabel1_3_2_3_2->setEnabled( TRUE );
    textLabel1_3_2_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_3_2_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_3_2_3_2->setMinimumSize( QSize( 50, 25 ) );
    textLabel1_3_2_3_2->setMaximumSize( QSize( 1700, 25 ) );
    textLabel1_3_2_3_2->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel1_3_2_3_2_font(  textLabel1_3_2_3_2->font() );
    textLabel1_3_2_3_2_font.setFamily( "Lucida Grande" );
    textLabel1_3_2_3_2_font.setBold( FALSE );
    textLabel1_3_2_3_2->setFont( textLabel1_3_2_3_2_font ); 
    layout95->addWidget( textLabel1_3_2_3_2 );

    spinBoxReadMatrixTofNumberPerLine = new QSpinBox( buttonGroupDetectorImage, "spinBoxReadMatrixTofNumberPerLine" );
    spinBoxReadMatrixTofNumberPerLine->setEnabled( TRUE );
    spinBoxReadMatrixTofNumberPerLine->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxReadMatrixTofNumberPerLine->sizePolicy().hasHeightForWidth() ) );
    spinBoxReadMatrixTofNumberPerLine->setMinimumSize( QSize( 30, 25 ) );
    spinBoxReadMatrixTofNumberPerLine->setMaximumSize( QSize( 1000, 25 ) );
    spinBoxReadMatrixTofNumberPerLine->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxReadMatrixTofNumberPerLine->setPalette( pal );
    spinBoxReadMatrixTofNumberPerLine->setBackgroundOrigin( QSpinBox::WidgetOrigin );
    QFont spinBoxReadMatrixTofNumberPerLine_font(  spinBoxReadMatrixTofNumberPerLine->font() );
    spinBoxReadMatrixTofNumberPerLine_font.setBold( FALSE );
    spinBoxReadMatrixTofNumberPerLine->setFont( spinBoxReadMatrixTofNumberPerLine_font ); 
    spinBoxReadMatrixTofNumberPerLine->setButtonSymbols( QSpinBox::UpDownArrows );
    spinBoxReadMatrixTofNumberPerLine->setMaxValue( 10000 );
    spinBoxReadMatrixTofNumberPerLine->setMinValue( 1 );
    spinBoxReadMatrixTofNumberPerLine->setValue( 128 );
    layout95->addWidget( spinBoxReadMatrixTofNumberPerLine );
    buttonGroupDetectorImageLayout->addLayout( layout95 );
    pageLayout_3->addWidget( buttonGroupDetectorImage );
    spacer79_3 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_3->addItem( spacer79_3 );
    toolBoxCONFIG->addItem( page_3, QString::fromLatin1("") );

    page_4 = new QWidget( toolBoxCONFIG, "page_4" );
    page_4->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_4 = new QVBoxLayout( page_4, 0, 0, "pageLayout_4"); 

    groupBoxDeadTime = new QButtonGroup( page_4, "groupBoxDeadTime" );
    groupBoxDeadTime->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, groupBoxDeadTime->sizePolicy().hasHeightForWidth() ) );
    groupBoxDeadTime->setMinimumSize( QSize( 0, 20 ) );
    groupBoxDeadTime->setMaximumSize( QSize( 2100, 140 ) );
    groupBoxDeadTime->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBoxDeadTime->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    groupBoxDeadTime->setPalette( pal );
    QFont groupBoxDeadTime_font(  groupBoxDeadTime->font() );
    groupBoxDeadTime_font.setBold( TRUE );
    groupBoxDeadTime->setFont( groupBoxDeadTime_font ); 
    groupBoxDeadTime->setFrameShape( QButtonGroup::NoFrame );
    groupBoxDeadTime->setFrameShadow( QButtonGroup::Plain );
    groupBoxDeadTime->setLineWidth( 0 );
    groupBoxDeadTime->setCheckable( FALSE );
    groupBoxDeadTime->setColumnLayout(0, Qt::Vertical );
    groupBoxDeadTime->layout()->setSpacing( 2 );
    groupBoxDeadTime->layout()->setMargin( 11 );
    groupBoxDeadTimeLayout = new QVBoxLayout( groupBoxDeadTime->layout() );
    groupBoxDeadTimeLayout->setAlignment( Qt::AlignTop );

    layout75 = new QHBoxLayout( 0, 0, 6, "layout75"); 

    layout74 = new QVBoxLayout( 0, 0, 6, "layout74"); 

    textLabelResoPixelSize_3 = new QLabel( groupBoxDeadTime, "textLabelResoPixelSize_3" );
    textLabelResoPixelSize_3->setEnabled( TRUE );
    textLabelResoPixelSize_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelResoPixelSize_3->sizePolicy().hasHeightForWidth() ) );
    textLabelResoPixelSize_3->setMinimumSize( QSize( 110, 0 ) );
    textLabelResoPixelSize_3->setMaximumSize( QSize( 130, 20 ) );
    textLabelResoPixelSize_3->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabelResoPixelSize_3_font(  textLabelResoPixelSize_3->font() );
    textLabelResoPixelSize_3_font.setFamily( "Lucida Grande" );
    textLabelResoPixelSize_3_font.setBold( FALSE );
    textLabelResoPixelSize_3->setFont( textLabelResoPixelSize_3_font ); 
    layout74->addWidget( textLabelResoPixelSize_3 );

    radioButtonDeadTimeCh = new QRadioButton( groupBoxDeadTime, "radioButtonDeadTimeCh" );
    radioButtonDeadTimeCh->setEnabled( TRUE );
    radioButtonDeadTimeCh->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, radioButtonDeadTimeCh->sizePolicy().hasHeightForWidth() ) );
    radioButtonDeadTimeCh->setMinimumSize( QSize( 0, 0 ) );
    radioButtonDeadTimeCh->setMaximumSize( QSize( 1300, 32767 ) );
    radioButtonDeadTimeCh->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    radioButtonDeadTimeCh->setPalette( pal );
    QFont radioButtonDeadTimeCh_font(  radioButtonDeadTimeCh->font() );
    radioButtonDeadTimeCh_font.setBold( FALSE );
    radioButtonDeadTimeCh->setFont( radioButtonDeadTimeCh_font ); 
    radioButtonDeadTimeCh->setChecked( TRUE );
    layout74->addWidget( radioButtonDeadTimeCh );

    radioButtonDeadTimeDet = new QRadioButton( groupBoxDeadTime, "radioButtonDeadTimeDet" );
    radioButtonDeadTimeDet->setEnabled( TRUE );
    radioButtonDeadTimeDet->setMaximumSize( QSize( 1300, 32767 ) );
    radioButtonDeadTimeDet->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    radioButtonDeadTimeDet->setPalette( pal );
    QFont radioButtonDeadTimeDet_font(  radioButtonDeadTimeDet->font() );
    radioButtonDeadTimeDet_font.setBold( FALSE );
    radioButtonDeadTimeDet->setFont( radioButtonDeadTimeDet_font ); 
    radioButtonDeadTimeDet->setChecked( FALSE );
    layout74->addWidget( radioButtonDeadTimeDet );
    layout75->addLayout( layout74 );

    layout73 = new QVBoxLayout( 0, 0, 6, "layout73"); 

    lineEditDeadTime = new QLineEdit( groupBoxDeadTime, "lineEditDeadTime" );
    lineEditDeadTime->setEnabled( TRUE );
    lineEditDeadTime->setMinimumSize( QSize( 0, 22 ) );
    lineEditDeadTime->setMaximumSize( QSize( 1000, 20 ) );
    lineEditDeadTime->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont lineEditDeadTime_font(  lineEditDeadTime->font() );
    lineEditDeadTime_font.setBold( FALSE );
    lineEditDeadTime->setFont( lineEditDeadTime_font ); 
    lineEditDeadTime->setFrameShape( QLineEdit::Box );
    lineEditDeadTime->setLineWidth( 1 );
    layout73->addWidget( lineEditDeadTime );

    textLabel1_6 = new QLabel( groupBoxDeadTime, "textLabel1_6" );
    textLabel1_6->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel1_6->sizePolicy().hasHeightForWidth() ) );
    textLabel1_6->setMaximumSize( QSize( 10000, 32767 ) );
    QFont textLabel1_6_font(  textLabel1_6->font() );
    textLabel1_6_font.setFamily( "Lucida Grande" );
    textLabel1_6_font.setBold( FALSE );
    textLabel1_6->setFont( textLabel1_6_font ); 
    layout73->addWidget( textLabel1_6 );

    textLabel2_2 = new QLabel( groupBoxDeadTime, "textLabel2_2" );
    textLabel2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2->setMaximumSize( QSize( 10000, 32767 ) );
    QFont textLabel2_2_font(  textLabel2_2->font() );
    textLabel2_2_font.setFamily( "Lucida Grande" );
    textLabel2_2_font.setBold( FALSE );
    textLabel2_2->setFont( textLabel2_2_font ); 
    layout73->addWidget( textLabel2_2 );
    layout75->addLayout( layout73 );
    groupBoxDeadTimeLayout->addLayout( layout75 );

    comboBoxDTtype = new QComboBox( FALSE, groupBoxDeadTime, "comboBoxDTtype" );
    comboBoxDTtype->setEnabled( TRUE );
    comboBoxDTtype->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxDTtype->sizePolicy().hasHeightForWidth() ) );
    comboBoxDTtype->setMinimumSize( QSize( 0, 22 ) );
    comboBoxDTtype->setMaximumSize( QSize( 2800, 32767 ) );
    comboBoxDTtype->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxDTtype_font(  comboBoxDTtype->font() );
    comboBoxDTtype_font.setBold( FALSE );
    comboBoxDTtype->setFont( comboBoxDTtype_font ); 
    groupBoxDeadTimeLayout->addWidget( comboBoxDTtype );
    pageLayout_4->addWidget( groupBoxDeadTime );
    spacer78_2 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_4->addItem( spacer78_2 );
    toolBoxCONFIG->addItem( page_4, QString::fromLatin1("") );

    page_5 = new QWidget( toolBoxCONFIG, "page_5" );
    page_5->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_5 = new QVBoxLayout( page_5, 11, 6, "pageLayout_5"); 

    buttonGroupDet = new QButtonGroup( page_5, "buttonGroupDet" );
    buttonGroupDet->setEnabled( TRUE );
    buttonGroupDet->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)3, 0, 0, buttonGroupDet->sizePolicy().hasHeightForWidth() ) );
    buttonGroupDet->setMinimumSize( QSize( 20, 20 ) );
    buttonGroupDet->setMaximumSize( QSize( 32767, 110 ) );
    buttonGroupDet->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroupDet->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    buttonGroupDet->setPalette( pal );
    QFont buttonGroupDet_font(  buttonGroupDet->font() );
    buttonGroupDet_font.setBold( TRUE );
    buttonGroupDet->setFont( buttonGroupDet_font ); 
    buttonGroupDet->setFrameShape( QButtonGroup::NoFrame );
    buttonGroupDet->setFrameShadow( QButtonGroup::Plain );
    buttonGroupDet->setLineWidth( 0 );
    buttonGroupDet->setCheckable( FALSE );
    buttonGroupDet->setChecked( FALSE );
    buttonGroupDet->setColumnLayout(0, Qt::Vertical );
    buttonGroupDet->layout()->setSpacing( 2 );
    buttonGroupDet->layout()->setMargin( 11 );
    buttonGroupDetLayout = new QVBoxLayout( buttonGroupDet->layout() );
    buttonGroupDetLayout->setAlignment( Qt::AlignTop );

    radioButtonCenterHF = new QRadioButton( buttonGroupDet, "radioButtonCenterHF" );
    radioButtonCenterHF->setEnabled( TRUE );
    radioButtonCenterHF->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, radioButtonCenterHF->sizePolicy().hasHeightForWidth() ) );
    radioButtonCenterHF->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    radioButtonCenterHF->setPalette( pal );
    QFont radioButtonCenterHF_font(  radioButtonCenterHF->font() );
    radioButtonCenterHF_font.setBold( FALSE );
    radioButtonCenterHF->setFont( radioButtonCenterHF_font ); 
    radioButtonCenterHF->setChecked( FALSE );
    buttonGroupDetLayout->addWidget( radioButtonCenterHF );

    radioButtonRadStdSymm = new QRadioButton( buttonGroupDet, "radioButtonRadStdSymm" );
    radioButtonRadStdSymm->setEnabled( TRUE );
    radioButtonRadStdSymm->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, radioButtonRadStdSymm->sizePolicy().hasHeightForWidth() ) );
    radioButtonRadStdSymm->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    radioButtonRadStdSymm->setPalette( pal );
    QFont radioButtonRadStdSymm_font(  radioButtonRadStdSymm->font() );
    radioButtonRadStdSymm_font.setBold( FALSE );
    radioButtonRadStdSymm->setFont( radioButtonRadStdSymm_font ); 
    radioButtonRadStdSymm->setChecked( TRUE );
    buttonGroupDetLayout->addWidget( radioButtonRadStdSymm );

    radioButtonCenterReadFromHeader = new QRadioButton( buttonGroupDet, "radioButtonCenterReadFromHeader" );
    radioButtonCenterReadFromHeader->setEnabled( TRUE );
    radioButtonCenterReadFromHeader->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, radioButtonCenterReadFromHeader->sizePolicy().hasHeightForWidth() ) );
    radioButtonCenterReadFromHeader->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    radioButtonCenterReadFromHeader->setPalette( pal );
    QFont radioButtonCenterReadFromHeader_font(  radioButtonCenterReadFromHeader->font() );
    radioButtonCenterReadFromHeader_font.setBold( FALSE );
    radioButtonCenterReadFromHeader->setFont( radioButtonCenterReadFromHeader_font ); 
    radioButtonCenterReadFromHeader->setChecked( FALSE );
    buttonGroupDetLayout->addWidget( radioButtonCenterReadFromHeader );
    pageLayout_5->addWidget( buttonGroupDet );
    spacer77 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_5->addItem( spacer77 );
    toolBoxCONFIG->addItem( page_5, QString::fromLatin1("") );

    page_6 = new QWidget( toolBoxCONFIG, "page_6" );
    page_6->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_6 = new QVBoxLayout( page_6, 0, 0, "pageLayout_6"); 

    groupBoxAU = new QButtonGroup( page_6, "groupBoxAU" );
    groupBoxAU->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, groupBoxAU->sizePolicy().hasHeightForWidth() ) );
    groupBoxAU->setMinimumSize( QSize( 0, 20 ) );
    groupBoxAU->setMaximumSize( QSize( 4200, 260 ) );
    groupBoxAU->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBoxAU->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    groupBoxAU->setPalette( pal );
    QFont groupBoxAU_font(  groupBoxAU->font() );
    groupBoxAU_font.setBold( TRUE );
    groupBoxAU->setFont( groupBoxAU_font ); 
    groupBoxAU->setFrameShape( QButtonGroup::NoFrame );
    groupBoxAU->setFrameShadow( QButtonGroup::Plain );
    groupBoxAU->setLineWidth( 0 );
    groupBoxAU->setCheckable( FALSE );
    groupBoxAU->setChecked( FALSE );
    groupBoxAU->setColumnLayout(0, Qt::Vertical );
    groupBoxAU->layout()->setSpacing( 2 );
    groupBoxAU->layout()->setMargin( 11 );
    groupBoxAULayout = new QVBoxLayout( groupBoxAU->layout() );
    groupBoxAULayout->setAlignment( Qt::AlignTop );

    comboBoxACmethod = new QComboBox( FALSE, groupBoxAU, "comboBoxACmethod" );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    comboBoxACmethod->setPalette( pal );
    QFont comboBoxACmethod_font(  comboBoxACmethod->font() );
    comboBoxACmethod_font.setBold( FALSE );
    comboBoxACmethod->setFont( comboBoxACmethod_font ); 
    groupBoxAULayout->addWidget( comboBoxACmethod );

    groupBoxFlatScatter = new QGroupBox( groupBoxAU, "groupBoxFlatScatter" );
    groupBoxFlatScatter->setEnabled( TRUE );
    groupBoxFlatScatter->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, groupBoxFlatScatter->sizePolicy().hasHeightForWidth() ) );
    groupBoxFlatScatter->setMaximumSize( QSize( 400, 2000 ) );
    groupBoxFlatScatter->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    groupBoxFlatScatter->setPalette( pal );
    QFont groupBoxFlatScatter_font(  groupBoxFlatScatter->font() );
    groupBoxFlatScatter_font.setBold( FALSE );
    groupBoxFlatScatter->setFont( groupBoxFlatScatter_font ); 
    groupBoxFlatScatter->setMargin( 0 );
    groupBoxFlatScatter->setCheckable( FALSE );
    groupBoxFlatScatter->setColumnLayout(0, Qt::Vertical );
    groupBoxFlatScatter->layout()->setSpacing( 6 );
    groupBoxFlatScatter->layout()->setMargin( 11 );
    groupBoxFlatScatterLayout = new QVBoxLayout( groupBoxFlatScatter->layout() );
    groupBoxFlatScatterLayout->setAlignment( Qt::AlignTop );

    layout96 = new QHBoxLayout( 0, 0, 6, "layout96"); 

    comboBoxCalibrant = new QComboBox( FALSE, groupBoxFlatScatter, "comboBoxCalibrant" );
    comboBoxCalibrant->setEnabled( TRUE );
    comboBoxCalibrant->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxCalibrant->sizePolicy().hasHeightForWidth() ) );
    comboBoxCalibrant->setMinimumSize( QSize( 0, 25 ) );
    comboBoxCalibrant->setMaximumSize( QSize( 32767, 20000 ) );
    comboBoxCalibrant->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout96->addWidget( comboBoxCalibrant );

    pushButtonsaveCurrentCalibrant = new QPushButton( groupBoxFlatScatter, "pushButtonsaveCurrentCalibrant" );
    pushButtonsaveCurrentCalibrant->setEnabled( TRUE );
    pushButtonsaveCurrentCalibrant->setMinimumSize( QSize( 25, 0 ) );
    pushButtonsaveCurrentCalibrant->setMaximumSize( QSize( 25, 25 ) );
    pushButtonsaveCurrentCalibrant->setPixmap( image7 );
    layout96->addWidget( pushButtonsaveCurrentCalibrant );

    pushButtonDeleteCurrentCalibrator = new QPushButton( groupBoxFlatScatter, "pushButtonDeleteCurrentCalibrator" );
    pushButtonDeleteCurrentCalibrator->setEnabled( TRUE );
    pushButtonDeleteCurrentCalibrator->setMinimumSize( QSize( 25, 0 ) );
    pushButtonDeleteCurrentCalibrator->setMaximumSize( QSize( 25, 25 ) );
    pushButtonDeleteCurrentCalibrator->setPixmap( image4 );
    layout96->addWidget( pushButtonDeleteCurrentCalibrator );
    groupBoxFlatScatterLayout->addLayout( layout96 );

    textLabel1_7 = new QLabel( groupBoxFlatScatter, "textLabel1_7" );
    textLabel1_7->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, textLabel1_7->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7->setMaximumSize( QSize( 32767, 22 ) );
    textLabel1_7->setPaletteForegroundColor( QColor( 166, 163, 157 ) );
    textLabel1_7->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    textLabel1_7->setAlignment( int( QLabel::WordBreak | QLabel::AlignTop | QLabel::AlignLeft ) );
    textLabel1_7->setIndent( -1 );
    groupBoxFlatScatterLayout->addWidget( textLabel1_7 );

    layout68 = new QHBoxLayout( 0, 0, 6, "layout68"); 

    layout107 = new QHBoxLayout( 0, 0, 1, "layout107"); 

    textLabel1_7_2 = new QLabel( groupBoxFlatScatter, "textLabel1_7_2" );
    textLabel1_7_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_7_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_2->setMaximumSize( QSize( 14, 3000 ) );
    layout107->addWidget( textLabel1_7_2 );

    lineEditMuY0 = new QLineEdit( groupBoxFlatScatter, "lineEditMuY0" );
    lineEditMuY0->setEnabled( TRUE );
    lineEditMuY0->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditMuY0->sizePolicy().hasHeightForWidth() ) );
    lineEditMuY0->setMaximumSize( QSize( 700, 32767 ) );
    lineEditMuY0->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditMuY0->setFrameShape( QLineEdit::Box );
    lineEditMuY0->setLineWidth( 1 );
    layout107->addWidget( lineEditMuY0 );
    layout68->addLayout( layout107 );

    layout108 = new QHBoxLayout( 0, 0, 1, "layout108"); 

    textLabel1_7_3 = new QLabel( groupBoxFlatScatter, "textLabel1_7_3" );
    textLabel1_7_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_7_3->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_3->setMaximumSize( QSize( 14, 32767 ) );
    layout108->addWidget( textLabel1_7_3 );

    lineEditMuA = new QLineEdit( groupBoxFlatScatter, "lineEditMuA" );
    lineEditMuA->setEnabled( TRUE );
    lineEditMuA->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditMuA->sizePolicy().hasHeightForWidth() ) );
    lineEditMuA->setMaximumSize( QSize( 700, 32767 ) );
    lineEditMuA->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditMuA->setFrameShape( QLineEdit::Box );
    lineEditMuA->setLineWidth( 1 );
    layout108->addWidget( lineEditMuA );
    layout68->addLayout( layout108 );

    layout109_2 = new QHBoxLayout( 0, 0, 1, "layout109_2"); 

    textLabel1_7_4 = new QLabel( groupBoxFlatScatter, "textLabel1_7_4" );
    textLabel1_7_4->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_7_4->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_4->setMaximumSize( QSize( 15, 32767 ) );
    layout109_2->addWidget( textLabel1_7_4 );

    lineEditMut = new QLineEdit( groupBoxFlatScatter, "lineEditMut" );
    lineEditMut->setEnabled( TRUE );
    lineEditMut->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditMut->sizePolicy().hasHeightForWidth() ) );
    lineEditMut->setMaximumSize( QSize( 700, 32767 ) );
    lineEditMut->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditMut->setFrameShape( QLineEdit::Box );
    lineEditMut->setLineWidth( 1 );
    layout109_2->addWidget( lineEditMut );
    layout68->addLayout( layout109_2 );
    groupBoxFlatScatterLayout->addLayout( layout68 );

    checkBoxTransmissionPlexi = new QCheckBox( groupBoxFlatScatter, "checkBoxTransmissionPlexi" );
    checkBoxTransmissionPlexi->setEnabled( TRUE );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxTransmissionPlexi->setPalette( pal );
    checkBoxTransmissionPlexi->setChecked( TRUE );
    groupBoxFlatScatterLayout->addWidget( checkBoxTransmissionPlexi );

    textLabel1_7_5 = new QLabel( groupBoxFlatScatter, "textLabel1_7_5" );
    textLabel1_7_5->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, textLabel1_7_5->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_5->setMaximumSize( QSize( 32767, 22 ) );
    textLabel1_7_5->setPaletteForegroundColor( QColor( 166, 163, 157 ) );
    textLabel1_7_5->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    textLabel1_7_5->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignLeft ) );
    groupBoxFlatScatterLayout->addWidget( textLabel1_7_5 );

    layout61 = new QHBoxLayout( 0, 0, 6, "layout61"); 

    layout111 = new QHBoxLayout( 0, 0, 1, "layout111"); 

    textLabel1_7_4_3 = new QLabel( groupBoxFlatScatter, "textLabel1_7_4_3" );
    textLabel1_7_4_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_7_4_3->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_4_3->setMaximumSize( QSize( 14, 32767 ) );
    layout111->addWidget( textLabel1_7_4_3 );

    lineEditTo = new QLineEdit( groupBoxFlatScatter, "lineEditTo" );
    lineEditTo->setEnabled( TRUE );
    lineEditTo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditTo->sizePolicy().hasHeightForWidth() ) );
    lineEditTo->setMaximumSize( QSize( 700, 32767 ) );
    lineEditTo->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditTo->setFrameShape( QLineEdit::Box );
    lineEditTo->setLineWidth( 1 );
    layout111->addWidget( lineEditTo );
    layout61->addLayout( layout111 );

    layout112 = new QHBoxLayout( 0, 0, 1, "layout112"); 

    textLabel1_7_4_3_2 = new QLabel( groupBoxFlatScatter, "textLabel1_7_4_3_2" );
    textLabel1_7_4_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_7_4_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_4_3_2->setMaximumSize( QSize( 14, 32767 ) );
    layout112->addWidget( textLabel1_7_4_3_2 );

    lineEditTA = new QLineEdit( groupBoxFlatScatter, "lineEditTA" );
    lineEditTA->setEnabled( TRUE );
    lineEditTA->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditTA->sizePolicy().hasHeightForWidth() ) );
    lineEditTA->setMaximumSize( QSize( 700, 32767 ) );
    lineEditTA->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditTA->setFrameShape( QLineEdit::Box );
    lineEditTA->setLineWidth( 1 );
    layout112->addWidget( lineEditTA );
    layout61->addLayout( layout112 );

    layout113 = new QHBoxLayout( 0, 0, 1, "layout113"); 

    textLabel1_7_4_2 = new QLabel( groupBoxFlatScatter, "textLabel1_7_4_2" );
    textLabel1_7_4_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_7_4_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_4_2->setMaximumSize( QSize( 15, 32767 ) );
    layout113->addWidget( textLabel1_7_4_2 );

    lineEditLate = new QLineEdit( groupBoxFlatScatter, "lineEditLate" );
    lineEditLate->setEnabled( TRUE );
    lineEditLate->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditLate->sizePolicy().hasHeightForWidth() ) );
    lineEditLate->setMaximumSize( QSize( 700, 32767 ) );
    lineEditLate->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditLate->setFrameShape( QLineEdit::Box );
    lineEditLate->setLineWidth( 1 );
    layout113->addWidget( lineEditLate );
    layout61->addLayout( layout113 );
    groupBoxFlatScatterLayout->addLayout( layout61 );
    groupBoxAULayout->addWidget( groupBoxFlatScatter );

    checkBoxACDBuseActive = new QCheckBox( groupBoxAU, "checkBoxACDBuseActive" );
    checkBoxACDBuseActive->setEnabled( TRUE );
    checkBoxACDBuseActive->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxACDBuseActive->sizePolicy().hasHeightForWidth() ) );
    checkBoxACDBuseActive->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxACDBuseActive->setPalette( pal );
    QFont checkBoxACDBuseActive_font(  checkBoxACDBuseActive->font() );
    checkBoxACDBuseActive_font.setBold( FALSE );
    checkBoxACDBuseActive->setFont( checkBoxACDBuseActive_font ); 
    groupBoxAULayout->addWidget( checkBoxACDBuseActive );
    spacer32_3 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    groupBoxAULayout->addItem( spacer32_3 );
    pageLayout_6->addWidget( groupBoxAU );
    spacer76_2 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_6->addItem( spacer76_2 );
    toolBoxCONFIG->addItem( page_6, QString::fromLatin1("") );

    page_7 = new QWidget( toolBoxCONFIG, "page_7" );
    page_7->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_7 = new QVBoxLayout( page_7, 0, 0, "pageLayout_7"); 

    buttonGroupTrMethod = new QButtonGroup( page_7, "buttonGroupTrMethod" );
    buttonGroupTrMethod->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroupTrMethod->sizePolicy().hasHeightForWidth() ) );
    buttonGroupTrMethod->setMinimumSize( QSize( 0, 80 ) );
    buttonGroupTrMethod->setMaximumSize( QSize( 32767, 20 ) );
    buttonGroupTrMethod->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroupTrMethod->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 255, 225) );
    cg.setColor( QColorGroup::Dark, QColor( 127, 127, 97) );
    cg.setColor( QColorGroup::Mid, QColor( 170, 170, 130) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 255, 233) );
    cg.setColor( QColorGroup::Dark, QColor( 127, 127, 97) );
    cg.setColor( QColorGroup::Mid, QColor( 170, 170, 130) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 255, 233) );
    cg.setColor( QColorGroup::Dark, QColor( 127, 127, 97) );
    cg.setColor( QColorGroup::Mid, QColor( 170, 170, 130) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    buttonGroupTrMethod->setPalette( pal );
    QFont buttonGroupTrMethod_font(  buttonGroupTrMethod->font() );
    buttonGroupTrMethod_font.setBold( TRUE );
    buttonGroupTrMethod->setFont( buttonGroupTrMethod_font ); 
    buttonGroupTrMethod->setFrameShape( QButtonGroup::NoFrame );
    buttonGroupTrMethod->setFrameShadow( QButtonGroup::Plain );
    buttonGroupTrMethod->setLineWidth( 0 );
    buttonGroupTrMethod->setCheckable( FALSE );
    buttonGroupTrMethod->setChecked( FALSE );
    buttonGroupTrMethod->setRadioButtonExclusive( FALSE );
    buttonGroupTrMethod->setColumnLayout(0, Qt::Vertical );
    buttonGroupTrMethod->layout()->setSpacing( 2 );
    buttonGroupTrMethod->layout()->setMargin( 11 );
    buttonGroupTrMethodLayout = new QVBoxLayout( buttonGroupTrMethod->layout() );
    buttonGroupTrMethodLayout->setAlignment( Qt::AlignTop );

    comboBoxTransmMethod = new QComboBox( FALSE, buttonGroupTrMethod, "comboBoxTransmMethod" );
    comboBoxTransmMethod->setEnabled( TRUE );
    comboBoxTransmMethod->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxTransmMethod->sizePolicy().hasHeightForWidth() ) );
    comboBoxTransmMethod->setMinimumSize( QSize( 0, 25 ) );
    comboBoxTransmMethod->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxTransmMethod_font(  comboBoxTransmMethod->font() );
    comboBoxTransmMethod_font.setBold( FALSE );
    comboBoxTransmMethod->setFont( comboBoxTransmMethod_font ); 
    buttonGroupTrMethodLayout->addWidget( comboBoxTransmMethod );

    buttonGroup37 = new QButtonGroup( buttonGroupTrMethod, "buttonGroup37" );
    buttonGroup37->setFrameShape( QButtonGroup::NoFrame );
    buttonGroup37->setFrameShadow( QButtonGroup::Plain );
    buttonGroup37->setColumnLayout(0, Qt::Vertical );
    buttonGroup37->layout()->setSpacing( 3 );
    buttonGroup37->layout()->setMargin( 3 );
    buttonGroup37Layout = new QHBoxLayout( buttonGroup37->layout() );
    buttonGroup37Layout->setAlignment( Qt::AlignTop );

    textLabel1_5 = new QLabel( buttonGroup37, "textLabel1_5" );
    textLabel1_5->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel1_5_font(  textLabel1_5->font() );
    textLabel1_5_font.setBold( FALSE );
    textLabel1_5->setFont( textLabel1_5_font ); 
    buttonGroup37Layout->addWidget( textLabel1_5 );

    lineEditDBdeadtime = new QLineEdit( buttonGroup37, "lineEditDBdeadtime" );
    QFont lineEditDBdeadtime_font(  lineEditDBdeadtime->font() );
    lineEditDBdeadtime_font.setBold( FALSE );
    lineEditDBdeadtime->setFont( lineEditDBdeadtime_font ); 
    buttonGroup37Layout->addWidget( lineEditDBdeadtime );
    buttonGroupTrMethodLayout->addWidget( buttonGroup37 );
    pageLayout_7->addWidget( buttonGroupTrMethod );
    spacer75_4 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_7->addItem( spacer75_4 );
    toolBoxCONFIG->addItem( page_7, QString::fromLatin1("") );

    page_8 = new QWidget( toolBoxCONFIG, "page_8" );
    page_8->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_8 = new QVBoxLayout( page_8, 0, 0, "pageLayout_8"); 

    buttonGroupResolusion = new QButtonGroup( page_8, "buttonGroupResolusion" );
    buttonGroupResolusion->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, buttonGroupResolusion->sizePolicy().hasHeightForWidth() ) );
    buttonGroupResolusion->setMinimumSize( QSize( 0, 125 ) );
    buttonGroupResolusion->setMaximumSize( QSize( 32767, 20 ) );
    buttonGroupResolusion->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroupResolusion->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 255, 225) );
    cg.setColor( QColorGroup::Dark, QColor( 127, 127, 97) );
    cg.setColor( QColorGroup::Mid, QColor( 170, 170, 130) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 255, 233) );
    cg.setColor( QColorGroup::Dark, QColor( 127, 127, 97) );
    cg.setColor( QColorGroup::Mid, QColor( 170, 170, 130) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 255, 233) );
    cg.setColor( QColorGroup::Dark, QColor( 127, 127, 97) );
    cg.setColor( QColorGroup::Mid, QColor( 170, 170, 130) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    buttonGroupResolusion->setPalette( pal );
    QFont buttonGroupResolusion_font(  buttonGroupResolusion->font() );
    buttonGroupResolusion_font.setBold( TRUE );
    buttonGroupResolusion->setFont( buttonGroupResolusion_font ); 
    buttonGroupResolusion->setFrameShape( QButtonGroup::NoFrame );
    buttonGroupResolusion->setFrameShadow( QButtonGroup::Plain );
    buttonGroupResolusion->setLineWidth( 0 );
    buttonGroupResolusion->setCheckable( FALSE );
    buttonGroupResolusion->setChecked( FALSE );
    buttonGroupResolusion->setRadioButtonExclusive( FALSE );
    buttonGroupResolusion->setColumnLayout(0, Qt::Vertical );
    buttonGroupResolusion->layout()->setSpacing( 2 );
    buttonGroupResolusion->layout()->setMargin( 11 );
    buttonGroupResolusionLayout = new QVBoxLayout( buttonGroupResolusion->layout() );
    buttonGroupResolusionLayout->setAlignment( Qt::AlignTop );

    checkBoxResoFocus = new QCheckBox( buttonGroupResolusion, "checkBoxResoFocus" );
    checkBoxResoFocus->setEnabled( TRUE );
    checkBoxResoFocus->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxResoFocus->setPalette( pal );
    QFont checkBoxResoFocus_font(  checkBoxResoFocus->font() );
    checkBoxResoFocus_font.setBold( FALSE );
    checkBoxResoFocus->setFont( checkBoxResoFocus_font ); 
    checkBoxResoFocus->setChecked( FALSE );
    buttonGroupResolusionLayout->addWidget( checkBoxResoFocus );

    checkBoxResoCAround = new QCheckBox( buttonGroupResolusion, "checkBoxResoCAround" );
    checkBoxResoCAround->setEnabled( TRUE );
    checkBoxResoCAround->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxResoCAround->setPalette( pal );
    QFont checkBoxResoCAround_font(  checkBoxResoCAround->font() );
    checkBoxResoCAround_font.setBold( FALSE );
    checkBoxResoCAround->setFont( checkBoxResoCAround_font ); 
    checkBoxResoCAround->setChecked( FALSE );
    buttonGroupResolusionLayout->addWidget( checkBoxResoCAround );

    checkBoxResoSAround = new QCheckBox( buttonGroupResolusion, "checkBoxResoSAround" );
    checkBoxResoSAround->setEnabled( TRUE );
    checkBoxResoSAround->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxResoSAround->setPalette( pal );
    QFont checkBoxResoSAround_font(  checkBoxResoSAround->font() );
    checkBoxResoSAround_font.setBold( FALSE );
    checkBoxResoSAround->setFont( checkBoxResoSAround_font ); 
    checkBoxResoSAround->setChecked( FALSE );
    buttonGroupResolusionLayout->addWidget( checkBoxResoSAround );

    layout60 = new QHBoxLayout( 0, 0, 6, "layout60"); 

    textLabel2_4 = new QLabel( buttonGroupResolusion, "textLabel2_4" );
    textLabel2_4->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel2_4->sizePolicy().hasHeightForWidth() ) );
    textLabel2_4->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabel2_4_font(  textLabel2_4->font() );
    textLabel2_4_font.setBold( FALSE );
    textLabel2_4->setFont( textLabel2_4_font ); 
    layout60->addWidget( textLabel2_4 );

    lineEditDetReso = new QLineEdit( buttonGroupResolusion, "lineEditDetReso" );
    lineEditDetReso->setEnabled( TRUE );
    lineEditDetReso->setMinimumSize( QSize( 50, 20 ) );
    lineEditDetReso->setMaximumSize( QSize( 15000, 20 ) );
    lineEditDetReso->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont lineEditDetReso_font(  lineEditDetReso->font() );
    lineEditDetReso_font.setBold( FALSE );
    lineEditDetReso->setFont( lineEditDetReso_font ); 
    lineEditDetReso->setFrameShape( QLineEdit::GroupBoxPanel );
    lineEditDetReso->setLineWidth( 1 );
    layout60->addWidget( lineEditDetReso );
    buttonGroupResolusionLayout->addLayout( layout60 );
    pageLayout_8->addWidget( buttonGroupResolusion );
    spacer72_3 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_8->addItem( spacer72_3 );
    toolBoxCONFIG->addItem( page_8, QString::fromLatin1("") );
    layout137->addWidget( toolBoxCONFIG );
    page2Layout->addLayout( layout137 );
    toolBox7->addItem( page2, QString::fromLatin1("") );

    page_9 = new QWidget( toolBox7, "page_9" );
    page_9->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_9 = new QVBoxLayout( page_9, 11, 0, "pageLayout_9"); 

    lineEditMD_2_2_2 = new QLineEdit( page_9, "lineEditMD_2_2_2" );
    lineEditMD_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditMD_2_2_2->sizePolicy().hasHeightForWidth() ) );
    lineEditMD_2_2_2->setMinimumSize( QSize( 15, 5 ) );
    lineEditMD_2_2_2->setMaximumSize( QSize( 15000, 5 ) );
    lineEditMD_2_2_2->setPaletteForegroundColor( QColor( 255, 255, 195 ) );
    lineEditMD_2_2_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 173, 173, 219) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    lineEditMD_2_2_2->setPalette( pal );
    lineEditMD_2_2_2->setBackgroundOrigin( QLineEdit::WidgetOrigin );
    QFont lineEditMD_2_2_2_font(  lineEditMD_2_2_2->font() );
    lineEditMD_2_2_2->setFont( lineEditMD_2_2_2_font ); 
    lineEditMD_2_2_2->setFrameShape( QLineEdit::Box );
    lineEditMD_2_2_2->setFrameShadow( QLineEdit::Plain );
    lineEditMD_2_2_2->setLineWidth( 1 );
    lineEditMD_2_2_2->setMargin( 0 );
    lineEditMD_2_2_2->setAlignment( int( QLineEdit::AlignHCenter ) );
    lineEditMD_2_2_2->setReadOnly( TRUE );
    pageLayout_9->addWidget( lineEditMD_2_2_2 );

    layout186 = new QHBoxLayout( 0, 0, 0, "layout186"); 

    lineEditMD_2_3 = new QLineEdit( page_9, "lineEditMD_2_3" );
    lineEditMD_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditMD_2_3->sizePolicy().hasHeightForWidth() ) );
    lineEditMD_2_3->setMinimumSize( QSize( 5, 25 ) );
    lineEditMD_2_3->setMaximumSize( QSize( 5, 3200 ) );
    lineEditMD_2_3->setPaletteForegroundColor( QColor( 255, 255, 195 ) );
    lineEditMD_2_3->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 173, 173, 219) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    lineEditMD_2_3->setPalette( pal );
    lineEditMD_2_3->setBackgroundOrigin( QLineEdit::WidgetOrigin );
    QFont lineEditMD_2_3_font(  lineEditMD_2_3->font() );
    lineEditMD_2_3->setFont( lineEditMD_2_3_font ); 
    lineEditMD_2_3->setFrameShape( QLineEdit::Box );
    lineEditMD_2_3->setFrameShadow( QLineEdit::Plain );
    lineEditMD_2_3->setLineWidth( 1 );
    lineEditMD_2_3->setMargin( 0 );
    lineEditMD_2_3->setAlignment( int( QLineEdit::AlignHCenter ) );
    lineEditMD_2_3->setReadOnly( TRUE );
    layout186->addWidget( lineEditMD_2_3 );

    toolBoxDP2D = new QToolBox( page_9, "toolBoxDP2D" );
    toolBoxDP2D->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 173, 173, 219) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    toolBoxDP2D->setPalette( pal );
    toolBoxDP2D->setBackgroundOrigin( QToolBox::AncestorOrigin );
    toolBoxDP2D->setAcceptDrops( FALSE );
    toolBoxDP2D->setFrameShape( QToolBox::NoFrame );
    toolBoxDP2D->setFrameShadow( QToolBox::Plain );
    toolBoxDP2D->setLineWidth( 1 );
    toolBoxDP2D->setMidLineWidth( 0 );
    toolBoxDP2D->setCurrentIndex( 1 );

    page1_3 = new QWidget( toolBoxDP2D, "page1_3" );
    page1_3->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout_3 = new QVBoxLayout( page1_3, 11, 6, "page1Layout_3"); 

    layout135 = new QHBoxLayout( 0, 0, 6, "layout135"); 

    comboBoxMatrixConvolusion = new QComboBox( FALSE, page1_3, "comboBoxMatrixConvolusion" );
    comboBoxMatrixConvolusion->setEnabled( TRUE );
    comboBoxMatrixConvolusion->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, comboBoxMatrixConvolusion->sizePolicy().hasHeightForWidth() ) );
    comboBoxMatrixConvolusion->setMinimumSize( QSize( 220, 25 ) );
    comboBoxMatrixConvolusion->setMaximumSize( QSize( 220, 20000 ) );
    comboBoxMatrixConvolusion->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxMatrixConvolusion->setPalette( pal );
    QFont comboBoxMatrixConvolusion_font(  comboBoxMatrixConvolusion->font() );
    comboBoxMatrixConvolusion->setFont( comboBoxMatrixConvolusion_font ); 
    comboBoxMatrixConvolusion->setDuplicatesEnabled( FALSE );
    layout135->addWidget( comboBoxMatrixConvolusion );
    spacer82_2_2 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout135->addItem( spacer82_2_2 );
    page1Layout_3->addLayout( layout135 );
    spacer67 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page1Layout_3->addItem( spacer67 );
    toolBoxDP2D->addItem( page1_3, QString::fromLatin1("") );

    page2_3 = new QWidget( toolBoxDP2D, "page2_3" );
    page2_3->setBackgroundMode( QWidget::PaletteBackground );
    page2Layout_3 = new QVBoxLayout( page2_3, 11, 0, "page2Layout_3"); 

    layout138 = new QHBoxLayout( 0, 0, 6, "layout138"); 

    layout137_2 = new QVBoxLayout( 0, 0, 6, "layout137_2"); 

    layout136 = new QHBoxLayout( 0, 0, 6, "layout136"); 

    checkBoxParallax = new QCheckBox( page2_3, "checkBoxParallax" );
    checkBoxParallax->setEnabled( TRUE );
    checkBoxParallax->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxParallax->setPalette( pal );
    QFont checkBoxParallax_font(  checkBoxParallax->font() );
    checkBoxParallax->setFont( checkBoxParallax_font ); 
    checkBoxParallax->setChecked( TRUE );
    layout136->addWidget( checkBoxParallax );

    comboBoxParallax = new QComboBox( FALSE, page2_3, "comboBoxParallax" );
    comboBoxParallax->setEnabled( TRUE );
    comboBoxParallax->setMinimumSize( QSize( 200, 25 ) );
    comboBoxParallax->setMaximumSize( QSize( 200, 20000 ) );
    comboBoxParallax->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxParallax->setPalette( pal );
    QFont comboBoxParallax_font(  comboBoxParallax->font() );
    comboBoxParallax->setFont( comboBoxParallax_font ); 
    comboBoxParallax->setDuplicatesEnabled( FALSE );
    layout136->addWidget( comboBoxParallax );
    layout137_2->addLayout( layout136 );

    checkBoxParallaxTr = new QCheckBox( page2_3, "checkBoxParallaxTr" );
    checkBoxParallaxTr->setEnabled( TRUE );
    checkBoxParallaxTr->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxParallaxTr->sizePolicy().hasHeightForWidth() ) );
    checkBoxParallaxTr->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxParallaxTr->setPalette( pal );
    QFont checkBoxParallaxTr_font(  checkBoxParallaxTr->font() );
    checkBoxParallaxTr->setFont( checkBoxParallaxTr_font ); 
    checkBoxParallaxTr->setChecked( TRUE );
    layout137_2->addWidget( checkBoxParallaxTr );
    layout138->addLayout( layout137_2 );
    spacer68 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout138->addItem( spacer68 );
    page2Layout_3->addLayout( layout138 );
    spacer69 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page2Layout_3->addItem( spacer69 );
    toolBoxDP2D->addItem( page2_3, QString::fromLatin1("") );

    page_10 = new QWidget( toolBoxDP2D, "page_10" );
    page_10->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_10 = new QVBoxLayout( page_10, 11, 6, "pageLayout_10"); 

    layout141 = new QHBoxLayout( 0, 0, 6, "layout141"); 

    layout140 = new QVBoxLayout( 0, 0, 6, "layout140"); 

    layout139 = new QHBoxLayout( 0, 0, 6, "layout139"); 

    comboBoxNorm = new QComboBox( FALSE, page_10, "comboBoxNorm" );
    comboBoxNorm->setEnabled( TRUE );
    comboBoxNorm->setMinimumSize( QSize( 100, 25 ) );
    comboBoxNorm->setMaximumSize( QSize( 32767, 20000 ) );
    comboBoxNorm->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxNorm->setPalette( pal );
    QFont comboBoxNorm_font(  comboBoxNorm->font() );
    comboBoxNorm->setFont( comboBoxNorm_font ); 
    comboBoxNorm->setDuplicatesEnabled( FALSE );
    layout139->addWidget( comboBoxNorm );

    spinBoxNorm = new QSpinBox( page_10, "spinBoxNorm" );
    spinBoxNorm->setEnabled( FALSE );
    spinBoxNorm->setMinimumSize( QSize( 100, 25 ) );
    spinBoxNorm->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxNorm->setPalette( pal );
    QFont spinBoxNorm_font(  spinBoxNorm->font() );
    spinBoxNorm->setFont( spinBoxNorm_font ); 
    spinBoxNorm->setWrapping( FALSE );
    spinBoxNorm->setMaxValue( 1000000 );
    spinBoxNorm->setMinValue( 1 );
    spinBoxNorm->setLineStep( 1 );
    layout139->addWidget( spinBoxNorm );
    layout140->addLayout( layout139 );

    checkBoxBCTimeNormalization = new QCheckBox( page_10, "checkBoxBCTimeNormalization" );
    checkBoxBCTimeNormalization->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxBCTimeNormalization->sizePolicy().hasHeightForWidth() ) );
    checkBoxBCTimeNormalization->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxBCTimeNormalization->setPalette( pal );
    QFont checkBoxBCTimeNormalization_font(  checkBoxBCTimeNormalization->font() );
    checkBoxBCTimeNormalization->setFont( checkBoxBCTimeNormalization_font ); 
    layout140->addWidget( checkBoxBCTimeNormalization );
    layout141->addLayout( layout140 );
    spacer70 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout141->addItem( spacer70 );
    pageLayout_10->addLayout( layout141 );
    spacer72_2 = new QSpacerItem( 16, 50, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_10->addItem( spacer72_2 );
    toolBoxDP2D->addItem( page_10, QString::fromLatin1("") );

    page_11 = new QWidget( toolBoxDP2D, "page_11" );
    page_11->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_11 = new QVBoxLayout( page_11, 11, 6, "pageLayout_11"); 

    layout144 = new QHBoxLayout( 0, 0, 6, "layout144"); 

    layout143 = new QVBoxLayout( 0, 0, 6, "layout143"); 

    comboBoxIxyFormat = new QComboBox( FALSE, page_11, "comboBoxIxyFormat" );
    comboBoxIxyFormat->setEnabled( TRUE );
    comboBoxIxyFormat->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, comboBoxIxyFormat->sizePolicy().hasHeightForWidth() ) );
    comboBoxIxyFormat->setMinimumSize( QSize( 220, 25 ) );
    comboBoxIxyFormat->setMaximumSize( QSize( 220, 20000 ) );
    comboBoxIxyFormat->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxIxyFormat->setPalette( pal );
    QFont comboBoxIxyFormat_font(  comboBoxIxyFormat->font() );
    comboBoxIxyFormat->setFont( comboBoxIxyFormat_font ); 
    comboBoxIxyFormat->setDuplicatesEnabled( FALSE );
    layout143->addWidget( comboBoxIxyFormat );

    layout142 = new QHBoxLayout( 0, 0, 6, "layout142"); 

    checkBoxASCIIheaderIxy = new QCheckBox( page_11, "checkBoxASCIIheaderIxy" );
    checkBoxASCIIheaderIxy->setChecked( FALSE );
    layout142->addWidget( checkBoxASCIIheaderIxy );

    checkBoxASCIIignoreMask = new QCheckBox( page_11, "checkBoxASCIIignoreMask" );
    checkBoxASCIIignoreMask->setChecked( FALSE );
    layout142->addWidget( checkBoxASCIIignoreMask );
    layout143->addLayout( layout142 );
    layout144->addLayout( layout143 );
    spacer82_2_3 = new QSpacerItem( 162, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout144->addItem( spacer82_2_3 );
    pageLayout_11->addLayout( layout144 );
    spacer75_3 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_11->addItem( spacer75_3 );
    toolBoxDP2D->addItem( page_11, QString::fromLatin1("") );

    page_12 = new QWidget( toolBoxDP2D, "page_12" );
    page_12->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_12 = new QVBoxLayout( page_12, 11, 6, "pageLayout_12"); 

    layout146 = new QHBoxLayout( 0, 0, 6, "layout146"); 

    buttonGroup8_2 = new QButtonGroup( page_12, "buttonGroup8_2" );
    buttonGroup8_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, buttonGroup8_2->sizePolicy().hasHeightForWidth() ) );
    buttonGroup8_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont buttonGroup8_2_font(  buttonGroup8_2->font() );
    buttonGroup8_2_font.setBold( TRUE );
    buttonGroup8_2->setFont( buttonGroup8_2_font ); 
    buttonGroup8_2->setFrameShape( QButtonGroup::NoFrame );
    buttonGroup8_2->setFrameShadow( QButtonGroup::Plain );
    buttonGroup8_2->setLineWidth( 0 );
    buttonGroup8_2->setColumnLayout(0, Qt::Vertical );
    buttonGroup8_2->layout()->setSpacing( 6 );
    buttonGroup8_2->layout()->setMargin( 5 );
    buttonGroup8_2Layout = new QHBoxLayout( buttonGroup8_2->layout() );
    buttonGroup8_2Layout->setAlignment( Qt::AlignTop );

    radioButtonXYdimPixel = new QRadioButton( buttonGroup8_2, "radioButtonXYdimPixel" );
    radioButtonXYdimPixel->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont radioButtonXYdimPixel_font(  radioButtonXYdimPixel->font() );
    radioButtonXYdimPixel_font.setBold( FALSE );
    radioButtonXYdimPixel->setFont( radioButtonXYdimPixel_font ); 
    radioButtonXYdimPixel->setChecked( TRUE );
    buttonGroup8_2Layout->addWidget( radioButtonXYdimPixel );

    radioButtonXYdimQ = new QRadioButton( buttonGroup8_2, "radioButtonXYdimQ" );
    radioButtonXYdimQ->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, radioButtonXYdimQ->sizePolicy().hasHeightForWidth() ) );
    radioButtonXYdimQ->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont radioButtonXYdimQ_font(  radioButtonXYdimQ->font() );
    radioButtonXYdimQ_font.setBold( FALSE );
    radioButtonXYdimQ->setFont( radioButtonXYdimQ_font ); 
    buttonGroup8_2Layout->addWidget( radioButtonXYdimQ );
    layout146->addWidget( buttonGroup8_2 );
    spacer76 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout146->addItem( spacer76 );
    pageLayout_12->addLayout( layout146 );
    spacer78 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_12->addItem( spacer78 );
    toolBoxDP2D->addItem( page_12, QString::fromLatin1("") );

    page_13 = new QWidget( toolBoxDP2D, "page_13" );
    page_13->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_13 = new QVBoxLayout( page_13, 11, 6, "pageLayout_13"); 

    checkBoxMaskNegative = new QCheckBox( page_13, "checkBoxMaskNegative" );
    checkBoxMaskNegative->setEnabled( TRUE );
    checkBoxMaskNegative->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, checkBoxMaskNegative->sizePolicy().hasHeightForWidth() ) );
    checkBoxMaskNegative->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxMaskNegative->setPalette( pal );
    QFont checkBoxMaskNegative_font(  checkBoxMaskNegative->font() );
    checkBoxMaskNegative->setFont( checkBoxMaskNegative_font ); 
    pageLayout_13->addWidget( checkBoxMaskNegative );
    spacer79_2 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_13->addItem( spacer79_2 );
    toolBoxDP2D->addItem( page_13, QString::fromLatin1("") );

    page_14 = new QWidget( toolBoxDP2D, "page_14" );
    page_14->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_14 = new QVBoxLayout( page_14, 11, 6, "pageLayout_14"); 

    layout150 = new QHBoxLayout( 0, 0, 6, "layout150"); 

    layout149 = new QVBoxLayout( 0, 0, 6, "layout149"); 

    layout145 = new QHBoxLayout( 0, 0, 6, "layout145"); 

    spinBoxPolar = new QSpinBox( page_14, "spinBoxPolar" );
    spinBoxPolar->setMinimumSize( QSize( 80, 25 ) );
    spinBoxPolar->setMaximumSize( QSize( 80, 32767 ) );
    spinBoxPolar->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxPolar->setPalette( pal );
    QFont spinBoxPolar_font(  spinBoxPolar->font() );
    spinBoxPolar->setFont( spinBoxPolar_font ); 
    spinBoxPolar->setMaxValue( 500 );
    spinBoxPolar->setMinValue( 4 );
    spinBoxPolar->setValue( 50 );
    layout145->addWidget( spinBoxPolar );

    textLabelMaskLeft_2_3 = new QLabel( page_14, "textLabelMaskLeft_2_3" );
    textLabelMaskLeft_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_font(  textLabelMaskLeft_2_3->font() );
    textLabelMaskLeft_2_3->setFont( textLabelMaskLeft_2_3_font ); 
    layout145->addWidget( textLabelMaskLeft_2_3 );
    layout149->addLayout( layout145 );

    layout146_2 = new QHBoxLayout( 0, 0, 6, "layout146_2"); 

    spinBoxPolarShift = new QSpinBox( page_14, "spinBoxPolarShift" );
    spinBoxPolarShift->setMinimumSize( QSize( 80, 25 ) );
    spinBoxPolarShift->setMaximumSize( QSize( 80, 32767 ) );
    spinBoxPolarShift->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxPolarShift->setPalette( pal );
    QFont spinBoxPolarShift_font(  spinBoxPolarShift->font() );
    spinBoxPolarShift->setFont( spinBoxPolarShift_font ); 
    spinBoxPolarShift->setMaxValue( 360 );
    spinBoxPolarShift->setMinValue( 0 );
    spinBoxPolarShift->setValue( 0 );
    layout146_2->addWidget( spinBoxPolarShift );

    textLabelMaskLeft_2_3_2 = new QLabel( page_14, "textLabelMaskLeft_2_3_2" );
    textLabelMaskLeft_2_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_font(  textLabelMaskLeft_2_3_2->font() );
    textLabelMaskLeft_2_3_2->setFont( textLabelMaskLeft_2_3_2_font ); 
    layout146_2->addWidget( textLabelMaskLeft_2_3_2 );
    layout149->addLayout( layout146_2 );

    checkBoxSkipPolar = new QCheckBox( page_14, "checkBoxSkipPolar" );
    checkBoxSkipPolar->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxSkipPolar->sizePolicy().hasHeightForWidth() ) );
    checkBoxSkipPolar->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxSkipPolar->setPalette( pal );
    QFont checkBoxSkipPolar_font(  checkBoxSkipPolar->font() );
    checkBoxSkipPolar->setFont( checkBoxSkipPolar_font ); 
    checkBoxSkipPolar->setChecked( TRUE );
    layout149->addWidget( checkBoxSkipPolar );
    layout150->addLayout( layout149 );
    spacer80 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout150->addItem( spacer80 );
    pageLayout_14->addLayout( layout150 );
    spacer81 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_14->addItem( spacer81 );
    toolBoxDP2D->addItem( page_14, QString::fromLatin1("") );
    layout186->addWidget( toolBoxDP2D );
    pageLayout_9->addLayout( layout186 );
    toolBox7->addItem( page_9, QString::fromLatin1("") );

    page_15 = new QWidget( toolBox7, "page_15" );
    page_15->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_15 = new QVBoxLayout( page_15, 11, 0, "pageLayout_15"); 

    lineEditMD_2_2_3 = new QLineEdit( page_15, "lineEditMD_2_2_3" );
    lineEditMD_2_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditMD_2_2_3->sizePolicy().hasHeightForWidth() ) );
    lineEditMD_2_2_3->setMinimumSize( QSize( 15, 5 ) );
    lineEditMD_2_2_3->setMaximumSize( QSize( 15000, 5 ) );
    lineEditMD_2_2_3->setPaletteForegroundColor( QColor( 255, 255, 195 ) );
    lineEditMD_2_2_3->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 173, 173, 219) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    lineEditMD_2_2_3->setPalette( pal );
    lineEditMD_2_2_3->setBackgroundOrigin( QLineEdit::WidgetOrigin );
    QFont lineEditMD_2_2_3_font(  lineEditMD_2_2_3->font() );
    lineEditMD_2_2_3->setFont( lineEditMD_2_2_3_font ); 
    lineEditMD_2_2_3->setFrameShape( QLineEdit::Box );
    lineEditMD_2_2_3->setFrameShadow( QLineEdit::Plain );
    lineEditMD_2_2_3->setLineWidth( 1 );
    lineEditMD_2_2_3->setMargin( 0 );
    lineEditMD_2_2_3->setAlignment( int( QLineEdit::AlignHCenter ) );
    lineEditMD_2_2_3->setReadOnly( TRUE );
    pageLayout_15->addWidget( lineEditMD_2_2_3 );

    layout187 = new QHBoxLayout( 0, 0, 0, "layout187"); 

    lineEditMD_2_3_2 = new QLineEdit( page_15, "lineEditMD_2_3_2" );
    lineEditMD_2_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditMD_2_3_2->sizePolicy().hasHeightForWidth() ) );
    lineEditMD_2_3_2->setMinimumSize( QSize( 5, 25 ) );
    lineEditMD_2_3_2->setMaximumSize( QSize( 5, 3200 ) );
    lineEditMD_2_3_2->setPaletteForegroundColor( QColor( 255, 255, 195 ) );
    lineEditMD_2_3_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 173, 173, 219) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    lineEditMD_2_3_2->setPalette( pal );
    lineEditMD_2_3_2->setBackgroundOrigin( QLineEdit::WidgetOrigin );
    QFont lineEditMD_2_3_2_font(  lineEditMD_2_3_2->font() );
    lineEditMD_2_3_2->setFont( lineEditMD_2_3_2_font ); 
    lineEditMD_2_3_2->setFrameShape( QLineEdit::Box );
    lineEditMD_2_3_2->setFrameShadow( QLineEdit::Plain );
    lineEditMD_2_3_2->setLineWidth( 1 );
    lineEditMD_2_3_2->setMargin( 0 );
    lineEditMD_2_3_2->setAlignment( int( QLineEdit::AlignHCenter ) );
    lineEditMD_2_3_2->setReadOnly( TRUE );
    layout187->addWidget( lineEditMD_2_3_2 );

    toolBoxDP1D = new QToolBox( page_15, "toolBoxDP1D" );
    toolBoxDP1D->setEnabled( TRUE );
    toolBoxDP1D->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)3, 0, 0, toolBoxDP1D->sizePolicy().hasHeightForWidth() ) );
    toolBoxDP1D->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    toolBoxDP1D->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 173, 173, 219) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    toolBoxDP1D->setPalette( pal );
    toolBoxDP1D->setBackgroundOrigin( QToolBox::AncestorOrigin );
    toolBoxDP1D->setLineWidth( 1 );
    toolBoxDP1D->setCurrentIndex( 3 );

    page1_4 = new QWidget( toolBoxDP1D, "page1_4" );
    page1_4->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout_4 = new QVBoxLayout( page1_4, 11, 6, "page1Layout_4"); 

    buttonGroup37_2 = new QButtonGroup( page1_4, "buttonGroup37_2" );
    buttonGroup37_2->setLineWidth( 0 );
    buttonGroup37_2->setColumnLayout(0, Qt::Vertical );
    buttonGroup37_2->layout()->setSpacing( 0 );
    buttonGroup37_2->layout()->setMargin( 0 );
    buttonGroup37_2Layout = new QVBoxLayout( buttonGroup37_2->layout() );
    buttonGroup37_2Layout->setAlignment( Qt::AlignTop );

    layout125 = new QHBoxLayout( 0, 0, 6, "layout125"); 

    radioButtonRadStd = new QRadioButton( buttonGroup37_2, "radioButtonRadStd" );
    radioButtonRadStd->setEnabled( TRUE );
    radioButtonRadStd->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, radioButtonRadStd->sizePolicy().hasHeightForWidth() ) );
    radioButtonRadStd->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    radioButtonRadStd->setPalette( pal );
    QFont radioButtonRadStd_font(  radioButtonRadStd->font() );
    radioButtonRadStd->setFont( radioButtonRadStd_font ); 
    radioButtonRadStd->setChecked( FALSE );
    layout125->addWidget( radioButtonRadStd );

    radioButtonRadHF = new QRadioButton( buttonGroup37_2, "radioButtonRadHF" );
    radioButtonRadHF->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, radioButtonRadHF->sizePolicy().hasHeightForWidth() ) );
    radioButtonRadHF->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    radioButtonRadHF->setPalette( pal );
    QFont radioButtonRadHF_font(  radioButtonRadHF->font() );
    radioButtonRadHF->setFont( radioButtonRadHF_font ); 
    radioButtonRadHF->setChecked( TRUE );
    layout125->addWidget( radioButtonRadHF );

    lineEditCommonRatio = new QLineEdit( buttonGroup37_2, "lineEditCommonRatio" );
    lineEditCommonRatio->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditCommonRatio->sizePolicy().hasHeightForWidth() ) );
    lineEditCommonRatio->setMaximumSize( QSize( 70, 32767 ) );
    lineEditCommonRatio->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont lineEditCommonRatio_font(  lineEditCommonRatio->font() );
    lineEditCommonRatio->setFont( lineEditCommonRatio_font ); 
    layout125->addWidget( lineEditCommonRatio );
    spacer54_2 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout125->addItem( spacer54_2 );
    buttonGroup37_2Layout->addLayout( layout125 );
    page1Layout_4->addWidget( buttonGroup37_2 );
    spacer53_2 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page1Layout_4->addItem( spacer53_2 );
    toolBoxDP1D->addItem( page1_4, QString::fromLatin1("") );

    page2_4 = new QWidget( toolBoxDP1D, "page2_4" );
    page2_4->setBackgroundMode( QWidget::PaletteBackground );
    page2Layout_4 = new QVBoxLayout( page2_4, 11, 6, "page2Layout_4"); 

    layout126 = new QHBoxLayout( 0, 0, 6, "layout126"); 

    comboBox4thCol = new QComboBox( FALSE, page2_4, "comboBox4thCol" );
    comboBox4thCol->setEnabled( TRUE );
    comboBox4thCol->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, comboBox4thCol->sizePolicy().hasHeightForWidth() ) );
    comboBox4thCol->setMinimumSize( QSize( 150, 22 ) );
    comboBox4thCol->setMaximumSize( QSize( 32767, 22 ) );
    comboBox4thCol->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBox4thCol->setPalette( pal );
    QFont comboBox4thCol_font(  comboBox4thCol->font() );
    comboBox4thCol->setFont( comboBox4thCol_font ); 
    layout126->addWidget( comboBox4thCol );

    checkBoxASCIIheader = new QCheckBox( page2_4, "checkBoxASCIIheader" );
    checkBoxASCIIheader->setChecked( TRUE );
    layout126->addWidget( checkBoxASCIIheader );
    spacer55_2 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout126->addItem( spacer55_2 );
    page2Layout_4->addLayout( layout126 );
    spacer56_2 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page2Layout_4->addItem( spacer56_2 );
    toolBoxDP1D->addItem( page2_4, QString::fromLatin1("") );

    page_16 = new QWidget( toolBoxDP1D, "page_16" );
    page_16->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_16 = new QVBoxLayout( page_16, 11, 6, "pageLayout_16"); 

    layout127 = new QHBoxLayout( 0, 0, 6, "layout127"); 

    comboBoxSelectPresentation = new QComboBox( FALSE, page_16, "comboBoxSelectPresentation" );
    comboBoxSelectPresentation->setEnabled( TRUE );
    comboBoxSelectPresentation->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, comboBoxSelectPresentation->sizePolicy().hasHeightForWidth() ) );
    comboBoxSelectPresentation->setMinimumSize( QSize( 150, 22 ) );
    comboBoxSelectPresentation->setMaximumSize( QSize( 250, 22 ) );
    comboBoxSelectPresentation->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    comboBoxSelectPresentation->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxSelectPresentation->setPalette( pal );
    QFont comboBoxSelectPresentation_font(  comboBoxSelectPresentation->font() );
    comboBoxSelectPresentation->setFont( comboBoxSelectPresentation_font ); 
    layout127->addWidget( comboBoxSelectPresentation );

    textLabelPres = new QLabel( page_16, "textLabelPres" );
    textLabelPres->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabelPres->sizePolicy().hasHeightForWidth() ) );
    textLabelPres->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont textLabelPres_font(  textLabelPres->font() );
    textLabelPres_font.setFamily( "Lucida Grande" );
    textLabelPres->setFont( textLabelPres_font ); 
    textLabelPres->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );
    layout127->addWidget( textLabelPres );
    spacer57_3 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout127->addItem( spacer57_3 );
    pageLayout_16->addLayout( layout127 );
    spacer58 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_16->addItem( spacer58 );
    toolBoxDP1D->addItem( page_16, QString::fromLatin1("") );

    page_17 = new QWidget( toolBoxDP1D, "page_17" );
    page_17->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_17 = new QVBoxLayout( page_17, 11, 6, "pageLayout_17"); 

    layout129 = new QHBoxLayout( 0, 0, 6, "layout129"); 

    layout128 = new QVBoxLayout( 0, 0, 3, "layout128"); 

    spinBoxRemoveFirst = new QSpinBox( page_17, "spinBoxRemoveFirst" );
    spinBoxRemoveFirst->setMinimumSize( QSize( 150, 25 ) );
    spinBoxRemoveFirst->setMaximumSize( QSize( 32767, 25 ) );
    spinBoxRemoveFirst->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxRemoveFirst->setPalette( pal );
    QFont spinBoxRemoveFirst_font(  spinBoxRemoveFirst->font() );
    spinBoxRemoveFirst->setFont( spinBoxRemoveFirst_font ); 
    spinBoxRemoveFirst->setMaxValue( 2048 );
    layout128->addWidget( spinBoxRemoveFirst );

    spinBoxRemoveLast = new QSpinBox( page_17, "spinBoxRemoveLast" );
    spinBoxRemoveLast->setMinimumSize( QSize( 170, 25 ) );
    spinBoxRemoveLast->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxRemoveLast->setPalette( pal );
    QFont spinBoxRemoveLast_font(  spinBoxRemoveLast->font() );
    spinBoxRemoveLast->setFont( spinBoxRemoveLast_font ); 
    spinBoxRemoveLast->setMaxValue( 2048 );
    layout128->addWidget( spinBoxRemoveLast );

    checkBoxMaskNegativeQ = new QCheckBox( page_17, "checkBoxMaskNegativeQ" );
    checkBoxMaskNegativeQ->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxMaskNegativeQ->sizePolicy().hasHeightForWidth() ) );
    checkBoxMaskNegativeQ->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxMaskNegativeQ->setPalette( pal );
    QFont checkBoxMaskNegativeQ_font(  checkBoxMaskNegativeQ->font() );
    checkBoxMaskNegativeQ->setFont( checkBoxMaskNegativeQ_font ); 
    layout128->addWidget( checkBoxMaskNegativeQ );
    layout129->addLayout( layout128 );
    spacer59 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout129->addItem( spacer59 );
    pageLayout_17->addLayout( layout129 );
    spacer60 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_17->addItem( spacer60 );
    toolBoxDP1D->addItem( page_17, QString::fromLatin1("") );

    page_18 = new QWidget( toolBoxDP1D, "page_18" );
    page_18->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_18 = new QVBoxLayout( page_18, 11, 6, "pageLayout_18"); 

    layout130 = new QHBoxLayout( 0, 0, 6, "layout130"); 

    spinBoxFrom = new QSpinBox( page_18, "spinBoxFrom" );
    spinBoxFrom->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, spinBoxFrom->sizePolicy().hasHeightForWidth() ) );
    spinBoxFrom->setMinimumSize( QSize( 90, 25 ) );
    spinBoxFrom->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxFrom->setPalette( pal );
    QFont spinBoxFrom_font(  spinBoxFrom->font() );
    spinBoxFrom->setFont( spinBoxFrom_font ); 
    spinBoxFrom->setMaxValue( 128 );
    spinBoxFrom->setMinValue( 1 );
    layout130->addWidget( spinBoxFrom );

    spinBoxTo = new QSpinBox( page_18, "spinBoxTo" );
    spinBoxTo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, spinBoxTo->sizePolicy().hasHeightForWidth() ) );
    spinBoxTo->setMinimumSize( QSize( 90, 25 ) );
    spinBoxTo->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxTo->setPalette( pal );
    QFont spinBoxTo_font(  spinBoxTo->font() );
    spinBoxTo->setFont( spinBoxTo_font ); 
    spinBoxTo->setMaxValue( 128 );
    spinBoxTo->setMinValue( 1 );
    spinBoxTo->setValue( 128 );
    layout130->addWidget( spinBoxTo );
    spacer39 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout130->addItem( spacer39 );
    pageLayout_18->addLayout( layout130 );
    spacer62 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_18->addItem( spacer62 );
    toolBoxDP1D->addItem( page_18, QString::fromLatin1("") );

    page_19 = new QWidget( toolBoxDP1D, "page_19" );
    page_19->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_19 = new QVBoxLayout( page_19, 11, 6, "pageLayout_19"); 

    layout131 = new QHBoxLayout( 0, 0, 6, "layout131"); 

    spinBoxMCshiftAngle = new QSpinBox( page_19, "spinBoxMCshiftAngle" );
    spinBoxMCshiftAngle->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, spinBoxMCshiftAngle->sizePolicy().hasHeightForWidth() ) );
    spinBoxMCshiftAngle->setMinimumSize( QSize( 120, 25 ) );
    spinBoxMCshiftAngle->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxMCshiftAngle->setPalette( pal );
    QFont spinBoxMCshiftAngle_font(  spinBoxMCshiftAngle->font() );
    spinBoxMCshiftAngle->setFont( spinBoxMCshiftAngle_font ); 
    spinBoxMCshiftAngle->setMaxValue( 180 );
    spinBoxMCshiftAngle->setMinValue( -180 );
    spinBoxMCshiftAngle->setValue( 0 );
    layout131->addWidget( spinBoxMCshiftAngle );

    spinBoxMCcheckQ = new QSpinBox( page_19, "spinBoxMCcheckQ" );
    spinBoxMCcheckQ->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, spinBoxMCcheckQ->sizePolicy().hasHeightForWidth() ) );
    spinBoxMCcheckQ->setMinimumSize( QSize( 120, 25 ) );
    spinBoxMCcheckQ->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxMCcheckQ->setPalette( pal );
    QFont spinBoxMCcheckQ_font(  spinBoxMCcheckQ->font() );
    spinBoxMCcheckQ->setFont( spinBoxMCcheckQ_font ); 
    spinBoxMCcheckQ->setMaxValue( 180 );
    spinBoxMCcheckQ->setMinValue( 0 );
    spinBoxMCcheckQ->setValue( 0 );
    layout131->addWidget( spinBoxMCcheckQ );
    spacer63 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout131->addItem( spacer63 );
    pageLayout_19->addLayout( layout131 );
    spacer64 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_19->addItem( spacer64 );
    toolBoxDP1D->addItem( page_19, QString::fromLatin1("") );
    layout187->addWidget( toolBoxDP1D );
    pageLayout_15->addLayout( layout187 );
    toolBox7->addItem( page_15, QString::fromLatin1("") );

    page_20 = new QWidget( toolBox7, "page_20" );
    page_20->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_20 = new QVBoxLayout( page_20, 11, 0, "pageLayout_20"); 

    lineEditMD_2_2_3_2 = new QLineEdit( page_20, "lineEditMD_2_2_3_2" );
    lineEditMD_2_2_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditMD_2_2_3_2->sizePolicy().hasHeightForWidth() ) );
    lineEditMD_2_2_3_2->setMinimumSize( QSize( 15, 5 ) );
    lineEditMD_2_2_3_2->setMaximumSize( QSize( 15000, 5 ) );
    lineEditMD_2_2_3_2->setPaletteForegroundColor( QColor( 255, 255, 195 ) );
    lineEditMD_2_2_3_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 173, 173, 219) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    lineEditMD_2_2_3_2->setPalette( pal );
    lineEditMD_2_2_3_2->setBackgroundOrigin( QLineEdit::WidgetOrigin );
    QFont lineEditMD_2_2_3_2_font(  lineEditMD_2_2_3_2->font() );
    lineEditMD_2_2_3_2->setFont( lineEditMD_2_2_3_2_font ); 
    lineEditMD_2_2_3_2->setFrameShape( QLineEdit::Box );
    lineEditMD_2_2_3_2->setFrameShadow( QLineEdit::Plain );
    lineEditMD_2_2_3_2->setLineWidth( 1 );
    lineEditMD_2_2_3_2->setMargin( 0 );
    lineEditMD_2_2_3_2->setAlignment( int( QLineEdit::AlignHCenter ) );
    lineEditMD_2_2_3_2->setReadOnly( TRUE );
    pageLayout_20->addWidget( lineEditMD_2_2_3_2 );

    layout190 = new QHBoxLayout( 0, 0, 0, "layout190"); 

    lineEditMD_2_3_3 = new QLineEdit( page_20, "lineEditMD_2_3_3" );
    lineEditMD_2_3_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, lineEditMD_2_3_3->sizePolicy().hasHeightForWidth() ) );
    lineEditMD_2_3_3->setMinimumSize( QSize( 5, 25 ) );
    lineEditMD_2_3_3->setMaximumSize( QSize( 5, 3200 ) );
    lineEditMD_2_3_3->setPaletteForegroundColor( QColor( 255, 255, 195 ) );
    lineEditMD_2_3_3->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 173, 173, 219) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    lineEditMD_2_3_3->setPalette( pal );
    lineEditMD_2_3_3->setBackgroundOrigin( QLineEdit::WidgetOrigin );
    QFont lineEditMD_2_3_3_font(  lineEditMD_2_3_3->font() );
    lineEditMD_2_3_3->setFont( lineEditMD_2_3_3_font ); 
    lineEditMD_2_3_3->setFrameShape( QLineEdit::Box );
    lineEditMD_2_3_3->setFrameShadow( QLineEdit::Plain );
    lineEditMD_2_3_3->setLineWidth( 1 );
    lineEditMD_2_3_3->setMargin( 0 );
    lineEditMD_2_3_3->setAlignment( int( QLineEdit::AlignHCenter ) );
    lineEditMD_2_3_3->setReadOnly( TRUE );
    layout190->addWidget( lineEditMD_2_3_3 );

    layout189 = new QVBoxLayout( 0, 0, 6, "layout189"); 

    groupBox16 = new QGroupBox( page_20, "groupBox16" );
    groupBox16->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, groupBox16->sizePolicy().hasHeightForWidth() ) );
    groupBox16->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    groupBox16->setPalette( pal );
    QFont groupBox16_font(  groupBox16->font() );
    groupBox16_font.setBold( TRUE );
    groupBox16->setFont( groupBox16_font ); 
    groupBox16->setFrameShape( QGroupBox::NoFrame );
    groupBox16->setFrameShadow( QGroupBox::Plain );
    groupBox16->setLineWidth( 0 );
    groupBox16->setColumnLayout(0, Qt::Vertical );
    groupBox16->layout()->setSpacing( 0 );
    groupBox16->layout()->setMargin( 5 );
    groupBox16Layout = new QVBoxLayout( groupBox16->layout() );
    groupBox16Layout->setAlignment( Qt::AlignTop );

    checkBoxRecalculateUseNumber = new QCheckBox( groupBox16, "checkBoxRecalculateUseNumber" );
    checkBoxRecalculateUseNumber->setEnabled( TRUE );
    checkBoxRecalculateUseNumber->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxRecalculateUseNumber->setPalette( pal );
    QFont checkBoxRecalculateUseNumber_font(  checkBoxRecalculateUseNumber->font() );
    checkBoxRecalculateUseNumber_font.setBold( FALSE );
    checkBoxRecalculateUseNumber->setFont( checkBoxRecalculateUseNumber_font ); 
    checkBoxRecalculateUseNumber->setChecked( FALSE );
    groupBox16Layout->addWidget( checkBoxRecalculateUseNumber );

    checkBoxAttenuatorAsPara = new QCheckBox( groupBox16, "checkBoxAttenuatorAsPara" );
    checkBoxAttenuatorAsPara->setEnabled( TRUE );
    checkBoxAttenuatorAsPara->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxAttenuatorAsPara->setPalette( pal );
    QFont checkBoxAttenuatorAsPara_font(  checkBoxAttenuatorAsPara->font() );
    checkBoxAttenuatorAsPara_font.setBold( FALSE );
    checkBoxAttenuatorAsPara->setFont( checkBoxAttenuatorAsPara_font ); 
    checkBoxAttenuatorAsPara->setChecked( FALSE );
    groupBox16Layout->addWidget( checkBoxAttenuatorAsPara );

    checkBoxBeamcenterAsPara = new QCheckBox( groupBox16, "checkBoxBeamcenterAsPara" );
    checkBoxBeamcenterAsPara->setEnabled( TRUE );
    checkBoxBeamcenterAsPara->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxBeamcenterAsPara->setPalette( pal );
    QFont checkBoxBeamcenterAsPara_font(  checkBoxBeamcenterAsPara->font() );
    checkBoxBeamcenterAsPara_font.setBold( FALSE );
    checkBoxBeamcenterAsPara->setFont( checkBoxBeamcenterAsPara_font ); 
    checkBoxBeamcenterAsPara->setChecked( FALSE );
    groupBox16Layout->addWidget( checkBoxBeamcenterAsPara );

    checkBoxPolarizationAsPara = new QCheckBox( groupBox16, "checkBoxPolarizationAsPara" );
    checkBoxPolarizationAsPara->setEnabled( TRUE );
    checkBoxPolarizationAsPara->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxPolarizationAsPara->setPalette( pal );
    QFont checkBoxPolarizationAsPara_font(  checkBoxPolarizationAsPara->font() );
    checkBoxPolarizationAsPara_font.setBold( FALSE );
    checkBoxPolarizationAsPara->setFont( checkBoxPolarizationAsPara_font ); 
    checkBoxPolarizationAsPara->setChecked( TRUE );
    groupBox16Layout->addWidget( checkBoxPolarizationAsPara );

    checkBoxRecalculate = new QCheckBox( groupBox16, "checkBoxRecalculate" );
    checkBoxRecalculate->setEnabled( TRUE );
    checkBoxRecalculate->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxRecalculate->setPalette( pal );
    QFont checkBoxRecalculate_font(  checkBoxRecalculate->font() );
    checkBoxRecalculate_font.setBold( FALSE );
    checkBoxRecalculate->setFont( checkBoxRecalculate_font ); 
    checkBoxRecalculate->setChecked( FALSE );
    groupBox16Layout->addWidget( checkBoxRecalculate );

    checkBoxFindCenter = new QCheckBox( groupBox16, "checkBoxFindCenter" );
    checkBoxFindCenter->setEnabled( TRUE );
    checkBoxFindCenter->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxFindCenter->setPalette( pal );
    QFont checkBoxFindCenter_font(  checkBoxFindCenter->font() );
    checkBoxFindCenter_font.setBold( FALSE );
    checkBoxFindCenter->setFont( checkBoxFindCenter_font ); 
    groupBox16Layout->addWidget( checkBoxFindCenter );

    checkBoxForceCopyPaste = new QCheckBox( groupBox16, "checkBoxForceCopyPaste" );
    checkBoxForceCopyPaste->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxForceCopyPaste->setPalette( pal );
    QFont checkBoxForceCopyPaste_font(  checkBoxForceCopyPaste->font() );
    checkBoxForceCopyPaste_font.setBold( FALSE );
    checkBoxForceCopyPaste->setFont( checkBoxForceCopyPaste_font ); 
    checkBoxForceCopyPaste->setChecked( TRUE );
    checkBoxForceCopyPaste->setTristate( FALSE );
    groupBox16Layout->addWidget( checkBoxForceCopyPaste );

    checkBoxNameAsTableName = new QCheckBox( groupBox16, "checkBoxNameAsTableName" );
    checkBoxNameAsTableName->setEnabled( TRUE );
    checkBoxNameAsTableName->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxNameAsTableName->setPalette( pal );
    QFont checkBoxNameAsTableName_font(  checkBoxNameAsTableName->font() );
    checkBoxNameAsTableName_font.setBold( FALSE );
    checkBoxNameAsTableName->setFont( checkBoxNameAsTableName_font ); 
    groupBox16Layout->addWidget( checkBoxNameAsTableName );

    checkBoxMergingTable = new QCheckBox( groupBox16, "checkBoxMergingTable" );
    checkBoxMergingTable->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxMergingTable->setPalette( pal );
    QFont checkBoxMergingTable_font(  checkBoxMergingTable->font() );
    checkBoxMergingTable_font.setBold( FALSE );
    checkBoxMergingTable->setFont( checkBoxMergingTable_font ); 
    checkBoxMergingTable->setChecked( TRUE );
    groupBox16Layout->addWidget( checkBoxMergingTable );

    checkBoxRewriteOutput = new QCheckBox( groupBox16, "checkBoxRewriteOutput" );
    checkBoxRewriteOutput->setEnabled( TRUE );
    checkBoxRewriteOutput->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxRewriteOutput->setPalette( pal );
    QFont checkBoxRewriteOutput_font(  checkBoxRewriteOutput->font() );
    checkBoxRewriteOutput_font.setBold( FALSE );
    checkBoxRewriteOutput->setFont( checkBoxRewriteOutput_font ); 
    checkBoxRewriteOutput->setChecked( TRUE );
    groupBox16Layout->addWidget( checkBoxRewriteOutput );

    checkBoxSkiptransmisionConfigurations = new QCheckBox( groupBox16, "checkBoxSkiptransmisionConfigurations" );
    checkBoxSkiptransmisionConfigurations->setEnabled( TRUE );
    checkBoxSkiptransmisionConfigurations->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxSkiptransmisionConfigurations->setPalette( pal );
    QFont checkBoxSkiptransmisionConfigurations_font(  checkBoxSkiptransmisionConfigurations->font() );
    checkBoxSkiptransmisionConfigurations_font.setBold( FALSE );
    checkBoxSkiptransmisionConfigurations->setFont( checkBoxSkiptransmisionConfigurations_font ); 
    groupBox16Layout->addWidget( checkBoxSkiptransmisionConfigurations );

    checkBoxSortOutputToFolders = new QCheckBox( groupBox16, "checkBoxSortOutputToFolders" );
    checkBoxSortOutputToFolders->setEnabled( TRUE );
    checkBoxSortOutputToFolders->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxSortOutputToFolders->setPalette( pal );
    QFont checkBoxSortOutputToFolders_font(  checkBoxSortOutputToFolders->font() );
    checkBoxSortOutputToFolders_font.setBold( FALSE );
    checkBoxSortOutputToFolders->setFont( checkBoxSortOutputToFolders_font ); 
    checkBoxSortOutputToFolders->setChecked( TRUE );
    groupBox16Layout->addWidget( checkBoxSortOutputToFolders );
    layout189->addWidget( groupBox16 );
    spacer43 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::MinimumExpanding );
    layout189->addItem( spacer43 );
    layout190->addLayout( layout189 );
    pageLayout_20->addLayout( layout190 );
    toolBox7->addItem( page_20, QString::fromLatin1("") );

    page_21 = new QWidget( toolBox7, "page_21" );
    page_21->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_21 = new QVBoxLayout( page_21, 11, 6, "pageLayout_21"); 

    layout121 = new QHBoxLayout( 0, 0, 0, "layout121"); 

    layout119 = new QVBoxLayout( 0, 4, 6, "layout119"); 

    pushButtonEasyDAN = new QToolButton( page_21, "pushButtonEasyDAN" );
    pushButtonEasyDAN->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonEasyDAN->sizePolicy().hasHeightForWidth() ) );
    pushButtonEasyDAN->setMinimumSize( QSize( 50, 51 ) );
    pushButtonEasyDAN->setMaximumSize( QSize( 50, 32767 ) );
    pushButtonEasyDAN->setUsesTextLabel( FALSE );
    pushButtonEasyDAN->setAutoRaise( FALSE );
    pushButtonEasyDAN->setTextPosition( QToolButton::BelowIcon );
    layout119->addWidget( pushButtonEasyDAN );
    spacerInstr_2_3_2_2 = new QSpacerItem( 5, 31, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout119->addItem( spacerInstr_2_3_2_2 );
    layout121->addLayout( layout119 );

    line1_2_3_11_5_6_2 = new QFrame( page_21, "line1_2_3_11_5_6_2" );
    line1_2_3_11_5_6_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)7, 0, 0, line1_2_3_11_5_6_2->sizePolicy().hasHeightForWidth() ) );
    line1_2_3_11_5_6_2->setMaximumSize( QSize( 3, 32767 ) );
    line1_2_3_11_5_6_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_6_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_6_2->setFrameShape( QFrame::VLine );
    line1_2_3_11_5_6_2->setFrameShadow( QFrame::Plain );
    line1_2_3_11_5_6_2->setLineWidth( 2 );
    line1_2_3_11_5_6_2->setFrameShape( QFrame::VLine );
    layout121->addWidget( line1_2_3_11_5_6_2 );

    layout117 = new QVBoxLayout( 0, 0, 0, "layout117"); 

    toolBox7_2 = new QToolBox( page_21, "toolBox7_2" );
    toolBox7_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, toolBox7_2->sizePolicy().hasHeightForWidth() ) );
    toolBox7_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 173, 173, 219) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Light, QColor( 210, 210, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 157, 157, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 68, 68, 91) );
    cg.setColor( QColorGroup::Mid, QColor( 91, 91, 122) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    toolBox7_2->setPalette( pal );
    toolBox7_2->setBackgroundOrigin( QToolBox::AncestorOrigin );
    toolBox7_2->setFrameShape( QToolBox::NoFrame );
    toolBox7_2->setFrameShadow( QToolBox::Plain );
    toolBox7_2->setLineWidth( 1 );
    toolBox7_2->setMargin( 0 );
    toolBox7_2->setMidLineWidth( 0 );
    toolBox7_2->setCurrentIndex( 0 );

    page1_5 = new QWidget( toolBox7_2, "page1_5" );
    page1_5->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout_5 = new QVBoxLayout( page1_5, 11, 3, "page1Layout_5"); 

    layout88_2 = new QHBoxLayout( 0, 0, 6, "layout88_2"); 

    spinBoxEDfiltrationTIME = new QSpinBox( page1_5, "spinBoxEDfiltrationTIME" );
    spinBoxEDfiltrationTIME->setMinimumSize( QSize( 170, 20 ) );
    spinBoxEDfiltrationTIME->setMaximumSize( QSize( 32767, 20 ) );
    spinBoxEDfiltrationTIME->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxEDfiltrationTIME->setPalette( pal );
    QFont spinBoxEDfiltrationTIME_font(  spinBoxEDfiltrationTIME->font() );
    spinBoxEDfiltrationTIME->setFont( spinBoxEDfiltrationTIME_font ); 
    spinBoxEDfiltrationTIME->setMaxValue( 2048000000 );
    spinBoxEDfiltrationTIME->setMinValue( -1 );
    spinBoxEDfiltrationTIME->setValue( 30 );
    layout88_2->addWidget( spinBoxEDfiltrationTIME );

    textLabelMaskLeft_2_3_2_2_2_2_3_2_4 = new QLabel( page1_5, "textLabelMaskLeft_2_3_2_2_2_2_3_2_4" );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_4->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2_3_2_4->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_4->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_3_2_4_font(  textLabelMaskLeft_2_3_2_2_2_2_3_2_4->font() );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_4->setFont( textLabelMaskLeft_2_3_2_2_2_2_3_2_4_font ); 
    layout88_2->addWidget( textLabelMaskLeft_2_3_2_2_2_2_3_2_4 );
    page1Layout_5->addLayout( layout88_2 );

    layout89 = new QHBoxLayout( 0, 0, 6, "layout89"); 

    spinBoxEDfiltrationSUM = new QSpinBox( page1_5, "spinBoxEDfiltrationSUM" );
    spinBoxEDfiltrationSUM->setMinimumSize( QSize( 170, 20 ) );
    spinBoxEDfiltrationSUM->setMaximumSize( QSize( 32767, 20 ) );
    spinBoxEDfiltrationSUM->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxEDfiltrationSUM->setPalette( pal );
    QFont spinBoxEDfiltrationSUM_font(  spinBoxEDfiltrationSUM->font() );
    spinBoxEDfiltrationSUM->setFont( spinBoxEDfiltrationSUM_font ); 
    spinBoxEDfiltrationSUM->setMaxValue( 2147400117 );
    spinBoxEDfiltrationSUM->setMinValue( -1 );
    spinBoxEDfiltrationSUM->setValue( 100 );
    layout89->addWidget( spinBoxEDfiltrationSUM );

    textLabelMaskLeft_2_3_2_2_2_2_3_2_4_2 = new QLabel( page1_5, "textLabelMaskLeft_2_3_2_2_2_2_3_2_4_2" );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_4_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2_3_2_4_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_4_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_3_2_4_2_font(  textLabelMaskLeft_2_3_2_2_2_2_3_2_4_2->font() );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_4_2->setFont( textLabelMaskLeft_2_3_2_2_2_2_3_2_4_2_font ); 
    layout89->addWidget( textLabelMaskLeft_2_3_2_2_2_2_3_2_4_2 );
    page1Layout_5->addLayout( layout89 );

    layout75_2_2_3_2 = new QHBoxLayout( 0, 0, 6, "layout75_2_2_3_2"); 

    lineEditEDwildcardFILEACCEPT = new QLineEdit( page1_5, "lineEditEDwildcardFILEACCEPT" );
    lineEditEDwildcardFILEACCEPT->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, lineEditEDwildcardFILEACCEPT->sizePolicy().hasHeightForWidth() ) );
    lineEditEDwildcardFILEACCEPT->setMinimumSize( QSize( 170, 20 ) );
    lineEditEDwildcardFILEACCEPT->setMaximumSize( QSize( 32767, 20 ) );
    lineEditEDwildcardFILEACCEPT->setFrameShape( QLineEdit::NoFrame );
    layout75_2_2_3_2->addWidget( lineEditEDwildcardFILEACCEPT );

    textLabelMaskLeft_2_3_2_2_2_2_3_2 = new QLabel( page1_5, "textLabelMaskLeft_2_3_2_2_2_2_3_2" );
    textLabelMaskLeft_2_3_2_2_2_2_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_3_2_font(  textLabelMaskLeft_2_3_2_2_2_2_3_2->font() );
    textLabelMaskLeft_2_3_2_2_2_2_3_2->setFont( textLabelMaskLeft_2_3_2_2_2_2_3_2_font ); 
    layout75_2_2_3_2->addWidget( textLabelMaskLeft_2_3_2_2_2_2_3_2 );
    page1Layout_5->addLayout( layout75_2_2_3_2 );

    layout75_2_2_3_2_2 = new QHBoxLayout( 0, 0, 6, "layout75_2_2_3_2_2"); 

    lineEditEDwildcardFILESKIP = new QLineEdit( page1_5, "lineEditEDwildcardFILESKIP" );
    lineEditEDwildcardFILESKIP->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)4, (QSizePolicy::SizeType)0, 0, 0, lineEditEDwildcardFILESKIP->sizePolicy().hasHeightForWidth() ) );
    lineEditEDwildcardFILESKIP->setMinimumSize( QSize( 170, 20 ) );
    lineEditEDwildcardFILESKIP->setMaximumSize( QSize( 32767, 20 ) );
    lineEditEDwildcardFILESKIP->setFrameShape( QLineEdit::NoFrame );
    layout75_2_2_3_2_2->addWidget( lineEditEDwildcardFILESKIP );

    textLabelMaskLeft_2_3_2_2_2_2_3_2_2 = new QLabel( page1_5, "textLabelMaskLeft_2_3_2_2_2_2_3_2_2" );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2_3_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_3_2_2_font(  textLabelMaskLeft_2_3_2_2_2_2_3_2_2->font() );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_2->setFont( textLabelMaskLeft_2_3_2_2_2_2_3_2_2_font ); 
    layout75_2_2_3_2_2->addWidget( textLabelMaskLeft_2_3_2_2_2_2_3_2_2 );
    page1Layout_5->addLayout( layout75_2_2_3_2_2 );

    layout75_2_2_3_2_3 = new QHBoxLayout( 0, 0, 6, "layout75_2_2_3_2_3"); 

    lineEditEDwildcardSAMPLEACCEPT = new QLineEdit( page1_5, "lineEditEDwildcardSAMPLEACCEPT" );
    lineEditEDwildcardSAMPLEACCEPT->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, lineEditEDwildcardSAMPLEACCEPT->sizePolicy().hasHeightForWidth() ) );
    lineEditEDwildcardSAMPLEACCEPT->setMinimumSize( QSize( 170, 20 ) );
    lineEditEDwildcardSAMPLEACCEPT->setMaximumSize( QSize( 32767, 20 ) );
    lineEditEDwildcardSAMPLEACCEPT->setFrameShape( QLineEdit::NoFrame );
    layout75_2_2_3_2_3->addWidget( lineEditEDwildcardSAMPLEACCEPT );

    textLabelMaskLeft_2_3_2_2_2_2_3_2_3 = new QLabel( page1_5, "textLabelMaskLeft_2_3_2_2_2_2_3_2_3" );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2_3_2_3->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_3_2_3_font(  textLabelMaskLeft_2_3_2_2_2_2_3_2_3->font() );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_3->setFont( textLabelMaskLeft_2_3_2_2_2_2_3_2_3_font ); 
    layout75_2_2_3_2_3->addWidget( textLabelMaskLeft_2_3_2_2_2_2_3_2_3 );
    page1Layout_5->addLayout( layout75_2_2_3_2_3 );

    layout75_2_2_3_2_2_2 = new QHBoxLayout( 0, 0, 6, "layout75_2_2_3_2_2_2"); 

    lineEditEDwildcardSAMPLESKIP = new QLineEdit( page1_5, "lineEditEDwildcardSAMPLESKIP" );
    lineEditEDwildcardSAMPLESKIP->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)4, (QSizePolicy::SizeType)0, 170, 20, lineEditEDwildcardSAMPLESKIP->sizePolicy().hasHeightForWidth() ) );
    lineEditEDwildcardSAMPLESKIP->setMinimumSize( QSize( 170, 20 ) );
    lineEditEDwildcardSAMPLESKIP->setMaximumSize( QSize( 32767, 20 ) );
    lineEditEDwildcardSAMPLESKIP->setFrameShape( QLineEdit::NoFrame );
    layout75_2_2_3_2_2_2->addWidget( lineEditEDwildcardSAMPLESKIP );

    textLabelMaskLeft_2_3_2_2_2_2_3_2_2_2 = new QLabel( page1_5, "textLabelMaskLeft_2_3_2_2_2_2_3_2_2_2" );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2_3_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_3_2_2_2_font(  textLabelMaskLeft_2_3_2_2_2_2_3_2_2_2->font() );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_2_2->setFont( textLabelMaskLeft_2_3_2_2_2_2_3_2_2_2_font ); 
    layout75_2_2_3_2_2_2->addWidget( textLabelMaskLeft_2_3_2_2_2_2_3_2_2_2 );
    page1Layout_5->addLayout( layout75_2_2_3_2_2_2 );
    spacerInstr_2_4 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page1Layout_5->addItem( spacerInstr_2_4 );
    toolBox7_2->addItem( page1_5, QString::fromLatin1("") );

    page2_5 = new QWidget( toolBox7_2, "page2_5" );
    page2_5->setBackgroundMode( QWidget::PaletteBackground );
    page2Layout_5 = new QVBoxLayout( page2_5, 11, 3, "page2Layout_5"); 

    checkBoxEDmaskMASK = new QCheckBox( page2_5, "checkBoxEDmaskMASK" );
    checkBoxEDmaskMASK->setEnabled( FALSE );
    checkBoxEDmaskMASK->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxEDmaskMASK->setChecked( TRUE );
    page2Layout_5->addWidget( checkBoxEDmaskMASK );

    checkBoxEDmaskMASKTR = new QCheckBox( page2_5, "checkBoxEDmaskMASKTR" );
    checkBoxEDmaskMASKTR->setEnabled( TRUE );
    checkBoxEDmaskMASKTR->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxEDmaskMASKTR->setChecked( FALSE );
    page2Layout_5->addWidget( checkBoxEDmaskMASKTR );

    checkBoxEDmaskMASKTR_2 = new QCheckBox( page2_5, "checkBoxEDmaskMASKTR_2" );
    checkBoxEDmaskMASKTR_2->setEnabled( TRUE );
    checkBoxEDmaskMASKTR_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxEDmaskMASKTR_2->setChecked( FALSE );
    page2Layout_5->addWidget( checkBoxEDmaskMASKTR_2 );
    spacerInstr_2 = new QSpacerItem( 5, 11, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page2Layout_5->addItem( spacerInstr_2 );
    toolBox7_2->addItem( page2_5, QString::fromLatin1("") );

    page_22 = new QWidget( toolBox7_2, "page_22" );
    page_22->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_22 = new QVBoxLayout( page_22, 11, 3, "pageLayout_22"); 

    layout75_2_2_3 = new QHBoxLayout( 0, 0, 6, "layout75_2_2_3"); 

    lineEditACFSwildcard_2 = new QLineEdit( page_22, "lineEditACFSwildcard_2" );
    lineEditACFSwildcard_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditACFSwildcard_2->sizePolicy().hasHeightForWidth() ) );
    lineEditACFSwildcard_2->setMaximumSize( QSize( 32767, 20 ) );
    lineEditACFSwildcard_2->setFrameShape( QLineEdit::NoFrame );
    layout75_2_2_3->addWidget( lineEditACFSwildcard_2 );

    textLabelMaskLeft_2_3_2_2_2_2_3 = new QLabel( page_22, "textLabelMaskLeft_2_3_2_2_2_2_3" );
    textLabelMaskLeft_2_3_2_2_2_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2_3->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_3_font(  textLabelMaskLeft_2_3_2_2_2_2_3->font() );
    textLabelMaskLeft_2_3_2_2_2_2_3->setFont( textLabelMaskLeft_2_3_2_2_2_2_3_font ); 
    layout75_2_2_3->addWidget( textLabelMaskLeft_2_3_2_2_2_2_3 );
    pageLayout_22->addLayout( layout75_2_2_3 );

    layout75_2_2_2_3 = new QHBoxLayout( 0, 0, 6, "layout75_2_2_2_3"); 

    lineEditACEBwildcard_3 = new QLineEdit( page_22, "lineEditACEBwildcard_3" );
    lineEditACEBwildcard_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditACEBwildcard_3->sizePolicy().hasHeightForWidth() ) );
    lineEditACEBwildcard_3->setMaximumSize( QSize( 32767, 20 ) );
    lineEditACEBwildcard_3->setFrameShape( QLineEdit::NoFrame );
    layout75_2_2_2_3->addWidget( lineEditACEBwildcard_3 );

    textLabelMaskLeft_2_3_2_2_2_2_2_3 = new QLabel( page_22, "textLabelMaskLeft_2_3_2_2_2_2_2_3" );
    textLabelMaskLeft_2_3_2_2_2_2_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2_2_3->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2_2_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_2_3_font(  textLabelMaskLeft_2_3_2_2_2_2_2_3->font() );
    textLabelMaskLeft_2_3_2_2_2_2_2_3->setFont( textLabelMaskLeft_2_3_2_2_2_2_2_3_font ); 
    layout75_2_2_2_3->addWidget( textLabelMaskLeft_2_3_2_2_2_2_2_3 );
    pageLayout_22->addLayout( layout75_2_2_2_3 );

    layout75_2_2_2_2_3 = new QHBoxLayout( 0, 0, 6, "layout75_2_2_2_2_3"); 

    lineEditACEBwildcard_2_3 = new QLineEdit( page_22, "lineEditACEBwildcard_2_3" );
    lineEditACEBwildcard_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditACEBwildcard_2_3->sizePolicy().hasHeightForWidth() ) );
    lineEditACEBwildcard_2_3->setMaximumSize( QSize( 32767, 20 ) );
    lineEditACEBwildcard_2_3->setFrameShape( QLineEdit::NoFrame );
    layout75_2_2_2_2_3->addWidget( lineEditACEBwildcard_2_3 );

    textLabelMaskLeft_2_3_2_2_2_2_2_2_3 = new QLabel( page_22, "textLabelMaskLeft_2_3_2_2_2_2_2_2_3" );
    textLabelMaskLeft_2_3_2_2_2_2_2_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2_2_2_3->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2_2_2_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_2_2_3_font(  textLabelMaskLeft_2_3_2_2_2_2_2_2_3->font() );
    textLabelMaskLeft_2_3_2_2_2_2_2_2_3->setFont( textLabelMaskLeft_2_3_2_2_2_2_2_2_3_font ); 
    layout75_2_2_2_2_3->addWidget( textLabelMaskLeft_2_3_2_2_2_2_2_2_3 );
    pageLayout_22->addLayout( layout75_2_2_2_2_3 );

    comboBox35 = new QComboBox( FALSE, page_22, "comboBox35" );
    comboBox35->setMaximumSize( QSize( 32767, 20 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    comboBox35->setPalette( pal );
    pageLayout_22->addWidget( comboBox35 );
    spacerInstr_2_3 = new QSpacerItem( 5, 13, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_22->addItem( spacerInstr_2_3 );
    toolBox7_2->addItem( page_22, QString::fromLatin1("") );

    page_23 = new QWidget( toolBox7_2, "page_23" );
    page_23->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_23 = new QVBoxLayout( page_23, 11, 3, "pageLayout_23"); 

    layout75_2 = new QHBoxLayout( 0, 0, 6, "layout75_2"); 

    lineEditECwildcard = new QLineEdit( page_23, "lineEditECwildcard" );
    lineEditECwildcard->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditECwildcard->sizePolicy().hasHeightForWidth() ) );
    lineEditECwildcard->setMaximumSize( QSize( 32767, 20 ) );
    lineEditECwildcard->setFrameShape( QLineEdit::NoFrame );
    layout75_2->addWidget( lineEditECwildcard );

    textLabelMaskLeft_2_3_2_2 = new QLabel( page_23, "textLabelMaskLeft_2_3_2_2" );
    textLabelMaskLeft_2_3_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_font(  textLabelMaskLeft_2_3_2_2->font() );
    textLabelMaskLeft_2_3_2_2->setFont( textLabelMaskLeft_2_3_2_2_font ); 
    layout75_2->addWidget( textLabelMaskLeft_2_3_2_2 );
    pageLayout_23->addLayout( layout75_2 );

    layout75_2_2 = new QHBoxLayout( 0, 0, 6, "layout75_2_2"); 

    lineEditB4Cwildcard = new QLineEdit( page_23, "lineEditB4Cwildcard" );
    lineEditB4Cwildcard->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditB4Cwildcard->sizePolicy().hasHeightForWidth() ) );
    lineEditB4Cwildcard->setMaximumSize( QSize( 32767, 20 ) );
    lineEditB4Cwildcard->setFrameShape( QLineEdit::NoFrame );
    layout75_2_2->addWidget( lineEditB4Cwildcard );

    textLabelMaskLeft_2_3_2_2_2 = new QLabel( page_23, "textLabelMaskLeft_2_3_2_2_2" );
    textLabelMaskLeft_2_3_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_font(  textLabelMaskLeft_2_3_2_2_2->font() );
    textLabelMaskLeft_2_3_2_2_2->setFont( textLabelMaskLeft_2_3_2_2_2_font ); 
    layout75_2_2->addWidget( textLabelMaskLeft_2_3_2_2_2 );
    pageLayout_23->addLayout( layout75_2_2 );

    layout75_2_2_2 = new QHBoxLayout( 0, 0, 6, "layout75_2_2_2"); 

    lineEditACFSwildcard = new QLineEdit( page_23, "lineEditACFSwildcard" );
    lineEditACFSwildcard->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditACFSwildcard->sizePolicy().hasHeightForWidth() ) );
    lineEditACFSwildcard->setMaximumSize( QSize( 32767, 20 ) );
    lineEditACFSwildcard->setFrameShape( QLineEdit::NoFrame );
    layout75_2_2_2->addWidget( lineEditACFSwildcard );

    textLabelMaskLeft_2_3_2_2_2_2 = new QLabel( page_23, "textLabelMaskLeft_2_3_2_2_2_2" );
    textLabelMaskLeft_2_3_2_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_font(  textLabelMaskLeft_2_3_2_2_2_2->font() );
    textLabelMaskLeft_2_3_2_2_2_2->setFont( textLabelMaskLeft_2_3_2_2_2_2_font ); 
    layout75_2_2_2->addWidget( textLabelMaskLeft_2_3_2_2_2_2 );
    pageLayout_23->addLayout( layout75_2_2_2 );

    layout75_2_2_2_2 = new QHBoxLayout( 0, 0, 6, "layout75_2_2_2_2"); 

    lineEditACEBwildcard = new QLineEdit( page_23, "lineEditACEBwildcard" );
    lineEditACEBwildcard->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditACEBwildcard->sizePolicy().hasHeightForWidth() ) );
    lineEditACEBwildcard->setMaximumSize( QSize( 32767, 20 ) );
    lineEditACEBwildcard->setFrameShape( QLineEdit::NoFrame );
    layout75_2_2_2_2->addWidget( lineEditACEBwildcard );

    textLabelMaskLeft_2_3_2_2_2_2_2 = new QLabel( page_23, "textLabelMaskLeft_2_3_2_2_2_2_2" );
    textLabelMaskLeft_2_3_2_2_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_2_font(  textLabelMaskLeft_2_3_2_2_2_2_2->font() );
    textLabelMaskLeft_2_3_2_2_2_2_2->setFont( textLabelMaskLeft_2_3_2_2_2_2_2_font ); 
    layout75_2_2_2_2->addWidget( textLabelMaskLeft_2_3_2_2_2_2_2 );
    pageLayout_23->addLayout( layout75_2_2_2_2 );

    layout75_2_2_2_2_2 = new QHBoxLayout( 0, 0, 6, "layout75_2_2_2_2_2"); 

    lineEditACEBwildcard_2 = new QLineEdit( page_23, "lineEditACEBwildcard_2" );
    lineEditACEBwildcard_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditACEBwildcard_2->sizePolicy().hasHeightForWidth() ) );
    lineEditACEBwildcard_2->setMaximumSize( QSize( 32767, 20 ) );
    lineEditACEBwildcard_2->setFrameShape( QLineEdit::NoFrame );
    layout75_2_2_2_2_2->addWidget( lineEditACEBwildcard_2 );

    textLabelMaskLeft_2_3_2_2_2_2_2_2 = new QLabel( page_23, "textLabelMaskLeft_2_3_2_2_2_2_2_2" );
    textLabelMaskLeft_2_3_2_2_2_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_2_2_font(  textLabelMaskLeft_2_3_2_2_2_2_2_2->font() );
    textLabelMaskLeft_2_3_2_2_2_2_2_2->setFont( textLabelMaskLeft_2_3_2_2_2_2_2_2_font ); 
    layout75_2_2_2_2_2->addWidget( textLabelMaskLeft_2_3_2_2_2_2_2_2 );
    pageLayout_23->addLayout( layout75_2_2_2_2_2 );

    layout75_2_2_2_2_2_2 = new QHBoxLayout( 0, 0, 6, "layout75_2_2_2_2_2_2"); 

    lineEditACEBwildcard_2_2 = new QLineEdit( page_23, "lineEditACEBwildcard_2_2" );
    lineEditACEBwildcard_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditACEBwildcard_2_2->sizePolicy().hasHeightForWidth() ) );
    lineEditACEBwildcard_2_2->setMaximumSize( QSize( 32767, 20 ) );
    lineEditACEBwildcard_2_2->setFrameShape( QLineEdit::NoFrame );
    layout75_2_2_2_2_2_2->addWidget( lineEditACEBwildcard_2_2 );

    textLabelMaskLeft_2_3_2_2_2_2_2_2_2 = new QLabel( page_23, "textLabelMaskLeft_2_3_2_2_2_2_2_2_2" );
    textLabelMaskLeft_2_3_2_2_2_2_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_3_2_2_2_2_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_3_2_2_2_2_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_2_3_2_2_2_2_2_2_2_font(  textLabelMaskLeft_2_3_2_2_2_2_2_2_2->font() );
    textLabelMaskLeft_2_3_2_2_2_2_2_2_2->setFont( textLabelMaskLeft_2_3_2_2_2_2_2_2_2_font ); 
    layout75_2_2_2_2_2_2->addWidget( textLabelMaskLeft_2_3_2_2_2_2_2_2_2 );
    pageLayout_23->addLayout( layout75_2_2_2_2_2_2 );
    spacerInstr_2_3_2 = new QSpacerItem( 5, 31, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_23->addItem( spacerInstr_2_3_2 );
    toolBox7_2->addItem( page_23, QString::fromLatin1("") );
    layout117->addWidget( toolBox7_2 );

    line1_2_3_11_5_10_3_2 = new QFrame( page_21, "line1_2_3_11_5_10_3_2" );
    line1_2_3_11_5_10_3_2->setMaximumSize( QSize( 32767, 3 ) );
    line1_2_3_11_5_10_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_3_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_3_2->setFrameShape( QFrame::HLine );
    line1_2_3_11_5_10_3_2->setFrameShadow( QFrame::Plain );
    line1_2_3_11_5_10_3_2->setLineWidth( 2 );
    line1_2_3_11_5_10_3_2->setFrameShape( QFrame::HLine );
    layout117->addWidget( line1_2_3_11_5_10_3_2 );
    layout121->addLayout( layout117 );
    pageLayout_21->addLayout( layout121 );
    spacer49_2 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_21->addItem( spacer49_2 );
    toolBox7->addItem( page_21, QString::fromLatin1("") );
    buttonGroupOptionsLayout->addWidget( toolBox7 );
    TabPageLayout->addWidget( buttonGroupOptions );
    sansTab->insertTab( TabPage, QString::fromLatin1("") );

    TabPage_2 = new QWidget( sansTab, "TabPage_2" );
    TabPageLayout_2 = new QVBoxLayout( TabPage_2, 11, 6, "TabPageLayout_2"); 

    toolBoxAdv = new QToolBox( TabPage_2, "toolBoxAdv" );
    toolBoxAdv->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, toolBoxAdv->sizePolicy().hasHeightForWidth() ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    toolBoxAdv->setPalette( pal );
    toolBoxAdv->setFocusPolicy( QToolBox::TabFocus );
    toolBoxAdv->setFrameShape( QToolBox::HLine );
    toolBoxAdv->setFrameShadow( QToolBox::Plain );
    toolBoxAdv->setLineWidth( 0 );
    toolBoxAdv->setCurrentIndex( 0 );

    page4 = new QWidget( toolBoxAdv, "page4" );
    page4->setBackgroundMode( QWidget::PaletteBackground );
    page4Layout = new QVBoxLayout( page4, 11, 6, "page4Layout"); 

    splitter9 = new QSplitter( page4, "splitter9" );
    splitter9->setOrientation( QSplitter::Horizontal );
    splitter9->setHandleWidth( 6 );

    QWidget* privateLayoutWidget = new QWidget( splitter9, "layout194" );
    layout194 = new QVBoxLayout( privateLayoutWidget, 0, 6, "layout194"); 

    frameExtractHeaderInfo = new QGroupBox( privateLayoutWidget, "frameExtractHeaderInfo" );
    frameExtractHeaderInfo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)5, 0, 0, frameExtractHeaderInfo->sizePolicy().hasHeightForWidth() ) );
    frameExtractHeaderInfo->setColumnLayout(0, Qt::Vertical );
    frameExtractHeaderInfo->layout()->setSpacing( 6 );
    frameExtractHeaderInfo->layout()->setMargin( 11 );
    frameExtractHeaderInfoLayout = new QVBoxLayout( frameExtractHeaderInfo->layout() );
    frameExtractHeaderInfoLayout->setAlignment( Qt::AlignTop );

    layout162 = new QHBoxLayout( 0, 0, 1, "layout162"); 

    comboBoxInfoTable = new QComboBox( FALSE, frameExtractHeaderInfo, "comboBoxInfoTable" );
    comboBoxInfoTable->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxInfoTable->sizePolicy().hasHeightForWidth() ) );
    comboBoxInfoTable->setMinimumSize( QSize( 0, 24 ) );
    comboBoxInfoTable->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxInfoTable->setPalette( pal );
    comboBoxInfoTable->setAutoMask( TRUE );
    layout162->addWidget( comboBoxInfoTable );

    pushButtonNewInfoTable = new QToolButton( frameExtractHeaderInfo, "pushButtonNewInfoTable" );
    pushButtonNewInfoTable->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonNewInfoTable->sizePolicy().hasHeightForWidth() ) );
    pushButtonNewInfoTable->setMinimumSize( QSize( 28, 23 ) );
    pushButtonNewInfoTable->setMaximumSize( QSize( 28, 23 ) );
    pushButtonNewInfoTable->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    pushButtonNewInfoTable->setPaletteBackgroundColor( QColor( 220, 220, 220 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonNewInfoTable->setPalette( pal );
    pushButtonNewInfoTable->setBackgroundOrigin( QToolButton::WindowOrigin );
    QFont pushButtonNewInfoTable_font(  pushButtonNewInfoTable->font() );
    pushButtonNewInfoTable->setFont( pushButtonNewInfoTable_font ); 
    pushButtonNewInfoTable->setIconSet( QIconSet( image8 ) );
    pushButtonNewInfoTable->setUsesBigPixmap( FALSE );
    pushButtonNewInfoTable->setUsesTextLabel( TRUE );
    pushButtonNewInfoTable->setTextPosition( QToolButton::BesideIcon );
    layout162->addWidget( pushButtonNewInfoTable );

    pushButtonMakeList = new QToolButton( frameExtractHeaderInfo, "pushButtonMakeList" );
    pushButtonMakeList->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonMakeList->sizePolicy().hasHeightForWidth() ) );
    pushButtonMakeList->setMinimumSize( QSize( 23, 23 ) );
    pushButtonMakeList->setMaximumSize( QSize( 23, 23 ) );
    pushButtonMakeList->setIconSet( QIconSet( image9 ) );
    pushButtonMakeList->setUsesTextLabel( TRUE );
    pushButtonMakeList->setAutoRaise( FALSE );
    pushButtonMakeList->setTextPosition( QToolButton::BesideIcon );
    layout162->addWidget( pushButtonMakeList );
    frameExtractHeaderInfoLayout->addLayout( layout162 );

    checkBoxDatYesNo = new QCheckBox( frameExtractHeaderInfo, "checkBoxDatYesNo" );
    checkBoxDatYesNo->setEnabled( TRUE );
    frameExtractHeaderInfoLayout->addWidget( checkBoxDatYesNo );

    checkBoxSumVsMask = new QCheckBox( frameExtractHeaderInfo, "checkBoxSumVsMask" );
    checkBoxSumVsMask->setEnabled( TRUE );
    checkBoxSumVsMask->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxSumVsMask->sizePolicy().hasHeightForWidth() ) );
    frameExtractHeaderInfoLayout->addWidget( checkBoxSumVsMask );

    checkBoxShortList = new QCheckBox( frameExtractHeaderInfo, "checkBoxShortList" );
    frameExtractHeaderInfoLayout->addWidget( checkBoxShortList );
    spacer75_2 = new QSpacerItem( 5, 4, QSizePolicy::Minimum, QSizePolicy::Fixed );
    frameExtractHeaderInfoLayout->addItem( spacer75_2 );
    layout194->addWidget( frameExtractHeaderInfo );

    groupBoxHeaderFunc_2 = new QGroupBox( privateLayoutWidget, "groupBoxHeaderFunc_2" );
    groupBoxHeaderFunc_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)5, 0, 0, groupBoxHeaderFunc_2->sizePolicy().hasHeightForWidth() ) );
    groupBoxHeaderFunc_2->setColumnLayout(0, Qt::Vertical );
    groupBoxHeaderFunc_2->layout()->setSpacing( 6 );
    groupBoxHeaderFunc_2->layout()->setMargin( 11 );
    groupBoxHeaderFunc_2Layout = new QVBoxLayout( groupBoxHeaderFunc_2->layout() );
    groupBoxHeaderFunc_2Layout->setAlignment( Qt::AlignTop );

    pushButtonAddUni = new QPushButton( groupBoxHeaderFunc_2, "pushButtonAddUni" );
    QFont pushButtonAddUni_font(  pushButtonAddUni->font() );
    pushButtonAddUni_font.setFamily( "Lucida Grande" );
    pushButtonAddUni->setFont( pushButtonAddUni_font ); 
    groupBoxHeaderFunc_2Layout->addWidget( pushButtonAddUni );

    pushButtonGenerateAddingTable = new QPushButton( groupBoxHeaderFunc_2, "pushButtonGenerateAddingTable" );
    QFont pushButtonGenerateAddingTable_font(  pushButtonGenerateAddingTable->font() );
    pushButtonGenerateAddingTable_font.setFamily( "Lucida Grande" );
    pushButtonGenerateAddingTable->setFont( pushButtonGenerateAddingTable_font ); 
    groupBoxHeaderFunc_2Layout->addWidget( pushButtonGenerateAddingTable );

    pushButtonAddUniInTable = new QPushButton( groupBoxHeaderFunc_2, "pushButtonAddUniInTable" );
    QFont pushButtonAddUniInTable_font(  pushButtonAddUniInTable->font() );
    pushButtonAddUniInTable_font.setFamily( "Lucida Grande" );
    pushButtonAddUniInTable->setFont( pushButtonAddUniInTable_font ); 
    groupBoxHeaderFunc_2Layout->addWidget( pushButtonAddUniInTable );
    layout194->addWidget( groupBoxHeaderFunc_2 );

    QWidget* privateLayoutWidget_2 = new QWidget( splitter9, "layout195" );
    layout195 = new QVBoxLayout( privateLayoutWidget_2, 0, 6, "layout195"); 

    frameExtractMatrixes = new QGroupBox( privateLayoutWidget_2, "frameExtractMatrixes" );
    frameExtractMatrixes->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)5, 0, 0, frameExtractMatrixes->sizePolicy().hasHeightForWidth() ) );
    frameExtractMatrixes->setColumnLayout(0, Qt::Vertical );
    frameExtractMatrixes->layout()->setSpacing( 6 );
    frameExtractMatrixes->layout()->setMargin( 11 );
    frameExtractMatrixesLayout = new QVBoxLayout( frameExtractMatrixes->layout() );
    frameExtractMatrixesLayout->setAlignment( Qt::AlignTop );

    layout161 = new QHBoxLayout( 0, 0, 1, "layout161"); 

    comboBoxInfoMatrix = new QComboBox( FALSE, frameExtractMatrixes, "comboBoxInfoMatrix" );
    comboBoxInfoMatrix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxInfoMatrix->sizePolicy().hasHeightForWidth() ) );
    comboBoxInfoMatrix->setMinimumSize( QSize( 0, 24 ) );
    comboBoxInfoMatrix->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxInfoMatrix->setPalette( pal );
    comboBoxInfoMatrix->setAutoMask( TRUE );
    layout161->addWidget( comboBoxInfoMatrix );

    pushButtonNewInfoMatrix = new QToolButton( frameExtractMatrixes, "pushButtonNewInfoMatrix" );
    pushButtonNewInfoMatrix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonNewInfoMatrix->sizePolicy().hasHeightForWidth() ) );
    pushButtonNewInfoMatrix->setMinimumSize( QSize( 28, 23 ) );
    pushButtonNewInfoMatrix->setMaximumSize( QSize( 28, 23 ) );
    pushButtonNewInfoMatrix->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    pushButtonNewInfoMatrix->setPaletteBackgroundColor( QColor( 220, 220, 220 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonNewInfoMatrix->setPalette( pal );
    pushButtonNewInfoMatrix->setBackgroundOrigin( QToolButton::WindowOrigin );
    QFont pushButtonNewInfoMatrix_font(  pushButtonNewInfoMatrix->font() );
    pushButtonNewInfoMatrix->setFont( pushButtonNewInfoMatrix_font ); 
    pushButtonNewInfoMatrix->setIconSet( QIconSet( image8 ) );
    pushButtonNewInfoMatrix->setUsesBigPixmap( FALSE );
    pushButtonNewInfoMatrix->setUsesTextLabel( TRUE );
    pushButtonNewInfoMatrix->setTextPosition( QToolButton::BesideIcon );
    layout161->addWidget( pushButtonNewInfoMatrix );

    pushButtonMakeBigMatrix = new QToolButton( frameExtractMatrixes, "pushButtonMakeBigMatrix" );
    pushButtonMakeBigMatrix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonMakeBigMatrix->sizePolicy().hasHeightForWidth() ) );
    pushButtonMakeBigMatrix->setMinimumSize( QSize( 23, 23 ) );
    pushButtonMakeBigMatrix->setMaximumSize( QSize( 23, 23 ) );
    pushButtonMakeBigMatrix->setIconSet( QIconSet( image9 ) );
    pushButtonMakeBigMatrix->setUsesTextLabel( TRUE );
    pushButtonMakeBigMatrix->setAutoRaise( FALSE );
    pushButtonMakeBigMatrix->setTextPosition( QToolButton::BesideIcon );
    layout161->addWidget( pushButtonMakeBigMatrix );
    frameExtractMatrixesLayout->addLayout( layout161 );

    layout211 = new QHBoxLayout( 0, 0, 6, "layout211"); 

    spinBoxBigMatrixCols = new QSpinBox( frameExtractMatrixes, "spinBoxBigMatrixCols" );
    spinBoxBigMatrixCols->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxBigMatrixCols->sizePolicy().hasHeightForWidth() ) );
    spinBoxBigMatrixCols->setMinimumSize( QSize( 0, 25 ) );
    spinBoxBigMatrixCols->setMaximumSize( QSize( 4000, 25 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    spinBoxBigMatrixCols->setPalette( pal );
    spinBoxBigMatrixCols->setMinValue( 1 );
    spinBoxBigMatrixCols->setValue( 3 );
    layout211->addWidget( spinBoxBigMatrixCols );

    textLabel1_2_2 = new QLabel( frameExtractMatrixes, "textLabel1_2_2" );
    textLabel1_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_2_2->sizePolicy().hasHeightForWidth() ) );
    layout211->addWidget( textLabel1_2_2 );

    checkBoxBigMatrixASCII = new QCheckBox( frameExtractMatrixes, "checkBoxBigMatrixASCII" );
    checkBoxBigMatrixASCII->setEnabled( TRUE );
    checkBoxBigMatrixASCII->setMinimumSize( QSize( 70, 0 ) );
    checkBoxBigMatrixASCII->setMaximumSize( QSize( 70, 32767 ) );
    layout211->addWidget( checkBoxBigMatrixASCII );
    frameExtractMatrixesLayout->addLayout( layout211 );

    layout56 = new QHBoxLayout( 0, 0, 6, "layout56"); 

    checkBoxBigMatrixNorm = new QCheckBox( frameExtractMatrixes, "checkBoxBigMatrixNorm" );
    checkBoxBigMatrixNorm->setEnabled( TRUE );
    layout56->addWidget( checkBoxBigMatrixNorm );

    checkBoxBigMatrixMask = new QCheckBox( frameExtractMatrixes, "checkBoxBigMatrixMask" );
    checkBoxBigMatrixMask->setEnabled( TRUE );
    layout56->addWidget( checkBoxBigMatrixMask );
    frameExtractMatrixesLayout->addLayout( layout56 );

    layout57_2 = new QHBoxLayout( 0, 0, 6, "layout57_2"); 

    checkBoxBigMatrixSens = new QCheckBox( frameExtractMatrixes, "checkBoxBigMatrixSens" );
    layout57_2->addWidget( checkBoxBigMatrixSens );

    checkBoxBigMatrixROI = new QCheckBox( frameExtractMatrixes, "checkBoxBigMatrixROI" );
    layout57_2->addWidget( checkBoxBigMatrixROI );
    frameExtractMatrixesLayout->addLayout( layout57_2 );
    layout195->addWidget( frameExtractMatrixes );

    groupBoxHeaderFunc = new QGroupBox( privateLayoutWidget_2, "groupBoxHeaderFunc" );
    groupBoxHeaderFunc->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)5, 0, 0, groupBoxHeaderFunc->sizePolicy().hasHeightForWidth() ) );
    groupBoxHeaderFunc->setColumnLayout(0, Qt::Vertical );
    groupBoxHeaderFunc->layout()->setSpacing( 6 );
    groupBoxHeaderFunc->layout()->setMargin( 11 );
    groupBoxHeaderFuncLayout = new QVBoxLayout( groupBoxHeaderFunc->layout() );
    groupBoxHeaderFuncLayout->setAlignment( Qt::AlignTop );

    layout127_2 = new QHBoxLayout( 0, 0, 6, "layout127_2"); 

    pushButtonHeader = new QPushButton( groupBoxHeaderFunc, "pushButtonHeader" );
    pushButtonHeader->setMinimumSize( QSize( 25, 21 ) );
    pushButtonHeader->setMaximumSize( QSize( 25, 25 ) );
    pushButtonHeader->setPixmap( image2 );
    layout127_2->addWidget( pushButtonHeader );

    lineEditCheck = new QLineEdit( groupBoxHeaderFunc, "lineEditCheck" );
    lineEditCheck->setMinimumSize( QSize( 0, 25 ) );
    lineEditCheck->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    lineEditCheck->setPalette( pal );
    lineEditCheck->setLineWidth( 1 );
    layout127_2->addWidget( lineEditCheck );
    groupBoxHeaderFuncLayout->addLayout( layout127_2 );

    splitter8 = new QSplitter( groupBoxHeaderFunc, "splitter8" );
    splitter8->setLineWidth( 1 );
    splitter8->setOrientation( QSplitter::Horizontal );
    splitter8->setHandleWidth( 6 );

    QWidget* privateLayoutWidget_3 = new QWidget( splitter8, "layout190" );
    layout190_2 = new QVBoxLayout( privateLayoutWidget_3, 0, 6, "layout190_2"); 

    comboBoxCheck = new QComboBox( FALSE, privateLayoutWidget_3, "comboBoxCheck" );
    comboBoxCheck->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxCheck->sizePolicy().hasHeightForWidth() ) );
    comboBoxCheck->setMinimumSize( QSize( 0, 25 ) );
    comboBoxCheck->setMaximumSize( QSize( 32767, 25 ) );
    comboBoxCheck->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxCheck_font(  comboBoxCheck->font() );
    comboBoxCheck->setFont( comboBoxCheck_font ); 
    layout190_2->addWidget( comboBoxCheck );

    comboBoxActiveFile = new QComboBox( FALSE, privateLayoutWidget_3, "comboBoxActiveFile" );
    comboBoxActiveFile->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxActiveFile->sizePolicy().hasHeightForWidth() ) );
    comboBoxActiveFile->setMinimumSize( QSize( 0, 25 ) );
    comboBoxActiveFile->setMaximumSize( QSize( 32767, 25 ) );
    comboBoxActiveFile->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxActiveFile_font(  comboBoxActiveFile->font() );
    comboBoxActiveFile->setFont( comboBoxActiveFile_font ); 
    layout190_2->addWidget( comboBoxActiveFile );

    QWidget* privateLayoutWidget_4 = new QWidget( splitter8, "layout192" );
    layout192 = new QVBoxLayout( privateLayoutWidget_4, 0, 6, "layout192"); 

    lineEditCheckRes = new QLineEdit( privateLayoutWidget_4, "lineEditCheckRes" );
    lineEditCheckRes->setEnabled( FALSE );
    lineEditCheckRes->setMaximumSize( QSize( 32767, 25 ) );
    lineEditCheckRes->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    lineEditCheckRes->setPalette( pal );
    lineEditCheckRes->setLineWidth( 1 );
    layout192->addWidget( lineEditCheckRes );

    layout191 = new QHBoxLayout( 0, 0, 6, "layout191"); 

    textLabel1_2 = new QLabel( privateLayoutWidget_4, "textLabel1_2" );
    textLabel1_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_2->sizePolicy().hasHeightForWidth() ) );
    layout191->addWidget( textLabel1_2 );

    checkBoxExtratorASCII = new QCheckBox( privateLayoutWidget_4, "checkBoxExtratorASCII" );
    checkBoxExtratorASCII->setEnabled( TRUE );
    checkBoxExtratorASCII->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxExtratorASCII->sizePolicy().hasHeightForWidth() ) );
    checkBoxExtratorASCII->setMinimumSize( QSize( 70, 0 ) );
    checkBoxExtratorASCII->setMaximumSize( QSize( 7000, 32767 ) );
    layout191->addWidget( checkBoxExtratorASCII );
    layout192->addLayout( layout191 );
    groupBoxHeaderFuncLayout->addWidget( splitter8 );
    layout195->addWidget( groupBoxHeaderFunc );
    page4Layout->addWidget( splitter9 );

    groupBoxHeaderFunc_2_2 = new QGroupBox( page4, "groupBoxHeaderFunc_2_2" );
    groupBoxHeaderFunc_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)5, 0, 0, groupBoxHeaderFunc_2_2->sizePolicy().hasHeightForWidth() ) );
    groupBoxHeaderFunc_2_2->setColumnLayout(0, Qt::Vertical );
    groupBoxHeaderFunc_2_2->layout()->setSpacing( 6 );
    groupBoxHeaderFunc_2_2->layout()->setMargin( 11 );
    groupBoxHeaderFunc_2_2Layout = new QHBoxLayout( groupBoxHeaderFunc_2_2->layout() );
    groupBoxHeaderFunc_2_2Layout->setAlignment( Qt::AlignTop );

    pushButtonExtractData = new QPushButton( groupBoxHeaderFunc_2_2, "pushButtonExtractData" );
    QFont pushButtonExtractData_font(  pushButtonExtractData->font() );
    pushButtonExtractData_font.setFamily( "Lucida Grande" );
    pushButtonExtractData->setFont( pushButtonExtractData_font ); 
    groupBoxHeaderFunc_2_2Layout->addWidget( pushButtonExtractData );
    page4Layout->addWidget( groupBoxHeaderFunc_2_2 );
    spacer75 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page4Layout->addItem( spacer75 );
    toolBoxAdv->addItem( page4, QString::fromLatin1("") );

    page_24 = new QWidget( toolBoxAdv, "page_24" );
    page_24->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_24 = new QVBoxLayout( page_24, 11, 6, "pageLayout_24"); 

    layout153 = new QGridLayout( 0, 1, 1, 0, 6, "layout153"); 

    pushButtonRTsum = new QPushButton( page_24, "pushButtonRTsum" );
    pushButtonRTsum->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonRTsum->sizePolicy().hasHeightForWidth() ) );
    pushButtonRTsum->setMaximumSize( QSize( 20000, 25 ) );
    pushButtonRTsum->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    pushButtonRTsum->setPalette( pal );
    QFont pushButtonRTsum_font(  pushButtonRTsum->font() );
    pushButtonRTsum_font.setBold( TRUE );
    pushButtonRTsum->setFont( pushButtonRTsum_font ); 
    pushButtonRTsum->setFlat( TRUE );

    layout153->addWidget( pushButtonRTsum, 0, 0 );

    pushButtonAddManyDat = new QPushButton( page_24, "pushButtonAddManyDat" );
    pushButtonAddManyDat->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonAddManyDat->sizePolicy().hasHeightForWidth() ) );
    pushButtonAddManyDat->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonAddManyDat->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonAddManyDat_font(  pushButtonAddManyDat->font() );
    pushButtonAddManyDat_font.setBold( TRUE );
    pushButtonAddManyDat->setFont( pushButtonAddManyDat_font ); 
    pushButtonAddManyDat->setFlat( TRUE );

    layout153->addWidget( pushButtonAddManyDat, 0, 1 );
    pageLayout_24->addLayout( layout153 );

    groupBoxTofEstimation_2_2 = new QGroupBox( page_24, "groupBoxTofEstimation_2_2" );
    groupBoxTofEstimation_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)1, 0, 0, groupBoxTofEstimation_2_2->sizePolicy().hasHeightForWidth() ) );
    groupBoxTofEstimation_2_2->setMaximumSize( QSize( 32700, 32767 ) );
    groupBoxTofEstimation_2_2->setColumnLayout(0, Qt::Vertical );
    groupBoxTofEstimation_2_2->layout()->setSpacing( 11 );
    groupBoxTofEstimation_2_2->layout()->setMargin( 14 );
    groupBoxTofEstimation_2_2Layout = new QVBoxLayout( groupBoxTofEstimation_2_2->layout() );
    groupBoxTofEstimation_2_2Layout->setAlignment( Qt::AlignTop );

    layout155 = new QHBoxLayout( 0, 0, 2, "layout155"); 

    lCDNumberTof4_2_3 = new QLCDNumber( groupBoxTofEstimation_2_2, "lCDNumberTof4_2_3" );
    lCDNumberTof4_2_3->setMaximumSize( QSize( 15, 25 ) );
    lCDNumberTof4_2_3->setNumDigits( 1 );
    lCDNumberTof4_2_3->setProperty( "value", 0 );
    lCDNumberTof4_2_3->setProperty( "intValue", 0 );
    layout155->addWidget( lCDNumberTof4_2_3 );

    pushButtonAddRTtable = new QToolButton( groupBoxTofEstimation_2_2, "pushButtonAddRTtable" );
    pushButtonAddRTtable->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonAddRTtable->sizePolicy().hasHeightForWidth() ) );
    pushButtonAddRTtable->setMinimumSize( QSize( 23, 0 ) );
    pushButtonAddRTtable->setMaximumSize( QSize( 2300, 25 ) );
    pushButtonAddRTtable->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonAddRTtable->setPaletteBackgroundColor( QColor( 220, 220, 220 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonAddRTtable->setPalette( pal );
    pushButtonAddRTtable->setBackgroundOrigin( QToolButton::WindowOrigin );
    QFont pushButtonAddRTtable_font(  pushButtonAddRTtable->font() );
    pushButtonAddRTtable_font.setBold( TRUE );
    pushButtonAddRTtable->setFont( pushButtonAddRTtable_font ); 
    pushButtonAddRTtable->setUsesBigPixmap( FALSE );
    pushButtonAddRTtable->setUsesTextLabel( TRUE );
    pushButtonAddRTtable->setTextPosition( QToolButton::BesideIcon );
    layout155->addWidget( pushButtonAddRTtable );

    checkBoxAddRTtable = new QCheckBox( groupBoxTofEstimation_2_2, "checkBoxAddRTtable" );
    checkBoxAddRTtable->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, checkBoxAddRTtable->sizePolicy().hasHeightForWidth() ) );
    checkBoxAddRTtable->setMinimumSize( QSize( 123, 0 ) );
    checkBoxAddRTtable->setMaximumSize( QSize( 123, 32767 ) );
    checkBoxAddRTtable->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxAddRTtable->setPalette( pal );
    QFont checkBoxAddRTtable_font(  checkBoxAddRTtable->font() );
    checkBoxAddRTtable->setFont( checkBoxAddRTtable_font ); 
    layout155->addWidget( checkBoxAddRTtable );
    groupBoxTofEstimation_2_2Layout->addLayout( layout155 );

    layout130_2 = new QHBoxLayout( 0, 0, 2, "layout130_2"); 

    lCDNumberTof4_2 = new QLCDNumber( groupBoxTofEstimation_2_2, "lCDNumberTof4_2" );
    lCDNumberTof4_2->setMaximumSize( QSize( 15, 25 ) );
    lCDNumberTof4_2->setNumDigits( 1 );
    lCDNumberTof4_2->setProperty( "value", 1 );
    lCDNumberTof4_2->setProperty( "intValue", 1 );
    layout130_2->addWidget( lCDNumberTof4_2 );

    pushButtonRTMergeLinear = new QToolButton( groupBoxTofEstimation_2_2, "pushButtonRTMergeLinear" );
    pushButtonRTMergeLinear->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonRTMergeLinear->sizePolicy().hasHeightForWidth() ) );
    pushButtonRTMergeLinear->setMinimumSize( QSize( 23, 0 ) );
    pushButtonRTMergeLinear->setMaximumSize( QSize( 2300, 25 ) );
    pushButtonRTMergeLinear->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonRTMergeLinear->setPaletteBackgroundColor( QColor( 220, 220, 220 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonRTMergeLinear->setPalette( pal );
    pushButtonRTMergeLinear->setBackgroundOrigin( QToolButton::WindowOrigin );
    QFont pushButtonRTMergeLinear_font(  pushButtonRTMergeLinear->font() );
    pushButtonRTMergeLinear_font.setBold( TRUE );
    pushButtonRTMergeLinear->setFont( pushButtonRTMergeLinear_font ); 
    pushButtonRTMergeLinear->setUsesBigPixmap( FALSE );
    pushButtonRTMergeLinear->setUsesTextLabel( TRUE );
    pushButtonRTMergeLinear->setTextPosition( QToolButton::BesideIcon );
    layout130_2->addWidget( pushButtonRTMergeLinear );

    spinBoxMergeRT = new QSpinBox( groupBoxTofEstimation_2_2, "spinBoxMergeRT" );
    spinBoxMergeRT->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, spinBoxMergeRT->sizePolicy().hasHeightForWidth() ) );
    spinBoxMergeRT->setMinimumSize( QSize( 123, 0 ) );
    spinBoxMergeRT->setMaximumSize( QSize( 123, 32767 ) );
    spinBoxMergeRT->setMaxValue( 1024 );
    spinBoxMergeRT->setMinValue( 1 );
    spinBoxMergeRT->setValue( 1 );
    layout130_2->addWidget( spinBoxMergeRT );
    groupBoxTofEstimation_2_2Layout->addLayout( layout130_2 );

    layout213 = new QHBoxLayout( 0, 0, 3, "layout213"); 

    lCDNumberTof4_2_2 = new QLCDNumber( groupBoxTofEstimation_2_2, "lCDNumberTof4_2_2" );
    lCDNumberTof4_2_2->setMaximumSize( QSize( 15, 25 ) );
    lCDNumberTof4_2_2->setNumDigits( 1 );
    lCDNumberTof4_2_2->setProperty( "value", 2 );
    lCDNumberTof4_2_2->setProperty( "intValue", 2 );
    layout213->addWidget( lCDNumberTof4_2_2 );

    pushButtonRTMergeProgressive = new QToolButton( groupBoxTofEstimation_2_2, "pushButtonRTMergeProgressive" );
    pushButtonRTMergeProgressive->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonRTMergeProgressive->sizePolicy().hasHeightForWidth() ) );
    pushButtonRTMergeProgressive->setMinimumSize( QSize( 23, 0 ) );
    pushButtonRTMergeProgressive->setMaximumSize( QSize( 2300, 25 ) );
    pushButtonRTMergeProgressive->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonRTMergeProgressive->setPaletteBackgroundColor( QColor( 220, 220, 220 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonRTMergeProgressive->setPalette( pal );
    pushButtonRTMergeProgressive->setBackgroundOrigin( QToolButton::WindowOrigin );
    QFont pushButtonRTMergeProgressive_font(  pushButtonRTMergeProgressive->font() );
    pushButtonRTMergeProgressive_font.setBold( TRUE );
    pushButtonRTMergeProgressive->setFont( pushButtonRTMergeProgressive_font ); 
    pushButtonRTMergeProgressive->setUsesBigPixmap( FALSE );
    pushButtonRTMergeProgressive->setUsesTextLabel( TRUE );
    pushButtonRTMergeProgressive->setTextPosition( QToolButton::BesideIcon );
    layout213->addWidget( pushButtonRTMergeProgressive );

    lineEditSplitFramesProgr = new QSpinBox( groupBoxTofEstimation_2_2, "lineEditSplitFramesProgr" );
    lineEditSplitFramesProgr->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, lineEditSplitFramesProgr->sizePolicy().hasHeightForWidth() ) );
    lineEditSplitFramesProgr->setMinimumSize( QSize( 122, 0 ) );
    lineEditSplitFramesProgr->setMaximumSize( QSize( 123, 32767 ) );
    lineEditSplitFramesProgr->setMaxValue( 999 );
    lineEditSplitFramesProgr->setMinValue( 0 );
    lineEditSplitFramesProgr->setLineStep( 1 );
    lineEditSplitFramesProgr->setValue( 0 );
    layout213->addWidget( lineEditSplitFramesProgr );
    groupBoxTofEstimation_2_2Layout->addLayout( layout213 );

    layout156 = new QHBoxLayout( 0, 0, 2, "layout156"); 

    lCDNumberTof5_3 = new QLCDNumber( groupBoxTofEstimation_2_2, "lCDNumberTof5_3" );
    lCDNumberTof5_3->setMaximumSize( QSize( 15, 25 ) );
    lCDNumberTof5_3->setNumDigits( 1 );
    lCDNumberTof5_3->setProperty( "value", 3 );
    lCDNumberTof5_3->setProperty( "intValue", 3 );
    layout156->addWidget( lCDNumberTof5_3 );

    pushButtonSplitFrames = new QToolButton( groupBoxTofEstimation_2_2, "pushButtonSplitFrames" );
    pushButtonSplitFrames->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, pushButtonSplitFrames->sizePolicy().hasHeightForWidth() ) );
    pushButtonSplitFrames->setMinimumSize( QSize( 23, 0 ) );
    pushButtonSplitFrames->setMaximumSize( QSize( 2300, 25 ) );
    pushButtonSplitFrames->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    pushButtonSplitFrames->setPaletteBackgroundColor( QColor( 220, 220, 220 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonSplitFrames->setPalette( pal );
    pushButtonSplitFrames->setBackgroundOrigin( QToolButton::WindowOrigin );
    QFont pushButtonSplitFrames_font(  pushButtonSplitFrames->font() );
    pushButtonSplitFrames_font.setBold( TRUE );
    pushButtonSplitFrames->setFont( pushButtonSplitFrames_font ); 
    pushButtonSplitFrames->setUsesBigPixmap( FALSE );
    pushButtonSplitFrames->setUsesTextLabel( TRUE );
    pushButtonSplitFrames->setTextPosition( QToolButton::BesideIcon );
    layout156->addWidget( pushButtonSplitFrames );

    spinBoxRtSplitFrom = new QSpinBox( groupBoxTofEstimation_2_2, "spinBoxRtSplitFrom" );
    spinBoxRtSplitFrom->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, spinBoxRtSplitFrom->sizePolicy().hasHeightForWidth() ) );
    spinBoxRtSplitFrom->setMinimumSize( QSize( 60, 0 ) );
    spinBoxRtSplitFrom->setMaximumSize( QSize( 60, 32767 ) );
    spinBoxRtSplitFrom->setMaxValue( 1024 );
    spinBoxRtSplitFrom->setMinValue( 1 );
    spinBoxRtSplitFrom->setValue( 1 );
    layout156->addWidget( spinBoxRtSplitFrom );

    spinBoxRtSplitTo = new QSpinBox( groupBoxTofEstimation_2_2, "spinBoxRtSplitTo" );
    spinBoxRtSplitTo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, spinBoxRtSplitTo->sizePolicy().hasHeightForWidth() ) );
    spinBoxRtSplitTo->setMinimumSize( QSize( 60, 0 ) );
    spinBoxRtSplitTo->setMaximumSize( QSize( 60, 32767 ) );
    spinBoxRtSplitTo->setMaxValue( 1024 );
    spinBoxRtSplitTo->setMinValue( 1 );
    spinBoxRtSplitTo->setValue( 1024 );
    layout156->addWidget( spinBoxRtSplitTo );
    groupBoxTofEstimation_2_2Layout->addLayout( layout156 );

    layout221 = new QHBoxLayout( 0, 0, 6, "layout221"); 

    textLabelMaskLeft_2_4 = new QLabel( groupBoxTofEstimation_2_2, "textLabelMaskLeft_2_4" );
    textLabelMaskLeft_2_4->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_4->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_4->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout221->addWidget( textLabelMaskLeft_2_4 );

    lineEditSplitFramesProgrMeasured = new QSpinBox( groupBoxTofEstimation_2_2, "lineEditSplitFramesProgrMeasured" );
    lineEditSplitFramesProgrMeasured->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, lineEditSplitFramesProgrMeasured->sizePolicy().hasHeightForWidth() ) );
    lineEditSplitFramesProgrMeasured->setMinimumSize( QSize( 122, 0 ) );
    lineEditSplitFramesProgrMeasured->setMaximumSize( QSize( 123, 32767 ) );
    lineEditSplitFramesProgrMeasured->setMaxValue( 999 );
    lineEditSplitFramesProgrMeasured->setMinValue( 0 );
    lineEditSplitFramesProgrMeasured->setLineStep( 1 );
    lineEditSplitFramesProgrMeasured->setValue( 0 );
    layout221->addWidget( lineEditSplitFramesProgrMeasured );
    groupBoxTofEstimation_2_2Layout->addLayout( layout221 );
    pageLayout_24->addWidget( groupBoxTofEstimation_2_2 );

    groupBox22_2 = new QGroupBox( page_24, "groupBox22_2" );
    groupBox22_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)5, 0, 0, groupBox22_2->sizePolicy().hasHeightForWidth() ) );
    groupBox22_2->setMaximumSize( QSize( 32767, 32767 ) );
    groupBox22_2->setColumnLayout(0, Qt::Vertical );
    groupBox22_2->layout()->setSpacing( 11 );
    groupBox22_2->layout()->setMargin( 11 );
    groupBox22_2Layout = new QVBoxLayout( groupBox22_2->layout() );
    groupBox22_2Layout->setAlignment( Qt::AlignTop );

    layout77_2 = new QHBoxLayout( 0, 0, 2, "layout77_2"); 

    lCDNumberTof1_2_3 = new QLCDNumber( groupBox22_2, "lCDNumberTof1_2_3" );
    lCDNumberTof1_2_3->setMaximumSize( QSize( 15, 25 ) );
    QFont lCDNumberTof1_2_3_font(  lCDNumberTof1_2_3->font() );
    lCDNumberTof1_2_3->setFont( lCDNumberTof1_2_3_font ); 
    lCDNumberTof1_2_3->setNumDigits( 1 );
    lCDNumberTof1_2_3->setProperty( "value", 0 );
    lCDNumberTof1_2_3->setProperty( "intValue", 0 );
    layout77_2->addWidget( lCDNumberTof1_2_3 );

    textLabelL_2_3 = new QLabel( groupBox22_2, "textLabelL_2_3" );
    textLabelL_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabelL_2_3->sizePolicy().hasHeightForWidth() ) );
    layout77_2->addWidget( textLabelL_2_3 );

    lCDNumberTof5_2_3 = new QLCDNumber( groupBox22_2, "lCDNumberTof5_2_3" );
    lCDNumberTof5_2_3->setMaximumSize( QSize( 15, 25 ) );
    lCDNumberTof5_2_3->setNumDigits( 1 );
    lCDNumberTof5_2_3->setProperty( "value", 3 );
    lCDNumberTof5_2_3->setProperty( "intValue", 3 );
    layout77_2->addWidget( lCDNumberTof5_2_3 );

    pushButtonRTAll = new QPushButton( groupBox22_2, "pushButtonRTAll" );
    pushButtonRTAll->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonRTAll->sizePolicy().hasHeightForWidth() ) );
    pushButtonRTAll->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonRTAll->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonRTAll_font(  pushButtonRTAll->font() );
    pushButtonRTAll_font.setBold( TRUE );
    pushButtonRTAll->setFont( pushButtonRTAll_font ); 
    pushButtonRTAll->setFlat( TRUE );
    layout77_2->addWidget( pushButtonRTAll );
    groupBox22_2Layout->addLayout( layout77_2 );

    layout212 = new QVBoxLayout( 0, 0, 6, "layout212"); 

    layout78_2 = new QHBoxLayout( 0, 0, 6, "layout78_2"); 

    checkBoxRtPrefix = new QCheckBox( groupBox22_2, "checkBoxRtPrefix" );
    layout78_2->addWidget( checkBoxRtPrefix );

    lineEditRtPrefix = new QLineEdit( groupBox22_2, "lineEditRtPrefix" );
    lineEditRtPrefix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, lineEditRtPrefix->sizePolicy().hasHeightForWidth() ) );
    lineEditRtPrefix->setFrameShape( QLineEdit::NoFrame );
    layout78_2->addWidget( lineEditRtPrefix );

    checkBoxRtSuffix = new QCheckBox( groupBox22_2, "checkBoxRtSuffix" );
    layout78_2->addWidget( checkBoxRtSuffix );

    lineEditRtSuffix = new QLineEdit( groupBox22_2, "lineEditRtSuffix" );
    lineEditRtSuffix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditRtSuffix->sizePolicy().hasHeightForWidth() ) );
    lineEditRtSuffix->setFrameShape( QLineEdit::NoFrame );
    layout78_2->addWidget( lineEditRtSuffix );
    layout212->addLayout( layout78_2 );

    checkBoxRtDelete = new QCheckBox( groupBox22_2, "checkBoxRtDelete" );
    checkBoxRtDelete->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, checkBoxRtDelete->sizePolicy().hasHeightForWidth() ) );
    layout212->addWidget( checkBoxRtDelete );
    groupBox22_2Layout->addLayout( layout212 );
    pageLayout_24->addWidget( groupBox22_2 );
    spacer61 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::MinimumExpanding );
    pageLayout_24->addItem( spacer61 );
    toolBoxAdv->addItem( page_24, QString::fromLatin1("") );

    page_25 = new QWidget( toolBoxAdv, "page_25" );
    page_25->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_25 = new QVBoxLayout( page_25, 11, 6, "pageLayout_25"); 

    layout88 = new QHBoxLayout( 0, 0, 6, "layout88"); 

    pushButtonTofSumRead = new QPushButton( page_25, "pushButtonTofSumRead" );
    pushButtonTofSumRead->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, pushButtonTofSumRead->sizePolicy().hasHeightForWidth() ) );
    pushButtonTofSumRead->setMaximumSize( QSize( 20000, 32767 ) );
    pushButtonTofSumRead->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    pushButtonTofSumRead->setPalette( pal );
    QFont pushButtonTofSumRead_font(  pushButtonTofSumRead->font() );
    pushButtonTofSumRead_font.setBold( TRUE );
    pushButtonTofSumRead->setFont( pushButtonTofSumRead_font ); 
    pushButtonTofSumRead->setFlat( TRUE );
    layout88->addWidget( pushButtonTofSumRead );

    pushButtonTofAddFiles = new QPushButton( page_25, "pushButtonTofAddFiles" );
    pushButtonTofAddFiles->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, pushButtonTofAddFiles->sizePolicy().hasHeightForWidth() ) );
    pushButtonTofAddFiles->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonTofAddFiles_font(  pushButtonTofAddFiles->font() );
    pushButtonTofAddFiles_font.setBold( TRUE );
    pushButtonTofAddFiles->setFont( pushButtonTofAddFiles_font ); 
    pushButtonTofAddFiles->setFlat( TRUE );
    layout88->addWidget( pushButtonTofAddFiles );
    pageLayout_25->addLayout( layout88 );

    groupBox14 = new QGroupBox( page_25, "groupBox14" );
    groupBox14->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)5, 0, 0, groupBox14->sizePolicy().hasHeightForWidth() ) );
    groupBox14->setMaximumSize( QSize( 32700, 32767 ) );
    groupBox14->setColumnLayout(0, Qt::Vertical );
    groupBox14->layout()->setSpacing( 4 );
    groupBox14->layout()->setMargin( 7 );
    groupBox14Layout = new QGridLayout( groupBox14->layout() );
    groupBox14Layout->setAlignment( Qt::AlignTop );

    lCDNumberTof1 = new QLCDNumber( groupBox14, "lCDNumberTof1" );
    lCDNumberTof1->setMaximumSize( QSize( 15, 25 ) );
    QFont lCDNumberTof1_font(  lCDNumberTof1->font() );
    lCDNumberTof1->setFont( lCDNumberTof1_font ); 
    lCDNumberTof1->setNumDigits( 1 );
    lCDNumberTof1->setProperty( "value", 1 );

    groupBox14Layout->addWidget( lCDNumberTof1, 0, 0 );

    lCDNumberTof2 = new QLCDNumber( groupBox14, "lCDNumberTof2" );
    lCDNumberTof2->setMaximumSize( QSize( 15, 25 ) );
    lCDNumberTof2->setNumDigits( 1 );
    lCDNumberTof2->setProperty( "value", 2 );

    groupBox14Layout->addWidget( lCDNumberTof2, 1, 0 );

    lCDNumberTof3 = new QLCDNumber( groupBox14, "lCDNumberTof3" );
    lCDNumberTof3->setMaximumSize( QSize( 15, 25 ) );
    lCDNumberTof3->setNumDigits( 1 );
    lCDNumberTof3->setProperty( "value", 3 );
    lCDNumberTof3->setProperty( "intValue", 3 );

    groupBox14Layout->addWidget( lCDNumberTof3, 2, 0 );

    lCDNumberTof4 = new QLCDNumber( groupBox14, "lCDNumberTof4" );
    lCDNumberTof4->setMaximumSize( QSize( 15, 25 ) );
    lCDNumberTof4->setNumDigits( 1 );
    lCDNumberTof4->setProperty( "value", 4 );
    lCDNumberTof4->setProperty( "intValue", 4 );

    groupBox14Layout->addWidget( lCDNumberTof4, 3, 0 );

    lCDNumberTof5 = new QLCDNumber( groupBox14, "lCDNumberTof5" );
    lCDNumberTof5->setMaximumSize( QSize( 15, 25 ) );
    lCDNumberTof5->setNumDigits( 1 );
    lCDNumberTof5->setProperty( "value", 5 );
    lCDNumberTof5->setProperty( "intValue", 5 );

    groupBox14Layout->addWidget( lCDNumberTof5, 4, 0 );

    pushButtonTofCollapse = new QPushButton( groupBox14, "pushButtonTofCollapse" );
    pushButtonTofCollapse->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonTofCollapse_font(  pushButtonTofCollapse->font() );
    pushButtonTofCollapse_font.setBold( TRUE );
    pushButtonTofCollapse->setFont( pushButtonTofCollapse_font ); 
    pushButtonTofCollapse->setFlat( TRUE );

    groupBox14Layout->addWidget( pushButtonTofCollapse, 1, 1 );

    pushButtonTofRemove = new QPushButton( groupBox14, "pushButtonTofRemove" );
    pushButtonTofRemove->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonTofRemove_font(  pushButtonTofRemove->font() );
    pushButtonTofRemove_font.setBold( TRUE );
    pushButtonTofRemove->setFont( pushButtonTofRemove_font ); 
    pushButtonTofRemove->setFlat( TRUE );

    groupBox14Layout->addWidget( pushButtonTofRemove, 2, 1 );

    pushButtonTofMerge = new QPushButton( groupBox14, "pushButtonTofMerge" );
    pushButtonTofMerge->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonTofMerge_font(  pushButtonTofMerge->font() );
    pushButtonTofMerge_font.setBold( TRUE );
    pushButtonTofMerge->setFont( pushButtonTofMerge_font ); 
    pushButtonTofMerge->setFlat( TRUE );

    groupBox14Layout->addWidget( pushButtonTofMerge, 3, 1 );

    pushButtonTofSplit = new QPushButton( groupBox14, "pushButtonTofSplit" );
    pushButtonTofSplit->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonTofSplit_font(  pushButtonTofSplit->font() );
    pushButtonTofSplit_font.setBold( TRUE );
    pushButtonTofSplit->setFont( pushButtonTofSplit_font ); 
    pushButtonTofSplit->setFlat( TRUE );

    groupBox14Layout->addWidget( pushButtonTofSplit, 4, 1 );

    pushButtonTofShift = new QPushButton( groupBox14, "pushButtonTofShift" );
    pushButtonTofShift->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonTofShift_font(  pushButtonTofShift->font() );
    pushButtonTofShift_font.setBold( TRUE );
    pushButtonTofShift->setFont( pushButtonTofShift_font ); 
    pushButtonTofShift->setToggleButton( FALSE );
    pushButtonTofShift->setOn( FALSE );
    pushButtonTofShift->setFlat( TRUE );

    groupBox14Layout->addWidget( pushButtonTofShift, 0, 1 );

    spinBoxMerge = new QSpinBox( groupBox14, "spinBoxMerge" );
    spinBoxMerge->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, spinBoxMerge->sizePolicy().hasHeightForWidth() ) );
    spinBoxMerge->setMaxValue( 32 );
    spinBoxMerge->setMinValue( 1 );
    spinBoxMerge->setValue( 4 );

    groupBox14Layout->addWidget( spinBoxMerge, 3, 2 );

    spinBoxRemove = new QSpinBox( groupBox14, "spinBoxRemove" );
    spinBoxRemove->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, spinBoxRemove->sizePolicy().hasHeightForWidth() ) );
    spinBoxRemove->setMaxValue( 15 );
    spinBoxRemove->setMinValue( 0 );
    spinBoxRemove->setValue( 2 );

    groupBox14Layout->addWidget( spinBoxRemove, 2, 2 );

    spinBoxCollapse = new QSpinBox( groupBox14, "spinBoxCollapse" );
    spinBoxCollapse->setEnabled( TRUE );
    spinBoxCollapse->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, spinBoxCollapse->sizePolicy().hasHeightForWidth() ) );
    spinBoxCollapse->setMaxValue( 2 );
    spinBoxCollapse->setMinValue( 1 );

    groupBox14Layout->addWidget( spinBoxCollapse, 1, 2 );

    spinBoxTofShift = new QSpinBox( groupBox14, "spinBoxTofShift" );
    spinBoxTofShift->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, spinBoxTofShift->sizePolicy().hasHeightForWidth() ) );
    spinBoxTofShift->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxTofShift->setMinValue( 0 );
    spinBoxTofShift->setValue( 3 );

    groupBox14Layout->addWidget( spinBoxTofShift, 0, 2 );

    layout157 = new QHBoxLayout( 0, 0, 5, "layout157"); 

    textLabelL = new QLabel( groupBox14, "textLabelL" );
    textLabelL->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabelL->sizePolicy().hasHeightForWidth() ) );
    layout157->addWidget( textLabelL );

    lineEditTofLambda = new QLineEdit( groupBox14, "lineEditTofLambda" );
    lineEditTofLambda->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditTofLambda->sizePolicy().hasHeightForWidth() ) );
    lineEditTofLambda->setMinimumSize( QSize( 30, 0 ) );
    lineEditTofLambda->setMaximumSize( QSize( 80, 32767 ) );
    lineEditTofLambda->setFrameShape( QLineEdit::NoFrame );
    layout157->addWidget( lineEditTofLambda );

    textLabelDL = new QLabel( groupBox14, "textLabelDL" );
    textLabelDL->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabelDL->sizePolicy().hasHeightForWidth() ) );
    layout157->addWidget( textLabelDL );

    lineEditTofDeltaLambda = new QLineEdit( groupBox14, "lineEditTofDeltaLambda" );
    lineEditTofDeltaLambda->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditTofDeltaLambda->sizePolicy().hasHeightForWidth() ) );
    lineEditTofDeltaLambda->setMinimumSize( QSize( 30, 0 ) );
    lineEditTofDeltaLambda->setMaximumSize( QSize( 32767, 32767 ) );
    lineEditTofDeltaLambda->setFrameShape( QLineEdit::NoFrame );
    layout157->addWidget( lineEditTofDeltaLambda );

    spinBoxTofSplitFrom = new QSpinBox( groupBox14, "spinBoxTofSplitFrom" );
    spinBoxTofSplitFrom->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, spinBoxTofSplitFrom->sizePolicy().hasHeightForWidth() ) );
    spinBoxTofSplitFrom->setMinimumSize( QSize( 45, 0 ) );
    spinBoxTofSplitFrom->setMaximumSize( QSize( 60, 32767 ) );
    spinBoxTofSplitFrom->setMaxValue( 1024 );
    spinBoxTofSplitFrom->setMinValue( 1 );
    spinBoxTofSplitFrom->setValue( 1 );
    layout157->addWidget( spinBoxTofSplitFrom );

    spinBoxTofSplitTo = new QSpinBox( groupBox14, "spinBoxTofSplitTo" );
    spinBoxTofSplitTo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, spinBoxTofSplitTo->sizePolicy().hasHeightForWidth() ) );
    spinBoxTofSplitTo->setMinimumSize( QSize( 50, 0 ) );
    spinBoxTofSplitTo->setMaximumSize( QSize( 60, 32767 ) );
    spinBoxTofSplitTo->setMaxValue( 1024 );
    spinBoxTofSplitTo->setMinValue( 1 );
    spinBoxTofSplitTo->setValue( 1024 );
    layout157->addWidget( spinBoxTofSplitTo );

    groupBox14Layout->addLayout( layout157, 4, 2 );
    pageLayout_25->addWidget( groupBox14 );

    groupBox22 = new QGroupBox( page_25, "groupBox22" );
    groupBox22->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)5, 0, 0, groupBox22->sizePolicy().hasHeightForWidth() ) );
    groupBox22->setMaximumSize( QSize( 32700, 32000 ) );
    groupBox22->setColumnLayout(0, Qt::Vertical );
    groupBox22->layout()->setSpacing( 3 );
    groupBox22->layout()->setMargin( 7 );
    groupBox22Layout = new QVBoxLayout( groupBox22->layout() );
    groupBox22Layout->setAlignment( Qt::AlignTop );

    layout77 = new QHBoxLayout( 0, 0, 6, "layout77"); 

    lCDNumberTof1_2 = new QLCDNumber( groupBox22, "lCDNumberTof1_2" );
    lCDNumberTof1_2->setMaximumSize( QSize( 15, 25 ) );
    QFont lCDNumberTof1_2_font(  lCDNumberTof1_2->font() );
    lCDNumberTof1_2->setFont( lCDNumberTof1_2_font ); 
    lCDNumberTof1_2->setNumDigits( 1 );
    lCDNumberTof1_2->setProperty( "value", 1 );
    layout77->addWidget( lCDNumberTof1_2 );

    textLabelL_2 = new QLabel( groupBox22, "textLabelL_2" );
    textLabelL_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabelL_2->sizePolicy().hasHeightForWidth() ) );
    layout77->addWidget( textLabelL_2 );

    lCDNumberTof5_2 = new QLCDNumber( groupBox22, "lCDNumberTof5_2" );
    lCDNumberTof5_2->setMaximumSize( QSize( 15, 25 ) );
    lCDNumberTof5_2->setNumDigits( 1 );
    lCDNumberTof5_2->setProperty( "value", 5 );
    lCDNumberTof5_2->setProperty( "intValue", 5 );
    layout77->addWidget( lCDNumberTof5_2 );

    pushButtonTofAll = new QPushButton( groupBox22, "pushButtonTofAll" );
    pushButtonTofAll->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, pushButtonTofAll->sizePolicy().hasHeightForWidth() ) );
    pushButtonTofAll->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonTofAll_font(  pushButtonTofAll->font() );
    pushButtonTofAll_font.setBold( TRUE );
    pushButtonTofAll->setFont( pushButtonTofAll_font ); 
    pushButtonTofAll->setFlat( TRUE );
    layout77->addWidget( pushButtonTofAll );
    groupBox22Layout->addLayout( layout77 );

    layout79_2 = new QHBoxLayout( 0, 0, 6, "layout79_2"); 

    checkBoxTofDelete = new QCheckBox( groupBox22, "checkBoxTofDelete" );
    checkBoxTofDelete->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, checkBoxTofDelete->sizePolicy().hasHeightForWidth() ) );
    layout79_2->addWidget( checkBoxTofDelete );

    checkBoxTof12345 = new QCheckBox( groupBox22, "checkBoxTof12345" );
    layout79_2->addWidget( checkBoxTof12345 );
    groupBox22Layout->addLayout( layout79_2 );

    layout78 = new QHBoxLayout( 0, 0, 6, "layout78"); 

    checkBoxTofPrefix = new QCheckBox( groupBox22, "checkBoxTofPrefix" );
    layout78->addWidget( checkBoxTofPrefix );

    lineEditTofPrefix = new QLineEdit( groupBox22, "lineEditTofPrefix" );
    lineEditTofPrefix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditTofPrefix->sizePolicy().hasHeightForWidth() ) );
    lineEditTofPrefix->setFrameShape( QLineEdit::NoFrame );
    layout78->addWidget( lineEditTofPrefix );

    checkBoxTofSuffix = new QCheckBox( groupBox22, "checkBoxTofSuffix" );
    layout78->addWidget( checkBoxTofSuffix );

    lineEditTofSuffix = new QLineEdit( groupBox22, "lineEditTofSuffix" );
    lineEditTofSuffix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)0, 0, 0, lineEditTofSuffix->sizePolicy().hasHeightForWidth() ) );
    lineEditTofSuffix->setFrameShape( QLineEdit::NoFrame );
    layout78->addWidget( lineEditTofSuffix );
    groupBox22Layout->addLayout( layout78 );
    pageLayout_25->addWidget( groupBox22 );

    groupBoxTofEstimation = new QGroupBox( page_25, "groupBoxTofEstimation" );
    groupBoxTofEstimation->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)5, 0, 0, groupBoxTofEstimation->sizePolicy().hasHeightForWidth() ) );
    groupBoxTofEstimation->setMaximumSize( QSize( 32767, 32767 ) );
    groupBoxTofEstimation->setColumnLayout(0, Qt::Vertical );
    groupBoxTofEstimation->layout()->setSpacing( 6 );
    groupBoxTofEstimation->layout()->setMargin( 11 );
    groupBoxTofEstimationLayout = new QHBoxLayout( groupBoxTofEstimation->layout() );
    groupBoxTofEstimationLayout->setAlignment( Qt::AlignTop );

    comboBoxTofInputAllFrames = new QComboBox( FALSE, groupBoxTofEstimation, "comboBoxTofInputAllFrames" );
    groupBoxTofEstimationLayout->addWidget( comboBoxTofInputAllFrames );

    spinBoxWLS = new QSpinBox( groupBoxTofEstimation, "spinBoxWLS" );
    spinBoxWLS->setMaxValue( 20 );
    spinBoxWLS->setMinValue( 10 );
    spinBoxWLS->setLineStep( 10 );
    spinBoxWLS->setValue( 20 );
    groupBoxTofEstimationLayout->addWidget( spinBoxWLS );

    pushButtonTofCheck = new QPushButton( groupBoxTofEstimation, "pushButtonTofCheck" );
    pushButtonTofCheck->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonTofCheck->sizePolicy().hasHeightForWidth() ) );
    pushButtonTofCheck->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonTofCheck_font(  pushButtonTofCheck->font() );
    pushButtonTofCheck_font.setBold( TRUE );
    pushButtonTofCheck->setFont( pushButtonTofCheck_font ); 
    pushButtonTofCheck->setFlat( TRUE );
    groupBoxTofEstimationLayout->addWidget( pushButtonTofCheck );

    comboBoxTofOutputFrames = new QComboBox( FALSE, groupBoxTofEstimation, "comboBoxTofOutputFrames" );
    groupBoxTofEstimationLayout->addWidget( comboBoxTofOutputFrames );

    lineEditTheoWLS = new QLineEdit( groupBoxTofEstimation, "lineEditTheoWLS" );
    lineEditTheoWLS->setEnabled( FALSE );
    lineEditTheoWLS->setMaximumSize( QSize( 35, 32767 ) );
    lineEditTheoWLS->setFrameShape( QLineEdit::NoFrame );
    groupBoxTofEstimationLayout->addWidget( lineEditTheoWLS );
    pageLayout_25->addWidget( groupBoxTofEstimation );
    spacer61_2 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::MinimumExpanding );
    pageLayout_25->addItem( spacer61_2 );
    toolBoxAdv->addItem( page_25, QString::fromLatin1("") );
    TabPageLayout_2->addWidget( toolBoxAdv );
    sansTab->insertTab( TabPage_2, QString::fromLatin1("") );

    TabPage_3 = new QWidget( sansTab, "TabPage_3" );
    TabPageLayout_3 = new QVBoxLayout( TabPage_3, 11, 6, "TabPageLayout_3"); 

    toolBox9 = new QToolBox( TabPage_3, "toolBox9" );
    toolBox9->setCurrentIndex( 0 );

    page1_6 = new QWidget( toolBox9, "page1_6" );
    page1_6->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout_6 = new QVBoxLayout( page1_6, 3, 3, "page1Layout_6"); 

    frame15 = new QFrame( page1_6, "frame15" );
    frame15->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, frame15->sizePolicy().hasHeightForWidth() ) );
    frame15->setMinimumSize( QSize( 400, 0 ) );
    frame15->setMaximumSize( QSize( 4000, 32767 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    frame15->setPalette( pal );
    frame15->setFrameShape( QFrame::StyledPanel );
    frame15->setFrameShadow( QFrame::Raised );
    frame15->setLineWidth( 0 );
    frame15Layout = new QVBoxLayout( frame15, 0, 0, "frame15Layout"); 

    buttonGroupActiveMask = new QButtonGroup( frame15, "buttonGroupActiveMask" );
    buttonGroupActiveMask->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroupActiveMask->sizePolicy().hasHeightForWidth() ) );
    buttonGroupActiveMask->setColumnLayout(0, Qt::Vertical );
    buttonGroupActiveMask->layout()->setSpacing( 2 );
    buttonGroupActiveMask->layout()->setMargin( 11 );
    buttonGroupActiveMaskLayout = new QHBoxLayout( buttonGroupActiveMask->layout() );
    buttonGroupActiveMaskLayout->setAlignment( Qt::AlignTop );

    comboBoxMaskFor = new QComboBox( FALSE, buttonGroupActiveMask, "comboBoxMaskFor" );
    comboBoxMaskFor->setEnabled( TRUE );
    comboBoxMaskFor->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxMaskFor->sizePolicy().hasHeightForWidth() ) );
    comboBoxMaskFor->setMinimumSize( QSize( 0, 25 ) );
    comboBoxMaskFor->setMaximumSize( QSize( 32767, 25 ) );
    comboBoxMaskFor->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxMaskFor->setPalette( pal );
    comboBoxMaskFor->setSizeLimit( 100 );
    buttonGroupActiveMaskLayout->addWidget( comboBoxMaskFor );

    pushButtonCreateMask = new QToolButton( buttonGroupActiveMask, "pushButtonCreateMask" );
    pushButtonCreateMask->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonCreateMask->sizePolicy().hasHeightForWidth() ) );
    pushButtonCreateMask->setMinimumSize( QSize( 0, 25 ) );
    pushButtonCreateMask->setMaximumSize( QSize( 80, 25 ) );
    pushButtonCreateMask->setIconSet( QIconSet( image10 ) );
    pushButtonCreateMask->setUsesTextLabel( TRUE );
    pushButtonCreateMask->setTextPosition( QToolButton::BesideIcon );
    buttonGroupActiveMaskLayout->addWidget( pushButtonCreateMask );

    pushButtonSaveMaskTr = new QToolButton( buttonGroupActiveMask, "pushButtonSaveMaskTr" );
    pushButtonSaveMaskTr->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonSaveMaskTr->sizePolicy().hasHeightForWidth() ) );
    pushButtonSaveMaskTr->setMinimumSize( QSize( 25, 25 ) );
    pushButtonSaveMaskTr->setMaximumSize( QSize( 120, 25 ) );
    pushButtonSaveMaskTr->setIconSet( QIconSet( image10 ) );
    pushButtonSaveMaskTr->setUsesTextLabel( TRUE );
    pushButtonSaveMaskTr->setTextPosition( QToolButton::BesideIcon );
    buttonGroupActiveMaskLayout->addWidget( pushButtonSaveMaskTr );

    pushButtonCreateMaskAs = new QToolButton( buttonGroupActiveMask, "pushButtonCreateMaskAs" );
    pushButtonCreateMaskAs->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonCreateMaskAs->sizePolicy().hasHeightForWidth() ) );
    pushButtonCreateMaskAs->setMinimumSize( QSize( 0, 25 ) );
    pushButtonCreateMaskAs->setMaximumSize( QSize( 65, 25 ) );
    pushButtonCreateMaskAs->setIconSet( QIconSet( image11 ) );
    pushButtonCreateMaskAs->setUsesTextLabel( TRUE );
    pushButtonCreateMaskAs->setTextPosition( QToolButton::BesideIcon );
    buttonGroupActiveMaskLayout->addWidget( pushButtonCreateMaskAs );

    pushButtonSaveMask = new QToolButton( buttonGroupActiveMask, "pushButtonSaveMask" );
    pushButtonSaveMask->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonSaveMask->sizePolicy().hasHeightForWidth() ) );
    pushButtonSaveMask->setMinimumSize( QSize( 25, 25 ) );
    pushButtonSaveMask->setMaximumSize( QSize( 25, 25 ) );
    pushButtonSaveMask->setIconSet( QIconSet( image3 ) );
    buttonGroupActiveMaskLayout->addWidget( pushButtonSaveMask );

    pushButtonOpenMask = new QToolButton( buttonGroupActiveMask, "pushButtonOpenMask" );
    pushButtonOpenMask->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonOpenMask->sizePolicy().hasHeightForWidth() ) );
    pushButtonOpenMask->setMinimumSize( QSize( 25, 25 ) );
    pushButtonOpenMask->setMaximumSize( QSize( 25, 25 ) );
    pushButtonOpenMask->setIconSet( QIconSet( image2 ) );
    buttonGroupActiveMaskLayout->addWidget( pushButtonOpenMask );
    frame15Layout->addWidget( buttonGroupActiveMask );

    groupBoxMask = new QGroupBox( frame15, "groupBoxMask" );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    groupBoxMask->setPalette( pal );
    groupBoxMask->setCheckable( TRUE );
    groupBoxMask->setColumnLayout(0, Qt::Vertical );
    groupBoxMask->layout()->setSpacing( 4 );
    groupBoxMask->layout()->setMargin( 8 );
    groupBoxMaskLayout = new QHBoxLayout( groupBoxMask->layout() );
    groupBoxMaskLayout->setAlignment( Qt::AlignTop );

    layout69 = new QGridLayout( 0, 1, 1, 0, 6, "layout69"); 

    pushButtonGetCoord1 = new QPushButton( groupBoxMask, "pushButtonGetCoord1" );
    pushButtonGetCoord1->setMinimumSize( QSize( 15, 25 ) );
    pushButtonGetCoord1->setMaximumSize( QSize( 15, 15 ) );

    layout69->addWidget( pushButtonGetCoord1, 1, 1 );

    comboBoxMaskEdgeShape = new QComboBox( FALSE, groupBoxMask, "comboBoxMaskEdgeShape" );
    comboBoxMaskEdgeShape->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxMaskEdgeShape->sizePolicy().hasHeightForWidth() ) );
    comboBoxMaskEdgeShape->setMinimumSize( QSize( 0, 25 ) );
    comboBoxMaskEdgeShape->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxMaskEdgeShape_font(  comboBoxMaskEdgeShape->font() );
    comboBoxMaskEdgeShape->setFont( comboBoxMaskEdgeShape_font ); 

    layout69->addWidget( comboBoxMaskEdgeShape, 0, 3 );

    textLabelMaskLeft = new QLabel( groupBoxMask, "textLabelMaskLeft" );
    textLabelMaskLeft->setMaximumSize( QSize( 20, 10 ) );
    textLabelMaskLeft->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeft_font(  textLabelMaskLeft->font() );
    textLabelMaskLeft->setFont( textLabelMaskLeft_font ); 

    layout69->addWidget( textLabelMaskLeft, 0, 0 );

    textLabelMaskRight_2 = new QLabel( groupBoxMask, "textLabelMaskRight_2" );
    textLabelMaskRight_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskRight_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskRight_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    layout69->addWidget( textLabelMaskRight_2, 2, 3 );

    spinBoxRBx = new QSpinBox( groupBoxMask, "spinBoxRBx" );
    spinBoxRBx->setMinimumSize( QSize( 0, 25 ) );
    spinBoxRBx->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxRBx->setPalette( pal );
    spinBoxRBx->setMaxValue( 128 );
    spinBoxRBx->setMinValue( 1 );
    spinBoxRBx->setValue( 121 );

    layout69->addWidget( spinBoxRBx, 2, 0 );

    spinBoxLTx = new QSpinBox( groupBoxMask, "spinBoxLTx" );
    spinBoxLTx->setMinimumSize( QSize( 0, 25 ) );
    spinBoxLTx->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxLTx->setPalette( pal );
    spinBoxLTx->setMaxValue( 128 );
    spinBoxLTx->setMinValue( -50 );
    spinBoxLTx->setValue( 8 );

    layout69->addWidget( spinBoxLTx, 1, 0 );

    pushButtonGetCoord2 = new QPushButton( groupBoxMask, "pushButtonGetCoord2" );
    pushButtonGetCoord2->setMinimumSize( QSize( 15, 25 ) );
    pushButtonGetCoord2->setMaximumSize( QSize( 15, 15 ) );

    layout69->addWidget( pushButtonGetCoord2, 2, 1 );

    textLabelMaskLeft_2 = new QLabel( groupBoxMask, "textLabelMaskLeft_2" );
    textLabelMaskLeft_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    layout69->addWidget( textLabelMaskLeft_2, 1, 3 );

    spinBoxLTy = new QSpinBox( groupBoxMask, "spinBoxLTy" );
    spinBoxLTy->setMinimumSize( QSize( 0, 25 ) );
    spinBoxLTy->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxLTy->setPalette( pal );
    spinBoxLTy->setMaxValue( 128 );
    spinBoxLTy->setMinValue( -50 );
    spinBoxLTy->setValue( 8 );

    layout69->addWidget( spinBoxLTy, 1, 2 );

    textLabelMaskRight = new QLabel( groupBoxMask, "textLabelMaskRight" );
    textLabelMaskRight->setMaximumSize( QSize( 10, 20 ) );
    textLabelMaskRight->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskRight_font(  textLabelMaskRight->font() );
    textLabelMaskRight->setFont( textLabelMaskRight_font ); 

    layout69->addWidget( textLabelMaskRight, 0, 2 );
    spacer32_2 = new QSpacerItem( 16, 16, QSizePolicy::Fixed, QSizePolicy::Minimum );
    layout69->addItem( spacer32_2, 0, 1 );

    spinBoxRBy = new QSpinBox( groupBoxMask, "spinBoxRBy" );
    spinBoxRBy->setMinimumSize( QSize( 0, 25 ) );
    spinBoxRBy->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxRBy->setPalette( pal );
    spinBoxRBy->setMaxValue( 128 );
    spinBoxRBy->setMinValue( 1 );
    spinBoxRBy->setValue( 121 );

    layout69->addWidget( spinBoxRBy, 2, 2 );
    groupBoxMaskLayout->addLayout( layout69 );

    layout67 = new QVBoxLayout( 0, 0, 0, "layout67"); 
    spacer36 = new QSpacerItem( 25, 5, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout67->addItem( spacer36 );
    groupBoxMaskLayout->addLayout( layout67 );
    frame15Layout->addWidget( groupBoxMask );

    groupBoxMaskBS = new QGroupBox( frame15, "groupBoxMaskBS" );
    groupBoxMaskBS->setCheckable( TRUE );
    groupBoxMaskBS->setColumnLayout(0, Qt::Vertical );
    groupBoxMaskBS->layout()->setSpacing( 4 );
    groupBoxMaskBS->layout()->setMargin( 8 );
    groupBoxMaskBSLayout = new QHBoxLayout( groupBoxMaskBS->layout() );
    groupBoxMaskBSLayout->setAlignment( Qt::AlignTop );

    layout68_2 = new QGridLayout( 0, 1, 1, 0, 6, "layout68_2"); 

    spinBoxRByBS = new QSpinBox( groupBoxMaskBS, "spinBoxRByBS" );
    spinBoxRByBS->setMinimumSize( QSize( 0, 25 ) );
    spinBoxRByBS->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxRByBS->setPalette( pal );
    spinBoxRByBS->setMaxValue( 128 );
    spinBoxRByBS->setMinValue( 1 );
    spinBoxRByBS->setValue( 71 );

    layout68_2->addWidget( spinBoxRByBS, 2, 2 );

    spinBoxLTyBS = new QSpinBox( groupBoxMaskBS, "spinBoxLTyBS" );
    spinBoxLTyBS->setMinimumSize( QSize( 0, 25 ) );
    spinBoxLTyBS->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxLTyBS->setPalette( pal );
    spinBoxLTyBS->setMaxValue( 128 );
    spinBoxLTyBS->setMinValue( 1 );
    spinBoxLTyBS->setValue( 58 );

    layout68_2->addWidget( spinBoxLTyBS, 1, 2 );

    pushButtonGetCoord4 = new QPushButton( groupBoxMaskBS, "pushButtonGetCoord4" );
    pushButtonGetCoord4->setMinimumSize( QSize( 15, 25 ) );
    pushButtonGetCoord4->setMaximumSize( QSize( 15, 15 ) );

    layout68_2->addWidget( pushButtonGetCoord4, 2, 1 );
    spacer32_2_2 = new QSpacerItem( 16, 16, QSizePolicy::Fixed, QSizePolicy::Minimum );
    layout68_2->addItem( spacer32_2_2, 0, 1 );

    textLabelMaskRight_2_2 = new QLabel( groupBoxMaskBS, "textLabelMaskRight_2_2" );
    textLabelMaskRight_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskRight_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskRight_2_2->setMinimumSize( QSize( 0, 0 ) );
    textLabelMaskRight_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    layout68_2->addWidget( textLabelMaskRight_2_2, 2, 3 );

    pushButtonGetCoord3 = new QPushButton( groupBoxMaskBS, "pushButtonGetCoord3" );
    pushButtonGetCoord3->setMinimumSize( QSize( 15, 25 ) );
    pushButtonGetCoord3->setMaximumSize( QSize( 15, 15 ) );

    layout68_2->addWidget( pushButtonGetCoord3, 1, 1 );

    textLabelMaskRightBS = new QLabel( groupBoxMaskBS, "textLabelMaskRightBS" );
    textLabelMaskRightBS->setMaximumSize( QSize( 10, 20 ) );
    textLabelMaskRightBS->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskRightBS_font(  textLabelMaskRightBS->font() );
    textLabelMaskRightBS->setFont( textLabelMaskRightBS_font ); 

    layout68_2->addWidget( textLabelMaskRightBS, 0, 2 );

    spinBoxRBxBS = new QSpinBox( groupBoxMaskBS, "spinBoxRBxBS" );
    spinBoxRBxBS->setMinimumSize( QSize( 0, 25 ) );
    spinBoxRBxBS->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxRBxBS->setPalette( pal );
    spinBoxRBxBS->setMaxValue( 128 );
    spinBoxRBxBS->setMinValue( 1 );
    spinBoxRBxBS->setValue( 71 );

    layout68_2->addWidget( spinBoxRBxBS, 2, 0 );

    comboBoxMaskBeamstopShape = new QComboBox( FALSE, groupBoxMaskBS, "comboBoxMaskBeamstopShape" );
    comboBoxMaskBeamstopShape->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxMaskBeamstopShape->sizePolicy().hasHeightForWidth() ) );
    comboBoxMaskBeamstopShape->setMinimumSize( QSize( 0, 25 ) );
    comboBoxMaskBeamstopShape->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxMaskBeamstopShape_font(  comboBoxMaskBeamstopShape->font() );
    comboBoxMaskBeamstopShape->setFont( comboBoxMaskBeamstopShape_font ); 

    layout68_2->addWidget( comboBoxMaskBeamstopShape, 0, 3 );

    textLabelMaskLeft_2_2 = new QLabel( groupBoxMaskBS, "textLabelMaskLeft_2_2" );
    textLabelMaskLeft_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelMaskLeft_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelMaskLeft_2_2->setMinimumSize( QSize( 0, 0 ) );
    textLabelMaskLeft_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    layout68_2->addWidget( textLabelMaskLeft_2_2, 1, 3 );

    textLabelMaskLeftBS = new QLabel( groupBoxMaskBS, "textLabelMaskLeftBS" );
    textLabelMaskLeftBS->setMaximumSize( QSize( 20, 10 ) );
    textLabelMaskLeftBS->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabelMaskLeftBS_font(  textLabelMaskLeftBS->font() );
    textLabelMaskLeftBS->setFont( textLabelMaskLeftBS_font ); 

    layout68_2->addWidget( textLabelMaskLeftBS, 0, 0 );

    spinBoxLTxBS = new QSpinBox( groupBoxMaskBS, "spinBoxLTxBS" );
    spinBoxLTxBS->setMinimumSize( QSize( 0, 25 ) );
    spinBoxLTxBS->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    spinBoxLTxBS->setPalette( pal );
    spinBoxLTxBS->setMaxValue( 128 );
    spinBoxLTxBS->setMinValue( 1 );
    spinBoxLTxBS->setValue( 58 );

    layout68_2->addWidget( spinBoxLTxBS, 1, 0 );
    groupBoxMaskBSLayout->addLayout( layout68_2 );

    layout70 = new QVBoxLayout( 0, 0, 2, "layout70"); 
    spacer37 = new QSpacerItem( 25, 30, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout70->addItem( spacer37 );

    toolButtonPlusMaskBS = new QToolButton( groupBoxMaskBS, "toolButtonPlusMaskBS" );
    toolButtonPlusMaskBS->setMinimumSize( QSize( 25, 25 ) );
    toolButtonPlusMaskBS->setMaximumSize( QSize( 25, 25 ) );
    toolButtonPlusMaskBS->setIconSet( QIconSet( image12 ) );
    layout70->addWidget( toolButtonPlusMaskBS );
    groupBoxMaskBSLayout->addLayout( layout70 );
    frame15Layout->addWidget( groupBoxMaskBS );
    page1Layout_6->addWidget( frame15 );

    layout119_2 = new QHBoxLayout( 0, 8, 6, "layout119_2"); 
    spacer48 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout119_2->addItem( spacer48 );

    pushButtonMaskTools = new QToolButton( page1_6, "pushButtonMaskTools" );
    pushButtonMaskTools->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonMaskTools->sizePolicy().hasHeightForWidth() ) );
    pushButtonMaskTools->setMinimumSize( QSize( 25, 25 ) );
    pushButtonMaskTools->setMaximumSize( QSize( 25, 25 ) );
    pushButtonMaskTools->setIconSet( QIconSet( image13 ) );
    pushButtonMaskTools->setUsesTextLabel( FALSE );
    pushButtonMaskTools->setAutoRaise( FALSE );
    pushButtonMaskTools->setTextPosition( QToolButton::BelowIcon );
    layout119_2->addWidget( pushButtonMaskTools );
    page1Layout_6->addLayout( layout119_2 );

    layout197 = new QGridLayout( 0, 1, 1, 0, 6, "layout197"); 

    lineEditDeadRows = new QLineEdit( page1_6, "lineEditDeadRows" );
    lineEditDeadRows->setEnabled( TRUE );
    lineEditDeadRows->setMinimumSize( QSize( 50, 25 ) );
    lineEditDeadRows->setMaximumSize( QSize( 15000, 25 ) );
    lineEditDeadRows->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditDeadRows->setFrameShape( QLineEdit::GroupBoxPanel );
    lineEditDeadRows->setLineWidth( 1 );

    layout197->addWidget( lineEditDeadRows, 0, 1 );

    lineEditDeadCols = new QLineEdit( page1_6, "lineEditDeadCols" );
    lineEditDeadCols->setEnabled( TRUE );
    lineEditDeadCols->setMinimumSize( QSize( 50, 25 ) );
    lineEditDeadCols->setMaximumSize( QSize( 15000, 25 ) );
    lineEditDeadCols->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditDeadCols->setFrameShape( QLineEdit::GroupBoxPanel );
    lineEditDeadCols->setLineWidth( 1 );

    layout197->addWidget( lineEditDeadCols, 1, 1 );

    textLabel1_9_2_2 = new QLabel( page1_6, "textLabel1_9_2_2" );
    textLabel1_9_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_9_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_9_2_2->setMinimumSize( QSize( 100, 0 ) );

    layout197->addWidget( textLabel1_9_2_2, 2, 0 );

    textLabel1_9_2 = new QLabel( page1_6, "textLabel1_9_2" );
    textLabel1_9_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_9_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_9_2->setMinimumSize( QSize( 150, 0 ) );

    layout197->addWidget( textLabel1_9_2, 1, 0 );

    textLabel1_9 = new QLabel( page1_6, "textLabel1_9" );
    textLabel1_9->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel1_9->sizePolicy().hasHeightForWidth() ) );
    textLabel1_9->setMinimumSize( QSize( 150, 0 ) );

    layout197->addWidget( textLabel1_9, 0, 0 );

    pushButtonGetCoordDRows = new QPushButton( page1_6, "pushButtonGetCoordDRows" );
    pushButtonGetCoordDRows->setMinimumSize( QSize( 15, 25 ) );
    pushButtonGetCoordDRows->setMaximumSize( QSize( 15, 15 ) );

    layout197->addWidget( pushButtonGetCoordDRows, 0, 2 );

    lineEditMaskPolygons = new QLineEdit( page1_6, "lineEditMaskPolygons" );
    lineEditMaskPolygons->setEnabled( TRUE );
    lineEditMaskPolygons->setMinimumSize( QSize( 50, 25 ) );
    lineEditMaskPolygons->setMaximumSize( QSize( 15000, 25 ) );
    lineEditMaskPolygons->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditMaskPolygons->setFrameShape( QLineEdit::GroupBoxPanel );
    lineEditMaskPolygons->setLineWidth( 1 );

    layout197->addWidget( lineEditMaskPolygons, 2, 1 );

    pushButtonGetCoordTrian = new QPushButton( page1_6, "pushButtonGetCoordTrian" );
    pushButtonGetCoordTrian->setMinimumSize( QSize( 15, 25 ) );
    pushButtonGetCoordTrian->setMaximumSize( QSize( 15, 15 ) );

    layout197->addWidget( pushButtonGetCoordTrian, 2, 2 );

    pushButtonGetCoordDCols = new QPushButton( page1_6, "pushButtonGetCoordDCols" );
    pushButtonGetCoordDCols->setMinimumSize( QSize( 15, 25 ) );
    pushButtonGetCoordDCols->setMaximumSize( QSize( 15, 15 ) );

    layout197->addWidget( pushButtonGetCoordDCols, 1, 2 );
    page1Layout_6->addLayout( layout197 );
    spacer45 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page1Layout_6->addItem( spacer45 );
    toolBox9->addItem( page1_6, QString::fromLatin1("") );
    TabPageLayout_3->addWidget( toolBox9 );
    sansTab->insertTab( TabPage_3, QString::fromLatin1("") );

    TabPage_4 = new QWidget( sansTab, "TabPage_4" );
    TabPageLayout_4 = new QVBoxLayout( TabPage_4, 11, 6, "TabPageLayout_4"); 

    toolBox10 = new QToolBox( TabPage_4, "toolBox10" );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    toolBox10->setPalette( pal );
    toolBox10->setCurrentIndex( 0 );

    page1_7 = new QWidget( toolBox10, "page1_7" );
    page1_7->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout_7 = new QVBoxLayout( page1_7, 3, 3, "page1Layout_7"); 

    frame16 = new QFrame( page1_7, "frame16" );
    frame16->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, frame16->sizePolicy().hasHeightForWidth() ) );
    frame16->setMinimumSize( QSize( 400, 0 ) );
    frame16->setMaximumSize( QSize( 4000, 32767 ) );
    frame16->setFrameShape( QFrame::StyledPanel );
    frame16->setFrameShadow( QFrame::Raised );
    frame16->setLineWidth( 0 );
    frame16Layout = new QVBoxLayout( frame16, 0, 6, "frame16Layout"); 

    buttonGroupActiveSens = new QButtonGroup( frame16, "buttonGroupActiveSens" );
    buttonGroupActiveSens->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroupActiveSens->sizePolicy().hasHeightForWidth() ) );
    buttonGroupActiveSens->setColumnLayout(0, Qt::Vertical );
    buttonGroupActiveSens->layout()->setSpacing( 2 );
    buttonGroupActiveSens->layout()->setMargin( 11 );
    buttonGroupActiveSensLayout = new QHBoxLayout( buttonGroupActiveSens->layout() );
    buttonGroupActiveSensLayout->setAlignment( Qt::AlignTop );

    comboBoxSensFor = new QComboBox( FALSE, buttonGroupActiveSens, "comboBoxSensFor" );
    comboBoxSensFor->setEnabled( TRUE );
    comboBoxSensFor->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxSensFor->sizePolicy().hasHeightForWidth() ) );
    comboBoxSensFor->setMinimumSize( QSize( 0, 25 ) );
    comboBoxSensFor->setMaximumSize( QSize( 32767, 25 ) );
    comboBoxSensFor->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxSensFor->setPalette( pal );
    buttonGroupActiveSensLayout->addWidget( comboBoxSensFor );

    pushButtonCreateSens = new QToolButton( buttonGroupActiveSens, "pushButtonCreateSens" );
    pushButtonCreateSens->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonCreateSens->sizePolicy().hasHeightForWidth() ) );
    pushButtonCreateSens->setMinimumSize( QSize( 0, 25 ) );
    pushButtonCreateSens->setMaximumSize( QSize( 80, 25 ) );
    pushButtonCreateSens->setIconSet( QIconSet( image10 ) );
    pushButtonCreateSens->setUsesTextLabel( TRUE );
    pushButtonCreateSens->setTextPosition( QToolButton::BesideIcon );
    buttonGroupActiveSensLayout->addWidget( pushButtonCreateSens );

    pushButtonCreateSensAs = new QToolButton( buttonGroupActiveSens, "pushButtonCreateSensAs" );
    pushButtonCreateSensAs->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonCreateSensAs->sizePolicy().hasHeightForWidth() ) );
    pushButtonCreateSensAs->setMinimumSize( QSize( 0, 25 ) );
    pushButtonCreateSensAs->setMaximumSize( QSize( 65, 25 ) );
    pushButtonCreateSensAs->setIconSet( QIconSet( image11 ) );
    pushButtonCreateSensAs->setUsesTextLabel( TRUE );
    pushButtonCreateSensAs->setTextPosition( QToolButton::BesideIcon );
    buttonGroupActiveSensLayout->addWidget( pushButtonCreateSensAs );

    pushButtonSaveSens = new QToolButton( buttonGroupActiveSens, "pushButtonSaveSens" );
    pushButtonSaveSens->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonSaveSens->sizePolicy().hasHeightForWidth() ) );
    pushButtonSaveSens->setMinimumSize( QSize( 25, 25 ) );
    pushButtonSaveSens->setMaximumSize( QSize( 25, 25 ) );
    pushButtonSaveSens->setIconSet( QIconSet( image3 ) );
    buttonGroupActiveSensLayout->addWidget( pushButtonSaveSens );

    pushButtonOpenSens = new QToolButton( buttonGroupActiveSens, "pushButtonOpenSens" );
    pushButtonOpenSens->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonOpenSens->sizePolicy().hasHeightForWidth() ) );
    pushButtonOpenSens->setMinimumSize( QSize( 25, 25 ) );
    pushButtonOpenSens->setMaximumSize( QSize( 25, 25 ) );
    pushButtonOpenSens->setIconSet( QIconSet( image2 ) );
    buttonGroupActiveSensLayout->addWidget( pushButtonOpenSens );
    frame16Layout->addWidget( buttonGroupActiveSens );

    buttonGroupSensanyD = new QButtonGroup( frame16, "buttonGroupSensanyD" );
    buttonGroupSensanyD->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroupSensanyD->sizePolicy().hasHeightForWidth() ) );
    buttonGroupSensanyD->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    buttonGroupSensanyD->setCheckable( TRUE );
    buttonGroupSensanyD->setColumnLayout(0, Qt::Vertical );
    buttonGroupSensanyD->layout()->setSpacing( 6 );
    buttonGroupSensanyD->layout()->setMargin( 11 );
    buttonGroupSensanyDLayout = new QGridLayout( buttonGroupSensanyD->layout() );
    buttonGroupSensanyDLayout->setAlignment( Qt::AlignTop );

    textLabel1 = new QLabel( buttonGroupSensanyD, "textLabel1" );
    textLabel1->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel1->sizePolicy().hasHeightForWidth() ) );
    textLabel1->setMinimumSize( QSize( 180, 0 ) );

    buttonGroupSensanyDLayout->addWidget( textLabel1, 0, 2 );

    textLabel2 = new QLabel( buttonGroupSensanyD, "textLabel2" );
    textLabel2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel2->sizePolicy().hasHeightForWidth() ) );

    buttonGroupSensanyDLayout->addWidget( textLabel2, 1, 2 );

    lineEditTransAnyD = new QLineEdit( buttonGroupSensanyD, "lineEditTransAnyD" );
    lineEditTransAnyD->setEnabled( TRUE );
    lineEditTransAnyD->setMinimumSize( QSize( 50, 25 ) );
    lineEditTransAnyD->setMaximumSize( QSize( 15000, 25 ) );
    lineEditTransAnyD->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditTransAnyD->setLineWidth( 1 );

    buttonGroupSensanyDLayout->addWidget( lineEditTransAnyD, 3, 1 );

    lineEditBcAnyD = new QLineEdit( buttonGroupSensanyD, "lineEditBcAnyD" );
    lineEditBcAnyD->setEnabled( TRUE );
    lineEditBcAnyD->setMinimumSize( QSize( 50, 25 ) );
    lineEditBcAnyD->setMaximumSize( QSize( 15000, 25 ) );
    lineEditBcAnyD->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditBcAnyD->setLineWidth( 1 );

    buttonGroupSensanyDLayout->addWidget( lineEditBcAnyD, 2, 1 );

    lineEditEBAnyD = new QLineEdit( buttonGroupSensanyD, "lineEditEBAnyD" );
    lineEditEBAnyD->setEnabled( TRUE );
    lineEditEBAnyD->setMinimumSize( QSize( 50, 25 ) );
    lineEditEBAnyD->setMaximumSize( QSize( 15000, 25 ) );
    lineEditEBAnyD->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditEBAnyD->setLineWidth( 1 );

    buttonGroupSensanyDLayout->addWidget( lineEditEBAnyD, 1, 1 );

    lineEditPlexiAnyD = new QLineEdit( buttonGroupSensanyD, "lineEditPlexiAnyD" );
    lineEditPlexiAnyD->setEnabled( TRUE );
    lineEditPlexiAnyD->setMinimumSize( QSize( 50, 25 ) );
    lineEditPlexiAnyD->setMaximumSize( QSize( 15000, 25 ) );
    lineEditPlexiAnyD->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditPlexiAnyD->setFrameShape( QLineEdit::GroupBoxPanel );
    lineEditPlexiAnyD->setLineWidth( 1 );

    buttonGroupSensanyDLayout->addWidget( lineEditPlexiAnyD, 0, 1 );

    textLabel3 = new QLabel( buttonGroupSensanyD, "textLabel3" );
    textLabel3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel3->sizePolicy().hasHeightForWidth() ) );

    buttonGroupSensanyDLayout->addWidget( textLabel3, 2, 2 );

    pushButtonAnyPlexi = new QToolButton( buttonGroupSensanyD, "pushButtonAnyPlexi" );
    pushButtonAnyPlexi->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonAnyPlexi->sizePolicy().hasHeightForWidth() ) );
    pushButtonAnyPlexi->setMinimumSize( QSize( 25, 25 ) );
    pushButtonAnyPlexi->setMaximumSize( QSize( 25, 25 ) );
    pushButtonAnyPlexi->setIconSet( QIconSet( image14 ) );

    buttonGroupSensanyDLayout->addWidget( pushButtonAnyPlexi, 0, 0 );

    pushButtonAnyBC = new QToolButton( buttonGroupSensanyD, "pushButtonAnyBC" );
    pushButtonAnyBC->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonAnyBC->sizePolicy().hasHeightForWidth() ) );
    pushButtonAnyBC->setMinimumSize( QSize( 25, 25 ) );
    pushButtonAnyBC->setMaximumSize( QSize( 25, 25 ) );
    pushButtonAnyBC->setIconSet( QIconSet( image14 ) );

    buttonGroupSensanyDLayout->addWidget( pushButtonAnyBC, 2, 0 );

    pushButtonAnyTr = new QToolButton( buttonGroupSensanyD, "pushButtonAnyTr" );
    pushButtonAnyTr->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonAnyTr->sizePolicy().hasHeightForWidth() ) );
    pushButtonAnyTr->setMinimumSize( QSize( 25, 25 ) );
    pushButtonAnyTr->setMaximumSize( QSize( 25, 25 ) );
    pushButtonAnyTr->setIconSet( QIconSet( image1 ) );

    buttonGroupSensanyDLayout->addWidget( pushButtonAnyTr, 3, 0 );

    pushButtonAnyEB = new QToolButton( buttonGroupSensanyD, "pushButtonAnyEB" );
    pushButtonAnyEB->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonAnyEB->sizePolicy().hasHeightForWidth() ) );
    pushButtonAnyEB->setMinimumSize( QSize( 25, 25 ) );
    pushButtonAnyEB->setMaximumSize( QSize( 25, 25 ) );
    pushButtonAnyEB->setIconSet( QIconSet( image14 ) );

    buttonGroupSensanyDLayout->addWidget( pushButtonAnyEB, 1, 0 );

    layout68_3 = new QHBoxLayout( 0, 0, 0, "layout68_3"); 

    pushButtonTrHiden = new QPushButton( buttonGroupSensanyD, "pushButtonTrHiden" );
    pushButtonTrHiden->setMaximumSize( QSize( 150, 32767 ) );
    pushButtonTrHiden->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    pushButtonTrHiden->setFlat( TRUE );
    layout68_3->addWidget( pushButtonTrHiden );
    spacer38 = new QSpacerItem( 110, 5, QSizePolicy::Fixed, QSizePolicy::Minimum );
    layout68_3->addItem( spacer38 );

    buttonGroupSensanyDLayout->addLayout( layout68_3, 3, 2 );
    frame16Layout->addWidget( buttonGroupSensanyD );
    page1Layout_7->addWidget( frame16 );
    spacer41 = new QSpacerItem( 5, 20, QSizePolicy::Minimum, QSizePolicy::Fixed );
    page1Layout_7->addItem( spacer41 );

    layout71 = new QVBoxLayout( 0, 0, 0, "layout71"); 

    line1_2_3_8 = new QFrame( page1_7, "line1_2_3_8" );
    line1_2_3_8->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_3_8->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_8->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_8->setFrameShape( QFrame::HLine );
    line1_2_3_8->setFrameShadow( QFrame::Plain );
    line1_2_3_8->setLineWidth( 1 );
    line1_2_3_8->setFrameShape( QFrame::HLine );
    layout71->addWidget( line1_2_3_8 );

    buttonGroupLimits = new QButtonGroup( page1_7, "buttonGroupLimits" );
    buttonGroupLimits->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroupLimits->sizePolicy().hasHeightForWidth() ) );
    buttonGroupLimits->setMinimumSize( QSize( 0, 20 ) );
    buttonGroupLimits->setMaximumSize( QSize( 32767, 20 ) );
    buttonGroupLimits->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroupLimits->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    buttonGroupLimits->setPalette( pal );
    QFont buttonGroupLimits_font(  buttonGroupLimits->font() );
    buttonGroupLimits_font.setBold( TRUE );
    buttonGroupLimits->setFont( buttonGroupLimits_font ); 
    buttonGroupLimits->setFrameShape( QButtonGroup::NoFrame );
    buttonGroupLimits->setFrameShadow( QButtonGroup::Plain );
    buttonGroupLimits->setLineWidth( 0 );
    buttonGroupLimits->setCheckable( TRUE );
    buttonGroupLimits->setColumnLayout(0, Qt::Vertical );
    buttonGroupLimits->layout()->setSpacing( 2 );
    buttonGroupLimits->layout()->setMargin( 11 );
    buttonGroupLimitsLayout = new QVBoxLayout( buttonGroupLimits->layout() );
    buttonGroupLimitsLayout->setAlignment( Qt::AlignTop );

    buttonGroupSensRange = new QButtonGroup( buttonGroupLimits, "buttonGroupSensRange" );
    buttonGroupSensRange->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroupSensRange->sizePolicy().hasHeightForWidth() ) );
    buttonGroupSensRange->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    QFont buttonGroupSensRange_font(  buttonGroupSensRange->font() );
    buttonGroupSensRange_font.setBold( FALSE );
    buttonGroupSensRange->setFont( buttonGroupSensRange_font ); 
    buttonGroupSensRange->setColumnLayout(0, Qt::Vertical );
    buttonGroupSensRange->layout()->setSpacing( 6 );
    buttonGroupSensRange->layout()->setMargin( 11 );
    buttonGroupSensRangeLayout = new QHBoxLayout( buttonGroupSensRange->layout() );
    buttonGroupSensRangeLayout->setAlignment( Qt::AlignTop );

    layout59_2 = new QHBoxLayout( 0, 0, 6, "layout59_2"); 

    spinBoxErrLeftLimit = new QSpinBox( buttonGroupSensRange, "spinBoxErrLeftLimit" );
    spinBoxErrLeftLimit->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxErrLeftLimit->sizePolicy().hasHeightForWidth() ) );
    spinBoxErrLeftLimit->setMinimumSize( QSize( 0, 25 ) );
    spinBoxErrLeftLimit->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxErrLeftLimit->setMaxValue( 1000 );
    layout59_2->addWidget( spinBoxErrLeftLimit );

    textLabel1_10 = new QLabel( buttonGroupSensRange, "textLabel1_10" );
    layout59_2->addWidget( textLabel1_10 );

    spinBoxErrRightLimit = new QSpinBox( buttonGroupSensRange, "spinBoxErrRightLimit" );
    spinBoxErrRightLimit->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxErrRightLimit->sizePolicy().hasHeightForWidth() ) );
    spinBoxErrRightLimit->setMinimumSize( QSize( 0, 25 ) );
    spinBoxErrRightLimit->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxErrRightLimit->setMaxValue( 1000 );
    spinBoxErrRightLimit->setValue( 1000 );
    layout59_2->addWidget( spinBoxErrRightLimit );
    buttonGroupSensRangeLayout->addLayout( layout59_2 );
    buttonGroupLimitsLayout->addWidget( buttonGroupSensRange );

    checkBoxSensError = new QCheckBox( buttonGroupLimits, "checkBoxSensError" );
    checkBoxSensError->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxSensError->sizePolicy().hasHeightForWidth() ) );
    checkBoxSensError->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxSensError->setPalette( pal );
    QFont checkBoxSensError_font(  checkBoxSensError->font() );
    checkBoxSensError_font.setBold( FALSE );
    checkBoxSensError->setFont( checkBoxSensError_font ); 
    buttonGroupLimitsLayout->addWidget( checkBoxSensError );

    checkBoxSensTr = new QCheckBox( buttonGroupLimits, "checkBoxSensTr" );
    checkBoxSensTr->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxSensTr->sizePolicy().hasHeightForWidth() ) );
    checkBoxSensTr->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    checkBoxSensTr->setPalette( pal );
    QFont checkBoxSensTr_font(  checkBoxSensTr->font() );
    checkBoxSensTr_font.setBold( FALSE );
    checkBoxSensTr->setFont( checkBoxSensTr_font ); 
    buttonGroupLimitsLayout->addWidget( checkBoxSensTr );
    layout71->addWidget( buttonGroupLimits );

    line1_2_3_8_2 = new QFrame( page1_7, "line1_2_3_8_2" );
    line1_2_3_8_2->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_3_8_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_8_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_8_2->setFrameShape( QFrame::HLine );
    line1_2_3_8_2->setFrameShadow( QFrame::Plain );
    line1_2_3_8_2->setLineWidth( 1 );
    line1_2_3_8_2->setFrameShape( QFrame::HLine );
    layout71->addWidget( line1_2_3_8_2 );
    page1Layout_7->addLayout( layout71 );
    spacer49 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page1Layout_7->addItem( spacer49 );
    toolBox10->addItem( page1_7, QString::fromLatin1("") );
    TabPageLayout_4->addWidget( toolBox10 );
    sansTab->insertTab( TabPage_4, QString::fromLatin1("") );

    TabPage_5 = new QWidget( sansTab, "TabPage_5" );
    TabPageLayout_5 = new QVBoxLayout( TabPage_5, 11, 6, "TabPageLayout_5"); 

    toolBoxProcess = new QToolBox( TabPage_5, "toolBoxProcess" );
    toolBoxProcess->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, toolBoxProcess->sizePolicy().hasHeightForWidth() ) );
    toolBoxProcess->setMinimumSize( QSize( 255, 0 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    toolBoxProcess->setPalette( pal );
    toolBoxProcess->setCurrentIndex( 0 );

    page1_8 = new QWidget( toolBoxProcess, "page1_8" );
    page1_8->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout_8 = new QVBoxLayout( page1_8, 11, 6, "page1Layout_8"); 

    layout121_2 = new QHBoxLayout( 0, 0, 0, "layout121_2"); 

    pushButtonDeleteFirst = new QToolButton( page1_8, "pushButtonDeleteFirst" );
    pushButtonDeleteFirst->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonDeleteFirst->sizePolicy().hasHeightForWidth() ) );
    pushButtonDeleteFirst->setMinimumSize( QSize( 20, 20 ) );
    pushButtonDeleteFirst->setMaximumSize( QSize( 20, 20 ) );
    pushButtonDeleteFirst->setIconSet( QIconSet( image4 ) );
    pushButtonDeleteFirst->setUsesTextLabel( FALSE );
    pushButtonDeleteFirst->setAutoRaise( FALSE );
    pushButtonDeleteFirst->setTextPosition( QToolButton::BelowIcon );
    layout121_2->addWidget( pushButtonDeleteFirst );

    sliderConfigurations = new QSlider( page1_8, "sliderConfigurations" );
    sliderConfigurations->setMinimumSize( QSize( 20, 20 ) );
    sliderConfigurations->setMaximumSize( QSize( 32767, 20 ) );
    sliderConfigurations->setMinValue( 1 );
    sliderConfigurations->setMaxValue( 30 );
    sliderConfigurations->setPageStep( 1 );
    sliderConfigurations->setOrientation( QSlider::Horizontal );
    sliderConfigurations->setTickmarks( QSlider::Above );
    sliderConfigurations->setTickInterval( 1 );
    layout121_2->addWidget( sliderConfigurations );

    pushButtonAddCopy = new QToolButton( page1_8, "pushButtonAddCopy" );
    pushButtonAddCopy->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonAddCopy->sizePolicy().hasHeightForWidth() ) );
    pushButtonAddCopy->setMinimumSize( QSize( 20, 20 ) );
    pushButtonAddCopy->setMaximumSize( QSize( 20, 20 ) );
    pushButtonAddCopy->setIconSet( QIconSet( image9 ) );
    pushButtonAddCopy->setUsesTextLabel( FALSE );
    pushButtonAddCopy->setAutoRaise( FALSE );
    pushButtonAddCopy->setTextPosition( QToolButton::BelowIcon );
    layout121_2->addWidget( pushButtonAddCopy );
    page1Layout_8->addLayout( layout121_2 );

    splitterTables = new QSplitter( page1_8, "splitterTables" );
    splitterTables->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)2, 0, 0, splitterTables->sizePolicy().hasHeightForWidth() ) );
    splitterTables->setOrientation( QSplitter::Horizontal );
    splitterTables->setHandleWidth( 6 );

    tableECinfo = new QTable( splitterTables, "tableECinfo" );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "#-EC ..." ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "#-BC..." ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "C..." ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "D..." ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, trUtf8( "\xce\xbb\x2e\x2e\x2e" ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "Bea..." ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "Abs...FS]" ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "Abs...EB]" ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "Abs...BC]" ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "D-[FS..." ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, trUtf8( "\xce\xbc\x2e\x2e\x2e" ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "Tr-[FS..." ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "Factor" ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "#-\"Ce..." ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "X-ce..." ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "Y-ce..." ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "Mask...rix" ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "Sen...rix" ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "#-EB..." ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "Tr [EC-...]" ) );
    tableECinfo->setNumRows( tableECinfo->numRows() + 1 );
    tableECinfo->verticalHeader()->setLabel( tableECinfo->numRows() - 1, image15, tr( "Mas... Tr]" ) );
    tableECinfo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)2, 100, 0, tableECinfo->sizePolicy().hasHeightForWidth() ) );
    tableECinfo->setMinimumSize( QSize( 0, 50 ) );
    tableECinfo->setMaximumSize( QSize( 0, 4000 ) );
    tableECinfo->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tableECinfo->setPalette( pal );
    tableECinfo->setBackgroundOrigin( QTable::WidgetOrigin );
    QFont tableECinfo_font(  tableECinfo->font() );
    tableECinfo->setFont( tableECinfo_font ); 
    tableECinfo->setMouseTracking( TRUE );
    tableECinfo->setAcceptDrops( FALSE );
    tableECinfo->setFrameShape( QTable::NoFrame );
    tableECinfo->setFrameShadow( QTable::Plain );
    tableECinfo->setLineWidth( 1 );
    tableECinfo->setMargin( 0 );
    tableECinfo->setMidLineWidth( 0 );
    tableECinfo->setResizePolicy( QTable::Default );
    tableECinfo->setVScrollBarMode( QTable::AlwaysOff );
    tableECinfo->setHScrollBarMode( QTable::AlwaysOff );
    tableECinfo->setDragAutoScroll( TRUE );
    tableECinfo->setNumRows( 21 );
    tableECinfo->setNumCols( 0 );
    tableECinfo->setShowGrid( FALSE );
    tableECinfo->setRowMovingEnabled( FALSE );
    tableECinfo->setColumnMovingEnabled( FALSE );
    tableECinfo->setReadOnly( TRUE );
    tableECinfo->setSorting( FALSE );
    tableECinfo->setSelectionMode( QTable::NoSelection );
    tableECinfo->setFocusStyle( QTable::SpreadSheet );

    tableECnew = new QTable( splitterTables, "tableECnew" );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image16, tr( "#-EC [EB]" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image16, tr( "#-BC" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, tr( "C[m]" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, tr( "D[m]" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, trUtf8( "\xce\xbb\x5b\xc3\x85\x5d" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, tr( "Beam Size" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image16, tr( "Abs.Cal. [#-FS]" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image16, tr( "Abs.Cal. [#-EB]" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image16, tr( "Abs.Cal. [#-BC]" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, tr( "D-[FS|EB][m]" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, trUtf8( "\xce\xbc\x2d\x5b\x46\x53\x5d" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, tr( "Tr-[FS|Att]" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, tr( "Factor" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image16, tr( "#-\"Center\"" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, tr( "X-center" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, tr( "Y-center" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, tr( "Mask Matrix" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, tr( "Sens. Matrix" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image16, tr( "#-EB" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image1, tr( "Tr [EC-to-EB]" ) );
    tableECnew->setNumRows( tableECnew->numRows() + 1 );
    tableECnew->verticalHeader()->setLabel( tableECnew->numRows() - 1, image10, tr( "Mask Matrix [Tr]" ) );
    tableECnew->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)2, 1, 0, tableECnew->sizePolicy().hasHeightForWidth() ) );
    tableECnew->setMinimumSize( QSize( 25, 50 ) );
    tableECnew->setMaximumSize( QSize( 2500, 4000 ) );
    tableECnew->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tableECnew->setPalette( pal );
    tableECnew->setBackgroundOrigin( QTable::WidgetOrigin );
    QFont tableECnew_font(  tableECnew->font() );
    tableECnew->setFont( tableECnew_font ); 
    tableECnew->setMouseTracking( TRUE );
    tableECnew->setAcceptDrops( FALSE );
    tableECnew->setFrameShape( QTable::NoFrame );
    tableECnew->setFrameShadow( QTable::Plain );
    tableECnew->setLineWidth( 1 );
    tableECnew->setMargin( 0 );
    tableECnew->setMidLineWidth( 0 );
    tableECnew->setResizePolicy( QTable::Default );
    tableECnew->setVScrollBarMode( QTable::Auto );
    tableECnew->setHScrollBarMode( QTable::Auto );
    tableECnew->setNumRows( 21 );
    tableECnew->setNumCols( 1 );
    tableECnew->setRowMovingEnabled( TRUE );
    tableECnew->setColumnMovingEnabled( TRUE );
    tableECnew->setSorting( FALSE );
    page1Layout_8->addWidget( splitterTables );

    buttonGroupScriptTools = new QButtonGroup( page1_8, "buttonGroupScriptTools" );
    buttonGroupScriptTools->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, buttonGroupScriptTools->sizePolicy().hasHeightForWidth() ) );
    buttonGroupScriptTools->setMaximumSize( QSize( 32767, 50 ) );
    buttonGroupScriptTools->setMargin( 0 );
    buttonGroupScriptTools->setColumnLayout(0, Qt::Vertical );
    buttonGroupScriptTools->layout()->setSpacing( 2 );
    buttonGroupScriptTools->layout()->setMargin( 9 );
    buttonGroupScriptToolsLayout = new QHBoxLayout( buttonGroupScriptTools->layout() );
    buttonGroupScriptToolsLayout->setAlignment( Qt::AlignTop );

    comboBoxMakeScriptTable = new QComboBox( FALSE, buttonGroupScriptTools, "comboBoxMakeScriptTable" );
    comboBoxMakeScriptTable->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxMakeScriptTable->sizePolicy().hasHeightForWidth() ) );
    comboBoxMakeScriptTable->setMinimumSize( QSize( 0, 24 ) );
    comboBoxMakeScriptTable->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    comboBoxMakeScriptTable->setPalette( pal );
    comboBoxMakeScriptTable->setAutoMask( TRUE );
    buttonGroupScriptToolsLayout->addWidget( comboBoxMakeScriptTable );

    pushButtonNewScript = new QToolButton( buttonGroupScriptTools, "pushButtonNewScript" );
    pushButtonNewScript->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)7, 0, 0, pushButtonNewScript->sizePolicy().hasHeightForWidth() ) );
    pushButtonNewScript->setMinimumSize( QSize( 60, 0 ) );
    pushButtonNewScript->setMaximumSize( QSize( 2300, 25 ) );
    pushButtonNewScript->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    pushButtonNewScript->setPaletteBackgroundColor( QColor( 220, 220, 220 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonNewScript->setPalette( pal );
    pushButtonNewScript->setBackgroundOrigin( QToolButton::WindowOrigin );
    QFont pushButtonNewScript_font(  pushButtonNewScript->font() );
    pushButtonNewScript->setFont( pushButtonNewScript_font ); 
    pushButtonNewScript->setIconSet( QIconSet( image8 ) );
    pushButtonNewScript->setUsesBigPixmap( FALSE );
    pushButtonNewScript->setUsesTextLabel( TRUE );
    pushButtonNewScript->setTextPosition( QToolButton::BesideIcon );
    buttonGroupScriptTools->insert( pushButtonNewScript, 2 );
    buttonGroupScriptToolsLayout->addWidget( pushButtonNewScript );

    pushButtonMakeTable = new QToolButton( buttonGroupScriptTools, "pushButtonMakeTable" );
    pushButtonMakeTable->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonMakeTable->sizePolicy().hasHeightForWidth() ) );
    pushButtonMakeTable->setMinimumSize( QSize( 60, 24 ) );
    pushButtonMakeTable->setMaximumSize( QSize( 24, 24 ) );
    pushButtonMakeTable->setIconSet( QIconSet( image9 ) );
    pushButtonMakeTable->setUsesTextLabel( TRUE );
    pushButtonMakeTable->setAutoRaise( FALSE );
    pushButtonMakeTable->setTextPosition( QToolButton::BesideIcon );
    buttonGroupScriptToolsLayout->addWidget( pushButtonMakeTable );

    pushButtonCalcTr = new QToolButton( buttonGroupScriptTools, "pushButtonCalcTr" );
    pushButtonCalcTr->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonCalcTr->sizePolicy().hasHeightForWidth() ) );
    pushButtonCalcTr->setMinimumSize( QSize( 60, 24 ) );
    pushButtonCalcTr->setMaximumSize( QSize( 50, 24 ) );
    pushButtonCalcTr->setIconSet( QIconSet( image17 ) );
    pushButtonCalcTr->setUsesTextLabel( TRUE );
    pushButtonCalcTr->setAutoRaise( FALSE );
    pushButtonCalcTr->setTextPosition( QToolButton::BesideIcon );
    buttonGroupScriptToolsLayout->addWidget( pushButtonCalcTr );

    pushButtonSaveSettings = new QToolButton( buttonGroupScriptTools, "pushButtonSaveSettings" );
    pushButtonSaveSettings->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonSaveSettings->sizePolicy().hasHeightForWidth() ) );
    pushButtonSaveSettings->setMinimumSize( QSize( 24, 24 ) );
    pushButtonSaveSettings->setMaximumSize( QSize( 24, 24 ) );
    pushButtonSaveSettings->setIconSet( QIconSet( image3 ) );
    buttonGroupScriptToolsLayout->addWidget( pushButtonSaveSettings );
    page1Layout_8->addWidget( buttonGroupScriptTools );

    buttonGroupdaNdAN = new QButtonGroup( page1_8, "buttonGroupdaNdAN" );
    buttonGroupdaNdAN->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, buttonGroupdaNdAN->sizePolicy().hasHeightForWidth() ) );
    buttonGroupdaNdAN->setCheckable( FALSE );
    buttonGroupdaNdAN->setColumnLayout(0, Qt::Vertical );
    buttonGroupdaNdAN->layout()->setSpacing( 1 );
    buttonGroupdaNdAN->layout()->setMargin( 11 );
    buttonGroupdaNdANLayout = new QHBoxLayout( buttonGroupdaNdAN->layout() );
    buttonGroupdaNdANLayout->setAlignment( Qt::AlignTop );

    layout122 = new QGridLayout( 0, 1, 1, 0, 1, "layout122"); 

    pushButtonIQx = new QToolButton( buttonGroupdaNdAN, "pushButtonIQx" );
    pushButtonIQx->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonIQx->sizePolicy().hasHeightForWidth() ) );
    pushButtonIQx->setMinimumSize( QSize( 0, 25 ) );
    pushButtonIQx->setMaximumSize( QSize( 80, 25 ) );

    layout122->addWidget( pushButtonIQx, 1, 1 );

    pushButtonPolar = new QToolButton( buttonGroupdaNdAN, "pushButtonPolar" );
    pushButtonPolar->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonPolar->sizePolicy().hasHeightForWidth() ) );
    pushButtonPolar->setMinimumSize( QSize( 0, 25 ) );
    pushButtonPolar->setMaximumSize( QSize( 80, 25 ) );

    layout122->addWidget( pushButtonPolar, 1, 0 );

    pushButtonIQy = new QToolButton( buttonGroupdaNdAN, "pushButtonIQy" );
    pushButtonIQy->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonIQy->sizePolicy().hasHeightForWidth() ) );
    pushButtonIQy->setMinimumSize( QSize( 0, 25 ) );
    pushButtonIQy->setMaximumSize( QSize( 80, 25 ) );

    layout122->addWidget( pushButtonIQy, 0, 1 );

    pushButtonIxy = new QToolButton( buttonGroupdaNdAN, "pushButtonIxy" );
    pushButtonIxy->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonIxy->sizePolicy().hasHeightForWidth() ) );
    pushButtonIxy->setMinimumSize( QSize( 0, 25 ) );
    pushButtonIxy->setMaximumSize( QSize( 80, 25 ) );

    layout122->addWidget( pushButtonIxy, 0, 0 );
    buttonGroupdaNdANLayout->addLayout( layout122 );

    pushButtonIQ = new QToolButton( buttonGroupdaNdAN, "pushButtonIQ" );
    pushButtonIQ->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonIQ->sizePolicy().hasHeightForWidth() ) );
    pushButtonIQ->setMinimumSize( QSize( 51, 51 ) );
    pushButtonIQ->setMaximumSize( QSize( 51, 51 ) );
    buttonGroupdaNdANLayout->addWidget( pushButtonIQ );

    layout122_2 = new QGridLayout( 0, 1, 1, 0, 1, "layout122_2"); 

    pushButtondQxy = new QToolButton( buttonGroupdaNdAN, "pushButtondQxy" );
    pushButtondQxy->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtondQxy->sizePolicy().hasHeightForWidth() ) );
    pushButtondQxy->setMinimumSize( QSize( 0, 25 ) );
    pushButtondQxy->setMaximumSize( QSize( 80, 25 ) );

    layout122_2->addWidget( pushButtondQxy, 1, 1 );

    pushButtonSigma = new QToolButton( buttonGroupdaNdAN, "pushButtonSigma" );
    pushButtonSigma->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonSigma->sizePolicy().hasHeightForWidth() ) );
    pushButtonSigma->setMinimumSize( QSize( 0, 25 ) );
    pushButtonSigma->setMaximumSize( QSize( 80, 25 ) );

    layout122_2->addWidget( pushButtonSigma, 1, 0 );

    pushButtonQxy = new QToolButton( buttonGroupdaNdAN, "pushButtonQxy" );
    pushButtonQxy->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonQxy->sizePolicy().hasHeightForWidth() ) );
    pushButtonQxy->setMinimumSize( QSize( 0, 25 ) );
    pushButtonQxy->setMaximumSize( QSize( 80, 25 ) );

    layout122_2->addWidget( pushButtonQxy, 0, 1 );

    pushButtondIxy = new QToolButton( buttonGroupdaNdAN, "pushButtondIxy" );
    pushButtondIxy->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtondIxy->sizePolicy().hasHeightForWidth() ) );
    pushButtondIxy->setMinimumSize( QSize( 0, 25 ) );
    pushButtondIxy->setMaximumSize( QSize( 80, 25 ) );

    layout122_2->addWidget( pushButtondIxy, 0, 0 );
    buttonGroupdaNdANLayout->addLayout( layout122_2 );

    layout69_2 = new QVBoxLayout( 0, 0, 0, "layout69_2"); 

    radioButtonOpenInProject = new QRadioButton( buttonGroupdaNdAN, "radioButtonOpenInProject" );
    radioButtonOpenInProject->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, radioButtonOpenInProject->sizePolicy().hasHeightForWidth() ) );
    radioButtonOpenInProject->setMinimumSize( QSize( 50, 17 ) );
    radioButtonOpenInProject->setMaximumSize( QSize( 2000, 17 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, QColor( 255, 255, 195) );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    radioButtonOpenInProject->setPalette( pal );
    radioButtonOpenInProject->setChecked( TRUE );
    layout69_2->addWidget( radioButtonOpenInProject );

    radioButtonFile = new QRadioButton( buttonGroupdaNdAN, "radioButtonFile" );
    radioButtonFile->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, radioButtonFile->sizePolicy().hasHeightForWidth() ) );
    radioButtonFile->setMinimumSize( QSize( 50, 17 ) );
    radioButtonFile->setMaximumSize( QSize( 2000, 17 ) );
    layout69_2->addWidget( radioButtonFile );

    lineEditFileExt = new QLineEdit( buttonGroupdaNdAN, "lineEditFileExt" );
    lineEditFileExt->setMinimumSize( QSize( 50, 17 ) );
    lineEditFileExt->setMaximumSize( QSize( 100, 17 ) );
    layout69_2->addWidget( lineEditFileExt );
    buttonGroupdaNdANLayout->addLayout( layout69_2 );
    page1Layout_8->addWidget( buttonGroupdaNdAN );
    toolBoxProcess->addItem( page1_8, QString::fromLatin1("") );
    TabPageLayout_5->addWidget( toolBoxProcess );
    sansTab->insertTab( TabPage_5, QString::fromLatin1("") );
    danLayout->addWidget( sansTab );

    layout50 = new QHBoxLayout( 0, 0, 3, "layout50"); 

    textLabelInfoSAS = new QLabel( this, "textLabelInfoSAS" );
    textLabelInfoSAS->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfoSAS->sizePolicy().hasHeightForWidth() ) );
    textLabelInfoSAS->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfoSAS->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabelInfoSAS->setPalette( pal );
    textLabelInfoSAS->setFrameShape( QLabel::Box );
    textLabelInfoSAS->setTextFormat( QLabel::RichText );
    textLabelInfoSAS->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    textLabelInfoSAS->setIndent( 0 );
    layout50->addWidget( textLabelInfoSAS );

    textLabelInfo_2_2 = new QLabel( this, "textLabelInfo_2_2" );
    textLabelInfo_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo_2_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabelInfo_2_2->setPalette( pal );
    textLabelInfo_2_2->setFrameShape( QLabel::Box );
    textLabelInfo_2_2->setAlignment( int( QLabel::AlignCenter ) );
    layout50->addWidget( textLabelInfo_2_2 );

    textLabelInfo_2 = new QLabel( this, "textLabelInfo_2" );
    textLabelInfo_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo_2->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo_2->setMinimumSize( QSize( 0, 20 ) );
    textLabelInfo_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabelInfo_2->setPalette( pal );
    textLabelInfo_2->setFrameShape( QLabel::Box );
    textLabelInfo_2->setFrameShadow( QLabel::Plain );
    textLabelInfo_2->setAlignment( int( QLabel::AlignCenter ) );
    layout50->addWidget( textLabelInfo_2 );
    danLayout->addLayout( layout50 );
    languageChange();
    resize( QSize(614, 762).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // tab order
    setTabOrder( lineEditPlexiAnyD, lineEditEBAnyD );
    setTabOrder( lineEditEBAnyD, lineEditBcAnyD );
    setTabOrder( lineEditBcAnyD, lineEditTransAnyD );
    setTabOrder( lineEditTransAnyD, sansTab );
    setTabOrder( sansTab, comboBoxSel );
    setTabOrder( comboBoxSel, toolBoxAdv );
    setTabOrder( toolBoxAdv, checkBoxRecalculate );
    setTabOrder( checkBoxRecalculate, lineEditCheckRes );
    setTabOrder( lineEditCheckRes, lineEditCheck );
    setTabOrder( lineEditCheck, comboBoxCheck );
    setTabOrder( comboBoxCheck, checkBoxFindCenter );
    setTabOrder( checkBoxFindCenter, radioButtonRadHF );
    setTabOrder( radioButtonRadHF, comboBoxSelectPresentation );
    setTabOrder( comboBoxSelectPresentation, spinBoxRemoveFirst );
    setTabOrder( spinBoxRemoveFirst, spinBoxRemoveLast );
    setTabOrder( spinBoxRemoveLast, spinBoxLTy );
    setTabOrder( spinBoxLTy, spinBoxLTx );
    setTabOrder( spinBoxLTx, spinBoxRBx );
    setTabOrder( spinBoxRBx, spinBoxRBy );
    setTabOrder( spinBoxRBy, spinBoxLTyBS );
    setTabOrder( spinBoxLTyBS, spinBoxLTxBS );
    setTabOrder( spinBoxLTxBS, spinBoxRBxBS );
    setTabOrder( spinBoxRBxBS, spinBoxRByBS );
    setTabOrder( spinBoxRByBS, comboBoxMakeScriptTable );

    // buddies
    textLabelResoPixelSize->setBuddy( lineEditResoPixelSize );
    textLabelResoPixelSize_2_2->setBuddy( lineEditResoPixelSize );
    textLabelResoPixelSize_3->setBuddy( lineEditResoPixelSize );
}

/*
 *  Destroys the object and frees any allocated resources
 */
dan::~dan()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void dan::languageChange()
{
    setCaption( tr( "QtiKWS :: Uni...SA(N)S :: DAN" ) );
    setIconText( QString::null );
    buttonGroupMode0->setTitle( QString::null );
    pushButtonNewSession->setText( QString::null );
    pushButtonNewSession->setTextLabel( tr( "Start NEW session" ) );
    QToolTip::add( pushButtonNewSession, tr( "Start a New Data-Treatment Session  " ) );
    QWhatsThis::add( pushButtonNewSession, tr( "Start a New Data-Treatment Session " ) );
    pushButtonInstrLabel->setText( QString::null );
    pushButtonInstrLabel->setTextLabel( tr( "KWS2" ) );
    QToolTip::add( pushButtonInstrLabel, tr( "Current Instrument" ) );
    QWhatsThis::add( pushButtonInstrLabel, tr( "Current Instrument" ) );
    pushButtonOpenSession->setText( QString::null );
    pushButtonOpenSession->setTextLabel( tr( "Load SAVED Session" ) );
    QToolTip::add( pushButtonOpenSession, tr( "Load a Saved Data-Treatment Session " ) );
    QWhatsThis::add( pushButtonOpenSession, tr( "Load a Saved Data-Treatment Session " ) );
    buttonGroupMode->setTitle( QString::null );
    textLabel1_12_4_2->setText( tr( "<p align=\"center\">Welcome to <font color=\"#5555ff\">  <b>Uni :: SA[N]S :: DAN </b></font>\n"
" interface!<br>\n"
"<p align=\"center\">[ QtiKWS v.16 ]</p></p>\n"
"<br><br>\n"
"\n"
"<p align=\"left\"> <font color=\"#5555ff\"><b>Uni</b></font> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <b>Uni</b>versal, or, <b>Uni</b>que :)</p>\n"
"<p align=\"left\"> <font color=\"#5555ff\"><b>SA[N]S</b></font>&nbsp;&nbsp; <b>S</b>mall <b>A</b>ngle [<b>N</b>eutron] <b>S</b>cattering</p>\n"
"<p align=\"left\"> <font color=\"#5555ff\"><b>DAN</b></font> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <b>D</b>ata <b>AN</b>alysys</p>" ) );
    textLabelInfo2->setText( tr( "<font color=\"#5555ff\">KWS1, KWS2, KWS3, Maria, ... Your SAS Instrument, ...</font>\n"
"<br><br>\n"
"- Did not find Your Instrument?<br>\n"
"- Want to include include it?<br>\n"
"- Ask me how!" ) );
    QToolTip::add( sansTab, tr( "", "Input Name of Table" ) );
    groupBox25->setTitle( tr( "Select [Create] SA(N)S Instrument && Data-Processing-Mode" ) );
    comboBoxSel->clear();
    comboBoxSel->insertItem( tr( "KWS1" ) );
    comboBoxSel->insertItem( tr( "KWS2" ) );
    comboBoxSel->insertItem( tr( "KWS3" ) );
    comboBoxSel->insertItem( tr( "SANS1" ) );
    comboBoxSel->setCurrentItem( 0 );
    QToolTip::add( comboBoxSel, tr( "Select Current Instrument" ) );
    QWhatsThis::add( comboBoxSel, tr( "Select Current Instrument" ) );
    comboBoxMode->clear();
    comboBoxMode->insertItem( tr( "(SM) Standard Mode" ) );
    comboBoxMode->insertItem( tr( "(BS) Buffer Subtraction [2D] " ) );
    comboBoxMode->insertItem( tr( "(BS-SENS) Buffer Subtraction [2D] | Buffer as Sensitivity" ) );
    comboBoxMode->insertItem( tr( "(MS) Magnetic Samples" ) );
    comboBoxMode->setCurrentItem( 0 );
    QToolTip::add( comboBoxMode, tr( "Select Data-Processing-Mode" ) );
    QWhatsThis::add( comboBoxMode, tr( "Select Data-Processing-Mode" ) );
    pushButtonsaveCurrentSaveInstr->setText( QString::null );
    QToolTip::add( pushButtonsaveCurrentSaveInstr, tr( "Save Current / Create New Instrument" ) );
    QWhatsThis::add( pushButtonsaveCurrentSaveInstr, tr( "Save Current / Create New Instrument" ) );
    pushButtonDeleteCurrentInstr->setText( QString::null );
    QToolTip::add( pushButtonDeleteCurrentInstr, tr( "Delete Current Instrument" ) );
    QWhatsThis::add( pushButtonDeleteCurrentInstr, tr( "Delete Current Instrument" ) );
    pushButtonInstrColor->setText( QString::null );
    pushButtonInstrColor->setTextLabel( QString::null );
    QToolTip::add( pushButtonInstrColor, tr( "Instrument Color" ) );
    QWhatsThis::add( pushButtonInstrColor, tr( "Instrument Color" ) );
    buttonGroupOptions->setTitle( QString::null );
    buttonGroup19->setTitle( tr( "Input Folder" ) );
    lineEditPathDAT->setText( tr( "home" ) );
    QToolTip::add( lineEditPathDAT, tr( "Raw Data Folder" ) );
    QWhatsThis::add( lineEditPathDAT, tr( "Raw Data Folder" ) );
    textEditPattern->setText( tr( "*.DAT" ) );
    QToolTip::add( textEditPattern, tr( "Wildcard :: Filter for Rawdata" ) );
    QWhatsThis::add( textEditPattern, tr( "Wildcard :: Filter for Rawdata" ) );
    pushButtonDATpath->setText( QString::null );
    QToolTip::add( pushButtonDATpath, tr( "Change Current Rawdata Folder" ) );
    QWhatsThis::add( pushButtonDATpath, tr( "Change Current Rawdata Folder" ) );
    checkBoxDirsIndir->setText( tr( "Search for rawdata also in sub-folders" ) );
    buttonGroup20_2->setTitle( tr( "Output Folder" ) );
    lineEditPathRAD->setText( tr( "home" ) );
    QToolTip::add( lineEditPathRAD, tr( "Output destination for generated ASCII Files" ) );
    QWhatsThis::add( lineEditPathRAD, tr( "Output destination for generated ASCII Files" ) );
    pushButtonRADpath->setText( QString::null );
    QToolTip::add( pushButtonRADpath, tr( "Change Current Output Folder" ) );
    QWhatsThis::add( pushButtonRADpath, tr( "Change Current Output Folder" ) );
    toolBox7->setItemLabel( toolBox7->indexOf(page1), tr( "Data :: Input and Output Folders" ) );
    lineEditMD_2_2->setText( QString::null );
    lineEditMD_2->setText( QString::null );
    buttonGroupColim->setTitle( QString::null );
    textLabel3_2->setText( trUtf8( "\xce\xbb\x2c\x20\x51" ) );
    comboBoxUnitsLambda->clear();
    comboBoxUnitsLambda->insertItem( trUtf8( "\x5b\xce\xbb\x5d\x3d\xc3\x85\x3b\x20\x20\x5b\x51\x5d\x3d\x31\x2f\xc3\x85" ) );
    comboBoxUnitsLambda->insertItem( trUtf8( "\x5b\xce\xbb\x5d\x3d\x6e\x6d\x3b\x20\x20\x5b\x51\x5d\x3d\x31\x2f\xc3\x85" ) );
    textLabelOutput->setText( tr( "Intensity" ) );
    comboBoxUnitsOutput->clear();
    comboBoxUnitsOutput->insertItem( tr( "1/cm" ) );
    textLabel3_2_2->setText( tr( "Appertures" ) );
    comboBoxUnitsBlends->clear();
    comboBoxUnitsBlends->insertItem( tr( "cm x cm" ) );
    comboBoxUnitsBlends->insertItem( tr( "mm x mm" ) );
    comboBoxUnitsBlends->insertItem( trUtf8( "\xce\xbc\x6d\x20\x78\x20\xce\xbc\x6d" ) );
    comboBoxUnitsBlends->setCurrentItem( 1 );
    textLabel3_2_2_3->setText( tr( "Thickness" ) );
    comboBoxThicknessUnits->clear();
    comboBoxThicknessUnits->insertItem( tr( "cm" ) );
    comboBoxThicknessUnits->insertItem( tr( "mm" ) );
    comboBoxThicknessUnits->setCurrentItem( 1 );
    textLabel3_2_2_2->setText( tr( "C, D, Offset" ) );
    comboBoxUnitsCandD->clear();
    comboBoxUnitsCandD->insertItem( tr( "m" ) );
    comboBoxUnitsCandD->insertItem( tr( "cm" ) );
    comboBoxUnitsCandD->insertItem( tr( "mm" ) );
    textLabel3_2_2_2_2->setText( tr( "Time: Duration" ) );
    comboBoxUnitsTime->clear();
    comboBoxUnitsTime->insertItem( tr( "sec" ) );
    comboBoxUnitsTime->insertItem( tr( "sec/10" ) );
    comboBoxUnitsTime->insertItem( tr( "msec" ) );
    comboBoxUnitsTime->insertItem( trUtf8( "\xce\xbc\x73\x65\x63" ) );
    textLabel3_2_2_2_2_2->setText( tr( "Time: TOF,RT" ) );
    comboBoxUnitsTimeRT->clear();
    comboBoxUnitsTimeRT->insertItem( tr( "sec" ) );
    comboBoxUnitsTimeRT->insertItem( tr( "sec/10" ) );
    comboBoxUnitsTimeRT->insertItem( tr( "msec" ) );
    comboBoxUnitsTimeRT->insertItem( trUtf8( "\xce\xbc\x73\x65\x63" ) );
    textLabel3_2_3->setText( tr( "Selector" ) );
    comboBoxUnitsSelector->clear();
    comboBoxUnitsSelector->insertItem( tr( "Number" ) );
    comboBoxUnitsSelector->insertItem( tr( "Hz" ) );
    comboBoxUnitsSelector->insertItem( tr( "RPM" ) );
    toolBoxCONFIG->setItemLabel( toolBoxCONFIG->indexOf(page1_2), tr( "Units" ) );
    buttonGroup2ndHeader->setTitle( QString::null );
    textLabel1_12_2_3_2_2->setText( tr( "File-Name-Pattern" ) );
    textLabel2_3_3_2_2->setText( tr( "# Lines in MAIN Header" ) );
    textLabel2_3_3_2_2_2->setText( tr( "# Lines in DATA Header" ) );
    textLabel2_3_3_2_2_2_2->setText( tr( "# Lines between FRAMES" ) );
    checkBoxYes2ndHeader->setTitle( tr( "Header File" ) );
    lineEditWildCard2ndHeader->setText( QString::null );
    checkBoxYes2ndHeader_2->setTitle( tr( "[Header+] Image File" ) );
    lineEditWildCard->setText( tr( "*_#_*.DAT" ) );
    checkBoxTiff->setText( tr( "Image :: TIFF, BMP ..." ) );
    checkBoxRemoveNonePrint->setText( tr( "Remove \"Non-Printable\" symbols from header(s)" ) );
    toolBoxCONFIG->setItemLabel( toolBoxCONFIG->indexOf(page2_2), tr( "File(s) :: Structure" ) );
    comboBoxHeaderFormat->clear();
    comboBoxHeaderFormat->insertItem( tr( "Free ASCII format [standart]" ) );
    comboBoxHeaderFormat->insertItem( tr( "XML format   [only header file]" ) );
    comboBoxHeaderFormat->insertItem( tr( "YAML format [only header file]" ) );
    buttonGroupXMLbase->setTitle( QString::null );
    textLabel1_11_3->setText( tr( "Xml-Base  ::" ) );
    buttonGroupFlexibleHeader->setTitle( QString::null );
    checkBoxHeaderFlexibility->setText( tr( "\"Flexible\" Header" ) );
    textLabel1_8->setText( tr( "| Last Line ::" ) );
    lineEditFlexiStop->setText( tr( "$" ) );
    tableHeaderPos->horizontalHeader()->setLabel( 0, tr( "#-Line" ) );
    tableHeaderPos->horizontalHeader()->setLabel( 1, tr( "#-Pos" ) );
    tableHeaderPos->verticalHeader()->setLabel( 0, tr( "[Experiment-Title]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 1, tr( "[User-Name]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 2, tr( "[Sample-Run-Number]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 3, tr( "[Sample-Title]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 4, tr( "[Sample-Thickness]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 5, tr( "[Sample-Position-Number]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 6, tr( "[Date]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 7, tr( "[Time]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 8, tr( "[C]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 9, tr( "[D]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 10, tr( "[D-TOF]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 11, tr( "[C,D-Offset]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 12, tr( "[CA-X]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 13, tr( "[CA-Y]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 14, tr( "[SA-X]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 15, tr( "[SA-Y]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 16, tr( "[Sum]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 17, tr( "[Selector]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 18, tr( "[Lambda]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 19, tr( "[Delta-Lambda]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 20, tr( "[Duration]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 21, tr( "[Duration-Factor]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 22, tr( "[Monitor-1]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 23, tr( "[Monitor-2]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 24, tr( "[Monitor-3|Tr|ROI]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 25, tr( "[Comment1]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 26, tr( "[Comment2]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 27, tr( "[Detector-X || Beamcenter-X]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 28, tr( "[Detector-Y || Beamcenter-Y]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 29, tr( "[Sample-Motor-1]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 30, tr( "[Sample-Motor-2]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 31, tr( "[Sample-Motor-3]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 32, tr( "[Sample-Motor-4]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 33, tr( "[Sample-Motor-5]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 34, tr( "[SA-Pos-X]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 35, tr( "[SA-Pos-Y]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 36, tr( "[Field-1]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 37, tr( "[Field-2]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 38, tr( "[Field-3]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 39, tr( "[Field-4]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 40, tr( "[RT-Number-Repetitions]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 41, tr( "[RT-Time-Factor]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 42, tr( "[RT-Current-Number]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 43, tr( "[Attenuator]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 44, tr( "[Polarization]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 45, tr( "[Lenses]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 46, tr( "[Slices-Count]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 47, tr( "[Slices-Duration]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 48, tr( "[Slices-Current-Number]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 49, tr( "[Slices-Current-Duration]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 50, tr( "[Slices-Current-Monitor1]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 51, tr( "[Slices-Current-Monitor2]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 52, tr( "[Slices-Current-Monitor3]" ) );
    tableHeaderPos->verticalHeader()->setLabel( 53, tr( "[Slices-Current-Sum]" ) );
    toolBoxCONFIG->setItemLabel( toolBoxCONFIG->indexOf(page), tr( "Header :: Map" ) );
    buttonGroupSel->setTitle( QString::null );
    radioButtonLambdaF->setText( trUtf8( "\xce\xbb\x3a" ) );
    lineEditSel1->setText( tr( "2096" ) );
    textLabel2_5_2->setText( tr( "/f  +" ) );
    lineEditSel2->setText( tr( "-4.66" ) );
    radioButtonLambdaHeader->setText( tr( "Read from Header" ) );
    toolBoxCONFIG->setItemLabel( toolBoxCONFIG->indexOf(page_2), tr( "Selector :: Wave Length" ) );
    buttonGroupDetectorImage->setTitle( QString::null );
    textLabel2_3_2_2->setText( QString::null );
    textLabel2_3_2->setText( QString::null );
    textLabel1_3_2_3->setText( tr( "Read :: Numbers-per-Line" ) );
    textLabel2_3->setText( tr( "Dimension" ) );
    textLabelResoPixelSize->setText( tr( "Pixel Width [cm]" ) );
    textLabelResoPixelSize_2_2->setText( tr( "Pixel Assymetry [h:w]" ) );
    textLabel1_3->setText( tr( "Set :: Range Of Interes" ) );
    textLabel1_3_2->setText( tr( "Set :: Binning" ) );
    textLabel3_3->setText( tr( "File" ) );
    QToolTip::add( spinBoxReadMatrixNumberPerLine, tr( "Number of Columns" ) );
    comboBoxMDdata->clear();
    comboBoxMDdata->insertItem( tr( "64" ) );
    comboBoxMDdata->insertItem( tr( "128" ) );
    comboBoxMDdata->insertItem( tr( "256" ) );
    comboBoxMDdata->insertItem( tr( "512" ) );
    comboBoxMDdata->insertItem( tr( "1024" ) );
    comboBoxMDdata->insertItem( tr( "2048" ) );
    comboBoxMDdata->setCurrentItem( 1 );
    lineEditResoPixelSize->setText( tr( "0.525" ) );
    lineEditAsymetry->setText( tr( "1.00" ) );
    comboBoxBinning->clear();
    comboBoxBinning->insertItem( tr( "1" ) );
    textLabel4_2->setText( tr( "Matrix" ) );
    checkBoxMatrixX2mX->setText( tr( "X -> -X" ) );
    checkBoxMatrixY2mY->setText( tr( "Y -> -Y" ) );
    checkBoxTranspose->setText( tr( "X <-> Y" ) );
    lineEditMD->setText( tr( "128" ) );
    lineEditPS->setText( tr( "0.525" ) );
    lineEditAsymetryMatrix->setText( tr( "1.00" ) );
    textLabel1_3_2_3_2->setText( tr( "TOF/RT Frames :: Read :: Numbers-per-Line" ) );
    QToolTip::add( spinBoxReadMatrixTofNumberPerLine, tr( "Number of Columns" ) );
    toolBoxCONFIG->setItemLabel( toolBoxCONFIG->indexOf(page_3), tr( "Detector :: Image" ) );
    groupBoxDeadTime->setTitle( QString::null );
    textLabelResoPixelSize_3->setText( tr( "Dead-Time [sec]" ) );
    radioButtonDeadTimeCh->setText( tr( "Non-Paralysable:" ) );
    QWhatsThis::add( radioButtonDeadTimeCh, tr( "Non Paralysable" ) );
    radioButtonDeadTimeDet->setText( tr( "Paralysable:" ) );
    lineEditDeadTime->setText( tr( "6.5e-7" ) );
    QToolTip::add( lineEditDeadTime, tr( "Dead time of Detector" ) );
    textLabel1_6->setText( trUtf8( "\x4e\x20\x3d\x20\x6e\x20\x65\x78\x70\x5b\x2d\x6e\xcf\x84\x5d" ) );
    textLabel2_2->setText( trUtf8( "\x4e\x20\x3d\x20\x6e\x2f\x5b\x31\x2b\x6e\xcf\x84\x5d" ) );
    comboBoxDTtype->clear();
    comboBoxDTtype->insertItem( tr( "Detector" ) );
    comboBoxDTtype->insertItem( tr( "1x PhotoM" ) );
    comboBoxDTtype->insertItem( tr( "9x PhotoM" ) );
    toolBoxCONFIG->setItemLabel( toolBoxCONFIG->indexOf(page_4), tr( "Detector :: Dead-Time" ) );
    buttonGroupDet->setTitle( QString::null );
    radioButtonCenterHF->setText( tr( "Moment-minimalization (H.F.)" ) );
    radioButtonRadStdSymm->setText( tr( "X and Y symmetrization" ) );
    radioButtonCenterReadFromHeader->setText( tr( "Read from Header" ) );
    toolBoxCONFIG->setItemLabel( toolBoxCONFIG->indexOf(page_5), tr( "Detector :: Center" ) );
    groupBoxAU->setTitle( QString::null );
    comboBoxACmethod->clear();
    comboBoxACmethod->insertItem( tr( "Flat Scatter [FS]" ) );
    comboBoxACmethod->insertItem( tr( "Direct Beam [DB]" ) );
    comboBoxACmethod->insertItem( tr( "Flat Scatter + Transmission[FS+Tr]" ) );
    comboBoxACmethod->insertItem( tr( "Counts per Channel" ) );
    groupBoxFlatScatter->setTitle( tr( "Properties" ) );
    comboBoxCalibrant->clear();
    comboBoxCalibrant->insertItem( tr( "Plexi-1.5mm[KWS-1&2]" ) );
    comboBoxCalibrant->insertItem( tr( "Direct-Beam[KWS-3]" ) );
    comboBoxCalibrant->insertItem( tr( "H2O[SANS-1]" ) );
    comboBoxCalibrant->insertItem( tr( "Plexi-1.5mm-[Current]" ) );
    comboBoxCalibrant->insertItem( tr( "DirectBeam-No-Attenuator" ) );
    pushButtonsaveCurrentCalibrant->setText( QString::null );
    pushButtonDeleteCurrentCalibrator->setText( QString::null );
    textLabel1_7->setText( trUtf8( "\xce\xbc\x28\xce\xbb\x29\x3d\xce\xbc\x3c\x73\x75\x62\x3e\x6f\x3c\x2f\x73\x75\x62\x3e\x2b\xce\xbc\x3c\x73\x75\x62\x3e\x41\x3c\x2f\x73\x75\x62\x3e\x65\x78\x70\x28\xce\xbb\x3c\x73\x75\x62\x3e\xce\xbc\x3c\x2f\x73\x75\x62\x3e\x2f\xce\xbb\x3c\x2f\x66\x6f\x6e\x74\x3e\x29\x20\x3a\x3a\x20\xce\xbc\x2d\x46\x61\x63\x74\x6f\x72" ) );
    textLabel1_7_2->setText( trUtf8( "\xce\xbc\x3c\x73\x75\x62\x3e\x6f\x3c\x2f\x73\x75\x62\x3e" ) );
    lineEditMuY0->setText( tr( "5.5998E-02" ) );
    textLabel1_7_3->setText( trUtf8( "\xce\xbc\x3c\x73\x75\x62\x3e\x41\x3c\x2f\x73\x75\x62\x3e" ) );
    lineEditMuA->setText( tr( "1.211E-02" ) );
    textLabel1_7_4->setText( trUtf8( "\xce\xbb\x3c\x73\x75\x62\x3e\xce\xbc\x3c\x2f\x73\x75\x62\x3e" ) );
    lineEditMut->setText( tr( "-6.7721E+00" ) );
    checkBoxTransmissionPlexi->setText( tr( "Calculate Transmission by Equation:" ) );
    QToolTip::add( checkBoxTransmissionPlexi, tr( "if it is checked transmission of Calibrant is fixed" ) );
    QWhatsThis::add( checkBoxTransmissionPlexi, tr( "if it is checked transmission of Calibrant is fixed" ) );
    textLabel1_7_5->setText( trUtf8( "\x54\x28\xce\xbb\x29\x3d\x54\x3c\x73\x75\x62\x3e\x6f\x3c\x2f\x73\x75\x62\x3e\x2d\x54\x3c\x73\x75\x62\x3e\x41\x3c\x2f\x73\x75\x62\x3e\x65\x78\x70\x28\x2d\x20\xce\xbb\x3c\x73\x75\x62\x3e\x54\x3c\x2f\x73\x75\x62\x3e\x2f\xce\xbb\x3c\x2f\x66\x6f\x6e\x74\x3e\x29\x20\x3a\x3a\x20\x54\x72\x61\x6e\x73\x6d\x69\x73\x73\x69\x6f\x6e" ) );
    textLabel1_7_4_3->setText( tr( "T<sub>o</sub>" ) );
    lineEditTo->setText( tr( "4.993E-01" ) );
    textLabel1_7_4_3_2->setText( tr( "T<sub>A</sub>" ) );
    lineEditTA->setText( tr( "-4.283E-01" ) );
    textLabel1_7_4_2->setText( trUtf8( "\xce\xbb\x3c\x73\x75\x62\x3e\x54\x3c\x2f\x73\x75\x62\x3e" ) );
    lineEditLate->setText( tr( "-8.246E+00" ) );
    checkBoxACDBuseActive->setText( tr( "Direct Beam:: Use Current Mask and Sensitivity Matrixes" ) );
    toolBoxCONFIG->setItemLabel( toolBoxCONFIG->indexOf(page_6), tr( "Absolute Calibration Standard" ) );
    buttonGroupTrMethod->setTitle( QString::null );
    comboBoxTransmMethod->clear();
    comboBoxTransmMethod->insertItem( tr( "Monitor-3 [dead-time -]" ) );
    comboBoxTransmMethod->insertItem( tr( "Direct Beam  [dead-time +]" ) );
    comboBoxTransmMethod->insertItem( tr( "Tr in Header  [dead-time -]" ) );
    comboBoxTransmMethod->insertItem( tr( "ROI in Header  [dead-time +]" ) );
    buttonGroup37->setTitle( QString::null );
    textLabel1_5->setText( tr( "Dead-Time in \"Direct-Beam-Mode\" [sec]" ) );
    lineEditDBdeadtime->setText( tr( "6.5e-7" ) );
    toolBoxCONFIG->setItemLabel( toolBoxCONFIG->indexOf(page_7), tr( "Transmission :: Method" ) );
    buttonGroupResolusion->setTitle( QString::null );
    checkBoxResoFocus->setText( tr( "Resolusion :: Focusing Geometry (Lenses, Mirror)" ) );
    checkBoxResoCAround->setText( tr( "Resolusion :: Entrance Aperture [CA] :: Round (Diameter)" ) );
    checkBoxResoSAround->setText( tr( "Resolusion :: Sample Aperture [SA] :: Round (Diameter)" ) );
    textLabel2_4->setText( tr( "Resolusion :: Detector Space Resolusion" ) );
    lineEditDetReso->setText( tr( "0.0" ) );
    QToolTip::add( lineEditDetReso, tr( "... Flat Scatter ..." ) );
    toolBoxCONFIG->setItemLabel( toolBoxCONFIG->indexOf(page_8), tr( "Resolusion :: Options" ) );
    toolBox7->setItemLabel( toolBox7->indexOf(page2), tr( "SA(N)S Instrument :: Configuration" ) );
    lineEditMD_2_2_2->setText( QString::null );
    lineEditMD_2_3->setText( QString::null );
    comboBoxMatrixConvolusion->clear();
    comboBoxMatrixConvolusion->insertItem( tr( "1   [no convolusion] " ) );
    comboBoxMatrixConvolusion->insertItem( tr( "5   [ neubours ]" ) );
    comboBoxMatrixConvolusion->insertItem( tr( "9   [3x3]" ) );
    comboBoxMatrixConvolusion->insertItem( tr( "25 [5x5]" ) );
    comboBoxMatrixConvolusion->setCurrentItem( 0 );
    toolBoxDP2D->setItemLabel( toolBoxDP2D->indexOf(page1_3), tr( "I[x,y] :: Matrix Convolusion" ) );
    checkBoxParallax->setText( tr( "Parallax ::" ) );
    QToolTip::add( checkBoxParallax, tr( "Switch on/off Wide-Angle-Corrections" ) );
    QWhatsThis::add( checkBoxParallax, tr( "Switch on/off Wide-Angle-Corrections" ) );
    comboBoxParallax->clear();
    comboBoxParallax->insertItem( trUtf8( "\x63\x6f\x73\xc2\xb3\x28\xce\x98\x29\x20\x20\x5b\x4c\x69\x5d" ) );
    comboBoxParallax->insertItem( trUtf8( "\x63\x6f\x73\x28\xce\xb1\x29\xe2\x8b\x85\x63\x6f\x73\xc2\xb2\x28\xce\x98\x29\x20\x5b\x48\x65\x2d\x74\x75\x62\x65\x73\x5d" ) );
    checkBoxParallaxTr->setText( trUtf8( "\x54\x72\x61\x6e\x73\x6d\x69\x73\x73\x69\x6f\x6e\x20\x3a\x3a\x20\x54\x72\x20\x3d\x20\x66\x20\x28\x20\x63\x6f\x73\x20\xce\x98\x20\x29" ) );
    QToolTip::add( checkBoxParallaxTr, tr( "Switch on/off Wide-Angle-Corrections" ) );
    QWhatsThis::add( checkBoxParallaxTr, tr( "Switch on/off Wide-Angle-Corrections" ) );
    toolBoxDP2D->setItemLabel( toolBoxDP2D->indexOf(page2_3), tr( "I[x,y] :: Wide Angle Corrections" ) );
    comboBoxNorm->clear();
    comboBoxNorm->insertItem( tr( "Monitor2" ) );
    comboBoxNorm->insertItem( tr( "Time" ) );
    comboBoxNorm->insertItem( tr( "Monitor1" ) );
    spinBoxNorm->setSpecialValueText( tr( "1" ) );
    checkBoxBCTimeNormalization->setText( tr( "Subtract #BC with TIME normalization" ) );
    toolBoxDP2D->setItemLabel( toolBoxDP2D->indexOf(page_10), tr( "I[x,y] :: Data Normalization" ) );
    comboBoxIxyFormat->clear();
    comboBoxIxyFormat->insertItem( tr( "I[x,y] >> Matrix" ) );
    comboBoxIxyFormat->insertItem( tr( "I[x,y] >> Table :: x-y-I[x,y]-dI" ) );
    comboBoxIxyFormat->insertItem( tr( "I[x,y] >> Table :: Qx-Qy-I[x,y]-dI" ) );
    comboBoxIxyFormat->insertItem( trUtf8( "\x49\x5b\x78\x2c\x79\x5d\x20\x3e\x3e\x20\x50\x6f\x6c\x61\x72\x20\x3a\x3a\x20\x51\x2d\xcf\x86\x2d\x49\x5b\x78\x2c\x79\x5d\x2d\x64\x49" ) );
    comboBoxIxyFormat->setCurrentItem( 0 );
    checkBoxASCIIheaderIxy->setText( tr( "+header" ) );
    checkBoxASCIIignoreMask->setText( tr( "ignore mask" ) );
    toolBoxDP2D->setItemLabel( toolBoxDP2D->indexOf(page_11), tr( "I[x,y] :: Output format of ASCII-files" ) );
    buttonGroup8_2->setTitle( QString::null );
    radioButtonXYdimPixel->setText( tr( "[1] Pixel number" ) );
    radioButtonXYdimQ->setText( trUtf8( "\x5b\x31\x2f\xc3\x85\x5d\x20\x51\x2d\x75\x6e\x69\x74\x73" ) );
    toolBoxDP2D->setItemLabel( toolBoxDP2D->indexOf(page_12), tr( "[x,y] :: Dimension" ) );
    checkBoxMaskNegative->setText( tr( "Mask Negative Pixels" ) );
    toolBoxDP2D->setItemLabel( toolBoxDP2D->indexOf(page_13), tr( "I[x,y] :: Negative Points" ) );
    QToolTip::add( spinBoxPolar, trUtf8( "\xcf\x86\x2d\x72\x65\x73\x6f\x6c\x75\x73\x69\x6f\x6e\x20\x28\x6e\x75\x6d\x62\x65\x72\x20\x70\x6f\x69\x6e\x74\x73\x29" ) );
    QWhatsThis::add( spinBoxPolar, trUtf8( "\xcf\x86\x2d\x72\x65\x73\x6f\x6c\x75\x73\x69\x6f\x6e\x20\x28\x6e\x75\x6d\x62\x65\x72\x20\x70\x6f\x69\x6e\x74\x73\x29" ) );
    textLabelMaskLeft_2_3->setText( trUtf8( "\xcf\x86\x2d\x72\x65\x73\x6f\x6c\x75\x73\x69\x6f\x6e\x20\x28\x6e\x75\x6d\x62\x65\x72\x20\x70\x6f\x69\x6e\x74\x73\x29" ) );
    spinBoxPolarShift->setSuffix( trUtf8( "\xc2\xb0" ) );
    QToolTip::add( spinBoxPolarShift, trUtf8( "\xcf\x86\x2d\x73\x68\x69\x66\x74" ) );
    QWhatsThis::add( spinBoxPolarShift, trUtf8( "\xcf\x86\x2d\x73\x68\x69\x66\x74" ) );
    textLabelMaskLeft_2_3_2->setText( trUtf8( "\xcf\x86\x2d\x73\x68\x69\x66\x74" ) );
    checkBoxSkipPolar->setText( tr( "Skip: 1st column (angle); and 1st row (Q)" ) );
    toolBoxDP2D->setItemLabel( toolBoxDP2D->indexOf(page_14), trUtf8( "\x49\x5b\x51\x2c\xcf\x86\x5d\x20\x3a\x3a\x20\x41\x6e\x67\x75\x6c\x61\x72\x20\x52\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e" ) );
    toolBox7->setItemLabel( toolBox7->indexOf(page_9), tr( "Data Processing :: [2D] :: Options" ) );
    lineEditMD_2_2_3->setText( QString::null );
    lineEditMD_2_3_2->setText( QString::null );
    buttonGroup37_2->setTitle( QString::null );
    radioButtonRadStd->setText( tr( "Standart (Shells)" ) );
    radioButtonRadHF->setText( tr( "4-Pixel Interpolation (H.F.)" ) );
    lineEditCommonRatio->setText( tr( "1.0" ) );
    QWhatsThis::add( lineEditCommonRatio, tr( "Progressive Step" ) );
    toolBoxDP1D->setItemLabel( toolBoxDP1D->indexOf(page1_4), tr( "I[Q] :: Radial Averaging :: Method" ) );
    comboBox4thCol->clear();
    comboBox4thCol->insertItem( trUtf8( "\x51\x2d\x49\x2d\x64\x49\x2d\xcf\x83" ) );
    comboBox4thCol->insertItem( tr( "Q-I-dI-dQ" ) );
    comboBox4thCol->insertItem( tr( "Q-I-dI" ) );
    comboBox4thCol->insertItem( tr( "Q-I-dI-dQ-Sigma" ) );
    checkBoxASCIIheader->setText( tr( "+header" ) );
    toolBoxDP1D->setItemLabel( toolBoxDP1D->indexOf(page2_4), tr( "I[Q] :: Output Format" ) );
    comboBoxSelectPresentation->clear();
    comboBoxSelectPresentation->insertItem( tr( "QI" ) );
    comboBoxSelectPresentation->insertItem( tr( "Guinier" ) );
    comboBoxSelectPresentation->insertItem( tr( "Zimm" ) );
    comboBoxSelectPresentation->insertItem( tr( "Porod" ) );
    comboBoxSelectPresentation->insertItem( tr( "Porod2" ) );
    comboBoxSelectPresentation->insertItem( tr( "logQ" ) );
    comboBoxSelectPresentation->insertItem( tr( "logI" ) );
    comboBoxSelectPresentation->insertItem( tr( "Debye" ) );
    comboBoxSelectPresentation->insertItem( tr( "1Moment" ) );
    comboBoxSelectPresentation->insertItem( tr( "2Moment" ) );
    comboBoxSelectPresentation->insertItem( tr( "GuinierRod" ) );
    comboBoxSelectPresentation->insertItem( tr( "GuinierPlate" ) );
    comboBoxSelectPresentation->insertItem( tr( "Kratky" ) );
    comboBoxSelectPresentation->setCurrentItem( 0 );
    textLabelPres->setText( tr( "I vs. Q" ) );
    toolBoxDP1D->setItemLabel( toolBoxDP1D->indexOf(page_16), tr( "I[Q] :: SAS Presentation" ) );
    spinBoxRemoveFirst->setPrefix( tr( "First: " ) );
    spinBoxRemoveFirst->setSuffix( tr( "  points" ) );
    spinBoxRemoveLast->setPrefix( tr( "Last: " ) );
    spinBoxRemoveLast->setSuffix( tr( "  points" ) );
    checkBoxMaskNegativeQ->setText( tr( "Negative Points" ) );
    toolBoxDP1D->setItemLabel( toolBoxDP1D->indexOf(page_17), tr( "I[Q] :: Remove Points" ) );
    spinBoxFrom->setPrefix( tr( "from: " ) );
    spinBoxFrom->setSuffix( QString::null );
    QToolTip::add( spinBoxFrom, tr( "define range: FROM" ) );
    QWhatsThis::add( spinBoxFrom, tr( "define range: FROM" ) );
    spinBoxTo->setPrefix( tr( "to: " ) );
    QToolTip::add( spinBoxTo, tr( "define range: TO" ) );
    QWhatsThis::add( spinBoxTo, tr( "define range: TO" ) );
    toolBoxDP1D->setItemLabel( toolBoxDP1D->indexOf(page_18), tr( "I[Qx], I[Qy] :: Slices :: Range" ) );
    spinBoxMCshiftAngle->setPrefix( tr( "Angle: " ) );
    spinBoxMCshiftAngle->setSuffix( QString::null );
    QToolTip::add( spinBoxMCshiftAngle, tr( "define range: FROM" ) );
    QWhatsThis::add( spinBoxMCshiftAngle, tr( "define range: FROM" ) );
    spinBoxMCcheckQ->setPrefix( tr( "Check Q #: " ) );
    spinBoxMCcheckQ->setSuffix( QString::null );
    QToolTip::add( spinBoxMCcheckQ, tr( "define range: FROM" ) );
    QWhatsThis::add( spinBoxMCcheckQ, tr( "define range: FROM" ) );
    toolBoxDP1D->setItemLabel( toolBoxDP1D->indexOf(page_19), tr( "I[Q] (MC) + I[Q] (NC) :: Magnetic Samples (MS-Mode)" ) );
    toolBox7->setItemLabel( toolBox7->indexOf(page_15), tr( "Data Processing :: [1D] :: Options" ) );
    lineEditMD_2_2_3_2->setText( QString::null );
    lineEditMD_2_3_3->setText( QString::null );
    groupBox16->setTitle( QString::null );
    checkBoxRecalculateUseNumber->setText( tr( "Condition :: Use \"Sample Position Number\" as a condition" ) );
    QToolTip::add( checkBoxRecalculateUseNumber, tr( "In case of Many-Empty-Cells, like sample rotation in beam, <br>we could automatically distinguish one position from other by checking this box..." ) );
    QWhatsThis::add( checkBoxRecalculateUseNumber, tr( "In case of Many-Empty-Cells, like sample rotation in beam, <br>we could automatically distinguish one position from other by checking this box..." ) );
    checkBoxAttenuatorAsPara->setText( tr( "Condition :: Use \"Attenuator\" as a condition" ) );
    checkBoxBeamcenterAsPara->setText( tr( "Condition :: Use \"Beam-Center/Detector-position\" as a condition" ) );
    checkBoxPolarizationAsPara->setText( tr( "Condition :: Use \"Polarization\" as a condition" ) );
    checkBoxRecalculate->setText( tr( "Script :: Reread old files [When added to script new runs]" ) );
    checkBoxFindCenter->setText( tr( "Script :: Find center for every file [during adding to script table]" ) );
    checkBoxForceCopyPaste->setText( tr( "Script :: Transmission :: Force copy-paste" ) );
    checkBoxNameAsTableName->setText( tr( "Processing :: Use sample info as RUN number in output names" ) );
    checkBoxMergingTable->setText( tr( "Processing :: Automatical generation of merging template [I(Q) case]" ) );
    checkBoxRewriteOutput->setText( tr( "Processing :: Rewrite output [No index]" ) );
    checkBoxSkiptransmisionConfigurations->setText( tr( "Processing :: Skip transmission configurations" ) );
    checkBoxSortOutputToFolders->setText( tr( "Processing :: Sort output widgets to corresponding folders" ) );
    toolBox7->setItemLabel( toolBox7->indexOf(page_20), tr( "Data Processing :: Script Table :: Options" ) );
    pushButtonEasyDAN->setText( tr( "Easy \n"
"DAN" ) );
    pushButtonEasyDAN->setTextLabel( QString::null );
    QToolTip::add( pushButtonEasyDAN, tr( "Processing of data in Script Tabe: Radial Avereging" ) );
    QWhatsThis::add( pushButtonEasyDAN, tr( "Processing of data in Script Tabe: Radial Avereging" ) );
    spinBoxEDfiltrationTIME->setPrefix( QString::null );
    spinBoxEDfiltrationTIME->setSuffix( tr( " seconds" ) );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_4->setText( tr( ":: SKIP       :: runs with shorter DURATION" ) );
    spinBoxEDfiltrationSUM->setPrefix( QString::null );
    spinBoxEDfiltrationSUM->setSuffix( tr( " counts" ) );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_4_2->setText( tr( ":: SKIP       ::  runs with smaller SUM" ) );
    lineEditEDwildcardFILEACCEPT->setText( tr( "*" ) );
    textLabelMaskLeft_2_3_2_2_2_2_3_2->setText( tr( ":: ACCEPT :: wildcard for FILE names" ) );
    lineEditEDwildcardFILESKIP->setText( QString::null );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_2->setText( tr( ":: SKIP       :: wildcard for FILE names" ) );
    lineEditEDwildcardSAMPLEACCEPT->setText( tr( "*" ) );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_3->setText( tr( ":: ACCEPT :: wildcard for SAMPLE names" ) );
    lineEditEDwildcardSAMPLESKIP->setText( QString::null );
    textLabelMaskLeft_2_3_2_2_2_2_3_2_2_2->setText( tr( ":: SKIP       :: wildcard for SAMPLE names" ) );
    toolBox7_2->setItemLabel( toolBox7_2->indexOf(page1_5), tr( "ED :: data filtration" ) );
    checkBoxEDmaskMASK->setText( tr( "\"mask\" :: generate default mask" ) );
    checkBoxEDmaskMASKTR->setText( tr( "\"maskTR\" :: generate mask for transmission" ) );
    checkBoxEDmaskMASKTR_2->setText( tr( "\"maskBS\" :: generate mask for radial averaging" ) );
    toolBox7_2->setItemLabel( toolBox7_2->indexOf(page2_5), tr( "ED :: Mask" ) );
    lineEditACFSwildcard_2->setText( tr( "plexi" ) );
    textLabelMaskLeft_2_3_2_2_2_2_3->setText( tr( "# Plexiglass [ H2O, ... ] wildcard" ) );
    lineEditACEBwildcard_3->setText( tr( "eb" ) );
    textLabelMaskLeft_2_3_2_2_2_2_2_3->setText( tr( "# EB [ EC ] wildcard" ) );
    lineEditACEBwildcard_2_3->setText( tr( "b4c" ) );
    textLabelMaskLeft_2_3_2_2_2_2_2_2_3->setText( tr( "# B4C [ Cd ] wildcard" ) );
    comboBox35->clear();
    comboBox35->insertItem( tr( "\"sens\" :: single sensitivity :: D4m" ) );
    comboBox35->insertItem( tr( "\"sens\" :: single sensitivity :: D2m" ) );
    comboBox35->insertItem( tr( "\"sens\" :: single sensitivity :: D1m" ) );
    comboBox35->insertItem( tr( "\"sens4m\", \"sens2m\", \"sens1m\" individual sensitivities" ) );
    toolBox7_2->setItemLabel( toolBox7_2->indexOf(page_22), tr( "ED :: Sensitivity" ) );
    lineEditECwildcard->setText( tr( "ec" ) );
    textLabelMaskLeft_2_3_2_2->setText( tr( "#-EC [EB] wildcard" ) );
    lineEditB4Cwildcard->setText( tr( "b4c" ) );
    textLabelMaskLeft_2_3_2_2_2->setText( tr( "#-BC wildcard" ) );
    lineEditACFSwildcard->setText( tr( "plexi" ) );
    textLabelMaskLeft_2_3_2_2_2_2->setText( tr( "Abs.Cal. [#-FS] wildcard" ) );
    lineEditACEBwildcard->setText( tr( "eb" ) );
    textLabelMaskLeft_2_3_2_2_2_2_2->setText( tr( "Abs.Cal. [#-EB] wildcard" ) );
    lineEditACEBwildcard_2->setText( tr( "b4c" ) );
    textLabelMaskLeft_2_3_2_2_2_2_2_2->setText( tr( "Abs.Cal. [#-BC] wildcard" ) );
    lineEditACEBwildcard_2_2->setText( tr( "corund" ) );
    textLabelMaskLeft_2_3_2_2_2_2_2_2_2->setText( tr( "#-\"Center\" wildcard" ) );
    toolBox7_2->setItemLabel( toolBox7_2->indexOf(page_23), tr( "ED :: Data Processing" ) );
    toolBox7->setItemLabel( toolBox7->indexOf(page_21), tr( "Easy DAN :: future project :: @data reduction by single click@" ) );
    sansTab->changeTab( TabPage, tr( "Options" ) );
    QToolTip::add( toolBoxAdv, QString::null );
    QWhatsThis::add( toolBoxAdv, QString::null );
    frameExtractHeaderInfo->setTitle( tr( ":: Header(s) - 2 - Info-Table ::" ) );
    QToolTip::add( comboBoxInfoTable, tr( "Active info-table" ) );
    QWhatsThis::add( comboBoxInfoTable, tr( "Active info-table" ) );
    pushButtonNewInfoTable->setText( QString::null );
    pushButtonNewInfoTable->setTextLabel( tr( "New" ) );
    QToolTip::add( pushButtonNewInfoTable, tr( "Create new info-table" ) );
    QWhatsThis::add( pushButtonNewInfoTable, tr( "Create new info-table" ) );
    pushButtonMakeList->setText( QString::null );
    pushButtonMakeList->setTextLabel( tr( "Add" ) );
    QToolTip::add( pushButtonMakeList, tr( "Add files to active info-table" ) );
    QWhatsThis::add( pushButtonMakeList, tr( "Add files to active info-table" ) );
    checkBoxDatYesNo->setText( tr( "Load also Matrixes" ) );
    checkBoxSumVsMask->setText( tr( "Detector Sum for active Mask" ) );
    checkBoxShortList->setText( tr( "Short list of parameters" ) );
    groupBoxHeaderFunc_2->setTitle( tr( ":: Add :: Several Files ::" ) );
    pushButtonAddUni->setText( tr( "Add :: by selection" ) );
    pushButtonGenerateAddingTable->setText( tr( "Add ::  generate table" ) );
    pushButtonAddUniInTable->setText( tr( "Add ::  read from table" ) );
    frameExtractMatrixes->setTitle( tr( ":: Image(s) - 2 - Info-Matrix ::" ) );
    QToolTip::add( comboBoxInfoMatrix, tr( "Active info-matrix" ) );
    QWhatsThis::add( comboBoxInfoMatrix, tr( "Active info-matrix" ) );
    pushButtonNewInfoMatrix->setText( QString::null );
    pushButtonNewInfoMatrix->setTextLabel( tr( "New" ) );
    QToolTip::add( pushButtonNewInfoMatrix, tr( "Create new info-matrix" ) );
    QWhatsThis::add( pushButtonNewInfoMatrix, tr( "Create new info-matrix" ) );
    pushButtonMakeBigMatrix->setText( QString::null );
    pushButtonMakeBigMatrix->setTextLabel( tr( "Add" ) );
    QToolTip::add( pushButtonMakeBigMatrix, tr( "Add files to active info-matrix [Filling in graph: left-to-right, bottom-to-top]" ) );
    QWhatsThis::add( pushButtonMakeBigMatrix, tr( "Add files to active info-matrix [Filling in graph: left-to-right, bottom-to-top]" ) );
    spinBoxBigMatrixCols->setPrefix( tr( "N - rows x  " ) );
    spinBoxBigMatrixCols->setSuffix( tr( " - columns" ) );
    QWhatsThis::add( spinBoxBigMatrixCols, tr( "Matrix of Matrixes Dimention", "Matrix of Matrixes Dimention" ) );
    textLabel1_2_2->setText( tr( "<<" ) );
    checkBoxBigMatrixASCII->setText( tr( "ascii" ) );
    QToolTip::add( checkBoxBigMatrixASCII, tr( "to look to ASCII output instead of rawdata" ) );
    QWhatsThis::add( checkBoxBigMatrixASCII, tr( "to look to ASCII output instead of rawdata" ) );
    checkBoxBigMatrixNorm->setText( tr( "Norm..." ) );
    QToolTip::add( checkBoxBigMatrixNorm, tr( "Apply Normalization" ) );
    QWhatsThis::add( checkBoxBigMatrixNorm, tr( "Apply Normalization" ) );
    checkBoxBigMatrixMask->setText( tr( "Mask..." ) );
    QToolTip::add( checkBoxBigMatrixMask, tr( "Apply Active Mask" ) );
    QWhatsThis::add( checkBoxBigMatrixMask, tr( "Apply Active Mask" ) );
    checkBoxBigMatrixSens->setText( tr( "Sens..." ) );
    QToolTip::add( checkBoxBigMatrixSens, tr( "Apply Active Sensitivity" ) );
    QWhatsThis::add( checkBoxBigMatrixSens, tr( "Apply Active Sensitivity" ) );
    checkBoxBigMatrixROI->setText( tr( "ROI..." ) );
    QToolTip::add( checkBoxBigMatrixROI, tr( "Extract only Range Of Interes (Mask>>Edge)" ) );
    QWhatsThis::add( checkBoxBigMatrixROI, tr( "Extract only Range Of Interes (Mask>>Edge)" ) );
    groupBoxHeaderFunc->setTitle( tr( ":: Fast Info Extractor :: " ) );
    pushButtonHeader->setText( QString::null );
    comboBoxCheck->clear();
    comboBoxCheck->insertItem( tr( "View I(Q)" ) );
    comboBoxCheck->insertItem( tr( "View I(Q) [in raw-QI  table]" ) );
    comboBoxCheck->insertItem( tr( "View Matrix" ) );
    comboBoxCheck->insertItem( tr( "View Matrix [Matrix-Active]" ) );
    comboBoxCheck->insertItem( tr( "Plot Matrix [Plot-Active]" ) );
    comboBoxCheck->insertItem( tr( "View Header" ) );
    comboBoxCheck->insertItem( tr( "Monitor-1" ) );
    comboBoxCheck->insertItem( tr( "Monitor-2" ) );
    comboBoxCheck->insertItem( tr( "Monitor-3" ) );
    comboBoxCheck->insertItem( tr( "Monitor-1 [cps]" ) );
    comboBoxCheck->insertItem( tr( "Monitor-2 [cps]" ) );
    comboBoxCheck->insertItem( tr( "Monitor-3 [cps]" ) );
    comboBoxCheck->insertItem( tr( "Duration[sec]" ) );
    comboBoxCheck->insertItem( tr( "Integral [cps]" ) );
    comboBoxCheck->insertItem( tr( "Integral-vs-Mask[cps]" ) );
    comboBoxCheck->insertItem( tr( "Dead-Time-Factor [1]" ) );
    comboBoxCheck->insertItem( tr( "C [cm]" ) );
    comboBoxCheck->insertItem( tr( "D [cm]" ) );
    comboBoxCheck->insertItem( tr( "f [Hz]" ) );
    comboBoxCheck->insertItem( tr( "Lambda" ) );
    comboBoxCheck->insertItem( tr( "R1 [cm]" ) );
    comboBoxCheck->insertItem( tr( "R2 [cm]" ) );
    comboBoxCheck->insertItem( tr( "Thickness [cm]" ) );
    comboBoxCheck->insertItem( tr( "SA" ) );
    comboBoxCheck->insertItem( tr( "CA" ) );
    comboBoxCheck->insertItem( tr( "[Info]" ) );
    comboBoxCheck->insertItem( tr( "RT-normalization" ) );
    comboBoxCheck->insertItem( tr( "Q2-vs-Mask" ) );
    comboBoxCheck->setCurrentItem( 4 );
    textLabel1_2->setText( tr( "<<" ) );
    checkBoxExtratorASCII->setText( tr( "ascii" ) );
    QToolTip::add( checkBoxExtratorASCII, tr( "to look to ASCII output instead of rawdata" ) );
    QWhatsThis::add( checkBoxExtratorASCII, tr( "to look to ASCII output instead of rawdata" ) );
    groupBoxHeaderFunc_2_2->setTitle( tr( ":: Extract :: Raw-matrixes :: INPUT to OUTPUT/raw-matrix folder" ) );
    pushButtonExtractData->setText( tr( "Extract" ) );
    QToolTip::add( pushButtonExtractData, tr( "if you want to extract pure  detector images as ASCII files, than push this button and select files. Output files will be saved in OUTPUT folder, in raw/matrix subfolder." ) );
    QWhatsThis::add( pushButtonExtractData, tr( "if you want to extract pure  detector images as ASCII files, than push this button and select files. Output files will be saved in OUTPUT folder, in raw/matrix subfolder." ) );
    toolBoxAdv->setItemLabel( toolBoxAdv->indexOf(page4), tr( "Rawdata Tools" ) );
    pushButtonRTsum->setText( tr( "RT :: Sum vs Number :: Read" ) );
    QToolTip::add( pushButtonRTsum, tr( "[sum-rt-]" ) );
    QWhatsThis::add( pushButtonRTsum, tr( "[sum-rt-]" ) );
    pushButtonAddManyDat->setText( tr( "RT :: Add :: by Selection" ) );
    QToolTip::add( pushButtonAddManyDat, tr( "rt0_..._added_N.DAT" ) );
    QWhatsThis::add( pushButtonAddManyDat, tr( "rt0_..._added_N.DAT" ) );
    groupBoxTofEstimation_2_2->setTitle( tr( "RT :: Tools" ) );
    QToolTip::add( lCDNumberTof4_2_3, tr( "rt1" ) );
    QWhatsThis::add( lCDNumberTof4_2_3, tr( "rt1" ) );
    pushButtonAddRTtable->setText( QString::null );
    pushButtonAddRTtable->setTextLabel( tr( "RT :: Add Files :: Active Table" ) );
    QToolTip::add( pushButtonAddRTtable, tr( "rt1_..._linear_N.DAT " ) );
    QWhatsThis::add( pushButtonAddRTtable, tr( "rt1_..._linear_N.DAT " ) );
    checkBoxAddRTtable->setText( tr( "Add first?" ) );
    QToolTip::add( checkBoxAddRTtable, tr( "Add files first?" ) );
    QWhatsThis::add( checkBoxAddRTtable, tr( "Add files first?" ) );
    QToolTip::add( lCDNumberTof4_2, tr( "rt1" ) );
    QWhatsThis::add( lCDNumberTof4_2, tr( "rt1" ) );
    pushButtonRTMergeLinear->setText( QString::null );
    pushButtonRTMergeLinear->setTextLabel( tr( "RT :: Merge Frames :: Linear" ) );
    QToolTip::add( pushButtonRTMergeLinear, tr( "rt1_..._linear_N.DAT " ) );
    QWhatsThis::add( pushButtonRTMergeLinear, tr( "rt1_..._linear_N.DAT " ) );
    QToolTip::add( spinBoxMergeRT, tr( "Number of merging frames" ) );
    QWhatsThis::add( spinBoxMergeRT, tr( "Number of merging frames" ) );
    QToolTip::add( lCDNumberTof4_2_2, tr( "rt2" ) );
    QWhatsThis::add( lCDNumberTof4_2_2, tr( "rt2" ) );
    pushButtonRTMergeProgressive->setText( QString::null );
    pushButtonRTMergeProgressive->setTextLabel( tr( "RT :: Merge Frames :: Progressive" ) );
    QToolTip::add( pushButtonRTMergeProgressive, tr( "rt1_..._linear_N.DAT " ) );
    QWhatsThis::add( pushButtonRTMergeProgressive, tr( "rt1_..._linear_N.DAT " ) );
    lineEditSplitFramesProgr->setPrefix( tr( "1.00" ) );
    lineEditSplitFramesProgr->setSuffix( QString::null );
    QToolTip::add( lineEditSplitFramesProgr, tr( "Ration of Geometrical Progration" ) );
    QWhatsThis::add( lineEditSplitFramesProgr, tr( "Ration of Geometrical Progration" ) );
    QToolTip::add( lCDNumberTof5_3, tr( "rt3" ) );
    QWhatsThis::add( lCDNumberTof5_3, tr( "rt3" ) );
    pushButtonSplitFrames->setText( QString::null );
    pushButtonSplitFrames->setTextLabel( tr( "RT :: Split Frames" ) );
    QToolTip::add( pushButtonSplitFrames, tr( "rt1_..._linear_N.DAT " ) );
    QWhatsThis::add( pushButtonSplitFrames, tr( "rt1_..._linear_N.DAT " ) );
    QToolTip::add( spinBoxRtSplitFrom, tr( "Split :: first frame number" ) );
    QWhatsThis::add( spinBoxRtSplitFrom, tr( "Split :: first frame number" ) );
    QToolTip::add( spinBoxRtSplitTo, tr( "Split :: last frame mumber" ) );
    QWhatsThis::add( spinBoxRtSplitTo, tr( "Split :: last frame mumber" ) );
    textLabelMaskLeft_2_4->setText( tr( "Ration of Geometrical Progression :: Used during measurement :" ) );
    lineEditSplitFramesProgrMeasured->setPrefix( tr( "1.00" ) );
    lineEditSplitFramesProgrMeasured->setSuffix( QString::null );
    QToolTip::add( lineEditSplitFramesProgrMeasured, tr( "Ration of Geometrical Progration" ) );
    QWhatsThis::add( lineEditSplitFramesProgrMeasured, tr( "Ration of Geometrical Progration" ) );
    groupBox22_2->setTitle( tr( "RT :: All steps" ) );
    QToolTip::add( groupBox22_2, tr( "Proceeding of  1..3 steps in one shoot" ) );
    QWhatsThis::add( groupBox22_2, tr( "Proceeding of  1..3 steps in one shoot" ) );
    QToolTip::add( lCDNumberTof1_2_3, tr( "tof1" ) );
    QWhatsThis::add( lCDNumberTof1_2_3, tr( "tof1" ) );
    textLabelL_2_3->setText( tr( "..." ) );
    QToolTip::add( lCDNumberTof5_2_3, tr( "tof5" ) );
    QWhatsThis::add( lCDNumberTof5_2_3, tr( "tof5" ) );
    pushButtonRTAll->setText( tr( "RT :: All Selected Steps :: Processing..." ) );
    checkBoxRtPrefix->setText( tr( "Change Prefix:" ) );
    checkBoxRtSuffix->setText( tr( "Change Suffix:" ) );
    checkBoxRtDelete->setText( tr( "Delete files (rt1...rt2)" ) );
    toolBoxAdv->setItemLabel( toolBoxAdv->indexOf(page_24), tr( "RT   :: KWS-1&&2  :: Real Time Tools" ) );
    pushButtonTofSumRead->setText( tr( "TOF :: Sum vs Number :: Read" ) );
    pushButtonTofAddFiles->setText( tr( "TOF :: Add  Files" ) );
    groupBox14->setTitle( tr( "TOF | RT :: Tools" ) );
    QToolTip::add( lCDNumberTof1, tr( "tof1" ) );
    QWhatsThis::add( lCDNumberTof1, tr( "tof1" ) );
    QToolTip::add( lCDNumberTof2, tr( "tof2" ) );
    QWhatsThis::add( lCDNumberTof2, tr( "tof2" ) );
    QToolTip::add( lCDNumberTof3, tr( "tof3" ) );
    QWhatsThis::add( lCDNumberTof3, tr( "tof3" ) );
    QToolTip::add( lCDNumberTof4, tr( "tof4" ) );
    QWhatsThis::add( lCDNumberTof4, tr( "tof4" ) );
    QToolTip::add( lCDNumberTof5, tr( "tof5" ) );
    QWhatsThis::add( lCDNumberTof5, tr( "tof5" ) );
    pushButtonTofCollapse->setText( tr( "TOF :: Collapse Wings" ) );
    pushButtonTofRemove->setText( tr( "TOF :: Remove Frames" ) );
    pushButtonTofMerge->setText( tr( "TOF :: Merge Frames ." ) );
    pushButtonTofSplit->setText( tr( "TOF :: Split Frames ..." ) );
    pushButtonTofShift->setText( tr( "TOF :: Shift Frames ..." ) );
    QToolTip::add( spinBoxMerge, tr( "Number of merging frames" ) );
    QWhatsThis::add( spinBoxMerge, tr( "Number of merging frames" ) );
    spinBoxRemove->setPrefix( QString::null );
    spinBoxRemove->setSuffix( QString::null );
    QToolTip::add( spinBoxRemove, tr( "Number of last frames to be removed" ) );
    QWhatsThis::add( spinBoxRemove, tr( "Number of last frames to be removed" ) );
    QToolTip::add( spinBoxCollapse, tr( "Number Windows of Chopper" ) );
    QWhatsThis::add( spinBoxCollapse, tr( "Number Windows of Chopper" ) );
    QToolTip::add( spinBoxTofShift, tr( "Number of the frame to be first" ) );
    QWhatsThis::add( spinBoxTofShift, tr( "Number of the frame to be first" ) );
    textLabelL->setText( trUtf8( "\xce\xbb\x3d" ) );
    lineEditTofLambda->setText( tr( "4.55" ) );
    QToolTip::add( lineEditTofLambda, tr( "Wave length of the central channel [A]" ) );
    QWhatsThis::add( lineEditTofLambda, tr( "Wave length of the central channel [A]" ) );
    textLabelDL->setText( trUtf8( "\xce\x94\xce\xbb\x3d" ) );
    lineEditTofDeltaLambda->setText( tr( "0.14" ) );
    QToolTip::add( lineEditTofDeltaLambda, tr( "Channel width [A]" ) );
    QWhatsThis::add( lineEditTofDeltaLambda, tr( "Channel width [A]" ) );
    QToolTip::add( spinBoxTofSplitFrom, tr( "Split :: starting from" ) );
    QWhatsThis::add( spinBoxTofSplitFrom, tr( "Split :: starting from" ) );
    QToolTip::add( spinBoxTofSplitTo, tr( "Split :: last frame mumber" ) );
    QWhatsThis::add( spinBoxTofSplitTo, tr( "Split :: last frame mumber" ) );
    groupBox22->setTitle( tr( "TOF :: All steps" ) );
    QToolTip::add( lCDNumberTof1_2, tr( "tof1" ) );
    QWhatsThis::add( lCDNumberTof1_2, tr( "tof1" ) );
    textLabelL_2->setText( tr( "..." ) );
    QToolTip::add( lCDNumberTof5_2, tr( "tof5" ) );
    QWhatsThis::add( lCDNumberTof5_2, tr( "tof5" ) );
    pushButtonTofAll->setText( tr( "TOF :: All Selected Steps :: Processing..." ) );
    checkBoxTofDelete->setText( tr( "delete tof1...tof4 files" ) );
    checkBoxTof12345->setText( tr( "Remove '12345' from file number" ) );
    checkBoxTofPrefix->setText( tr( "Change Prefix:" ) );
    checkBoxTofSuffix->setText( tr( "Change Suffix:" ) );
    groupBoxTofEstimation->setTitle( tr( "TOF :: Parameters :: Estimation" ) );
    comboBoxTofInputAllFrames->clear();
    comboBoxTofInputAllFrames->insertItem( tr( "64" ) );
    QToolTip::add( comboBoxTofInputAllFrames, tr( "TOF frames" ) );
    QWhatsThis::add( comboBoxTofInputAllFrames, tr( "TOF frames" ) );
    spinBoxWLS->setSuffix( tr( "%" ) );
    QToolTip::add( spinBoxWLS, tr( "Selector Spread" ) );
    QWhatsThis::add( spinBoxWLS, tr( "Selector Spread" ) );
    pushButtonTofCheck->setText( tr( ">>> TOF :: Calculate Parameters >>>" ) );
    comboBoxTofOutputFrames->clear();
    comboBoxTofOutputFrames->insertItem( tr( "1" ) );
    comboBoxTofOutputFrames->insertItem( tr( "3" ) );
    comboBoxTofOutputFrames->insertItem( tr( "5" ) );
    comboBoxTofOutputFrames->insertItem( tr( "7" ) );
    comboBoxTofOutputFrames->insertItem( tr( "9" ) );
    comboBoxTofOutputFrames->insertItem( tr( "11" ) );
    comboBoxTofOutputFrames->insertItem( tr( "13" ) );
    comboBoxTofOutputFrames->insertItem( tr( "15" ) );
    comboBoxTofOutputFrames->setCurrentItem( 3 );
    QToolTip::add( comboBoxTofOutputFrames, tr( "Final Number Frames" ) );
    QWhatsThis::add( comboBoxTofOutputFrames, tr( "Final Number Frames" ) );
    toolBoxAdv->setItemLabel( toolBoxAdv->indexOf(page_25), tr( "TOF :: KWS-1&&2 :: Time Of Flight Tools" ) );
    sansTab->changeTab( TabPage_2, tr( "Rawdata Tools" ) );
    buttonGroupActiveMask->setTitle( tr( "Active Mask-Matrix :: Generate|Open|Select" ) );
    comboBoxMaskFor->clear();
    comboBoxMaskFor->insertItem( tr( "mask" ) );
    QToolTip::add( comboBoxMaskFor, tr( "Current Mask" ) );
    QWhatsThis::add( comboBoxMaskFor, tr( "Current Mask" ) );
    pushButtonCreateMask->setText( QString::null );
    pushButtonCreateMask->setTextLabel( tr( "update" ) );
    QToolTip::add( pushButtonCreateMask, tr( "Update/Create Current Mask" ) );
    QWhatsThis::add( pushButtonCreateMask, tr( "Update/Create Current Mask" ) );
    pushButtonSaveMaskTr->setText( QString::null );
    pushButtonSaveMaskTr->setTextLabel( tr( "... as Tr" ) );
    QToolTip::add( pushButtonSaveMaskTr, tr( "Generate Mask for Transmision calculations" ) );
    QWhatsThis::add( pushButtonSaveMaskTr, tr( "Generate Mask for Transmision calculations" ) );
    pushButtonCreateMaskAs->setText( QString::null );
    pushButtonCreateMaskAs->setTextLabel( tr( "new" ) );
    QToolTip::add( pushButtonCreateMaskAs, tr( "Create a new Mask" ) );
    QWhatsThis::add( pushButtonCreateMaskAs, tr( "Create a new Mask" ) );
    pushButtonSaveMask->setText( QString::null );
    QToolTip::add( pushButtonSaveMask, tr( "Save the active matrix in the Output Folder (see Options-Data::Input and\n"
"\n"
"Output Folders)" ) );
    QWhatsThis::add( pushButtonSaveMask, tr( "Save the active matrix in the Output Folder (see Options-Data::Input and\n"
"\n"
"Output Folders)" ) );
    pushButtonOpenMask->setText( QString::null );
    QToolTip::add( pushButtonOpenMask, tr( "Load *.mask file in the active matrix" ) );
    QWhatsThis::add( pushButtonOpenMask, tr( "Load *.mask file in the active matrix" ) );
    groupBoxMask->setTitle( tr( "Edge" ) );
    pushButtonGetCoord1->setText( QString::null );
    comboBoxMaskEdgeShape->clear();
    comboBoxMaskEdgeShape->insertItem( tr( "Rectangle :: Shape of Edge" ) );
    comboBoxMaskEdgeShape->insertItem( tr( "Ellipse :: Shape of Edge" ) );
    QToolTip::add( comboBoxMaskEdgeShape, tr( "Edge Shape" ) );
    QWhatsThis::add( comboBoxMaskEdgeShape, tr( "Edge Shape" ) );
    textLabelMaskLeft->setText( tr( "X" ) );
    textLabelMaskRight_2->setText( tr( "Right-Top-Corner" ) );
    pushButtonGetCoord2->setText( QString::null );
    textLabelMaskLeft_2->setText( tr( "Left-Bottom-Corner" ) );
    textLabelMaskRight->setText( tr( "Y" ) );
    groupBoxMaskBS->setTitle( tr( "Beam-Stop | Direct-Beam " ) );
    pushButtonGetCoord4->setText( QString::null );
    textLabelMaskRight_2_2->setText( tr( "Right-Top-Corner" ) );
    pushButtonGetCoord3->setText( QString::null );
    textLabelMaskRightBS->setText( tr( "Y" ) );
    comboBoxMaskBeamstopShape->clear();
    comboBoxMaskBeamstopShape->insertItem( tr( "Rectangle :: Shape of Beam-Stop" ) );
    comboBoxMaskBeamstopShape->insertItem( tr( "Ellipse :: Shape of Beam-Stop" ) );
    QToolTip::add( comboBoxMaskBeamstopShape, tr( "Beam-stop Shape" ) );
    QWhatsThis::add( comboBoxMaskBeamstopShape, tr( "Beam-stop Shape" ) );
    textLabelMaskLeft_2_2->setText( tr( "Left-Bottom-Corner" ) );
    textLabelMaskLeftBS->setText( tr( "X" ) );
    toolButtonPlusMaskBS->setText( QString::null );
    pushButtonMaskTools->setText( QString::null );
    pushButtonMaskTools->setTextLabel( QString::null );
    QToolTip::add( pushButtonMaskTools, tr( "Switch to DANP for advanced masking" ) );
    QWhatsThis::add( pushButtonMaskTools, tr( "Switch to DANP for advanced masking" ) );
    lineEditDeadRows->setText( QString::null );
    QToolTip::add( lineEditDeadRows, tr( "f.e.: 3-3;10-15;25-27 " ) );
    QWhatsThis::add( lineEditDeadRows, tr( "f.e.: 3-3;10-15;25-27 " ) );
    lineEditDeadCols->setText( QString::null );
    QToolTip::add( lineEditDeadCols, tr( "f.e.: 3-3;10-15;25-27 " ) );
    QWhatsThis::add( lineEditDeadCols, tr( "f.e.: 3-3;10-15;25-27 " ) );
    textLabel1_9_2_2->setText( tr( "Thriangular mask(s)" ) );
    textLabel1_9_2->setText( tr( "\"Dead\" cols" ) );
    textLabel1_9->setText( tr( "\"Dead\" rows" ) );
    pushButtonGetCoordDRows->setText( QString::null );
    lineEditMaskPolygons->setText( QString::null );
    QToolTip::add( lineEditMaskPolygons, tr( "f.e.: 10-10, 40-10, 60-40;100-100,80-80, 10-90 " ) );
    QWhatsThis::add( lineEditMaskPolygons, tr( "f.e.: 10-10, 40-10, 60-40;100-100,80-80, 10-90 " ) );
    pushButtonGetCoordTrian->setText( QString::null );
    pushButtonGetCoordDCols->setText( QString::null );
    toolBox9->setItemLabel( toolBox9->indexOf(page1_6), tr( "Step #1 | Select Active Area of Detector" ) );
    sansTab->changeTab( TabPage_3, tr( "Mask" ) );
    buttonGroupActiveSens->setTitle( tr( "Active Sensitivity-Matrix :: Generate|Open|Select" ) );
    comboBoxSensFor->clear();
    comboBoxSensFor->insertItem( tr( "sens" ) );
    pushButtonCreateSens->setText( QString::null );
    pushButtonCreateSens->setTextLabel( tr( "update" ) );
    pushButtonCreateSensAs->setText( QString::null );
    pushButtonCreateSensAs->setTextLabel( tr( "new" ) );
    pushButtonSaveSens->setText( QString::null );
    pushButtonOpenSens->setText( QString::null );
    buttonGroupSensanyD->setTitle( tr( "Input File Numbers and Transmission" ) );
    textLabel1->setText( tr( "# Plexiglass [ H2O, ... ]" ) );
    textLabel2->setText( tr( "# EB [ EC ]" ) );
    lineEditTransAnyD->setText( tr( "1.0000" ) );
    lineEditBcAnyD->setText( QString::null );
    QToolTip::add( lineEditBcAnyD, tr( "Hall Background, Black Current, ..." ) );
    lineEditEBAnyD->setText( QString::null );
    lineEditPlexiAnyD->setText( QString::null );
    QToolTip::add( lineEditPlexiAnyD, tr( "... Flat Scatter ..." ) );
    textLabel3->setText( tr( "# B4C [ Cd ]" ) );
    pushButtonAnyPlexi->setText( QString::null );
    pushButtonAnyBC->setText( QString::null );
    pushButtonAnyTr->setText( QString::null );
    pushButtonAnyEB->setText( QString::null );
    pushButtonTrHiden->setText( tr( "Transmission" ) );
    buttonGroupLimits->setTitle( tr( "Sensitivity :: Options" ) );
    buttonGroupSensRange->setTitle( tr( "Used Pixels:: Statistical Error range" ) );
    spinBoxErrLeftLimit->setSuffix( tr( " [x0.1%]" ) );
    textLabel1_10->setText( trUtf8( "\xe2\x89\xa4\x20\x20\x45\x72\x72\x6f\x72\x20\x20\xe2\x89\xa4" ) );
    spinBoxErrRightLimit->setSuffix( tr( " [x0.1%]" ) );
    checkBoxSensError->setText( tr( "Calculate also Matrix of Statistical Errors" ) );
    checkBoxSensTr->setText( trUtf8( "\x43\x61\x6c\x63\x75\x6c\x61\x74\x65\x20\x54\x72\x61\x6e\x73\x6d\x69\x73\x73\x69\x6f\x6e\x20\x62\x79\x20\x46\x6f\x72\x6d\x75\x6c\x61\x20\x54\x28\xce\xbb\x29" ) );
    toolBox10->setItemLabel( toolBox10->indexOf(page1_7), tr( "Step #2 | Calculation of Sensitivity-Matrixes" ) );
    sansTab->changeTab( TabPage_4, tr( "Sensitivity" ) );
    pushButtonDeleteFirst->setText( QString::null );
    pushButtonDeleteFirst->setTextLabel( QString::null );
    QToolTip::add( pushButtonDeleteFirst, tr( "delete FIRST configuration" ) );
    QWhatsThis::add( pushButtonDeleteFirst, tr( "delete FIRST configuration" ) );
    QToolTip::add( sliderConfigurations, tr( "Define Number of Instrument Configurations" ) );
    QWhatsThis::add( sliderConfigurations, tr( "Define Number of Instrument Configurations" ) );
    pushButtonAddCopy->setText( QString::null );
    pushButtonAddCopy->setTextLabel( QString::null );
    QToolTip::add( pushButtonAddCopy, tr( "add configuration" ) );
    QWhatsThis::add( pushButtonAddCopy, tr( "add configuration" ) );
    tableECinfo->verticalHeader()->setLabel( 0, tr( "#-EC ..." ) );
    tableECinfo->verticalHeader()->setLabel( 1, tr( "#-BC..." ) );
    tableECinfo->verticalHeader()->setLabel( 2, tr( "C..." ) );
    tableECinfo->verticalHeader()->setLabel( 3, tr( "D..." ) );
    tableECinfo->verticalHeader()->setLabel( 4, trUtf8( "\xce\xbb\x2e\x2e\x2e" ) );
    tableECinfo->verticalHeader()->setLabel( 5, tr( "Bea..." ) );
    tableECinfo->verticalHeader()->setLabel( 6, tr( "Abs...FS]" ) );
    tableECinfo->verticalHeader()->setLabel( 7, tr( "Abs...EB]" ) );
    tableECinfo->verticalHeader()->setLabel( 8, tr( "Abs...BC]" ) );
    tableECinfo->verticalHeader()->setLabel( 9, tr( "D-[FS..." ) );
    tableECinfo->verticalHeader()->setLabel( 10, trUtf8( "\xce\xbc\x2e\x2e\x2e" ) );
    tableECinfo->verticalHeader()->setLabel( 11, tr( "Tr-[FS..." ) );
    tableECinfo->verticalHeader()->setLabel( 12, tr( "Factor" ) );
    tableECinfo->verticalHeader()->setLabel( 13, tr( "#-\"Ce..." ) );
    tableECinfo->verticalHeader()->setLabel( 14, tr( "X-ce..." ) );
    tableECinfo->verticalHeader()->setLabel( 15, tr( "Y-ce..." ) );
    tableECinfo->verticalHeader()->setLabel( 16, tr( "Mask...rix" ) );
    tableECinfo->verticalHeader()->setLabel( 17, tr( "Sen...rix" ) );
    tableECinfo->verticalHeader()->setLabel( 18, tr( "#-EB..." ) );
    tableECinfo->verticalHeader()->setLabel( 19, tr( "Tr [EC-...]" ) );
    tableECinfo->verticalHeader()->setLabel( 20, tr( "Mas... Tr]" ) );
    QToolTip::add( tableECinfo, tr( "Questions about rows-content? Push here...." ) );
    QWhatsThis::add( tableECinfo, tr( "Questions about rows-content? Push here...." ) );
    tableECnew->verticalHeader()->setLabel( 0, tr( "#-EC [EB]" ) );
    tableECnew->verticalHeader()->setLabel( 1, tr( "#-BC" ) );
    tableECnew->verticalHeader()->setLabel( 2, tr( "C[m]" ) );
    tableECnew->verticalHeader()->setLabel( 3, tr( "D[m]" ) );
    tableECnew->verticalHeader()->setLabel( 4, trUtf8( "\xce\xbb\x5b\xc3\x85\x5d" ) );
    tableECnew->verticalHeader()->setLabel( 5, tr( "Beam Size" ) );
    tableECnew->verticalHeader()->setLabel( 6, tr( "Abs.Cal. [#-FS]" ) );
    tableECnew->verticalHeader()->setLabel( 7, tr( "Abs.Cal. [#-EB]" ) );
    tableECnew->verticalHeader()->setLabel( 8, tr( "Abs.Cal. [#-BC]" ) );
    tableECnew->verticalHeader()->setLabel( 9, tr( "D-[FS|EB][m]" ) );
    tableECnew->verticalHeader()->setLabel( 10, trUtf8( "\xce\xbc\x2d\x5b\x46\x53\x5d" ) );
    tableECnew->verticalHeader()->setLabel( 11, tr( "Tr-[FS|Att]" ) );
    tableECnew->verticalHeader()->setLabel( 12, tr( "Factor" ) );
    tableECnew->verticalHeader()->setLabel( 13, tr( "#-\"Center\"" ) );
    tableECnew->verticalHeader()->setLabel( 14, tr( "X-center" ) );
    tableECnew->verticalHeader()->setLabel( 15, tr( "Y-center" ) );
    tableECnew->verticalHeader()->setLabel( 16, tr( "Mask Matrix" ) );
    tableECnew->verticalHeader()->setLabel( 17, tr( "Sens. Matrix" ) );
    tableECnew->verticalHeader()->setLabel( 18, tr( "#-EB" ) );
    tableECnew->verticalHeader()->setLabel( 19, tr( "Tr [EC-to-EB]" ) );
    tableECnew->verticalHeader()->setLabel( 20, tr( "Mask Matrix [Tr]" ) );
    QToolTip::add( tableECnew, tr( "Table of Instrument Configurations" ) );
    QWhatsThis::add( tableECnew, tr( "Table of Instrument Configurations _" ) );
    buttonGroupScriptTools->setTitle( tr( "Script-Table Tools " ) );
    comboBoxMakeScriptTable->clear();
    comboBoxMakeScriptTable->insertItem( tr( "New-Script-Table" ) );
    QToolTip::add( comboBoxMakeScriptTable, tr( "Active Script-Table" ) );
    QWhatsThis::add( comboBoxMakeScriptTable, tr( "Active Script-Table" ) );
    pushButtonNewScript->setText( QString::null );
    pushButtonNewScript->setTextLabel( tr( "New" ) );
    QToolTip::add( pushButtonNewScript, tr( "Create new Script-table" ) );
    QWhatsThis::add( pushButtonNewScript, tr( "Create new Script-table" ) );
    pushButtonMakeTable->setText( QString::null );
    pushButtonMakeTable->setTextLabel( tr( "Add" ) );
    QToolTip::add( pushButtonMakeTable, tr( "Add files to active Script-Table" ) );
    QWhatsThis::add( pushButtonMakeTable, tr( "Add files to active Script-Table" ) );
    pushButtonCalcTr->setText( QString::null );
    pushButtonCalcTr->setTextLabel( tr( "Tr" ) );
    QToolTip::add( pushButtonCalcTr, tr( "Update (re-calculate) Transmissions in active script-Table" ) );
    QWhatsThis::add( pushButtonCalcTr, tr( "Update (re-calculate) Transmissions in active script-Table" ) );
    pushButtonSaveSettings->setText( QString::null );
    QToolTip::add( pushButtonSaveSettings, tr( "Save current Settings" ) );
    QWhatsThis::add( pushButtonSaveSettings, tr( "Save current Settings" ) );
    buttonGroupdaNdAN->setTitle( tr( "Process active Script-Table" ) );
    pushButtonIQx->setText( tr( "I [Qx]" ) );
    pushButtonPolar->setText( trUtf8( "\x49\x20\x5b\x51\x2c\xcf\x86\x5d" ) );
    QToolTip::add( pushButtonPolar, tr( "Processing of data in Script Tabe.Output: 2D Matrix in Polar Coordinates" ) );
    QWhatsThis::add( pushButtonPolar, tr( "Processing of data in Script Tabe.Output: 2D Matrix in Polar Coordinates" ) );
    pushButtonIQy->setText( tr( "I [Qy]" ) );
    pushButtonIxy->setText( tr( "I [x,y]" ) );
    QToolTip::add( pushButtonIxy, tr( "Processing of data in Script Tabe.Output: 2D Matrix" ) );
    QWhatsThis::add( pushButtonIxy, tr( "Processing of data in Script Tabe.Output: 2D Matrix" ) );
    pushButtonIQ->setText( tr( "I [Q]" ) );
    QToolTip::add( pushButtonIQ, tr( "Processing of data in Script Tabe: Radial Averaging" ) );
    QWhatsThis::add( pushButtonIQ, tr( "Processing of data in Script Tabe: Radial Averaging" ) );
    pushButtondQxy->setText( tr( "dQ [x,y]" ) );
    pushButtonSigma->setText( trUtf8( "\xcf\x83\x20\x5b\x78\x2c\x79\x5d" ) );
    pushButtonQxy->setText( tr( "Q [x,y]" ) );
    pushButtondIxy->setText( tr( "dI [x,y]" ) );
    radioButtonOpenInProject->setText( tr( ">> Project" ) );
    QToolTip::add( radioButtonOpenInProject, tr( "Data Processing Output :: Open in Current Project" ) );
    QWhatsThis::add( radioButtonOpenInProject, tr( "Data Processing Output :: Open in Current Project" ) );
    radioButtonFile->setText( tr( ">> File (ascii)" ) );
    QToolTip::add( radioButtonFile, tr( "Data Processing Output :: Save as ASCII File" ) );
    QWhatsThis::add( radioButtonFile, tr( "Data Processing Output :: Save as ASCII File" ) );
    QToolTip::add( lineEditFileExt, tr( "Suffix inside of name of generated tables/matrixes" ) );
    QWhatsThis::add( lineEditFileExt, tr( "Suffix inside of name of generated tables/matrixes" ) );
    toolBoxProcess->setItemLabel( toolBoxProcess->indexOf(page1_8), tr( "Step #3 | Data Processing" ) );
    sansTab->changeTab( TabPage_5, tr( "Data Processing" ) );
    textLabelInfoSAS->setText( tr( "Uni :: SA(N)S :: DAN" ) );
    textLabelInfo_2_2->setText( tr( "v.16-06.09.2017" ) );
    textLabelInfo_2->setText( tr( "Vitaliy Pipich @ JCNS" ) );
}

