#include "dan16.h"

//+++ connect Slots
void dan16::maskConnectSlot()
{
    connect( pushButtonCreateMaskAs,    SIGNAL( clicked() ), this, SLOT( saveMaskAs()   ) );
    connect( pushButtonCreateMask,      SIGNAL( clicked() ), this, SLOT( createMask()   ) );
    connect( pushButtonSaveMaskTr,      SIGNAL( clicked() ), this, SLOT( createMaskTr() ) );
    connect( pushButtonSaveMask,        SIGNAL( clicked() ), this, SLOT( saveMaskFul()  ) );
    connect( pushButtonOpenMask,        SIGNAL( clicked() ), this, SLOT( loadMaskFul()  ) );
    
    connect( pushButtonGetCoord1,       SIGNAL( clicked() ), this, SLOT( readCoord1()   ) );
    connect( pushButtonGetCoord2,       SIGNAL( clicked() ), this, SLOT( readCoord2()   ) );
    connect( pushButtonGetCoord3,       SIGNAL( clicked() ), this, SLOT( readCoord3()   ) );
    connect( pushButtonGetCoord4,       SIGNAL( clicked() ), this, SLOT( readCoord4()   ) );

    connect( pushButtonMaskTools,       SIGNAL( clicked() ), this, SLOT( showDANP()     ) );
    
    connect( toolButtonPlusMaskBS,      SIGNAL( clicked() ), this, SLOT( maskPlusMaskBS() ) );

    connect( pushButtonGetCoordDRows,   SIGNAL( clicked() ), this, SLOT( readCoordDRows()   ) );
    connect( pushButtonGetCoordDCols,   SIGNAL( clicked() ), this, SLOT( readCoordDCols()   ) );
    connect( pushButtonGetCoordTrian,   SIGNAL( clicked() ), this, SLOT( readCoordTriangle()   ) );
    
    connect( comboBoxMaskFor, SIGNAL( activated(const QString&) ), this, SLOT( readMaskParaFromMaskMatrix(const QString&) ) );
}

//+++++SLOT::Save mask as
void dan16::saveMaskAs()
{
    ImportantConstants();
    
    bool ok;
    
    QString oldName=comboBoxMaskFor->currentText();
    
    QString maskName = QInputDialog::getText(
                                             "QtiKWS", "Input matrix name for mask:", QLineEdit::Normal,
                                             oldName, &ok, this );
    
    if ( !ok ||  maskName.isEmpty() )
    {
        return;
    }
    
    //+++
    QWidgetList* windows=app(this)->windowsList();
    
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
        if (windows->at(mm)->name()==maskName  )
        {
            myWidget* mmm=(myWidget*) windows->at(mm);
            if ( !mmm->windowLabel().contains( "DAN::Mask::"+QString::number(MD)) ) ok=false;
        }
    }
    
    if ( !ok ||  maskName.isEmpty() )
    {
        return;
    }
    
    bool exist=existWindow(maskName);
    
    createMaskFul(maskName);
    
    if (!exist )
    {
        maximizeWindow(maskName);
        if (checkBoxSortOutputToFolders->isChecked()) app(this)->changeFolder("DAN :: mask, sens");
        Folder *cf = ( Folder * ) app(this)->current_folder;
        app(this)->folders->setCurrentItem ( cf->folderListItem() );
        app(this)->folders->setFocus();
    }
    
    //    statusShow();
    updateMaskList();
    
    comboBoxMaskFor->setCurrentText(maskName);
    
}


//+++ SLOT::MASK create standart mask
void dan16::createMask()
{
    
    
    ImportantConstants();
    
    updateMaskList();
    
    QString maskName=comboBoxMaskFor->currentText();
    bool exist=existWindow(maskName);
    
    createMaskFul(maskName);
    
    if (!exist )
    {
        maximizeWindow(maskName);
        if (checkBoxSortOutputToFolders->isChecked()) app(this)->changeFolder("DAN :: mask, sens");
        Folder *cf = ( Folder * ) app(this)->current_folder;
        app(this)->folders->setCurrentItem ( cf->folderListItem() );
        app(this)->folders->setFocus();
    }
}


//+++++SLOT::MASK create mask for transmission calculations
void dan16::createMaskTr()
{
    
    ImportantConstants();
    
    updateMaskList();
    
    QString maskName=comboBoxMaskFor->currentText();
    bool exist=existWindow(maskName);
    
    createMaskFullTr(maskName);
    
    if (!exist ) maximizeWindow(maskName);
    
}

//+++++SLOT::save MASK+++++++++++
void dan16::saveMaskFul( )
{
    ImportantConstants();
    
    QString maskName=comboBoxMaskFor->currentText();
    
    //+++
    gsl_matrix *mask=gsl_matrix_alloc(MD,MD);  // allocate sens matrix
    gsl_matrix_set_zero(mask);
    
    if ( make_GSL_Matrix_Symmetric(maskName, mask, MD) ) saveMatrixToFile(Dir+maskName+".mask",mask, MD);
    
    gsl_matrix_free(mask);//2013-11-12
}

//+++++SLOT::load MASK+++++++++++
void dan16::loadMaskFul()
{
    ImportantConstants();
    QString maskName = comboBoxMaskFor->currentText();
    
    QString maskFileName = QFileDialog::getOpenFileName(
                                                        Dir,
                                                        "*.mask",
                                                        this,
                                                        "open file dialog",
                                                        "Choose a Mask file");
    if (maskFileName!="") loadMaskFul(maskName, maskFileName);
}


void dan16::readCoord1()
{
    int x,y;
    if (!readDisplay(x, y)) return;
    
    spinBoxLTx->setValue(x);
    spinBoxLTy->setValue(y);
}

void dan16::readCoord2()
{
    int x,y;
    readDisplay(x, y) ;
    if (!readDisplay(x, y)) return;
    
    spinBoxRBx->setValue(x);
    spinBoxRBy->setValue(y);
}

void dan16::readCoord3()
{
    int x,y;
    readDisplay(x, y) ;
    if (!readDisplay(x, y)) return;
    
    spinBoxLTxBS->setValue(x);
    spinBoxLTyBS->setValue(y);
}

void dan16::readCoord4()
{
    int x,y;
    readDisplay(x, y) ;
    if (!readDisplay(x, y)) return;
    
    spinBoxRBxBS->setValue(x);
    spinBoxRByBS->setValue(y);
}

//+++
void dan16::showDANP()
{
    app(this)->showDANPmask();
}

//+++
void dan16::maskPlusMaskBS(){
    ImportantConstants();
    
    updateMaskList();
    
    QString maskName=comboBoxMaskFor->currentText();
    if (!existWindow(maskName)) return;
    
    
    addBS2CurrentMask(maskName);
    
}

//+++++SLOT::MASK slot Mask to table+++++++++++
void dan16::createMaskFul( QString maskName )
{
    app(this)->ws->hide();
    app(this)->ws->blockSignals ( true );
    
    if (checkBoxSortOutputToFolders->isChecked() && !checkExistenceOfMaskNoMessage(QString::number(MD), maskName))
    {
        app(this)->changeFolder("DAN :: mask, sens");
    }
    
    //+++
    int i,j,mm;
    Matrix *m;
    QString ss;
    bool YN=true;
    //+++
    QWidgetList* windows=app(this)->windowsList();
    
    QString maskRange;
    maskRange ="|"+QString::number(spinBoxLTx->value());
    maskRange+="|"+QString::number(spinBoxRBx->value());
    maskRange+="|"+QString::number(spinBoxLTy->value());
    maskRange+="|"+QString::number(spinBoxRBy->value());
    maskRange+="|"+QString::number(spinBoxLTxBS->value());
    maskRange+="|"+QString::number(spinBoxRBxBS->value());
    maskRange+="|"+QString::number(spinBoxLTyBS->value());
    maskRange+="|"+QString::number(spinBoxRByBS->value());
    
    //+++2014-11
    maskRange+="| "+lineEditDeadRows->text();
    maskRange+="| "+lineEditDeadCols->text();
    maskRange+="| "+lineEditMaskPolygons->text();
    maskRange+="|";
    //+++
    for (mm=0; mm < (int)windows->count(); mm++ )
    {
        ss=windows->at(mm)->name();
        
        if (ss==maskName && windows->at(mm)->isA("Matrix"))
        {
            m=(Matrix *)windows->at(mm);
            YN=false;
        }
    }
    
    //+++
    if (YN)
    {
        
        m=app(this)->newMatrix(maskName,MD, MD);
        app(this)->updateRecentProjectsList();
        m->setNumericFormat('f',0);
        m->setCoordinates(0.5,MD+0.5,0.5,MD+0.5);//m->setCoordinates(1,MD,1,MD);
        
        //+++
    }
    else
    {
        m->setMatrixDimensions(MD,MD);
        m->setCoordinates(0.5,MD+0.5,0.5,MD+0.5);
    }
    
    m->setWindowLabel("DAN::Mask::"+QString::number(MD)+maskRange);
    app(this)->setListViewLabel(m->name(), "DAN::Mask::"+QString::number(MD)+maskRange);
    app(this)->updateWindowLists(m);
    
    
    int LTy, RBy, LTx, RBx;
    int LTyBS, RByBS, LTxBS, RBxBS;
    
    double xCenter, yCenter, xSize, ySize;
    
    for(i=0;i<MD;i++) for(j=0;j<MD;j++)  m->setText(i,j,"1");
    
    
    
    if (groupBoxMask->isChecked())
    {
        
        if (comboBoxMaskEdgeShape->currentItem()==0)
        {
            
            LTy=spinBoxLTy->value()-1;
            RBy=spinBoxRBy->value()-1;
            LTx=spinBoxLTx->value()-1;
            RBx=spinBoxRBx->value()-1;
            
            for(i=0;i<MD;i++) for(j=0;j<MD;j++)
            {
                if (i<(LTy) || i>(RBy) ||
                    j<(LTx) || j>(RBx))
                    m->setText(i,j,"0");
            }
            
        }
        else
        {
            
            LTy=spinBoxLTy->value()-1;
            RBy=spinBoxRBy->value()-1;
            LTx=spinBoxLTx->value()-1;
            RBx=spinBoxRBx->value()-1;
            
            xCenter=(LTx+RBx)/2.0;
            yCenter=(LTy+RBy)/2.0;
            xSize=(RBx-LTx)+2;
            ySize=(RBy-LTy)+2;
            
            for (int xx=0;xx<MD;xx++) for (int yy=0; yy<MD;yy++)
            {
                
                if ( (xCenter-xx)*(xCenter-xx)*4/xSize/xSize+(yCenter-yy)*(yCenter-yy)*4/ySize/ySize>1 )
                    m->setText(yy,xx,"0");
            }
            
            
            
            
        }
    }
    
    
    if (groupBoxMaskBS->isChecked())
    {
        
        if (comboBoxMaskBeamstopShape->currentItem()==0)
        {
            
            LTyBS=spinBoxLTyBS->value()-1;
            RByBS=spinBoxRByBS->value()-1;
            LTxBS=spinBoxLTxBS->value()-1;
            RBxBS=spinBoxRBxBS->value()-1;
            
            for(i=0;i<MD;i++) for(j=0;j<MD;j++)
            {
                if (i>=(LTyBS) && i<=(RByBS) &&
                    j>=(LTxBS) && j<=(RBxBS))
                    m->setText(i,j,"0");
            }
        }
        else
        {
            
            LTy=spinBoxLTyBS->value()-1;
            RBy=spinBoxRByBS->value()-1;
            LTx=spinBoxLTxBS->value()-1;
            RBx=spinBoxRBxBS->value()-1;
            
            xCenter=(LTx+RBx)/2.0;
            yCenter=(LTy+RBy)/2.0;
            xSize=(RBx-LTx)+0.5;
            ySize=(RBy-LTy)+0.5;
            
            for (int xx=0;xx<MD;xx++) for (int yy=0; yy<MD;yy++)
            {
                
                if ( (xCenter-xx)*(xCenter-xx)*4/xSize/xSize+(yCenter-yy)*(yCenter-yy)*4/ySize/ySize<=1 )
                    m->setText(yy,xx,"0");
            }
            
            
        }
    }
    
    //+++ 2014-11-05
    QString sDeadRows=lineEditDeadRows->text();
    
    if (sDeadRows!="")
    {
        QStringList lst;
        lst=lst.split(";",sDeadRows);
        for (int li=0; li<lst.count();li++)
        {
            QStringList lstMin;
            lstMin=lstMin.split("-",lst[li]);

            if (lstMin.count()==2)
            {
                if (lstMin[0].toInt()>0 && lstMin[1].toInt()>0 && lstMin[0].toInt()<=MD && lstMin[1].toInt()<=MD && lstMin[0].toInt()<=lstMin[1].toInt())
                {
                 for (int raw=lstMin[0].toInt()-1;raw<=lstMin[1].toInt()-1;raw++) for (int yy=0; yy<MD;yy++)
                 {
                     m->setText(raw,yy,"0");
                 }
                }
                
            }
            else if (lstMin.count()==4 && lstMin[0].toInt()>0 && lstMin[1].toInt()>0 && lstMin[0].toInt()<=MD && lstMin[1].toInt()<=MD && lstMin[0].toInt()<=lstMin[1].toInt())
            {
                int start=0;
                int finish=MD-1;
                
                if (lstMin[2].toInt()<=MD && lstMin[2].toInt()>0 ) start=lstMin[2].toInt()-1;
                if (lstMin[3].toInt()<=MD && lstMin[3].toInt()>0 ) finish=lstMin[3].toInt()-1;
                if (start>finish){int tmp=finish; finish=start; start=tmp;};
                
                for (int raw=lstMin[0].toInt()-1;raw<=lstMin[1].toInt()-1;raw++) for (int yy=start; yy<=finish;yy++)
                {
                    m->setText(raw,yy,"0");
                }
                
            }
        }
    }
    
    //+++ 2014-11-05
    QString sDeadCols=lineEditDeadCols->text();
    
    if (sDeadCols!="")
    {
        QStringList lst;
        lst=lst.split(";",sDeadCols);
        for (int li=0; li<lst.count();li++)
        {
            QStringList lstMin;
            lstMin=lstMin.split("-",lst[li]);
      
            if (lstMin.count()==2)
            {
                if( lstMin[0].toInt()>0 && lstMin[1].toInt()>0 && lstMin[0].toInt()<=MD && lstMin[1].toInt()<=MD && lstMin[0].toInt()<=lstMin[1].toInt())
                {
                    for (int yy=0; yy<MD;yy++) for (int col=lstMin[0].toInt()-1;col<=lstMin[1].toInt()-1;col++)
                    {
                        m->setText(yy,col,"0");
                    }
                
                }
            }
            else if (lstMin.count()==4)
            {
                if( lstMin[0].toInt()>0 && lstMin[1].toInt()>0 && lstMin[0].toInt()<=MD && lstMin[1].toInt()<=MD && lstMin[0].toInt()<=lstMin[1].toInt())
                {
                    int start=0;
                    int finish=MD-1;
                    
                    if (lstMin[2].toInt()<=MD && lstMin[2].toInt()>0 ) start=lstMin[2].toInt()-1;
                    if (lstMin[3].toInt()<=MD && lstMin[3].toInt()>0 ) finish=lstMin[3].toInt()-1;
                    if (start>finish){int tmp=finish; finish=start; start=tmp;};
                    
                    for (int yy=start; yy<=finish;yy++) for (int col=lstMin[0].toInt()-1;col<=lstMin[1].toInt()-1;col++)
                    {
                        m->setText(yy,col,"0");
                    }
                    
                }
            }
        }
    }
    
    maskTriangle(m, MD);
    
    
    m->setColumnsWidth(25);
    m->cellEdited(0,0);
    
    
    //*************************************Log Window Output
    toResLogAll("DAN","\n\nMask template is created: \""+maskName+"\". \nEdge: " +
                QString::number(LTx) +" | "+
                QString::number(RBx) +" | "+
                QString::number(LTy) +" | "+
                QString::number(RBy) +" and Beam-Stop: " +
                QString::number(LTxBS) +" | "+
                QString::number(RBxBS) +" | "+
                QString::number(LTyBS) +" | "+
                QString::number(RByBS)+". \n ",this );
    //*************************************Log Window Output
    
    
    app(this)->ws->show();
    app(this)->ws->blockSignals ( false );
    
    app(this)->updateWindowLists(m);
    m->notifyChanges();
    
    if (YN) {m->hide(); m->showMaximized();}
}


//+++++SLOT::MASK slot Mask to table+++++++++++
void dan16::createMaskFullTr( QString maskName )
{
    
    app(this)->ws->hide();
    app(this)->ws->blockSignals ( true );
    
    bool cfbool=checkBoxSortOutputToFolders->isChecked() && !checkExistenceOfMaskNoMessage(QString::number(MD), maskName);
    
    if (cfbool)
    {
        app(this)->changeFolder("DAN :: mask, sens");
    }
    
    //+++
    int i,j,mm;
    Matrix *m;
    QString ss;
    bool YN=true;
    //+++
    QWidgetList* windows=app(this)->windowsList();
    
    QString maskRange;
    maskRange ="|"+QString::number(spinBoxLTx->value());
    maskRange+="|"+QString::number(spinBoxRBx->value());
    maskRange+="|"+QString::number(spinBoxLTy->value());
    maskRange+="|"+QString::number(spinBoxRBy->value());
    maskRange+="|"+QString::number(spinBoxLTxBS->value());
    maskRange+="|"+QString::number(spinBoxRBxBS->value());
    maskRange+="|"+QString::number(spinBoxLTyBS->value());
    maskRange+="|"+QString::number(spinBoxRByBS->value());
    
    //+++2014-11
    maskRange+="| "+lineEditDeadRows->text();
    maskRange+="| "+lineEditDeadCols->text();
    maskRange+="| "+lineEditMaskPolygons->text();
    maskRange+="|";
    
    //+++
    for (mm=0; mm < (int)windows->count(); mm++ )
    {
        ss=windows->at(mm)->name();
        
        if (ss==maskName && windows->at(mm)->isA("Matrix"))
        {
            m=(Matrix *)windows->at(mm);
            YN=false;
        }
    }
    
    //+++
    if (YN)
    {
        
        m=app(this)->newMatrix(maskName,MD, MD);
        app(this)->updateRecentProjectsList();
        m->setNumericFormat('f',0);
        m->setCoordinates(0.5,MD+0.5,0.5,MD+0.5); //  m->setCoordinates(1,MD,1,MD);
        //+++
    }
    
    m->setWindowLabel("DAN::Mask::"+QString::number(MD)+maskRange);
    app(this)->setListViewLabel(m->name(), "DAN::Mask::"+QString::number(MD)+maskRange);
    app(this)->updateWindowLists(m);
    
    
    int LTy, RBy, LTx, RBx;
    int LTyBS, RByBS, LTxBS, RBxBS;
    
    double xCenter, yCenter, xSize, ySize;
    
    for(i=0;i<MD;i++) for(j=0;j<MD;j++)  m->setText(i,j,"0");
    
    
    if (groupBoxMaskBS->isChecked())
    {
        
        if (comboBoxMaskBeamstopShape->currentItem()==0)
        {
            
            LTyBS=spinBoxLTyBS->value()-1;
            RByBS=spinBoxRByBS->value()-1;
            LTxBS=spinBoxLTxBS->value()-1;
            RBxBS=spinBoxRBxBS->value()-1;
            
            for(i=0;i<MD;i++) for(j=0;j<MD;j++)
            {
                if (i>=(LTyBS) && i<=(RByBS) &&
                    j>=(LTxBS) && j<=(RBxBS))
                    m->setText(i,j,"1");
            }
        }
        else
        {
            
            LTy=spinBoxLTyBS->value()-1;
            RBy=spinBoxRByBS->value()-1;
            LTx=spinBoxLTxBS->value()-1;
            RBx=spinBoxRBxBS->value()-1;
            
            xCenter=(LTx+RBx)/2.0;
            yCenter=(LTy+RBy)/2.0;
            xSize=(RBx-LTx)+0.5;
            ySize=(RBy-LTy)+0.5;
            
            for (int xx=0;xx<MD;xx++) for (int yy=0; yy<MD;yy++)
            {
                
                if ( (xCenter-xx)*(xCenter-xx)*4/xSize/xSize+(yCenter-yy)*(yCenter-yy)*4/ySize/ySize<=1 )
                    m->setText(yy,xx,"1");
            }
            
            
        }
    }
    
    m->setColumnsWidth(25);
    m->cellEdited(0,0);
    
    
    //*************************************Log Window Output
    toResLogAll("DAN","\n\nMask template is created: \""+maskName+"\". \nEdge: " +
                QString::number(LTx) +" | "+
                QString::number(RBx) +" | "+
                QString::number(LTy) +" | "+
                QString::number(RBy) +" and Beam-Stop: " +
                QString::number(LTxBS) +" | "+
                QString::number(RBxBS) +" | "+
                QString::number(LTyBS) +" | "+
                QString::number(RByBS)+". \n ",this );
    //*************************************Log Window Output
    
    if (cfbool)
    {
        app(this)->changeFolder(app(this)->projectFolder(),true);
    }
    
    app(this)->ws->show();
    app(this)->ws->blockSignals ( false );
    
    if (cfbool)
    {
        app(this)->changeFolder("DAN :: mask, sens");
    }
}


//+++++SLOT::load MASK+++++++++++
void dan16::loadMaskFul( QString maskName, QString maskFileName)
{  
    app(this)->ws->hide();
    app(this)->ws->blockSignals ( true );
    
    if (checkBoxSortOutputToFolders->isChecked() && !checkExistenceOfMaskNoMessage(QString::number(MD), maskName))
    {
        app(this)->changeFolder("DAN :: mask, sens");
    }
    
    //+++ 
    gsl_matrix *mask=gsl_matrix_alloc(MD,MD);  // allocate sens matrix
    gsl_matrix_set_zero(mask);
    
    
    readMatrixByNameGSL (maskFileName, mask);
    
    
    for (int i=0;i<MD;i++) for (int j=0; j<MD; j++) 
    {
        if (gsl_matrix_get(mask,i,j) >0.0 ) gsl_matrix_set(mask,i,j,1.0); else gsl_matrix_set(mask,i,j,0.0);    
    }
    
    //    readMatrixByName (maskFileName, MD, MD, false, false, 0, mask);
    
    QString label="DAN::Mask::"+QString::number(MD)+" Mask file: "+maskFileName;
    
    makeMatrixSymmetric(mask, maskName, label, MD);
    
    //*************************************Log Window Output
    toResLogAll("DAN","\n\nMask template is created: \""+maskName+"\"." +" Mask file: "+maskFileName +". \n ",this );
    //*************************************Log Window Output
    
    gsl_matrix_free(mask);//2013-11-12
    
    app(this)->ws->show();
    app(this)->ws->blockSignals (false );
}


void dan16::addBS2CurrentMask( QString maskName )
{
    
    //+++
    int i,j,mm;
    Matrix *m;
    QString ss;
    bool YN=true;
    //+++
    QWidgetList* windows=app(this)->windowsList();
    
    
    //+++
    for (mm=0; mm < (int)windows->count(); mm++ )
    {
        ss=windows->at(mm)->name();
        
        if (ss==maskName && windows->at(mm)->isA("Matrix"))
        {
            m=(Matrix *)windows->at(mm);
            YN=false;
        }
    }
    
    //+++
    if (YN) return;
    
    
    
    int LTy, RBy, LTx, RBx;
    int LTyBS, RByBS, LTxBS, RBxBS;
    
    double xCenter, yCenter, xSize, ySize;
    
    
    if (comboBoxMaskBeamstopShape->currentItem()==0)
    {
        
        LTyBS=spinBoxLTyBS->value()-1;
        RByBS=spinBoxRByBS->value()-1;
        LTxBS=spinBoxLTxBS->value()-1;
        RBxBS=spinBoxRBxBS->value()-1;
        
        for(i=LTyBS;i<=RByBS;i++) for(j=LTxBS;j<=RBxBS;j++)
        {
            m->setText(i,j,"0");
        }
    }
    else
    {
        
        LTy=spinBoxLTyBS->value()-1;
        RBy=spinBoxRByBS->value()-1;
        LTx=spinBoxLTxBS->value()-1;
        RBx=spinBoxRBxBS->value()-1;
        
        xCenter=(LTx+RBx)/2.0;
        yCenter=(LTy+RBy)/2.0;
        xSize=(RBx-LTx)+0.5;
        ySize=(RBy-LTy)+0.5;
        
        for(int yy=LTy;yy<=RBy;yy++) for(int xx=LTx;xx<=RBx;xx++)
        {
            
            if ( (xCenter-xx)*(xCenter-xx)*4/xSize/xSize+(yCenter-yy)*(yCenter-yy)*4/ySize/ySize<=1 ) 
                m->setText(yy,xx,"0");
        }
        
    }
    
    m->cellEdited(0,0);
    
}


void dan16::readCoordDRows()
{
    int x,y;
    if (!readDisplay(x, y)) return;
    
    QString currentStr=lineEditDeadRows->text();
    currentStr=currentStr.remove(" ");
    if (currentStr.right(1)=="-") currentStr+=QString::number(y)+";";
    else currentStr+=QString::number(y)+"-";
        
    lineEditDeadRows->setText(currentStr);
}

void dan16::readCoordDCols()
{
    int x,y;
    if (!readDisplay(x, y)) return;
    
    QString currentStr=lineEditDeadCols->text();
    currentStr=currentStr.remove(" ");
    if (currentStr.right(1)=="-") currentStr+=QString::number(x)+";";
    else currentStr+=QString::number(x)+"-";
    
    lineEditDeadCols->setText(currentStr);
}

void dan16::readCoordTriangle()
{
    int x,y;
    if (!readDisplay(x, y)) return;
    
    QString currentStr=lineEditMaskPolygons->text();
    currentStr=currentStr.remove(" ");
    
    if (int(currentStr.contains(",")/2)*2!=currentStr.contains(",") || currentStr.contains(",")==0 || currentStr.right(1)==";" ) currentStr+=QString::number(x)+"-"+QString::number(y)+",";
    else currentStr+=QString::number(x)+"-"+QString::number(y)+";";
    
    lineEditMaskPolygons->setText(currentStr);
}


bool dan16::maskTriangle(Matrix *m, int md)
{
    QString sMask=lineEditMaskPolygons->text();
    
    if (sMask!="")
    {
        QStringList lst;
        lst=lst.split(";",sMask);
        
        int *pointListX=new int[3];
        int *pointListY=new int[3];
        
        for (int li=0; li<lst.count();li++)
        {
            QStringList lstPoint;
            lstPoint=lstPoint.split(",",lst[li]);
            if (lstPoint.count()!=3) continue;
            
            for (int pi=0; pi<lstPoint.count();pi++)
            {
                QStringList lstXY;
                lstXY=lstXY.split("-",lstPoint[pi]);
                pointListX[pi]=lstXY[0].toInt();
                pointListY[pi]=lstXY[1].toInt();
            }
            
            maskTriangle(m, md, pointListX[0], pointListY[0], pointListX[1], pointListY[1], pointListX[2], pointListY[2]);
            
        }
        delete[] pointListX, pointListY;
    }
    return true;
}

bool dan16::maskTriangle(Matrix *m, int md, int x1, int y1, int x2, int y2, int x3, int y3)
{
    if (md<=0) return false;
    
    if (x1>md || x2>md || x3>md || y1>md || y2>md || y3>md) return false;
    if (x1<1 || x2<1 || x3<1 || y1<1 || y2<1 || y3<1) return false;
    if ( ( x1==x2 && y1==y2) || ( x1==x3 && y1==y3) || ( x3==x2 && y3==y2)) return false;
    
    x1--; y1--;
    x2--; y2--;
    x3--; y3--;
    
    for (int ix=0; ix<md; ix++) for (int iy=0; iy<md; iy++)
    {
        int a = (x1 - ix) * (y2 - y1) - (x2 - x1) * (y1 - iy);
        int b = (x2 - ix) * (y3 - y2) - (x3 - x2) * (y2 - iy);
        int c = (x3 - ix) * (y1 - y3) - (x1 - x3) * (y3 - iy);
        
        if ((a >= 0 && b >= 0 && c >= 0) || (a <= 0 && b <= 0 && c <= 0))
        {
            m->setText(iy,ix,"0");
        }
        
    }
    return true;    
}

//+++
void dan16::readMaskParaFromMaskMatrix( const QString &name )
{
    MD=lineEditMD->text().toInt();
    //+++
    QWidgetList* windows=app(this)->windowsList();
    //+++
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
        if ( windows->at(mm)->isA("Matrix") && windows->at(mm)->name()==name)
        {
            myWidget* mmm=(myWidget*) windows->at(mm);
            if (mmm->windowLabel().contains("DAN::Mask::"+QString::number(MD)))
            {
                QString s=mmm->windowLabel().remove("DAN::Mask::"+QString::number(MD));
                if ( s.contains("|") )
                {
                    //		    s=s.replace("|"," ");
                    s=s.simplifyWhiteSpace();
                    QStringList lst;
                    
                    lst=lst.split("|",s);
                    
                    if (lst.count()==8)
                    {
                        spinBoxLTx->setValue(lst[0].toInt());
                        spinBoxRBx->setValue(lst[1].toInt());
                        spinBoxLTy->setValue(lst[2].toInt());
                        spinBoxRBy->setValue(lst[3].toInt());
                        spinBoxLTxBS->setValue(lst[4].toInt());
                        spinBoxRBxBS->setValue(lst[5].toInt());
                        spinBoxLTyBS->setValue(lst[6].toInt());
                        spinBoxRByBS->setValue(lst[7].toInt());
                    }
                    if (lst.count()==11)
                    {
                        spinBoxLTx->setValue(lst[0].toInt());
                        spinBoxRBx->setValue(lst[1].toInt());
                        spinBoxLTy->setValue(lst[2].toInt());
                        spinBoxRBy->setValue(lst[3].toInt());
                        spinBoxLTxBS->setValue(lst[4].toInt());
                        spinBoxRBxBS->setValue(lst[5].toInt());
                        spinBoxLTyBS->setValue(lst[6].toInt());
                        spinBoxRByBS->setValue(lst[7].toInt());
                        lineEditDeadRows->setText(lst[8]);
                        lineEditDeadCols->setText(lst[9]);
                        lineEditMaskPolygons->setText(lst[10]);
                    }
                    
                    
                }
                
            }
        }
    }
    
}

bool dan16::readDisplay(int &x, int &y)
{
    QString info=app(this)->info->text();
    
    QStringList lst=lst.split(";",info);
    
    QString xs=lst[2].remove("ix=").remove(" ");
    xs=QString::number(xs.toDouble(),'f',3);
    x=(int)xs.toDouble();
    
    
    QString ys=lst[3].remove("iy=").remove(" ");
    ys=QString::number(ys.toDouble(),'f',3);
    y=(int)ys.toDouble();
    
    return true;
}

//+++ check existence of mask and sensitivity matrixes
bool dan16::checkExistenceOfMask(QString MaDe, QString maskToCheck)
{
    QStringList lst;
    findMatrixListByLabel("DAN::Mask::"+MaDe,lst);
    if (!lst.contains(maskToCheck))
    {
        QMessageBox::critical(0, "QtiKWS", "<b>"+maskToCheck+"</b> does not exist!");
        return false;
    }
    return true;
}

bool dan16::checkExistenceOfMaskNoMessage(QString MaDe, QString maskToCheck)
{
    QStringList lst;
    findMatrixListByLabel("DAN::Mask::"+MaDe,lst);
    if (!lst.contains(maskToCheck))
    {
        return false;
    }
    return true;
}

void dan16::updateMaskList()
{
    ImportantConstants();
    
    //mask
    QStringList lst;
    findMatrixListByLabel("DAN::Mask::"+QString::number(MD),lst);
    if (!lst.contains("mask")) lst.prepend("mask");
    QString currentMask;
    
    currentMask=comboBoxMaskFor->currentText();
    comboBoxMaskFor->clear();
    comboBoxMaskFor->insertStringList(lst);
    if (lst.contains(currentMask)) comboBoxMaskFor->setCurrentText(currentMask);
    
}
