/****************************************************************************
** Form implementation generated from reading ui file '../qtiKWS/sans/spheres10/spheres10.ui'
**
** Created: Thu Sep 14 02:32:09 2017
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "spheres10.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qtabwidget.h>
#include <qframe.h>
#include <qlineedit.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include "spheres10.ui.h"

/*
 *  Constructs a spheres10 as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
spheres10::spheres10( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "spheres10" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 510, 300 ) );
    setMaximumSize( QSize( 5100, 3000 ) );
    setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QFont f( font() );
    setFont( f ); 
    spheres10Layout = new QVBoxLayout( this, 11, 6, "spheres10Layout"); 

    textLabelInfo = new QLabel( this, "textLabelInfo" );
    textLabelInfo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo->setMinimumSize( QSize( 0, 20 ) );
    textLabelInfo->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfo->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QFont textLabelInfo_font(  textLabelInfo->font() );
    textLabelInfo->setFont( textLabelInfo_font ); 
    textLabelInfo->setFrameShape( QLabel::Box );
    textLabelInfo->setLineWidth( 1 );
    textLabelInfo->setAlignment( int( QLabel::AlignCenter ) );
    spheres10Layout->addWidget( textLabelInfo );

    sansTab = new QTabWidget( this, "sansTab" );
    sansTab->setEnabled( TRUE );
    sansTab->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 4, sansTab->sizePolicy().hasHeightForWidth() ) );
    sansTab->setMinimumSize( QSize( 485, 220 ) );
    sansTab->setMaximumSize( QSize( 4850, 230 ) );
    sansTab->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 63, 75, 138) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    sansTab->setPalette( pal );

    TabPage = new QWidget( sansTab, "TabPage" );
    TabPageLayout = new QVBoxLayout( TabPage, 11, 6, "TabPageLayout"); 

    frameRAD = new QFrame( TabPage, "frameRAD" );
    frameRAD->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 63, 75, 138) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    frameRAD->setPalette( pal );
    frameRAD->setBackgroundOrigin( QFrame::AncestorOrigin );
    frameRAD->setFrameShape( QFrame::GroupBoxPanel );
    frameRAD->setFrameShadow( QFrame::Sunken );
    frameRADLayout = new QVBoxLayout( frameRAD, 10, 10, "frameRADLayout"); 

    pushButtonRADpath = new QPushButton( frameRAD, "pushButtonRADpath" );
    pushButtonRADpath->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonRADpath->sizePolicy().hasHeightForWidth() ) );
    pushButtonRADpath->setMinimumSize( QSize( 0, 0 ) );
    pushButtonRADpath->setMaximumSize( QSize( 3800, 40 ) );
    QFont pushButtonRADpath_font(  pushButtonRADpath->font() );
    pushButtonRADpath->setFont( pushButtonRADpath_font ); 
    frameRADLayout->addWidget( pushButtonRADpath );

    lineEditPathDAT = new QLineEdit( frameRAD, "lineEditPathDAT" );
    lineEditPathDAT->setEnabled( TRUE );
    lineEditPathDAT->setMinimumSize( QSize( 200, 15 ) );
    lineEditPathDAT->setMaximumSize( QSize( 3800, 25 ) );
    lineEditPathDAT->setPaletteForegroundColor( QColor( 166, 163, 157 ) );
    lineEditPathDAT->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QFont lineEditPathDAT_font(  lineEditPathDAT->font() );
    lineEditPathDAT->setFont( lineEditPathDAT_font ); 
    lineEditPathDAT->setFrameShadow( QLineEdit::Plain );
    lineEditPathDAT->setLineWidth( 1 );
    lineEditPathDAT->setReadOnly( TRUE );
    frameRADLayout->addWidget( lineEditPathDAT );
    TabPageLayout->addWidget( frameRAD );

    layout72 = new QHBoxLayout( 0, 0, 6, "layout72"); 
    spacer46 = new QSpacerItem( 111, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout72->addItem( spacer46 );

    textLabel1_3 = new QLabel( TabPage, "textLabel1_3" );
    textLabel1_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont textLabel1_3_font(  textLabel1_3->font() );
    textLabel1_3_font.setPointSize( 14 );
    textLabel1_3->setFont( textLabel1_3_font ); 
    layout72->addWidget( textLabel1_3 );
    spacer47 = new QSpacerItem( 161, 21, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout72->addItem( spacer47 );
    TabPageLayout->addLayout( layout72 );
    spacer51 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    TabPageLayout->addItem( spacer51 );
    sansTab->insertTab( TabPage, QString::fromLatin1("") );

    TabPage_2 = new QWidget( sansTab, "TabPage_2" );
    TabPageLayout_2 = new QVBoxLayout( TabPage_2, 11, 6, "TabPageLayout_2"); 

    pushButtonMakeList = new QPushButton( TabPage_2, "pushButtonMakeList" );
    pushButtonMakeList->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonMakeList->sizePolicy().hasHeightForWidth() ) );
    pushButtonMakeList->setMaximumSize( QSize( 4500, 40 ) );
    QFont pushButtonMakeList_font(  pushButtonMakeList->font() );
    pushButtonMakeList->setFont( pushButtonMakeList_font ); 
    TabPageLayout_2->addWidget( pushButtonMakeList );

    lineEditFileName = new QLineEdit( TabPage_2, "lineEditFileName" );
    lineEditFileName->setEnabled( FALSE );
    lineEditFileName->setMinimumSize( QSize( 150, 25 ) );
    lineEditFileName->setMaximumSize( QSize( 32767, 25 ) );
    lineEditFileName->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    lineEditFileName->setPalette( pal );
    QFont lineEditFileName_font(  lineEditFileName->font() );
    lineEditFileName->setFont( lineEditFileName_font ); 
    lineEditFileName->setFrameShape( QLineEdit::LineEditPanel );
    lineEditFileName->setFrameShadow( QLineEdit::Sunken );
    lineEditFileName->setLineWidth( 1 );
    TabPageLayout_2->addWidget( lineEditFileName );
    spacer52 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    TabPageLayout_2->addItem( spacer52 );
    sansTab->insertTab( TabPage_2, QString::fromLatin1("") );
    spheres10Layout->addWidget( sansTab );

    layout68 = new QHBoxLayout( 0, 0, 6, "layout68"); 

    textLabelInfoSpheres = new QLabel( this, "textLabelInfoSpheres" );
    textLabelInfoSpheres->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfoSpheres->sizePolicy().hasHeightForWidth() ) );
    textLabelInfoSpheres->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfoSpheres->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfoSpheres->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    textLabelInfoSpheres->setFrameShape( QLabel::Box );
    textLabelInfoSpheres->setTextFormat( QLabel::RichText );
    textLabelInfoSpheres->setAlignment( int( QLabel::WordBreak | QLabel::AlignBottom | QLabel::AlignHCenter ) );
    textLabelInfoSpheres->setIndent( 0 );
    layout68->addWidget( textLabelInfoSpheres );

    textLabelInfoVer = new QLabel( this, "textLabelInfoVer" );
    textLabelInfoVer->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfoVer->sizePolicy().hasHeightForWidth() ) );
    textLabelInfoVer->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfoVer->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfoVer->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    textLabelInfoVer->setFrameShape( QLabel::Box );
    textLabelInfoVer->setAlignment( int( QLabel::AlignCenter ) );
    layout68->addWidget( textLabelInfoVer );

    textLabelInfoVP = new QLabel( this, "textLabelInfoVP" );
    textLabelInfoVP->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfoVP->sizePolicy().hasHeightForWidth() ) );
    textLabelInfoVP->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfoVP->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfoVP->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    textLabelInfoVP->setFrameShape( QLabel::Box );
    textLabelInfoVP->setAlignment( int( QLabel::AlignCenter ) );
    layout68->addWidget( textLabelInfoVP );
    spheres10Layout->addLayout( layout68 );
    spacer53 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    spheres10Layout->addItem( spacer53 );
    languageChange();
    resize( QSize(917, 886).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( lineEditPathDAT, SIGNAL( textChanged(const QString&) ), this, SLOT( forceReadSettings() ) );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
spheres10::~spheres10()
{
    destroy();
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void spheres10::languageChange()
{
    setCaption( tr( "QtiKWS::SPHERES" ) );
    textLabelInfo->setText( tr( "Path >>> Set Location of Spheres-Files <<<" ) );
    pushButtonRADpath->setText( tr( "Set Path to ASCII data" ) );
    lineEditPathDAT->setText( tr( "home" ) );
    textLabel1_3->setText( tr( "SPHERES" ) );
    sansTab->changeTab( TabPage, tr( "Path" ) );
    pushButtonMakeList->setText( tr( "Import of SPHERES-files" ) );
    lineEditFileName->setText( tr( "info" ) );
    sansTab->changeTab( TabPage_2, tr( "Import" ) );
    textLabelInfoSpheres->setText( tr( "SPHERES Tools" ) );
    textLabelInfoVer->setText( tr( "v.10-29.01.14" ) );
    textLabelInfoVP->setText( tr( "Vitaliy Pipich @ JCNS" ) );
}

