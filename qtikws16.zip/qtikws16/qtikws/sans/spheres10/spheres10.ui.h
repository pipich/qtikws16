/***************************************************************************
 File                 : spheres10.ui.h
 Project              : QtiKWS
 --------------------------------------------------------------------
 Copyright            : (C) 2006-2013 by Vitaliy Pipich
 Email (use @ for *)  : v.pipich*gmail.com
 Description          : SPHERES Data Reading Interface
 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *  This program is free software; you can redistribute it and/or modify   *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation; either version 2 of the License, or      *
 *  (at your option) any later version.                                    *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the Free Software           *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor,                    *
 *   Boston, MA  02110-1301  USA                                           *
 *                                                                         *
 ***************************************************************************/

#include "../qtiKWS/src/application.h"
#include "../qtiKWS/src/fileDialogs.h"
#include "../qtiKWS/src/multilayer.h"
#include <qwt_color_map.h> 
#include <qwt_plot_spectrogram.h>
#include <qwt_plot_curve.h>
#include "../qtiKWS/src/Spectrogram.h"

#include "../standart-functions/standartFunctions.h"

#include <gsl/gsl_math.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h> 
#include <math.h>
#include <qdir.h>
#include <qvalidator.h> 
#include <qmessagebox.h>
#include <qpainter.h> 
#include <qfiledialog.h> 
#include <qtextstream.h> 
#include <qaction.h> 
#include <qprocess.h> 

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <qworkspace.h>
#include <qfiledialog.h>
#include <qinputdialog.h>

#include <qmessagebox.h>
#include <qapplication.h>
#include <qsettings.h>

#include <iostream>
//+++   INIT   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void spheres10::init()
{
    
    // signals and slots connections
    connect( pushButtonRADpath, SIGNAL( clicked() ), this, SLOT( buttomRADpath() ) );
    connect( pushButtonMakeList, SIGNAL( clicked() ), this, SLOT( slotMakeList() ) );
    connect( sansTab, SIGNAL( selected(const QString&) ), this, SLOT( tabSelected() ) );
	
    readSettings();
    
    lineEditFileName->hide();
}

//*******************************************
//+++ Destroy
//*******************************************
void spheres10::destroy()
{    
    writeSettings();
}

// ************************************************************************************
// ************************************************************************************
//            Settings Tab
// ************************************************************************************
// ************************************************************************************


//*******************************************
//+++  Read settings at init()
//*******************************************
void spheres10::readSettings()
{
#ifdef Q_OS_MAC // Mac 
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
    
    settings.setPath("JCNS", "QtiKWS", QSettings::User);
    
    bool ok;
    QString ss;
    
    settings.beginGroup("/SPHERES");
    //
    ss=settings.readEntry("/SPHERES_path",0,&ok); if (ok) lineEditPathDAT->setText(ss);
    ss=settings.readEntry("/SPHERES_tabeleName",0,&ok);  if (ok) lineEditFileName->setText(ss);
    //
    settings.endGroup();   
}

//*******************************************
//+++  Write settings at destroy()
//*******************************************
void spheres10::writeSettings()
{
#ifdef Q_OS_MAC // Mac 
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
    
    settings.setPath("JCNS", "QtiKWS", QSettings::User);
    //
    settings.beginGroup("/SPHERES");
    //
    settings.writeEntry("/SPHERES_path",  lineEditPathDAT->text());
    settings.writeEntry("/SPHERES_tabeleName",  lineEditFileName->text());    
    //
    settings.endGroup();
}


//+++  Options: Buttons: DAT & RAD direcrories  ++++++++++++++++++++
void spheres10::buttomRADpath()
{
    QString pppath=lineEditPathDAT->text();
    
    if (pppath=="home") pppath = QDir::home().path();
    
    QString s = QFileDialog::getExistingDirectory(
	    pppath, 
	    this,
	    "get data directory"
	    "Choose a directory");
    if (s)
    {
	lineEditPathDAT->setText(s);
    }
}

//++++++SLOT::Make Table+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void spheres10::slotMakeList()
{        
    QString TableName	= lineEditFileName->text();
    QString DatDir		= lineEditPathDAT->text();
    
    bool ok;
    TableName = QInputDialog::getText(
	    "Table's Generation: all header info", "Enter name of Table:", QLineEdit::Normal,
	    TableName, &ok, this );
    if ( !ok ||  TableName.isEmpty() ) 
    {
	return;
    }
    
    
    int i;
    
    //+++ create table
    Table* tableDat;
    
    //+++ select files
    QFileDialog *fd = new QFileDialog(DatDir,"Make Yours Filter (*.YOURS)",this,"SPHERES - File Import");
    fd->setDir(DatDir);
    fd->setMode( QFileDialog::ExistingFiles );
    fd->setCaption(tr("QtiJCNS - File Import"));
    fd->addFilter("Spheres - data (*)");
    
    if (!fd->exec() == QDialog::Accepted ) return;
    
    lineEditFileName->setText(TableName);
    
    
    QStringList selectedDat=fd->selectedFiles();
    int filesNumber= selectedDat.count();
    
    int startRaw=0;
    
    //+++
    bool exist=false;
    
    //+++
    
    QWidgetList* tableListAll=app(this)->tableList();
    
    //+++
    for (i=0;i<(int)tableListAll->count();i++)  if (tableListAll->at(i) && tableListAll->at(i)->name()==TableName) exist=true;    
    
    if (exist)
    {
	for (i=0;i<(int)tableListAll->count();i++)
	{
	    if (tableListAll->at(i) && tableListAll->at(i)->name()==TableName)
	    {
		tableDat=(Table*)tableListAll->at(i);
		
	    }
	}
	
	
	if (tableDat->numCols()<26) 
	{
	    QMessageBox::critical( 0, "QtiJCNS", "Create new table (# cols)");
	    return;
	}	    
	
	startRaw=tableDat->numRows();
	
    }	  
    else
    {
	tableDat=app(this)->newTable(TableName, 0,26);
    }
    
    //+++
    tableDat->setWindowLabel("SPHERES Headers");    
    app(this)->setListViewLabel(tableDat->name(), "SPHERES Headers");
    
    //+++ Cols Names
    tableDat->setColName(0,"File-Name-Spheres"); tableDat->setColPlotDesignation(0,Table::None);  
    tableDat->setColName(1,"subscan"); tableDat->setColPlotDesignation(1,Table::None);
    tableDat->setColName(2,"Code");tableDat->setColPlotDesignation(2,Table::None);
    tableDat->setColName(3,"q");tableDat->setColPlotDesignation(3,Table::X);
    tableDat->setColName(4,"normal"); tableDat->setColPlotDesignation(4,Table::None);
    tableDat->setColName(5,"det_no");tableDat->setColPlotDesignation(5,Table::None);
    tableDat->setColName(6,"angle");tableDat->setColPlotDesignation(6,Table::None);
    tableDat->setColName(7,"lambda");tableDat->setColPlotDesignation(7,Table::None);
    tableDat->setColName(8,"vzg_velo");tableDat->setColPlotDesignation(8,Table::None);
    tableDat->setColName(9,"vzg_m1");tableDat->setColPlotDesignation(9,Table::None);
    tableDat->setColName(10,"vzg_m1-2");tableDat->setColPlotDesignation(10,Table::None);
    tableDat->setColName(11,"cho_freq");tableDat->setColPlotDesignation(11,Table::None);
    tableDat->setColName(12,"cho_pha");tableDat->setColPlotDesignation(12,Table::None);
    tableDat->setColName(13,"cho_clo");tableDat->setColPlotDesignation(13,Table::None);
    tableDat->setColName(14,"temp");tableDat->setColPlotDesignation(14,Table::None);
    tableDat->setColName(15,"temp_1");tableDat->setColPlotDesignation(15,Table::None);
    tableDat->setColName(16,"temp_set");tableDat->setColPlotDesignation(16,Table::None);
    tableDat->setColName(17,"chan_v0");tableDat->setColPlotDesignation(17,Table::None);
    tableDat->setColName(18,"d_energ");tableDat->setColPlotDesignation(18,Table::None);
    tableDat->setColName(19,"d_weg");tableDat->setColPlotDesignation(19,Table::None);
    tableDat->setColName(20,"d_rdgs");tableDat->setColPlotDesignation(20,Table::None);
    tableDat->setColName(21,"d_speed");tableDat->setColPlotDesignation(21,Table::None);
    tableDat->setColName(22,"d_freq");tableDat->setColPlotDesignation(22,Table::None);
    tableDat->setColName(23,"rangf5v");tableDat->setColPlotDesignation(23,Table::None);    
    tableDat->setColName(24,"f_a_si");tableDat->setColPlotDesignation(24,Table::None);
    tableDat->setColName(25,"v_5v");tableDat->setColPlotDesignation(25,Table::None);
    
    //+++
    tableDat->show();
    
    //+++
    QString fnameOnly;
    
    QString s,ss,nameMatrix;
    int iter;
    //
    for(iter=0; iter<filesNumber;iter++)
    {	
	// Files
	
	QFile f(selectedDat[iter]);
	QTextStream t( &f );
	f.open(IO_ReadOnly);
	
	int lineNum=0;
	
	bool stop=false;
	
	QFileInfo fi( selectedDat[iter]);
	QString currentFileName=fi.baseName();
	
	//+++ sub-scan-calc
	int subScan=0;
	
	//+++ scan
	Table* tableResults;
	
	//+++ Current Q
	QString currentQ;
	do
	{	    
	    tableDat->setNumRows(startRaw+1);
	    
	    //+++ File name
	    tableDat->setText(startRaw,0,currentFileName); 
	    
	    //+++ First line::  subscan
	    s = t.readLine().stripWhiteSpace(); lineNum++;
	    tableDat->setText(startRaw,1,s.remove("subscan "));
	    
	    //+++
	    nameMatrix="SPH"+s.remove("subscan ").stripWhiteSpace()+"-v-";
	    nameMatrix=app(this)->generateUniqueName(nameMatrix);
	    //+++ Second line:: we need?
	    s = t.readLine().stripWhiteSpace(); lineNum++;
	    tableDat->setText(startRaw,2,s); 
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    if (!s.contains("parameter") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++ q	    
	    if (!s.contains("q")) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    currentQ=s.remove("q").stripWhiteSpace();
	    tableDat->setText(startRaw,3,currentQ);
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  normal
	    if (!s.contains("normal") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,4,s.remove("normal").stripWhiteSpace());
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  det_no
	    if (!s.contains("det_no") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,5,s.remove("det_no").stripWhiteSpace());
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  angle
	    if (!s.contains("angle") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,6,s.remove("angle").stripWhiteSpace());
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  lambda
	    if (!s.contains("lambda") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,7,s.remove("lambda").stripWhiteSpace());	 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  vzg_velo
	    if (!s.contains("vzg_velo") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,8,s.remove("vzg_velo").stripWhiteSpace());	 	 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  vzg_m1
	    if (!s.contains("vzg_m1") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,9,s.remove("vzg_m1").stripWhiteSpace());
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  vzg_m1 --	2
	    if (!s.contains("vzg_m1") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,10,s.remove("vzg_m1").stripWhiteSpace());	 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++ cho_freq
	    if (!s.contains("cho_freq") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,11,s.remove("cho_freq").stripWhiteSpace());
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  cho_pha
	    if (!s.contains("cho_pha") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,12,s.remove("cho_pha").stripWhiteSpace());
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  cho_clo
	    if (!s.contains("cho_clo") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,13,s.remove("cho_clo").stripWhiteSpace());
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  temp
	    if (!s.contains("temp") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,14,s.remove("temp").stripWhiteSpace());	 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  temp_1
	    if (!s.contains("temp_1") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,15,s.remove("temp_1").stripWhiteSpace());	 	 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  temp_set
	    if (!s.contains("temp_set") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,16,s.remove("temp_set").stripWhiteSpace());	 
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  chan_v0
	    if (!s.contains("chan_v0") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,17,s.remove("chan_v0").stripWhiteSpace());
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  d_energ
	    if (!s.contains("d_energ") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,18,s.remove("d_energ").stripWhiteSpace());
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++ d_weg
	    if (!s.contains("d_weg") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,19,s.remove("d_weg").stripWhiteSpace());
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  d_rdgs
	    if (!s.contains("d_rdgs") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,20,s.remove("d_rdgs").stripWhiteSpace());
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++ d_speed
	    if (!s.contains("d_speed") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,21,s.remove("d_speed").stripWhiteSpace());
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++ d_freq
	    if (!s.contains("d_freq") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,22,s.remove("d_freq").stripWhiteSpace());
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  rangf5v
	    if (!s.contains("rangf5v") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,23,s.remove("rangf5v").stripWhiteSpace());
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++  f_a_si
	    if (!s.contains("f_a_si") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,24,s.remove("f_a_si").stripWhiteSpace());
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    
	    //+++ v_5v
	    if (!s.contains("v_5v") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    tableDat->setText(startRaw,25,s.remove("v_5v").stripWhiteSpace());
	    
	    //+++
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    //+++
	    if (!s.contains("values") && !stop) 
	    {
		QMessageBox::critical( 0, "QtiJCNS", 
				       "Check Format of File: "+selectedDat[iter-startRaw]+"; line # "+QString::number(lineNum)
				       );
		break; stop=true;
	    }
	    
	    //+++  Read Table +++
	    if (subScan==0)
	    {
		tableResults=app(this)->newTable(nameMatrix, 0,3);
		
		//+++
		tableResults->setWindowLabel("SPHERES datasets");    
		app(this)->setListViewLabel(tableResults->name(), "SPHERES datasets");
		
		
		//+++ Cols Names
		tableResults->setColName(0,"Energy"); 	
		tableResults->setColPlotDesignation(0,Table::X);  
		tableResults->setColComment(0, "Energy [GHz] \nHeader Info in:: " + TableName );
	    }
	    else
	    {
		tableResults->addColumns(2);
		
	    }
	    //+++
	    tableResults->setColName(2*subScan+1,"I"+QString::number(subScan)); 
	    tableResults->setColPlotDesignation(2*subScan+1,Table::Y);
	    tableResults->setColComment(2*subScan+1, "Q="+currentQ+"/A");
	    
	    tableResults->setColName(2*subScan+2,"dI"+QString::number(subScan)); 
	    tableResults->setColPlotDesignation(2*subScan+2,Table::yErr);
	    
	    //+++
	    int Ncur=0;
	    QRegExp rx("((\\-|\\+)?\\d*(\\.|\\,)\\d*((e|E)(\\-|\\+)\\d*)?)");	
	    
	    s = t.readLine().stripWhiteSpace();lineNum++;
	    s.replace(',','.');
	    
	    while(s!="" && !s.contains("#eod") && !s.contains("#nxt") )
	    {
		int pos = 0;
		if ( tableResults->numRows()<(Ncur+1) ) tableResults->setNumRows(Ncur+1);
		
		for (i=0;i<3;i++)
		{
		    pos = rx.search( s, pos );
		    
		    if ( pos > -1 ) 
		    {
			pos  += rx.matchedLength();
			if (i>0) tableResults->setText(Ncur,2*subScan+i,QString::number(rx.cap( 1 ).toDouble(),'E'));
			else 
			    if (subScan==0 ) tableResults->setText(Ncur,2*subScan+i,QString::number(rx.cap( 1 ).toDouble(),'E'));
		    }
		}
		
		Ncur++;
		
		s = t.readLine().stripWhiteSpace();lineNum++;
		s.replace(',','.');  
	    }
	    
	    while (s=="") {s = t.readLine().stripWhiteSpace();lineNum++;}
	    
	    
	    // +++ Hide all files
	    app(this)->hiddenWindows->append(tableResults);
	    tableResults->setHidden();
	    //app->modified();
	    // ---
	    
	    //+++
	    if (s=="#eod") 
	    {
		stop=true;
	    }
	    startRaw++;
	    subScan++;
	    
	} while(!stop);
	
	
	f.close();
	
	
    }  
}



//+++ Tab changed:: show new Title
void spheres10::tabSelected()
{
    QString newLabel=sansTab->label(sansTab->currentPageIndex());
    
    switch ( sansTab->currentPageIndex() )    {
	
    case 0: newLabel+=" >>> Set Location of Spheres-Files <<<";
	break;
    case 1: newLabel+=" >>> Import of SPHERES-Files <<<";	
	break;
    case 2: newLabel+=" >>> Simultaneous Fit for SPHERES is not yet ready <<<";
	break;	
    }
    textLabelInfo->setText(newLabel);
}


void spheres10::forceReadSettings()
{
    if (lineEditPathDAT->text()=="home") readSettings();
}

