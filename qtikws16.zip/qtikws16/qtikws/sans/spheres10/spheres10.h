/****************************************************************************
** Form interface generated from reading ui file '..\qtiKWS\sans\spheres10\spheres10.ui'
**
** Created: Do 14. Sep 01:52:13 2017
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.4   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef SPHERES10_H
#define SPHERES10_H

#include <qvariant.h>
#include <qwidget.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QTabWidget;
class QFrame;
class QPushButton;
class QLineEdit;

class spheres10 : public QWidget
{
    Q_OBJECT

public:
    spheres10( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~spheres10();

    QLabel* textLabelInfo;
    QTabWidget* sansTab;
    QWidget* TabPage;
    QFrame* frameRAD;
    QPushButton* pushButtonRADpath;
    QLineEdit* lineEditPathDAT;
    QLabel* textLabel1_3;
    QWidget* TabPage_2;
    QPushButton* pushButtonMakeList;
    QLineEdit* lineEditFileName;
    QLabel* textLabelInfoSpheres;
    QLabel* textLabelInfoVer;
    QLabel* textLabelInfoVP;

public slots:
    virtual void readSettings();
    virtual void writeSettings();
    virtual void buttomRADpath();
    virtual void slotMakeList();
    virtual void tabSelected();
    virtual void forceReadSettings();

protected:
    QVBoxLayout* spheres10Layout;
    QSpacerItem* spacer53;
    QVBoxLayout* TabPageLayout;
    QSpacerItem* spacer51;
    QVBoxLayout* frameRADLayout;
    QHBoxLayout* layout72;
    QSpacerItem* spacer46;
    QSpacerItem* spacer47;
    QVBoxLayout* TabPageLayout_2;
    QSpacerItem* spacer52;
    QHBoxLayout* layout68;

protected slots:
    virtual void languageChange();

private:
    void init();
    void destroy();

};

#endif // SPHERES10_H
