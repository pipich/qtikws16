//
//  danp16-header.cpp
//  
//
//  Created by Vitaliy Pipich on 02.03.17.
//
//
#include "danp16.h"

#include "../standart-functions/standartFunctions.h"

#include <qstring.h>
#include <qstringlist.h>
#include <qcombobox.h>
#include <qinputdialog.h>
#include <qlineedit.h>
#include <qregexp.h>
#include <qworkspace.h>
#include <qfiledialog.h>
#include <qspinbox.h>
#include <qwidgetlist.h>
#include <qradiobutton.h>
#include <qtoolbutton.h>



void danp16::initTableHeader()
{
    QValueList<int> linesList, orderList, posList;
    headerNamesShort.clear();
    QValueList<bool> activeHeader;
    QStringList headerNames;
    lineEditNumberExtractor->setText("");
    
    //+++
    spinBoxHeaderReaderPeriod->setValue(0);
    spinBoxHeaderReaderOffset->setValue(0);
    
    headerNames<<"Sample-Info[Info]";  	linesList<<16; 	orderList<<0;	posList<<78;	activeHeader<<true;
    headerNames<<"Run-Number[Run]";  	linesList<<11; 	orderList<<1;	posList<<0;	activeHeader<<true;
    
    headerNames<<"Collimation-Length[C]";	linesList<<21; 	orderList<<1;	posList<<0;	activeHeader<<true;
    headerNames<<"Col.-Apperture-X[CA-X]";	linesList<<21; 	orderList<<3;	posList<<0;	activeHeader<<false;
    headerNames<<"Col.-Apperture-Y[CA-Y]";linesList<<21; 	orderList<<4;	posList<<0;	activeHeader<<false;
    
    
    headerNames<<"[Det-X-Pos]";		linesList<<28; 	orderList<<3;	posList<<0;	activeHeader<<false;
    headerNames<<"[Det-Y-Pos]";		linesList<<28; 	orderList<<4;	posList<<0;	activeHeader<<false;
    headerNames<<"[Det-Z-Pos]";		linesList<<28; 	orderList<<2;	posList<<0;	activeHeader<<false;
    headerNames<<"[Det-Offset]";		linesList<<28; 	orderList<<1;	posList<<0;	activeHeader<<false;
    
    headerNames<<"Sample-to-Detector-Distance[D]";	linesList<<-2; orderList<<-1;posList<<-2;	activeHeader<<true; //+++ Calculated
    
    headerNames<<"Wave-Length[Lambda]";	linesList<<-2; 	orderList<<-2;	posList<<0;	activeHeader<<true; //+++ Calculated from FRM
    
    headerNames<<"Slit-Sizes[Beam]";	linesList<<-2; 	orderList<<-2;	posList<<0;	activeHeader<<true;  //+++ 30x30|10x10
    
    headerNames<<"Integral-Intensity[Sum]";	linesList<<62; 	orderList<<1;	posList<<0;	activeHeader<<true;
    headerNames<<"[Duration]";		linesList<<58; 	orderList<<1;	posList<<0;	activeHeader<<true;
    headerNames<<"Count-Rate[cps]";	linesList<<-2; 	orderList<<-2;	posList<<-1;	activeHeader<<true;  //+++ calculated -2/-1
    
    headerNames<<"[Date]";		linesList<<5; 	orderList<<54;	posList<<11;	activeHeader<<false;
    headerNames<<"[Time]";		linesList<<5; 	orderList<<66;	posList<<11;	activeHeader<<false;
    headerNames<<"[Field-1]";		linesList<<38; 	orderList<<1;	posList<<0;	activeHeader<<false;
    headerNames<<"[Field-2]";		linesList<<39; 	orderList<<1;	posList<<0;	activeHeader<<false;
    headerNames<<"[Field-3]";		linesList<<40; 	orderList<<1;	posList<<0;	activeHeader<<false;
    headerNames<<"[Field-4]";		linesList<<41; 	orderList<<1;	posList<<0;	activeHeader<<false;
    headerNames<<"[Sample-Nr]";		linesList<<34; 	orderList<<1;	posList<<0;	activeHeader<<false;
    headerNames<<"[Motor-1]";		linesList<<34; 	orderList<<2;	posList<<0;	activeHeader<<false;
    headerNames<<"[Motor-2]";		linesList<<35; 	orderList<<2;	posList<<0;	activeHeader<<false;
    headerNames<<"[Motor-3]";		linesList<<0; 	orderList<<0;	posList<<0;	activeHeader<<false;
    headerNames<<"[Motor-4]";		linesList<<0; 	orderList<<0;	posList<<0;	activeHeader<<false;
    headerNames<<"[Motor-5]";		linesList<<0; 	orderList<<0;	posList<<0;	activeHeader<<false;
    headerNames<<"[Thickness]";		linesList<<34; 	orderList<<3;	posList<<0;	activeHeader<<true;
    headerNames<<"BeamWin-Xs[SA-X]";	linesList<<34; 	orderList<<4;	posList<<0;	activeHeader<<false;
    headerNames<<"BeamWin-Ys[SA-Y]";	linesList<<34; 	orderList<<5;	posList<<0;	activeHeader<<false;
    headerNames<<"Beamwin-X-Pos[SA-X-Pos]";linesList<<35; 	orderList<<4;	posList<<0;	activeHeader<<false;
    headerNames<<"Beamwin-Y-Pos[SA-Y-Pos]";linesList<<35; orderList<<5;	posList<<0;	activeHeader<<false;
    headerNames<<"[Time-Factor]";		linesList<<34; 	orderList<<6;	posList<<0;	activeHeader<<false;
    headerNames<<"[Comment1]";		linesList<<14; 	orderList<<0;	posList<<78;	activeHeader<<false;
    headerNames<<"[Comment2]";		linesList<<15; 	orderList<<0;	posList<<78;	activeHeader<<false;
    headerNames<<"[Name]";		linesList<<3; 	orderList<<1;	posList<<999;	activeHeader<<false;
    headerNames<<"[Who]";		linesList<<5; 	orderList<<47;	posList<<10;	activeHeader<<false;
    headerNames<<"[Selector]";		linesList<<49; 	orderList<<1;	posList<<0;	activeHeader<<true;
    headerNames<<"[Monitor-1]";		linesList<<49; 	orderList<<2;	posList<<0;	activeHeader<<true;
    headerNames<<"[Monitor-2]";		linesList<<49; 	orderList<<3;	posList<<0;	activeHeader<<true;
    headerNames<<"[Monitor-3]";		linesList<<49; 	orderList<<4;	posList<<0;	activeHeader<<true;
    headerNames<<"[File]";		linesList<<-2; 	orderList<<0;	posList<<0;	activeHeader<<false;  //+++ from file name
    headerNames<<"[RT-number]";		linesList<<45; 	orderList<<1;	posList<<0;	activeHeader<<false;
    headerNames<<"[RT-Time-Factor]";	linesList<<45; 	orderList<<3;	posList<<0;	activeHeader<<false;
    headerNames<<"[RT-Repetitions]";	linesList<<45; 	orderList<<4;	posList<<0;	activeHeader<<false;
    headerNames<<"[RT-Frame-Duration]";	linesList<<69; 	orderList<<2;	posList<<0;	activeHeader<<false;
    headerNames<<"[Sum-vs-Mask]";	linesList<<-2; 	orderList<<0;	posList<<0;	activeHeader<<false;  //+++
    headerNames<<"[Sum-vs-Mask-Dead-Time-Corrected]"; linesList<<-2; orderList<<0; posList<<0;activeHeader<<false;
    headerNames<<"Second-Moment[SumQ2]";linesList<<-2; 	orderList<<0;	posList<<0;	activeHeader<<false;  //+++
    
    int rowNumber=headerNames.count();
    for(int i=0;i<rowNumber;i++) headerNamesShort<<headerNames[i].right(headerNames[i].length()-headerNames[i].find('['));
    
    
    tableHeader->setNumRows(rowNumber);
    tableHeader->setRowLabels(headerNames);
    
    for (int i=0; i<rowNumber; i++)
    {
        //+++
        QCheckTableItem *useHeader = new QCheckTableItem(tableHeader,"" );
        tableHeader->setItem(i,0, useHeader);
        if (activeHeader[i]) useHeader->setChecked(true);
        tableHeader->setText(i,1, QString::number(linesList[i],'f',0));
        tableHeader->setText(i,2, QString::number(orderList[i],'f',0));
        tableHeader->setText(i,3, QString::number(posList[i],'f',0));
    }
    
    
    int numberLinesInHeader=70;
    
    tableHeader->setColumnWidth(0,18);
    //tableHeader->setColumnWidth(2,55);
    //tableHeader->setColumnWidth(3,75);
    xmlHeader();
    yamlHeader();
}


//++++++ SLOT::Make Table +++
void danp16::slotMakeUniHeader()
{
    app(this)->changeFolder("DANP :: Header.Reader");
    
    QString TableName   = textLabelCurrentHeader->text();
    QString DatDir        = lineEditPath->text();
    int splitingNumber=comboBoxNMcolumns->currentItem()+1;
    
    QString infoNumberExtractor=lineEditNumberExtractor->text().remove(" ");
    if (infoNumberExtractor!="" && !infoNumberExtractor.contains("*") && !infoNumberExtractor.contains("#"))
    {
        TableName=infoNumberExtractor;
    }
    else {
        if (!radioButtonNfiles->isChecked() && splitingNumber==1)
        {
            bool ok;
            TableName = QInputDialog::getText(
                                              "Table's Generation: all header info", "Enter name of Table:",
                                              QLineEdit::Normal,
                                              TableName, &ok, this );
            if ( !ok ||  TableName.isEmpty() )
            {
                return;
            }
        }
        else
        {
            bool ok;
            
            TableName = QInputDialog::getText(
                                          "Table name generation ", "Enter Prefix of Table-names:",
                                          QLineEdit::Normal,
                                          TableName, &ok, this );
            if ( !ok )
            {
                return;
            }
        }
    }
    
    textLabelCurrentHeader->setText(TableName);
    
    //+++ select files
    QFileDialog *fd = new QFileDialog(DatDir,"Rawdata (*.DAT *.dat)",this,"Getting File Information");
    fd->setDir(DatDir);
    fd->setMode( QFileDialog::ExistingFiles );
    fd->setCaption(tr("QtiKWS - Getting File Information"));
    fd->addFilter( "All (*)" );
    if (groupBoxXML->isChecked()) fd->addFilter( "XML (*.xml *.XML)" );
    if (groupBoxYAML->isChecked()) fd->addFilter( "YAML (*.yaml *.YAML)" );
    
    if (!fd->exec() == QDialog::Accepted ) return;
    
    QStringList selectedDat=fd->selectedFiles();
    
    if (radioButtonNfiles->isChecked())
    {
        QStringList lst;
        
        for(int i=0; i<selectedDat.count();i++)
        {
            lst.clear();
            lst<<selectedDat[i];
            slotMakeUniHeader(TableName, lst);
        }
    }
    else
    {
        
        
        if (splitingNumber==1)
        {
            slotMakeUniHeader(TableName, selectedDat);
        }
        else
        {
            int numberOfTables=selectedDat.count()/splitingNumber;
            
            QStringList lst;
            
            for(int ii=0; ii<numberOfTables;ii++)
            {	
                lst.clear();
                QFileInfo fi( selectedDat[ii*splitingNumber] );    
                //TableName=fi.baseName(); 
                for(int i=0; i<splitingNumber;i++) lst<<selectedDat[ii*splitingNumber+i];
                slotMakeUniHeader(TableName, lst);
            }
        }
        
    }
    
    app(this)->changeFolder("DANP :: Header.Reader");
}



void danp16::slotMakeUniHeader(QString TableName, QStringList selectedDat)
{
    int splitingNumber=comboBoxNMcolumns->currentItem()+1;
    
    if (radioButtonNfiles->isChecked() || radioButtonNMcolumns->isChecked())
    {
        //+++
        QFileInfo fi( selectedDat[0] );
        QString s=findFileNumberInFileName(lineEditNumberExtractor->text(), fi.baseName());
        s=s.replace("_","-");
        
        if (TableName!="") TableName+="-";
        if (s=="") TableName+=fi.baseName().replace("_","-"); else TableName+=s;
        if (checkTableExistence(TableName)) TableName=generateTableName(TableName, "",  0, true,true);
    }
    
    
    //+++ create table
    Table* tableDat;
    
    int filesNumber= selectedDat.count();
    
    int startRaw=0;
    int startCol=0;
    
    
    if (checkTableExistence(TableName,tableDat) && !radioButtonNfiles->isChecked())
    {
        if (radioButtonNMcolumns->isChecked())
        {
            startRaw=0;
            startCol=tableDat->numCols();
        }
        else
        {
            if (tableDat->numCols()!=headerNamesShort.count())
            {
                QMessageBox::critical( 0, "QtiKWS", "Create new table (# cols)");
                return;
            }
            
            startRaw=tableDat->numRows();
        }
    }
    else  if (checkTableExistence(TableName,tableDat) && radioButtonNfiles->isChecked())
    {
        if (tableDat->numCols()!=headerNamesShort.count())
        {
            return;
        }
        
        startRaw=0;
    }
    else
    {
        if (radioButtonNMcolumns->isChecked())
        {
            tableDat=app(this)->newTable(TableName,0,filesNumber*headerNamesShort.count());
            
        }
        else
            tableDat=app(this)->newTable(TableName,0,headerNamesShort.count());
        
        //+++
        tableDat->setWindowLabel("Info::Table::Uni");
        app(this)->setListViewLabel(tableDat->name(), "Info::Table::uni");
        app(this)->updateWindowLists(tableDat);
        
        QString colName;
        QStringList colType;
        
        
        if (radioButtonNMcolumns->isChecked() &&  filesNumber>1)
        {
            for (int ff=0; ff<filesNumber;ff++ ) for (int i=0;i<headerNamesShort.count();i++)
            {
                if (headerNamesShort[i].contains("_x_") || headerNamesShort[i].contains("_x_e"))
                {
                    colType<<"0";
                    tableDat->setColPlotDesignation( ff*headerNamesShort.count()+i,Table::X);
                }
                else if (headerNamesShort[i].contains("_y_") || headerNamesShort[i].contains("_y_e"))
                {
                    colType<<"0";
                    tableDat->setColPlotDesignation(ff*headerNamesShort.count()+i,Table::Y);
                    //+++
                    QFileInfo fi( selectedDat[ff] );
                    
                    tableDat->setColComment(ff*headerNamesShort.count()+i, fi.fileName());
                }
                else if (headerNamesShort[i].contains("_xErr_") || headerNamesShort[i].contains("_xErr_e"))
                {
                    colType<<"0";
                    tableDat->setColPlotDesignation(ff*headerNamesShort.count()+i,Table::xErr);
                }
                else if (headerNamesShort[i].contains("_yErr_") || headerNamesShort[i].contains("_yErr_e"))
                {
                    colType<<"0";
                    tableDat->setColPlotDesignation(ff*headerNamesShort.count()+i,Table::yErr);
                }
                else if (headerNamesShort[i].contains("_z_") || headerNamesShort[i].contains("_z_e"))
                {
                    colType<<"0";
                    tableDat->setColPlotDesignation(ff*headerNamesShort.count()+i,Table::Z);
                    //+++
                    QFileInfo fi( selectedDat[ff]);
                    
                    tableDat->setColComment(ff*headerNamesShort.count()+i, fi.fileName() );
                }
                else
                {
                    colType<<"1";
                    tableDat->setColPlotDesignation(ff*headerNamesShort.count()+i,Table::None);
                }
                colName=headerNamesShort[i];
                
                colName=colName.remove('[').remove(']').remove("_x_e").remove("_y_e").remove("_z_e").remove("_xErr_e").remove("_yErr_e").remove("_x_").remove("_y_").remove("_z_").remove("_xErr_").remove("_yErr_").remove("_e");
                
                
                QString com=tableHeader->text(i,1).stripWhiteSpace();
                QString com2=tableHeader->text(i,2).stripWhiteSpace();
                
                if (com.contains("col(") && com2=="all" && ff==(filesNumber-1))
                {
                    tableDat->setColName(ff*headerNamesShort.count()+i,colName);
                    tableDat->setColComment(ff*headerNamesShort.count()+i, "all" );
                }
                else tableDat->setColName(ff*headerNamesShort.count()+i,colName+"-"+QString::number(ff+1));
                
            }
        }
        else
        {
            
            for (int i=0;i<headerNamesShort.count();i++)
            {
                
                if (radioButtonOneFile->isChecked())
                {
                    QString s=tableHeader->verticalHeader()->label(i);
                    tableDat->setColComment(i, tableHeader->verticalHeader()->label(i).left(s.find("[")));
                }
                
                //if (tableDat->text(i,3).toInt()>0)
                if (headerNamesShort[i].contains("_x_") || headerNamesShort[i].contains("_x_e"))
                {
                    colType<<"0";
                    tableDat->setColPlotDesignation(i,Table::X);
                }
                else if (headerNamesShort[i].contains("_y_") || headerNamesShort[i].contains("_y_e"))
                {
                    colType<<"0";
                    tableDat->setColPlotDesignation(i,Table::Y);
                    if (radioButtonNfiles->isChecked())
                    {
                        //+++
                        QFileInfo fi( selectedDat[0] );
                        
                        tableDat->setColComment(i, fi.fileName());
                    }
                    
                }
                else if (headerNamesShort[i].contains("_z_") || headerNamesShort[i].contains("_z_e"))
                {
                    colType<<"0";
                    tableDat->setColPlotDesignation(i,Table::Z);
                }
                else if (headerNamesShort[i].contains("_xErr_") || headerNamesShort[i].contains("_xErr_e"))
                {
                    colType<<"0";
                    tableDat->setColPlotDesignation(i,Table::xErr);
                }
                else if (headerNamesShort[i].contains("_yErr_") || headerNamesShort[i].contains("_yErr_e"))
                {
                    colType<<"0";
                    tableDat->setColPlotDesignation(i,Table::yErr);
                }
                else
                {
                    colType<<"1";
                    tableDat->setColPlotDesignation(i,Table::None);
                }
                colName=headerNamesShort[i];
                
                colName=colName.remove('[').remove(']').remove("_x_e").remove("_y_e").remove("_z_e").remove("_xErr_e").remove("_yErr_e").remove("_x_").remove("_y_").remove("_z_").remove("_xErr_").remove("_yErr_").remove("_e");
                tableDat->setColName(i,colName);
                
                
            }
        }
        tableDat->setColumnTypes(colType);
    }
    
    //+++
    tableDat->show();
    
    
    //+++
    QString fnameOnly;
    int skip;
    QString s,ss,nameMatrix;
    
    //+++ Number Lines in Header
    int numberLinesInHeader=1;
    bool containsKeyString=false;
    for(int i=0;i<tableHeader->numRows();i++)
    {
        if (tableHeader->text(i,1).toInt()>numberLinesInHeader) numberLinesInHeader=tableHeader->text(i,1).toInt();
        if (tableHeader->text(i,1).contains("{") && tableHeader->text(i,1).contains("}")) containsKeyString=true;
    }
    
    if ( containsKeyString &&  numberLinesInHeader < lineEditMaxLengthHeader->text().toInt() ) numberLinesInHeader = lineEditMaxLengthHeader->text().toInt();
    
    //+++ Periodisity +++
    int periodicity=spinBoxHeaderReaderPeriod->value();
    int periodicityOffset=spinBoxHeaderReaderOffset->value();
    if (periodicity==0) periodicityOffset=0;
    
    int currentLine=startRaw; // starting raw in table
    
    
    if (groupBoxXML->isChecked())
    {
        QDomDocument	doc;
        QDomElement 	root;
        QDomElement 	element;
        
        QStringList 	lst;
        
        QString 		errorStr;
        QString 		units;
        QString 		ss;
        
        int 		errorLine;
        int 		errorColumn;
        
        double 		currentValue;
        
        int 		repeationsCount, maxRepeationsCount;
        
        //+++
        for(int iter=startRaw; iter<(startRaw+filesNumber);iter++)
        {
            
            
            QFile *xmlFile= new QFile( selectedDat[iter-startRaw] );
            if (!xmlFile->open(IO_ReadOnly)) continue;
            
            
            if (!doc.setContent(xmlFile, true, &errorStr, &errorLine,&errorColumn))
            {
                qWarning("XML file error: line %d, column %d: %s", errorLine, errorColumn,errorStr.ascii());			continue;
            }
            
            root = doc.documentElement();
            
            QFileInfo fi(selectedDat[iter]);
            QString base = fi.baseName();
            
            tableDat->setNumRows(currentLine+1);
            
            repeationsCount=0;
            maxRepeationsCount=1;
            
            int currentLineLocal;
            int colAdd=0;
            
            if (radioButtonNMcolumns->isChecked() &&  filesNumber>1)
            {
                currentLine=0;
                colAdd=(iter-startRaw)*headerNamesShort.count();
            }
            
            for (int colIndex=0; colIndex<headerNamesShort.count();colIndex++)
            {
                currentLineLocal=0;
                
                //+++ read or not
                QCheckTableItem *active = (QCheckTableItem *)tableHeader->item(colIndex, 0);
                //if (!active->isChecked()) continue;
                
                lst.clear();
                //		ss=lineEditXMLbase->text();
                
                ss=tableHeader->text(colIndex,1).remove(" ");
                
                if (ss.contains("../"))
                {
                    int numberBack=ss.contains("../");
                    QStringList lstTemp=lstTemp.split(":",lineEditXMLbase->text().remove(" "));
                    ss="";
                    for (int kk=0;kk<(lstTemp.count()-numberBack);kk++)
                        ss+=lstTemp[kk]+":";
                    ss+=tableHeader->text(colIndex,1).remove("../").remove(" ");
                    ss+=":";
                }
                else
                {
                    ss=lineEditXMLbase->text().remove(" ");
                    ss+=tableHeader->text(colIndex,1).remove(" ");
                }
                
                ss=ss.replace("::",":");ss=ss.replace("::",":");
                
                
                lst.clear();
                lst=lst.split(":",ss);
                repeationsCount=0;
                
                //qWarning("repeationsCount (1): %d",repeationsCount);
                repeationsCount=numberSameEntries(root, lst);
                //qWarning("repeationsCount (2): %d",repeationsCount);
                
                if (tableHeader->text(colIndex,1)=="CONST" || tableHeader->text(colIndex,1)=="FILENAME")
                    repeationsCount=1;
                
                if (repeationsCount<1) continue;
                
                if (maxRepeationsCount<repeationsCount)
                {
                    maxRepeationsCount=repeationsCount;
                    
                    if (tableDat->numRows() < (currentLine+maxRepeationsCount) )
                        tableDat->setNumRows(currentLine+maxRepeationsCount);
                }
                
                for (int j=0;j<repeationsCount;j++)
                {
                    
                    if (tableHeader->text(colIndex,1)!="FILENAME" && tableHeader->text(colIndex,1)!="CONST" && !readXMLentry(root, lst, element,j)) continue;
                    
                    QString attribute=tableHeader->text(colIndex,2).remove(" ");
                    
                    if (tableHeader->text(colIndex,1)=="CONST")
                    {
                        tableDat->setText(currentLine+currentLineLocal,colAdd+colIndex,tableHeader->text(colIndex,2));
                        currentLineLocal++;
                    }
                    else if (tableHeader->text(colIndex,1)=="FILENAME")
                    {
                        tableDat->setText(currentLine+currentLineLocal,colAdd+colIndex,fi.fileName());
                        currentLineLocal++;
                    }
                    else if (attribute=="")
                    {
                        tableDat->setText(currentLine+currentLineLocal,colAdd+colIndex,element.text().simplifyWhiteSpace());
                        currentLineLocal++;
                    }
                    else
                    {
                        if (attribute=="all")
                        {
                            QDomNamedNodeMap map=element.attributes();
                            int numberAttributes=map.count();
                            if (numberAttributes<1) continue;
                            
                            
                            if ((currentLineLocal+numberAttributes)>maxRepeationsCount)
                            {
                                maxRepeationsCount=currentLineLocal+numberAttributes;
                                
                                if (tableDat->numRows() < (currentLine+currentLineLocal+numberAttributes) )
                                    tableDat->setNumRows(currentLine+currentLineLocal+numberAttributes);
                                
                                
                            }
                            
                            for(int aa=0; aa<numberAttributes;aa++)
                            {
                                tableDat->setText(currentLine+currentLineLocal,colAdd+colIndex, map.item(aa).nodeName().stripWhiteSpace()+" = "+map.item(aa).nodeValue().stripWhiteSpace());
                                currentLineLocal++;
                            }
                        }
                        else
                        {
                            tableDat->setText(currentLine+currentLineLocal,colAdd+colIndex,element.attribute(attribute).stripWhiteSpace());
                            currentLineLocal++;
                        }
                    }
                    
                }
                //+++
                
            }
            
            currentLine+=maxRepeationsCount;
            
            
            xmlFile->close();
        }
        
    }
    else   if (groupBoxYAML->isChecked())
    {
        
        QStringList 	lst;
        
        QString 		errorStr;
        QString 		units;
        QString 		ss;
        
        int 		errorLine;
        int 		errorColumn;
        
        double 		currentValue;
        
        int 		repeationsCount, maxRepeationsCount;
        
        //+++
        for(int iter=startRaw; iter<(startRaw+filesNumber);iter++)
        {
            QFileInfo fi(selectedDat[iter]);
            QString base = fi.baseName();
            
            tableDat->setNumRows(currentLine+1);
            
            repeationsCount=0;
            maxRepeationsCount=1;
            
            int currentLineLocal;
            int colAdd=0;
            
            if (radioButtonNMcolumns->isChecked() &&  filesNumber>1)
            {
                currentLine=0;
                colAdd=(iter-startRaw)*headerNamesShort.count();
            }
            
            for (int colIndex=0; colIndex<headerNamesShort.count();colIndex++)
            {
                currentLineLocal=0;
                
                //+++ read or not
                QCheckTableItem *active = (QCheckTableItem *)tableHeader->item(colIndex, 0);
                
                lst.clear();
                
                ss=tableHeader->text(colIndex,1).remove(" ");
                
                ss=ss.replace("::",":");ss=ss.replace("::",":");
                
                lst.clear();
                lst=lst.split(":",ss);
                repeationsCount=0;
                
                //qWarning("repeationsCount (1): %d",repeationsCount);
                repeationsCount=numberSameEntriesYAML(selectedDat[iter-startRaw], lst);
                //qWarning("repeationsCount (2): %d",repeationsCount);
                
                
                if (tableHeader->text(colIndex,1)=="CONST" || tableHeader->text(colIndex,1)=="FILENAME")
                    repeationsCount=1;
                
                if (repeationsCount<1) continue;
                
                if (maxRepeationsCount<repeationsCount)
                {
                    maxRepeationsCount=repeationsCount;
                    
                    if (tableDat->numRows() < (currentLine+maxRepeationsCount) )
                        tableDat->setNumRows(currentLine+maxRepeationsCount);
                }
                
                for (int j=0;j<repeationsCount;j++)
                {
                    QString value="";
                    if (tableHeader->text(colIndex,1)!="FILENAME" && tableHeader->text(colIndex,1)!="CONST" && !readYAMLentry(selectedDat[iter-startRaw], lst, j+1,value)) continue;
                    
                    QString attribute=tableHeader->text(colIndex,2).remove(" ");
                    
                    if (tableHeader->text(colIndex,1)=="CONST")
                    {
                        tableDat->setText(currentLine+currentLineLocal,colAdd+colIndex,tableHeader->text(colIndex,2));
                        currentLineLocal++;
                    }
                    else if (tableHeader->text(colIndex,1)=="FILENAME")
                    {
                        tableDat->setText(currentLine+currentLineLocal,colAdd+colIndex,fi.fileName());
                        currentLineLocal++;
                    }
                    else if (attribute=="")
                    {
                        tableDat->setText(currentLine+currentLineLocal,colAdd+colIndex,value);
                        //			tableDat->setText(currentLine+currentLineLocal,colAdd+colIndex,"test1");
                        currentLineLocal++;
                    }
                    else
                    {
                        if (attribute=="all")
                        {
                            /*
                             
                             QDomNamedNodeMap map=element.attributes();
                             int numberAttributes=map.count();
                             if (numberAttributes<1) continue;
                             
                             
                             if ((currentLineLocal+numberAttributes)>maxRepeationsCount)
                             {
                             maxRepeationsCount=currentLineLocal+numberAttributes;
                             
                             if (tableDat->numRows() < (currentLine+currentLineLocal+numberAttributes) )
                             tableDat->setNumRows(currentLine+currentLineLocal+numberAttributes);
                             
                             
                             }
                             
                             for(int aa=0; aa<numberAttributes;aa++)
                             {
                             tableDat->setText(currentLine+currentLineLocal,colAdd+colIndex, map.item(aa).nodeName().stripWhiteSpace()+" = "+map.item(aa).nodeValue().stripWhiteSpace());
                             currentLineLocal++;
                             }
                             */
                        }
                        else
                        {
                            //			    tableDat->setText(currentLine+currentLineLocal,colAdd+colIndex,element.attribute(attribute).stripWhiteSpace());
                            tableDat->setText(currentLine+currentLineLocal,colAdd+colIndex,"TEST");			    
                            currentLineLocal++;
                        }
                    }
                    
                }
                //+++
                
            }
            
            currentLine+=maxRepeationsCount;
            
        }
        
    }
    else
    {
        //+++
        for(int iter=startRaw; iter<(startRaw+filesNumber);iter++)
        {	
            //+++ Read Header Lines
            QFile f(selectedDat[iter-startRaw]);
            QTextStream t( &f );
            f.open(IO_ReadOnly);
            QFileInfo fi(selectedDat[iter]);
            QString base = fi.baseName();
            
            QStringList headerList;
            int colAdd=0;
            if (radioButtonNMcolumns->isChecked() &&  filesNumber>1)
            {
                currentLine=0; 
                colAdd=(iter-startRaw)*headerNamesShort.count();
            }
            //+++ Offset  lines +++
            QStringList offsetHeader;
            for (int line=0;  line<spinBoxHeaderReaderOffset->value(); line++) offsetHeader<<t.readLine(); 
            
            while (!t.atEnd())
            {
                headerList.clear();
                
                for (int line=1;  line<= numberLinesInHeader; line++) 
                {
                    headerList<<t.readLine();	
                    if (t.atEnd()) break;
                }
                
                if (headerList.count()<numberLinesInHeader) break;
                
                currentLine++;
                if (tableDat->numRows()<currentLine) tableDat->setNumRows(currentLine);
                
                for (int colIndex=0; colIndex<headerNamesShort.count();colIndex++)
                {
                    
                    if (tableHeader->text(colIndex,1)=="FILENAME")
                        
                    {
                        tableDat->setText(currentLine-1,colAdd+colIndex,fi.fileName());
                        continue;
                    }
                    //+++ read or not
                    QCheckTableItem *active = (QCheckTableItem *)tableHeader->item(colIndex, 0);	
                    if (!active->isChecked() && readHeader(headerNamesShort[colIndex],headerList,offsetHeader).toInt()<0) continue;
                    //+++
                    tableDat->setText(currentLine-1,colAdd+colIndex,readHeader(headerNamesShort[colIndex],headerList,offsetHeader));
                    
                }
                
                if (periodicity==0) break;
                for (int line=0;  line<(periodicity-numberLinesInHeader); line++) if (!t.atEnd()) t.readLine(); 
            }
            
            f.close();
         
            // 2017 test
            if (!radioButtonOneFile->isChecked() && tableDat->numRows() > (lineEditMaxLengthHeader->text().toInt() - spinBoxHeaderReaderOffset->value()) )
                tableDat->setNumRows(lineEditMaxLengthHeader->text().toInt() - spinBoxHeaderReaderOffset->value());
            
        }
    }
    
    maximizeWindow(TableName);
    
    if (radioButtonNMcolumns->isChecked() &&  filesNumber>1)
    {
        for (int colIndex=0; colIndex<headerNamesShort.count();colIndex++)
        {
            for (int ff=0; ff<filesNumber;ff++ ) 
            {
                int iMax=headerNamesShort.count();
                for (int i=0;i<iMax;i++)
                {
                    
                    if (headerNamesShort[colIndex].contains("_e]")) 
                    {
                        tableDat->setColNumericFormat(2, 8, ff*headerNamesShort.count()+colIndex);	    
                        tableDat->setColNumericFormat(2, 6, ff*headerNamesShort.count()+colIndex);
                    }
                    
                    QString com=tableHeader->text(colIndex,1).stripWhiteSpace();
                    QString com2=tableHeader->text(colIndex,2).stripWhiteSpace();
                    if (com.contains("col("))
                    {
                        int currentCCpos=0;
                        for (int cc=0; cc<com.contains("col("); cc++)
                        {
                            currentCCpos=com.find("col(",currentCCpos);
                            currentCCpos=com.find(")",currentCCpos);
                            if (com2!="all") com=com.insert(currentCCpos, "-"+QString::number(ff+1));
                        }
                        tableDat->setCommand(ff*headerNamesShort.count()+colIndex, com);
                        tableDat->calculate(ff*headerNamesShort.count()+colIndex, 0, tableDat->numRows()-1);
                        
                        
                        
                    }
                    
                    
                    //+++ read or not
                    QCheckTableItem *active = (QCheckTableItem *)tableHeader->item(colIndex, 0);	
                    if (active->isChecked()) 
                    {
                        tableDat->table()->showColumn(ff*headerNamesShort.count()+colIndex);
                        tableDat->table()->adjustColumn(ff*headerNamesShort.count()+colIndex);
                        tableDat->table()->setColumnWidth(ff*headerNamesShort.count()+colIndex, tableDat->table()->columnWidth(ff*headerNamesShort.count()+colIndex)+10); 
                    }
                    else tableDat->table()->hideColumn(ff*headerNamesShort.count()+colIndex);
                    
                    if ((com.contains("col(") || com.contains("CONST")) && com2=="all" && ff<(filesNumber-1))  tableDat->table()->hideColumn(ff*headerNamesShort.count()+colIndex);
                }		
            }
        }
    }
    else
    {
        for (int colIndex=0; colIndex<headerNamesShort.count();colIndex++)
        {
            
            
            if (headerNamesShort[colIndex].contains("_e]")) 
            {
                tableDat->setColNumericFormat(2, 8, colIndex);	    
                tableDat->setColNumericFormat(2, 6, colIndex);
            }
            
            QString com=tableHeader->text(colIndex,1).stripWhiteSpace();
            if (com.contains("col("))
            {
                tableDat->setCommand(colIndex, com);
                tableDat->calculate(colIndex, 0, tableDat->numRows()-1);
            }
            
            
            //+++ read or not
            QCheckTableItem *active = (QCheckTableItem *)tableHeader->item(colIndex, 0);	
            if (active->isChecked()) 
            {
                tableDat->table()->showColumn(colIndex);
                tableDat->table()->adjustColumn(colIndex);
                tableDat->table()->setColumnWidth(colIndex, tableDat->table()->columnWidth(colIndex)+10); 
            }
            else tableDat->table()->hideColumn(colIndex);
        }
    }
    
    int sampleLength=0;
    for(int i=0;i<tableDat->numRows();i++)
    {
        s=tableDat->text(i,0);
        if (s.length()>sampleLength ) sampleLength=s.length();
    }
    
    
    for(int i=0;i<tableDat->numRows();i++)
    {
        
        s=tableDat->text(i,0);
        while(s.length()<sampleLength)s+=" ";
        tableDat->setText(i,0,s);
    }    
    
    for(int i=tableDat->numCols()-1;i>=0;i--) if (tableDat->table()->isColumnHidden (i))  tableDat->removeCol(i);
    
    
   
    tableDat->notifyChanges();
    
}

//+++ save current HSTR tablr
void danp16::saveCurrentHSTRtable()
{
    if (comboBoxHeaderStructure->currentItem()==0) return;
    else saveCurrentHSTRtable(comboBoxHeaderStructure->currentText());
    readCurrentHSTRtable();
    return;
}

//+++ save NEW HSTR tablr
void danp16::saveNewHSTRtable()
{
    QString newTableName="newtable";
    
    bool ok;
    newTableName = QInputDialog::getText(
                                         "Header table", "Enter name of Table:",
                                         QLineEdit::Normal,
                                         newTableName, &ok, this );
    if ( !ok ||  newTableName.isEmpty() )
    {
        return;
    }
    
    saveCurrentHSTRtable(newTableName);
    
    return;
}

//+++ save current HSTR tablr
void danp16::saveCurrentHSTRtable(QString fileName)
{
    //+++
    QDir dd;
    QString headerPath=app(this)->qtiKwsPath+"/headerFormats";
    headerPath=headerPath.replace("//","/");
    if (!dd.cd(headerPath))
    {
        headerPath=QDir::homeDirPath()+"/headerFormats";
        headerPath=headerPath.replace("//","/");
        
        if (!dd.cd(headerPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/headerFormats");
            dd.cd("./qtiKWS/headerFormats");
        }
    };
    headerPath=dd.absPath();
    
    QFile f(headerPath+"/"+fileName+".HSTR");
    
    
    if ( !f.open( IO_WriteOnly ) )
    {
        //*************************************Log Window Output
        QMessageBox::warning(this,"Could not write to file", tr("qtiKWS::DANP"));
        //*************************************Log Window Output
        return;
    }
    QTextStream stream( &f );
    int numberLines=tableHeader->numRows();
    
    if (groupBoxPeriodicalHeader->isChecked())
        stream<<"{Header-Periodicity-Yes-No} Yes\n";
    else
        stream<<"{Header-Periodicity-Yes-No} No\n";
    stream<<"{Header-Periodicity-Offset} "+QString::number(spinBoxHeaderReaderOffset->value())+"\n";
    stream<<"{Header-Periodicity} "+QString::number(spinBoxHeaderReaderPeriod->value())+"\n";
    
    if (groupBoxXML->isChecked())
        stream<<"{XML-Header-Yes-No} Yes\n";
    else
        stream<<"{XML-Header-Yes-No} No\n";
    
    stream<<"{XML-base} "+lineEditXMLbase->text()+"\n";
    
    if (groupBoxYAML->isChecked())
        stream<<"{YAML-Header-Yes-No} Yes\n";
    else
        stream<<"{YAML-Header-Yes-No} No\n";
    
    stream<<"{Maximal-Number-Lines} "+lineEditMaxLengthHeader->text()+"\n";
    
    if (radioButtonNfiles->isChecked()) stream<<"{Table-Structure} 1\n";
    else if (radioButtonOneFile->isChecked()) stream<<"{Table-Structure} 2\n";
    else  stream<<"{Table-Structure} 3\n";
    
    stream<<"{Merge-Every-X} "+QString::number(comboBoxNMcolumns->currentItem())+"\n";
    
    stream<<"{File-Number-Pattern} "+lineEditNumberExtractor->text()+"\n";
    
    
    for (int i=0; i<numberLines;i++)
    {
        stream<<tableHeader->verticalHeader()->label(i)+"   ";
        //+++
        QCheckTableItem *active = (QCheckTableItem *)tableHeader->item(i, 0);
        if (active->isChecked()) stream<<"[true]   "; else stream<<"[false]   ";
        //+++
        if (groupBoxXML->isChecked() || groupBoxYAML->isChecked())
        {
            stream<<tableHeader->text(i,1)+"   "+tableHeader->text(i,2)+"\n";
        }
        else
        {
            stream<<tableHeader->text(i,1)+"   ";
            stream<<tableHeader->text(i,2)+"   ";
            stream<<tableHeader->text(i,3)+"\n";
        }
    }
    f.close();
    findHeaderFormats();
    
    comboBoxHeaderStructure->setCurrentText(fileName);
    defaultHeader();
    return;
}


//+++ read current HSTR table from file
void danp16::readCurrentHSTRtable()
{
    groupBoxPeriodicalHeader->setChecked(false);periodicalHeader();
    groupBoxXML->setChecked(false);lineEditXMLbase->setText("");
    groupBoxYAML->setChecked(false);
    
    lineEditMaxLengthHeader->setText("");
    lineEditXMLbase->setText("");
    
    radioButtonOneFile->setChecked(true);
    comboBoxNMcolumns->setCurrentItem(0);
    lineEditNumberExtractor->setText("");
    
    defaultHeader();
    if (comboBoxHeaderStructure->currentItem()==0)
    {
        initTableHeader();
        return;
    }
    
    headerNamesShort.clear();
    QString fileName=comboBoxHeaderStructure->currentText();
    
    //+++
    QDir dd;
    QString headerPath=app(this)->qtiKwsPath+"/headerFormats";
    headerPath=headerPath.replace("//","/");
    if (!dd.cd(headerPath))
    {
        headerPath=QDir::homeDirPath()+"/headerFormats";
        headerPath=headerPath.replace("//","/");
        
        if (!dd.cd(headerPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/headerFormats");
            dd.cd("./qtiKWS/headerFormats");
        }
    };
    headerPath=dd.absPath();
    
    QFile f(headerPath+"/"+fileName+".HSTR");
    
    
    if ( !f.open( IO_ReadOnly ) )
    {
        //*************************************Log Window Output
        QMessageBox::warning(this,"Could not read file", tr("qtiKWS::DANP"));
        //*************************************Log Window Output
        return;
    }
    
    
    QTextStream t( &f );
    
    QRegExp rx("((\\-)?\\d+)");
    int pos, indexCurrent;
    
    int boundaryRight, boundaryLeft;
    QString s;
    int rowsNum=0;
    
    tableHeader->setNumRows(rowsNum);
    
    QStringList names, col1, col2, col3;
    QValueList<bool> col0;
    
    while(!t.atEnd())
    {
        s=t.readLine().stripWhiteSpace();
        boundaryRight=s.find("]");
        boundaryLeft=s.find("[");
        
        if (boundaryRight<0)
        {
            if (s.contains("{Header-Periodicity-Yes-No} Yes"))
                groupBoxPeriodicalHeader->setChecked(true);
            
            if (s.contains("{Header-Periodicity-Yes-No} No"))
                groupBoxPeriodicalHeader->setChecked(false);
            
            if (s.contains("{Header-Periodicity-Offset} "))
                spinBoxHeaderReaderOffset->setValue(s.remove("{Header-Periodicity-Offset} ").stripWhiteSpace().toInt());
            if (s.contains("{Header-Periodicity} "))
                spinBoxHeaderReaderPeriod->setValue(s.remove("{Header-Periodicity} ").stripWhiteSpace().toInt());
            
            if (s.contains("{XML-Header-Yes-No} Yes"))
                groupBoxXML->setChecked(true);
            if (s.contains("{XML-Header-Yes-No} No"))
                groupBoxXML->setChecked(false);
            
            if (s.contains("{XML-base} "))
                lineEditXMLbase->setText(s.remove("{XML-base} "));
            
            if (s.contains("{YAML-Header-Yes-No} Yes"))
                groupBoxYAML->setChecked(true);
            if (s.contains("{YAML-Header-Yes-No} No"))
                groupBoxYAML->setChecked(false);
            
            if (s.contains("{Maximal-Number-Lines} "))
                lineEditMaxLengthHeader->setText(s.remove("{Maximal-Number-Lines} "));
            
            if (s.contains("{Table-Structure} "))
            {
                int casex=s.remove("{Table-Structure} ").toInt();
                if (casex==1) radioButtonNfiles->setChecked(true);
                else if (casex==2) radioButtonOneFile->setChecked(true);
                else radioButtonNMcolumns->setChecked(true);
            }
            
            if (s.contains("{Merge-Every-X} "))
                comboBoxNMcolumns->setCurrentItem(s.remove("{Merge-Every-X} ").toInt());
            
            if (s.contains("{File-Number-Pattern} "))
                lineEditNumberExtractor->setText(s.remove("{File-Number-Pattern} "));
            
            continue;
        }
        //+++
        names<<s.left(boundaryRight+1);
        headerNamesShort<<s.mid(boundaryLeft,boundaryRight-boundaryLeft+1);
        //+++
        if (s.contains("[true]")) col0<<true; else col0<<false;
        //+++
        
        if (groupBoxXML->isChecked() || groupBoxYAML->isChecked())
        {
            QStringList lst=lst.split("   ",s.right(s.length()-s.findRev("]")-1).stripWhiteSpace());
            if (lst.count()>0) col1<<lst[0]; else col1<<"";
            if (lst.count()>1) col2<<lst[1]; else col2<<"";
        }
        else
        {
            QStringList lst=lst.split("   ",s.right(s.length()-s.findRev("]")-1).stripWhiteSpace());
            if (lst.count()>0) col1<<lst[0]; else col1<<"";
            if (lst.count()>1) col2<<lst[1]; else col2<<"";
            if (lst.count()>2) col3<<lst[2];else col3<<"";
        }
    }
    
    periodicalHeader();
    //+++
    tableHeader->setNumRows(0);
    tableHeader->setNumRows(names.count());
    tableHeader->setRowLabels(names);
    
    for(int i=0;i<names.count();i++)
    {
        //+++
        QCheckTableItem *useHeader = new QCheckTableItem(tableHeader,"" );
        tableHeader->setItem(i,0, useHeader);
        if (col0[i]==true) useHeader->setChecked(true);
        //+++
        tableHeader->setText(i,1,col1[i]);
        tableHeader->setText(i,2,col2[i]);
        
        if (!groupBoxXML->isChecked() && !groupBoxYAML->isChecked())
        {
            tableHeader->setText(i,3,col3[i]);
        }
    }
    
    f.close();
    findHeaderFormats();
    return;
}


//+++
QString danp16::readHeader(QString paraName, QStringList &header1, QStringList &header2)
{
    QString result;
    int index=headerNamesShort.findIndex(paraName);
    if (index<0) return "-1";
    QString lineS=tableHeader->text(index,1);
    
    if (lineS.toInt()<0) return readHeaderLine(index, lineS, header2);
    else return readHeaderLine(index, lineS, header1);
}

//+++
QString danp16::readHeaderLine(int index, QString lineS, QStringList &header)
{
    QString result;
    
    int line=int(fabs(double(lineS.toInt())));
    
    if (line<1)
    {
        if (lineS.contains("{") && lineS.contains("}"))
        {
            lineS=lineS.remove("{");
            lineS=lineS.remove("}");
            lineS=lineS.stripWhiteSpace();
            if (lineS=="") return "-22";
            
            line=0;
            for (int hh=0; hh<header.count(); hh++ )
            {
                if (header[hh].stripWhiteSpace().left(lineS.length())==lineS)
                {
                    line=hh+1;
                    break;
                }
            }
            
            if (line<1) return "-23";
        }
        else if (lineS=="CONST")
        {
            if (tableHeader->text(index,2)=="all")  return tableHeader->text(index,3);
            else return tableHeader->text(index,2);
        }
        else return "-2";
    }
    else lineS="";
    
    
    QString s=header[line-1];
    if (lineS!="") s=s.right(s.length()-s.find(lineS)-lineS.length());
    
    //+++
    int digitNumber=tableHeader->text(index,2).toInt();
    int numberSymbols=tableHeader->text(index,3).toInt();
    if (numberSymbols==0)
    {
        int pos=0;
        int currentNumber=0;
        QRegExp rx("((\\-|\\+)?\\d\\d*(\\.\\d*)?((E\\-|E\\+)\\d\\d?\\d?\\d?)?)");
        
        s=s.stripWhiteSpace();
        s.replace(",",".");
        s.replace("e","E");
        s.replace("E","E0");
        s.replace("E0+","E+0");
        s.replace("E0-","E-0");
        s.replace("E0","E+0");
        
        while ( pos >= 0 && currentNumber<digitNumber)
        {
            pos = rx.search( s, pos );
            if ( pos <0 ) return "-3";
            
            result=rx.cap( 1 );
            
            if ( ( pos==0 || s[pos-1]==' ' || s[pos-1]=='\t') && ( s[pos+rx.matchedLength()]==' ' || s[pos+rx.matchedLength()]=='\t' ||  pos+rx.matchedLength() == s.length())) currentNumber++;
            
            pos  += rx.matchedLength();
        }
        
        
        return result;
    }
    
    return s.mid(digitNumber,numberSymbols).simplifyWhiteSpace() ;
}


void danp16::defaultHeader()
{
    if (comboBoxHeaderStructure->currentItem()==0) 
    {
        pushButtonsaveCurrentHeaderSTR->setEnabled(false);
        pushButtonHSTRdelete->setEnabled(false);
        pushButtonHSTRitemsDel->setEnabled(false);
        pushButtonAdd->setEnabled(false);
    }
    else 
    {
        pushButtonsaveCurrentHeaderSTR->setEnabled(true);
        pushButtonHSTRdelete->setEnabled(true);
        pushButtonHSTRitemsDel->setEnabled(true);
        pushButtonAdd->setEnabled(true);
    }
}


void danp16::deleteHSTR()
{
    if (comboBoxHeaderStructure->currentItem()==0) 
    {
        return;
    }
    
    QString fileName=comboBoxHeaderStructure->currentText();
    
    //+++
    QDir dd;
    QString headerPath=app(this)->qtiKwsPath+"/headerFormats";
    headerPath=headerPath.replace("//","/");
    if (!dd.cd(headerPath)) 
    {
        headerPath=QDir::homeDirPath()+"/headerFormats";
        headerPath=headerPath.replace("//","/");
        
        if (!dd.cd(headerPath)) 
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/headerFormats"); 	
            dd.cd("./qtiKWS/headerFormats");
        }
    };
    headerPath=dd.absPath();
    
    dd.remove(fileName+".HSTR");
    
    findHeaderFormats();
    defaultHeader();    
    readCurrentHSTRtable();
}

void danp16::deleteAllUncheckedLinesHSTR()
{
    
    if ( QMessageBox::warning( this, "QtiKWS",
                              "You are going to remove all unchecked lines in Header-Definition-Table.\n",
                              "Continue",
                              "Quit", 0, 0, 1 ) ==1) return;
    
    
    int numberLines=tableHeader->numRows();
    
    for (int i=numberLines-1; i>=0;i--)
    {
        //+++
        QCheckTableItem *active = (QCheckTableItem *)tableHeader->item(i, 0);
        if (!active->isChecked())
        {
            tableHeader->removeRow(i);
        }
    }
    saveCurrentHSTRtable();
    readCurrentHSTRtable();
}


void danp16::addLineToHSTR()
{
    bool ok;
    QString fullName = "Full-Name[short-name]";
    fullName=QInputDialog::getText(
                                   "Table's Generation: all header info", "Enter name of Table:",
                                   QLineEdit::Normal,
                                   fullName, &ok, this );
    
    
    if ( !ok ||  fullName.isEmpty() )
    {
        return;
    }
    
    
    int boundaryRight=fullName.find("]");
    int boundaryLeft=fullName.find("[");
    
    QString shortName=fullName.mid(boundaryLeft,boundaryRight-boundaryLeft+1);
    
    if (boundaryRight<0 || boundaryRight<0 || shortName.length()<3) return;
    
    if (headerNamesShort.findIndex(shortName)>=0) return;
    
    tableHeader->insertRows(tableHeader->numRows(),1);
    tableHeader->verticalHeader()->setLabel(tableHeader->numRows()-1,fullName);
    
    QCheckTableItem *useHeader = new QCheckTableItem(tableHeader,"" );
    tableHeader->setItem(tableHeader->numRows()-1,0, useHeader);
    useHeader->setChecked(true);
    tableHeader->setText(tableHeader->numRows()-1,1,"0");
    tableHeader->setText(tableHeader->numRows()-1,2,"0");
    tableHeader->setText(tableHeader->numRows()-1,3,"0");    
    
    saveCurrentHSTRtable();
    readCurrentHSTRtable();
}



void danp16::periodicalHeader()
{
    if (!groupBoxPeriodicalHeader->isChecked())
    {
        spinBoxHeaderReaderOffset->setValue(0);
        spinBoxHeaderReaderPeriod->setValue(0);
    }
}

void danp16::xmlHeader()
{
    QStringList lst;
    if (groupBoxXML->isChecked())
    {
        groupBoxYAML->setChecked(false);
        tableHeader->setColumnWidth(2,75);
        tableHeader->setColumnWidth(3,0);
        //	tableHeader->setColName(1,"XML-tags-sequense");
        groupBoxPeriodicalHeader->setChecked(false);
        periodicalHeader();
        groupBoxPeriodicalHeader->setEnabled(false);
        lst<<"?"<<"XML-Tag-Sequense"<<"Attribute"<<"#-Symbols";
        
        textLabelMLH->hide();
        lineEditMaxLengthHeader->hide();
    }
    else
    {
        tableHeader->setColumnWidth(2,55);
        tableHeader->setColumnWidth(3,75);
        groupBoxPeriodicalHeader->setEnabled(true);
        //	tableHeader->setColName(1,"#-Line");
        lst<<"?"<<"#-Lines"<<"#-Order"<<"#-Symbols";
        
        textLabelMLH->show();
        lineEditMaxLengthHeader->show();
    }
    tableHeader->setColumnLabels(lst);
}

void danp16::yamlHeader()
{
    QStringList lst;
    if (groupBoxYAML->isChecked())
    {
        groupBoxXML->setChecked(false);
        tableHeader->setColumnWidth(2,75);
        tableHeader->setColumnWidth(3,0);
        //	tableHeader->setColName(1,"XML-tags-sequense");
        groupBoxPeriodicalHeader->setChecked(false);
        periodicalHeader();
        groupBoxPeriodicalHeader->setEnabled(false);
        lst<<"?"<<"YAML-Tag-Sequense"<<"Attribute"<<"#-Symbols";
        
        textLabelMLH->hide();
        lineEditMaxLengthHeader->hide();
    }
    else
    {
        tableHeader->setColumnWidth(2,55);
        tableHeader->setColumnWidth(3,75);
        groupBoxPeriodicalHeader->setEnabled(true);
        //	tableHeader->setColName(1,"#-Line");
        lst<<"?"<<"#-Lines"<<"#-Order"<<"#-Symbols";
        
        textLabelMLH->show();
        lineEditMaxLengthHeader->show();
    }
    tableHeader->setColumnLabels(lst);
}

void danp16::vertHeaderTableClicked(int i)
{
    QString oldName=tableHeader->verticalHeader()->label(i);
    
    bool ok;
    QString newName = QInputDialog::getText(
                                            "Change current raw label", "Enter new label:",
                                            QLineEdit::Normal,
                                            oldName, &ok, this );
    if ( !ok ||  newName.isEmpty() )
    {
        return;
    }
    
    tableHeader->verticalHeader()->setLabel(i,newName);
}
