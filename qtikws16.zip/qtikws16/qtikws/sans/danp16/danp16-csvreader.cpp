//
//  dan16-csvreader.cpp
//  
//
//  Created by Vitaliy Pipich on 02.03.17.
//
//

#include "danp16.h"

#include "../standart-functions/standartFunctions.h"
#include "../../src/multilayer.h"

#include <qworkspace.h>
#include <qfiledialog.h>
#include <qlineedit.h>

void  danp16::csvImport()
{
    // current folder
    Folder *cf = ( Folder * ) app(this)->current_folder;
    
    //+++ Initial Check
    QString csvStartingLine = startingLineCSV->text();
    QString tableStartingLine = headerLineCSV->text();
    
    if (csvStartingLine =="" || tableStartingLine=="") return;
    
    //+++ Select files
    QString DatDir		= lineEditPath->text();
    
    bool ok;
    
    //+++ select files
    QFileDialog *fd = new QFileDialog(DatDir,"Make Yours Filter (*.YOURS)",this,"CSV :: Many-Table-Import");
    fd->setDir(DatDir);
    fd->setMode( QFileDialog::ExistingFiles );
    fd->setCaption(tr("QtiKWS - File Import"));
    fd->addFilter("CSV - Many-Table-Import (*.csv)");
    
    if (!fd->exec() == QDialog::Accepted ) return;
    
    QStringList selectedDat=fd->selectedFiles();
    int filesNumber= selectedDat.count();
    
    
    for (int iFiles=0; iFiles<filesNumber; iFiles++)
    {
        
        //+++ Files
        QFile f(selectedDat[iFiles]);
        QTextStream t( &f );
        f.open(IO_ReadOnly);
        
        t.setEncoding(QTextStream::UnicodeUTF8);
        
        //+++
        QFileInfo fi( selectedDat[iFiles]);
        QString currentFileName=fi.baseName();
        
        
        app(this)->changeFolder(cf,true);
        app(this)->changeFolderLocal("CSV :: " +currentFileName);
        //		cf->addFolder("CSV :: " +currentFileName);
        
        //	app(this)->folders->setFocus();
        //+++
        QString s;
        QStringList csvTalbeList, csvTalbeHeaderList;
        int currentTable=0;
        
        bool endf=false;
        //+++ Find First Table
        s = "";
        while (!s.contains(csvStartingLine)) {s = t.readLine(); if (t.atEnd()) {break;endf=true;}}
        
        if (endf) continue;
        
        while (!t.atEnd() )
        {
            currentTable++;
            
            csvTalbeList.clear();
            csvTalbeHeaderList.clear();
            
            csvTalbeHeaderList<<currentFileName;
            csvTalbeHeaderList<<s;
            s = "";
            
            while (!s.contains(tableStartingLine)) {s = t.readLine(); csvTalbeHeaderList<<s; if (t.atEnd()) {break;endf=true;}}
            if (endf) break;
            
            csvTalbeList<<s;
            s = "";
            while (!s.contains(csvStartingLine))
            {s = t.readLine();csvTalbeList<<s; if (t.atEnd()) {break;endf=true;};}
            
            makeCSVtable(csvTalbeList,csvTalbeHeaderList,currentTable);
            if (endf) break;
            
        }
        //	app(this)->showAllFolderWindows();
        //	app(this)->hideAllFolderWindows();
        
    }
    
    
}

void danp16::makeCSVtable(QStringList lstTable, QStringList lstHeader, int currentTable)
{
    QString tableName=lstHeader[0];
    tableName=tableName.remove(" ").replace("_","-");
    if (tableName=="") {return;}
    
    QString pre0="";
    if (currentTable<10) pre0="00";
    else if(currentTable<100) pre0="0";
    
    if (cbSkip->isChecked()) tableName="csv-"+pre0 + QString::number(currentTable);
    else tableName=tableName.prepend("csv-"+pre0 + QString::number(currentTable)+"-");
    tableName+="-";
    
    tableName=app(this)->generateUniqueName(tableName);
    
    if(lstTable.count()<2) {return;}
    
    QStringList colNamesList;
    colNamesList=colNamesList.split(";", lstTable[0].remove(" ").remove(".").remove(","),TRUE );
    
    QStringList colHeadersList;
    colHeadersList=colHeadersList.split(";", lstTable[1].remove(" ").remove(".").remove(","),TRUE );
    
    if(colNamesList.count()!=colHeadersList.count()) {return;}
    
    
    //+++
    QString tableLabel;
    for(int i=0;i<lstHeader.count()-1;i++) tableLabel+=lstHeader[i]+"\n";
    
    
    Table *csvTable=app(this)->newHiddenTable(tableName,tableLabel, 0,colNamesList.count());
    
    //+++
    csvTable->setHeader(colNamesList);
    //+++
    csvTable->setColComments(colHeadersList);
    
    QStringList dataList;
    int lines=0;
    for(int i=2;i<lstTable.count()-1;i++)
    {
        dataList.clear();
        
        dataList=dataList.split(";", lstTable[i],TRUE );
        
        if(colNamesList.count()!=dataList.count()) continue;
        
        lines++;
        csvTable->setNumRows(lines);
        
        for(int j=0;j<dataList.count();j++)csvTable->setText(i-2,j,dataList[j]);
    }
    
    //+++ adjust cols
    for (int tt=0; tt<csvTable->numCols(); tt++)
    {
        csvTable->table()->adjustColumn (tt);
        csvTable->table()->setColumnWidth(tt, csvTable->table()->columnWidth(tt)+10); 
    }
    
    
    // +++ Hide all files
    csvTable->setWindowLabel(tableLabel);    
    app(this)->setListViewLabel(csvTable->name(), tableLabel);
    
    
    csvTable->setStatus ( myWidget::Hidden );
    csvTable->hide();
}
