//
//  danp16-plot1d.cpp
//  
//
//  Created by Vitaliy Pipich on 02.03.17.
//
//

#include "danp16.h"

#include "../standart-functions/standartFunctions.h"
#include "../../src/application.h"
#include "../../src/multilayer.h"
#include "../../src/ErrorBar.h"
#include "../../src/colorBox.h"

#include <qwt_symbol.h>
#include <qwt_color_map.h>
#include <qwt_plot_spectrogram.h>
#include <qwt_plot_curve.h>

#include <qaction.h> 
#include <qwidgetlist.h>
#include <qcombobox.h>
#include <qworkspace.h>
#include <qbuttongroup.h>
#include <qspinbox.h>
#include <qlineedit.h>
#include <qradiobutton.h>
#include <qregexp.h>
#include <qinputdialog.h>

//+++   Plot Range  +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::slotPlotRange()
{
    //
    int i, j;
    int fileFirst=lineEditFileFirst->text().toInt();
    int fileLast=lineEditFileLast->text().toInt();
    int fileStep=lineEditFileStep->text().toInt();
    QString filePreffix=comboBoxSelectPresentationPlot->currentText();
    QString fileSuffix=lineEditFileSuffix->text();
    bool YerrorYN=checkBoxYerror->isChecked();
    bool XerrorYN=checkBoxXerror->isChecked();
    
    QString CurrentLabel	=comboBoxSelectPresentationTo->currentText();
    
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer")) return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>There are no plot layers available in this window.</h4>"
                                "<p><h4>Please add a layer and try again!</h4>"));
        return;
    }
    
    if (!plot)	return;
    
    Graph* g = (Graph*)plot->activeGraph();
    if (!g) return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        app(this)->btnPointer->setOn(true);
        return;
    }
    else
    {
        //
        QString name, nameNew;
        QStringList contents;
        QWidgetList* tables=app(this)->tableList();
        contents=g->curvesList();
        //
        int style = Graph::Scatter;
        //
        app(this)->activeGraph=g;
        QStringList curvesOnPlot=app(this)->activeGraph->curvesList();
        QStringList columnsList1=app(this)->columnsList(Table::Y);
        //
        for (i=fileFirst; i<=fileLast; i+=fileStep)
        {
            name.setNum(i);
            nameNew.setNum(i);
            name=filePreffix+name+fileSuffix;
            nameNew=filePreffix+"-"+nameNew+fileSuffix;
            //
            for (j=0; j < (int)tables->count(); j++ )
                if (tables->at(j)->name() == name || tables->at(j)->name() == nameNew)
                {
                    
                    if (tables->at(j)->name() == nameNew) name=nameNew;
                    Table *  t=(Table *)tables->at(j);
                    
                    
                    if (!contents.contains(name+"_I") && columnsList1.contains(name+"_I"))
                    {
                        
                        g->resizeMy(g->curves());
                        
                        if (!contents.contains(name+"_dI") && app(this)->columnsList(Table::yErr).contains(name+"_dI") && YerrorYN)
                        {
                            g->addErrorBars(t,name+"_Q", name+"_I",t, name+"_dI", 1, 1, 1, QColor(black), TRUE, TRUE,TRUE);
                        }
                        
                        g->insertCurve(t,name+"_I",style);
                        
                        curveLayout cl = Graph::initCurveLayout();
                        
                        int color;
                        
                        
                        int curve = g->curves()-1 ;
                        
                        long key = g->curveKey(curve);
                        if (key == (long) curve ) key++;
                        g->guessUniqueCurveLayout(color, cl.sType);
                        
                        //int color =key%16;
                        //if (color == 13) color = 0; //avoid white invisible curves
                        int shape=key%9;
                        if (shape == 0) shape = 1; //avoid white invisible symbol
                        
                        cl.lCol=color;
                        cl.symCol=color;
                        cl.fillCol=color;
                        cl.aCol=color;
                        cl.lWidth = app(this)->defaultCurveLineWidth;
                        cl.sSize = app(this)->defaultSymbolSize;
                        
                        //cl.sType=shape;
                        
                        g->updateCurveLayout(curve, &cl);
                        
                        if (!contents.contains(name+"_Sigma") && app(this)->columnsList(Table::xErr).contains(name+"_Sigma") && XerrorYN && CurrentLabel=="QI")
                        {
                            g->addErrorBars (t,name+"_Q", name+"_I", t, name+"_Sigma", 0, 2, 10, color, TRUE, TRUE,TRUE);
                            curve = g->curves() - 1;
                            g->updateErrorBars(curve,TRUE,1,1, color, TRUE,TRUE,FALSE);
                        }
                        
                        
                        g->replot();
                        
                    }
                }
        }
        
        
        
    }
}

//+++  Slot Set Titles  +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::slotSetTitels()
{
    QString Label= comboBoxSelectPresentationPlot->currentText();
    
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer"))
        return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>There are no plot layers available in this window.</h4>"
                                "<p><h4>Please add a layer and try again!</h4>"));
        return;
    }
    
    
    if (!plot)
        return;
    
    
    Graph* g = (Graph*)plot->activeGraph();
    
    if (!g)
        return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        app(this)->btnPointer->setOn(true);
        return;
    }
    else
    {
        
        app(this)->activeGraph=g;
        QString s;
        if (Label=="QI")
        {
            s="Q [";
            s+=QChar(197);
            s+="<sup>-1</sup>]";
            g->setAxisTitle(0,s);
            g->setAxisTitle(1,"I [cm<sup>-1</sup>]");
            g->setTitle("I vs. Q");
        }
        else if (Label=="Guinier")
        {
            s="Q<sup>2</sup> [";
            s+=QChar(197);
            s+="<sup>-2</sup>]";
            g->setAxisTitle(0,s);
            g->setAxisTitle(1,"ln(I)");
            g->setTitle("Guinier");
        }
        else if (Label=="Zimm")
        {
            s="Q<sup>2</sup> [";
            s+=QChar(197);
            s+="<sup>-2</sup>]";
            g->setAxisTitle(0,s);
            g->setAxisTitle(1,"I<sup>-1</sup> [cm]");
            g->setTitle("Zimm");
        }
        else if (Label=="Porod")
        {
            g->setAxisTitle(0,"log<sub>10</sub>(Q)");
            g->setAxisTitle(1,"log<sub>10</sub>(I)");
            g->setTitle("Porod");
        }
        else if (Label=="Porod2")
        {
            s="Q<sup>2</sup> [";
            s+=QChar(197);
            s+="<sup>-2</sup>]";
            g->setAxisTitle(0,s);
            s="IQ<sup>4</sup> [cm<sup>-1</sup>";
            s+=QChar(197);
            s+="<sup>-4</sup>]";
            g->setAxisTitle(1,s);
            g->setTitle("Porod2");
        }
        else if (Label=="logI")
        {
            s="Q [";
            s+=QChar(197);
            s+="<sup>-1</sup>]";
            g->setAxisTitle(0,s);
            g->setAxisTitle(1,"log<sub>10</sub>(I)]");
            g->setTitle("log[I(Q)] vs. Q");
        }
        else if (Label=="logQ")
        {
            g->setAxisTitle(0,"log<sub>10</sub>(Q)");
            g->setAxisTitle(1,"I [cm<sup>-1</sup>]");
            g->setTitle("I(Q) vs.  log[Q]");
        }
        else if (Label=="Debye")
        {
            s="Q<sup>2</sup> [";
            s+=QChar(197);
            s+="<sup>-2</sup>]";
            g->setAxisTitle(0,s);
            g->setAxisTitle(1,"I<sup>-1/2</sup> [cm<sup>1/2</sup>]");
            g->setTitle("Debye");
        }
        else if (Label=="1Moment")
        {
            s="Q [";
            s+=QChar(197);
            s+="<sup>-1</sup>]";
            g->setAxisTitle(0,s);
            s="IQ [";
            s+=QChar(197);
            s+="<sup>-1</sup>cm<sup>-1</sup>]";
            g->setAxisTitle(1,s);
            g->setTitle("1st Moment");
        }
        else if (Label=="2Moment")
        {
            s="Q [";
            s+=QChar(197);
            s+="<sup>-1</sup>]";
            g->setAxisTitle(0,s);
            s="IQ<sup>2</sup> [";
            s+=QChar(197);
            s+="<sup>-1</sup>cm<sup>-2</sup>]";
            g->setAxisTitle(1,s);
            g->setTitle("2nd Moment");
        }
        else if (Label=="Kratky")
        {
            s="Q [";
            s+=QChar(197);
            s+="<sup>-1</sup>]";
            g->setAxisTitle(0,s);
            s="IQ<sup>2</sup> [";
            s+=QChar(197);
            s+="<sup>-1</sup>cm<sup>-2</sup>]";
            g->setAxisTitle(1,s);
            g->setTitle("Kratky Plot");
        }
        else if (Label=="GuinierRod")
        {
            s="Q<sup>2</sup> [";
            s+=QChar(197);
            s+="<sup>-2</sup>]";
            g->setAxisTitle(0,s);
            g->setAxisTitle(1,"ln(IQ)");
            g->setTitle("Guinier: Rod");
        }
        else if (Label=="GuinierPlate")
        {
            s="Q<sup>2</sup> [";
            s+=QChar(197);
            s+="<sup>-2</sup>]";
            g->setAxisTitle(0,s);
            g->setAxisTitle(1,"ln(IQ<sup>2</sup>)");
            g->setTitle("Guinier: Plate");
        }
    }
}

//+++  Slot Clear Plot  +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::slotCLEAR()
{
    int i,k;
    int fileFirst=lineEditFileFirst->text().toInt();
    int fileLast=lineEditFileLast->text().toInt();
    int fileStep=lineEditFileStep->text().toInt();
    QString filePreffix=comboBoxSelectPresentationPlot->currentText();
    QString fileSuffix=lineEditFileSuffix->text();
    
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer"))
        return;
    
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>There are no plot layers available in this window.</h4>"
                                "<p><h4>Please add a layer and try again!</h4>"));
        return;
    }
    
    
    if (!plot)
        return;
    
    
    Graph* g = (Graph*)plot->activeGraph();
    if (!g)
        return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        app(this)->btnPointer->setOn(true);
        return;
    }
    else
    {
        QString name,nameNew;
        //
        for (i=fileFirst; i<=fileLast; i+=fileStep)
        {
            name.setNum(i);
            nameNew.setNum(i);
            name=filePreffix+name+fileSuffix;
            nameNew=filePreffix+"-"+nameNew+fileSuffix;
            //
            QStringList associations=g->plotAssociations();
            //
            for (k=0; k<int(associations.count()); k++)
            {
                QString ass = associations[k];
                if (ass.contains(name+"_I")) g->removeCurve(ass);
                if (ass.contains(nameNew+"_I")) g->removeCurve(ass);
            }
        }
    }
}

//+++  Log-Log  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::slotLogLog()
{
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer"))
        return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>There are no plot layers available in this window.</h4>"
                                "<p><h4>Please add a layer and try again!</h4>"));
        return;
    }
    
    
    if (!plot) return;
    
    Graph* g = (Graph*)plot->activeGraph();
    if (!g) return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        app(this)->btnPointer->setOn(true);
        return;
    }
    
    
    if (buttonGroupLogLog->isChecked())
    {
        g->setScale(QwtPlot::xBottom, double(pow(10.0, double(spinBoxLogMinX->value()))), double(1.2*pow(10.0, double(spinBoxLogMaxX->value()))), 0, 10, 9, 1,false);
        g->setScale(QwtPlot::yLeft, double(pow(10.0, double(spinBoxLogMinY->value()))), double(1.2*pow(10.0, double(spinBoxLogMaxY->value()))), 0, 10, 9, 1,false);
        g->setScale(QwtPlot::xTop, double(pow(10.0, double(spinBoxLogMinX->value()))), double(1.2*pow(10.0, double(spinBoxLogMaxX->value()))), 0, 10, 9, 1,false);
        g->setScale(QwtPlot::yRight, double(pow(10.0, double(spinBoxLogMinY->value()))), double(1.2*pow(10.0, double(spinBoxLogMaxY->value()))), 0, 10, 9, 1,false);
    }
    else
    {
        double minX, maxX, minY, maxY;
        
        minmaxPositiveXY(g, minX, maxX, minY, maxY, true, true);
        
        g->setScale(QwtPlot::xBottom, minX, maxX, 0, 10, 9, 1,false);
        g->setScale(QwtPlot::yLeft, minY, maxY, 0, 10, 9, 1,false);
        g->setScale(QwtPlot::xTop, minX, maxX, 0, 10, 9, 1,false);
        g->setScale(QwtPlot::yRight, minY, maxY, 0, 10, 9, 1,false);
    }
    g->setLabelsNumericFormat(QwtPlot::yLeft, 3, 0, "");
    g->setLabelsNumericFormat(QwtPlot::xBottom, 3, 0, "");
    
    g->setAxisTicksLength(QwtPlot::yLeft, 3, 3,5, 9);
    g->setAxisTicksLength(QwtPlot::xBottom, 3, 3,5, 9);
    
    g->setAxisTicksLength(QwtPlot::yRight, 3, 3,5, 9);
    g->setAxisTicksLength(QwtPlot::xTop, 3, 3,5, 9);
    
    QStringList l;
    l<<"1"<<"1"<<"1"<<"1"<<"1";
    g->enableAxes(l);
    l.clear();
    
    l<<"1"<<"0"<<"1"<<"0"<<"0"<<"0";
    g->setEnabledTickLabels(l);
    //g->setTopAxisTitle("ddd");
    
    
    g->drawAxesBackbones(true);
    
    g->emitModified();
    g->replot();    
    
    g->drawAxesBackbones(false);
    
    g->emitModified();
    g->replot();    
    
    //	g->updatePlot();
    
}

//+++  Lin-lin  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::slotLinLin()
{    
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer")) return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>There are no plot layers available in this window.</h4>"
                                "<p><h4>Please add a layer and try again!</h4>"));
        return;
    }
    
    if (!plot) return;
    
    Graph* g = (Graph*)plot->activeGraph();
    if (!g) return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        app(this)->btnPointer->setOn(true);
        return;
    }
    else
    {
        double minX, maxX, minY, maxY;
        minmaxPositiveXY(g, minX, maxX, minY, maxY, false, false);
        
        g->setScale(QwtPlot::xBottom, minX, maxX, 0, 10, 5, 0,false);
        g->setScale(QwtPlot::yLeft,minY, maxY, 0, 10, 5, 0,false);
        g->setScale(QwtPlot::xTop,minX, maxX, 0, 10, 5, 0,false);
        g->setScale(QwtPlot::yRight,minY, maxY, 0, 10, 5, 0,false);
        
        //	g->setScale(QwtPlot::xBottom, 0, 0.2, 0, 3, 9, 0,false);
        //	g->setScale(QwtPlot::yLeft,0, 100, 0, 7, 9, 0,false);
        //	g->setScale(QwtPlot::xTop,0, 0.2, 0, 3, 9, 0,false);
        //	g->setScale(QwtPlot::yRight,0, 100, 0, 7, 9, 0,false);
        
        
        g->setLabelsNumericFormat(QwtPlot::xBottom, 0, 0, "");
        g->setLabelsNumericFormat(QwtPlot::yLeft, 0, 0, "");
        
        g->setAxisTicksLength(QwtPlot::yLeft, 3, 3,5, 9);
        g->setAxisTicksLength(QwtPlot::xBottom, 3, 3,5, 9);
        
        g->drawAxesBackbones(true);
        
        g->emitModified();
        g->replot();    
        
        g->drawAxesBackbones(false);
        
        
        g->emitModified();
        g->replot();      
        //g->updatePlot();
        
    }
}

void danp16::plotByFilter()
{
    //
    int i;
    
    bool YerrorYN=checkBoxYerror->isChecked();
    bool XerrorYN=checkBoxXerror->isChecked();
    
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer")) return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>There are no plot layers available in this window.</h4>"
                                "<p><h4>Please add a layer and try again!</h4>"));
        return;
    }
    
    if (!plot)	return;
    
    Graph* g = (Graph*)plot->activeGraph();
    if (!g) return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        app(this)->btnPointer->setOn(true);
        return;
    }
    
    QStringList columnsListAll=app(this)->columnsList(Table::Y);
    QStringList columnsListOnPlot=g->curvesList();
    // QWidgetList* tables=app(this)->tableList();
    
    QStringList toPlot;
    
    QRegExp rx(lineEditPlotFilter->text());
    rx.setWildcard( TRUE );
    
    if (radioButtonPlotCurveNames->isChecked())
    {
        for (i=0;i<columnsListAll.count();i++)
        {
            if ( rx.exactMatch(columnsListAll[i]) && !columnsListOnPlot.contains(columnsListAll[i]) )
            {
                toPlot<<columnsListAll[i];
            }
        }
    }
    else if (radioButtonPlotTableNames->isChecked())
    {
        for (i=0;i<columnsListAll.count();i++)
        {
            if ( rx.exactMatch(columnsListAll[i].left(columnsListAll[i].find('_'))) && !columnsListOnPlot.contains(columnsListAll[i]) )
            {
                toPlot<<columnsListAll[i];
            }
        }
    }
    else if (radioButtonPlotCurveLabels->isChecked())
    {
        for (i=0;i<columnsListAll.count();i++)
        {
            Table *table;
            int xColIndex, yColIndex, dxColIndex, dyColIndex;
            findTable(columnsListAll[i], table, xColIndex, yColIndex, dxColIndex, dyColIndex);
            
            if ( rx.exactMatch(table->colComment(yColIndex)) && !columnsListOnPlot.contains(columnsListAll[i]) )
            {
                toPlot<<columnsListAll[i];
            }
        }
    }
    else if (radioButtonPlotTableLabels->isChecked())
    {
        for (i=0;i<columnsListAll.count();i++)
        {
            Table *table;
            int xColIndex, yColIndex, dxColIndex, dyColIndex;
            findTable(columnsListAll[i], table, xColIndex, yColIndex, dxColIndex, dyColIndex);
            
            if (  rx.exactMatch(table->windowLabel()) && !columnsListOnPlot.contains(columnsListAll[i]) )
            {
                toPlot<<columnsListAll[i];
            }
        }
    }
    else return;
    
    
    toPlot.sort();
    //
    int style = Graph::Scatter;
    
    //
    for (i=0; i<toPlot.count(); i++)
    {
        Table *table;
        int xColIndex, yColIndex, dxColIndex, dyColIndex;
        findTable(toPlot[i], table, xColIndex, yColIndex, dxColIndex, dyColIndex);
        
        QString tableName=toPlot[i].left(toPlot[i].find('_'));
        
        g->resizeMy(g->curves());
        
        if (dyColIndex>0 && YerrorYN && xColIndex>=0 && !columnsListOnPlot.contains(table->colName(dyColIndex)))
        {
            g->addErrorBars(table,table->colName(xColIndex), toPlot[i],table,table->colName(dyColIndex), 1, 1, 1, QColor(black), TRUE, TRUE,TRUE);
        }
        
        g->insertCurve(table,toPlot[i],style);
        
        curveLayout cl = Graph::initCurveLayout();
        
        int color;
        
        
        int curve = g->curves()-1 ;
        
        long key = g->curveKey(curve);
        if (key == (long) curve ) key++;
        g->guessUniqueCurveLayout(color, cl.sType);
        
        //int color =key%16;
        //if (color == 13) color = 0; //avoid white invisible curves
        int shape=key%9;
        if (shape == 0) shape = 1; //avoid white invisible symbol
        
        cl.lCol=color;
        cl.symCol=color;
        cl.fillCol=color;
        cl.aCol=color;
        cl.lWidth = app(this)->defaultCurveLineWidth;
        cl.sSize = app(this)->defaultSymbolSize;
        
        //cl.sType=shape;
        
        g->updateCurveLayout(curve, &cl);
        
        if (dxColIndex>0 &&  XerrorYN && !columnsListOnPlot.contains(table->colName(dxColIndex)))
        {
            g->addErrorBars(table,table->colName(xColIndex), toPlot[i],table, table->colName(dxColIndex), 0, 2, 10, color, TRUE, TRUE,TRUE);
            curve = g->curves() - 1;
            g->updateErrorBars(curve,TRUE,1,1, color, TRUE,TRUE,FALSE);
        }
        
        
        g->replot();
        
    }
}


void danp16::removeByFilter()
{
    
    //
    int i;
    
    bool YerrorYN=checkBoxYerror->isChecked();
    bool XerrorYN=checkBoxXerror->isChecked();
    
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer")) return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>There are no plot layers available in this window.</h4>"
                                "<p><h4>Please add a layer and try again!</h4>"));
        return;
    }
    
    if (!plot)	return;
    
    Graph* g = (Graph*)plot->activeGraph();
    if (!g) return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        app(this)->btnPointer->setOn(true);
        return;
    }
    
    
    QStringList columnsListOnPlot=g->curvesList();
    // QWidgetList* tables=app(this)->tableList();
    
    QStringList fromPlot;
    
    QRegExp rx(lineEditPlotFilter->text());
    rx.setWildcard( TRUE );
    
    if (radioButtonPlotCurveNames->isChecked())
    {
        for (i=0;i<columnsListOnPlot.count();i++)
        {
            if ( rx.exactMatch(columnsListOnPlot[i]))
            {
                fromPlot<<columnsListOnPlot[i];
            }
        }
    }
    else if (radioButtonPlotTableNames->isChecked())
    {
        for (i=0;i<columnsListOnPlot.count();i++)
        {
            if ( rx.exactMatch(columnsListOnPlot[i].left(columnsListOnPlot[i].find('_'))) )
            {
                fromPlot<<columnsListOnPlot[i];
            }
        }
    }
    else if (radioButtonPlotCurveLabels->isChecked())
    {
        for (i=0;i<columnsListOnPlot.count();i++)
        {
            Table *table;
            int xColIndex, yColIndex, dxColIndex, dyColIndex;	    
            findTable(columnsListOnPlot[i], table, xColIndex, yColIndex, dxColIndex, dyColIndex);
            
            if ( rx.exactMatch(table->colComment(yColIndex)))
            {
                fromPlot<<columnsListOnPlot[i];
            }
        }
    }
    else if (radioButtonPlotTableLabels->isChecked())
    {
        for (i=0;i<columnsListOnPlot.count();i++)
        {
            Table *table;
            int xColIndex, yColIndex, dxColIndex, dyColIndex;	    
            findTable(columnsListOnPlot[i], table, xColIndex, yColIndex, dxColIndex, dyColIndex);
            
            if (  rx.exactMatch(table->windowLabel()) )
            {
                fromPlot<<columnsListOnPlot[i];
            }
        }
    }
    else return;
    
    
    
    
    for (i=0; i<fromPlot.count(); i++)
    {
        g->removeCurve(fromPlot[i]);
        
    }
}


void danp16::addNewLegend()
{
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer")) return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>There are no plot layers available in this window.</h4>"
                                "<p><h4>Please add a layer and try again!</h4>"));
        return;
    }
    
    if (!plot) return;
    
    Graph* g = (Graph*)plot->activeGraph();
    if (!g) return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        return;
    }
    
    QStringList columnsListOnPlot=g->curvesList();
    
    int i;
    QString legend;
    
    for (i=0; i<columnsListOnPlot.count();i++)
    {
        QwtPlotCurve *c = g->curve(i);
        if (!c)
            return;
        
        int curveType = g->curveType(i);
        
        if (curveType == Graph::Scatter || curveType == Graph::Line)
        {
            Table *table;
            int xColIndex, yColIndex, dxColIndex, dyColIndex;
            findTable(columnsListOnPlot[i], table, xColIndex, yColIndex, dxColIndex, dyColIndex);
            
            
            if (radioButtonPlotCurveNames->isChecked())
            {
                legend+="\\c{"+ QString::number(i+1)+"} " +    columnsListOnPlot[i] +"\n";
            }
            else if (radioButtonPlotTableNames->isChecked())
            {
                legend+="\\c{"+ QString::number(i+1)+"} " +    columnsListOnPlot[i].left(columnsListOnPlot[i].find("_")) +"\n";
            }
            else if (radioButtonPlotCurveLabels->isChecked())
            {
                legend+="\\c{"+ QString::number(i+1)+"} " +    table->colComment(yColIndex) +"\n";
            }
            else if (radioButtonPlotTableLabels->isChecked())
            {
                legend+="\\c{"+ QString::number(i+1)+"} " +    table->windowLabel() +"\n";
            }
            else return;
            
            
            
            
            
        } 
    }
    if (g) g->newLegend(legend);	
    g->replot();
}

bool danp16::findTable(QString curveName, Table* &table, int &xColIndex, int &yColIndex,int &dxColIndex, int &dyColIndex )
{
    int i, ixy;
    bool exist=false;
    
    xColIndex=-1;
    dxColIndex=-1;
    dyColIndex=-1;
    
    QString tableName=curveName.left(curveName.find("_",0));
    QString colName=curveName.remove(tableName+"_");
    
    QWidgetList *windows = app(this)->windowsList();
    
    for (i=0;i<(int)windows->count();i++)
    {
        if (windows->at(i) && windows->at(i)->isA("Table") && windows->at(i)->name()==tableName)
        {
            table=(Table*)windows->at(i);
            yColIndex=table->colIndex(colName);
            
            bool xSearch=true;
            ixy=yColIndex-1;
            while(xSearch && ixy>=0)
            {
                if (table->colPlotDesignation(ixy)==1)
                {
                    xColIndex=ixy;
                    xSearch=false;
                }
                else ixy--;
            }
            exist=true;
            
            ixy=yColIndex+1;
            xSearch=true;
            while( xSearch && ixy<table->numCols() )
            {
                if (table->colPlotDesignation(ixy)==5)
                {
                    dyColIndex=ixy;
                    xSearch=false;
                }
                else ixy++;
            }
            
            if (xColIndex>=0)
            {
                ixy=xColIndex+1;
                xSearch=true;
                while( xSearch && ixy<table->numCols() )
                {
                    if (table->colPlotDesignation(ixy)==4)
                    {
                        dxColIndex=ixy;
                        xSearch=false;
                    }
                    else ixy++;
                }
            }
        }
    }
    
    return exist;
}


void danp16::symbolSchemChanged()
{
    
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer")) return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>There are no plot layers available in this window.</h4>"
                                "<p><h4>Please add a layer and try again!</h4>"));
        return;
    }
    
    if (!plot) return;
    
    Graph* g = (Graph*)plot->activeGraph();
    if (!g) return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        return;
    }
    
    //+++
    QDir dd;
    QString symbolPath=app(this)->qtiKwsPath+"/symbolMaps";
    symbolPath=symbolPath.replace("//","/");
    if (!dd.cd(symbolPath))
    {
        symbolPath=QDir::homeDirPath()+"/symbolMaps";
        symbolPath=symbolPath.replace("//","/");
        
        if (!dd.cd(symbolPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/symbolMaps");
            dd.cd("./qtiKWS/symbolMaps");
        }
    };
    symbolPath=dd.absPath();
    
    QValueList<int> stype, size, fillYN, fillColor, edgeColor, EdgeThickness;
    int numberColors=0;
    
    //+++ Read File
    QFile f(symbolPath+"/"+comboBoxSchema1D->currentText()+".SYM") ;
    if ( !f.open( IO_ReadOnly ) ) return;
    
    QTextStream t( &f );
    
    QString s;
    
    QRegExp rx("(\\d+)");
    int pos, NN, currentValue;
    
    
    
    int stypeS, sizeS, fillYNS, fillColorS, edgeColorS, EdgeThicknessS;
    //+++  default parameters  +++
    stypeS=0;
    sizeS=8;
    fillYNS=1;
    fillColorS=1;
    edgeColorS=1;
    EdgeThicknessS=1;
    //+++
    
    int N=0;
    QStringList lst;
    
    
    while (!t.atEnd())
    {
        s=t.readLine().simplifyWhiteSpace();
        lst.clear();
        lst=lst.split(" ",s);
        
        if (lst.count()>0) stypeS=lst[0].toInt();
        if (lst.count()>1) { fillColorS=lst[1].toInt(); edgeColorS=lst[1].toInt();};
        if (lst.count()>2) edgeColorS=lst[2].toInt();
        if (lst.count()>3) sizeS=lst[3].toInt();
        if (lst.count()>4) EdgeThicknessS=lst[4].toInt();
        if (lst.count()>5) fillYNS=lst[5].toInt();
        
        numberColors++;
        stype<<stypeS;
        size<<sizeS;
        fillYN<<fillYNS;
        fillColor<<fillColorS;
        edgeColor<<edgeColorS;
        EdgeThickness<<EdgeThicknessS;
    }
    
    f.close();
    
    if (numberColors==0) return;
    
    QStringList columnsListOnPlot=g->curvesList();
    
    int scatterCounter=0;
    int xErrCounter=0;
    int yErrCounter=0;
    int lineCounter=0;
    int scatLineCounter=0;
    int i;
    for (i=0; i<columnsListOnPlot.count();i++)
    {
        QwtPlotCurve *c = g->curve(i);
        if (!c)
            return;
        
        int curveType = g->curveType(i);
        
        
        //++++++++++  Error-Bars  ++++++++++++++
        if (comboBoxSchemaAim->currentText()=="error-bars" && curveType == Graph::ErrorBars)
        {
            QwtErrorPlotCurve *err = (QwtErrorPlotCurve*)g->curve(i);
            if (err)
            {
                if (err->xErrors())
                {
                    g->updateErrorBars(i, true, EdgeThickness[xErrCounter],  0, ColorBox::color(edgeColor[xErrCounter]), true, true,FALSE);
                    xErrCounter++;
                    if (xErrCounter>=numberColors) xErrCounter=0;
                }
                else
                {
                    g->updateErrorBars(i, false, EdgeThickness[yErrCounter],  0, ColorBox::color(edgeColor[yErrCounter]), true, true,FALSE);
                    yErrCounter++;
                    if (yErrCounter>=numberColors) yErrCounter=0;
                };
            }
        }
        //++++++++++  Scatter  ++++++++++++++
        if (comboBoxSchemaAim->currentText()=="symbols" && curveType == Graph::Scatter)
        {
            //-----------
            QBrush br = QBrush(ColorBox::color( fillColor[scatterCounter] ), Qt::SolidPattern);
            //-----------
            if (fillYN[scatterCounter]==0) br = QBrush();
            //-----------
            QPen pen = QPen(ColorBox::color(edgeColor[scatterCounter]),EdgeThickness[scatterCounter],Qt::SolidLine);
            //-----------
            QwtSymbol s = QwtSymbol(QwtSymbol::Style(stype[scatterCounter]), br, pen, QSize(size[scatterCounter], size[scatterCounter]));
            //-----------
            g->setCurveSymbol(i, s);
            //-----------
            scatterCounter++;
            //-----------
            if (scatterCounter>=numberColors) scatterCounter=0;
        }
        
        //++++++++++  Symbols+Lines  ++++++++++++++
        if (comboBoxSchemaAim->currentText()=="symbols+lines" && curveType == Graph::LineSymbols)
        {
            //-----------
            QBrush br = QBrush(ColorBox::color( fillColor[scatLineCounter] ), Qt::SolidPattern);
            //-----------
            if (fillYN[scatLineCounter]==0) br = QBrush();
            //-----------
            QPen pen = QPen(ColorBox::color(edgeColor[scatLineCounter]),EdgeThickness[scatLineCounter],Qt::SolidLine);
            //-----------
            QwtSymbol s = QwtSymbol(QwtSymbol::Style(stype[scatLineCounter]), br, pen, QSize(size[scatLineCounter], size[scatLineCounter]));
            //-----------
            g->setCurveSymbol(i, s);
            
            //---------- Line
            g->setCurveStyle(i, 1);
            //----------
            QBrush br2 = QBrush();
            //----------
            g->setCurveBrush(i, br2);
            //-----------
            QPen pen2 = QPen(ColorBox::color(edgeColor[scatLineCounter]),EdgeThickness[scatLineCounter],Qt::PenStyle(1));
            //-----------
            g->setCurvePen(i, pen2);
            
            //-----------
            scatLineCounter++;
            //-----------
            if (scatLineCounter>=numberColors) scatLineCounter=0;
        }
        
        //++++++++++  Lines  ++++++++++++++
        if (comboBoxSchemaAim->currentText()=="lines" && curveType == Graph::Line)
        {
            //----------
            g->setCurveStyle(i, 1);
            //----------
            QBrush br = QBrush();
            //----------
            g->setCurveBrush(i, br);
            //-----------
            QPen pen = QPen(ColorBox::color(edgeColor[lineCounter]),EdgeThickness[lineCounter],Qt::PenStyle(stype[lineCounter]));
            //-----------
            g->setCurvePen(i, pen);
            //-----------
            lineCounter++;
            //-----------
            if (lineCounter>=numberColors) lineCounter=0;
        }
        
    }	    
    
    g->replot();
    g->emitModified();
}



void danp16::openSymbolSequenceAsTable()
{
    //+++
    QDir dd;
    QString symbolPath=app(this)->qtiKwsPath+"/symbolMaps";
    symbolPath=symbolPath.replace("//","/");
    if (!dd.cd(symbolPath))
    {
        symbolPath=QDir::homeDirPath()+"/symbolMaps";
        symbolPath=symbolPath.replace("//","/");
        
        if (!dd.cd(symbolPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/symbolMaps");
            dd.cd("./qtiKWS/symbolMaps");
        }
    };
    symbolPath=dd.absPath();
    
    QString fileName=symbolPath+"/"+comboBoxSchema1D->currentText()+".SYM";
    
    
    
    
    //+++ create table
    QString tableName="SYM";
    tableName=app(this)->generateUniqueName(tableName);
    Table* w=app(this)->newHiddenTable(tableName,fileName, 0 ,7);
    
    w->setColName(0,"#");
    w->setColName(1,"Symbol-or-Line-Type");
    w->setColName(2,"Fill-Color");
    w->setColName(3,"Edge-or-Line-Color");
    w->setColName(4,"Symbol-Size");
    w->setColName(5,"Edge-or-Line-Thickness");
    w->setColName(6,"Fill-Yes-No");
    
    QFile f(fileName);
    
    if ( !f.open( IO_ReadOnly ) )
    {
        //*************************************Log Window Output
        QMessageBox::warning(this,"Could not open file", tr("qtiKWS::DANP"));
        //*************************************Log Window Output
        return;
    }
    QTextStream t( &f );
    QString s;
    
    int N=0;
    
    while (!t.atEnd())
    {
        s=t.readLine().simplifyWhiteSpace();
        w->setNumRows(N+1);
        w->setText(N,0,QString::number(N+1));
        QStringList lst;
        lst=lst.split(" ",s);
        int maxN=6;
        if (lst.count()<6) maxN=lst.count();
        for(int i=0;i<maxN;i++)
        {
            w->setText(N,i+1,lst[i]);
        }
        N++;
    }
    
    
    
    f.close();
    
    for (int tt=0; tt<w->numCols(); tt++)
    {
        w->table()->adjustColumn (tt);
        w->table()->setColumnWidth(tt, w->table()->columnWidth(tt)+10);
    }
    
    w->setHeaderColType();
    
    app(this)->updateWindowLists(w);
    
    w->setWindowLabel(fileName);
    app(this)->setListViewLabel(w->name(),fileName);
    app(this)->updateWindowLists(w);
    
    w->showMaximized();
}


void danp16::saveCurrentTableAsSymbolSequence()
{
    
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("Table"))
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>FIRST, activate SYMBOL table.</h4>"));
        return;
    }
    Table* w=(Table*)app(this)->ws->activeWindow();
    
    if (!w)	return;
    
    
    if (!w->colName(0).contains("#")) return;
    
    
    //+++
    QDir dd;
    QString symbolPath=app(this)->qtiKwsPath+"/symbolMaps";
    symbolPath=symbolPath.replace("//","/");
    if (!dd.cd(symbolPath))
    {
        symbolPath=QDir::homeDirPath()+"/symbolMaps";
        symbolPath=symbolPath.replace("//","/");
        
        if (!dd.cd(symbolPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/symbolMaps");
            dd.cd("./qtiKWS/symbolMaps");
        }
    };
    symbolPath=dd.absPath();
    
    bool ok=false;
    
    QString fileName=comboBoxSchema1D->currentText();
    
    while (ok==false)
    {
        fileName = QInputDialog::getText(
                                         "QtiKWS", "Input Schema Name:", QLineEdit::Normal,
                                         fileName, &ok, this );
        if ( !ok )
        {
            return;
        }
        
        if (fileName.isEmpty())
        {
            ok=false;
        }
    }
    
    QString s;
    
    for (int i=0; i<w->numRows();i++)
    {
        for(int j=1;j<=6;j++)
        {
            s+=QString::number(w->text(i,j).toInt())+" ";
        }
        s+="\n";
    }
    
    
    QFile f(symbolPath+"/"+fileName+".SYM");
    
    
    if ( !f.open( IO_WriteOnly ) )  
    {
        //*************************************Log Window Output
        QMessageBox::warning(this,"Could not write to file", tr("qtiKWS::DANP"));
        //*************************************Log Window Output
        return;
    }	
    QTextStream stream( &f );
    stream<<s;
    f.close();	
    
    findSymbolMaps();
    
    comboBoxSchema1D->setCurrentText(fileName);
}


void danp16::deleteSymbolSequence()
{
    QString fileName=comboBoxSchema1D->currentText();
    if (fileName=="") return;
    
    //+++
    QDir dd;
    QString symbolPath=app(this)->qtiKwsPath+"/symbolMaps";
    symbolPath=symbolPath.replace("//","/");
    if (!dd.cd(symbolPath))
    {
        symbolPath=QDir::homeDirPath()+"/symbolMaps";
        symbolPath=symbolPath.replace("//","/");
        
        if (!dd.cd(symbolPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/symbolMaps");
            dd.cd("./qtiKWS/symbolMaps");
        }
    };
    symbolPath=dd.absPath();
    
    dd.remove(fileName+".SYM");
    
    findSymbolMaps();
}


bool danp16::plotTable(Graph *g,Table *table, QString tableName)
{
    //
    int cols=table->numCols();
    int style = Graph::Scatter;
    QStringList columnsListOnPlot=g->curvesList();
    //
    g->resizeMy(g->curves());
    
    if (cols>2 && !checkBoxYerror->isChecked() && columnsListOnPlot.contains(table->colName(2)))
    {
        g->removeCurve(tableName+"_dI");
    }
    else if (cols>2 && checkBoxYerror->isChecked() && !columnsListOnPlot.contains(table->colName(2)))
    {
        g->addErrorBars(table,table->colName(0), tableName+"_I",table,table->colName(2), 1, 1, 1, QColor(black), TRUE, TRUE,TRUE);
    }
    
    if (cols>1  && !columnsListOnPlot.contains(table->colName(1)))
    {
        g->insertCurve(table,tableName+"_I",style);
    }
    curveLayout cl = Graph::initCurveLayout();
    
    int color;
    int curve = g->curves()-1 ;
    long key = g->curveKey(curve);
    if (key == (long) curve ) key++;
    g->guessUniqueCurveLayout(color, cl.sType);
    int shape=key%9;
    if (shape == 0) shape = 1; //avoid white invisible symbol
    
    cl.lCol=color;
    cl.symCol=color;
    cl.fillCol=color;
    cl.aCol=color;
    cl.lWidth = app(this)->defaultCurveLineWidth;
    cl.sSize = app(this)->defaultSymbolSize;
    
    //cl.sType=shape;
    
    g->updateCurveLayout(curve, &cl);
    
    if (cols>3 && !checkBoxXerror->isChecked() && columnsListOnPlot.contains(table->colName(3)))
    {
        g->removeCurve(tableName+"_Sigma");
    }
    else if (cols>3 &&  checkBoxXerror->isChecked() && !columnsListOnPlot.contains(table->colName(3)))
    {
        g->addErrorBars(table,table->colName(0), tableName+"_I",table, table->colName(3), 0, 2, 10, color, TRUE, TRUE,TRUE);
        curve = g->curves() - 1;
        g->updateErrorBars(curve,TRUE,1,1, color, TRUE,TRUE,FALSE);
    }
    
    g->replot();
    
    if (comboBoxSchema1D->count()>0)
    {
        int old=comboBoxSchemaAim->currentItem();
        comboBoxSchemaAim->setCurrentItem(0);
        symbolSchemChanged();
        comboBoxSchemaAim->setCurrentItem(3);
        symbolSchemChanged();
        comboBoxSchemaAim->setCurrentItem(old);
        
    }
    return true;
}

void danp16::movePointPlus()
{
    movePoint(true);
}

void danp16::movePointMinus()
{
    movePoint(false);
}

void danp16::movePoint(bool plus)
{
    //+++
    Graph *g;
    if(!findActiveGraph(g)){QMessageBox::critical(this,tr("QtiKWS"), tr("Activate first GRAPH with data to shift !!!")); return;};
    if (g->curves()==0) {QMessageBox::critical(this,tr("QtiKWS"), tr("Graph is EMPTY !!!")); return;};
    
    QString curveName=g->selectedCurveTitle();
    curveName=g->selectedCurveTitle();
    //---
    
    QString info=app(this)->info->text();
    
    if (!info.contains(":")) return;
    if (info.contains("<=>")) return;
    
    //    if (info.left(info.find("["))!=curveName) {QMessageBox::critical(this,tr("QtiKWS"), tr("Activate first GRAPH with data to shift !!!")); return;};
    curveName=info.left(info.find("["));
    
    int pointNumber=info.mid( info.find("[")+1,info.find("]")-info.find("[") -1).toInt()-1;
    
    Table *table;
    int xColIndex, yColIndex;
    
    findFitDataTable(curveName, table, xColIndex, yColIndex );
    
    
    double xx=table->text(pointNumber,xColIndex).toDouble();
    double yy=table->text(pointNumber,yColIndex).toDouble();
    
    
    info=info.right(info.length()-info.find(":"));
    info=info.remove(":").remove(" ").remove("x=").remove("y=");
    
    //    if (xx!=info.left(info.find(";")).toDouble() || yy!=info.right(info.length()-info.find(";")-1).toDouble()) {QMessageBox::critical(this,tr("QtiKWS"), tr("Table contains emply cells !!!")); return;};
    
    
    //    QPoint o=g->d_plot->canvas()->mapFromGlobal(QCursor::pos());
    
    double sign=1;
    if (!plus) sign=-1;
    
    double step=0.01;
    if (comboBoxMovePointLevel->currentItem()==0) step=0.1;
    if (comboBoxMovePointLevel->currentItem()==2) step=0.001;
    if (comboBoxMovePointLevel->currentItem()==3) step=0.0001;
    
    if (comboBoxMovePointXorY->currentItem()==0)
    {
        if (xx==0) xx=sign*step; else xx+= sign*step*fabs(xx);
        table->setText(pointNumber,xColIndex, QString::number(xx));
        table->cellEdited(pointNumber,xColIndex);
    }
    else
    {
        if (yy==0) yy =sign*step; else yy+= sign*step*fabs(yy);
        table->setText(pointNumber,yColIndex, QString::number(yy));
        table->cellEdited(pointNumber,yColIndex);
    }
    g->emitModified();
    g->replot();
    //    g->selectCurve(o);
    //    app(this)->pickDataTool ( app(this)->btnCursor);
    //    g->showPlotPicker(true);
    
    QString sss=curveName+"["+QString::number(pointNumber+1)+"]: x="+QString::number(xx, 'G', 15)+"; y="+QString::number(yy, 'G', 15);
    
    app(this)->info->setText ( sss);
}
