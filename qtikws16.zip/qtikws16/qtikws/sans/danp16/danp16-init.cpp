#include "danp16.h"

#include "../standart-functions/standartFunctions.h"
 
#include "../../src/application.h"
#include "../../src/multilayer.h"
#include "../../src/pixmaps.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qbuttongroup.h>
#include <qtoolbutton.h>
#include <qlabel.h>
#include <qheader.h>
#include <qlistview.h>
#include <qtabwidget.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qcombobox.h>
#include <qtoolbox.h>
#include <qlineedit.h>
#include <qtextedit.h>
#include <qcheckbox.h>
#include <qspinbox.h>
#include <qtable.h>
#include <qradiobutton.h>
#include <qslider.h>
#include <qlcdnumber.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>
#include <qinputdialog.h>
#include <qmessagebox.h>
#include <qdir.h>
#include <qfiledialog.h>
#include <qcolordialog.h>
#include <qwidgetlist.h>
#include <qregexp.h>
#include <qworkspace.h>

//+++ connect Slots
void danp16::connectSlot()
{
    //+++ Path +++
    connect( pushButtonPath, SIGNAL( clicked() ), this, SLOT( buttomPath() ) );
    connect( pushButtonPathOut, SIGNAL( clicked() ), this, SLOT( buttomPathOut() ) );
    connect( lineEditPath, SIGNAL( textChanged(const QString&) ), this, SLOT(forceReadSettings() ) );
    connect( lineEditPathOut, SIGNAL( textChanged(const QString&) ), this, SLOT( forceReadSettings() ) );
    
    //+++ ASCII 1D
    connect( comboBoxStructureASCII1D, SIGNAL( activated(int) ), this, SLOT( readCurrentASCII1D() ) );
    connect( pushButtonNewASCII1D, SIGNAL( clicked() ), this, SLOT( saveNewASCII1D() ) );
    connect( pushButtonDeleteASCII1D, SIGNAL( clicked() ), this, SLOT( deleteASCII1D()) );
    connect( pushButtonSaveCurrentASCII1D, SIGNAL( clicked() ), this, SLOT( saveCurrentASCII1D() ) );


    //+++ Plot 1D
    connect( pushButtonCLEAR, SIGNAL( clicked() ), this, SLOT( slotCLEAR() ) );
    connect( pushButtonLinLin, SIGNAL( clicked() ), this, SLOT( slotLinLin() ) );
    connect( pushButtonLogLog, SIGNAL( clicked() ), this, SLOT( slotLogLog() ) );
    
    connect( spinBoxLogMinX, SIGNAL( valueChanged(int) ), this, SLOT( slotLogLog() ) );
    connect( spinBoxLogMinY, SIGNAL( valueChanged(int) ), this, SLOT( slotLogLog() ) );
    connect( spinBoxLogMaxX, SIGNAL( valueChanged(int) ), this, SLOT( slotLogLog() ) );
    connect( spinBoxLogMaxY, SIGNAL( valueChanged(int) ), this, SLOT( slotLogLog() ) );
    
    
    connect( pushButtonPlotTitels, SIGNAL( clicked() ), this, SLOT( slotSetTitels() ) );
    connect( pushButtonplotRange, SIGNAL( clicked() ), this, SLOT( slotPlotRange() ) );
    connect( lineEditResoSamAper, SIGNAL( lostFocus() ), this, SLOT( detColDistanceValidator() ) );
    connect( lineEditResoSamAper2, SIGNAL( lostFocus() ), this, SLOT( detColDistanceValidator() ) );
    connect( lineEditResoPixelSize, SIGNAL( lostFocus() ), this, SLOT( detColDistanceValidator() ) );
    connect( lineEditResoLambda, SIGNAL( lostFocus() ), this, SLOT( detColDistanceValidator() ) );
    connect( lineEditResoFocus, SIGNAL( lostFocus() ), this, SLOT( detColDistanceValidator() ) );
    connect( lineEditResoDet, SIGNAL( lostFocus() ), this, SLOT( detColDistanceValidator() ) );
    connect( lineEditResoDeltaLambda, SIGNAL( lostFocus() ), this, SLOT( detColDistanceValidator() ) );
    connect( lineEditResoColAper, SIGNAL( lostFocus() ), this, SLOT( detColDistanceValidator() ) );
    connect( lineEditResoColAper2, SIGNAL( lostFocus() ), this, SLOT( detColDistanceValidator() ) );
    connect( lineEditResoCol, SIGNAL( lostFocus() ), this, SLOT( detColDistanceValidator() ) );
    connect( lineEditMath, SIGNAL( lostFocus() ), this, SLOT( slotMathYN() ) );
    connect( comboBoxMath, SIGNAL( activated(const QString&) ), this, SLOT( slotMathYN() ) );
    connect( comboBoxInstrument, SIGNAL( activated(int) ), this, SLOT( setSANSinstrument() ) );
    connect( checkBoxReso, SIGNAL( stateChanged(int) ), this, SLOT( checkBoxResoSlot() ) );
    
    connect( checkBoxLenses, SIGNAL( stateChanged(int) ), this, SLOT( checkBoxLensesChanged() ) );
    
    connect( checkBoxMath, SIGNAL( clicked() ), this, SLOT( slotMathYN() ) );
    
    connect( checkBox1DCalculator, SIGNAL( clicked() ), this, SLOT( slot1DcalcYN() ) );
    
    
    connect( pushButtonMovePointPlus, SIGNAL( clicked() ), this, SLOT( movePointPlus() ) );
    connect( pushButtonMovePointMinus, SIGNAL( clicked() ), this, SLOT( movePointMinus() ) );
    
    //+++ Merge 1D
    
    //+++ ASCII 2D
    connect( pushButtonLoadDATmatrix, SIGNAL( clicked() ), this, SLOT( loadDATmatrixNew() ) );
    
    //+++ Plot 2D
    connect( comboBoxSchema, SIGNAL( activated(const QString&) ), this, SLOT( colorSchemSelected() ) );
    
    connect( pushButtonEdit2dColorSchemaAccept, SIGNAL( clicked() ), this, SLOT( colorSchemSelected() ) );
    
    connect( checkBoxLog, SIGNAL( stateChanged(int) ), this, SLOT( colorSchemSelectedNotColor() ) );
    connect( lineEditMin, SIGNAL( lostFocus() ), this, SLOT( colorSchemSelectedNotColor() ) );
    connect( lineEditMax, SIGNAL( lostFocus() ), this, SLOT( colorSchemSelectedNotColor() ) );
    
    connect( lineEditMinAbs, SIGNAL( lostFocus() ), this, SLOT( colorSchemSelectedNotColor() ) );
    connect( lineEditMaxAbs, SIGNAL( lostFocus() ), this, SLOT( colorSchemSelectedNotColor() ) );
    
    connect( lineEditMinAbs, SIGNAL( returnPressed()), this, SLOT( colorSchemSelectedNotColor() ) );
    connect( lineEditMaxAbs, SIGNAL( returnPressed()), this, SLOT( colorSchemSelectedNotColor() ) );
    
    connect( radioButton2DplotRelative, SIGNAL( stateChanged(int) ), this, SLOT( colorSchemSelectedNotColor() ) );
    
    
    connect( lineEditMin, SIGNAL( returnPressed()), this, SLOT( colorSchemSelectedNotColor() ) );
    connect( lineEditMax, SIGNAL( returnPressed()), this, SLOT( colorSchemSelectedNotColor() ) );
    connect(pushButtonEditXYZtomatrix, SIGNAL( clicked() ), this, SLOT(xyzTOmatrix() ) );
    
    connect(pushButtonWaterfall, SIGNAL( clicked() ), this, SLOT(tablesToWasserfallMatrix() ) );
    
    //+++ Help
    connect( ASCIIpushButton, SIGNAL( clicked() ), this, SLOT( loadASCIIall() ) );
    connect( pushButtonRescale, SIGNAL( clicked() ), this, SLOT( rescale2Dplot() ) );
    connect( pushButtonMlist, SIGNAL( clicked() ), this, SLOT( matrixList() ) );
    connect( comboBoxMlist, SIGNAL( activated(const QString&) ), this, SLOT( matrixSelected(const QString&) ) );
    connect( pushButtonExportM, SIGNAL( clicked() ), this, SLOT( exportMatrix() ) );
    connect( checkBoxSens, SIGNAL( clicked() ), this, SLOT( checkSensInExportMatrix() ) );
    connect( pushButtonMlist_2, SIGNAL( clicked() ), this, SLOT( matrixList() ) );
    connect( pushButtonElips, SIGNAL( clicked() ), this, SLOT( maskElips() ) );
    connect( pushButtonSquared, SIGNAL( clicked() ), this, SLOT( maskSquared() ) );
    connect( pushButtonSetValue, SIGNAL( clicked() ), this, SLOT( maskSetValue() ) );
    connect( comboBoxSelectPresentationFrom, SIGNAL( activated(int) ), this, SLOT( presentationFromChanged() ) );
    connect( comboBoxSelectPresentationTo, SIGNAL( activated(int) ), this, SLOT( presentationToChanged() ) );
    connect( checkBoxReso, SIGNAL( toggled(bool) ), textLabelResoDescription, SLOT( setHidden(bool) ) );
    connect( checkBoxReso, SIGNAL( toggled(bool) ), buttonGroupReso, SLOT( setShown(bool) ) );
    
    
    connect( checkBoxConvert, SIGNAL( toggled(bool) ), textLabelSASdesc, SLOT( setHidden(bool) ) );
    connect( checkBoxConvert, SIGNAL( toggled(bool) ), frameSASpresentation, SLOT( setShown(bool) ) );
    
    connect( checkBoxMath, SIGNAL( clicked() ), this, SLOT( mathControl() ) );
    connect( checkBoxMath2, SIGNAL( clicked() ), this, SLOT( mathControl2() ) );
    connect( checkBoxRemoveRange, SIGNAL( clicked() ), this, SLOT( removeRangeControl() ) );
    connect( checkBoxRemoveFirst, SIGNAL( clicked() ), this, SLOT( removeFirstControl() ) );
    connect( checkBoxRemoveLast, SIGNAL( clicked() ), this, SLOT( removeLastControl() ) );
    connect( pushButtonKWS2, SIGNAL( clicked() ), this, SLOT( readKWS2resoInfo() ) );
    connect( pushButtonKWS1, SIGNAL( clicked() ), this, SLOT( readKWS1resoInfo() ) );
    connect( pushButtonCANSAS, SIGNAL( clicked() ), this, SLOT( readCANSASresoInfo() ) );
    
    connect( checkBoxActions, SIGNAL( toggled(bool) ), textLabelHelp, SLOT( setHidden(bool) ) );
    connect( checkBoxActions, SIGNAL( toggled(bool) ), toolBoxChange, SLOT( setShown(bool) ) );
    
    connect( comboBoxMC1, SIGNAL( activated(int) ), this, SLOT( mCalcSelected1() ) );
    connect( comboBoxMC2, SIGNAL( activated(int) ), this, SLOT( mCalcSelected2() ) );
    
    connect( comboBoxActiveMatrix, SIGNAL( activated(int) ), this, SLOT( activeMatrixSelected() ) );
    
    connect( pushButtonMC, SIGNAL( clicked() ), this, SLOT( matrixCalculation() ) );
    connect( sansTab, SIGNAL( selected(const QString&) ), this, SLOT( tabSelected() ) );
    connect( pushButtonMCscalar, SIGNAL( clicked() ), this, SLOT( mcCalculateScalar() ) );
    connect( spinBoxMmergingCond, SIGNAL( valueChanged(int) ), this, SLOT( mergingTableChange() ) );
    connect( spinBoxNtoMerge, SIGNAL( valueChanged(int) ), this, SLOT( mergingTableChange() ) );
    connect( pushButtonMerge, SIGNAL( clicked() ), this, SLOT( mergeMethod() ) );
    connect( pushButtonHelp, SIGNAL( clicked() ), this, SLOT( openHelpOnline() ) );
    connect( pushButtonBackToDAN, SIGNAL( clicked() ), this, SLOT( showDAN() ) );
    connect( pushButtonMaskSector, SIGNAL( clicked() ), this, SLOT( maskSector() ) );
    connect( pushButtonEllShell, SIGNAL( clicked() ), this, SLOT( maskElipsShell() ) );

    
    connect( pushButtonPlotByFilter, SIGNAL( clicked() ), this, SLOT( plotByFilter() ) );
    connect( pushButtonRemoveByFilter, SIGNAL( clicked() ), this, SLOT( removeByFilter() ) );
    connect( comboBoxSchema1D, SIGNAL( activated(const QString&) ), this, SLOT( symbolSchemChanged() ) );
    connect( pushButtonColorSchemaAccept, SIGNAL( clicked() ), this, SLOT( symbolSchemChanged() ) );
    
    connect( pushButtonAddLegend, SIGNAL( clicked() ), this, SLOT( addNewLegend() ) );
    connect( pushButtonIQ, SIGNAL( clicked() ), this, SLOT( radUniHFcall() ) );
    connect( pushButtonDefineMergeFromTable, SIGNAL( clicked() ), this, SLOT( readMergeInfo() ) );
    connect( pushButtonSaveMergeDataToTable, SIGNAL( clicked() ), this, SLOT( saveMergeInfo() ) );
    connect( checkBoxAllMatrixes, SIGNAL( toggled(bool) ), comboBoxMlistMask, SLOT( setDisabled(bool) ) );
    
    
    //+++ new
    connect( pushButtonReadDisplay, SIGNAL( clicked() ), this, SLOT( readDisplay() ) );
    connect( pushButtonNewHeaderSTR, SIGNAL( clicked() ), this, SLOT( saveNewHSTRtable() ) );
    connect( pushButtonsaveCurrentHeaderSTR, SIGNAL( clicked() ), this, SLOT( saveCurrentHSTRtable() ) );
    connect( comboBoxHeaderStructure, SIGNAL( activated(int) ), this, SLOT( readCurrentHSTRtable() ) );
    connect( pushButtonHSTRdelete, SIGNAL( clicked() ), this, SLOT( deleteHSTR()) );
    connect( pushButtonHeaderReader, SIGNAL( clicked() ), this, SLOT( slotMakeUniHeader() ) );
    connect( pushButtonHSTRitemsDel, SIGNAL( clicked() ), this, SLOT( deleteAllUncheckedLinesHSTR() ) );
    connect( pushButtonAdd, SIGNAL( clicked() ), this, SLOT( addLineToHSTR() ) );
    connect( pushButtonsaveCurrentSave2Dtype, SIGNAL( clicked() ), this, SLOT( saveMatrix2Dformat() ) );
    connect( pushButtonDeleteCurrentSave2Dtype, SIGNAL( clicked() ), this, SLOT( deleteMatrix2Dformat() ) );
    connect( pushButtonEditColorSchema, SIGNAL( clicked() ), this, SLOT(openSymbolSequenceAsTable() ) );
    connect( pushButtonEditColorSchema2D, SIGNAL( clicked() ), this, SLOT(open2dColorSequenceAsTable() ) );
    connect(pushButtonsaveCurrentSaveColorSchema, SIGNAL( clicked() ), this, SLOT(saveCurrentTableAsSymbolSequence() ) );
    connect(pushButtonSaveCurrentColorSchema2d, SIGNAL( clicked() ), this, SLOT(saveCurrentTableAsColorSequence() ) );
    connect(pushButtonDeleteColorSchema, SIGNAL( clicked() ), this, SLOT(deleteSymbolSequence() ) );
    connect(pushButtonDeleteColorSchema2D, SIGNAL( clicked() ), this, SLOT(deleteColorSequence() ) );
    connect( comboBoxFormat, SIGNAL( activated(int) ), this, SLOT( asciiFormatSelected() ) );
    connect( comboBoxSource, SIGNAL( activated(int) ), this, SLOT( sourceSelected() ) );
    connect( groupBoxPeriodicalHeader, SIGNAL( toggled(bool) ), this, SLOT( periodicalHeader()));
    connect( groupBoxXML, SIGNAL( toggled(bool) ), this, SLOT( xmlHeader()));
    connect( groupBoxYAML, SIGNAL( toggled(bool) ), this, SLOT( yamlHeader()));
    
    connect(tableHeader->verticalHeader(), SIGNAL(clicked(int)), this,SLOT(vertHeaderTableClicked(int)));
    

    
    connect( CSVimport, SIGNAL( clicked() ), this, SLOT( csvImport() ) );
}

//+++   INIT   +++++++++++++++++++++++
void danp16::initDANP()
{
    //+++ Any Header Interface
    initTableHeader();
    
    pushButtonReadDisplay->setIconSet ( QPixmap ( cursor_16 ) );
    //DATA
    initDATA();
    
    findColorMaps();
    findSymbolMaps();
    findMatrixFormats();
    findHeaderFormats();
    findASCII1DFormats();
    
    toolBoxChange->setShown(false);
    
    textLabelHelp->setMinimumWidth(320);
    textLabelHelp->setMaximumWidth(320);
    
    frameSASpresentation->hide();
    textLabelSASdesc->setMinimumHeight(200);
    textLabelSASdesc->setMaximumHeight(200);
    
    textLabelResoDescription->setMinimumHeight(230);
    textLabelResoDescription->setMaximumHeight(230);
    buttonGroupReso->hide();
    checkBoxLensesChanged();
    asciiFormatSelected();
    sourceSelected();

    
    tableHeader->setColumnStretchable(1,true);
    
    checkBoxX2mX->hide();
    checkBoxY2mY->hide();
}

void danp16::tabSelected()
{
    QString newLabel=sansTab->label(sansTab->currentPageIndex());
    
    switch ( sansTab->currentPageIndex() )    {
            
        case 0: newLabel+=" >>> Set Directory for the Import/Export of Files <<<";
            break;
        case 1: newLabel+=" >>> Import/Export/Modification of Radial Avereged Datasets <<<";
            findASCII1DFormats();
            break;
        case 2: newLabel+=" >>> Control of [1D]-Plot  <<<";
            findSymbolMaps();
            break;
        case 3: newLabel+=" >>> Merging of Radial Avereged Datasets  <<<";
            break;
        case 4: newLabel+=" >>> Import/Export/Modification of (Detector) [2D]-Matrixes <<<";
            findMatrixFormats();
            matrixList();
            mCalcSelected1();
            break;
        case 5: newLabel+=" >>> Control of [2D] Plot <<<";
            activeMatrixUpdate();
//            activeMatrixSelected();
            findColorMaps();
            break;
        case 6: newLabel+=" >>> Universal File Reader (File Parser) <<<";
            findHeaderFormats();
            break;
        case 7: newLabel+=" >>> CSV File Reader <<<";
            if (startingLineCSV->text()=="") readSettingsCSV();
            if (startingLineCSV->text()=="") startingLineCSV->setText("Interval:;;;");
            break;		
    }
    textLabelInfo->setText(newLabel);
}

//+++   DATA   +++++++++++++++++
void danp16::initDATA()
{
    detColDistanceValidator();
}


//+++  Options: Buttons: DAT & RAD direcrories  ++++++++++++++++++++
void danp16::buttomRADpath()
{
    QString pppath=lineEditPath->text();
    
    if (pppath.left(4)=="home") pppath = QDir::homeDirPath();
    
    QString s = QFileDialog::getExistingDirectory(
                                                  pppath,
                                                  this,
                                                  "get data directory"
                                                  "Choose a directory");
    if (s)
    {
        lineEditPath->setText(s);
    }
    
}



//+++++  openHelpOnline +++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::openHelpOnline()
{
    app(this)->open_browser(this, "http://www.qtikws.de");
}





//++++++++++++++++++++        Text-To-Results Log-Window +++++++++++++++++++++++++++++++++++++++++++
void danp16::toResLog( QString text)
{
    toResLogAll( "DANP", text, this);
}


//+++  Options: Buttons: DAT & RAD direcrories  ++++++++++++++++++++
void danp16::buttomPath()
{
    QString pppath=lineEditPath->text();
    
    if (pppath.left(4)=="home") pppath = QDir::homeDirPath();
    
    QString s = QFileDialog::getExistingDirectory(
                                                  pppath,
                                                  this,
                                                  "ASCII-files location "
                                                  "Choose a directory");
    if (s)
    {
        lineEditPath->setText(s);
        lineEditPathOut->setText(s);
        strPath=s;
    }
}

//+++  Options: Buttons: DAT & RAD direcrories  ++++++++++++++++++++
void danp16::buttomPathOut()
{
    QString pppath=lineEditPathOut->text();
    
    if (pppath.left(4)=="home") pppath = lineEditPath->text();
    
    if (pppath.left(4)=="home") pppath = QDir::homeDirPath();
    
    QString s = QFileDialog::getExistingDirectory(
                                                  pppath,  
                                                  this,
                                                  "ASCII-files location :: Output "
                                                  "Choose a directory");
    if (s)
    {
        lineEditPathOut->setText(s);
        strPath=s;
    }
}

void    danp16::showDAN()
{
    app(this)->backToDANmask();
}

void danp16::findColorMaps()
{
    //+++
    QDir dd;
    QString colorPath=app(this)->qtiKwsPath+"/colorMaps";
    colorPath=colorPath.replace("//","/");
    if (!dd.cd(colorPath))
    {
        colorPath=QDir::homeDirPath()+"/colorMaps";
        colorPath=colorPath.replace("//","/");
        
        if (!dd.cd(colorPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/colorMaps");
            dd.cd("./qtiKWS/colorMaps");
        }
    };
    colorPath=dd.absPath();
    
    QStringList lst = dd.entryList("*.MAP");
    lst.gres(".MAP", "");
    lst.prepend("Standard #3: jet");
    lst.prepend("Standard #2: white|black");
    lst.prepend("Standard #1: red|blue");
    comboBoxSchema->clear();
    comboBoxSchema->insertStringList(lst);
}

void danp16::findSymbolMaps()
{
    //+++
    QDir dd;
    QString symbolPath=app(this)->qtiKwsPath+"/symbolMaps";
    symbolPath=symbolPath.replace("//","/");
    if (!dd.cd(symbolPath))
    {
        symbolPath=QDir::homeDirPath()+"/symbolMaps";
        symbolPath=symbolPath.replace("//","/");
        
        if (!dd.cd(symbolPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/symbolMaps");
            dd.cd("./qtiKWS/symbolMaps");
        }
    };
    symbolPath=dd.absPath();
    
    QStringList lst = dd.entryList("*.SYM");
    lst.gres(".SYM", "");
    comboBoxSchema1D->clear();
    comboBoxSchema1D->insertStringList(lst);
}


void danp16::findMatrixFormats()
{
    //+++
    QDir dd;
    QString formatsPath=app(this)->qtiKwsPath+"/matrixFormats";
    formatsPath=formatsPath.replace("//","/");
    if (!dd.cd(formatsPath))
    {
        formatsPath=QDir::homeDirPath()+"/matrixFormats";
        formatsPath=formatsPath.replace("//","/");
        
        if (!dd.cd(formatsPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/matrixFormats");
            dd.cd("./qtiKWS/matrixFormats");
        }
    };
    formatsPath=dd.absPath();
    
    QStringList lst = dd.entryList("*.MSTR");
    lst.gres(".MSTR", "");
    lst.prepend("Other || Save");
    lst.prepend("Small Detector");
    lst.prepend("KWS1&2");
    
    QString ct=comboBoxInstrument->currentText();
    
    comboBoxInstrument->clear();
    comboBoxInstrument->insertStringList(lst);
    if (lst.contains(ct))     comboBoxInstrument->setCurrentText(ct);
}

void danp16::findHeaderFormats()
{
    //+++
    QDir dd;
    QString headerPath=app(this)->qtiKwsPath+"/headerFormats";
    headerPath=headerPath.replace("//","/");
    if (!dd.cd(headerPath))
    {
        headerPath=QDir::homeDirPath()+"/headerFormats";
        headerPath=headerPath.replace("//","/");
        
        if (!dd.cd(headerPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/headerFormats");
            dd.cd("./qtiKWS/headerFormats");
        }
    };
    headerPath=dd.absPath();
    
    QStringList lst = dd.entryList("*.HSTR");
    lst.gres(".HSTR", "");
    lst.prepend("KWS1&2");
    
    QString ct=comboBoxHeaderStructure->currentText();
    
    comboBoxHeaderStructure->clear();
    comboBoxHeaderStructure->insertStringList(lst);
    if (lst.contains(ct))     comboBoxHeaderStructure->setCurrentText(ct);
    
    
    tableHeader->setLeftMargin (215);//->verticalHeader()->setMaximumWidth (70);
}


//+++ Delete Windows Buttom +++
void danp16::removeWindows(QString pattern)
{
    int i;
    
    QWidgetList *windows = app(this)->windowsList();
    
    QRegExp rx(pattern);
    rx.setWildcard( TRUE );
    
    for (i=0;i<(int)windows->count();i++)
    {
        if ( rx.exactMatch(windows->at(i)->name()))
        {
            myWidget *close =(myWidget*)windows->at(i);
            emit app(this)->closeWindow(close);
        }
    }
}

//+++++FUNCTION::check Table Existence ++++++++++++++++++++++++
bool danp16::checkTableExistence(QString &tableName, Table* &w)
{
    int i;
    bool exist=false;
    
    QWidgetList* tableList=app(this)->tableList();
    //+++
    for (i=0;i<(int)tableList->count();i++)
    {
        if (tableList->at(i) && tableList->at(i)->name()==tableName)
        {
            w=(Table *)tableList->at(i);
            exist=true;
        }
    }
    return exist;
}


//existance+++++++++++++++++++++++++++++++++++++++++++++++++++++
bool danp16::checkTableExistence(QString &tableName)
{
    int i;
    bool exist=false;
    
    QWidgetList* tableList=app(this)->tableList();
    //+++
    for (i=0;i<(int)tableList->count();i++)  if (tableList->at(i) &&
                                                 tableList->at(i)->name()==tableName) exist=true;
    return exist;
}

//+++++SLOT::maximizeWindow
void danp16::maximizeWindow(QString name)
{
    QWidgetList* windows=app(this)->windowsList();
    
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
        if (windows->at(mm)->name()==name  )
        {
            myWidget* mmm=(myWidget*) windows->at(mm);
            mmm->showMaximized();
        }
    }
}


//*********************************************************
//***  findActiveGraph
//*********************************************************
bool danp16::findActiveGraph( Graph * & g)
{
    if (app(this)->windowsList()->count()==0 || !app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer"))  return false;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty()) return false;
    
    g = (Graph*)plot->activeGraph();
    
    return true;
}

//+++ uni
//+++ find-File-Number-In-File-Name
QString danp16::findFileNumberInFileName(QString wildCardLocal, QString file)
{
    if (wildCardLocal.contains("#")==1)
    {
        if ( wildCardLocal.contains(".") ) wildCardLocal=wildCardLocal.left( wildCardLocal.find(".")+1 );
        
        wildCardLocal=wildCardLocal.remove("*");
        wildCardLocal=wildCardLocal.replace("#","(\\d+)");
        
        
        QRegExp rxF( wildCardLocal );
        int pos=0;
        
        pos = rxF.search(file, pos );
        
        if (pos<0) return false;
        //
        file=rxF.cap(1);
        
        QRegExp rxF1( "(\\d+)" );
        pos=0;
        pos = rxF1.search(file, pos );
        
        if (pos<0) return false;
        
        return rxF1.cap(1);
    }
    else if (wildCardLocal.contains("#")==2)
    {
        QString wildCardLocal2nd=wildCardLocal;
        QString file2nd=file;
        QStringList lst;
        QString res;
        
        
        wildCardLocal=wildCardLocal.left(wildCardLocal.findRev("#"));
        if(wildCardLocal.contains("*"))
        {
            lst=lst.split("*",wildCardLocal);
            for (int i=0; i<lst.count();i++) if (lst[i].contains("#")){wildCardLocal=lst[i];break;};
        }
        
        
        wildCardLocal=wildCardLocal.replace("#","(\\d+)");
        
        
        QRegExp rxF( wildCardLocal );
        int pos=0;
        
        pos = rxF.search(file, pos );
        
        if (pos<0) return false;
        //
        file=rxF.cap(1);
        
        QRegExp rxF1( "(\\d+)" );
        pos=0;
        pos = rxF1.search(file, pos );
        if (pos<0) return "";
        
        res=rxF1.cap(1);
        
        //+++ 2nd
        wildCardLocal=wildCardLocal2nd;
        file=file2nd;
        
        wildCardLocal=wildCardLocal.right(wildCardLocal.length()-wildCardLocal.find("#")-1);
        
        if(wildCardLocal.contains("*"))
        {
            lst=lst.split("*",wildCardLocal);
            for (int i=0; i<lst.count();i++)if (lst[i].contains("#")){wildCardLocal=lst[i];break;};
        }
        
        
        wildCardLocal=wildCardLocal.replace("#","(\\d+)");
        
        
        QRegExp rxF2nd( wildCardLocal );
        pos=0;
        
        pos = rxF2nd.search(file, pos );
        
        if (pos<0) return "";
        //
        file=rxF2nd.cap(1);
        
        QRegExp rxF12nd( "(\\d+)" );
        pos=0;
        pos = rxF12nd.search(file, pos );
        if (pos<0) return "";
        
        res+="-"+rxF12nd.cap(1);
        
        return res; 	
    }
    else if (wildCardLocal.contains("#")>2) return "";
    
    
    if (wildCardLocal.contains("*")==1)
    {
        QRegExp rx0( wildCardLocal );
        rx0.setWildcard( TRUE );
        
        if (rx0.exactMatch( file) )
        {
            if(wildCardLocal.find("*")>0)
                file=file.right(file.length()-wildCardLocal.find("*"));
            
            wildCardLocal=wildCardLocal.right(wildCardLocal.length()-wildCardLocal.find("*")-1);
            
            file=file.left(file.length()-wildCardLocal.length());
            return file;
        }
    }
    return "";
}

//*******************************************
//*** findFitDataTable
//*******************************************
bool danp16::findFitDataTable(QString curveName, Table* &table, int &xColIndex, int &yColIndex )
{
    int i, ixy;
    bool exist=false;
    
    QString tableName=curveName.left(curveName.find("_",0));
    QString colName=curveName.remove(tableName+"_");
    
    QWidgetList *windows = app(this)->windowsList();
    
    for (i=0;i<(int)windows->count();i++)
    {
        if (windows->at(i) && windows->at(i)->isA("Table") && windows->at(i)->name()==tableName)
        {
            table=(Table*)windows->at(i);
            yColIndex=table->colIndex(colName);
            xColIndex=0;
            
            bool xSearch=true;
            ixy=yColIndex-1;
            while(xSearch && ixy>0 )
            {
                if (table->colPlotDesignation(ixy)==1)
                {
                    xColIndex=ixy;
                    xSearch=false;
                }
                else ixy--;
            }
            exist=true;
        }
    }
    return exist;
}
