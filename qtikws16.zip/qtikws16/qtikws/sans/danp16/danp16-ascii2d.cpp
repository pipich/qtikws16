//
//  danp16-ascii2d.cpp
//  
//
//  Created by Vitaliy Pipich on 02.03.17.
//
//

#include "danp16.h"

#include "../standart-functions/standartFunctions.h"

#include <qfiledialog.h> 
#include <qspinbox.h>
#include <qlineedit.h>
#include <qregexp.h>
#include <qcombobox.h>
#include <qwidgetlist.h>
#include <qradiobutton.h>
#include <qinputdialog.h>

//
QString danp16::generateMatrixName(QString fn)
{
    bool findNumber=true;
    if (spinBoxFindIndex->currentItem()==0) findNumber=false;
    
    QString format;
    
    format="DAT-";
    
    // fing number
    int number=0;
    if (findNumber)
    {
        
        QRegExp rx("(\\d+)");
        int pos=0;
        while ( pos >= 0 && number<100)
        {
            pos = rx.search( fn, pos );
            number=rx.cap( 1 ).toInt();
            if ( pos > -1 ) pos  += rx.matchedLength();
        }
        if (number<100) findNumber=false;
    }
    
    if (findNumber)
    {
        format+=QString::number(number);
    }
    else
    {
        format+=fn.replace("_","-");
    }
    
    //
    
    format+="-v-";
    format=app(this)->generateUniqueName(format);
    
    return format;
}

//+++   Load DAT Matrix  +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::loadDATmatrixNew()
{
    app(this)->changeFolder("DANP :: ASCII.2D");
    
    //+++
    int iter;
    int line, posInLine;
    int ii,jj, pos;
    
    //+++
    QString fnameOnly;
    QString s,ss,nameMatrix;
    //+++
    
    //+++
    QString Dir=lineEditPath->text();
    
    //+++
    int 	dimensionX=spinBoxLoadDimension->value();
    int 	dimensionY=spinBoxLoadDimension_2->value();
    
    int 	positions=spinBoxLoadPos->value();
    int 	loadSkip=spinBoxLoadSkip->value();
    bool 	XtoY=checkBoxTranspose->isChecked();
    
    bool 	XtomX=checkBoxX2mX->isChecked();
    bool 	YtomY=checkBoxY2mY->isChecked();
    
    bool 	startEnd=checkBoxReadEnd->isChecked();
    
    //    QRegExp rx("((\\-|\\+)?\\d\\d*(\\.\\d*)?((E\\-|E\\+)\\d\\d?\\d?\\d?)?)");
    QRegExp rx("((\\-|\\+)?\\d\\d*(\\.\\d*)?(((e|E)\\-|(e|E)\\+)\\d\\d?\\d?\\d?)?)");  //very new
    
    
    if  (positions==0) return;
    
    int linesToRead=int ( dimensionX*dimensionY /positions);
    if ( ( dimensionX*dimensionY /positions) > linesToRead) linesToRead++;
    //+++
    QFileDialog *fd = new QFileDialog(Dir,"Rawdata (*.DAT *.dat)",this,"Getting File Information");
    fd->setDir(Dir);
    fd->setMode( QFileDialog::ExistingFiles );
    fd->setCaption(tr("QtiKWS - Getting File Information"));
    fd->addFilter( "All (*)" );
    
    //+++
    if ( fd->exec() == QDialog::Accepted )
    {
        //+++
        QStringList selectedDat=fd->selectedFiles();
        int filesNumber= selectedDat.count();
        
        //+++
        for(iter=0; iter<filesNumber;iter++)
        {
            //+++ Open File
            QFile f(selectedDat[iter]);
            QTextStream t( &f );
            f.open(IO_ReadOnly);
            QFileInfo fi(selectedDat[iter]);
            QString base = fi.baseName();
            
            for (line=1;  line<= loadSkip; line++) s = t.readLine();
            
            //matrix
            QString matrixName=generateMatrixName(base);
            
            Matrix* matrixDat;
            if ( XtoY )
            {
                matrixDat=app(this)->newMatrix(matrixName, dimensionX,dimensionY);
                matrixDat->setCoordinates(1,dimensionY,1,dimensionX);
                
            }
            else
            {
                matrixDat=app(this)->newMatrix(matrixName, dimensionY,dimensionX);
                matrixDat->setCoordinates(1,dimensionX,1,dimensionY);
            }
            
            
            ii=0;jj=0;
            
            for (line=0; line < linesToRead; line++)
            {
                s=t.readLine();
                s=s.stripWhiteSpace();
                s.replace(",",".");
                s.replace("e","E");
                s.replace("E","E0");
                s.replace("E0+","E+0");
                s.replace("E0-","E-0");
                s.replace("E0","E+0");
                pos=0;
                
                
                for (posInLine=1; posInLine <= positions; posInLine++)
                {
                    pos = rx.search( s, pos );
                    pos  += rx.matchedLength();
                    
                    if ( XtoY && !startEnd)
                        matrixDat->setText(ii,jj,rx.cap( 1 ));
                    else if ( !XtoY && startEnd) 
                        matrixDat->setText(dimensionY-jj-1,dimensionX-ii-1,rx.cap( 1 ));
                    else if ( XtoY && startEnd) 
                        matrixDat->setText(dimensionX-ii-1,dimensionY-jj-1,rx.cap( 1 ));
                    else
                        matrixDat->setText(jj,ii,rx.cap( 1 )); 
                    ii++;	
                    if (ii>=dimensionX) { ii=0; jj++;};
                    if (jj>=dimensionY) break;
                }
                if (jj>=dimensionY) break;
            }
            
            f.close();
        }	
    }
    app(this)->changeFolder("DANP :: ASCII.2D");
}

void danp16::deleteMatrix2Dformat()
{
    if (comboBoxInstrument->currentItem()<3)
    {
        return;
    }
    
    QString fileName=comboBoxInstrument->currentText();
    
    //+++
    QDir dd;
    QString formatsPath=app(this)->qtiKwsPath+"/matrixFormats";
    formatsPath=formatsPath.replace("//","/");
    if (!dd.cd(formatsPath))
    {
        formatsPath=QDir::homeDirPath()+"/matrixFormats";
        formatsPath=formatsPath.replace("//","/");
        
        if (!dd.cd(formatsPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/matrixFormats");
            dd.cd("./qtiKWS/matrixFormats");
        }
    };
    formatsPath=dd.absPath();
    
    dd.remove(fileName+".MSTR");
    
    findMatrixFormats();
    setSANSinstrument();
}

//++++++++++ Export Matrixes


QStringList danp16::matrixListSL()
{
    int i;
    QWidgetList *windows = app(this)->windowsList();
    QStringList list;
    list.empty();
    
    for (i=0;i<(int)windows->count();i++)
    {
        Matrix *m=(Matrix*)windows->at(i);
        if (m && m->isA("Matrix"))
        {
            list<<m->name();
        }
    }
    delete windows;
    
    return list;
}

QStringList danp16::matrixListSL(int xDim, int yDim)
{
    int i;
    QWidgetList *windows = app(this)->windowsList();
    QStringList list;
    list.empty();
    
    for (i=0;i<(int)windows->count();i++)
    {
        Matrix *m=(Matrix*)windows->at(i);
        if (m && m->isA("Matrix") && m->numRows()==yDim && m->numCols()==xDim)
        {
            list<<m->name();
        }
    }
    delete windows;
    
    return list;
}

QStringList danp16::matrixListSLm(QString matrix)
{
    int i;
    QWidgetList *windows = app(this)->windowsList();
    QStringList list;
    list.empty();
    
    int xD=0;
    int yD=0;
    
    for (i=0;i<(int)windows->count();i++)
    {
        Matrix *m=(Matrix*)windows->at(i);
        if (m && m->isA("Matrix") && m->name()==matrix)
        {
            yD=m->numRows();
            xD=m->numCols();
        }
    }
    
    delete windows;
    
    return matrixListSL(xD,yD);
}
//+++   export Matrix  +++

void danp16::matrixList()
{
    
    QStringList list=matrixListSL();
    
    
    QString comboBoxMlistOld=comboBoxMlist->currentText();
    comboBoxMlist->clear();
    
    QString comboBoxMlistMaskOld=comboBoxMlistMask->currentText();
    comboBoxMlistMask->clear();
    
    //+++ new:2015 (mask)
    QString comboBoxMaskForRadialAvOld=comboBoxMaskForRadialAv->currentText();
    comboBoxMaskForRadialAv->clear();
    
    
    comboBoxMlist->insertStringList(list);
    comboBoxMlistMask->insertStringList(list);
    comboBoxMaskForRadialAv->insertStringList(list);
    
    int iComboBoxMlistOld=-1;
    int iComboBoxMlistMaskOld=-1;
    int iComboBoxMaskForRadialAvOld=-1;
    
    for(int i=0; i<list.count();i++)
    {
        if (list[i]==comboBoxMlistOld) iComboBoxMlistOld=i;
        if (list[i]==comboBoxMlistMaskOld) iComboBoxMlistMaskOld=i;
        if (list[i]==comboBoxMaskForRadialAvOld) iComboBoxMaskForRadialAvOld=i;
    }
    
    
    if (iComboBoxMlistOld>=0 )   comboBoxMlist->setCurrentItem(iComboBoxMlistOld);
    if (iComboBoxMlistMaskOld>=0 )
    {
        comboBoxMlistMask->setCurrentItem(iComboBoxMlistMaskOld);
        matrixSelected(comboBoxMlistOld);
    }
    else  matrixSelected(list[0]);
    
    if (iComboBoxMaskForRadialAvOld>=0 )   comboBoxMaskForRadialAv->setCurrentItem(iComboBoxMaskForRadialAvOld);
    
}


void danp16::matrixSelected(const QString &mName)
{
    int i;
    QWidgetList *windows = app(this)->windowsList();
    
    for (i=0;i<(int)windows->count();i++)
    {
        Matrix *m=(Matrix*)windows->at(i);
        if (m && m->isA("Matrix") && mName==m->name())
        {
            
            spinBoxMy->setValue(m->numRows());
            spinBoxMx->setValue(m->numCols());
            
        }
    }
    delete windows;
}



void danp16::exportMatrix()
{
    QWidgetList *windows = app(this)->windowsList();
    
    for (int ww=0;ww<(int)windows->count();ww++)
    {
        Matrix *m=(Matrix*)windows->at(ww);
        if (m && m->isA("Matrix") && comboBoxMlist->currentText()==m->name())
        {
            //+++
            QString Dir=lineEditPathOut->text();
            
            //+ Dialog
            QString fileName= comboBoxMlist->currentText();
            fileName = QFileDialog::getSaveFileName(
                                                    Dir,
                                                    "(*.DAT )",
                                                    this,
                                                    "save Matrix dialog",
                                                    "Choose a Matrix-name to save under" );
            
            //+++ Interface info +++
            bool XtoY=checkBoxTransposeExport->isChecked(); // not yet ...
            bool XtomX=checkBoxX2mX->isChecked(); // not yet ...
            bool YtomY=checkBoxY2mY->isChecked(); // not yet ...
            
            bool startEnd=checkBoxReadEndExportM->isChecked();  // not yet ...
            int colNumber=spinBoxExpMatrixPos->value();
            int prec=spinBoxExPrecExportM->value();
            
            //+++ N
            int nTotal=m->numRows();
            nTotal*=m->numCols();
            
            
            //+++ Start +++
            QString spacer=" ";
            if (comboBoxSpacerExpM->currentText()=="Tab") spacer="\t";
            
            //+++
            QString s;
            int i,j;
            
            
            //+++ Open File
            if ( fileName.isEmpty() ) return;
            
            QFile f( fileName );
            //+++
            if ( !f.open( IO_WriteOnly ) )  return;
            
            
            QTextStream stream( &f );
            
            int curr=0;
            
            if (checkBoxSens->isChecked()) stream<<"$\n";
            if (!startEnd)
            {
                if (!XtoY)
                    for (i=0; i<m->numRows();i++) for (j=0; j<m->numCols();j++)
                    {
                        if (prec==-1)
                        {
                            s+=QString::number(QString::number(m->text(i,j).toDouble()).toInt()); s+=spacer;
                        }
                        else
                        {
                            s+=QString::number(m->text(i,j).toDouble(), 'e', prec); s+=spacer;
                        }
                        curr++;
                        if (curr==colNumber) { curr=0; stream<<s<<"\n";s="";};
                    }
                else
                    for (j=0; j<m->numCols();j++) for (i=0; i<m->numRows();i++)
                    {
                        if (prec==-1)
                        {
                            s+=QString::number(QString::number(m->text(i,j).toDouble()).toInt()); s+=spacer;
                        }
                        else
                        {
                            s+=QString::number(m->text(i,j).toDouble(), 'e', prec); s+=spacer;
                        }
                        curr++;
                        if (curr==colNumber) { curr=0; stream<<s<<"\n";s="";};
                    }
            }
            else
            {
                if (!XtoY)
                    for (i=(m->numRows()-1); i>=0;i--) for (j=(m->numCols()-1); j>=0;j--)
                    {
                        if (prec==-1)
                        {
                            s+=QString::number(QString::number(m->text(i,j).toDouble()).toInt()); s+=spacer;
                        }
                        else
                        {
                            s+=QString::number(m->text(i,j).toDouble(), 'e', prec); s+=spacer;
                        }
                        curr++;
                        if (curr==colNumber) { curr=0; stream<<s<<"\n";s="";};
                    }
                else 
                    for (j=(m->numCols()-1); j>=0;j--) for (i=(m->numRows()-1); i>=0;i--) 
                    {	
                        if (prec==-1) 
                        {
                            s+=QString::number(QString::number(m->text(i,j).toDouble()).toInt()); s+=spacer;
                        }
                        else
                        {
                            s+=QString::number(m->text(i,j).toDouble(), 'e', prec); s+=spacer;
                        }
                        curr++;
                        if (curr==colNumber) { curr=0; stream<<s<<"\n";s="";};
                    }
            }
            f.close();
        }
    }
    delete windows;
}	    


//+++ Export Matrix:: Check Sensitivity +++
void danp16::checkSensInExportMatrix()
{
    
    if (checkBoxSens->isChecked()) 
    {
        spinBoxExpMatrixPos->setEnabled(false);
        spinBoxExpMatrixPos->setValue(8);
        spinBoxExPrecExportM->setEnabled(false);
        spinBoxExPrecExportM->setValue(6);
        comboBoxSpacerExpM->setEnabled(false);
        comboBoxSpacerExpM->setCurrentItem(1);
        checkBoxTransposeExport->setEnabled(false);
        checkBoxTransposeExport->setChecked(false);
        
        checkBoxX2mX->setEnabled(false);
        checkBoxX2mX->setChecked(false);
        checkBoxY2mY->setEnabled(false);
        checkBoxY2mY->setChecked(false);
        
        checkBoxReadEndExportM->setEnabled(false);
        checkBoxReadEndExportM->setChecked(false);
    }
    else
    {
        spinBoxExpMatrixPos->setEnabled(true);
        spinBoxExPrecExportM->setEnabled(true);
        comboBoxSpacerExpM->setEnabled(true);
        checkBoxTransposeExport->setEnabled(true);
        
        checkBoxX2mX->setEnabled(false);
        checkBoxY2mY->setEnabled(false);
        
        checkBoxReadEndExportM->setEnabled(true);
    }
}


void danp16::mCalcSelected1()
{
    QStringList list=matrixListSL();
    list.sort();
    list.prepend("select matrix");
    
    QString selected=comboBoxMC1->currentText();
    
    comboBoxMC1->clear();
    comboBoxMC1->insertStringList(list);
    
    if ( list.contains(selected) )
    {
        comboBoxMC1->setCurrentText(selected);
        if (comboBoxMC1->currentItem()>0)
        {
            QStringList list2=matrixListSLm(comboBoxMC1->currentText());
            list2.sort();
            list2.prepend("select matrix");
            QString selected2=comboBoxMC2->currentText();
            comboBoxMC2->clear();
            comboBoxMC2->insertStringList(list2);
            
            
            if ( list2.contains(selected2) )
            {
                comboBoxMC2->setCurrentText(selected2);
            }
        }
        else
        {
            comboBoxMC2->clear();
            comboBoxMC2->insertItem("select matrix");
        }	    
    }
    else
    {
        comboBoxMC2->clear();
        comboBoxMC2->insertItem("select matrix");
    }
}


void danp16::mCalcSelected2()
{
    
}


void danp16::matrixCalculation()
{
    //	if (radioButtonOW3->isChecked()) app(this)->changeFolder("DANP :: ASCII.2D");
    
    mCalcSelected1();
    if (comboBoxMC1->currentItem()==0 || comboBoxMC2->currentItem()==0) return;
    
    QString matrix1=comboBoxMC1->currentText();
    QString matrix2=comboBoxMC2->currentText();
    QString matrix3;
    
    if (radioButtonOW3->isChecked())
    {
        bool ok;
        matrix3 = QInputDialog::getText(
                                        "QtiKWS", "Input Matrix Name:", QLineEdit::Normal,
                                        "matrix-new", &ok, this );
        if ( !ok ||  matrix3.isEmpty() )
        {
            return;
        }
    }
    
    int i,j;
    
    QWidgetList *windows = app(this)->windowsList();
    
    Matrix *m1;
    Matrix *m2;
    Matrix *m3;
    
    bool m1Exist=false;
    bool m2Exist=false;
    bool m3Exist=false;
    
    for (i=0;i<(int)windows->count();i++)
    {
        if (windows->at(i)->name()==matrix1 && windows->at(i)->isA("Matrix"))
        {
            m1=(Matrix*)windows->at(i);
            m1Exist=true;
        }
        if (windows->at(i)->name()==matrix2 && windows->at(i)->isA("Matrix"))
        {
            m2=(Matrix*)windows->at(i);
            m2Exist=true;
        }
        if (windows->at(i)->name()==matrix3 && windows->at(i)->isA("Matrix"))
        {
            m3=(Matrix*)windows->at(i);
            m3Exist=true;
        }
    }
    
    if (!m1Exist || !m2Exist) return;
    if (radioButtonOW3->isChecked() && !m3Exist )
    {
        m3=app(this)->newMatrix(matrix3, m1->numRows(),m1->numCols());
        m3->setCoordinates(1,m1->numRows(),1,m1->numCols());
    }
    
    double mm1, mm2, mm3;
    for (i=0; i<m1->numRows();i++) for (j=0; j<m1->numCols();j++)
    {
        mm1=m1->text(i,j).toDouble();
        mm2=m2->text(i,j).toDouble();
        //+++
        if (comboBoxAction->currentText()=="+")  mm3=mm1+mm2;
        else if (comboBoxAction->currentText()=="-")  mm3=mm1-mm2;
        else if (comboBoxAction->currentText()=="*") mm3=mm1*mm2;
        else
        {
            mm3=0.0;
            if (mm2!=0.0) mm3=mm1/mm2;
        }
        //+++
        if ( radioButtonOW1->isChecked() ) m1->setText(i,j,QString::number(mm3));
        else  if (radioButtonOW2->isChecked()) m2->setText(i,j,QString::number(mm3));
        else m3->setText(i,j,QString::number(mm3));
    }
    
    if (radioButtonOW1->isChecked()) m1->notifyChanges();
    if (radioButtonOW2->isChecked()) m2->notifyChanges();
    if (radioButtonOW3->isChecked()) m3->notifyChanges();
}



void danp16::mcCalculateScalar()
{
    //	if (radioButtonOW3->isChecked())  app(this)->changeFolder("DANP :: ASCII.2D");
    
    mCalcSelected1();
    if (comboBoxMC1->currentItem()==0) return;
    
    if (radioButtonOW2->isChecked() && comboBoxMC2->currentItem()==0 ) return;
    
    QString matrix1=comboBoxMC1->currentText();
    QString matrix2=comboBoxMC2->currentText();
    QString matrix3;
    
    if (radioButtonOW3->isChecked())
    {
        bool ok;
        matrix3 = QInputDialog::getText(
                                        "QtiKWS", "Input Matrix Name:", QLineEdit::Normal,
                                        "matrix-new", &ok, this );
        if ( !ok ||  matrix3.isEmpty() )
        {
            return;
        }
    }
    
    
    double scale=lineEditScalar->text().toDouble();
    
    if (scale==0 && comboBoxActionScalar->currentText()=="/") return;
    
    int i,j;
    
    QWidgetList *windows = app(this)->windowsList();
    Matrix *m1;
    Matrix *m2;
    Matrix *m3;
    
    bool m1Exist=false;
    bool m2Exist=false;
    bool m3Exist=false;
    
    for (i=0;i<(int)windows->count();i++)
    {
        if (windows->at(i)->name()==matrix1 && windows->at(i)->isA("Matrix"))
        {
            m1=(Matrix*)windows->at(i);
            m1Exist=true;
        }
        if (windows->at(i)->name()==matrix2 && windows->at(i)->isA("Matrix"))
        {
            m2=(Matrix*)windows->at(i);
            m2Exist=true;
        }
        if (windows->at(i)->name()==matrix3 && windows->at(i)->isA("Matrix"))
        {
            m3=(Matrix*)windows->at(i);
            m3Exist=true;
        }
    }
    
    if (!m1Exist ) return;
    
    if (!m2Exist && radioButtonOW2->isChecked() ) return;
    
    if (radioButtonOW3->isChecked() && !m3Exist )
    {
        m3=app(this)->newMatrix(matrix3, m1->numRows(),m1->numCols());
        m3->setCoordinates(1,m1->numRows(),1,m1->numCols());
    }
    
    QString action=comboBoxActionScalar->currentText();
    if (comboBoxActionScalar->currentItem()>3)
    {
        if (comboBoxActionScalar->currentItem()==4) m1->transpose();
        else if (comboBoxActionScalar->currentItem()==5) m1->X2mX();
        else if (comboBoxActionScalar->currentItem()==6) m1->Y2mY();
        else if (comboBoxActionScalar->currentItem()==7) m1->invert();
        action="+";
        scale=0.0;
    }
    
    
    for (i=0; i<m1->numRows();i++) for (j=0; j<m1->numCols();j++)
    {
        if (radioButtonOW1->isChecked())
        {
            if (action=="+")
                m1->setText(i,j,QString::number(m1->text(i,j).toDouble() + scale));
            if (action=="-")
                m1->setText(i,j,QString::number(m1->text(i,j).toDouble() - scale));
            if (action=="*")
                m1->setText(i,j,QString::number(m1->text(i,j).toDouble() * scale));
            if (action=="/")
                m1->setText(i,j,QString::number(m1->text(i,j).toDouble() / scale));
        }
        else if (radioButtonOW2->isChecked())
        {
            if (action=="+")
                m2->setText(i,j,QString::number(m1->text(i,j).toDouble() + scale));
            if (action=="-")
                m2->setText(i,j,QString::number(m1->text(i,j).toDouble() - scale));
            if (action=="*")
                m2->setText(i,j,QString::number(m1->text(i,j).toDouble() * scale));
            if (action=="/") 
                m2->setText(i,j,QString::number(m1->text(i,j).toDouble() / scale));
        }
        else if (radioButtonOW3->isChecked())
        {
            if (action=="+") 
                m3->setText(i,j,QString::number(m1->text(i,j).toDouble() + scale));
            if (action=="-") 
                m3->setText(i,j,QString::number(m1->text(i,j).toDouble() - scale));
            if (action=="*") 
                m3->setText(i,j,QString::number(m1->text(i,j).toDouble() * scale));
            if (action=="/") 
                m3->setText(i,j,QString::number(m1->text(i,j).toDouble() / scale));
        }
        
    }
    
    if (radioButtonOW1->isChecked()) m1->notifyChanges();
    if (radioButtonOW2->isChecked()) m2->notifyChanges();
    if (radioButtonOW3->isChecked()) m3->notifyChanges();
    
    //	app(this)->changeFolder("DANP :: ASCII.2D");	
}


//+++++++++++  Mask

void danp16::maskElips()
{
    if (checkBoxAllMatrixes->isChecked())
    {
        for (int i=0; i<comboBoxMlistMask->count(); i++)
            maskElipsInd(i);
    }
    else maskElipsInd(comboBoxMlistMask->currentItem());
}

void danp16::maskElipsInd(int number)
{
    QWidgetList *windows = app(this)->windowsList();
    Matrix *m;
    
    for (int ww=0;ww<(int)windows->count();ww++)
    {
        m=(Matrix*)windows->at(ww);
        if (m && m->isA("Matrix") && comboBoxMlistMask->text(number)==m->name())
        {
            double xCenter=lineEditXcenter->text().toDouble()-1;
            double yCenter=lineEditYcenter->text().toDouble()-1;
            double xSize=lineEditRx->text().toDouble();
            double ySize=lineEditRy->text().toDouble();
            bool maskInside=true;
            double newValue=lineEditValue->text().toDouble();
            
            if ( xSize==0 || ySize==0) return;
            if (comboBoxMaskInside->currentItem()==1) maskInside=false;
            
            for (int xx=0;xx<m->numCols();xx++) for (int yy=0; yy<m->numRows();yy++)
            {
                if ( maskInside && (xCenter-xx)*(xCenter-xx)*4/xSize/xSize+(yCenter-yy)*(yCenter-yy)*4/ySize/ySize<=1 ) m->setText(yy,xx,QString::number(newValue));
                
                if ( !maskInside && (xCenter-xx)*(xCenter-xx)*4/xSize/xSize+(yCenter-yy)*(yCenter-yy)*4/ySize/ySize>1 ) m->setText(yy,xx,QString::number(newValue));
            }
            m->notifyChanges();
        }
    }
}

void danp16::maskElipsShell()
{
    if (checkBoxAllMatrixes->isChecked())
    {
        for (int i=0; i<comboBoxMlistMask->count(); i++)
            maskElipsShellInd(i);
    }
    else maskElipsShellInd(comboBoxMlistMask->currentItem());
}

void danp16::maskElipsShellInd(int number)
{
    QWidgetList *windows = app(this)->windowsList();
    Matrix *m;
    
    for (int ww=0;ww<(int)windows->count();ww++)
    {
        m=(Matrix*)windows->at(ww);
        if (m && m->isA("Matrix") && comboBoxMlistMask->text(number)==m->name())
        {
            double xCenter=lineEditXcenter->text().toDouble()-1;
            double yCenter=lineEditYcenter->text().toDouble()-1;
            double xSize=lineEditRx->text().toDouble();
            double ySize=lineEditRy->text().toDouble();
            double shell=lineEditEllShell->text().toDouble();
            
            bool maskInside=true;
            double newValue=lineEditValue->text().toDouble();
            
            if ( xSize==0 ||  ySize==0 || shell==0 ) return;
            if (comboBoxMaskInside->currentItem()==1) maskInside=false;
            
            for (int xx=0;xx<m->numCols();xx++) for (int yy=0; yy<m->numRows();yy++)
            {
                if ( maskInside && (xCenter-xx)*(xCenter-xx)*4/(xSize+shell)/(xSize+shell)+(yCenter-yy)*(yCenter-yy)*4/(ySize+shell)/(ySize+shell)<=1 && (xCenter-xx)*(xCenter-xx)*4/(xSize-shell)/(xSize-shell)+(yCenter-yy)*(yCenter-yy)*4/(ySize-shell)/(ySize-shell)>=1) m->setText(yy,xx,QString::number(newValue));
                
                if ( !maskInside && ( (xCenter-xx)*(xCenter-xx)*4/(xSize+shell)/(xSize+shell)+(yCenter-yy)*(yCenter-yy)*4/(ySize+shell)/(ySize+shell)>1 || (xCenter-xx)*(xCenter-xx)*4/(xSize-shell)/(xSize-shell)+(yCenter-yy)*(yCenter-yy)*4/(ySize-shell)/(ySize-shell)< 1) ) m->setText(yy,xx,QString::number(newValue));
            }
            m->notifyChanges();
        }
    }
}

void danp16::maskSquared()
{
    if (checkBoxAllMatrixes->isChecked())
    {
        for (int i=0; i<comboBoxMlistMask->count(); i++)
            maskSquaredInd(i);
    }
    else maskSquaredInd(comboBoxMlistMask->currentItem());
}


void danp16::maskSquaredInd(int number)
{
    QWidgetList *windows = app(this)->windowsList();
    Matrix *m;
    
    for (int ww=0;ww<(int)windows->count();ww++)
    {
        m=(Matrix*)windows->at(ww);
        if (m && m->isA("Matrix") && comboBoxMlistMask->currentText()==m->name())
        {
            double xCenter=lineEditXcenter->text().toDouble()-1;
            double yCenter=lineEditYcenter->text().toDouble()-1;
            double xSize=lineEditXsize->text().toDouble();
            double ySize=lineEditYsize->text().toDouble();
            bool maskInside=true;
            double newValue=lineEditValue->text().toDouble();
            
            if (comboBoxMaskInside->currentItem()==1) maskInside=false;
            
            for (int xx=0;xx<m->numCols();xx++) for (int yy=0; yy<m->numRows();yy++)
            {
                if ( maskInside && xx <= (xCenter + xSize/2) && xx>= (xCenter - xSize/2) && yy<= (yCenter + ySize/2) && yy>= (yCenter - ySize/2) ) m->setText(yy,xx,QString::number(newValue));
                
                if ( !maskInside && (xx> (xCenter + xSize/2) || xx< (xCenter - xSize/2) || yy> (yCenter + ySize/2) || yy< (yCenter - ySize/2) )) m->setText(yy,xx,QString::number(newValue));
            }
            m->notifyChanges();
        }
    }
    
}

void danp16::maskSector()
{
    if (checkBoxAllMatrixes->isChecked())
    {
        for (int i=0; i<comboBoxMlistMask->count(); i++)
            maskSectorInd(i);
    }
    else maskSectorInd(comboBoxMlistMask->currentItem());
}


void danp16::maskSectorInd(int number)
{
    QWidgetList *windows = app(this)->windowsList();
    Matrix *m;
    
    for (int ww=0;ww<(int)windows->count();ww++)
    {
        m=(Matrix*)windows->at(ww);
        if (m && m->isA("Matrix") && comboBoxMlistMask->text(number)==m->name())
        {
            double xCenter=lineEditXcenter->text().toDouble()-1;
            double yCenter=lineEditYcenter->text().toDouble()-1;
            double phiMin=spinBoxAngleFrom->value();
            double phiMax=spinBoxAngleTo->value();
            double currentPhi;
            bool maskInside=true;
            double newValue=lineEditValue->text().toDouble();
            
            if (comboBoxMaskInside->currentItem()==1) maskInside=false;
            
            for (int xx=0;xx<m->numCols();xx++) for (int yy=0; yy<m->numRows();yy++)
            {
                double rr=sqrt ( (xx-xCenter)*(xx-xCenter) + (yy-yCenter)*(yy-yCenter));
                if (xx>=xCenter && yy>=yCenter && rr>0) currentPhi=asin((xx-xCenter)/rr)/M_PI*180;
                else if (xx>=xCenter && yy<yCenter && rr>0) currentPhi=90+asin((yCenter-yy)/rr)/M_PI*180;
                else if (xx<xCenter && yy<=yCenter && rr>0) currentPhi=180+asin((xCenter-xx)/rr)/M_PI*180;
                else if (xx<xCenter && yy>yCenter && rr>0) currentPhi=270+asin((yy-yCenter)/rr)/M_PI*180;
                else currentPhi=phiMin;
                
                if ( maskInside && currentPhi >= phiMin && currentPhi <= phiMax) m->setText(yy,xx,QString::number(newValue));
                
                if ( !maskInside && ( currentPhi < phiMin || currentPhi > phiMax ) ) m->setText(yy,xx,QString::number(newValue));
            }
            m->notifyChanges();
        }	
    }
    
}

//+++ mask:: set value +++
void danp16::maskSetValue()
{    
    QWidgetList *windows = app(this)->windowsList();
    Matrix *m;
    
    for (int ww=0;ww<(int)windows->count();ww++)
    {
        m=(Matrix*)windows->at(ww);
        if (m && m->isA("Matrix") && comboBoxMlistMask->currentText()==m->name())
        {
            double newValue=lineEditValue->text().toDouble();
            
            for (int xx=0;xx<m->numCols();xx++) for (int yy=0; yy<m->numRows();yy++)
            {
                m->setText(yy,xx,QString::number(newValue));		
            }
            //m->cellEdited(0,0);
            m->notifyChanges();
        }	
    }
}

void danp16::saveMatrix2Dformat()
{
    //+++
    QDir dd;
    QString formatsPath=app(this)->qtiKwsPath+"/matrixFormats";
    formatsPath=formatsPath.replace("//","/");
    if (!dd.cd(formatsPath))
    {
        formatsPath=QDir::homeDirPath()+"/matrixFormats";
        formatsPath=formatsPath.replace("//","/");
        
        if (!dd.cd(formatsPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/matrixFormats");
            dd.cd("./qtiKWS/matrixFormats");
        }
    };
    formatsPath=dd.absPath();
    
    bool ok=false;
    
    QString fileName=comboBoxInstrument->currentText();
    
    while (ok==false)
    {
        fileName = QInputDialog::getText(
                                         "QtiKWS", "Input 2D-format Name:", QLineEdit::Normal,
                                         fileName, &ok, this );
        if ( !ok ||  fileName.isEmpty() )
        {
            return;
        }
        
        if (fileName=="KWS1&2" || fileName=="Small Detector" || fileName=="Other || Save" )
        {
            ok=false;
            fileName=="";
        }
    }
    
    QString s;
    s ="lines_in_header\t"+QString::number(spinBoxLoadSkip->value())+"\n";
    s+="numbers_per_line\t"+QString::number(spinBoxLoadPos->value())+"\n";
    s+="matrix_structure\t"+QString::number(spinBoxLoadDimension->value())+"\t"+QString::number(spinBoxLoadDimension_2->value())+"\n";
    s+="transpose_x_y\t"+QString::number(checkBoxTranspose->isChecked())+"\n";
    s+="start_from_end\t"+QString::number(checkBoxReadEnd->isChecked())+"\n";
    
    
    
    QFile f(formatsPath+"/"+fileName+".MSTR");
    
    
    if ( !f.open( IO_WriteOnly ) )
    {
        //*************************************Log Window Output
        QMessageBox::warning(this,"Could not write to file", tr("qtiKWS::DANP"));
        //*************************************Log Window Output
        return;
    }	
    QTextStream stream( &f );
    stream<<s;
    f.close();	
    
    findMatrixFormats();
    
    comboBoxInstrument->setCurrentText(fileName);
    
    return;
    
    
}


void danp16::matrixFormatsChanged()
{
    //+++
    QDir dd;
    QString formatsPath=app(this)->qtiKwsPath+"/matrixFormats";
    formatsPath=formatsPath.replace("//","/");
    if (!dd.cd(formatsPath))
    {
        formatsPath=QDir::homeDirPath()+"/matrixFormats";
        formatsPath=formatsPath.replace("//","/");
        
        if (!dd.cd(formatsPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/matrixFormats");
            dd.cd("./qtiKWS/matrixFormats");
        }
    };
    formatsPath=dd.absPath();
    
    if (comboBoxInstrument->currentItem() > 2)
    {
        QFile f(formatsPath+"/"+comboBoxInstrument->currentText()+".MSTR") ;
        if ( !f.open( IO_ReadOnly ) ) return;
        
        QTextStream t( &f );
        QRegExp rx("(\\d+)");
        QString s;
        int currentValue;
        int pos;
        
        while(!t.atEnd())
        {
            pos=0;
            s=t.readLine().stripWhiteSpace();
            pos = rx.search( s, pos );
            pos += rx.matchedLength();
            currentValue=rx.cap( 1 ).toInt();
            
            if (s.contains("header")) spinBoxLoadSkip->setValue(currentValue);
            if (s.contains("numbers_per_line")) spinBoxLoadPos->setValue(currentValue);
            if (s.contains("structure"))
            {
                spinBoxLoadDimension->setValue(currentValue);
                
                pos = rx.search( s, pos );
                
                if (pos>0) spinBoxLoadDimension_2->setValue(rx.cap( 1 ).toInt());
                else spinBoxLoadDimension_2->setValue(currentValue);
            }
            if (s.contains("transpose")) if (currentValue==0) checkBoxTranspose->setChecked(false); else checkBoxTranspose->setChecked(true);
            if (s.contains("X2mX")) if (currentValue==0) checkBoxX2mX->setChecked(false); else checkBoxX2mX->setChecked(true);
            if (s.contains("Y2mY")) if (currentValue==0) checkBoxY2mY->setChecked(false); else checkBoxY2mY->setChecked(true);
            if (s.contains("from_end")) if (currentValue==0) checkBoxReadEnd->setChecked(false); else checkBoxReadEnd->setChecked(true);
        }
        f.close();
    }
}




//
void danp16::radUniHF
(
 int chanellNumberX,int chanellNumberY,
 gsl_matrix *Sample, gsl_matrix *SampleErr,  gsl_matrix *mask,
 double XYcenter, double YXcenter,
 QString sampleMatrix,
 QString label
 )
{
    //+++
    double Xcenter=XYcenter;
    double Ycenter=YXcenter;
    
    //+++
    int numRowsOut=0;
    
    //+++ Table Name
    QString tableOUT;
    tableOUT="CI-"+sampleMatrix+"-";
    tableOUT=app(this)->generateUniqueName(tableOUT);
    
    //+++ RAD-table
    Table *wOut;
    
    //+++
    
    wOut=app(this)->newHiddenTable(tableOUT,label, 0, 3);
    
    wOut->setColName(0,"Channel");
    wOut->setColName(1,"I");
    wOut->setColName(2,"dI");
    
    wOut->setWindowLabel(label);
    app(this)->setListViewLabel(wOut->name(), label);
    app(this)->updateWindowLists(wOut);
    
    wOut->setColPlotDesignation(2,Table::yErr);
    wOut->setHeaderColType();
    
    //------------------------------------
    // calculation of radial averaging
    //------------------------------------
    
    
    double Xc=(double(chanellNumberX)-1)/2;
    double Yc=(double(chanellNumberY)-1)/2;
    
    double R;
    
    double rmax =  sqrt( (Xcenter)*(Xcenter) + ( Ycenter)*(Ycenter));
    rmax = GSL_MAX(rmax, (sqrt(((chanellNumberX-1) -
                                Xcenter)*((chanellNumberX-1) - Xcenter) + (Ycenter)*(Ycenter))));
    rmax = GSL_MAX(rmax,sqrt(((chanellNumberX-1) -
                              Xcenter)*((chanellNumberX-1) - Xcenter) + ((chanellNumberY-1) -
                                                                         Ycenter)*((chanellNumberY-1) - Ycenter)));
    rmax = GSL_MAX(rmax,sqrt(( Xcenter)*(Xcenter) + ((chanellNumberY-1)
                                                     - Ycenter)*((chanellNumberY-1) - Ycenter)));
    
    int ir,ii;                  //iR iPhi...
    int ix1,iy1,ix2,iy2;                //...
    int msk, phisteps;          //mask &
    
    double qr,phi,xs,ys,rex,rey;
    double wt;
    
    double pi=M_PI;
    double  twt ;                       // totales Gewicht    >>>RESET<<<
    double avg;                 // Mittel
    double avge;                        //Fehler
    
    
    double sigmaErr;
    
    QString streamSTR="";
    
    for(ir=0;ir<=int(rmax-0.5);ir++)
    {
        //      qr  = 2.*pi/lambda *  (1.0/radInter*ir*detelem/detdist);
        qr  = ir;  // test
        
        phisteps =int( GSL_MAX( int(4*pi*ir+0.5), 4) );
        
        twt = 0.0;      //      ! totales Gewicht    >>>RESET<<<
        avg = 0.0;      //      ! Mittel
        avge= 0.0;      //      ! Fehler
        
        
        
        for(ii=0;ii<=(phisteps-1);ii++)
        {
            //+++ Phi
            phi = 2.*pi*ii/phisteps;
            
            //+++
            xs  = Xcenter + ir * cos(phi);
            ys  = Ycenter + ir * sin(phi);
            
            //+++
            R=sqrt((xs-Xc)*(xs-Xc)+(ys-Yc)*(ys-Yc));
            
            //+++
            ix1 = int(xs);      //         ! Eckpunkte
            iy1 = int(ys);
            ix2 = ix1 + 1;
            iy2 = iy1 + 1;
            
            rex = xs - ix1;     //        ! Reste f"ur Gewichtung sp"ater
            rey = ys - iy1;
            
            msk = 0;    //        ! linker unterer Punkt
            
            
            if (ix1>=0 && ix1<chanellNumberX && iy1>=0 && iy1<chanellNumberY)
            {
                //+++
                msk=gsl_matrix_get(mask,iy1,ix1); if (msk>0) msk=1;
                wt  = msk*(1.0-rex)*(1.0-rey);
                twt += wt;
                avg += wt *gsl_matrix_get(Sample,iy1,ix1);
                
                //+++
                avge += wt*fabs(gsl_matrix_get(Sample,iy1,ix1));
            }
            
            msk=0;
            if (ix2>=0 && ix2<chanellNumberX && iy1>=0 && iy1<chanellNumberY)
            {
                //+++
                msk=gsl_matrix_get(mask,iy1,ix2);if (msk>0) msk=1;
                wt  = msk*(rex)*(1.0-rey);
                twt +=  wt;
                avg += wt*gsl_matrix_get(Sample,iy1,ix2);
                
                //+++err
                avge += wt*fabs(gsl_matrix_get(Sample,iy1, ix2));
            }
            
            msk=0;
            if (ix1>=0 && ix1<chanellNumberX && iy2>=0 && iy2<chanellNumberY)
            {
                //+++
                msk=gsl_matrix_get(mask,iy2,ix1);if (msk>0) msk=1;
                wt  = msk* (1.0-rex)*(rey);
                twt += wt;
                avg += wt*gsl_matrix_get(Sample,iy2,ix1);
                
                //+++err
                avge += wt*fabs(gsl_matrix_get(Sample,iy2,ix1));
            }
            
            msk=0;
            if (ix2>=0 && ix2<chanellNumberX && iy2>=0 && iy2<chanellNumberY)
            {
                //+++
                msk=gsl_matrix_get(mask,iy2,ix2);if (msk>0) msk=1;
                wt  = msk* (rex)*(rey);
                twt += wt;
                avg += wt * gsl_matrix_get(Sample,iy2,ix2);
                
                //+++erri
                avge +=wt*fabs(gsl_matrix_get(Sample,iy2,ix2));
            }
        }
        
        //+++  Mean Value
        if (twt>0.0  && checkBoxNormNumberPixels->isChecked())
        {
            avge=sqrt(avge)  / twt;
            avg = avg / twt;
        }
        
        if (twt>0.0)
        {
            //
            double Q,I,dI;
            double QQ, II, dII;
            Q=qr;
            I=avg;
            dI=avge;
            
            QQ=qr;
            II=avg;
            dII=avge;
            
            //+++ Create QI table +++
            wOut->setNumRows(numRowsOut+1);
            wOut->setText(numRowsOut,0,QString::number(QQ*lineEditRscale->text().toDouble(),'e',5));
            wOut->setText(numRowsOut,1,QString::number(II*lineEditIscale->text().toDouble(),'e',5));
            wOut->setText(numRowsOut,2,QString::number(dII*lineEditIscale->text().toDouble(),'e',5));
            numRowsOut++;
        }
        
    }
}

void danp16::make_GSL_Matrix(Matrix *m, gsl_matrix * &gmatrix)
{
    
    //+++
    int i,j;
    //+++
    QString ss;
    //+++
    int chanellNumberX=m->numCols();
    int chanellNumberY=m->numRows();
    
    for (i=0;i<chanellNumberY;i++) for (j=0;j<chanellNumberX;j++)
    {
        gsl_matrix_set(gmatrix, i, j,  m->text(i,j).toDouble() ); //Matrix transfer
    }
}

void danp16::make_GSL_Matrix_Err(Matrix *m, gsl_matrix * &gmatrix)
{
    
    //+++
    int i,j;
    //+++
    QString ss;
    //+++
    int chanellNumberX=m->numCols();
    int chanellNumberY=m->numRows();
    
    for (i=0;i<chanellNumberY;i++) for (j=0;j<chanellNumberX;j++)
    {
        if (m->text(i,j).toDouble() != 0.0) gsl_matrix_set(gmatrix, i, j,  1 / m->text(i,j).toDouble() ); //Matrix transfer
        else gsl_matrix_set(gmatrix, i, j,  0.0 ); //Matrix transfer
    }
}

void danp16::radUniHFcall()
{
    //	app(this)->changeFolder("DANP :: ASCII.2D");
    
    if (checkBoxAllMatrixes->isChecked())
    {
        for (int i=0; i<comboBoxMlistMask->count(); i++)
            radUniHFcallind(i);
    }
    else radUniHFcallind(comboBoxMlistMask->currentItem());
    
    //	app(this)->changeFolder("DANP :: ASCII.2D");
}

void danp16::radUniHFcallind(int number)
{
    
    QWidgetList *windows = app(this)->windowsList();
    
    Matrix *sample;
    bool exist=false;
    
    for (int ww=0;ww<(int)windows->count();ww++)
    {
        if (windows->at(ww)->isA("Matrix") && comboBoxMlistMask->text(number)==windows->at(ww)->name())
        {
            sample=(Matrix*)windows->at(ww);
            exist=true;
        }
        
    }
    
    if(!exist) return;
    
    
    int chanellNumberX=sample->numCols();
    int chanellNumberY=sample->numRows();
    
    gsl_matrix *Sample=gsl_matrix_alloc(chanellNumberY,chanellNumberX);
    make_GSL_Matrix(sample, Sample);
    
    gsl_matrix *SampleErr=gsl_matrix_alloc(chanellNumberY,chanellNumberX);
    make_GSL_Matrix_Err(sample, SampleErr);
    
    
    
    Matrix *mask;
    
    bool existMask=false;
    for (int ww=0;ww<(int)windows->count();ww++)
    {
        if (windows->at(ww)->isA("Matrix") && comboBoxMaskForRadialAv->currentText()==windows->at(ww)->name())
        {
            mask=(Matrix*)windows->at(ww);
            if (mask->numCols()==chanellNumberX && mask->numRows()==chanellNumberY) existMask=true;
        }
        
    }
    
    gsl_matrix *Mask=gsl_matrix_alloc(chanellNumberY,chanellNumberX);
    if (existMask) make_GSL_Matrix(mask, Mask);
    else gsl_matrix_set_all(Mask,1.0);
    
    
    
    
    double XYcenter=lineEditXcenter->text().toDouble()-1;
    double YXcenter=lineEditYcenter->text().toDouble()-1;
    
    QString sampleMatrix=sample->name();
    QString label="Radial averaged matrix :: " + comboBoxMlistMask->currentText();
    
    radUniHF(chanellNumberX, chanellNumberY, Sample, SampleErr, Mask, XYcenter, YXcenter, sampleMatrix, label);
    
    gsl_matrix_free(Sample);
    gsl_matrix_free(SampleErr);
    gsl_matrix_free(Mask);
}
