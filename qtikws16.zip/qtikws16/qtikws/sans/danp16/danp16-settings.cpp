#include "danp16.h"

#include "../standart-functions/standartFunctions.h"

#include <qlineedit.h>
#include <qfiledialog.h>
#include <qregexp.h>
#include <qcombobox.h>
#include <qspinbox.h>
#include <qpushbutton.h>
#include <qinputdialog.h>
#include <qtoolbutton.h>
#include <qsettings.h>
#include <iostream>


//*******************************************
//+++  Read settings
//*******************************************
void danp16::readSettings()
{
#ifdef Q_OS_MAC // Mac
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
    
    settings.setPath("JCNS", "QtiKWS", QSettings::User);
    
    bool ok;
    QString ss;
    
    settings.beginGroup("/DANP");
    
    ss=settings.readEntry("/DANP_lineEditPath",0,&ok); if (ok && ss.left(4)!="home") { lineEditPath->setText(ss); strPath=ss;}
    
    ss=settings.readEntry("/DANP_lineEditPathOut",0,&ok); if (ok && ss.left(4)!="home") { lineEditPathOut->setText(ss);}
    
    if (ss.left(4)=="home" && strPath.left(4)!="home")  {lineEditPathOut->setText(strPath);}
    
    //---data
    ss=settings.readEntry("/DANP_From",0,&ok); if (ok) lineEditFileFirst->setText(ss);
    ss=settings.readEntry("/DANP_To",0,&ok); if (ok) lineEditFileLast->setText(ss);
    ss=settings.readEntry("/DANP_Step",0,&ok); if (ok) lineEditFileStep->setText(ss);
    ss=settings.readEntry("/DANP_Suffix",0,&ok); if (ok) lineEditFileSuffix->setText(ss);
    //---reso
    ss=settings.readEntry("/DANP_reso_C",0,&ok); if (ok) lineEditResoCol->setText(ss);
    ss=settings.readEntry("/DANP_reso_D",0,&ok); if (ok) lineEditResoDet->setText(ss);
    ss=settings.readEntry("/DANP_reso_pixel",0,&ok); if (ok) lineEditResoPixelSize->setText(ss);
    ss=settings.readEntry("/DANP_reso_sApper",0,&ok); if (ok) lineEditResoSamAper->setText(ss);
    ss=settings.readEntry("/DANP_reso_cApper",0,&ok); if (ok) lineEditResoColAper->setText(ss);
    ss=settings.readEntry("/DANP_reso_lambda",0,&ok); if (ok) lineEditResoLambda->setText(ss);
    ss=settings.readEntry("/DANP_reso_dLambda",0,&ok); if (ok) lineEditResoDeltaLambda->setText(ss);
    
    //---csv
    //ss=settings.readEntry("/DANP_CSV_startLine",0,&ok); if (ok) {startingLineCSV->setText(ss); }
    //ss=settings.readEntry("/DANP_CSV_headerLine",0,&ok); if (ok) headerLineCSV->setText(ss);
    //ss=settings.readEntry("/DANP_CSV_dataSplitter",0,&ok); if (ok) csvSplitter->setCurrentItem(ss.toInt());
    
    settings.endGroup();
}

//*******************************************
//+++  Write settings
//*******************************************
void danp16::writeSettings()
{
#ifdef Q_OS_MAC // Mac
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
    QString ss;
    
    settings.setPath("JCNS", "QtiKWS", QSettings::User);
    //
    //DANP
    settings.beginGroup("/DANP");
    
    if (lineEditPath->text()!="home") settings.writeEntry("/DANP_lineEditPath",  lineEditPath->text());
    if (lineEditPathOut->text()!="home") settings.writeEntry("/DANP_lineEditPathOut",  lineEditPathOut->text());
    //---data
    settings.writeEntry("/DANP_From",  lineEditFileFirst->text());
    settings.writeEntry("/DANP_To",  lineEditFileLast->text());
    settings.writeEntry("/DANP_Step",  lineEditFileStep->text());
    settings.writeEntry("/DANP_Suffix",  lineEditFileSuffix->text());
    //---reso
    ss=settings.writeEntry("/DANP_reso_C",lineEditResoCol->text());
    ss=settings.writeEntry("/DANP_reso_D",lineEditResoDet->text());
    ss=settings.writeEntry("/DANP_reso_pixel",lineEditResoPixelSize->text());
    ss=settings.writeEntry("/DANP_reso_sApper",lineEditResoSamAper->text());
    ss=settings.writeEntry("/DANP_reso_cApper",lineEditResoColAper->text());
    ss=settings.writeEntry("/DANP_reso_lambda",lineEditResoLambda->text());
    ss=settings.writeEntry("/DANP_reso_dLambda",lineEditResoDeltaLambda->text());
    //---csv
    if (startingLineCSV->text()!="")
    {
        settings.writeEntry("/DANP_CSV_startLine",  startingLineCSV->text());
        settings.writeEntry("/DANP_CSV_headerLine",  headerLineCSV->text());
        settings.writeEntry("/DANP_CSV_dataSplitter",  QString::number(csvSplitter->currentItem()));
    }
    settings.endGroup();
}

void danp16::readSettingsCSV()
{
#ifdef Q_OS_MAC // Mac
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
    
    settings.setPath("JCNS", "QtiKWS", QSettings::User);
    
    bool ok;
    QString ss;
    
    settings.beginGroup("/DANP");
    
    //---csv
    ss=settings.readEntry("/DANP_CSV_startLine",0,&ok); if (ok) {startingLineCSV->setText(ss); }
    ss=settings.readEntry("/DANP_CSV_headerLine",0,&ok); if (ok) headerLineCSV->setText(ss);
    ss=settings.readEntry("/DANP_CSV_dataSplitter",0,&ok); if (ok) csvSplitter->setCurrentItem(ss.toInt());
    
    settings.endGroup();
    
}

//+++++  forceReadSettings +++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::forceReadSettings()
{
    if (lineEditPath->text()=="home" || lineEditPathOut->text()=="home") readSettings();
}

