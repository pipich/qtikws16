//
//  danp16-ascii1d.cpp
//
//
//  Created by Vitaliy Pipich on 01.01.17.
//
//
#include "danp16.h"

#include "../standart-functions/standartFunctions.h"
#include "../../src/multilayer.h"
#include "../../src/Spectrogram.h"

#include <qlineedit.h>
#include <qfiledialog.h>
#include <qregexp.h>
#include <qcombobox.h>
#include <qspinbox.h>
#include <qpushbutton.h>
#include <qinputdialog.h>
#include <qtoolbutton.h>
#include <qsettings.h>
#include <qworkspace.h>
#include <qaction.h>
#include <qradiobutton.h>

#include <iostream>

void danp16::readDisplay()
{
    QString info=app(this)->info->text();
    
    QStringList lst=lst.split(";",info);
    
    QString xs=lst[2].remove("ix=").remove(" ");
    xs=QString::number(xs.toDouble(),'f',3);
    lineEditXcenter->setText(xs);
    
    
    QString ys=lst[3].remove("iy=").remove(" ");
    ys=QString::number(ys.toDouble(),'f',3);
    lineEditYcenter->setText(ys);
}


void danp16::activeMatrixUpdate()
{
    QStringList list=matrixListSL();
    list.sort();
    list.prepend("select matrix");
    
    QString selected=comboBoxActiveMatrix->currentText();
    
    comboBoxActiveMatrix->clear();
    comboBoxActiveMatrix->insertStringList(list);
    
    if ( list.contains(selected) )
    {
        comboBoxActiveMatrix->setCurrentText(selected);
    }
}

void danp16::activeMatrixSelected()
{
    
    QStringList list=matrixListSL();
    list.sort();
    list.prepend("select matrix");
    
    QString selected=comboBoxActiveMatrix->currentText();
    
    comboBoxActiveMatrix->clear();
    comboBoxActiveMatrix->insertStringList(list);
    
    if ( list.contains(selected) )
    {
        comboBoxActiveMatrix->setCurrentText(selected);
    }
    else return;
    
    if (comboBoxActiveMatrix->currentItem()==0) return;
    
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer")) return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>There are no plot layers available in this window.</h4>"
                                "<p><h4>Please add a layer and try again!</h4>"));
        return;
    }
    
    if (!plot) return;
    
    Graph* g = (Graph*)plot->activeGraph();
    if (!g) return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        return;
    }
    
    QwtPlotCurve *c = g->curve(0);
    if (!c)
        return;
    
    if (c->rtti() != QwtPlotItem::Rtti_PlotSpectrogram) return;
    
    QwtPlotItem *ii = (QwtPlotItem*)g->curve(0);
    Spectrogram *sp = (Spectrogram *)ii;
    
    QWidgetList *windows = app(this)->windowsList();
    
    for (int i=0;i<(int)windows->count();i++)
    {
        if (windows->at(i)->name()==selected && windows->at(i)->isA("Matrix"))
        {
            Matrix *m=(Matrix*)windows->at(i);
            
            sp->updateData(m);
            const QString sss=selected;
            const QStringList lst(sss);
            sp->updateData(m);
            
            ii->setTitle(sss);
            g->setPlotAssociations(lst);
            if (checkBoxShowInTitle->isChecked()) g->setTitle(m->windowLabel());
            textLabelMatrix->setText(m->windowLabel());
            
            colorSchemSelectedNotColor();
            g->replot();//2017 BUG-AF    
            
            break;
        }
    }  
    
    
}

//+++  SANS Instrument  +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::setSANSinstrument()
{
    if (comboBoxInstrument->currentText()=="KWS1&2") {
        spinBoxLoadSkip->setValue(70);
        spinBoxLoadSkip->setEnabled(FALSE);
        spinBoxLoadPos->setValue(8);
        spinBoxLoadPos->setEnabled(FALSE);
        spinBoxLoadDimension->setValue(128);
        spinBoxLoadDimension_2->setValue(128);
        spinBoxLoadDimension->setEnabled(FALSE);
        spinBoxLoadDimension_2->setEnabled(FALSE);
        checkBoxTranspose->setEnabled(FALSE);
        checkBoxTranspose->setChecked(FALSE);
        
        //  2012
        checkBoxX2mX->setEnabled(FALSE);
        checkBoxX2mX->setChecked(FALSE);
        checkBoxY2mY->setEnabled(FALSE);
        checkBoxY2mY->setChecked(FALSE);
        
        checkBoxReadEnd->setEnabled(FALSE);
        checkBoxReadEnd->setChecked(FALSE);
        pushButtonsaveCurrentSave2Dtype->setEnabled(FALSE);
        pushButtonDeleteCurrentSave2Dtype->setEnabled(FALSE);
    }
    else if (comboBoxInstrument->currentText()=="Small Detector") {
        spinBoxLoadSkip->setValue(0);
        spinBoxLoadSkip->setEnabled(FALSE);
        spinBoxLoadPos->setValue(256);
        spinBoxLoadPos->setEnabled(FALSE);
        spinBoxLoadDimension->setValue(256);
        spinBoxLoadDimension_2->setValue(256);
        spinBoxLoadDimension->setEnabled(FALSE);
        spinBoxLoadDimension_2->setEnabled(FALSE);
        checkBoxTranspose->setEnabled(FALSE);
        checkBoxTranspose->setChecked(TRUE);
        
        //  2012
        checkBoxX2mX->setEnabled(FALSE);
        checkBoxX2mX->setChecked(FALSE);
        checkBoxY2mY->setEnabled(FALSE);
        checkBoxY2mY->setChecked(FALSE);
        
        checkBoxReadEnd->setEnabled(FALSE);
        checkBoxReadEnd->setChecked(FALSE);
        pushButtonsaveCurrentSave2Dtype->setEnabled(FALSE);
        pushButtonDeleteCurrentSave2Dtype->setEnabled(FALSE);
    }
    else if (comboBoxInstrument->currentText()=="Other || Save")
    {
        spinBoxLoadSkip->setEnabled(TRUE);
        spinBoxLoadPos->setEnabled(TRUE);
        spinBoxLoadDimension->setEnabled(TRUE);
        spinBoxLoadDimension_2->setEnabled(TRUE);
        checkBoxTranspose->setEnabled(TRUE);
        
        //  2012
        checkBoxX2mX->setEnabled(TRUE);
        checkBoxY2mY->setEnabled(TRUE);
        
        checkBoxReadEnd->setEnabled(TRUE);
        pushButtonsaveCurrentSave2Dtype->setEnabled(TRUE);
        pushButtonDeleteCurrentSave2Dtype->setEnabled(FALSE);
    }
    else
    {
        spinBoxLoadSkip->setEnabled(TRUE);
        spinBoxLoadPos->setEnabled(TRUE);
        spinBoxLoadDimension->setEnabled(TRUE);
        spinBoxLoadDimension_2->setEnabled(TRUE);	
        checkBoxTranspose->setEnabled(TRUE);
        //  2012
        checkBoxX2mX->setEnabled(TRUE);
        checkBoxY2mY->setEnabled(TRUE);	
        
        checkBoxReadEnd->setEnabled(TRUE);
        pushButtonsaveCurrentSave2Dtype->setEnabled(TRUE);
        pushButtonDeleteCurrentSave2Dtype->setEnabled(TRUE);
    }
    matrixFormatsChanged();   
}


//++++
void danp16::rescale2Dplot()
{
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer")) return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>There are no plot layers available in this window.</h4>"
                                "<p><h4>Please add a layer and try again!</h4>"));
        return;
    }
    
    if (!plot) return;
    
    Graph* g = (Graph*)plot->activeGraph();
    if (!g) return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        app(this)->btnPointer->setOn(true);
        return;
    }
    QStringList axes;
    
    QString ax,ay;
    
    //+++ changed 09.11.2009 4pi--> 2pi
    ax="2*pi/"+QString::number(lineEditResoLambdaRescale->text().toDouble())+"*sin(atan((x-(";
    ay=ax+QString::number(lineEditResoDeltaYcenter->text().toDouble());
    ax=ax+QString::number(lineEditResoDeltaXcenter->text().toDouble());
    
    ay=ay+"))*"+QString::number(lineEditResoPixelSizeRescale->text().toDouble())+"/"+QString::number(lineEditDetRescale->text().toDouble())+"))";
    
    ax=ax+"))*"+QString::number(lineEditResoPixelSizeRescale->text().toDouble())+"/"+QString::number(lineEditDetRescale->text().toDouble())+"))";
    
    
    g->setLabelsNumericFormat(QwtPlot::yLeft, 3, 1, ay);
    g->setAxisTicksLength(QwtPlot::yLeft, 3, 3,5, 9);
    
    g->setLabelsNumericFormat(QwtPlot::xBottom, 3, 1, ax);
    g->setAxisTicksLength(QwtPlot::xBottom, 3, 3,5, 9);
    
    g->drawAxesBackbones(true);
    
    QString ss="[";
    ss+=QChar(197);
    ss+="<sup>-1</sup>]";
    
    g->setXAxisTitle("Q<sub>x</sub>"+ss);
    g->setYAxisTitle("Q<sub>y</sub>"+ss);
    g->setRightAxisTitle("Intensity");
    
    g->emitModified();
    g->replot();
    
    g->drawAxesBackbones(false);
    
    
    g->emitModified();
    g->replot();    
    
}



void danp16::changeSpecrogram()
{
    colorSchemChanged(FALSE);
}


void danp16::colorSchemSelected()
{
    colorSchemChanged(true);
}

void danp16::colorSchemSelectedNotColor()
{
    colorSchemChanged(false);
}

void danp16::colorSchemChanged(bool chColor)
{
    if (!app(this)->ws->activeWindow() ) return;
    
    if ( app(this)->ws->activeWindow()->isA( "Graph3D" )) return colorSchemChanged3d(chColor);
    
    if (!app(this)->ws->activeWindow()->isA("MultiLayer")) return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>There are no plot layers available in this window.</h4>"
                                "<p><h4>Please add a layer and try again!</h4>"));
        return;
    }
    
    if (!plot) return;
    
    Graph* g = (Graph*)plot->activeGraph();
    
    colorSchemChanged(chColor, g);
}


void danp16::colorSchemChanged3d(bool chColor)
{
    
    Graph3D* plot= ( Graph3D* ) app(this)->ws->activeWindow();
    
    if (chColor)
    {
        //+++
        QDir dd;
        QString colorPath=app(this)->qtiKwsPath+"/colorMaps";
        colorPath=colorPath.replace("//","/");
        if (!dd.cd(colorPath))
        {
            colorPath=QDir::homeDirPath()+"/colorMaps";
            colorPath=colorPath.replace("//","/");
            
            if (!dd.cd(colorPath))
            {
                dd.cd(QDir::homeDirPath());
                dd.mkdir("./qtiKWS/colorMaps");
                dd.cd("./qtiKWS/colorMaps");
            }
        };
        colorPath=dd.absPath();
        
        plot->setDataColorMap(colorPath+"/"+comboBoxSchema->currentText()+".MAP");
        
        return;
    }
    
    QStringList scaleLimits=plot->scaleLimits();
    
    if (radioButton2DplotAbsolute->isChecked())
    {
        scaleLimits[10]=lineEditMinAbs->text();
        scaleLimits[11]=lineEditMaxAbs->text();
    }
    else
    {
        double min=lineEditMin->text().toDouble();
        double max=lineEditMax->text().toDouble();
        
        if (min<0 || min >=1) { min=0; lineEditMin->setText("0.0");};
        if (max<=0 || max >1) { max=1; lineEditMax->setText("1.0");};
        
        if (min>max)
        {
            min=0; lineEditMin->setText("0.0");
            max=1; lineEditMax->setText("1.0");
        }
        
        double *mmax=new double[1];
        double *mmin=new double[1];
        plot->maxmin(mmin,mmax);
        
        double relmin=mmin[0]+(mmax[0]-mmin[0])*min;
        double relmax=mmin[0]+(mmax[0]-mmin[0])*max;
        
        
        scaleLimits[10]=QString::number(relmin);
        scaleLimits[11]=QString::number(relmax);
        
        if (checkBoxLog->isChecked()) scaleLimits[14]="1";
        else scaleLimits[14]="0";
    }
    
    plot->updateScales(scaleLimits[0].toDouble(), scaleLimits[1].toDouble(), scaleLimits[5].toDouble(), scaleLimits[6].toDouble(), scaleLimits[10].toDouble(), scaleLimits[11].toDouble());
    
    app(this)->fitFrameToLayer();
}


void danp16::colorSchemChanged(bool chColor, Graph* g)
{
    if (radioButton2DplotAbsolute->isChecked()) return colorSchemChangedAbs(chColor, g);
    
    
    if (!g) return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        return;
    }
    
    
    QwtPlotCurve *c = g->curve(0);
    if (!c)
        return;
    
    if (c->rtti() != QwtPlotItem::Rtti_PlotSpectrogram) return;
    
    //+++
    QDir dd;
    QString colorPath=app(this)->qtiKwsPath+"/colorMaps";
    colorPath=colorPath.replace("//","/");
    if (!dd.cd(colorPath))
    {
        colorPath=QDir::homeDirPath()+"/colorMaps";
        colorPath=colorPath.replace("//","/");
        
        if (!dd.cd(colorPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/colorMaps");
            dd.cd("./qtiKWS/colorMaps");
        }
    };
    colorPath=dd.absPath();
    
    QValueList<int> lR, lG, lB;
    int numberColors=0;
    
    if (comboBoxSchema->currentItem() > 2)
    {
        
        QFile f(colorPath+"/"+comboBoxSchema->currentText()+".MAP");
        if ( !f.open( IO_ReadOnly ) ) return;
        
        QTextStream t( &f );
        
        bool realColor;
        
        QString s;
        
        QRegExp rx("(\\d+)");
        int pos, NN, colorRGB;
        
        
        
        int nR, nG, nB;
        while(!t.atEnd())
        {
            s=t.readLine().stripWhiteSpace();
            
            realColor=true;
            pos = 0;
            NN=0;
            
            while ( pos >= 0  && NN<3 && realColor)
            {
                pos = rx.search( s, pos );
                
                colorRGB=rx.cap( 1 ).toInt();
                if (NN==0) nR=colorRGB;
                if (NN==1) nG=colorRGB;
                if (NN==2) nB=colorRGB;
                
                if ( pos > -1 && colorRGB>=0 && colorRGB<=255 )
                {
                    pos  += rx.matchedLength();
                    NN++;
                }
                else realColor=false;
            }
            if (NN==3 && realColor)
            {
                numberColors++;
                lR<<nR;lG<<nG;lB<<nB;
            }
        }
        numberColors=numberColors-2;
        f.close();
    }
    else if (comboBoxSchema->currentItem() == 2)
    {
        lR<<0; lG<<0; lB<<143;
        lR<<0; lG<<0; lB<<159;
        lR<<0; lG<<0; lB<<175;
        lR<<0; lG<<0; lB<<191;
        lR<<0; lG<<0; lB<<207;
        lR<<0; lG<<0; lB<<223;
        lR<<0; lG<<0; lB<<239;
        lR<<0; lG<<0; lB<<255;
        lR<<0; lG<<15; lB<<255;
        lR<<0; lG<<31; lB<<255;
        lR<<0; lG<<47; lB<<255;
        lR<<0; lG<<63; lB<<255;
        lR<<0; lG<<79; lB<<255;
        lR<<0; lG<<95; lB<<255;
        lR<<0; lG<<111; lB<<255;
        lR<<0; lG<<127; lB<<255;
        lR<<0; lG<<143; lB<<255;
        lR<<0; lG<<159; lB<<255;
        lR<<0; lG<<175; lB<<255;
        lR<<0; lG<<191; lB<<255;
        lR<<0; lG<<207; lB<<255;
        lR<<0; lG<<223; lB<<255;
        lR<<0; lG<<239; lB<<255;
        lR<<0; lG<<255; lB<<255;
        lR<<15; lG<<255; lB<<239;
        lR<<31; lG<<255; lB<<223;
        lR<<47; lG<<255; lB<<207;
        lR<<63; lG<<255; lB<<191;
        lR<<79; lG<<255; lB<<175;
        lR<<95; lG<<255; lB<<159;
        lR<<111; lG<<255; lB<<143;
        lR<<127; lG<<255; lB<<127;
        lR<<143; lG<<255; lB<<111;
        lR<<159; lG<<255; lB<<95;
        lR<<175; lG<<255; lB<<79;
        lR<<191; lG<<255; lB<<63;
        lR<<207; lG<<255; lB<<47;
        lR<<223; lG<<255; lB<<31;
        lR<<239; lG<<255; lB<<15;
        lR<<255; lG<<255; lB<<0;
        lR<<255; lG<<239; lB<<0;
        lR<<255; lG<<223; lB<<0;
        lR<<255; lG<<207; lB<<0;
        lR<<255; lG<<191; lB<<0;
        lR<<255; lG<<175; lB<<0;
        lR<<255; lG<<159; lB<<0;
        lR<<255; lG<<143; lB<<0;
        lR<<255; lG<<127; lB<<0;
        lR<<255; lG<<111; lB<<0;
        lR<<255; lG<<95; lB<<0;
        lR<<255; lG<<79; lB<<0;
        lR<<255; lG<<63; lB<<0;
        lR<<255; lG<<47; lB<<0;
        lR<<255; lG<<31; lB<<0;
        lR<<255; lG<<15; lB<<0;
        lR<<255; lG<<0; lB<<0;
        lR<<239; lG<<0; lB<<0;
        lR<<223; lG<<0; lB<<0;
        lR<<207; lG<<0; lB<<0;
        lR<<191; lG<<0; lB<<0;
        lR<<175; lG<<0; lB<<0;
        lR<<159; lG<<0; lB<<0;
        lR<<143; lG<<0; lB<<0;
        lR<<127; lG<<0; lB<<0;
        numberColors=62;
        
    }
    else if (comboBoxSchema->currentItem() == 1)
    {
        lR<<0; lG<<0;lB<<0; //"black"
        lR<<0; lG<<0;lB<<255; //"blue"
        lR<<0; lG<<255;lB<<0; //"green"
        lR<<255; lG<<255;lB<<0; //"yellow"
        lR<<255; lG<<0;lB<<255; //"magenta"
        lR<<255; lG<<0;lB<<0; //"red"
        lR<<255; lG<<255;lB<<255; //"white"
        numberColors=5;
    }
    else
    {
        
        lR<<0; lG<<0;lB<<255;
        lR<<0; lG<<255;lB<<255;
        lR<<0; lG<<255;lB<<0; //"green"
        lR<<255; lG<<255;lB<<0; //"yellow"
        lR<<255; lG<<0;lB<<0; //"red"
        numberColors=3;
    }
    
    
    
    
    //+++ relative color scale
    double min=lineEditMin->text().toDouble();
    double max=lineEditMax->text().toDouble();
    
    if (min<0 || min >=1) { min=0; lineEditMin->setText("0.0");};
    if (max<=0 || max >1) { max=1; lineEditMax->setText("1.0");};
    
    if (min>max)
    {
        min=0; lineEditMin->setText("0.0");
        max=1; lineEditMax->setText("1.0");
    }
    //--- relative color scale
    
    //+++ first and last color
    QColor colF, colL;
    colF.setRgb(lR[0],lG[0],lB[0]);
    colL.setRgb(lR[numberColors+1],lG[numberColors+1],lB[numberColors+1]);
    QwtLinearColorMap colorMap(colF, colL);
    
    //+++ Matrix Min & Max
    double mindata,maxdata;
    
    //+++
    Spectrogram *sp = (Spectrogram *)c;
    sp->MMatrix()->range(&mindata, &maxdata);
    
    //+++ in case of log scale
    double realMin=mindata;
    
    //+++
    if (mindata<=0 && checkBoxLog->isChecked())
    {
        realMin=maxdata;
        double tmp;
        for (int i = 0; i < sp->MMatrix()->numRows(); i++)   for (int j = 0; j < sp->MMatrix()->numCols(); j++)
        {
            tmp=sp->MMatrix()->text (i, j).toDouble();
            if(tmp>0 && tmp<realMin) realMin=tmp;
        }
        if (realMin==maxdata) realMin=maxdata/10.0;
    }
    
    //+++
    double deltaAbs=maxdata-realMin;
    //+++
    double minAbs=realMin+min*deltaAbs;
    double maxAbs=maxdata-(1-max)*deltaAbs;
    //+++
    double minRel= (minAbs-mindata)/(maxdata-mindata);
    double maxRel= (maxAbs-mindata)/(maxdata-mindata);
    //+++
    int levels=numberColors+2;
    //+++
    double deltaRel=(maxRel-minRel)/(levels-1);
    //+++
    if(deltaAbs==0.0) {levels=0; deltaRel=0;};
    
    //+++
    for (int i=0;i<levels;i++)
    {
        //+++
        QColor col;
        col.setRgb(lR[i],lG[i],lB[i]);
        
        //+++
        if (checkBoxLog->isChecked())
        {
            colorMap.addColorStop(maxRel*pow(10,  (-log10(maxRel)+log10(minRel)) * (levels-1-i) / (levels-1)), col);
        }
        else
        {
            colorMap.addColorStop(minRel+deltaRel*i, col);
        }
    }
    
    //+++
    sp->setCustomColorMap(colorMap);
    sp->setLevelsNumber(sp->levels());
    
    //+++
    if (1==0)
    {
        g->setScale(QwtPlot::xBottom, sp->MMatrix()->xStart(), sp->MMatrix()->xEnd(), 0, 8, 4, 0,false);
        g->setScale(QwtPlot::yLeft,sp->MMatrix()->yStart(), sp->MMatrix()->yEnd(), 0, 8, 4, 0,false);
        g->setScale(QwtPlot::xTop,sp->MMatrix()->xStart(), sp->MMatrix()->xEnd(), 0, 8, 4, 0,false);
        g->setScale(QwtPlot::yRight,sp->MMatrix()->yStart(), sp->MMatrix()->yEnd(), 0, 8, 4, 0,false);
    }
    
    //+++
    if (checkBoxLog->isChecked() && realMin>0)
    {
        int numberOfMajorTicks=18;
        //	g->setScale(QwtPlot::yRight,realMin/1.5, maxdata*1.5,0, numberOfMajorTicks, 9, 1,false);
        //	if (minAbs==maxAbs || realMin==maxAbs) { minAbs/=10.0; 	int numberOfMajorTicks=5;};
        g->setScale(QwtPlot::yRight,minAbs*0.9, maxAbs*1.1,0, numberOfMajorTicks, 9, 1,false);
        g->setLabelsNumericFormat(QwtPlot::yRight, 0, 4, "");
    }
    else
    {
        //	g->setScale(QwtPlot::yRight,realMin, maxdata, 0, 8, 5, 0,false);
        g->setScale(QwtPlot::yRight,minAbs, maxAbs, 0, 8, 5, 0,false);
        
        g->setLabelsNumericFormat(QwtPlot::yRight, 0, 4, "");
    }
    
    //+++
    g->emitModified();
    g->replot();
}

void danp16::colorSchemChangedAbs(bool chColor, Graph* g)
{
    
    if (!g) return;
    
    if (g->isPiePlot())
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("This functionality is not available for pie plots!"));
        
        return;
    }
    
    
    QwtPlotCurve *c = g->curve(0);
    if (!c)
        return;
    
    if (c->rtti() != QwtPlotItem::Rtti_PlotSpectrogram) return;
    
    //+++
    QDir dd;
    QString colorPath=app(this)->qtiKwsPath+"/colorMaps";
    colorPath=colorPath.replace("//","/");
    if (!dd.cd(colorPath))
    {
        colorPath=QDir::homeDirPath()+"/colorMaps";
        colorPath=colorPath.replace("//","/");
        
        if (!dd.cd(colorPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/colorMaps");
            dd.cd("./qtiKWS/colorMaps");
        }
    };
    colorPath=dd.absPath();
    
    QValueList<int> lR, lG, lB;
    int numberColors=0;
    
    if (comboBoxSchema->currentItem() > 2)
    {
        
        QFile f(colorPath+"/"+comboBoxSchema->currentText()+".MAP");
        if ( !f.open( IO_ReadOnly ) ) return;
        
        QTextStream t( &f );
        
        bool realColor;
        
        QString s;
        
        QRegExp rx("(\\d+)");
        int pos, NN, colorRGB;
        
        
        
        int nR, nG, nB;
        while(!t.atEnd())
        {
            s=t.readLine().stripWhiteSpace();
            
            realColor=true;
            pos = 0;
            NN=0;
            
            while ( pos >= 0  && NN<3 && realColor)
            {
                pos = rx.search( s, pos );
                
                colorRGB=rx.cap( 1 ).toInt();
                if (NN==0) nR=colorRGB;
                if (NN==1) nG=colorRGB;
                if (NN==2) nB=colorRGB;
                
                if ( pos > -1 && colorRGB>=0 && colorRGB<=255 )
                {
                    pos  += rx.matchedLength();
                    NN++;
                }
                else realColor=false;
            }
            if (NN==3 && realColor)
            {
                numberColors++;
                lR<<nR;lG<<nG;lB<<nB;
            }
        }
        numberColors=numberColors-2;
        f.close();
    }
    else if (comboBoxSchema->currentItem() == 2)
    {
        lR<<0; lG<<0; lB<<143;
        lR<<0; lG<<0; lB<<159;
        lR<<0; lG<<0; lB<<175;
        lR<<0; lG<<0; lB<<191;
        lR<<0; lG<<0; lB<<207;
        lR<<0; lG<<0; lB<<223;
        lR<<0; lG<<0; lB<<239;
        lR<<0; lG<<0; lB<<255;
        lR<<0; lG<<15; lB<<255;
        lR<<0; lG<<31; lB<<255;
        lR<<0; lG<<47; lB<<255;
        lR<<0; lG<<63; lB<<255;
        lR<<0; lG<<79; lB<<255;
        lR<<0; lG<<95; lB<<255;
        lR<<0; lG<<111; lB<<255;
        lR<<0; lG<<127; lB<<255;
        lR<<0; lG<<143; lB<<255;
        lR<<0; lG<<159; lB<<255;
        lR<<0; lG<<175; lB<<255;
        lR<<0; lG<<191; lB<<255;
        lR<<0; lG<<207; lB<<255;
        lR<<0; lG<<223; lB<<255;
        lR<<0; lG<<239; lB<<255;
        lR<<0; lG<<255; lB<<255;
        lR<<15; lG<<255; lB<<239;
        lR<<31; lG<<255; lB<<223;
        lR<<47; lG<<255; lB<<207;
        lR<<63; lG<<255; lB<<191;
        lR<<79; lG<<255; lB<<175;
        lR<<95; lG<<255; lB<<159;
        lR<<111; lG<<255; lB<<143;
        lR<<127; lG<<255; lB<<127;
        lR<<143; lG<<255; lB<<111;
        lR<<159; lG<<255; lB<<95;
        lR<<175; lG<<255; lB<<79;
        lR<<191; lG<<255; lB<<63;
        lR<<207; lG<<255; lB<<47;
        lR<<223; lG<<255; lB<<31;
        lR<<239; lG<<255; lB<<15;
        lR<<255; lG<<255; lB<<0;
        lR<<255; lG<<239; lB<<0;
        lR<<255; lG<<223; lB<<0;
        lR<<255; lG<<207; lB<<0;
        lR<<255; lG<<191; lB<<0;
        lR<<255; lG<<175; lB<<0;
        lR<<255; lG<<159; lB<<0;
        lR<<255; lG<<143; lB<<0;
        lR<<255; lG<<127; lB<<0;
        lR<<255; lG<<111; lB<<0;
        lR<<255; lG<<95; lB<<0;
        lR<<255; lG<<79; lB<<0;
        lR<<255; lG<<63; lB<<0;
        lR<<255; lG<<47; lB<<0;
        lR<<255; lG<<31; lB<<0;
        lR<<255; lG<<15; lB<<0;
        lR<<255; lG<<0; lB<<0;
        lR<<239; lG<<0; lB<<0;
        lR<<223; lG<<0; lB<<0;
        lR<<207; lG<<0; lB<<0;
        lR<<191; lG<<0; lB<<0;
        lR<<175; lG<<0; lB<<0;
        lR<<159; lG<<0; lB<<0;
        lR<<143; lG<<0; lB<<0;
        lR<<127; lG<<0; lB<<0;
        numberColors=62;
        
    }
    else if (comboBoxSchema->currentItem() == 1)
    {
        lR<<0; lG<<0;lB<<0; //"black"
        lR<<0; lG<<0;lB<<255; //"blue"
        lR<<0; lG<<255;lB<<0; //"green"
        lR<<255; lG<<255;lB<<0; //"yellow"
        lR<<255; lG<<0;lB<<255; //"magenta"
        lR<<255; lG<<0;lB<<0; //"red"
        lR<<255; lG<<255;lB<<255; //"white"
        numberColors=5;
    }
    else
    {
        
        lR<<0; lG<<0;lB<<255;
        lR<<0; lG<<255;lB<<255;
        lR<<0; lG<<255;lB<<0; //"green"
        lR<<255; lG<<255;lB<<0; //"yellow"
        lR<<255; lG<<0;lB<<0; //"red"
        numberColors=3;
    }
    
    
    
    //+++ abs. color scale
    double minAbs=lineEditMinAbs->text().toDouble();
    double maxAbs=lineEditMaxAbs->text().toDouble();
    
    //+++ Matrix Min & Max
    double minData,maxData;
    Spectrogram *sp = (Spectrogram *)c;
    sp->MMatrix()->range(&minData, &maxData); 
    
    //+++ first and last color
    QColor colF, colL;    
    
    if (minAbs>=minData) colF.setRgb(lR[0],lG[0],lB[0]);
    if (maxAbs<=maxData) colL.setRgb(lR[numberColors+1],lG[numberColors+1],lB[numberColors+1]);    
    if (minAbs>=maxData) colL.setRgb(lR[0],lG[0],lB[0]);
    if (maxAbs<=minData) colF.setRgb(lR[numberColors+1],lG[numberColors+1],lB[numberColors+1]);    
    
    //+++
    int levels=numberColors+2;    
    
    bool changeColF=false;
    bool changeColL=false;
    int firstLevel=0;
    int lastLevel=levels-1;
    
    double currentLevelValue, nextLevelValue;
    
    double scaleColF=0;
    double scaleColL=0;
    
    
    double deltaAbsLine=(maxAbs-minAbs)/(levels-1);
    //+++
    for (int i=0;i<levels-1;i++) 
    {
        currentLevelValue=minAbs+i*deltaAbsLine;
        nextLevelValue=minAbs+(i+1)*deltaAbsLine;
        
        if (currentLevelValue<minData && nextLevelValue>=minData)
        {
            firstLevel=i+1;
            changeColF=true;
            scaleColF=(minData-currentLevelValue)/deltaAbsLine;
        }
        
        if (currentLevelValue<maxData && nextLevelValue>=maxData)
        {
            lastLevel=i;
            changeColL=true;
            scaleColL=(maxData-currentLevelValue)/deltaAbsLine;
        }
        
    }
    
    if (changeColF) colF.setRgb(lR[firstLevel-1]+int(scaleColF*(lR[firstLevel]-lR[firstLevel-1])) ,lG[firstLevel-1]+scaleColF*(lG[firstLevel]-lG[firstLevel-1]),lB[firstLevel-1]+scaleColF*(lB[firstLevel]-lB[firstLevel-1]));
    
    if (changeColL) colL.setRgb(lR[lastLevel]+scaleColL*(lR[lastLevel+1]-lR[lastLevel]) ,lG[lastLevel]+scaleColL*(lG[lastLevel+1]-lG[lastLevel]),lB[lastLevel]+scaleColL*(lB[lastLevel+1]-lB[lastLevel]));
    
    
    levels=lastLevel-firstLevel+1;
    
    if (minAbs>=maxData || maxAbs<=minData) 
    {
        levels=0;
        firstLevel=0;
        lastLevel=0;
    }
    
    
    
    QwtLinearColorMap colorMap(colF, colL);
    
    
    //+++
    for (int i=firstLevel;i<=lastLevel;i++) 
    {
        //+++
        QColor col;
        col.setRgb(lR[i],lG[i],lB[i]);
        
        colorMap.addColorStop((minAbs+deltaAbsLine*i-minData)/(maxData-minData), col); 
    }
    
    //+++
    sp->setCustomColorMap(colorMap);
    sp->setLevelsNumber(sp->levels());
    
    //+++
    g->setScale(QwtPlot::xBottom, sp->MMatrix()->xStart(), sp->MMatrix()->xEnd(), 0, 8, 4, 0,false);
    g->setScale(QwtPlot::yLeft,sp->MMatrix()->yStart(), sp->MMatrix()->yEnd(), 0, 8, 4, 0,false);
    g->setScale(QwtPlot::xTop,sp->MMatrix()->xStart(), sp->MMatrix()->xEnd(), 0, 8, 4, 0,false);
    g->setScale(QwtPlot::yRight,sp->MMatrix()->yStart(), sp->MMatrix()->yEnd(), 0, 8, 4, 0,false);
    
    g->setScale(QwtPlot::yRight,minAbs, maxAbs, 0, 8, 5, 0,false);	
    g->setLabelsNumericFormat(QwtPlot::yRight, 0, 4, "");	
    
    //+++    
    g->emitModified();
    g->replot();     
}



void danp16::open2dColorSequenceAsTable()
{
    //+++ new : 2016
    QDir dd;
    QString colorPath=app(this)->qtiKwsPath+"/colorMaps";
    colorPath=colorPath.replace("//","/");
    if (!dd.cd(colorPath))
    {
        colorPath=QDir::homeDirPath()+"/colorMaps";
        colorPath=colorPath.replace("//","/");
        
        if (!dd.cd(colorPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/colorMaps");
            dd.cd("./qtiKWS/colorMaps");
        }
    };
    colorPath=dd.absPath();
    
    QValueList<int> lR, lG, lB;
    int numberColors=0;
    QString fileName=comboBoxSchema->currentText();
    
    if (comboBoxSchema->currentItem() > 2)
    {
        
        QFile f(colorPath+"/"+fileName+".MAP");
        if ( !f.open( IO_ReadOnly ) ) return;
        
        QTextStream t( &f );
        
        bool realColor;
        
        QString s;
        
        QRegExp rx("(\\d+)");
        int pos, NN, colorRGB;
        
        
        
        int nR, nG, nB;
        while(!t.atEnd())
        {
            s=t.readLine().stripWhiteSpace();
            
            realColor=true;
            pos = 0;
            NN=0;
            
            while ( pos >= 0  && NN<3 && realColor)
            {
                pos = rx.search( s, pos );
                
                colorRGB=rx.cap( 1 ).toInt();
                if (NN==0) nR=colorRGB;
                if (NN==1) nG=colorRGB;
                if (NN==2) nB=colorRGB;
                
                if ( pos > -1 && colorRGB>=0 && colorRGB<=255 )
                {
                    pos  += rx.matchedLength();
                    NN++;
                }
                else realColor=false;
            }
            if (NN==3 && realColor)
            {
                numberColors++;
                lR<<nR;lG<<nG;lB<<nB;
            }
        }
        numberColors=numberColors-2;
        f.close();
    }
    else if (comboBoxSchema->currentItem() == 2)
    {
        lR<<0; lG<<0; lB<<143;
        lR<<0; lG<<0; lB<<159;
        lR<<0; lG<<0; lB<<175;
        lR<<0; lG<<0; lB<<191;
        lR<<0; lG<<0; lB<<207;
        lR<<0; lG<<0; lB<<223;
        lR<<0; lG<<0; lB<<239;
        lR<<0; lG<<0; lB<<255;
        lR<<0; lG<<15; lB<<255;
        lR<<0; lG<<31; lB<<255;
        lR<<0; lG<<47; lB<<255;
        lR<<0; lG<<63; lB<<255;
        lR<<0; lG<<79; lB<<255;
        lR<<0; lG<<95; lB<<255;
        lR<<0; lG<<111; lB<<255;
        lR<<0; lG<<127; lB<<255;
        lR<<0; lG<<143; lB<<255;
        lR<<0; lG<<159; lB<<255;
        lR<<0; lG<<175; lB<<255;
        lR<<0; lG<<191; lB<<255;
        lR<<0; lG<<207; lB<<255;
        lR<<0; lG<<223; lB<<255;
        lR<<0; lG<<239; lB<<255;
        lR<<0; lG<<255; lB<<255;
        lR<<15; lG<<255; lB<<239;
        lR<<31; lG<<255; lB<<223;
        lR<<47; lG<<255; lB<<207;
        lR<<63; lG<<255; lB<<191;
        lR<<79; lG<<255; lB<<175;
        lR<<95; lG<<255; lB<<159;
        lR<<111; lG<<255; lB<<143;
        lR<<127; lG<<255; lB<<127;
        lR<<143; lG<<255; lB<<111;
        lR<<159; lG<<255; lB<<95;
        lR<<175; lG<<255; lB<<79;
        lR<<191; lG<<255; lB<<63;
        lR<<207; lG<<255; lB<<47;
        lR<<223; lG<<255; lB<<31;
        lR<<239; lG<<255; lB<<15;
        lR<<255; lG<<255; lB<<0;
        lR<<255; lG<<239; lB<<0;
        lR<<255; lG<<223; lB<<0;
        lR<<255; lG<<207; lB<<0;
        lR<<255; lG<<191; lB<<0;
        lR<<255; lG<<175; lB<<0;
        lR<<255; lG<<159; lB<<0;
        lR<<255; lG<<143; lB<<0;
        lR<<255; lG<<127; lB<<0;
        lR<<255; lG<<111; lB<<0;
        lR<<255; lG<<95; lB<<0;
        lR<<255; lG<<79; lB<<0;
        lR<<255; lG<<63; lB<<0;
        lR<<255; lG<<47; lB<<0;
        lR<<255; lG<<31; lB<<0;
        lR<<255; lG<<15; lB<<0;
        lR<<255; lG<<0; lB<<0;
        lR<<239; lG<<0; lB<<0;
        lR<<223; lG<<0; lB<<0;
        lR<<207; lG<<0; lB<<0;
        lR<<191; lG<<0; lB<<0;
        lR<<175; lG<<0; lB<<0;
        lR<<159; lG<<0; lB<<0;
        lR<<143; lG<<0; lB<<0;
        lR<<127; lG<<0; lB<<0;
        numberColors=62;
        
    }
    else if (comboBoxSchema->currentItem() == 1)
    {
        lR<<0; lG<<0;lB<<0; //"black"
        lR<<0; lG<<0;lB<<255; //"blue"
        lR<<0; lG<<255;lB<<0; //"green"
        lR<<255; lG<<255;lB<<0; //"yellow"
        lR<<255; lG<<0;lB<<255; //"magenta"
        lR<<255; lG<<0;lB<<0; //"red"
        lR<<255; lG<<255;lB<<255; //"white"
        numberColors=5;
    }
    else
    {
        
        lR<<0; lG<<0;lB<<255;
        lR<<0; lG<<255;lB<<255;
        lR<<0; lG<<255;lB<<0; //"green"
        lR<<255; lG<<255;lB<<0; //"yellow"
        lR<<255; lG<<0;lB<<0; //"red"
        numberColors=3;
    }
    
    int levels=numberColors+2;
    
    
    //+++ create table
    QString tableName="MAP";
    tableName=app(this)->generateUniqueName(tableName);
    Table* w=app(this)->newHiddenTable(tableName,fileName, levels ,4);
    
    w->setColName(0,"#");
    w->setColName(1,"Red");
    w->setColName(2,"Green");
    w->setColName(3,"Blue");
    
    //+++
    for (int i=0; i<levels; i++)
    {
        w->setText(i,0,QString::number(i+1));
        w->setText(i,1,QString::number(lR[i]));
        w->setText(i,2,QString::number(lG[i]));
        w->setText(i,3,QString::number(lB[i]));
    }
    
    //+++
    for (int tt=0; tt<w->numCols(); tt++)
    {
        w->table()->adjustColumn (tt);
        w->table()->setColumnWidth(tt, w->table()->columnWidth(tt)+10);
    }
    
    w->setHeaderColType();
    
    app(this)->updateWindowLists(w);
    
    w->setWindowLabel(fileName);
    app(this)->setListViewLabel(w->name(),fileName);
    app(this)->updateWindowLists(w);
    
    w->showMaximized();
}

void danp16::saveCurrentTableAsColorSequence()
{
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("Table"))
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>FIRST, activate COLOR table.</h4>"));
        return;
    }
    Table* w=(Table*)app(this)->ws->activeWindow();
    
    if (!w)	return;
    
    
    if (!w->colName(0).contains("#")) return;
    
    
    //+++
    QDir dd;
    QString colorPath=app(this)->qtiKwsPath+"/colorMaps";
    colorPath=colorPath.replace("//","/");
    if (!dd.cd(colorPath))
    {
        colorPath=QDir::homeDirPath()+"/colorMaps";
        colorPath=colorPath.replace("//","/");
        
        if (!dd.cd(colorPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/colorMaps");
            dd.cd("./qtiKWS/colorMaps");
        }
    };
    colorPath=dd.absPath();
    
    bool ok=false;
    
    QString fileName=comboBoxSchema->currentText();
    
    while (ok==false)
    {
        fileName = QInputDialog::getText(
                                         "QtiKWS", "Input Color Schema Name:", QLineEdit::Normal,
                                         fileName, &ok, this );
        if ( !ok )
        {
            return;
        }
        
        if (fileName.isEmpty())
        {
            ok=false;
        }
    }
    
    QString s;
    
    for (int i=0; i<w->numRows();i++)
    {
        for(int j=1;j<=3;j++)
        {
            if ( w->text(i,j).toDouble()>0 && w->text(i,j).toDouble()<1)
                s+=QString::number(int(w->text(i,j).toDouble()*255))+" ";
            else
                s+=QString::number(w->text(i,j).toInt())+" ";
        }
        s+="\n";
    }
    
    
    QFile f(colorPath+"/"+fileName+".MAP");
    
    
    if ( !f.open( IO_WriteOnly ) )  
    {
        //*************************************Log Window Output
        QMessageBox::warning(this,"Could not write to file", tr("qtiKWS::DANP"));
        //*************************************Log Window Output
        return;
    }	
    QTextStream stream( &f );
    stream<<s;
    f.close();	
    
    findColorMaps();
    
    comboBoxSchema->setCurrentText(fileName);
}



void danp16::deleteColorSequence()
{
    if (comboBoxSchema->currentItem()==0) return;    
    
    QString fileName=comboBoxSchema->currentText();
    if (fileName=="") return;
    
    //+++
    QDir dd;
    QString colorPath=app(this)->qtiKwsPath+"/colorMaps";
    colorPath=colorPath.replace("//","/");
    if (!dd.cd(colorPath)) 
    {
        colorPath=QDir::homeDirPath()+"/colorMaps";
        colorPath=colorPath.replace("//","/");
        
        if (!dd.cd(colorPath)) 
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/colorMaps"); 	
            dd.cd("./qtiKWS/colorMaps");
        }
    };
    colorPath=dd.absPath();
    
    dd.remove(fileName+".MAP");
    
    findColorMaps();
}



//+++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++FUNCTIONS::create Matrix from gsl_matrix-Uni++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::makeMatrixUni( gsl_matrix * gmatrix, QString name, int xDim, int yDim)
{
    int i,j,mm;
    //+++
    QWidgetList* windows=app(this)->windowsList();
    //+++
    QString ss;
    //+++
    bool existYN=false;
    Matrix* m;
    //+++
    
    for (mm=0; mm < (int)windows->count(); mm++ )
    {
        ss=windows->at(mm)->name();
        
        if (ss==name && windows->at(mm)->isA("Matrix"))
        {
            m=(Matrix *)windows->at(mm);
            existYN=true;
            m->setMatrixDimensions(yDim,xDim);
        }
    }
    //+++make Unique Name
    
    if (!existYN)
    {
        m=app(this)->newMatrixHidden(name,yDim,xDim);
        app(this)->updateRecentProjectsList();
        m->setNumericFormat('E',8);
        m->setCoordinates(1,yDim,1,xDim);
    }
    //+++
    
    for (i=0;i<yDim;i++) for (j=0;j<xDim;j++)
    {
        m->setText(i,j,QString::number(gsl_matrix_get(gmatrix,i,j),'E',8));
    }
    
    m->setColumnsWidth(140);
    m->notifyChanges();
}





void danp16::xyzTOmatrix()
{
    if ( !app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA ( "Table" ) )
        return;
    
    if ( int ( ( ( Table* ) app(this)->ws->activeWindow() )->selectedColumns().count() ) !=3 ) return;
    
    Table* w = ( Table* ) app(this)->ws->activeWindow();
    
    int firstSelectedColumn=w->firstSelectedColumn();
    int rows=w->numRows();
    
    if (rows==0) return;
    
    double minX, minY, maxX, maxY ;
    int maxXint, maxYint ;
    
    double resoX=lineEditStepX->text().toDouble();
    double resoY=lineEditStepY->text().toDouble();
    
    if (resoX<=0 ||resoY<=0 ) return;
    
    // find min max x, y
    minX=w->text(0,firstSelectedColumn).toDouble();
    maxX=w->text(0,firstSelectedColumn).toDouble();
    
    minY=w->text(0,firstSelectedColumn+1).toDouble();
    maxY=w->text(0,firstSelectedColumn+1).toDouble();
    
    for (int i=0;i<rows;i++)
    {
        if (minX>w->text(i,firstSelectedColumn).toDouble())
            minX=w->text(i,firstSelectedColumn).toDouble();
        if (maxX<w->text(i,firstSelectedColumn).toDouble())
            maxX=w->text(i,firstSelectedColumn).toDouble();
        
        if (minY>w->text(i,firstSelectedColumn+1).toDouble())
            minY=w->text(i,firstSelectedColumn+1).toDouble();
        if (maxY<w->text(i,firstSelectedColumn+1).toDouble()) maxY=w->text(i,firstSelectedColumn+1).toDouble();
    }
    
    
    int dimX=int((maxX-minX)/resoX)+1;
    int dimY=int((maxY-minY)/resoY)+1;
    
    
    
    if (dimX<1 || dimY<1) return;
    
    gsl_matrix* data=gsl_matrix_calloc(dimY,dimX);
    gsl_matrix* counter=gsl_matrix_calloc(dimY,dimX);
    
    int xx,yy;
    double tmp,zz;
    
    
    
    for (int i=0;i<rows;i++)
    {
        //
        tmp=w->text(i,firstSelectedColumn).toDouble();
        xx=int((tmp-minX)/resoX);
        //
        tmp=w->text(i,firstSelectedColumn+1).toDouble();
        yy=int((tmp-minY)/resoY);
        //
        zz=w->text(i,firstSelectedColumn+2).toDouble();
        
        tmp=gsl_matrix_get(data,yy,xx);
        gsl_matrix_set(data,yy,xx,tmp+zz);
        //
        tmp=gsl_matrix_get(counter,yy,xx);
        gsl_matrix_set(counter,yy,xx,tmp+1.0);
    }
    
    
    for (int i=0;i<dimX;i++)for(int j=0;j<dimY;j++)
    {
        if (gsl_matrix_get(counter,j,i)<1) continue;
        
        tmp=gsl_matrix_get(data,j,i);
        tmp/=gsl_matrix_get(counter,j,i);
        gsl_matrix_set(data,j,i,tmp);
        
    }
    
    QString name=w->name();
    name=generateTableName(name+"xyz2matrix");
    
    makeMatrixUni(data, name, dimX, dimY);
}


void danp16::tablesToWasserfallMatrix()
{
};
