/***************************************************************************
File : danp16.h
Project  : QtiKWS16
--------------------------------------------------------------------
Copyright: (C) 2016 ... by Vitaliy Pipich
Email (use @ for *)  : v.pipich*gmail.com
Description  : preparation to qtisas

 ***************************************************************************/

/***************************************************************************
 * *
 *  This program is free software; you can redistribute it and/or modify   *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation; either version 2 of the License, or  *
 *  (at your option) any later version.*
 * *
 *  This program is distributed in the hope that it will be useful,*
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  *
 *  GNU General Public License for more details.   *
 * *
 *   You should have received a copy of the GNU General Public License *
 *   along with this program; if not, write to the Free Software   *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor,*
 *   Boston, MA  02110-1301  USA   *
 * *
 ***************************************************************************/

#ifndef DANP16_H
#define DANP16_H

#include "../../src/application.h"
#include "danp.h"

#include <qvariant.h>
#include <qpixmap.h>
#include <qwidget.h>
#include <qprogressdialog.h>
#include <qdom.h>
#include <qstring.h>

class danp16 : public danp
{
    Q_OBJECT
public:
    danp16( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~danp16();
    
    // connections
    void connectSlot();
    
    // settings
    void readSettings();
    void writeSettings();
    void readSettingsCSV();
    
    // init
    void initDANP();
    void initDATA();
    void toResLog( QString text);  // to remove???
    void removeWindows(QString pattern);
    bool checkTableExistence(QString &tableName, Table* &w);
    bool checkTableExistence(QString &tableName);
    void maximizeWindow(QString name);
    bool findActiveGraph( Graph * & g);
    QString findFileNumberInFileName(QString wildCardLocal, QString file);
    bool findFitDataTable(QString curveName, Table* &table, int &xColIndex, int &yColIndex );
    
    // ascii1d
    void defaultASCII1D();
    void findASCII1DFormats();
    void saveCurrentASCII1D(QString fileName);
    void loadASCIIfromTables();
    void loadASCIIfromFiles();
    void sigmaCalculation(gsl_matrix* &data, int N);
    void applyMath(gsl_matrix* &data, QString MathChar, double MathFactor, int N);
    void dataMatrixSave(QString &fn, gsl_matrix* data, int N, int Nfinal, bool loadedReso, Table* &w);
    QString generateTableName(QString fn);
    QString generateTableName(QString fn,   QString prefix,  int findNumberIndex, bool indexing, bool tableOutput);
    void convertToQI(gsl_matrix* &data, int N, int &Nfinal);
    void convertFromQI(gsl_matrix* &data, int N, int &Nfinal);
    int removePoints(gsl_matrix* &data, int N);
    int columnCalculation(gsl_matrix* &data, int N, int Nfinal, QString action, QString columnName);
    bool loadASCIIfromFile(const QString fn, gsl_matrix* &data, int &N, bool &sigmaExist);
    bool loadASCIIfromTable(const QString table, gsl_matrix* &data, int &N, bool &sigmaExist);
    int rowsNumber(const QString table);
    int linesNumber(const QString fn);
    double sigma( double Q);
    void sasPresentation(QString &presentation );
    QString readDataC(QString name);
    QString readDataD(QString name);
    void readDataCollimationAperture(QString name, QString &ca1, QString &ca2);
    void readDataSampleAperture(QString name, QString &sa1, QString &sa2);
    QString readLambdaKWS2(QString name);
    QString readLambdaKWS1(QString name);
    int numberSameEntriesYAML(QString fileName, QStringList lst);
    int numberSameEntries(QDomElement root, QStringList lst);
    bool readYAMLentry(QString fileName, QStringList lst,int order, QString &resultString);
    bool readXMLentry(QDomElement root, QStringList lst, QDomElement &element, int order);
    bool linearBinning(gsl_matrix* &data, int N, int &Nfinal);
    bool logBinning(gsl_matrix* &data, int N, int &Nfinal);
    void minmaxPositiveXY(Graph* g, double &minX, double &maxX, double &minY, double &maxY, bool onlyPositiveX, bool onlyPositiveY);
    
    // ascii2d
    QString generateMatrixName(QString fn);
    QStringList matrixListSL();
    QStringList matrixListSL(int xDim, int yDim);
    QStringList matrixListSLm(QString matrix);
    void maskElipsInd(int number);
    void maskElipsShellInd(int number);
    void maskSquaredInd(int number);
    void maskSectorInd(int number);
    void radUniHF
    (
     int chanellNumberX,int chanellNumberY,
     gsl_matrix *Sample, gsl_matrix *SampleErr,  gsl_matrix *mask,
     double XYcenter, double YXcenter,
     QString sampleMatrix,
     QString label
     );
    void make_GSL_Matrix(Matrix *m, gsl_matrix * &gmatrix);
    void make_GSL_Matrix_Err(Matrix *m, gsl_matrix * &gmatrix);
    void radUniHFcallind(int number);
    
    // merge1d
    bool checkTableExistance(QString tName, int &Rows, int &Cols, double &Qmin, double &Qmax );
    bool addTable(const QString table, gsl_matrix* &data, int &N, int Rows, int overlap, int &firstPosition);
    void saveMergedMatrix(QString name, QString labelList,gsl_matrix* data, int N, bool loadReso);
    void saveMergedMatrixAscii(QString name, gsl_matrix* data, int N, bool loadReso);
    
    // plot1d
    bool findTable(QString curveName, Table* &table, int &xColIndex, int &yColIndex,int &dxColIndex, int &dyColIndex );
    bool plotTable(Graph *g,Table *table, QString tableName);
    void movePoint(bool plus);
    
    // plot2d
    void colorSchemChanged(bool chColor);
    void colorSchemChanged3d(bool chColor);
    void colorSchemChanged(bool chColor, Graph* g);
    void colorSchemChangedAbs(bool chColor, Graph* g);
    void makeMatrixUni( gsl_matrix * gmatrix, QString name, int xDim, int yDim);
    
    // header
    void slotMakeUniHeader(QString TableName, QStringList selectedDat);
    void saveCurrentHSTRtable(QString fileName);
    QString readHeader(QString paraName, QStringList &header1, QStringList &header2);
    QString readHeaderLine(int index, QString lineS, QStringList &header);

    // csv reader
    void makeCSVtable(QStringList lstTable, QStringList lstHeader, int currentTable);

    QString strPath;
    QStringList headerNamesShort;
    
signals:
    void showAxis(int, int, const QString&, bool, int, int, bool, const QColor&, int, int, int, int, const QString&, const QColor&);
    
    
public slots:

    // slots

    // init
    void tabSelected();
    void buttomRADpath();
    void openHelpOnline();
    void buttomPath();
    void buttomPathOut();
    void showDAN();
    void findColorMaps();
    void findSymbolMaps();
    void findMatrixFormats();
    void findHeaderFormats();
    
    // settings
    void forceReadSettings();
    
    // ascii1d
    void saveCurrentASCII1D();
    void saveNewASCII1D();
    void readCurrentASCII1D();
    void deleteASCII1D();
    //...
    void asciiFormatSelected();
    void sourceSelected();
    void loadASCIIall();
    void detColDistanceValidator();
    void checkBoxResoSlot();
    void checkBoxLensesChanged();
    void slotMathYN();
    void slot1DcalcYN();
    void calcSigmaActiveTable();
    void presentationFromChanged();
    void presentationToChanged();
    void mathControl();
    void mathControl2();
    void removeRangeControl();
    void removeLastControl();
    void removeFirstControl();
    void readKWS1resoInfo();
    void readKWS2resoInfo();
    void readDANresoInfo();
    void readCANSASresoInfo();
    
    // ascii2d    
    void loadDATmatrixNew();
    void deleteMatrix2Dformat();

    void matrixList();
    void exportMatrix();
    void checkSensInExportMatrix();
    void matrixCalculation();
    void mcCalculateScalar();
    void maskElips();
    void maskElipsShell();
    void maskSquared();
    void maskSector();
    void maskSetValue();
    void saveMatrix2Dformat();
    void matrixFormatsChanged();
    void radUniHFcall();
    void matrixSelected(const QString &mName);
    void mCalcSelected1();
    void mCalcSelected2();
    
    // merge1d
    void mergingTableChange();
    void mergeMethod();
    void saveMergeInfo();
    void readMergeInfo();
    
    // plot1d
    void slotPlotRange();
    void slotSetTitels();
    void slotCLEAR();
    void slotLogLog();
    void slotLinLin();
    void plotByFilter();
    void removeByFilter();
    void addNewLegend();
    void symbolSchemChanged();
    void openSymbolSequenceAsTable();
    void saveCurrentTableAsSymbolSequence();
    void deleteSymbolSequence();
    void movePointPlus();
    void movePointMinus();
    
    // plot2d
    void readDisplay();
    void activeMatrixUpdate();
    void activeMatrixSelected();
    void setSANSinstrument();
    void rescale2Dplot();
    void changeSpecrogram();
    void colorSchemSelected();
    void colorSchemSelectedNotColor();
    void open2dColorSequenceAsTable();
    void saveCurrentTableAsColorSequence();
    void deleteColorSequence();
    
    void xyzTOmatrix();
    void tablesToWasserfallMatrix();

    // header
    void initTableHeader();
    void slotMakeUniHeader();
    void saveCurrentHSTRtable();
    void saveNewHSTRtable();
    void readCurrentHSTRtable();
    void defaultHeader();
    void deleteHSTR();
    void deleteAllUncheckedLinesHSTR();
    void addLineToHSTR();
    void periodicalHeader();
    void xmlHeader();
    void yamlHeader();
    void vertHeaderTableClicked(int i);

    // csv reader
    void  csvImport();
    
private:

    // constans
};

#endif
