/***************************************************************************
 File                 : danp.ui.h
 Project              : QtiKWS
 --------------------------------------------------------------------
 Copyright            : (C) 2006-2013 by Vitaliy Pipich
 Email (use @ for *)  : v.pipich*gmail.com 
 Description          : Data Analysis Tools 
 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *  This program is free software; you can redistribute it and/or modify   *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation; either version 2 of the License, or      *
 *  (at your option) any later version.                                    *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the Free Software           *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor,                    *
 *   Boston, MA  02110-1301  USA                                           *
 *                                                                         *
 ***************************************************************************/
 
#include "../standart-functions/standartFunctions.h"

#include "../../src/application.h"
#include "../../src/fileDialogs.h"
#include "../../src/multilayer.h"
#include "../../src/Spectrogram.h"
#include "../../src/ErrorBar.h"
#include "../../src/colorBox.h"
#include "yaml-cpp/yaml.h"

#include "../../src/canvaspicker.h"
#include <qwt_plot_canvas.h>

#include <iostream>
#include <fstream>
#include <string>

#include <qdom.h> 
#include <qwt_symbol.h>
#include <qwt_color_map.h>
#include <qwt_plot_spectrogram.h>
#include <qwt_plot_curve.h>

#include <gsl/gsl_math.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h> 
#include <gsl/gsl_integration.h>

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>

#include <qdir.h>
#include <qvalidator.h> 
#include <qmessagebox.h>
#include <qpainter.h> 
#include <qfiledialog.h> 
#include <qtextstream.h> 
#include <qaction.h> 
#include <qprocess.h> 
#include <qworkspace.h>
#include <qinputdialog.h>
#include <qtextedit.h> 
#include <qapplication.h>
#include <qimage.h> 
