//
//  danp16-ascii1d.cpp
//  
//
//  Created by Vitaliy Pipich on 02.03.17.
//
//
#include "danp16.h"

#include "../standart-functions/standartFunctions.h"
#include "yaml-cpp/yaml.h"

#include <iostream>
#include <fstream>

#include <qstring.h>
#include <qcombobox.h>
#include <qinputdialog.h>
#include <qlineedit.h>
#include <qregexp.h>
#include <qworkspace.h>
#include <qinputdialog.h>
#include <qfiledialog.h>
#include <qspinbox.h>
#include <qwidgetlist.h>
#include <qgroupbox.h>
#include <qtoolbutton.h>
#include <qcheckbox.h>
#include <qtoolbox.h>

#include <gsl/gsl_matrix.h>

void danp16::defaultASCII1D()
{
    comboBoxSource->setCurrentItem(0);
    comboBoxSource->setCurrentItem(0);
    spinBoxForceNumCols->setValue(4);
    comboBoxFormat->setCurrentItem(0);
    lineEditSkipHeader->setText("0");
    spinBoxFindIndex->setCurrentItem(0);
    comboBoxPrefixASCII1D->setCurrentItem(1);
    checkBoxIndexing->setChecked(false);
    checkBoxPlotInActive->setChecked(false);
    checkBoxActions->setChecked(false);
    checkBoxReso->setChecked(false);
    // reso tab
    lineEditResoCol->setText("2000");
    lineEditResoDet->setText("2000");
    lineEditResoPixelSize->setText("0.525");
    lineEditResoSamAper->setText("10");
    lineEditResoSamAper2->setText("10");
    lineEditResoColAper->setText("30");
    lineEditResoColAper2->setText("30");
    lineEditResoDeltaLambda->setText("0.2");
    lineEditResoFocus->setText("1000");
    checkBoxLenses->setChecked(false);
    
    // convert tab
    checkBoxConvert->setChecked(false);
    comboBoxSelectPresentationFrom->setCurrentItem(0);
    comboBoxSelectPresentationTo->setCurrentItem(0);
    // tab bad points
    checkBoxRemoveRange->setChecked(false);
    lineEditRemoveFrom->setText("0");
    lineEditRemoveTo->setText("0");
    checkBoxRemoveFirst->setChecked(false);
    lineEditRemoveFirst->setText("0");
    checkBoxRemoveLast->setChecked(false);
    lineEditRemoveLast->setText("0");
    checkBoxNoNegative->setChecked(false);
    // tab math
    checkBoxMath->setChecked(false);
    comboBoxMath->setCurrentItem(2);
    lineEditMath->setText("1");
    checkBoxMath2->setChecked(false);
    comboBoxMath2->setCurrentItem(2);
    lineEditMath2->setText("1");
    // Q-Binning
    checkBoxBinningLinear->setChecked(false);
    spinBoxBinningLinear->setValue(1);
    checkBoxBinningProgressive->setChecked(false);
    lineEditBinningProgressive->setText("1.");

    
    textLabelSASdesc->setHidden(checkBoxConvert->isChecked());
    frameSASpresentation->setShown(checkBoxConvert->isChecked());
    mathControl();
    mathControl2();
    removeRangeControl();
    removeFirstControl();
    removeLastControl();
    textLabelHelp->setHidden(checkBoxActions->isChecked());
    toolBoxChange->setShown(checkBoxActions->isChecked());
    mCalcSelected1();
    mCalcSelected2();
    
    
    if (comboBoxStructureASCII1D->currentItem()==0)
    {
        pushButtonSaveCurrentASCII1D->setEnabled(false);
        pushButtonDeleteASCII1D->setEnabled(false);
    }
    else
    {
        pushButtonSaveCurrentASCII1D->setEnabled(true);
        pushButtonDeleteASCII1D->setEnabled(true);
    }
}


void danp16::findASCII1DFormats()
{
    //+++
    QDir dd;
    QString asciiPath=app(this)->qtiKwsPath+"/ascii1dFormats";
    asciiPath=asciiPath.replace("//","/");
    if (!dd.cd(asciiPath))
    {
        asciiPath=QDir::homeDirPath()+"/ascii1dFormats";
        asciiPath=asciiPath.replace("//","/");
        
        if (!dd.cd(asciiPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/ascii1dFormats");
            dd.cd("./qtiKWS/ascii1dFormats");
        }
    };
    asciiPath=dd.absPath();
    
    QStringList lst = dd.entryList("*.ASCII1D");
    lst.gres(".ASCII1D", "");
    lst.prepend("default");
    
    QString ct=comboBoxStructureASCII1D->currentText();
    
    comboBoxStructureASCII1D->clear();
    comboBoxStructureASCII1D->insertStringList(lst);
    if (lst.contains(ct))     comboBoxStructureASCII1D->setCurrentText(ct);
}

//+++ read current HSTR table from file
void danp16::readCurrentASCII1D()
{
    defaultASCII1D();
    
    if (comboBoxStructureASCII1D->currentItem()==0) return;
    
    
    QString fileName=comboBoxStructureASCII1D->currentText();
    
    //+++
    QDir dd;
    QString asciiPath=app(this)->qtiKwsPath+"/ascii1dFormats";
    asciiPath=asciiPath.replace("//","/");
    if (!dd.cd(asciiPath))
    {
        asciiPath=QDir::homeDirPath()+"/ascii1dFormats";
        asciiPath=asciiPath.replace("//","/");
        
        if (!dd.cd(asciiPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/ascii1dFormats");
            dd.cd("./qtiKWS/ascii1dFormats");
        }
    };
    asciiPath=dd.absPath();
    
    QFile f(asciiPath+"/"+fileName+".ASCII1D");
    
    
    if ( !f.open( IO_ReadOnly ) )
    {
        //*************************************Log Window Output
        QMessageBox::warning(this,"Could not read file", tr("qtiKWS::DANP"));
        //*************************************Log Window Output
        return;
    }
    
    
    QTextStream t( &f );

    QRegExp rx("((\\-)?\\d+)");
    int pos, indexCurrent;
    
    QString s;
    
    
    while(!t.atEnd())
    {
        s=t.readLine().stripWhiteSpace();
 
        if (s.contains("{Data-Source-From} Table")) comboBoxSource->setCurrentItem(1);
        if (s.contains("{Data-Source-From} File")) comboBoxSource->setCurrentItem(0);
        if (s.contains("{Data-Destination-To} Table")) comboBoxSource->setCurrentItem(0);
        if (s.contains("{Data-Destination-To} File")) comboBoxSource->setCurrentItem(1);
        if (s.contains("{Data-Number-Columns} ")) spinBoxForceNumCols->setValue(s.remove("Data-Number-Columns} ").stripWhiteSpace().toInt());
        if (s.contains("{Data-Format} ")) comboBoxFormat->setCurrentItem(s.remove("{Data-Format} ").stripWhiteSpace().toInt());
        if (s.contains("{Data-Skip-Header} ")) lineEditSkipHeader->setText(s.remove("{Data-Skip-Header} "));
        if (s.contains("{Name-Structure} ")) spinBoxFindIndex->setCurrentItem(s.remove("{Name-Structure} ").stripWhiteSpace().toInt());
        if (s.contains("{Name-Prefix} ")) comboBoxPrefixASCII1D->setCurrentItem(s.remove("{Name-Prefix} ").stripWhiteSpace().toInt());
        if (s.contains("{Indexing-Yes-No} Yes"))
            checkBoxIndexing->setChecked(true);
        if (s.contains("{Indexing-Yes-No} No"))
            checkBoxIndexing->setChecked(false);
        if (s.contains("{Plot-Yes-No} Yes"))
            checkBoxPlotInActive->setChecked(true);
        if (s.contains("{Plot-Yes-No} No"))
            checkBoxPlotInActive->setChecked(false);
        if (s.contains("{Modify-Yes-No} Yes"))
            checkBoxActions->setChecked(true);
        if (s.contains("{Modify-Yes-No} No"))
            checkBoxActions->setChecked(false);
        // reso tab
        if (s.contains("{Reso-Yes-No} Yes"))
            checkBoxReso->setChecked(true);
        if (s.contains("{Reso-Yes-No} No"))
            checkBoxReso->setChecked(false);
        if (s.contains("{Reso-Colimation} ")) lineEditResoCol->setText(s.remove("{Reso-Colimation} "));
        if (s.contains("{Reso-SDD} ")) lineEditResoDet->setText(s.remove("{Reso-SDD} "));
        if (s.contains("{Reso-PixelSize} ")) lineEditResoPixelSize->setText(s.remove("{Reso-PixelSize} "));
        if (s.contains("{Reso-Sample-Aperture-W} ")) lineEditResoSamAper->setText(s.remove("{Reso-Sample-Aperture-W} "));
        if (s.contains("{Reso-Sample-Aperture-H} ")) lineEditResoSamAper2->setText(s.remove("{Reso-Sample-Aperture-H} "));
        if (s.contains("{Reso-Sample-Source-W} ")) lineEditResoColAper->setText(s.remove("{Reso-Sample-Source-W} "));
        if (s.contains("{Reso-Sample-Source-H} ")) lineEditResoColAper2->setText(s.remove("{Reso-Sample-Source-H} "));
        if (s.contains("{Reso-Delta-Lambda} ")) lineEditResoDeltaLambda->setText(s.remove("{Reso-Delta-Lambda} "));
        if (s.contains("{Reso-Focus} ")) lineEditResoFocus->setText(s.remove("{Reso-Focus} "));
        if (s.contains("{Reso-Lens-Yes-No} Yes"))
            checkBoxLenses->setChecked(true);
        if (s.contains("{Reso-Lens-Yes-No} No"))
            checkBoxLenses->setChecked(false);
        // convert tab
        if (s.contains("{Convert-Yes-No} Yes"))
            checkBoxConvert->setChecked(true);
        if (s.contains("Convert-Yes-No} No"))
            checkBoxConvert->setChecked(false);
        if (s.contains("{Convert-From} "))  comboBoxSelectPresentationFrom->setCurrentItem(s.remove("{Convert-From} ").stripWhiteSpace().toInt());
        if (s.contains("{Convert-To} "))    comboBoxSelectPresentationTo->setCurrentItem(s.remove("{Convert-To} ").stripWhiteSpace().toInt());
        // tab bad points
        if (s.contains("{Remove-Range-Yes-No} Yes"))
            checkBoxRemoveRange->setChecked(true);
        if (s.contains("{Remove-Range-Yes-No} No"))
            checkBoxRemoveRange->setChecked(false);
        if (s.contains("{Remove-Range-From} ")) lineEditRemoveFrom->setText(s.remove("{Remove-Range-From} "));
        if (s.contains("{Remove-Range-To} "))   lineEditRemoveTo->setText(s.remove("{Remove-Range-To} "));
        if (s.contains("{Remove-First-Yes-No} Yes"))
            checkBoxRemoveFirst->setChecked(true);
        if (s.contains("{Remove-First-Yes-No} No"))
            checkBoxRemoveFirst->setChecked(false);
        if (s.contains("{Remove-First} ")) lineEditRemoveFirst->setText(s.remove("{Remove-First} "));
        if (s.contains("{Remove-Last-Yes-No} Yes"))
            checkBoxRemoveLast->setChecked(true);
        if (s.contains("{Remove-Last-Yes-No} No"))
            checkBoxRemoveLast->setChecked(false);
        if (s.contains("{Remove-Last} ")) lineEditRemoveLast->setText(s.remove("{Remove-Last} "));
        if (s.contains("{Remove-Negative-Yes-No} Yes"))
            checkBoxNoNegative->setChecked(true);
        if (s.contains("{Remove-Negative-Yes-No} No"))
            checkBoxNoNegative->setChecked(false);
        // tab math
        if (s.contains("{Math1-Yes-No} Yes"))
            checkBoxMath->setChecked(true);
        if (s.contains("{Math1-Yes-No} No"))
            checkBoxMath->setChecked(false);
        if (s.contains("{Math1-Action} ")) comboBoxMath->setCurrentItem(s.remove("{Math1-Action} ").stripWhiteSpace().toInt());
        if (s.contains("{Math1-Factor} ")) lineEditMath->setText(s.remove("{Math1-Factor} "));
        if (s.contains("{Math2-Yes-No} Yes"))
            checkBoxMath2->setChecked(true);
        if (s.contains("{Math2-Yes-No} No"))
            checkBoxMath2->setChecked(false);
        if (s.contains("{Math2-Action} ")) comboBoxMath2->setCurrentItem(s.remove("{Math2-Action} ").stripWhiteSpace().toInt());
        if (s.contains("{Math2-Factor} ")) lineEditMath2->setText(s.remove("{Math2-Factor} "));
        // Q-Binning
        if (s.contains("{Binning-Linear-Yes-No} Yes"))
            checkBoxBinningLinear->setChecked(true);
        if (s.contains("{Binning-Linear-Yes-No} No"))
            checkBoxBinningLinear->setChecked(false);
        if (s.contains("{Binning-Linear-Value} ")) spinBoxBinningLinear->setValue(s.remove("{Binning-Linear-Value} ").stripWhiteSpace().toInt());
        if (s.contains("{Binning-Progressive-Yes-No} Yes"))
            checkBoxBinningProgressive->setChecked(true);
        if (s.contains("{Binning-Progressive-Yes-No} No"))
            checkBoxBinningProgressive->setChecked(false);
        if (s.contains("{Binning-Progressive-Value} ")) lineEditBinningProgressive->setText(s.remove("{Binning-Progressive-Value} "));

        
            continue;
        }


    f.close();
    findASCII1DFormats();
    
    
    textLabelSASdesc->setHidden(checkBoxConvert->isChecked());
    frameSASpresentation->setShown(checkBoxConvert->isChecked());
    mathControl();
    mathControl2();
    removeRangeControl();
    removeFirstControl();
    removeLastControl();
    textLabelHelp->setHidden(checkBoxActions->isChecked());
    toolBoxChange->setShown(checkBoxActions->isChecked());
    mCalcSelected1();
    mCalcSelected2();
    
    return;
}


//+++ save NEW ASCII.1D format 
void danp16::saveNewASCII1D()
{
    QString newTableName="newformat";
    
    bool ok;
    newTableName = QInputDialog::getText(
                                         "New Structure of ASCII.1D", "Enter name of new Format:",
                                         QLineEdit::Normal,
                                         newTableName, &ok, this );
    if ( !ok ||  newTableName.isEmpty() )
    {
        return;
    }
    
    saveCurrentASCII1D(newTableName);
    
    return;
}

//+++ save current ASCII.1D format
void danp16::saveCurrentASCII1D()
{
    if (comboBoxStructureASCII1D->currentItem()==0) return;
    else saveCurrentASCII1D(comboBoxStructureASCII1D->currentText());
    readCurrentASCII1D();
    return;
}

//+++ save current ASCII.1D format
void danp16::saveCurrentASCII1D(QString fileName)
{
    //+++
    QDir dd;
    QString asciiPath=app(this)->qtiKwsPath+"/ascii1dFormats";
    asciiPath=asciiPath.replace("//","/");
    if (!dd.cd(asciiPath))
    {
        asciiPath=QDir::homeDirPath()+"/ascii1dFormats";
        asciiPath=asciiPath.replace("//","/");
        
        if (!dd.cd(asciiPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/ascii1dFormats");
            dd.cd("./qtiKWS/ascii1dFormats");
        }
    };
    asciiPath=dd.absPath();
    
    QFile f(asciiPath+"/"+fileName+".ASCII1D");
    
    
    if ( !f.open( IO_WriteOnly ) )
    {
        //*************************************Log Window Output
        QMessageBox::warning(this,"Could not write to file", tr("qtiKWS::DANP"));
        //*************************************Log Window Output
        return;
    }
    QTextStream stream( &f );

    stream<<"{Data-Source-From} "   <<comboBoxSource->currentText()         <<"\n";
    stream<<"{Data-Destination-To} "<<comboBoxDestination->currentText()    <<"\n";
    stream<<"{Data-Number-Columns} "<<spinBoxForceNumCols->value()          <<"\n";
    stream<<"{Data-Format} "        <<comboBoxFormat->currentItem()         <<"\n";
    stream<<"{Data-Skip-Header} "   <<lineEditSkipHeader->text()            <<"\n";
    stream<<"{Name-Structure} "     <<spinBoxFindIndex->currentItem()       <<"\n";
    stream<<"{Name-Prefix} "        <<comboBoxPrefixASCII1D->currentItem()  <<"\n";
    if (checkBoxIndexing->isChecked())
        stream<<"{Indexing-Yes-No} Yes\n";
    else
        stream<<"{Indexing-Yes-No} No\n";
    if (checkBoxPlotInActive->isChecked())
        stream<<"{Plot-Yes-No} Yes\n";
    else
        stream<<"{Plot-Yes-No} No\n";
    if (checkBoxActions->isChecked())
        stream<<"{Modify-Yes-No} Yes\n";
    else
        stream<<"{Modify-Yes-No} No\n";
    // reso tab
    if (checkBoxReso->isChecked())
        stream<<"{Reso-Yes-No} Yes\n";
    else
        stream<<"{Reso-Yes-No} No\n";
    stream<<"{Reso-Colimation} "            <<lineEditResoCol->text()           <<"\n";
    stream<<"{Reso-SDD} "                   <<lineEditResoDet->text()           <<"\n";
    stream<<"{Reso-PixelSize} "             <<lineEditResoPixelSize->text()     <<"\n";
    stream<<"{Reso-Sample-Aperture-W} "     <<lineEditResoSamAper->text()       <<"\n";
    stream<<"{Reso-Sample-Aperture-H} "     <<lineEditResoSamAper2->text()      <<"\n";
    stream<<"{Reso-Sample-Source-W} "       <<lineEditResoColAper->text()       <<"\n";
    stream<<"{Reso-Sample-Source-H} "       <<lineEditResoColAper2->text()      <<"\n";
    stream<<"{Reso-Delta-Lambda} "          <<lineEditResoDeltaLambda->text()   <<"\n";
    stream<<"{Reso-Focus} "                 <<lineEditResoFocus->text()         <<"\n";
    if (checkBoxLenses->isChecked())
        stream<<"{Reso-Lens-Yes-No} Yes\n";
    else
        stream<<"{Reso-Lens-Yes-No} No\n";
    // convert tab
    if (checkBoxConvert->isChecked())
        stream<<"{Convert-Yes-No} Yes\n";
    else
        stream<<"{Convert-Yes-No} No\n";
    stream<<"{Convert-From} "       <<comboBoxSelectPresentationFrom->currentItem()  <<"\n";
    stream<<"{Convert-To} "         <<comboBoxSelectPresentationTo->currentItem()  <<"\n";
    // tab bad points
    if (checkBoxRemoveRange->isChecked())
        stream<<"{Remove-Range-Yes-No} Yes\n";
    else
        stream<<"{Remove-Range-Yes-No} No\n";
    stream<<"{Remove-Range-From} "     <<lineEditRemoveFrom->text()         <<"\n";
    stream<<"{Remove-Range-To} "       <<lineEditRemoveTo->text()         <<"\n";
    if (checkBoxRemoveFirst->isChecked())
        stream<<"{Remove-First-Yes-No} Yes\n";
    else
        stream<<"{Remove-First-Yes-No} No\n";
    stream<<"{Remove-First} "     <<lineEditRemoveFirst->text()         <<"\n";
    if (checkBoxRemoveLast->isChecked())
        stream<<"{Remove-Last-Yes-No} Yes\n";
    else
        stream<<"{Remove-Last-Yes-No} No\n";
    stream<<"{Remove-Last} "     <<lineEditRemoveLast->text()         <<"\n";
    if (checkBoxNoNegative->isChecked())
        stream<<"{Remove-Negative-Yes-No} Yes\n";
    else
        stream<<"{Remove-Negative-Yes-No} No\n";
    // tab math
    if (checkBoxMath->isChecked())
        stream<<"{Math1-Yes-No} Yes\n";
    else
        stream<<"{Math1-Yes-No} No\n";
    stream<<"{Math1-Action} "  <<comboBoxMath->currentItem()  <<"\n";
    stream<<"{Math1-Factor} "  <<lineEditMath->text()         <<"\n";
    if (checkBoxMath2->isChecked())
        stream<<"{Math2-Yes-No} Yes\n";
    else
        stream<<"{Math2-Yes-No} No\n";
    stream<<"{Math2-Action} "  <<comboBoxMath2->currentItem()  <<"\n";
    stream<<"{Math2-Factor} "  <<lineEditMath2->text()         <<"\n";
    // Q-Binning
    if (checkBoxBinningLinear->isChecked())
        stream<<"{Binning-Linear-Yes-No} Yes\n";
    else
        stream<<"{Binning-Linear-Yes-No} No\n";
    stream<<"{Binning-Linear-Value} "     <<spinBoxBinningLinear->value()       <<"\n";
    if (checkBoxBinningProgressive->isChecked())
        stream<<"{Binning-Progressive-Yes-No} Yes\n";
    else
        stream<<"{Binning-Progressive-Yes-No} No\n";
    stream<<"{Binning-Progressive-Value} "     <<lineEditBinningProgressive->text()       <<"\n";
    
    f.close();
    findASCII1DFormats();
    
    comboBoxStructureASCII1D->setCurrentText(fileName);
    defaultASCII1D();
    return;
}

void danp16::deleteASCII1D()
{
    if (comboBoxStructureASCII1D->currentItem()==0)
    {
        return;
    }
    
    QString fileName=comboBoxStructureASCII1D->currentText();
    
    //+++
    QDir dd;
    QString headerPath=app(this)->qtiKwsPath+"/ascii1dFormats";
    headerPath=headerPath.replace("//","/");
    if (!dd.cd(headerPath))
    {
        headerPath=QDir::homeDirPath()+"/ascii1dFormats";
        headerPath=headerPath.replace("//","/");
        
        if (!dd.cd(headerPath))
        {
            dd.cd(QDir::homeDirPath());
            dd.mkdir("./qtiKWS/ascii1dFormats");
            dd.cd("./qtiKWS/ascii1dheaderFormats");
        }
    };
    headerPath=dd.absPath();
    
    dd.remove(fileName+".ASCII1D");
    
    findASCII1DFormats();
    defaultASCII1D();
    readCurrentASCII1D();
}


void danp16::asciiFormatSelected()
{
    switch ( comboBoxFormat->currentItem() )
    {
            
        case 0: lineEditSkipHeader->hide(); // ASCII
            lineEditSkipHeader->setEnabled(false);
            lineEditSkipHeader->setText("0");
            break;
        case 1: lineEditSkipHeader->show();// ASCII-HEADER
            lineEditSkipHeader->setEnabled(true);
            lineEditSkipHeader->setText("0");
            break;
        case 2: lineEditSkipHeader->hide();// cansas
            lineEditSkipHeader->setEnabled(false);
            lineEditSkipHeader->setText("0");
            break;
        case 3: lineEditSkipHeader->show();//nist
            lineEditSkipHeader->setEnabled(false);
            lineEditSkipHeader->setText("{The 6 columns are}");
            break;
    }
    
    
}

void danp16::sourceSelected()
{
    if (comboBoxSource->currentItem()==0)
    {
        groupFormat->show();
        lineinput->show();
    }
    else 
    {
        groupFormat->hide();
        lineinput->hide();
    }
}

//---Proceed:: SANS | 1D
void danp16::loadASCIIall()
{
    //	app(this)->changeFolder("DANP :: ASCII.1D");
    
    if (comboBoxSource->currentItem()==0) loadASCIIfromFiles();
    if (comboBoxSource->currentItem()==1) loadASCIIfromTables();
    
    //	app(this)->changeFolder("DANP :: ASCII.1D");
}

//+++   Load ASCII files   ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::loadASCIIfromTables()
{
    bool ok;
    
    QString text = QInputDialog::getText(
                                         "uni-SAS", "Input pattern to select tables:", QLineEdit::Normal, QString::null, &ok, this );
    
    if ( !ok || text.isEmpty() ) return;
    
    int i;
    
    QWidgetList *windows = app(this)->windowsList();
    
    QRegExp rx(text);
    rx.setWildcard( TRUE );
    QStringList tableNames;
    int tables=0;
    
    for (i=0;i<(int)windows->count();i++)
    {
        if ( rx.exactMatch(windows->at(i)->name()) && windows->at(i)->isA("Table"))
        {
            tableNames<<windows->at(i)->name();
            tables++;
        }
    }
    
    if (tables==0)
    {
        QMessageBox::warning(this,tr("qtiKWS::uni-SAS"),
                             "No table is selected");
        return;
    }
    
    bool sigmaExist;
    int N,Nfinal;
    
    // active graph
    Graph *g;
    Table* w;
    QString currentName;
    bool plotData=checkBoxPlotInActive->isChecked();
    if (comboBoxDestination->currentItem()>0) plotData=false;
    
    if (plotData)
    {
        plotData=findActiveGraph(g);
        bool maximaizedYN=false;
        myWidget *w;
        
        if ( plotData )
        {
            w= ( myWidget * ) app(this)->ws->activeWindow();
            if (w->status() == myWidget::Maximized && w->isA("MultiLayer") )
            {
                maximaizedYN=true;
                // w->showMinimized();
            }
        }
    }
    
    for (i=0;i<tables;i++)
    {
        //loadASCII(fileNames[i]); //+ call  loadASCII
        sigmaExist=false;
        N=0;
        if (rowsNumber(tableNames[i])==0) continue;
        gsl_matrix* data=gsl_matrix_alloc(rowsNumber(tableNames[i]),4);
        
        if ( loadASCIIfromTable(tableNames[i], data, N, sigmaExist) )
        {
            if (N==0) continue;
            Nfinal=N;
            if (checkBoxActions->isChecked())
            {
                // remove points
                Nfinal=removePoints(data,N);
                if (Nfinal==0)
                {
                    QMessageBox::warning(this,tr("qtiKWS::uniSAS"),
                                         "File "+tableNames[i]+" contains no data, and is skipped");
                    break;
                }
                // convert from
                convertFromQI(data, N, Nfinal);
                //sigma
                sigmaCalculation(data, N);
                // math 1....
                if (checkBoxMath->isChecked())
                    applyMath(data, comboBoxMath->currentText(), lineEditMath->text().toDouble(), N);
                // math 2....
                if (checkBoxMath2->isChecked())
                    applyMath(data, comboBoxMath2->currentText(), lineEditMath2->text().toDouble(),N);
                // convert to
                convertToQI(data, N, Nfinal);
                // column calculation
                if (checkBox1DCalculator->isChecked()) columnCalculation(data, N,Nfinal,comboBoxMath1D->currentText(), comboBox1DclacTables->currentText() );
                // Linear Binning
                if(checkBoxBinningLinear->isChecked()) linearBinning(data, N, Nfinal);
                // Log Binning
                if(checkBoxBinningProgressive->isChecked()) logBinning(data, N, Nfinal);
                
            }
            // save ascii as ...
            currentName=tableNames[i];
            dataMatrixSave(currentName,data,N,Nfinal, sigmaExist,w );
            
            if (plotData)
            {
                plotTable(g,w, currentName);
            }
            
            //
        }
        gsl_matrix_free(data);
    }
}
//+++   Load ASCII files   ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::loadASCIIfromFiles()
{
    QString Dir=lineEditPath->text();
    
    //+ Dialog
    QFileDialog *fd = new QFileDialog(Dir,"Rawdata (*.RAD *.rad *)",this,"Getting File Information");
    fd->setDir(Dir);
    fd->setMode( QFileDialog::ExistingFiles );
    fd->setCaption(tr("QtiKWS - Reading RAD files"));
    //+
    if ( !fd->exec() == QDialog::Accepted ) return;
    
    
    QStringList fileNames=fd->selectedFiles();
    
    int files = fileNames.count();
    if (!files) 	return;
    
    int i;
    int N, Nfinal;
    bool sigmaExist;
    
    // active graph
    Graph *g;
    Table* w;
    QStringList listToPlot;
    QString currentName;
    bool plotData=checkBoxPlotInActive->isChecked();
    if (comboBoxDestination->currentItem()>0) plotData=false;
    
    if (plotData)
    {
        plotData=findActiveGraph(g);
        bool maximaizedYN=false;
        myWidget *w;
        
        if ( plotData )
        {
            w= ( myWidget * ) app(this)->ws->activeWindow();
            if (w->status() == myWidget::Maximized && w->isA("MultiLayer") )
            {
                maximaizedYN=true;
                // w->showMinimized();
            }
        }
    }
    
    for (i=0;i<files;i++)
    {
        //loadASCII(fileNames[i]); //+ call  loadASCII
        sigmaExist=false;
        N=linesNumber(fileNames[i]);
        gsl_matrix* data=gsl_matrix_alloc(N,4);
        
        
        if ( loadASCIIfromFile(fileNames[i], data, N, sigmaExist) )
        {
            Nfinal=N;
            if (checkBoxActions->isChecked())
            {
                // remove points
                Nfinal=removePoints(data,N);
                if (Nfinal==0)
                {
                    QMessageBox::warning(this,tr("qtiKWS::uniSAS"),
                                         "File "+fileNames[i]+" contains no data, and is skipped");
                    break;
                }
                // convert from
                convertFromQI(data, N, Nfinal);
                //sigma
                sigmaCalculation(data, N);
                // math 1....
                if (checkBoxMath->isChecked() && checkBoxActions->isChecked())
                    applyMath(data, comboBoxMath->currentText(), lineEditMath->text().toDouble(), N);
                // math 2....
                if (checkBoxMath2->isChecked() && checkBoxActions->isChecked())
                    applyMath(data, comboBoxMath2->currentText(), lineEditMath2->text().toDouble(),N);
                // convert to
                convertToQI(data, N, Nfinal);
                // column calculation
                if (checkBox1DCalculator->isChecked())
                    columnCalculation(data, N,Nfinal,comboBoxMath1D->currentText(), comboBox1DclacTables->currentText() );
                // Linear Binning
                if(checkBoxBinningLinear->isChecked()) linearBinning(data, N, Nfinal);
                // Log Binning
                if(checkBoxBinningProgressive->isChecked()) logBinning(data, N, Nfinal);
            }
            // save ascii as ..
            currentName=fileNames[i];
            dataMatrixSave(currentName,data,N,Nfinal, sigmaExist,w );
            
            if (plotData)
            {
                plotTable(g,w, currentName);
            }
            
        }
        gsl_matrix_free (data);
    }
    
}

// __________ ASCII  | Table::  sigma...
void danp16::sigmaCalculation(gsl_matrix* &data, int N)
{
    if (checkBoxReso->isChecked() && checkBoxActions->isChecked())
    {
        for (int i=0; i<N;i++)  if (gsl_matrix_get(data, i,0) != -99.99)
        {
            gsl_matrix_set(data,i,3,sigma(fabs(gsl_matrix_get(data,i,0))));
        }
    }
}
// Apply Math...
void danp16::applyMath(gsl_matrix* &data, QString MathChar, double MathFactor, int N)
{
    double Q,I,dI;
    for (int i=0; i<N;i++)  if (gsl_matrix_get(data, i,0) != -99.99)
    {
        Q=gsl_matrix_get(data,i,0);
        I=gsl_matrix_get(data,i,1);
        dI=gsl_matrix_get(data,i,2);
        if (MathChar=="+")
        {
            I+=MathFactor;
        }
        else if (MathChar=="*")
        {
            I*=MathFactor;
            if (dI>0) dI*=MathFactor;
        }
        else if (MathChar=="/")
        {
            if (MathFactor!=0)
            {
                I/=MathFactor;
                if (dI>0) dI/=MathFactor;
            }
        }
        else if (MathChar=="-")
        {
            I-=MathFactor;
        }
        gsl_matrix_set(data,i,0,Q);
        gsl_matrix_set(data,i,1,I);
        gsl_matrix_set(data,i,2,dI);
    }
}

// Save Data
void danp16::dataMatrixSave(QString &fn, gsl_matrix* data, int N, int Nfinal, bool loadedReso, Table* &w)
{
    QFileInfo fi( fn );
    QString name=generateTableName(fi.baseName());
    
    bool calculateReso=checkBoxReso->isChecked();
    
    QString label="QI";
    if (checkBoxConvert->isChecked()) label=comboBoxSelectPresentationTo->currentText();
    
    int i;
    
    if (comboBoxDestination->currentText()=="Table")
    {
        //+++ create table
        
        
        if (checkBoxIndexing->isChecked() || !checkTableExistence(name,w) )
        {
            if (calculateReso || loadedReso)
            {
                w=app(this)->newHiddenTable(name,label, 0 ,4);
                w->setColName(3,"Sigma");
                w->setColPlotDesignation(3,Table::xErr);
            }
            else w=app(this)->newHiddenTable(name,label, 0 ,3);
        }
        else
        {
            w->setNumRows(0);
            if (w->numCols()==2) w->addCol();
            if (w->numCols()<4 && (calculateReso || loadedReso) ) w->addCol(); //w->setNumCols(4);
            //	    if (w->numCols()<3 && !(calculateReso || loadedReso) ) w->setNumCols(3);
        }
        
        w->setColName(0,"Q");
        w->setColName(1,"I");
        w->setColName(2,"dI");
        if (calculateReso || loadedReso ) w->setColName(3,"Sigma");
        
        w->setColPlotDesignation(0,Table::X);
        w->setColPlotDesignation(1,Table::Y);
        w->setColPlotDesignation(2,Table::yErr);
        if (calculateReso || loadedReso ) 	w->setColPlotDesignation(3,Table::xErr);
        
        w->setHeaderColType();
        
        w->setNumericFormat(2, 8, true);
        
        app(this)->updateWindowLists(w);
        
        w->setWindowLabel(label);
        app(this)->setListViewLabel(w->name(),label);
        app(this)->updateWindowLists(w);
        
        int currentRow=0;
        
        for (i=0; i<N;i++)  if (gsl_matrix_get(data, i,0) != -99.99)
        {
            w->setNumRows(currentRow+1);
            //
            w->setText(currentRow,0, QString::number(gsl_matrix_get(data,i,0),'E'));
            //
            w->setText(currentRow,1, QString::number(gsl_matrix_get(data,i,1),'E'));
            //
            if (gsl_matrix_get(data, i,2) == -99.99) w->setText(currentRow,2, "---");
            else w->setText(currentRow,2, QString::number(gsl_matrix_get(data,i,2),'E'));
            //
            if (calculateReso || loadedReso)
            {
                if (gsl_matrix_get(data, i,3) == -99.99) w->setText(currentRow,3, "---");
                else w->setText(currentRow,3, QString::number(gsl_matrix_get(data,i,3),'E'));
            }
            currentRow++;
        }
        
        //+++ adjust cols
        for (int tt=0; tt<w->numCols(); tt++)
        {
            w->table()->adjustColumn (tt);
            w->table()->setColumnWidth(tt, w->table()->columnWidth(tt)+10);
        }
        
        
        w->setNumCols(spinBoxForceNumCols->value());
        w->notifyChanges();
        
    }
    else
    {
        QFile f( lineEditPathOut->text()+"/"+name);
        
        
        if ( !f.open( IO_WriteOnly ) )
        {
            //*************************************Log Window Output
            QMessageBox::warning(this,"Could not write to file::" +  fn, tr("qtiKWS::DANP"));
            //*************************************Log Window Output
            return;
        }
        QTextStream stream( &f );
        int currentRow=0;
        
        for (i=0; i<N;i++)  if (gsl_matrix_get(data, i,0) != -99.99)
        {
            stream<<QString::number(gsl_matrix_get(data,i,0),'E');
            //
            stream<<"   "+QString::number(gsl_matrix_get(data,i,1),'E');
            //
            if (spinBoxForceNumCols->value()>2)
            {
                if (gsl_matrix_get(data, i,2) == -99.99) stream<<"   ---";
                else stream<<"   "+QString::number(gsl_matrix_get(data,i,2),'E');
            }
            //
            if (spinBoxForceNumCols->value()>3)
            {
                if (calculateReso)
                {
                    stream<<"   "+QString::number(sigma(gsl_matrix_get(data,i,0)),'E');
                }
                else if (loadedReso)
                {
                    stream<<"   "+QString::number(gsl_matrix_get(data,i,3),'E');
                }
            }
            currentRow++;
            stream<<"\n";
        }
        f.close();
        
    }
    fn=name;
}

//

QString danp16::generateTableName(QString fn)
{
    QString format;
    
    if (checkBoxConvert->isChecked()) format=comboBoxSelectPresentationTo->currentText()+"-";
    else format="QI-";
    
    int findNumberIndex=spinBoxFindIndex->currentItem();
    
    bool indexing=checkBoxIndexing->isChecked();
    
    bool tableOutput=true;
    
    if (comboBoxDestination->currentText()=="File") tableOutput=false;
    
    
    return generateTableName(fn, format,  findNumberIndex, indexing, tableOutput);
}

/*
 fn:	 	file name
 format:		prefix, like "QI-"
 findNumberIndex:	find cuber in file name and generate name with this number; 0: ne name = old one
 indexing:		indexing of tables[files]
 tableOutput:	outbut > table opposite file
 */

QString danp16::generateTableName(QString fn,   QString prefix,  int findNumberIndex, bool indexing, bool tableOutput)
{
    QString format=prefix;
    
    
    fn.replace('_', '-');
    
    bool findNumber=true;
    if (findNumberIndex==0) findNumber=false;
    
    // fing number
    int number=0;
    if (findNumber)
    {
        
        QRegExp rx("(\\d+)");
        int pos=0;
        int indexCurrent=0;
        while ( pos >= 0 && indexCurrent<findNumberIndex)
        {
            pos = rx.search( fn, pos );
            number=rx.cap( 1 ).toInt();
            if ( pos > -1 ) pos  += rx.matchedLength();
            indexCurrent++;
        }
        if (indexCurrent<findNumberIndex) findNumber=false;
    }
    
    if (findNumber)
    {
        format+=QString::number(number);
    }
    else
    {
        if (comboBoxPrefixASCII1D->currentItem()==1) format="";
        format+=fn;
    }
    //
    if (!indexing)
    {
        if (!tableOutput) format+=".RAD";
    }
    else
    {
        format+="-v-";
        if (tableOutput)
        {
            format=app(this)->generateUniqueName(format);
        }
        else
        {
            int fff=0;
            bool fileExist=true;
            QString path=lineEditPath->text();
            
            while (fileExist)
            {
                if ( QFile::exists(path+format+QString::number(fff)+".RAD") ) fff++;
                else fileExist=false;
            }
            format+=QString::number(fff)+".RAD";
        }
    }
    return format;
}

//
void danp16::convertToQI(gsl_matrix* &data, int N, int &Nfinal)
{
    if (!checkBoxConvert->isChecked() || !checkBoxActions->isChecked()) return;
    if (comboBoxSelectPresentationTo->currentItem()==0) return;
    //
    QString newPresentation=comboBoxSelectPresentationTo->currentText();
    //
    // * ****** Change of Presentation  *****************************
    double QQ, II, dII;
    double Q, I, dI;
    
    for (int i=0; i<N; i++) if (gsl_matrix_get(data, i,0) != -99.99)
    {
        Q=gsl_matrix_get(data, i,0);
        I=gsl_matrix_get(data, i,1);
        dI=gsl_matrix_get(data, i,2);
        
        if (newPresentation=="Guinier")
        {
            QQ=Q*Q;
            if (I<=0) {QQ =-99.99;Nfinal--;}
            else
            {
                II=log(I);
                if (dI>0) dII=dI/I;
            }
        }
        else if (newPresentation=="Zimm")
        {
            QQ=Q*Q;
            
            if (I==0) {QQ=-99.99;Nfinal--;}
            else
            {
                II=1/I;
                if (dI>0) dII=dI/I/I;
            }
        }
        else if (newPresentation=="Porod")
        {
            if (Q<=0) {QQ=-99.99;Nfinal--;}
            else
            {
                QQ=log10(Q);
                if (I<=0) {QQ=-99.99;Nfinal--;}
                else
                {
                    II=log10(I);
                    if (dI>0) dII=dI/I/log(10.0);
                }
            }
        }
        else if (newPresentation=="Porod2")
        {
            QQ=Q*Q;
            if (I<0) {QQ=-99.99;Nfinal--;}
            else
            {
                II=I*pow(Q,4);
                if (dI>0) dII=dI*pow(Q,4);
            }
        }
        else if (newPresentation=="logQ")
        {
            if (Q<=0) {QQ=-99.99;Nfinal--;}
            else
            {
                QQ=log10(Q);
                
                II=I;
                if (dI>0) dII=dI;
            }
        }
        else if (newPresentation=="logI")
        {
            QQ=Q;
            if (I<=0) {QQ=-99.99;Nfinal--;}
            else
            {
                II=log10(I);
                if (dI>0) dII=dI/I/log(10.0);
            }
        }
        else if (newPresentation=="Debye")
        {
            QQ=Q*Q;
            if (I<=0) {QQ=-99.99;Nfinal--;}
            else
            {
                II=1/sqrt(I);
                if (dI>0) dII=dI/pow(I,1.5);
            }
        }
        else if (newPresentation=="1Moment")
        {
            QQ=Q;
            if (I<0) {QQ=-99.99;Nfinal--;}
            else
            {
                II=Q*I;
                if (dI>0) dII=Q*dI;
            }
        }
        else if (newPresentation=="2Moment")
        {
            QQ=Q;
            if (I<0) {QQ=-99.99;Nfinal--;}
            else
            {
                II=Q*Q*I;
                if (dI>0) dII=Q*Q*dI;
            }
        }
        else if (newPresentation=="Kratky")
        {
            QQ=Q;
            if (I<0) {QQ=-99.99;Nfinal--;}
            else
            {
                II=Q*Q*I;
                if (dI>0) dII=Q*Q*dI;
            }
        }
        else if (newPresentation=="GuinierRod")
        {
            QQ=Q*Q;
            if (I<=0 || Q<=0 ) {QQ=-99.99;Nfinal--;}
            else
            {
                II=log(I*Q);
                if (dI>0) dII=Q*(dI/I);
            }
        }
        else if (newPresentation=="GuinierPlate")
        {
            if (Q<0) {QQ=-99.99;Nfinal--;}
            else
            {
                QQ=Q*Q;
                if (I<=0) {QQ=-99.99;Nfinal--;}
                else
                {
                    II=log(I*Q*Q);
                    if (dI>0) dII=Q*Q*(dI/I);
                }
            }
        }
        else
        {
            QQ=Q;
            if (I<0) {QQ=-99.99;Nfinal--;}
            else
            {
                II=I;
                if (dI>0) dII=dI;
            }
        }
        
        gsl_matrix_set(data, i,0, QQ);
        gsl_matrix_set(data, i,1, II);
        gsl_matrix_set(data, i,2, dII);
    }
}

//
void danp16::convertFromQI(gsl_matrix* &data, int N, int &Nfinal)
{
    if (!checkBoxConvert->isChecked() || !checkBoxActions->isChecked()) return;
    if (comboBoxSelectPresentationFrom->currentItem()==0) return;
    //
    QString oldPresentation=comboBoxSelectPresentationFrom->currentText();
    //
    // * ****** Change of Presentation  *****************************
    double QQ, II, dII;
    double Q, I, dI;
    for (int i=0; i<N; i++) if (gsl_matrix_get(data, i,0) != -99.99)
    {
        QQ=gsl_matrix_get(data, i,0);
        II=gsl_matrix_get(data, i,1);
        dII=gsl_matrix_get(data, i,2);
        
        if (oldPresentation=="Guinier")
        {
            if (QQ<0) {Q=-99.99;Nfinal--;}
            else
            {
                Q=sqrt(QQ);
                I=exp(II);
                if (dII>0) dI=I*dII;
            }
        }
        else if (oldPresentation=="Zimm")
        {
            if (QQ<0) {Q=-99.99;Nfinal--;}
            else
            {
                Q=sqrt(QQ);
                if (II<=0) {Q=-99.99;Nfinal--;}
                else
                {
                    I=1/II;
                    if (dII>0) dI=dII/II/II;
                }
            }
        }
        else if (oldPresentation=="Porod")
        {
            Q=pow(10,QQ);
            I=pow(10,II);
            
            if (dII>0) dI=dII*I*log(10.0);
        }
        else if (oldPresentation=="Porod2")
        {
            if (QQ<=0) {Q=-99.99;Nfinal--;}
            else
            {
                Q=sqrt(QQ);
                if (II<0) {Q=-99.99;Nfinal--;}
                else
                {
                    I=II/pow(Q,4);
                    if (dII>0) dI=dII/pow(Q,4);
                }
            }
        }
        else if (oldPresentation=="logQ")
        {
            if (QQ<0) {Q=-99.99;Nfinal--;}
            else
            {
                Q=pow(10,QQ);
                if (II<0) {Q=-99.99;Nfinal--;}
                else
                {
                    I=II;
                    if (dII>0) dI=dII;
                }
            }
        }
        else if (oldPresentation=="logI")
        {
            Q=QQ;
            I=pow(10,II);
            if (dII>0) dI=dII*I*log(10.0);
        }
        else if (oldPresentation=="Debye")
        {
            if (QQ<0) {Q=-99.99;Nfinal--;}
            else
            {
                Q=sqrt(QQ);
                if (II<=0) {Q=-99.99;Nfinal--;}
                else
                {
                    I=1/II/II;
                    if (dII>0) dI=2*dII/II/II/II;
                }
            }
        }
        else if (oldPresentation=="1Moment")
        {
            if (QQ<=0) {Q=-99.99;Nfinal--;}
            else
            {
                Q=QQ;
                if (II<0) {Q=-99.99;Nfinal--;}
                else
                {
                    I=II/Q;
                    dI=dII/Q;
                }
            }
        }
        else if (oldPresentation=="2Moment")
        {
            if (QQ<=0) {Q=-99.99;Nfinal--;}
            else
            {
                Q=QQ;
                if (II<0) {Q=-99.99;Nfinal--;}
                else
                {
                    I=II/Q/Q;
                    if (dII>0) dI=dII/Q/Q;
                }
            }
        }
        else if (oldPresentation=="Kratky")
        {
            if (QQ<=0) {Q=-99.99;Nfinal--;}
            else
            {
                Q=QQ;
                if (II<0) {Q=-99.99;Nfinal--;}
                else
                {
                    I=II/Q/Q;
                    if (dII>0) dI=dII/Q/Q;
                }
            }
        }
        else if (oldPresentation=="GuinierRod")
        {
            if (QQ<=0) {Q=-99.99;Nfinal--;}
            else
            {
                Q=sqrt(QQ);
                I=exp(II)/Q;
                if (dII>0) dI=I*dII/Q;
            }
        }
        else if (oldPresentation=="GuinierPlate")
        {
            if (QQ<=0) {Q=-99.99;Nfinal--;}
            else
            {
                Q=sqrt(QQ);
                I=exp(II)/Q/Q;
                if (dII>0) dI=I*dII/Q/Q;
            }
        }
        else
        {
            if (QQ<=0) {Q=-99.99;Nfinal--;}
            else
            {
                Q=QQ;
                if (II<0) {Q=-99.99;Nfinal--;}
                else
                {
                    I=II;
                    if (dII>0)   dI=dII;
                }
            }
        }
        
        gsl_matrix_set(data, i,0, Q);
        gsl_matrix_set(data, i,1, I);
        gsl_matrix_set(data, i,2, dI);
    }
}

//
int danp16::removePoints(gsl_matrix* &data, int N)
{
    int i;
    if (checkBoxRemoveRange->isChecked() && checkBoxActions->isChecked())
    {
        //
        int from=lineEditRemoveFrom->text().toInt()-1;
        int to=lineEditRemoveTo->text().toInt()-1;
        
        if (from<0) from=0;
        if (to<0) to=0;
        
        if (to >= N) to=N-1;
        if (to<from) {to=0; from=0;};
        if (to!=from) for(i=from;i<=to;i++) gsl_matrix_set(data, i,0, -99.99);
    }
    //
    if (checkBoxRemoveFirst->isChecked() && checkBoxActions->isChecked())
    {
        int first=lineEditRemoveFirst->text().toInt();
        if (first>=N) return 0;
        for(i=0;i<first; i++) gsl_matrix_set(data, i,0, -99.99);
    }
    //
    if (checkBoxRemoveLast->isChecked() && checkBoxActions->isChecked())
    {
        int last=lineEditRemoveLast->text().toInt();
        if (last>=N) return 0;
        for(i=(N-last);i<N; i++) gsl_matrix_set(data, i,0, -99.99);
    }
    //
    if (checkBoxNoNegative->isChecked())
    {
        for(i=0;i<N; i++) if ( gsl_matrix_get(data, i,1) <=0 ) gsl_matrix_set(data, i,0, -99.99);
    }
    
    //
    int Nfinal=0;
    for(i=0;i<N; i++) if (gsl_matrix_get(data, i,0)!=-99.99) Nfinal++;
    
    //
    return Nfinal;
}


//
int danp16::columnCalculation(gsl_matrix* &data, int N, int Nfinal, QString action, QString columnName)
{
    int i;
    Table* w;
    QString tableName=columnName.left(columnName.find("_"));
    QString colShortName=columnName.remove(tableName+"_");
    
    if (N>0 && comboBoxSelectPresentationFrom->currentText() == comboBoxSelectPresentationTo->currentText() && columnName!="" && checkTableExistence(tableName,w))
    {
        int colIndex=w->colIndex(colShortName);
        int rowNumber=w->numRows();
        if (Nfinal!=rowNumber) return -1;
        
        double n1, n2;
        int j=0;
        for (int i=0; i<N; i++) if (gsl_matrix_get(data, i,0) != -99.99)
        {
            n1=gsl_matrix_get(data,i,1);
            n2=w->text(j,colIndex).toDouble();
            if (action=="+")
            {
                n1+=n2;
            }
            else if (action=="-")
            {
                n1-=n2;
            }
            else if (action=="/")
            {
                if ( n2!=0.0 ) n1/=n2;
            }
            else if (action=="*")
            {
                n1*=n2;
            }
            gsl_matrix_set(data,i,1,n1);
            j++;
        }
        
    }
}

//
bool danp16::loadASCIIfromFile(const QString fn, gsl_matrix* &data, int &N, bool &sigmaExist)
{
    //scan No1
    int maxN=N;
    N=0;
    
    QFile f(fn);
    
    if (!f.open(IO_ReadOnly))
    {
        QMessageBox::warning(this,"File "+fn+" could not be opened, and was skipped", tr("qtiKWS::DANP"));
        return false;
    }
    
    QTextStream t( &f );
    int pos,NN;
    double Q,I,dI,sigma;
    QString s; 
    
    //QRegExp rx("((\\-)?\\d*(\\.\\d*)?((e|E)(\\-)?\\d*)?)");// old
    //QRegExp rx("((\\-|\\+)?\\d\\d*(\\.\\d*)?((E\\-|E\\+)\\d\\d?\\d?\\d?)?)");  //new
    QRegExp rx("((\\-|\\+)?\\d\\d*(\\.\\d*)?(((e|E)\\-|(e|E)\\+)\\d\\d?\\d?\\d?)?)");  //very new
    
    QString ss=lineEditSkipHeader->text().stripWhiteSpace();
    
    if (ss.left(1)=="{" && ss.right(1)=="}")
    {
        ss=ss.mid(1,ss.length()-2);
        while (!t.atEnd() && !s.contains(ss) ) s=t.readLine();
    }
    else
    {
        for (int i=0; i<ss.toInt(); i++) t.readLine();
    }
    int n;
    if (comboBoxFormat->currentText().contains("cansas1d"))
    {
        while (!t.atEnd() && !s.contains("<SASdata") ) s=t.readLine();
        while (!t.atEnd() && !s.contains("</SASdata>") && N<maxN )
        {	    
            Q=0;
            I=0;
            dI=-99.99;
            sigma=-99.99;
            n=0;
            while (!t.atEnd() && (!s.contains("</Idata>") || n==0) ) 
            {
                n++;
                s=t.readLine();
                if (s.contains("<Q ") && s.contains("</Q>")) 
                {	
                    ss=s.left(s.find("</Q>"));
                    ss=ss.right(ss.length()-ss.find(">",ss.find("<Q "))-1);
                    ss=ss.stripWhiteSpace();	
                    Q=ss.toDouble();
                }
                if (s.contains("<I ") && s.contains("</I>")) 
                {	
                    ss=s.left(s.find("</I>"));
                    ss=ss.right(ss.length()-ss.find(">",ss.find("<I "))-1);
                    ss=ss.stripWhiteSpace();
                    I=ss.toDouble();
                }
                if (s.contains("<Idev ") && s.contains("</Idev>")) 
                {	
                    ss=s.left(s.find("</Idev>"));
                    ss=ss.right(ss.length()-ss.find(">",ss.find("<Idev "))-1);
                    ss=ss.stripWhiteSpace();
                    dI=ss.toDouble();
                }
                if (s.contains("<Qdev ") && s.contains("</Qdev>")) 
                {	
                    ss=s.left(s.find("</Qdev>"));
                    ss=ss.right(ss.length()-ss.find(">",ss.find("<Qdev "))-1);
                    ss=ss.stripWhiteSpace();
                    sigma=ss.toDouble();
                    sigmaExist=true;
                }
            }
            gsl_matrix_set(data,N,0,Q);
            gsl_matrix_set(data,N,1,I);
            gsl_matrix_set(data,N,2,dI);
            gsl_matrix_set(data,N,3,sigma);
            N++;
            if (!s.contains("<Idata>")) s=t.readLine();
        }
    }
    else while (!t.atEnd() && N<maxN)
    {
        Q=0;
        I=0;
        dI=-99.99;
        sigma=-99.99;
        
        s=t.readLine().stripWhiteSpace();
        
        s.replace(",",".");
        s.replace("e","E");	
        s.replace("E","E0");	
        s.replace("E0+","E+0");
        s.replace("E0-","E-0");
        s.replace("E0","E+0");	
        
        
        pos = 0;
        NN=0;
        while ( pos >= 0 ) 
        {
            pos = rx.search( s, pos );
            
            if (NN==0) Q=rx.cap( 1 ).toDouble();
            if (NN==1) I=rx.cap( 1 ).toDouble();	    
            if (NN==2) dI=rx.cap( 1 ).toDouble();	    
            if (NN==3 && pos > -1 ) 
            {
                sigma=rx.cap( 1 ).toDouble();
                sigmaExist=true;
            }
            
            if ( pos > -1 ) 
            {
                pos  += rx.matchedLength();
                NN++;
            }
            if (NN>3) break;
        }
        
        if (NN>=2)
        {
            gsl_matrix_set(data,N,0,Q);
            gsl_matrix_set(data,N,1,I);
            gsl_matrix_set(data,N,2,dI);
            gsl_matrix_set(data,N,3,sigma);
            N++;
        } 
    }
    
    if (N==0)
    {
        QMessageBox::warning(this,"File "+fn+" contains no data, and is skipped", tr("qtiKWS::DANP"));
        return false;
    }
    
    f.close();
    return true;   
}


//
bool danp16::loadASCIIfromTable(const QString table, gsl_matrix* &data, int &N, bool &sigmaExist)
{    
    QWidgetList *windows = app(this)->windowsList();
    Table *w;
    int i; 
    
    for (i=0;i<(int)windows->count();i++)
    {
        if ( windows->at(i)->name()==table)
        {
            w=(Table *)windows->at(i);
        }
    }
    
    if (w->tableCols()<2 || w->tableRows()==0) return false;
    
    int pos;
    double Q,I,dI,sigma;
    QRegExp rx("((\\-|\\+)?\\d\\d*(\\.\\d*)?(((e|E)\\-|(e|E)\\+)\\d\\d?\\d?\\d?)?)");  //very new
    
    
    // to change to
    
    sigmaExist=false;
    
    if (w->tableRows()==0) return false;
    
    for (i=0;i<w->tableRows();i++)
    {
        pos=0;
        if ( rx.search(w->text(i,0),pos)>-1 ) Q=rx.cap( 1 ).toDouble(); else Q=-99.99;
        pos=0;
        if ( rx.search(w->text(i,1),pos)>-1 ) I=rx.cap( 1 ).toDouble(); else I=-99.99;
        pos=0;
        if ( w->tableCols() > 2 && rx.search(w->text(i,2),pos)>-1 ) dI=rx.cap( 1 ).toDouble(); else dI=-99.99;
        pos=0;
        if ( w->tableCols() > 3 && rx.search(w->text(i,3),pos)>-1 ) 
        {
            sigma=rx.cap( 1 ).toDouble();
            sigmaExist=true;
        }
        else sigma=-99.99;	
        
        if (Q!=-99.99 && I!=-99.99)
        {
            gsl_matrix_set(data,N,0,Q);
            gsl_matrix_set(data,N,1,I);
            gsl_matrix_set(data,N,2,dI);
            gsl_matrix_set(data,N,3,sigma);
            N++;
        } 
    }
    
    if (N==0)
    {
        QMessageBox::warning(this, tr("qtiKWS::uniSAS") ,"File "+table+" contains no data, and is skipped");
        return false;
    }
    
    return true;   
}


//
int danp16::rowsNumber(const QString table)
{    
    QWidgetList *windows = app(this)->windowsList();
    Table *w;
    int i; 
    
    for (i=0;i<(int)windows->count();i++)
    {
        if ( windows->at(i)->name()==table)
        {
            w=(Table *)windows->at(i);
        }
    }
    return w->tableRows();
}

//
int danp16::linesNumber(const QString fn)
{
    //scan No1
    QFile f(fn);
    
    if (!f.open(IO_ReadOnly))
    {
        return 0;
    }
    
    QTextStream t( &f );
    int N=0;
    QString s;
    
    QString ss=lineEditSkipHeader->text().stripWhiteSpace();
    
    if (ss.left(1)=="{" && ss.right(1)=="}")
    {
        ss=ss.mid(1,ss.length()-2);
        while (!t.atEnd() && !s.contains(ss) ) s=t.readLine();
    }
    else
    {
        for (int i=0; i<ss.toInt(); i++) t.readLine();
    }
    
    if (comboBoxFormat->currentText().contains("cansas1d"))
    {
        while (!t.atEnd())
        {	
            s=t.readLine();
            
            if (s.contains("<Idata>")) N++;
        }
    }
    else while (!t.atEnd())
    {
        s=t.readLine();
        N++;
    }
    f.close();
    return N;
}


//+++  Reso Validator  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::detColDistanceValidator()
{
    double change;
    
    // Check Collimation Distance
    change = lineEditResoDet->text().toDouble();
    if (change<10.0)
        lineEditResoDet->setText(QString::number( 10.0, 'f', 2 ) );
    else if (change>10000.0)
        lineEditResoDet->setText( QString::number( 10000.0, 'f', 2 ) );
    else
        lineEditResoDet->setText( QString::number( change, 'f', 2 ) );
    
    // Check Detector Distance
    change = lineEditResoCol->text().toDouble();
    if (change<10.0)
        lineEditResoCol->setText( QString::number( 10.0, 'f', 2 ) );
    else if (change>10000.0)
        lineEditResoCol->setText( QString::number( 10000.0, 'f', 2 ) );
    else
        lineEditResoCol->setText( QString::number( change, 'f', 2 ) );
    
    // Check Focus Distance
    change = lineEditResoFocus->text().toDouble();
    if (change<10.0)
        lineEditResoFocus->setText( QString::number( 10.0, 'f', 2 ) );
    else if (change>10000.0)
        lineEditResoFocus->setText( QString::number( 10000.0, 'f', 2 ) );
    else
        lineEditResoFocus->setText( QString::number( change, 'f', 2 ) );
    // Check Detector Pixel Size
    change = lineEditResoPixelSize->text().toDouble();
    if (change<0.0001)
        lineEditResoPixelSize->setText( QString::number( 0.0001, 'f', 4 ) );
    else if (change>5.0)
        lineEditResoPixelSize->setText( QString::number( 5.0, 'f', 4 ) );
    else
        lineEditResoPixelSize->setText( QString::number( change, 'f', 4 ) );
    
    // Check Sample Aperture Size
    change = lineEditResoSamAper->text().toDouble();
    if (change<0.01)
        lineEditResoSamAper->setText( QString::number( 0.01, 'f', 2 ) );
    else if (change>100.0)
        lineEditResoSamAper->setText( QString::number( 100.0, 'f', 2 ) );
    else
        lineEditResoSamAper->setText( QString::number( change, 'f', 2 ) );
    
    // Check Sample Aperture Size
    change = lineEditResoSamAper2->text().toDouble();
    if (change<0.01)
        lineEditResoSamAper2->setText( QString::number( 0.01, 'f', 2 ) );
    else if (change>100.0)
        lineEditResoSamAper2->setText( QString::number( 100.0, 'f', 2 ) );
    else
        lineEditResoSamAper2->setText( QString::number( change, 'f', 2 ) );
    
    // Check Collimation Aperture Size
    change = lineEditResoColAper->text().toDouble();
    if (change<0.01)
        lineEditResoColAper->setText( QString::number( 0.01, 'f', 2 ) );
    else if (change>100.0)
        lineEditResoColAper->setText( QString::number( 100.0, 'f', 2 ) );
    else
        lineEditResoColAper->setText( QString::number( change, 'f', 2 ) );
    
    // Check Collimation Aperture Size
    change = lineEditResoColAper2->text().toDouble();
    if (change<0.01)
        lineEditResoColAper2->setText( QString::number( 0.01, 'f', 2 ) );
    else if (change>100.0)
        lineEditResoColAper2->setText( QString::number( 100.0, 'f', 2 ) );
    else
        lineEditResoColAper2->setText( QString::number( change, 'f', 2 ) );
    
    // Check Wave Length [A]
    change = lineEditResoLambda->text().toDouble();
    if (change<0.1)
        lineEditResoLambda->setText( QString::number( 0.1, 'f', 3 ) );
    else if (change>50.0)
        lineEditResoLambda->setText( QString::number( 50.0, 'f', 3 ) );
    else
        lineEditResoLambda->setText( QString::number( change, 'f', 3 ) );
    
    // Check delta lambda [1]
    change = lineEditResoDeltaLambda->text().toDouble();
    if (change<0.0001)
        lineEditResoDeltaLambda->setText( QString::number( 0.0001, 'f', 4 ) );
    else if (change>0.8)
        lineEditResoDeltaLambda->setText( QString::number( 0.8, 'f', 4 ) );
    else
        lineEditResoDeltaLambda->setText( QString::number( change, 'f', 4 ) );
}

//+++   checkBoxResoSlot  +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::checkBoxResoSlot()
{
    if (checkBoxReso->isChecked())
    {
        checkBoxConvert->setChecked(false);
    }
}

void danp16::checkBoxLensesChanged()
{
    
    if (checkBoxLenses->isChecked())
    {
        textLabelResoFocus->show();
        lineEditResoFocus->show();
        textLabelResoFocus2->show();
    }
    else
    {
        textLabelResoFocus->hide();
        lineEditResoFocus->hide();
        textLabelResoFocus2->hide();
    }
    
}


//+++   slotMathYN  +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::slotMathYN()
{
    double mathFactor=lineEditMath->text().toDouble();
    QString mathChar=comboBoxMath->currentText();
    if (mathChar=="/" && mathFactor==0)
    {
        mathFactor=1;
        lineEditMath->setText("1");
    }
}

//+++   slot1DcalcYN    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void danp16::slot1DcalcYN()
{
    QString currentItem=comboBox1DclacTables->currentText();
    QStringList yTables=app(this)->columnsList(Table::Y);
    comboBox1DclacTables->clear();
    comboBox1DclacTables->insertStringList(yTables);
    if (yTables.findIndex(currentItem)>=0) comboBox1DclacTables->setCurrentText(currentItem);
    
    if (checkBox1DCalculator->isChecked()) 
    {
        comboBoxMath1D->setEnabled(true);
        comboBox1DclacTables->setEnabled(true);
    }
    else
    {
        comboBoxMath1D->setEnabled(false);
        comboBox1DclacTables->setEnabled(false);
    }
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++
double danp16::sigma( double Q)
{
    const double PI =M_PI;
    double temp;
    
    double C          =lineEditResoCol->text().toDouble();			//[cm]
    double D          =lineEditResoDet->text().toDouble();			//[cm]
    double Rdet      =lineEditResoPixelSize->text().toDouble()/sqrt(PI); 		//[cm]
    
    temp=lineEditResoSamAper->text().toDouble();
    temp*=lineEditResoSamAper2->text().toDouble();
    
    double r2         =0.1*sqrt(temp/PI);					//[cm]
    
    temp=lineEditResoColAper->text().toDouble();
    temp*=lineEditResoColAper2->text().toDouble();
    
    double r1         =0.1*sqrt(temp/PI);					//[cm]
    
    double Lambda     =lineEditResoLambda->text().toDouble();		//[A]
    double SigmaLambda=lineEditResoDeltaLambda->text().toDouble();		//[1]
    double f			=lineEditResoFocus->text().toDouble();	//[cm]
    
    
    double SigQ2,SigQ;
    double Theta0,cos2Theta02, a1, a2, beta1;
    
    
    if (checkBoxLenses	->isChecked())
    {
        SigQ2=PI*PI/Lambda/Lambda/3*(3*r1*r1/C/C+2*r2*r2/f/f*SigmaLambda*SigmaLambda+Rdet*Rdet/D/D+Lambda*Lambda/2/2/PI/PI*Q*Q*SigmaLambda*SigmaLambda);
        SigQ=2*0.4246609*sqrt(SigQ2);
    }
    else
    {
        
        double K0                 = 2.0*PI/Lambda;   //[A-1]
        
        //
        Theta0          = asin(Q/2/K0);
        cos2Theta02     = cos(2*Theta0)*cos(2*Theta0);
        
        //+++ Sigma-D1  +++
        double SigmaDetector      = K0*cos(Theta0)*cos2Theta02*Rdet/D;       //[A-1]
        
        //
        if (cos2Theta02!=0) a1 = r1/(C+D/cos2Theta02); else a1 =0;
        a2 = r2*cos2Theta02/D;
        
        //
        if (a2>a1)
        {
            beta1   =2*r2*(1/C+cos2Theta02/D)-r1*r1*D/(2*r2*cos2Theta02*C*(C+D/cos2Theta02));
        }
        else
        {
            beta1   =2*r1/C-0.5*r2*r2/r1*cos2Theta02*cos2Theta02*(C+D/cos2Theta02)*(C+D/cos2Theta02)/C/D/D;
        }
        
        //+++ Sigma-W  +++
        SigQ2        =Q*Q*SigmaLambda*SigmaLambda;
        //+++ Sigma-D1  +++
        SigQ2       +=SigmaDetector*SigmaDetector;
        //+++ Sigma-C1  +++
        SigQ2       +=K0*K0*cos(Theta0)*cos(Theta0)*beta1*beta1;
        //+++  Sigma-AV  +++
        SigQ2       +=K0*K0*cos(Theta0)*cos(Theta0)*cos2Theta02*cos2Theta02*Rdet/D*Rdet/D;
        //
        SigQ         =0.4246609*sqrt(SigQ2); //[A-1];
    }    
    
    return SigQ;
}

//+++ Change Active Table
void danp16::calcSigmaActiveTable()
{
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("Table"))
    {
        QMessageBox::warning(this,tr("QtiKWS"),
                             tr("<h4>Activate first Table.</h4>"));
        return;
    }
    Table* w=(Table*)app(this)->ws->activeWindow();
    
    if (!w)	return;
    
    int Cols=w->numCols();
    int Rows=w->numRows();
    int Ntot=Rows;
    
    int		RemoveFirst	=lineEditRemoveFirst->text().toInt();
    int		RemoveLast	=lineEditRemoveLast->text().toInt();
    
    bool	RemoveYN		=checkBoxRemoveRange->isChecked();
    bool	MathYN			=checkBoxMath->isChecked();
    bool	ResoYN			=checkBoxReso->isChecked();
    bool	ConvertYN		=checkBoxConvert->isChecked();
    
    QString MathChar		=comboBoxMath->currentText();
    double	MathFactor		=lineEditMath->text().toDouble();
    
    //+++Remove
    if (RemoveYN && Ntot>=(RemoveFirst+RemoveLast)) Ntot=Ntot-RemoveFirst-RemoveLast;
    else
    {
        RemoveFirst=0;
        RemoveLast=0;
    }
    
    int i;
    for (i=Rows-1; i>(Rows-RemoveLast-1); i--) w->removeRow(i);
    for (i=0;i<RemoveFirst;i++) w->removeRow(0);
    
    Rows=w->numRows();
    
    //+++ Math
    if (MathYN)
    {
        double Q,I,dI;
        for(i=0; i<Rows; i++)
        {
            Q=w->text(i,0).toDouble();
            I=w->text(i,1).toDouble();
            dI=w->text(i,2).toDouble();
            if (Q!=0 && I!=0)
            {
                
                if (MathChar=="+")
                {
                    I+=MathFactor;
                }
                else if (MathChar=="*")
                {
                    I*=MathFactor;
                    dI*=MathFactor;
                }
                else if (MathChar=="/")
                {
                    if (MathFactor!=0)
                    {
                        I/=MathFactor;
                        dI/=MathFactor;
                    }
                }
                else if (MathChar=="-")
                {
                    I-=MathFactor;
                }
                w->setText(i,1, QString::number(I,'E'));
                w->setText(i,2, QString::number(dI,'E'));
            }
        }
    }
    
    //+++ Reso
    if (ResoYN)
    {
        w->addCol();
        if (Cols==3) w->setColName(Cols,"Sigma");
        else w->setColName(Cols,"Sigma-"+QString::number(Cols-3));
        w->setColPlotDesignation(Cols,Table::xErr);
        
        
        double Q;
        for(i=0; i<Rows; i++)
        {
            Q=w->text(i,0).toDouble();
            if (Q>=0)
            {
                w->setText(i,Cols,QString::number(sigma(Q),'E',5));
            }
        }
    }
    w->show();
}




//+++ function:: SAS visualization
void danp16::sasPresentation(QString &presentation )
{
    if (presentation=="QI") presentation="I vs. Q";
    else if (presentation=="Guinier") presentation="ln[I] vs. Q<sup>2</sup>";
    else if (presentation=="Zimm") presentation="I<sup>-1</sup> vs. Q<sup>2</sup>";
    else if (presentation=="Porod") presentation="log[I] vs. log[Q]";
    else if (presentation=="Porod2") presentation=" IQ<sup>4</sup> vs. Q<sup>2</sup>";
    else if (presentation=="logQ") presentation=" I vs. log[Q]";
    else if (presentation=="logI") presentation=" log[I] vs. Q ";
    else if (presentation=="Debye") presentation="I<sup>-1/2</sup> vs. Q<sup>2</sup>";
    else if (presentation=="1Moment") presentation="IQ vs. Q";
    else if (presentation=="2Moment") presentation="IQ<sup>2</sup> vs. Q";
    else if (presentation=="Kratky") presentation="IQ<sup>2</sup> vs. Q";
    else if (presentation=="GuinierRod") presentation="ln[IQ] vs. Q<sup>2</sup>";
    else if (presentation=="GuinierPlate") presentation="ln[IQ<sup>2</sup>] vs. Q<sup>2</sup>";
}

//+++ Presentation:: From Changed +++
void danp16::presentationFromChanged()
{
    QString presentation=comboBoxSelectPresentationFrom->currentText();
    sasPresentation(presentation );
    textLabelPresFrom->setText(presentation);
}

//+++ Presentation:: To Changed +++
void danp16::presentationToChanged()
{
    QString presentation=comboBoxSelectPresentationTo->currentText();
    sasPresentation(presentation );
    textLabelPresTo->setText(presentation);
}

void danp16::mathControl()
{
    mathControl2();
    if (!checkBoxMath->isChecked())
    {
        checkBoxMath2->setChecked(false);
        checkBoxMath2->setEnabled(false);
        lineEditMath2->setEnabled(false);
        comboBoxMath2->setEnabled(false);
        comboBoxMath2->setCurrentItem(2);
        lineEditMath2->setText("1");
        
        comboBoxMath->setEnabled(false);
        lineEditMath->setEnabled(false);
        comboBoxMath->setCurrentItem(2);
        lineEditMath->setText("1");
        
        textLabelMath->setText("I(Q)");
    }
    else
    {
        checkBoxMath2->setEnabled(true);
        
        comboBoxMath->setEnabled(true);
        lineEditMath->setEnabled(true);
        
        textLabelMath->setText("I<sub>1</sub> ( Q )");
    }
    
}

void danp16::mathControl2()
{
    
    if (checkBoxMath->isChecked())
    {
        if (!checkBoxMath2->isChecked())
        {
            comboBoxMath2->setEnabled(false);
            lineEditMath2->setText("1");
            lineEditMath2->setEnabled(false);
            
            textLabelMath->setText("I<sub>1</sub> ( Q )");
            
        }
        else
        {
            
            comboBoxMath2->setEnabled(true);
            lineEditMath2->setEnabled(true);
            
            textLabelMath->setText("I<sub>2</sub> ( Q )");
        }
    }
}


void danp16::removeRangeControl()
{
    if (checkBoxRemoveRange->isChecked())
    {
        lineEditRemoveFrom->setEnabled(true);
        lineEditRemoveTo->setEnabled(true);
    }
    else
    {
        lineEditRemoveFrom->setEnabled(false);
        lineEditRemoveTo->setEnabled(false);
        lineEditRemoveFrom->setText("0");
        lineEditRemoveTo->setText("0");
    }
}


void danp16::removeLastControl()
{
    if (checkBoxRemoveLast->isChecked())
    {
        lineEditRemoveLast->setEnabled(true);
    }
    else
    {
        lineEditRemoveLast->setEnabled(false);
        lineEditRemoveLast->setText("0");
    }
}


void danp16::removeFirstControl()
{
    if (checkBoxRemoveFirst->isChecked())
    {
        lineEditRemoveFirst->setEnabled(true);
    }
    else
    {
        lineEditRemoveFirst->setEnabled(false);
        lineEditRemoveFirst->setText("0");
    }
}





// ++++++++++++++ read reso parameters

//+++ read f from DAT-files [cm]
QString danp16::readDataC(QString name)
{
    //+++
    QString s,ss;
    int skip;
    double colimation;
    
    //+++
    QFile file( name );
    QTextStream t( &file );
    file.open(IO_ReadOnly);
    
    //+++
    for(skip=0;skip<21;skip++) s= t.readLine();
    
    //+++
    ss=s.mid(1,16).stripWhiteSpace();
    colimation=ss.toDouble();
    
    //+++
    for(skip=21;skip<28;skip++) s= t.readLine();
    
    //+++
    colimation-=s.mid(1,8).stripWhiteSpace().toDouble();
    
    
    //
    file.close();
    //
    return QString::number(colimation*100);
}

//+++ read from DAT-file:: D=D+offset   [cm]
QString danp16::readDataD(QString name)
{
    //+++
    QString s,ss;
    int skip;
    double D;
    
    //+++
    QFile file( name );
    QTextStream t( &file );
    file.open(IO_ReadOnly);
    
    //+++
    for(skip=0;skip<28;skip++) s= t.readLine();
    //
    ss=s.mid(1,8).stripWhiteSpace();
    D=ss.toDouble();
    
    ss=s.mid(9,12).stripWhiteSpace();
    D+=ss.toDouble();
    
    file.close();
    
    return QString::number(D*100);
}

//+++ read  R1 source aperture
void danp16::readDataCollimationAperture(QString name, QString &ca1, QString &ca2)
{
    //+++
    QString s,ss;
    int skip;
    
    //+++
    QFile file( name );
    QTextStream t( &file );
    file.open(IO_ReadOnly);
    
    //+++
    for(skip=0;skip<21;skip++) s= t.readLine();
    //
    ss=s.mid(29,16).stripWhiteSpace();
    ca1=ss;
    
    ss=s.right(8).stripWhiteSpace();
    ca2=ss;
    
    file.close();
    
}

//+++ read  R2 defining aperture
void danp16::readDataSampleAperture(QString name, QString &sa1, QString &sa2)
{
    //+++
    QString s,ss;
    int skip;
    
    //+++
    QFile file( name );
    QTextStream t( &file );
    file.open(IO_ReadOnly);
    
    //+++
    for(skip=0;skip<34;skip++) s= t.readLine();
    //
    ss=s.mid(36,14).stripWhiteSpace();
    sa1=ss;
    
    ss=s.mid(50,14).stripWhiteSpace();
    sa2=ss;
    
    file.close();
}

//+++ lambda
QString danp16::readLambdaKWS2(QString name)
{
    //+++
    QString ss,s;
    int skip;
    double offset=0;
    
    //+++
    QFile file( name );
    QTextStream t( &file );
    file.open(IO_ReadOnly);
    
    //+++
    for (skip=1;skip<50;skip++) s = t.readLine();
    
    //Selector
    QRegExp rxF( "(\\d+)" );
    int pos=0;
    
    pos = rxF.search( s, pos ); pos+=rxF.matchedLength(); //  Selector
    ss=rxF.cap(1);   ss=QString::number(ss.toDouble(),'e',6);  double f=ss.toDouble();
    
    
    //+++
    for (skip=1;skip<10;skip++) s = t.readLine();
    
    
    //Real measurement time ok
    ss=s.left(9);
    double time=ss.toDouble();
    // lambda
    double lambda=2096/f*time+0.054;
    
    return QString::number(lambda);
}

//+++ lambda
QString danp16::readLambdaKWS1(QString name)
{
    //+++
    QString ss,s;
    int skip;
    double offset=0;
    
    //+++
    QFile file( name );
    QTextStream t( &file );
    file.open(IO_ReadOnly);
    
    //+++
    for (skip=1;skip<50;skip++) s = t.readLine();
    
    //Selector
    QRegExp rxF( "(\\d+)" );
    int pos=0;
    
    pos = rxF.search( s, pos ); pos+=rxF.matchedLength(); //  Selector
    ss=rxF.cap(1);   ss=QString::number(ss.toDouble(),'e',6);  double f=ss.toDouble();
    
    
    //+++
    for (skip=1;skip<10;skip++) s = t.readLine();
    
    
    //Real measurement time ok
    ss=s.left(9);
    double time=ss.toDouble();
    // lambda
    double lambda=2190/f*time+0.0946;
    
    return QString::number(lambda);
}

void danp16::readKWS2resoInfo()
{
    QString name = QFileDialog::getOpenFileName(
                                                lineEditPath->text(),
                                                "KWS2 rawdata (*.DAT)",
                                                this,
                                                "open file dialog",
                                                "Choose a file" );
    if (name=="")  return;
    
    
    lineEditResoCol->setText(readDataC(name));
    lineEditResoDet->setText(readDataD(name));
    lineEditResoPixelSize->setText("0.525");
    lineEditResoDeltaLambda->setText("0.2");
    
    QString sa1, sa2;
    readDataSampleAperture(name, sa1, sa2);
    
    lineEditResoSamAper->setText(sa1);
    lineEditResoSamAper2->setText(sa2);
    
    QString ca1, ca2;
    readDataCollimationAperture(name, ca1, ca2);
    
    lineEditResoColAper->setText(ca1);
    lineEditResoColAper2->setText(ca2);
    
    lineEditResoLambda->setText(readLambdaKWS2(name));
    
    lineEditResoFocus->setText(QString::number(1/ (1/ (lineEditResoCol->text().toDouble()-100) +  1/ (lineEditResoDet->text().toDouble()+100) )));
}

void danp16::readKWS1resoInfo()
{
    QString name = QFileDialog::getOpenFileName(
                                                lineEditPath->text(),
                                                "KWS1 rawdata (*.DAT)",
                                                this,
                                                "open file dialog",
                                                "Choose a file" );
    if (name=="")  return;
    
    
    lineEditResoCol->setText(readDataC(name));
    lineEditResoDet->setText(readDataD(name));
    lineEditResoPixelSize->setText("0.525");
    lineEditResoDeltaLambda->setText("0.1");
    
    QString sa1, sa2;
    readDataSampleAperture(name, sa1, sa2);
    
    lineEditResoSamAper->setText(sa1);
    lineEditResoSamAper2->setText(sa2);
    
    QString ca1, ca2;
    readDataCollimationAperture(name, ca1, ca2);
    
    lineEditResoColAper->setText(ca1);
    lineEditResoColAper2->setText(ca2);
    
    lineEditResoLambda->setText(readLambdaKWS1(name));
    
    lineEditResoFocus->setText(QString::number(1/ (1/ (lineEditResoCol->text().toDouble()-100) +  1/ (lineEditResoDet->text().toDouble()+100) )));
}

void danp16::readDANresoInfo()
{
    QString name = QFileDialog::getOpenFileName(
                                                lineEditPath->text(),
                                                "DAN Instrument (*.*)",
                                                this,
                                                "open file dialog",
                                                "Choose a file" );
    if (name=="")  return;
    
    
    lineEditResoCol->setText(readDataC(name));
    lineEditResoDet->setText(readDataD(name));
    lineEditResoPixelSize->setText("0.525");
    lineEditResoDeltaLambda->setText("0.1");
    
    QString sa1, sa2;
    readDataSampleAperture(name, sa1, sa2);
    
    lineEditResoSamAper->setText(sa1);
    lineEditResoSamAper2->setText(sa2);
    
    QString ca1, ca2;
    readDataCollimationAperture(name, ca1, ca2);
    
    lineEditResoColAper->setText(ca1);
    lineEditResoColAper2->setText(ca2);
    
    lineEditResoLambda->setText(readLambdaKWS1(name));
    
    lineEditResoFocus->setText(QString::number(1/ (1/ (lineEditResoCol->text().toDouble()-100) +  1/ (lineEditResoDet->text().toDouble()+100) )));
}



int danp16::numberSameEntriesYAML(QString fileName, QStringList lst)
{
    std::ifstream fin(fileName.ascii());
    YAML::Parser parser(fin);
    YAML::Node doc;
    
    std::string sss=lst[0].ascii();
    
    int count=0;
    int countLevels=lst.count();
    int i=0;
    
    if (countLevels==2 && lst[1]=="status") return 0;
    if (countLevels==3) return 0;
    if (countLevels==4 && lst[1]!="status") return 0;
    if (countLevels==4 && lst[2]=="") return 0;
    if (countLevels==4 && lst[3].toInt()<1) return 0;
    
    while(parser.GetNextDocument(doc))
    {
        for(YAML::Iterator it=doc.begin();it!=doc.end();++it)
        {
            // 2nd
            std::string key, value;
            std::string key2, value2;
            std::string ssss=lst[0].ascii();
            
            it.first() >> key;
            
            if (countLevels==1 && key==ssss) count++;
            
            int ttt=0;
            for(YAML::Iterator it2=it.second().begin();it2!=it.second().end();++it2)
            {
                key2=""; value2="";
                it2.first() >> key2;
                
                if (countLevels==2)
                {
                    if (key==lst[0].ascii() && key2==lst[1].ascii()) count++;
                }
                else if (countLevels==4)
                {
                    if (key2=="status")
                    {
                        std::string key3, value3,s3;
                        key3="\tstatus:\n";
                        
                        for (int k=0;k<it2.second().size();k++)
                        {
                            key3+="\t- [";
                            for (int kk=0;kk<it2.second()[k].size();kk++)
                            {
                                it2.second()[k][kk]>>value3;
                                QString vvv=value3.c_str();
                                
                                if (countLevels==4 && key==lst[0].ascii() && vvv.remove(" ")==lst[2].ascii()) count++;
                                
                                
                                
                                key3+=value3;
                                if (k+1<it2.second().size()) key3+=",";
                            }
                            key3+="]\n";
                        }
                        //std::cout <<key3;
                    }
                    else it2.second() >> value2;
                    
                }
                //std::cout << "\t" << key2 << ": " << value2 << std::endl;
                ttt++;
            }
            if(ttt==0) it.second() >> value;
            
            
            //std::cout<<"---\n"<<  key << ": " << value << std::endl;
        }
        i++;
    }
    
    return count;
}

int danp16::numberSameEntries(QDomElement root, QStringList lst)
{
    int number=lst.count();
    if (number<1) return -1;
    if (number==1) return 1;
    
    int numberCycles=0;
    QValueList<int> positions;
    
    //+++ number of cycles ...
    for (int i=1; i<number;i++)
    {
        if (lst[i].contains("{") && lst[i].contains("}"))
        {
            lst[i]=lst[i].remove("}");
            lst[i]=lst[i].remove("{");
            
            positions<<i;
            numberCycles++;
        }
    }
    
    if (numberCycles==0) return 1;
    if (numberCycles>2) return  -2;
    
    
    if (numberCycles==1)
    {
        int repeatCounter=0;
        int i=positions[0];
        
        if (root.tagName() != lst[0])
        {
            return -3;
        }
        
        QDomNode node = root.firstChild();
        
        bool nodeFound=false;
        bool repeatedNote;
        
        for(int ii=1; ii<=positions[0];ii++)
        {
            nodeFound=false;
            repeatedNote=false;
            
            if (ii==positions[0]) repeatedNote=true;
            
            while (!node.isNull() && !nodeFound )
            {
                if (node.toElement().tagName() == lst[ii] )
                {
                    if (repeatedNote)
                    {
                        node = node.nextSibling();
                        repeatCounter++;
                        if (node.toElement().tagName() != lst[positions[0]] ) return repeatCounter;
                    }
                    else
                    {
                        nodeFound=true;
                        repeatCounter++;
                        if (ii<positions[0]) node = node.firstChild();
                    }
                }
                else
                {
                    node = node.nextSibling();
                }
            }
            if (!nodeFound)
            {
                qWarning("XML(1) file error: level # %d, %s", ii, lst[ii].ascii());
                return 0;
            }
            if (repeatedNote) return repeatCounter;
            nodeFound=false;
        }
        return -4;
    }
    
    
    if (numberCycles==2)
    {
        int i=positions[0];
        
        if (root.tagName() != lst[0])
        {
            return -5;
        }
        
        QDomNode node = root.firstChild();
        
        bool nodeFound=false;
        bool repeatedNote;
        int repeatCounter2=0;
        
        for(int ii=1; ii<=positions[0];ii++)
        {
            nodeFound=false;
            repeatedNote=false;
            
            if (ii==positions[0]) repeatedNote=true;
            
            while (!node.isNull() && !nodeFound )
            {
                if (node.toElement().tagName() == lst[ii] )
                {
                    if (repeatedNote)
                    {
                        QDomNode node2 = node;
                        bool nodeFound2=false;
                        bool repeatedNote2;
                        
                        for(int iii=ii; iii<=positions[1];iii++)
                        {
                            nodeFound2=false;
                            repeatedNote2=false;
                            
                            if (iii==positions[1]) repeatedNote2=true;
                            
                            while (!node2.isNull() && !nodeFound2 )
                            {
                                if (node2.toElement().tagName() == lst[iii] )
                                {
                                    if (repeatedNote2)
                                    {
                                        node2 = node2.nextSibling();
                                        repeatCounter2++;
                                        if (node2.toElement().tagName() != lst[positions[1]] ) break;
                                        
                                    }
                                    else
                                    {
                                        nodeFound2=true;
                                        if (iii<positions[1]) node2 = node2.firstChild();
                                    }
                                }
                                else
                                {
                                    node2 = node2.nextSibling();
                                }
                            }
                            nodeFound2=false;
                        }
                        
                        node = node.nextSibling();
                        if (node.toElement().tagName() != lst[positions[0]] ) return repeatCounter2;
                    }
                    else
                    {
                        nodeFound=true;
                        if (ii<positions[0]) node = node.firstChild();
                    }
                }
                else
                {
                    node = node.nextSibling();
                }
            }
            if (!nodeFound)
            {
                qWarning("XML(2) file error: level # %d, %s", ii, lst[ii].ascii());
                return 0;
            }
            if (repeatedNote) return repeatCounter2;
            nodeFound=false;
        }
        return -5;
    }
    
}

bool danp16::readYAMLentry(QString fileName, QStringList lst,int order, QString &resultString)
{
    resultString="";
    
    std::ifstream fin(fileName.ascii());
    YAML::Parser parser(fin);
    YAML::Node doc;
    
    int count=0;
    
    int countLevels=lst.count();
    int i=0;
    
    if (countLevels==2 && lst[1]=="status") return false;
    if (countLevels==3) return false;
    if (countLevels==4 && lst[1]!="status") return false;
    if (countLevels==4 && lst[2]=="") return false;
    if (countLevels==4 && lst[3].toInt()<1) return false;
    
    
    while(parser.GetNextDocument(doc))
    {
        for(YAML::Iterator it=doc.begin();it!=doc.end();++it)
        {
            // 2nd
            std::string key, value;
            std::string key2, value2;
            
            it.first() >> key;
            if (countLevels==1 && key==lst[0].ascii())
            {
                count++;
                if (count==order)
                {
                    it.second()>>value;
                    resultString=value.c_str();
                    return true;
                }
            }
            for(YAML::Iterator it2=it.second().begin();it2!=it.second().end();++it2)
            {
                key2=""; value2="";
                it2.first() >> key2;
                
                if (countLevels==2)
                {
                    if (key==lst[0].ascii() && key2==lst[1].ascii())
                    {
                        count++;
                        if (count==order)
                        {
                            it2.second()>>value2;
                            resultString=value2.c_str();
                            return true;
                        }
                    }
                }
                else if (countLevels==4)
                {
                    if (key2=="status")
                    {
                        std::string value3,s3;
                        
                        for (int k=0;k<it2.second().size();k++)
                        {
                            for (int kk=0;kk<it2.second()[k].size();kk++)
                            {
                                it2.second()[k][kk]>>value3;
                                std::string vvv=value3;
                                
                                if (key==lst[0].ascii() && ((QString)vvv.c_str()).remove(" ")==lst[2].ascii())
                                {
                                    count++;
                                    if (count==order)
                                    {
                                        it2.second()[k][lst[3].toInt()]>>value3;
                                        resultString=value3.c_str();
                                        return true;
                                    }
                                }
                                
                            }
                        }
                    }
                }
            }
        }
        i++;
    }
    
    return false;
}

bool danp16::readXMLentry(QDomElement root, QStringList lst, QDomElement &element, int order)
{
    int number=lst.count();
    if (number<1) return false;
    if (number==1)
    {
        if (root.tagName() != lst[0] ) return false;
        element=root;
        return true;
    }
    int numberCycles=0;
    QValueList<int> positions;
    
    //+++ number of cycles ...
    for (int i=1; i<number;i++)
    {
        if (lst[i].contains("{") && lst[i].contains("}"))
        {
            lst[i]=lst[i].remove("}");
            lst[i]=lst[i].remove("{");
            
            positions<<i;
            numberCycles++;
        }
    }
    
    if (numberCycles>2) return  false;
    
    
    if (numberCycles<=1)
    {
        if (root.tagName() != lst[0])
        {
            qWarning("XML(0-1) file error: level # 0");
            return false;
        }
        
        QDomNode node = root.firstChild();
        bool nodeFound=false;
        
        bool repeatedNote;
        int repeatCounter;
        
        for(int i=1; i<number;i++)
        {
            repeatedNote=false;
            repeatCounter=0;
            
            if (lst[i].contains("{") && lst[i].contains("}"))
            {
                repeatedNote=true;
                lst[i]=lst[i].remove("{");
                lst[i]=lst[i].remove("}");
            }
            
            while (!node.isNull() && !nodeFound )
            {
                
                if (node.toElement().tagName() == lst[i] )
                {
                    if (repeatCounter<order && repeatedNote)
                    {
                        repeatCounter++;
                        node=node.nextSibling();
                    }
                    else
                    {
                        //qWarning("current node %s", node.toElement().tagName());
                        if (i<(number-1)) node = node.firstChild();
                        nodeFound=true;
                    }
                }
                else node = node.nextSibling();
            }
            if (!nodeFound)
            {
                qWarning("XML file error: level # %d, %s", i, lst[i].ascii());
                return false;
            }
            nodeFound=false;
        }
        if (node.toElement().tagName() == lst[number-1]) element=node.toElement();
        else return false;
    }
    
    if (numberCycles==2)
    {
        int i=positions[0];
        
        if (root.tagName() != lst[0])
        {
            return -5;
        }
        
        QDomNode node = root.firstChild();
        
        bool nodeFound=false;
        bool repeatedNote;
        int repeatCounter2=0;
        
        for(int ii=1; ii<=positions[0];ii++)
        {
            nodeFound=false;
            repeatedNote=false;
            
            if (ii==positions[0]) repeatedNote=true;
            
            while (!node.isNull() && !nodeFound )
            {
                if (node.toElement().tagName() == lst[ii] )
                {
                    if (repeatedNote)
                    {
                        QDomNode node2 = node;
                        bool nodeFound2=false;
                        bool repeatedNote2;
                        
                        for(int iii=ii; iii<=positions[1];iii++)
                        {
                            nodeFound2=false;
                            repeatedNote2=false;
                            
                            if (iii==positions[1]) repeatedNote2=true;
                            
                            while (!node2.isNull() && !nodeFound2 )
                            {
                                if (node2.toElement().tagName() == lst[iii] )
                                {
                                    if (repeatedNote2)
                                    {
                                        if (repeatCounter2==order)
                                        {
                                            if (iii<number-1)
                                            {
                                                for(int iiii=iii+1; iiii<number;iiii++)
                                                {
                                                    node2 = node2.firstChild();
                                                    while (!node2.isNull() && node2.toElement().tagName() != lst[iiii])
                                                        node2 = node2.nextSibling();
                                                }
                                            }
                                            element=node2.toElement();
                                            return true;
                                        }
                                        
                                        node2 = node2.nextSibling();
                                        repeatCounter2++;
                                        if (node2.toElement().tagName() != lst[positions[1]] ) break;
                                        
                                    }
                                    else
                                    {
                                        nodeFound2=true;
                                        if (iii<positions[1]) node2 = node2.firstChild();
                                    }
                                }
                                else
                                {
                                    node2 = node2.nextSibling();
                                }
                            }
                            nodeFound2=false;
                        }
                        
                        node = node.nextSibling();
                        if (node.toElement().tagName() != lst[positions[0]] ) return repeatCounter2;
                    }
                    else
                    {
                        nodeFound=true;
                        if (ii<positions[0]) node = node.firstChild();
                    }
                }
                else
                {
                    node = node.nextSibling();
                }
            }
            if (!nodeFound)
            {
                qWarning("XML(2) file error: level # %d, %s", ii, lst[ii].ascii());
                return 0;
            }
            if (repeatedNote) return repeatCounter2;
            nodeFound=false;
        }
        return -5;
    }
    
    
    return true;
}



void danp16::readCANSASresoInfo()
{
    QString name = QFileDialog::getOpenFileName(
                                                lineEditPath->text(),
                                                "cansas1d (*.XML *.xml)",
                                                this,
                                                "open file dialog",
                                                "Choose a file" );
    
    if (name=="")  return;
    
    QFile *xmlFile= new QFile( name );
    if (!xmlFile->open(IO_ReadOnly)) return;
    
    QString errorStr;
    int errorLine;
    int errorColumn;
    
    QDomDocument doc;
    if (!doc.setContent(xmlFile, true, &errorStr, &errorLine,&errorColumn))
    {
        qWarning("XML file error: line %d, column %d: %s", errorLine, errorColumn,errorStr.ascii());
        return;
    }
    
    QDomElement root = doc.documentElement();
    
    
    QStringList lst;
    QDomElement element;
    
    
    double currentValue;
    QString units;
    
    //+++++++++++ COLLIMATION
    lst.clear();
    lst<<"SASroot"<<"SASentry"<<"SASinstrument"<<"SAScollimation"<<"length";
    if (readXMLentry(root, lst, element,0))
    {
        currentValue=element.text().toDouble();
        units= element.attribute("unit");
        if (units.contains("mm")) currentValue/=10.0;
        else if (units.contains("cm")) currentValue*=1.0;
        else if (units.contains("m")) currentValue*=100;
    }
    else currentValue=0;
    
    if (currentValue<10.0)  
    {
        lineEditResoCol->blockSignals( TRUE );
        lineEditResoCol->setText("not in file");
        lineEditResoCol->blockSignals( FALSE );	
    }
    else
        lineEditResoCol->setText(QString::number(currentValue));
    
    //+++++++++++ Wavelength
    lst.clear();
    lst<<"SASroot"<<"SASentry"<<"SASinstrument"<<"SASsource"<<"wavelength";
    if (readXMLentry(root, lst, element,0))
    {
        currentValue=element.text().toDouble();
        units= element.attribute("unit");
        if (units.contains("nm")) currentValue/=10.0;
    }
    else currentValue=0;
    
    if (currentValue<0.1)  
    {
        lineEditResoLambda->blockSignals( TRUE );
        lineEditResoLambda->setText("not in file");
        lineEditResoLambda->blockSignals( FALSE );	
    }
    else
        lineEditResoLambda->setText(QString::number(currentValue));
    
    
    //+++++++++++ Wavelength Spread
    lst.clear();
    lst<<"SASroot"<<"SASentry"<<"SASinstrument"<<"SASsource"<<"wavelength_spread";
    if (readXMLentry(root, lst, element,0))
    {
        currentValue=element.text().toDouble();
        units= element.attribute("unit");
        if (units.contains("%")) currentValue/=100.0;
    }
    else currentValue=0;
    
    if (currentValue<0.0001)  
    {
        lineEditResoDeltaLambda->blockSignals( TRUE );
        lineEditResoDeltaLambda->setText("not in file");
        lineEditResoDeltaLambda->blockSignals( FALSE );	
    }
    else
        lineEditResoDeltaLambda->setText(QString::number(currentValue));
    
    //+++++++++++ DETECTOR
    lst.clear();
    lst<<"SASroot"<<"SASentry"<<"SASinstrument"<<"SASdetector"<<"SDD";
    if (readXMLentry(root, lst, element,0))
    {
        currentValue=element.text().toDouble();
        units= element.attribute("unit");
        if (units.contains("mm")) currentValue/=10.0;
        else if (units.contains("cm")) currentValue*=1.0;
        else if (units.contains("m")) currentValue*=100;
    }
    else currentValue=0;
    
    if (currentValue<10.0)  
    {
        lineEditResoDet->blockSignals( TRUE );
        lineEditResoDet->setText("not in file");
        lineEditResoDet->blockSignals( FALSE );	
    }
    else
        lineEditResoDet->setText(QString::number(currentValue));
    
    //+++++++++++ Pixel Size
    lst.clear();
    lst<<"SASroot"<<"SASentry"<<"SASinstrument"<<"SASdetector"<<"pixel_size"<<"x";
    if (readXMLentry(root, lst, element,0))
    {
        currentValue=element.text().toDouble();
        units= element.attribute("unit");
        if (units.contains("mm")) currentValue/=10.0;
        else if (units.contains("cm")) currentValue*=1.0;
        else if (units.contains("m")) currentValue*=100;
    }
    else currentValue=0;
    
    if (currentValue<0.0001)  
    {
        lineEditResoPixelSize->blockSignals( TRUE );
        lineEditResoPixelSize->setText("not in file");
        lineEditResoPixelSize->blockSignals( FALSE );	
    }
    else
        lineEditResoPixelSize->setText(QString::number(currentValue));
    
    //+++++++++++ Collimation Aperture
    lst.clear();
    lst<<"SASroot"<<"SASentry"<<"SASinstrument"<<"SAScollimation"<<"aperture"<<"size"<<"x";
    if (readXMLentry(root, lst, element,0))
    {
        currentValue=element.text().toDouble();
        units= element.attribute("unit");
        if (units.contains("mm")) currentValue*=1.0;
        else if (units.contains("cm")) currentValue*=10.0;
        else if (units.contains("m")) currentValue*=1000;
    }
    else currentValue=0;
    
    if (currentValue<0.01)  
    {
        lineEditResoColAper->blockSignals( TRUE );
        lineEditResoColAper->setText("not in file");
        lineEditResoColAper->blockSignals( FALSE );	
    }
    else
        lineEditResoColAper->setText(QString::number(currentValue));
    
    lst.clear();
    lst<<"SASroot"<<"SASentry"<<"SASinstrument"<<"SAScollimation"<<"aperture"<<"size"<<"y";
    if (readXMLentry(root, lst, element,0))
    {
        currentValue=element.text().toDouble();
        units= element.attribute("unit");
        if (units.contains("mm")) currentValue*=1.0;
        else if (units.contains("cm")) currentValue*=10.0;
        else if (units.contains("m")) currentValue*=1000;
    }
    else currentValue=0;
    
    if (currentValue<0.01)  
    {
        lineEditResoColAper2->blockSignals( TRUE );
        lineEditResoColAper2->setText("not in file");
        lineEditResoColAper2->blockSignals( FALSE );	
    }
    else
        lineEditResoColAper2->setText(QString::number(currentValue));
    
    //+++++++++++ Sample Aperture
    double factor=1;
    lst.clear();
    lst<<"SASroot"<<"SASentry"<<"SASinstrument"<<"SASsource"<<"beam_shape";
    if (readXMLentry(root, lst, element,0))
    {
        units= element.text();
        if (units.contains("disc")) factor=sqrt(M_PI)/2; // a*a=sqrt(pi) * d/2 * sqrt(pi) * d/2  --> a= sqrt(pi)/2 d 
    }
    
    
    lst.clear();
    lst<<"SASroot"<<"SASentry"<<"SASinstrument"<<"SASsource"<<"beam_size"<<"x";
    if (readXMLentry(root, lst, element,0))
    {
        currentValue=element.text().toDouble();
        units= element.attribute("unit");
        if (units.contains("mm")) currentValue*=1.0;
        else if (units.contains("cm")) currentValue*=10.0;
        else if (units.contains("m")) currentValue*=1000;
    }
    else currentValue=0;
    
    currentValue*=factor;
    
    if (currentValue<0.01)  
    {
        lineEditResoSamAper->blockSignals( TRUE );
        lineEditResoSamAper->setText("not in file");
        lineEditResoSamAper->blockSignals( FALSE );	
    }
    else
        lineEditResoSamAper->setText(QString::number(currentValue));
    
    lst.clear();
    lst<<"SASroot"<<"SASentry"<<"SASinstrument"<<"SASsource"<<"beam_size"<<"y";
    if (readXMLentry(root, lst, element,0))
    {
        currentValue=element.text().toDouble();
        units= element.attribute("unit");
        if (units.contains("mm")) currentValue*=1.0;
        else if (units.contains("cm")) currentValue*=10.0;
        else if (units.contains("m")) currentValue*=1000;
    }
    else currentValue=0;
    
    currentValue*=factor;
    
    if (currentValue<0.01)  
    {
        lineEditResoSamAper2->blockSignals( TRUE );
        lineEditResoSamAper2->setText("not in file");
        lineEditResoSamAper2->blockSignals( FALSE );	
    }
    else
        lineEditResoSamAper2->setText(QString::number(currentValue));
    
    
    
    xmlFile->close();
    /*
     lst<<"SASroot"<<"SASentry"<<"SASinstrument"<<"SASsource"<<"beam_size"<<"y";
     
     
     lineEditResoDeltaLambda->setText("0.1");
     
     QString sa1, sa2;
     readDataSampleAperture(name, sa1, sa2);
     
     lineEditResoSamAper->setText(sa1);
     lineEditResoSamAper2->setText(sa2);
     
     QString ca1, ca2;
     readDataCollimationAperture(name, ca1, ca2);
     
     lineEditResoColAper->setText(ca1);
     lineEditResoColAper2->setText(ca2);
     
     lineEditResoLambda->setText(readLambdaKWS1(name));
     
     lineEditResoFocus->setText(QString::number(1/ (1/ (lineEditResoCol->text().toDouble()-100) +  1/ (lineEditResoDet->text().toDouble()+100) )));
     */
}


//+++ linearBinning
bool danp16::linearBinning(gsl_matrix* &data, int N, int &Nfinal)
{
    int binning=spinBoxBinningLinear->value();
    
    if (binning==1) return true;
    if (Nfinal==1) return true;
    
    
    int Nnew=(int)(double(double(Nfinal)/double(binning)));
    
    int lastBinning=binning;
    
    if ((Nfinal-Nnew*binning)>0) lastBinning+=Nfinal-Nnew*binning;
    
    double qq, ii, di, sigma;
    int localBinning=binning;
    
    int nn=0;
    
    
    for(int n=0;n<Nnew;n++)
    {
        
        qq=0;
        ii=0;
        di=0;
        sigma=0;
        if (n==Nnew-1) localBinning=lastBinning;
        
        for(int b=0;b<localBinning;b++)
        {
            if (gsl_matrix_get(data, nn,0) == -99.99)
            {
                b--;
                nn++;
                continue;
            }
            qq+=gsl_matrix_get(data, nn, 0);
            ii+=gsl_matrix_get(data, nn, 1);
            di+=gsl_matrix_get(data, nn, 2)*gsl_matrix_get(data, nn, 2);
            sigma+=gsl_matrix_get(data, nn, 3)*gsl_matrix_get(data, nn, 3);
            nn++;
        }
        
        gsl_matrix_set(data,n,0,qq/localBinning);
        gsl_matrix_set(data,n,1,ii/localBinning);
        gsl_matrix_set(data,n,2,sqrt(fabs(di))/localBinning);
        gsl_matrix_set(data,n,3,sqrt(sigma)/localBinning);
    }
    
    for(int n=Nnew; n<N; n++) gsl_matrix_set(data,n,0,-99.99);
    
    Nfinal=Nnew;
    return true;
}

//+++ logBinning
bool danp16::logBinning(gsl_matrix* &data, int N, int &Nfinal)
{
    double binningRatio=lineEditBinningProgressive->text().toDouble();
    
    if (binningRatio==1.0) return true;
    if (Nfinal==1) return true;
    
    
    int Nnew=0;
    
    int currentBinning=1;
    
    double qq, ii, di, sigma;
    
    for(int n=0;n<N;n++)
    {
        
        
        currentBinning=int( pow(binningRatio,Nnew));
        
        qq=0;
        ii=0;
        di=0;
        sigma=0;
        
        for(int b=0;b<currentBinning;b++)
        {
            if (n==N-1 || Nnew==Nfinal-1)
            {
                currentBinning=b;
                n++;
                break;
            }
            
            if (gsl_matrix_get(data, n,0) == -99.99)
            {
                n++;
                b--;
                continue;
            }
            
            qq+=gsl_matrix_get(data, n, 0);
            ii+=gsl_matrix_get(data, n, 1);
            di+=gsl_matrix_get(data, n, 2)*gsl_matrix_get(data, n, 2);
            sigma+=gsl_matrix_get(data, n, 3)*gsl_matrix_get(data, n, 3);
            
            n++;
        }
        
        n--;
        
        if(currentBinning==0) break;
        
        gsl_matrix_set(data,Nnew,0,qq/currentBinning);
        gsl_matrix_set(data,Nnew,1,ii/currentBinning);
        gsl_matrix_set(data,Nnew,2,sqrt(fabs(di))/currentBinning);
        gsl_matrix_set(data,Nnew,3,sqrt(sigma)/currentBinning);
        
        
        Nnew++;
    }
    
    for(int n=Nnew; n<N; n++) gsl_matrix_set(data,n,0,-99.99);
    
    Nfinal=Nnew;
    return true;
}


void danp16::minmaxPositiveXY(Graph* g, double &minX, double &maxX, double &minY, double &maxY, bool onlyPositiveX, bool onlyPositiveY)
{
    QStringList columnsListOnPlot=g->curvesList();
    
    minX=1e300;
    maxX=0;
    minY=1e300;
    maxY=0;
    
    
    
    for (int i=0; i<columnsListOnPlot.count();i++)
    {
        QwtPlotCurve *c = g->curve(i);
        if (!c)
            return;
        
        int curveType = g->curveType(i);
        
        
        //++++++++++  Error-Bars  ++++++++++++++
        if (comboBoxSchemaAim->currentText()!="error-bars" && curveType != Graph::ErrorBars)
        {
            for (int ii=0; ii<c->dataSize(); ii++)
            {
                if ( ( !onlyPositiveX || c->x(ii)>0) && c->x(ii)<minX) minX=c->x(ii);
                if ( ( !onlyPositiveX || c->x(ii)>0) && c->x(ii)>maxX) maxX=c->x(ii);
                
                if ( ( !onlyPositiveY ||c->y(ii)>0) && c->y(ii)<minY) minY=c->y(ii);
                if ( ( !onlyPositiveY ||c->y(ii)>0) && c->y(ii)>maxY) maxY=c->y(ii);
            }
            
        }
        
        
    }
    
}
