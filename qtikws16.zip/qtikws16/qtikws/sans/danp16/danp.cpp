/****************************************************************************
** Form implementation generated from reading ui file '..\qtiKWS\sans\danp16\danp.ui'
**
** Created: Do 14. Sep 02:02:06 2017
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.4   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "danp.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qtabwidget.h>
#include <qbuttongroup.h>
#include <qlineedit.h>
#include <qtoolbutton.h>
#include <qcombobox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qspinbox.h>
#include <qcheckbox.h>
#include <qsplitter.h>
#include <qtoolbox.h>
#include <qradiobutton.h>
#include <qtable.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "danp.ui.h"
static const unsigned char image0_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0x72, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0xcd, 0x8f, 0x0b,
    0x71, 0x00, 0x86, 0x9f, 0x99, 0x4e, 0xdb, 0x99, 0x4e, 0x6b, 0x35, 0xa5,
    0x2c, 0xb1, 0x64, 0x7d, 0x64, 0x49, 0x6c, 0x90, 0x88, 0x83, 0x08, 0x4e,
    0xe2, 0xe4, 0xc2, 0xcd, 0x41, 0xe2, 0xec, 0x9f, 0xc0, 0x41, 0x48, 0x9c,
    0x36, 0x5c, 0x71, 0x12, 0x17, 0x17, 0x1f, 0x89, 0x88, 0xe2, 0xa0, 0x42,
    0x10, 0xf1, 0xb9, 0x8b, 0xfd, 0x2a, 0x5b, 0x53, 0xed, 0x74, 0x3a, 0xd3,
    0xf9, 0xec, 0xcc, 0xfc, 0x1c, 0xb0, 0x89, 0x44, 0x5c, 0xf6, 0x4d, 0xde,
    0xe3, 0xfb, 0x9c, 0xde, 0x47, 0x12, 0x42, 0xb0, 0x94, 0xc8, 0x4b, 0x5a,
    0x03, 0x0a, 0x40, 0x7d, 0x42, 0x1a, 0x13, 0x89, 0x72, 0x34, 0x5f, 0xd6,
    0xb7, 0x4a, 0x4a, 0x61, 0x47, 0xe8, 0x07, 0xdb, 0xba, 0x66, 0xef, 0xec,
    0x95, 0xab, 0xe9, 0x99, 0xd1, 0x6d, 0x68, 0x99, 0x98, 0x75, 0xd5, 0x61,
    0x76, 0x29, 0x59, 0x9a, 0xd5, 0x05, 0x1e, 0x1c, 0xbb, 0x21, 0x92, 0x3f,
    0x00, 0x49, 0x08, 0x41, 0xfd, 0x72, 0xae, 0xb6, 0x66, 0x7c, 0xdf, 0x81,
    0xca, 0xc6, 0xed, 0x14, 0x34, 0x88, 0x5c, 0x83, 0x17, 0xb7, 0x6b, 0xb3,
    0xb3, 0x93, 0xe6, 0xc3, 0x91, 0x2d, 0xea, 0x26, 0xbd, 0xc8, 0xce, 0x52,
    0xc1, 0xd5, 0xe7, 0xe7, 0xd3, 0xef, 0x6f, 0x26, 0x39, 0xbc, 0xb6, 0xba,
    0x6c, 0x3e, 0x46, 0xc8, 0x53, 0x38, 0xa6, 0x02, 0x90, 0x4a, 0xd9, 0x6c,
    0x65, 0x74, 0x9c, 0xe2, 0xea, 0xf5, 0xe0, 0x35, 0xc8, 0x69, 0x1a, 0x63,
    0xbb, 0x37, 0x6d, 0xd8, 0x3c, 0xde, 0x3e, 0xb1, 0x62, 0x28, 0x46, 0x56,
    0x2c, 0x90, 0x53, 0xa4, 0x94, 0x95, 0x4e, 0x50, 0x38, 0x57, 0x5e, 0x2e,
    0xaf, 0xee, 0xf7, 0x5d, 0x5d, 0x9f, 0xe6, 0xb8, 0x02, 0x60, 0x5b, 0xe1,
    0xab, 0x7e, 0x73, 0x72, 0x6f, 0xb1, 0x92, 0x07, 0xdf, 0x44, 0x4e, 0x4c,
    0xca, 0xab, 0x72, 0x88, 0xb4, 0x4a, 0xd0, 0x75, 0xe9, 0x35, 0x55, 0xa2,
    0x48, 0x27, 0xc9, 0x65, 0x32, 0x9b, 0x47, 0x8d, 0x43, 0xaa, 0x12, 0x30,
    0xe5, 0x24, 0x84, 0x21, 0x7b, 0x14, 0x80, 0xce, 0x0f, 0x31, 0xe7, 0x5a,
    0x06, 0xa4, 0x1d, 0x92, 0xa0, 0x85, 0x65, 0xf8, 0x0c, 0xd2, 0x11, 0xba,
    0xed, 0x80, 0x28, 0xd1, 0x08, 0xbd, 0x1e, 0x56, 0xeb, 0x2d, 0xaa, 0x6c,
    0xa2, 0x66, 0x3b, 0x38, 0x11, 0xcc, 0x7e, 0x43, 0x74, 0x2c, 0x3e, 0x2a,
    0x00, 0x66, 0x37, 0xfd, 0xe4, 0x74, 0xdb, 0xe0, 0x37, 0x70, 0xdb, 0x5d,
    0x2c, 0x6f, 0x3f, 0x3d, 0xd3, 0xc7, 0x98, 0x79, 0x47, 0x68, 0xbf, 0x24,
    0x89, 0x53, 0xf2, 0x39, 0xc8, 0x16, 0x20, 0xaf, 0x81, 0x15, 0x82, 0xed,
    0xf2, 0x3a, 0xf0, 0x79, 0xae, 0x00, 0xf4, 0x07, 0x34, 0x3c, 0xdb, 0x8e,
    0xb1, 0x1b, 0x4a, 0xe4, 0x0e, 0x21, 0xe2, 0x01, 0xd3, 0xcf, 0x26, 0x48,
    0x12, 0xd0, 0x74, 0xc8, 0x15, 0x40, 0x55, 0x41, 0x2f, 0x40, 0x3e, 0x07,
    0x5f, 0xa7, 0xc1, 0x71, 0xb9, 0x77, 0xe9, 0x96, 0xe8, 0xca, 0xbf, 0x01,
    0x7d, 0xc7, 0xee, 0x9b, 0x61, 0xa7, 0xc5, 0x20, 0x56, 0x30, 0x66, 0xee,
    0x93, 0x91, 0xa1, 0xbc, 0x12, 0x54, 0x0d, 0x34, 0x0d, 0x4a, 0xc5, 0x5f,
    0xf5, 0x23, 0xf8, 0xde, 0x81, 0x48, 0xf0, 0x68, 0xf1, 0x07, 0x9e, 0x4f,
    0xcf, 0xb1, 0xe3, 0x6f, 0xb6, 0xe9, 0x56, 0xbd, 0xc8, 0x21, 0xf6, 0x3e,
    0x53, 0x5c, 0x06, 0x05, 0x0d, 0xd4, 0x3c, 0x64, 0x33, 0x90, 0xa6, 0xd0,
    0xb3, 0xe1, 0xc3, 0x1c, 0xd8, 0x1e, 0xef, 0xe3, 0x01, 0x4f, 0x17, 0x01,
    0xbe, 0xc0, 0x69, 0x99, 0x52, 0xbb, 0xef, 0x49, 0xc4, 0x51, 0x13, 0x29,
    0x09, 0xa8, 0x56, 0x40, 0x48, 0x60, 0x39, 0xd0, 0x32, 0x7f, 0xd5, 0xf6,
    0x21, 0x08, 0x69, 0x09, 0xc1, 0xa9, 0x8b, 0x37, 0x84, 0xb9, 0x08, 0x60,
    0x81, 0x81, 0x33, 0x2c, 0x3a, 0x0b, 0xcd, 0x01, 0xe5, 0x92, 0x89, 0x17,
    0x42, 0xcb, 0x06, 0xc3, 0x84, 0x5e, 0x1f, 0xbc, 0x00, 0x23, 0x15, 0xd4,
    0xa2, 0x98, 0x3b, 0xb2, 0xe0, 0xc9, 0xf9, 0xeb, 0xe2, 0xcb, 0x5f, 0x4f,
    0x04, 0x38, 0x7d, 0x52, 0x3a, 0xa8, 0xab, 0xdc, 0xd4, 0x35, 0x86, 0xda,
    0x16, 0x22, 0x8c, 0x79, 0x83, 0xe0, 0xee, 0x20, 0xa6, 0xee, 0x05, 0xbc,
    0xc8, 0xeb, 0x74, 0x2f, 0x5c, 0x13, 0xee, 0x3f, 0x5d, 0x00, 0x78, 0xeb,
    0xf0, 0x78, 0x83, 0xc3, 0x11, 0x32, 0xec, 0xca, 0x65, 0xf9, 0x1c, 0xc4,
    0xd4, 0x4b, 0x4d, 0xac, 0x33, 0x35, 0x11, 0xff, 0x4f, 0x26, 0x69, 0xa9,
    0x3a, 0xff, 0x04, 0x4b, 0x8d, 0x4f, 0xed, 0xbd, 0xdc, 0x21, 0x42, 0x00,
    0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image1_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xe0, 0x77, 0x3d, 0xf8, 0x00, 0x00, 0x05,
    0x37, 0x49, 0x44, 0x41, 0x54, 0x48, 0x89, 0xb5, 0x95, 0x6b, 0x8c, 0x9c,
    0x55, 0x19, 0x80, 0x9f, 0xf3, 0x5d, 0xe7, 0x9b, 0xeb, 0xce, 0xee, 0x74,
    0x6f, 0xbd, 0x6c, 0xbb, 0xb5, 0xac, 0x96, 0xa2, 0x01, 0x22, 0x69, 0x48,
    0x50, 0x2e, 0x26, 0xd0, 0x0a, 0x18, 0xb9, 0x14, 0x2f, 0x51, 0xa2, 0x21,
    0xf1, 0x16, 0x42, 0x84, 0x1f, 0x62, 0x14, 0x09, 0x9a, 0xe8, 0x0f, 0x13,
    0x62, 0x24, 0x31, 0xda, 0x9a, 0x68, 0x68, 0x4c, 0x13, 0x4b, 0x82, 0xb5,
    0x16, 0x48, 0x50, 0x9b, 0x60, 0xc0, 0x68, 0x69, 0x2b, 0x4d, 0xed, 0x2e,
    0xed, 0x16, 0xda, 0xed, 0x6e, 0x99, 0xbd, 0xcc, 0x7c, 0x33, 0xfb, 0xcd,
    0xcc, 0x77, 0x3d, 0xe7, 0xf8, 0xc3, 0x48, 0x58, 0xb2, 0x2b, 0xfe, 0x90,
    0xf7, 0xf7, 0x7b, 0x9e, 0x27, 0x79, 0xcf, 0x7b, 0x11, 0x5a, 0x6b, 0xde,
    0xcf, 0x30, 0xde, 0x57, 0x3a, 0x60, 0xbd, 0x57, 0xc2, 0x55, 0xbf, 0x14,
    0x43, 0x4e, 0xde, 0xf9, 0x84, 0xe3, 0xe4, 0x3e, 0x23, 0xa5, 0xd8, 0x29,
    0x33, 0x51, 0x93, 0x11, 0x10, 0x99, 0xaf, 0x64, 0xa1, 0x71, 0xb4, 0x17,
    0x45, 0xfb, 0xdf, 0xf8, 0xee, 0xf2, 0xeb, 0x6b, 0xbd, 0x17, 0x6b, 0x95,
    0x68, 0xcf, 0xc1, 0x3d, 0x66, 0x50, 0x78, 0xe9, 0x1b, 0xf9, 0x62, 0xf1,
    0xa1, 0xcd, 0xe5, 0x2b, 0xc7, 0x87, 0xf3, 0xe3, 0xe4, 0xed, 0x2a, 0xa1,
    0xe8, 0x31, 0xe3, 0x5f, 0xe0, 0xd4, 0xe5, 0x93, 0xbc, 0x35, 0x5f, 0x87,
    0x96, 0xdd, 0x8a, 0x42, 0xb5, 0x37, 0xcb, 0x65, 0x3f, 0x9e, 0x7b, 0x64,
    0x79, 0xe9, 0x7f, 0x12, 0xdc, 0x74, 0xa0, 0x5c, 0xab, 0x8e, 0xf6, 0xef,
    0xbf, 0x7a, 0xe4, 0x86, 0xdb, 0x76, 0x8f, 0x7e, 0x99, 0xd1, 0xe2, 0x56,
    0x5a, 0xba, 0x41, 0x23, 0x99, 0xc7, 0x4f, 0x9b, 0xa4, 0x4a, 0x62, 0x5a,
    0x2e, 0x2f, 0xcf, 0xfd, 0x99, 0x23, 0xa7, 0x0f, 0xd1, 0xb9, 0xd8, 0x23,
    0x6d, 0xeb, 0x33, 0xa1, 0x54, 0x9f, 0xf3, 0xbf, 0xdf, 0x79, 0xed, 0xbf,
    0x0a, 0x76, 0xfe, 0x46, 0x94, 0x47, 0x37, 0x6e, 0x3a, 0x7c, 0xd7, 0xb6,
    0xaf, 0x7e, 0xec, 0x9e, 0x91, 0x07, 0x39, 0xc7, 0xab, 0x1c, 0xed, 0xfc,
    0x96, 0xb9, 0x70, 0x06, 0x3f, 0x6c, 0xd3, 0x8d, 0x13, 0x64, 0x6a, 0x62,
    0xa4, 0x39, 0x26, 0xca, 0xd7, 0x10, 0xc8, 0x1e, 0x47, 0x26, 0x7f, 0x8f,
    0x7f, 0xb6, 0x8d, 0xf4, 0xd5, 0x9b, 0x5d, 0x5b, 0xdf, 0xd8, 0x7b, 0xbc,
    0x37, 0xb3, 0xaa, 0x60, 0xcf, 0xc1, 0xeb, 0xbd, 0x4e, 0x65, 0xe6, 0x99,
    0x4f, 0x6f, 0x7f, 0x60, 0xf7, 0x67, 0x37, 0x7c, 0x93, 0x17, 0xf4, 0x53,
    0x4c, 0x66, 0x7f, 0x25, 0x0e, 0x35, 0x71, 0xa2, 0x48, 0xc9, 0x68, 0x85,
    0x5d, 0xda, 0x9d, 0x90, 0x4e, 0x27, 0xc6, 0xef, 0x04, 0xac, 0xf7, 0xb6,
    0x21, 0x15, 0x9c, 0xb8, 0x74, 0x92, 0xe8, 0x6c, 0x82, 0xea, 0xc8, 0xe7,
    0xda, 0x69, 0x72, 0x8f, 0x7e, 0x52, 0x87, 0xf0, 0xae, 0x2e, 0x9a, 0xcb,
    0xa6, 0xee, 0xbe, 0x62, 0xe0, 0x9a, 0xdd, 0x9f, 0xdc, 0xf0, 0x25, 0x0e,
    0x44, 0x3f, 0xe0, 0x54, 0xfc, 0x17, 0x44, 0xe6, 0x62, 0x60, 0xd3, 0xe9,
    0x44, 0xbc, 0xfc, 0xdc, 0x05, 0xfc, 0x57, 0x8a, 0xb8, 0x8b, 0x35, 0x6c,
    0xd3, 0xc6, 0x31, 0x3d, 0x26, 0xfd, 0xd3, 0x5c, 0x6a, 0x5f, 0x22, 0xef,
    0x95, 0x90, 0x83, 0x0a, 0x05, 0xbb, 0x3d, 0xd3, 0xb9, 0xed, 0x3f, 0xcc,
    0xb7, 0x05, 0x3b, 0x9e, 0x10, 0x45, 0x2b, 0x6f, 0x3d, 0x7c, 0xeb, 0xe6,
    0xcf, 0xf3, 0x8f, 0xf8, 0x28, 0xff, 0xec, 0x1e, 0x43, 0x27, 0x2e, 0x4a,
    0x80, 0xed, 0x19, 0x9c, 0x3f, 0xb7, 0xc8, 0xe3, 0x1f, 0x7e, 0x8a, 0xa7,
    0x77, 0x3d, 0xcb, 0x2f, 0xae, 0x7b, 0x86, 0x75, 0xb9, 0x61, 0xa4, 0xc8,
    0xb0, 0xb0, 0xf1, 0xc3, 0x26, 0x41, 0x14, 0x60, 0x14, 0x2c, 0x74, 0x4e,
    0xa0, 0x52, 0xf5, 0x05, 0x71, 0x93, 0xb0, 0xe0, 0x1d, 0x6d, 0x1a, 0x0f,
    0x70, 0xf3, 0xe6, 0xca, 0x8e, 0xab, 0xab, 0xe5, 0x75, 0xfc, 0xae, 0xf1,
    0x33, 0x14, 0x16, 0xb1, 0x4e, 0x39, 0x71, 0x7a, 0x9a, 0x46, 0xdb, 0x67,
    0xfe, 0xf5, 0x94, 0x5b, 0xbe, 0x7e, 0x33, 0x9e, 0xe3, 0x12, 0xab, 0x88,
    0x33, 0xd3, 0xd3, 0xcc, 0x85, 0x75, 0x9c, 0x5c, 0x1e, 0x81, 0x89, 0x81,
    0xc0, 0x34, 0x21, 0x2b, 0x29, 0x74, 0x53, 0xde, 0xca, 0x26, 0x86, 0x80,
    0xb9, 0xb7, 0x05, 0x96, 0xe3, 0xde, 0x3f, 0xd6, 0xf7, 0x21, 0xa6, 0xc2,
    0x93, 0xcc, 0x76, 0x2f, 0x51, 0xc9, 0x17, 0x38, 0x7e, 0xe2, 0x0d, 0x3e,
    0xd2, 0xdb, 0xc5, 0xae, 0x89, 0xdb, 0x71, 0x3f, 0xe8, 0xa2, 0xad, 0x8c,
    0x48, 0x2b, 0x22, 0x15, 0xf3, 0xc5, 0xc1, 0x07, 0x71, 0x0d, 0x8f, 0xe7,
    0xbb, 0x87, 0xf8, 0x7b, 0xe3, 0x6f, 0xd8, 0x46, 0x0e, 0xc3, 0x50, 0x64,
    0x39, 0x09, 0x3a, 0xcd, 0xe3, 0x72, 0xed, 0x0a, 0x81, 0xc6, 0xfc, 0xa8,
    0xe3, 0x78, 0x34, 0xc2, 0x45, 0x96, 0xa3, 0x80, 0x9c, 0xeb, 0xb2, 0x74,
    0x31, 0xe1, 0x5b, 0xf7, 0x3e, 0xc6, 0x50, 0xdf, 0x00, 0x00, 0xbe, 0xf2,
    0x51, 0x5a, 0x21, 0x0c, 0xc1, 0x03, 0x3b, 0xbf, 0x86, 0x47, 0x0e, 0x63,
    0x5a, 0xf3, 0x6a, 0xf3, 0x38, 0x05, 0xb3, 0x48, 0x4a, 0x46, 0x6c, 0xa5,
    0xa0, 0x63, 0x90, 0xf4, 0xad, 0x28, 0x91, 0xd0, 0xc6, 0xc6, 0x0e, 0x01,
    0x49, 0x64, 0x91, 0xc4, 0x92, 0x66, 0x67, 0x99, 0x1d, 0x63, 0x57, 0x52,
    0xf0, 0x0a, 0x48, 0x34, 0x2d, 0xdd, 0x24, 0x52, 0x11, 0xa0, 0xb1, 0x0d,
    0x9b, 0x94, 0x04, 0x8f, 0x1c, 0x12, 0xc8, 0x19, 0x79, 0x2a, 0x4e, 0x85,
    0x9e, 0x8e, 0xe8, 0xd2, 0x03, 0x05, 0x68, 0xd4, 0x0a, 0x81, 0x4a, 0x0d,
    0x5d, 0x5f, 0xae, 0x8b, 0x9c, 0xe1, 0x92, 0xa6, 0x82, 0xb0, 0xab, 0x60,
    0x70, 0x81, 0x9f, 0xce, 0x7f, 0x87, 0xa5, 0xb9, 0x0e, 0x77, 0x8c, 0xdd,
    0xc7, 0xc4, 0xc8, 0x04, 0x89, 0x4a, 0x39, 0xbb, 0x3c, 0xc5, 0xe9, 0xe6,
    0x6b, 0x18, 0xca, 0xe2, 0xf0, 0x85, 0x3f, 0x50, 0x75, 0x07, 0x28, 0xe7,
    0xaa, 0xc8, 0xd8, 0x47, 0x24, 0x06, 0x52, 0x2b, 0x30, 0x09, 0x56, 0x08,
    0x64, 0x6c, 0x4c, 0x36, 0x03, 0x7f, 0x7b, 0xb1, 0x50, 0x44, 0x28, 0x87,
    0x2c, 0x35, 0x68, 0x24, 0x01, 0x87, 0xeb, 0x07, 0x99, 0x3d, 0xd3, 0xe2,
    0xba, 0xca, 0x8d, 0x6c, 0x1d, 0xdd, 0x0a, 0x06, 0x1c, 0x99, 0x79, 0x96,
    0xa7, 0xa7, 0x7e, 0x8d, 0x6b, 0x94, 0x19, 0xca, 0x0f, 0xb3, 0xa1, 0xb4,
    0x09, 0x43, 0x98, 0xf8, 0x61, 0x8b, 0xac, 0x9d, 0xa1, 0xb5, 0x8e, 0x88,
    0x39, 0xb5, 0x72, 0x0e, 0x22, 0xf3, 0xd8, 0xc2, 0xc2, 0x02, 0xbd, 0x24,
    0xa2, 0x68, 0xf6, 0xe3, 0x50, 0xc4, 0x94, 0x39, 0xb2, 0xd0, 0x62, 0x5d,
    0x69, 0x84, 0x4a, 0xa9, 0x42, 0x42, 0x0c, 0x02, 0x96, 0xc2, 0x26, 0x25,
    0xab, 0x9f, 0x2d, 0xe5, 0x71, 0xb6, 0x55, 0x27, 0xa8, 0x79, 0xb5, 0x7f,
    0x23, 0x82, 0x90, 0xc8, 0x8f, 0x50, 0xa8, 0x17, 0xf1, 0x98, 0x5d, 0xf9,
    0x07, 0xd2, 0x3c, 0x10, 0x34, 0xba, 0xf7, 0x97, 0xdb, 0x31, 0xb5, 0xea,
    0x20, 0x96, 0x36, 0x08, 0x45, 0x88, 0x4d, 0x81, 0x6e, 0x7f, 0x97, 0x3f,
    0xb6, 0x9e, 0xe7, 0xa2, 0x31, 0x41, 0x98, 0x84, 0xcc, 0xf7, 0x16, 0xd9,
    0x5e, 0xbb, 0x8a, 0xd1, 0xe2, 0x06, 0x4a, 0x76, 0x89, 0x20, 0x0d, 0x68,
    0x47, 0x6d, 0xfc, 0x37, 0x7d, 0xe2, 0x28, 0x06, 0xc5, 0x21, 0xbd, 0x4f,
    0xa7, 0x2b, 0x04, 0x51, 0xc9, 0x79, 0x49, 0x04, 0xd9, 0x9f, 0xda, 0x97,
    0x83, 0x5b, 0xaa, 0xe5, 0x1a, 0x55, 0xb7, 0x46, 0xbf, 0xeb, 0x30, 0x28,
    0x53, 0x42, 0xaf, 0xc7, 0xe5, 0xde, 0x5b, 0x5c, 0xee, 0xd6, 0xb1, 0x0c,
    0x87, 0xad, 0xfd, 0x57, 0x50, 0x71, 0x2a, 0xd8, 0x86, 0x43, 0x90, 0x04,
    0x2c, 0x44, 0x8b, 0xd4, 0xcf, 0xd7, 0x69, 0xd7, 0xdb, 0x64, 0x32, 0x9b,
    0xc4, 0xe0, 0xd0, 0xaa, 0xbb, 0x68, 0xcb, 0x8f, 0x46, 0x3e, 0xee, 0x0a,
    0xfb, 0x85, 0xe1, 0x0f, 0xac, 0xcf, 0x8d, 0x8d, 0x6f, 0x61, 0x38, 0x3f,
    0x42, 0xc1, 0x2a, 0x62, 0x19, 0x16, 0x60, 0x20, 0x34, 0x08, 0x61, 0x22,
    0x04, 0x24, 0x32, 0xa5, 0x19, 0x35, 0xb8, 0xd8, 0x9a, 0xe1, 0xfc, 0x99,
    0xf3, 0xcc, 0x9e, 0x9b, 0xa5, 0xdd, 0x69, 0x47, 0x32, 0x93, 0x77, 0xea,
    0x7d, 0xfa, 0xc5, 0x55, 0x05, 0x00, 0x63, 0x8f, 0x0d, 0x7e, 0xdb, 0x76,
    0xdd, 0x1f, 0x8e, 0x8c, 0xaf, 0x67, 0xe3, 0x96, 0x31, 0x86, 0x2a, 0xc3,
    0x54, 0xdc, 0x3e, 0x5c, 0xd3, 0x05, 0x20, 0x95, 0x29, 0x41, 0xda, 0xa5,
    0x11, 0x2c, 0x31, 0x5b, 0x9f, 0x65, 0x66, 0x7a, 0x86, 0xf9, 0xd9, 0x79,
    0x3a, 0x61, 0x87, 0x2c, 0xcb, 0x1e, 0xd1, 0x7b, 0xf5, 0x93, 0xef, 0xe4,
    0xad, 0x7a, 0x0f, 0x86, 0x1e, 0x1d, 0x78, 0xc2, 0xb1, 0xad, 0xef, 0xf5,
    0xf5, 0x0f, 0x50, 0x1b, 0x1d, 0xa4, 0xaf, 0x5a, 0xc1, 0x73, 0xf2, 0x20,
    0x20, 0x8c, 0x42, 0xda, 0xad, 0x65, 0x1a, 0x8b, 0x0d, 0x96, 0xea, 0x4b,
    0xb4, 0x82, 0x16, 0x71, 0x12, 0x07, 0x52, 0xcb, 0x87, 0xf4, 0xcf, 0xf5,
    0xaf, 0xde, 0xcd, 0x5a, 0xf3, 0xa2, 0x95, 0x1f, 0x2e, 0xdc, 0x61, 0x0a,
    0xe3, 0x51, 0xdb, 0x70, 0xaf, 0xf7, 0x72, 0x1e, 0x96, 0x6b, 0xa3, 0x81,
    0x24, 0x4e, 0x88, 0xc3, 0x98, 0x5e, 0x12, 0x92, 0x66, 0x89, 0x94, 0x4a,
    0x1e, 0x50, 0x52, 0xfd, 0x44, 0xef, 0xd3, 0xc7, 0x57, 0xe3, 0xac, 0x29,
    0x00, 0x10, 0x9f, 0x12, 0x25, 0x77, 0xa3, 0x7b, 0x83, 0x21, 0x8c, 0xaf,
    0x08, 0xc4, 0xb5, 0x1a, 0xd6, 0x4b, 0x2d, 0xb3, 0x4c, 0xa6, 0x53, 0x4a,
    0xaa, 0xa3, 0xc0, 0x7e, 0xbd, 0x57, 0x1f, 0x5b, 0x13, 0xf0, 0x5e, 0x82,
    0xff, 0x47, 0xfc, 0x0b, 0x17, 0x34, 0xa3, 0x4f, 0xde, 0x9e, 0x34, 0x7c,
    0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image2_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xe0, 0x77, 0x3d, 0xf8, 0x00, 0x00, 0x05,
    0x0b, 0x49, 0x44, 0x41, 0x54, 0x48, 0x89, 0xb5, 0x95, 0x5b, 0x88, 0x9d,
    0xd5, 0x15, 0xc7, 0x7f, 0xfb, 0xbb, 0x9d, 0xeb, 0x77, 0x66, 0x32, 0x99,
    0x64, 0x26, 0x19, 0x27, 0x97, 0x99, 0x09, 0x2a, 0xd1, 0x4a, 0x11, 0x6b,
    0x2d, 0x98, 0xde, 0x6b, 0x0c, 0x58, 0x28, 0xed, 0x83, 0x88, 0x35, 0xa8,
    0x6d, 0x05, 0x8b, 0x84, 0x46, 0x6c, 0x94, 0xd2, 0xca, 0x58, 0x28, 0x14,
    0xa9, 0x29, 0xfa, 0xd0, 0x5a, 0xad, 0xd2, 0xa6, 0x56, 0x21, 0x96, 0x22,
    0x29, 0x45, 0x2a, 0xc5, 0x42, 0xa1, 0xa1, 0xc4, 0x4b, 0x13, 0x4d, 0x66,
    0x26, 0x4d, 0x34, 0x26, 0x99, 0xcb, 0x99, 0x73, 0x72, 0x72, 0x26, 0xe7,
    0xf2, 0x9d, 0xef, 0xdb, 0x97, 0xd5, 0x87, 0x56, 0x71, 0x24, 0x53, 0xfb,
    0x50, 0x17, 0xec, 0xb7, 0xbd, 0xfe, 0xbf, 0xbd, 0xd6, 0x5e, 0xfc, 0x97,
    0x12, 0x11, 0x3e, 0xca, 0xf0, 0x3e, 0x52, 0x75, 0x20, 0xf8, 0xb0, 0x0b,
    0x4f, 0x2a, 0x35, 0xd4, 0x0f, 0x5f, 0x28, 0xc1, 0xcd, 0x02, 0x9f, 0x74,
    0x30, 0xd8, 0x03, 0xba, 0xf0, 0xb7, 0x2e, 0xbc, 0x9c, 0xc2, 0xbe, 0x5d,
    0x22, 0x33, 0x2b, 0xe5, 0xab, 0x95, 0x5a, 0xb4, 0x5f, 0x29, 0x3f, 0x86,
    0x6f, 0xf7, 0xf9, 0xec, 0x8a, 0x3f, 0xf1, 0xb1, 0xb1, 0xe2, 0xc4, 0x18,
    0x61, 0x25, 0x26, 0x30, 0x3d, 0x5a, 0xa7, 0xce, 0x70, 0x7e, 0xe6, 0x24,
    0x8b, 0xf3, 0x0d, 0x16, 0x52, 0xd7, 0x4c, 0x90, 0x5f, 0xe4, 0xe1, 0xe1,
    0x6f, 0x89, 0xd4, 0xff, 0x27, 0xc0, 0x1f, 0x94, 0x1a, 0xec, 0x87, 0x7d,
    0xc3, 0xdb, 0xaf, 0xdf, 0xbe, 0xee, 0xee, 0xbb, 0x29, 0x8e, 0x6d, 0xc4,
    0x2e, 0x9c, 0xc5, 0xcc, 0xcf, 0x61, 0x6a, 0x8b, 0x48, 0xd2, 0x45, 0x19,
    0x4d, 0xfb, 0x8d, 0x63, 0x9c, 0x3a, 0xf8, 0x3a, 0x27, 0x6a, 0x2d, 0x6a,
    0x99, 0x3d, 0x26, 0x70, 0xcb, 0x6e, 0x91, 0xc3, 0xff, 0x15, 0xf0, 0x8c,
    0x52, 0x95, 0xcd, 0x70, 0x60, 0xfc, 0x81, 0x5d, 0xdb, 0x86, 0xee, 0xdb,
    0x83, 0xbc, 0x79, 0x10, 0xfd, 0xa7, 0xfd, 0xe8, 0xb9, 0x59, 0x6c, 0xab,
    0x83, 0xee, 0x6a, 0xac, 0x55, 0x68, 0xf1, 0x51, 0x03, 0x83, 0xd0, 0x4d,
    0x58, 0x3c, 0x3c, 0xcd, 0x91, 0xd9, 0x26, 0x55, 0x6d, 0xdf, 0x76, 0xc8,
    0x67, 0xf6, 0x88, 0x9c, 0xbe, 0x28, 0xe0, 0xa0, 0x52, 0x85, 0x0e, 0x3c,
    0x7f, 0xf9, 0x3d, 0x77, 0xec, 0x18, 0xf9, 0xde, 0xf7, 0x91, 0xdf, 0x3d,
    0x86, 0x9a, 0x3e, 0x84, 0xb3, 0x8a, 0x5e, 0x5b, 0xa3, 0x7b, 0x1a, 0xa5,
    0x2d, 0xa6, 0x9b, 0xd1, 0x6d, 0xf5, 0x48, 0xda, 0x09, 0xae, 0x10, 0x63,
    0x8d, 0xa5, 0xf9, 0x4e, 0x95, 0x7f, 0x34, 0xba, 0x5c, 0x70, 0xee, 0x8f,
    0x39, 0xe4, 0x6b, 0xdf, 0x11, 0x49, 0xe0, 0x03, 0x53, 0x34, 0x07, 0x5f,
    0x5d, 0x7b, 0xcd, 0x15, 0x3b, 0x86, 0xbf, 0x71, 0x27, 0xfa, 0x97, 0x3f,
    0x44, 0x1d, 0x3d, 0xc8, 0xd9, 0xd3, 0x4d, 0x4e, 0xfc, 0xb3, 0x06, 0xce,
    0x12, 0xfa, 0x8a, 0x33, 0xa7, 0xeb, 0x9c, 0x99, 0x6b, 0x82, 0x35, 0x28,
    0x14, 0xbd, 0x5a, 0x83, 0x4e, 0xb3, 0x45, 0x50, 0x08, 0xd9, 0x90, 0xf3,
    0x01, 0xb5, 0x23, 0xc5, 0xdf, 0xfe, 0xae, 0xe6, 0x7b, 0x80, 0x49, 0xa5,
    0xca, 0x15, 0x4f, 0xed, 0x1e, 0xb9, 0xf5, 0x66, 0xdc, 0xab, 0x7f, 0x41,
    0x8e, 0xbf, 0xc1, 0xc9, 0xa9, 0x2a, 0xd3, 0x7a, 0x84, 0x81, 0x87, 0x7f,
    0x4b, 0x76, 0xdd, 0x4d, 0x4c, 0xbd, 0x32, 0xc3, 0x09, 0x56, 0xb3, 0xe1,
    0xa9, 0xe7, 0x90, 0x2f, 0x7d, 0x05, 0xdb, 0xcb, 0xb0, 0xc6, 0x90, 0xf5,
    0x32, 0x92, 0x54, 0x53, 0x09, 0x03, 0xca, 0xbe, 0x87, 0x56, 0xee, 0xeb,
    0x93, 0x4a, 0x05, 0xf0, 0xbe, 0x31, 0x1d, 0x85, 0xcf, 0x55, 0x2e, 0xdd,
    0xf4, 0xf1, 0x78, 0x68, 0x15, 0xd9, 0x9f, 0x7f, 0x8f, 0xe9, 0xa4, 0xcc,
    0xc6, 0x5b, 0xb8, 0xf6, 0xe7, 0x4f, 0x13, 0xaf, 0x1b, 0xc2, 0x6e, 0xde,
    0x40, 0xd4, 0x14, 0x3e, 0x7b, 0xe3, 0x17, 0xa9, 0x6c, 0xbd, 0x8c, 0xfe,
    0x8d, 0xa3, 0xcc, 0xe7, 0x0b, 0xb4, 0x9e, 0x7c, 0x02, 0x9b, 0x69, 0x0c,
    0x3e, 0x91, 0x2f, 0xac, 0x0a, 0x3c, 0xce, 0xa5, 0xee, 0x06, 0x8d, 0x0c,
    0x01, 0xb3, 0xef, 0x55, 0x50, 0x82, 0x9d, 0xe5, 0x89, 0x31, 0xcc, 0xf1,
    0xa3, 0xe8, 0x85, 0x2a, 0x2e, 0xb5, 0x4c, 0x6c, 0xdd, 0x44, 0xbc, 0xba,
    0x0f, 0xd2, 0x2e, 0x3e, 0xc2, 0x95, 0xf7, 0xdf, 0x47, 0x65, 0x62, 0x1c,
    0x16, 0x6b, 0x28, 0x05, 0xeb, 0x6f, 0xdf, 0x49, 0x30, 0xbc, 0x1e, 0xad,
    0x0d, 0x12, 0x85, 0x04, 0x51, 0x48, 0x39, 0xf0, 0x71, 0x9e, 0x2a, 0x86,
    0x70, 0xf5, 0xb2, 0x16, 0x29, 0xb8, 0x26, 0x2a, 0xe6, 0xd0, 0xe7, 0xea,
    0xe8, 0x4e, 0x82, 0xa8, 0x80, 0xe2, 0x91, 0xbf, 0x32, 0xfd, 0xdd, 0x7b,
    0xc8, 0x9a, 0x0d, 0xc0, 0x42, 0xa3, 0x0e, 0x9d, 0x36, 0xf8, 0x0a, 0xbb,
    0xb4, 0xc4, 0xec, 0x23, 0x7b, 0x69, 0x9d, 0x7a, 0x07, 0x29, 0x14, 0xf0,
    0xf3, 0x11, 0x5e, 0x2e, 0x87, 0x1f, 0xf8, 0xa0, 0x14, 0x16, 0xfa, 0x97,
    0xb5, 0x48, 0x60, 0x34, 0xcc, 0x12, 0x4c, 0xd3, 0x61, 0x33, 0x87, 0xaf,
    0x1d, 0x6f, 0x9d, 0x5c, 0x60, 0x76, 0xe1, 0x15, 0x46, 0x97, 0x9a, 0x44,
    0xd1, 0x20, 0x18, 0x0d, 0xd6, 0x40, 0x14, 0x92, 0x4c, 0x1d, 0xe5, 0xed,
    0x5f, 0xff, 0x86, 0x0c, 0x0f, 0xaf, 0x94, 0x27, 0x2a, 0xe6, 0x08, 0x55,
    0x06, 0xbe, 0x8f, 0xa0, 0x00, 0xdc, 0xb2, 0x0a, 0x0c, 0x48, 0x52, 0x6f,
    0xe0, 0x9a, 0x4b, 0x88, 0x85, 0x6e, 0xa3, 0x45, 0x7d, 0xd5, 0x46, 0xb6,
    0x3d, 0xf1, 0x38, 0xa5, 0xb5, 0x83, 0xff, 0x7e, 0xb9, 0x35, 0x20, 0x06,
    0xda, 0x2d, 0x8a, 0x57, 0x5d, 0xc5, 0xc8, 0xee, 0x7b, 0xa1, 0x1c, 0x13,
    0x14, 0x72, 0xe4, 0x4b, 0x45, 0xfc, 0x28, 0x24, 0xf3, 0x14, 0x88, 0xa0,
    0xa0, 0xb5, 0x0c, 0x90, 0xc2, 0x54, 0xa7, 0xd9, 0xc2, 0x25, 0x09, 0x16,
    0x1f, 0xa7, 0x0d, 0x63, 0x97, 0x8f, 0x53, 0x19, 0x59, 0x0b, 0xed, 0x0b,
    0xe0, 0x2c, 0x28, 0x01, 0x63, 0x40, 0x09, 0x9e, 0xd6, 0x6c, 0xfe, 0xe6,
    0x1d, 0x8c, 0xdd, 0x7e, 0x1b, 0x85, 0x4a, 0x91, 0x5c, 0x3e, 0x07, 0x40,
    0xc3, 0x0a, 0x88, 0xf4, 0x1c, 0x1c, 0x59, 0x06, 0xe8, 0xc2, 0xa1, 0xc6,
    0xb9, 0x26, 0x68, 0x8b, 0xe4, 0xf3, 0x48, 0xb9, 0x0f, 0x79, 0xed, 0xef,
    0x9c, 0x79, 0xec, 0x51, 0xc8, 0x45, 0xa0, 0x1c, 0xa7, 0xf7, 0xee, 0xe5,
    0xad, 0xa7, 0x7e, 0x85, 0xf3, 0x03, 0xc8, 0xe5, 0xb0, 0xb5, 0x1a, 0xb4,
    0xce, 0x53, 0xea, 0x8f, 0x09, 0x45, 0xe8, 0xf4, 0x34, 0xf5, 0x54, 0xe3,
    0x0b, 0x2f, 0x2d, 0xc2, 0xd9, 0x65, 0x7f, 0x60, 0x83, 0xe0, 0xd9, 0xc5,
    0x76, 0x6f, 0xe7, 0x85, 0x4e, 0x4a, 0x79, 0xb0, 0x0f, 0xa3, 0x3c, 0x3c,
    0xdf, 0xa7, 0xf5, 0xe2, 0x01, 0x6a, 0x7d, 0x31, 0x69, 0xa3, 0xc1, 0xdc,
    0xfe, 0xfd, 0x64, 0xca, 0xa7, 0x34, 0x31, 0xce, 0x9a, 0xeb, 0xae, 0x65,
    0xfe, 0xb9, 0x67, 0x48, 0x8f, 0x1f, 0x23, 0x1f, 0x86, 0x64, 0x9d, 0x26,
    0x33, 0xad, 0x2e, 0x69, 0xa6, 0x71, 0xf0, 0xc2, 0xe3, 0x22, 0x7a, 0x99,
    0x55, 0xec, 0x55, 0xaa, 0x10, 0x15, 0xf2, 0x07, 0xb6, 0x0c, 0x0f, 0x7c,
    0xfe, 0xca, 0x2d, 0xeb, 0x91, 0xbe, 0x18, 0x17, 0x04, 0x98, 0x4c, 0x93,
    0x75, 0x13, 0xb4, 0xb1, 0x48, 0x10, 0xa2, 0x7c, 0x1f, 0xbf, 0x54, 0xa0,
    0xb4, 0x6e, 0x18, 0xdb, 0xa8, 0xe3, 0x65, 0x0e, 0x57, 0xad, 0x73, 0xf8,
    0xd4, 0x02, 0x6f, 0x56, 0x1b, 0x98, 0x44, 0x4f, 0x21, 0x66, 0xdb, 0x83,
    0xff, 0x71, 0xd6, 0x65, 0x5e, 0xf4, 0xb3, 0x38, 0xfe, 0xb4, 0xe7, 0x7b,
    0x2f, 0x6e, 0x1d, 0x5d, 0x93, 0x1f, 0xdf, 0x34, 0x84, 0x1a, 0xe8, 0x47,
    0x15, 0x22, 0xc4, 0xf3, 0x71, 0x4a, 0xc1, 0xbb, 0x07, 0x41, 0xd2, 0x0c,
    0x69, 0xf7, 0x48, 0xe6, 0xeb, 0x4c, 0xcd, 0xd6, 0x98, 0xa9, 0x9e, 0xa7,
    0xdb, 0x49, 0x7a, 0xce, 0x9a, 0x2f, 0x4f, 0x8a, 0xbc, 0x74, 0x51, 0xb3,
    0x03, 0x78, 0xb4, 0x5c, 0x7e, 0x20, 0x0c, 0x83, 0x1f, 0x6d, 0x59, 0xbf,
    0x9a, 0xf1, 0x4b, 0xd6, 0x50, 0x58, 0xdd, 0x47, 0x58, 0x2a, 0x42, 0x14,
    0x20, 0x4a, 0x21, 0xc6, 0x62, 0xba, 0x09, 0x69, 0xb3, 0xcd, 0x62, 0xb5,
    0xc9, 0x4c, 0xf5, 0x1c, 0xb3, 0x8d, 0x0b, 0x64, 0x49, 0x0f, 0x31, 0xee,
    0xde, 0x07, 0xc5, 0x3e, 0xf2, 0x7e, 0xbd, 0x8b, 0xee, 0x83, 0x9f, 0x14,
    0x0a, 0x93, 0x7e, 0x14, 0xfe, 0x60, 0xa0, 0x52, 0xe2, 0x92, 0xc1, 0x3e,
    0x56, 0xc5, 0x25, 0xa2, 0x42, 0x84, 0x12, 0x48, 0xb3, 0x8c, 0x66, 0x27,
    0x61, 0x71, 0xa9, 0xcb, 0xfc, 0xf9, 0x16, 0x9d, 0x76, 0x82, 0xcd, 0x74,
    0xcb, 0x3a, 0xb3, 0x6b, 0x52, 0xe4, 0xe9, 0x0f, 0x6a, 0xad, 0xb8, 0xd1,
    0x7e, 0x9c, 0xcf, 0xdf, 0x84, 0x52, 0xf7, 0xab, 0x30, 0xf8, 0x54, 0x2e,
    0x9f, 0x23, 0x17, 0xfa, 0x28, 0xa0, 0x67, 0x2c, 0x49, 0xa6, 0xb1, 0xbd,
    0x0c, 0xa7, 0x8d, 0x75, 0x22, 0xcf, 0x5a, 0x67, 0x7f, 0xfa, 0x90, 0xc8,
    0xab, 0x17, 0xd3, 0x59, 0x11, 0x00, 0xb0, 0x47, 0xa9, 0x38, 0xf6, 0x73,
    0xd7, 0x7b, 0x81, 0x77, 0x97, 0x28, 0xb9, 0x5a, 0x60, 0x44, 0x9c, 0x33,
    0x62, 0xcc, 0xb4, 0x38, 0x5e, 0xb6, 0xb8, 0x7d, 0x0f, 0x89, 0x1c, 0x5a,
    0x51, 0xe0, 0xc3, 0x00, 0xff, 0x8f, 0xf8, 0x17, 0xd4, 0xb8, 0x9b, 0x4e,
    0x48, 0x0a, 0x2c, 0x0e, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44,
    0xae, 0x42, 0x60, 0x82
};

static const unsigned char image3_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xe0, 0x77, 0x3d, 0xf8, 0x00, 0x00, 0x05,
    0xb2, 0x49, 0x44, 0x41, 0x54, 0x48, 0x89, 0xb5, 0x96, 0x4b, 0x6c, 0x94,
    0xd7, 0x15, 0xc7, 0x7f, 0xf7, 0x7b, 0xcc, 0xc3, 0xf3, 0xf6, 0xd8, 0xe3,
    0x37, 0x9e, 0x9a, 0x30, 0x09, 0x71, 0x90, 0x93, 0x88, 0x87, 0x1b, 0x5c,
    0xe4, 0xd0, 0x20, 0xdc, 0x45, 0x1a, 0x42, 0x85, 0x23, 0x45, 0xea, 0x06,
    0xa9, 0x8d, 0x22, 0xa7, 0xab, 0xa8, 0x2a, 0x52, 0xab, 0x3a, 0x6c, 0x2a,
    0x75, 0x91, 0x45, 0x70, 0x93, 0xd4, 0xad, 0xd4, 0x2a, 0x52, 0xa5, 0xbe,
    0x5c, 0x54, 0xa0, 0x0d, 0x48, 0x05, 0xc5, 0x94, 0x12, 0x07, 0x13, 0x70,
    0x69, 0x82, 0x0b, 0x4c, 0x3c, 0xc6, 0x8c, 0x1f, 0x63, 0x63, 0x7b, 0xc6,
    0xe3, 0x79, 0x7d, 0xf3, 0x3d, 0x6e, 0x17, 0x8d, 0xac, 0x10, 0xb7, 0x4b,
    0xce, 0xf6, 0xde, 0x7b, 0x7e, 0xfa, 0xdf, 0xff, 0x39, 0xe7, 0x5e, 0x21,
    0xa5, 0xe4, 0x61, 0x86, 0xf2, 0x50, 0xb3, 0x03, 0xda, 0xff, 0x5b, 0xe8,
    0xef, 0xef, 0x57, 0x7d, 0xbe, 0x4e, 0x3d, 0x9f, 0xd7, 0x23, 0xa5, 0x92,
    0x59, 0xaf, 0xeb, 0x6a, 0x87, 0xe3, 0x28, 0xb5, 0x00, 0x9a, 0x26, 0x8b,
    0x96, 0x65, 0x7c, 0xa6, 0x69, 0xce, 0x92, 0xe3, 0xe8, 0x2b, 0x67, 0xce,
    0xdc, 0x34, 0xa4, 0xfc, 0x83, 0xfd, 0xbf, 0xf2, 0x88, 0x2f, 0x5e, 0x51,
    0x7f, 0xff, 0x1f, 0xd5, 0xd6, 0x56, 0x42, 0x6e, 0xb7, 0xb3, 0x73, 0x75,
    0x75, 0x65, 0x17, 0x28, 0xbb, 0x63, 0xb1, 0xda, 0x27, 0x43, 0xa1, 0x9a,
    0x2d, 0x81, 0x80, 0x07, 0x9f, 0x4f, 0xc7, 0xb2, 0x2c, 0x0a, 0x05, 0x93,
    0x6c, 0xb6, 0x48, 0x3e, 0xbf, 0x7e, 0x7f, 0x69, 0x29, 0x7b, 0xb5, 0x5a,
    0xad, 0x5e, 0x0e, 0x06, 0x6b, 0x3e, 0xb6, 0x6d, 0xeb, 0xe3, 0xb6, 0xb6,
    0x7c, 0x6e, 0x70, 0x70, 0xd0, 0xd9, 0x04, 0x38, 0x7e, 0xfc, 0xb7, 0x75,
    0x85, 0x82, 0x78, 0xd1, 0x30, 0xca, 0x47, 0x81, 0xee, 0x44, 0x62, 0x2b,
    0x1d, 0x1d, 0x8d, 0x34, 0x35, 0x45, 0x69, 0x69, 0x89, 0x10, 0x8d, 0x2a,
    0xa8, 0xea, 0x7f, 0x0f, 0x99, 0x26, 0x2c, 0x2c, 0x54, 0x99, 0x9f, 0xcf,
    0xb1, 0xbc, 0x9c, 0xa3, 0xb0, 0x9e, 0x65, 0xec, 0xa3, 0x4f, 0x58, 0xcd,
    0xad, 0x7d, 0xa4, 0x6a, 0xfc, 0xcc, 0xad, 0x59, 0x7f, 0x19, 0x1e, 0xfe,
    0xc1, 0x1a, 0x7c, 0xee, 0xc1, 0xb1, 0x63, 0xbf, 0xef, 0x32, 0x0c, 0xf1,
    0xbb, 0x50, 0xc8, 0xf7, 0x8b, 0x44, 0xa2, 0xad, 0x5b, 0xd3, 0x20, 0x1e,
    0x6f, 0x67, 0xdf, 0xbe, 0x04, 0x0d, 0x61, 0x8d, 0xdc, 0xb5, 0xf3, 0xac,
    0x2c, 0xe4, 0x99, 0xbe, 0x34, 0xc6, 0x99, 0xbe, 0x6d, 0xa4, 0xc7, 0xc6,
    0xd0, 0x65, 0x05, 0xff, 0xe2, 0x3f, 0x39, 0xd8, 0xdb, 0x40, 0xef, 0x73,
    0xdb, 0x89, 0x04, 0x83, 0x6c, 0x6b, 0x6d, 0xeb, 0x0e, 0xf8, 0xfc, 0xbf,
    0xb1, 0x6d, 0xf7, 0xf0, 0x2b, 0xaf, 0xbc, 0x59, 0xb7, 0x01, 0xb0, 0x6d,
    0x73, 0x48, 0x51, 0xf4, 0xaf, 0x1f, 0x38, 0xb0, 0x8b, 0xd7, 0x5e, 0x7b,
    0x8e, 0x9d, 0x3b, 0xb7, 0x72, 0xfa, 0xf4, 0x05, 0x92, 0xc9, 0x0a, 0x8b,
    0x57, 0xff, 0xc1, 0xed, 0xb7, 0x06, 0x98, 0x39, 0x3b, 0x82, 0x21, 0xfd,
    0x78, 0x9a, 0x13, 0x94, 0x6d, 0x3f, 0xd3, 0xef, 0x8f, 0x30, 0xfd, 0xee,
    0x00, 0x0b, 0xe3, 0x7f, 0xe7, 0xdd, 0x5f, 0x9e, 0xe3, 0x91, 0x48, 0x03,
    0xc7, 0xbe, 0xdd, 0xcf, 0xc1, 0x3d, 0xdd, 0x28, 0xaa, 0xfa, 0x92, 0x61,
    0x38, 0x47, 0x36, 0x4c, 0xb6, 0xed, 0xea, 0x29, 0x21, 0xbc, 0x3d, 0x4d,
    0x4d, 0x7e, 0x51, 0x2c, 0x42, 0x34, 0xba, 0x15, 0x29, 0x27, 0xb9, 0x78,
    0x71, 0x9c, 0x43, 0xdf, 0xf8, 0x1a, 0xe2, 0xbb, 0x6f, 0x13, 0x4e, 0x74,
    0xe1, 0x6b, 0x68, 0xc0, 0xff, 0xe3, 0x11, 0x6c, 0xe1, 0xc5, 0xd4, 0x63,
    0xb4, 0x3f, 0xd1, 0x4a, 0xb2, 0x1c, 0x25, 0x9d, 0xfc, 0x90, 0xa7, 0xf6,
    0x76, 0xa0, 0x9a, 0x92, 0xc7, 0xea, 0x1b, 0x39, 0x05, 0x96, 0x6d, 0x5b,
    0x73, 0x1b, 0x0a, 0x26, 0x26, 0xd2, 0x6f, 0x15, 0x0a, 0x6b, 0x7f, 0xbb,
    0x72, 0x25, 0xc9, 0xbd, 0x7b, 0x36, 0xa6, 0xe9, 0x22, 0x91, 0xd8, 0xca,
    0xe4, 0xe4, 0x24, 0x96, 0x2a, 0xd8, 0xf1, 0xc2, 0x7e, 0x94, 0xa0, 0x46,
    0xa1, 0xb0, 0x44, 0xd5, 0x29, 0x60, 0x59, 0xab, 0xb4, 0x77, 0xd6, 0x11,
    0x7c, 0xb2, 0x87, 0xbf, 0x7e, 0x70, 0x93, 0xc7, 0xdb, 0xe3, 0xd4, 0x06,
    0x03, 0xcc, 0x2d, 0xe5, 0x38, 0x7f, 0x63, 0x82, 0x4a, 0xa9, 0x7c, 0x45,
    0x08, 0xfd, 0xc2, 0x03, 0x26, 0x0f, 0x0c, 0xbc, 0xf3, 0x4c, 0x24, 0x52,
    0x7f, 0xe1, 0xf9, 0xe7, 0x7b, 0x3d, 0xc5, 0x22, 0x64, 0x32, 0x2b, 0x5c,
    0xba, 0x74, 0x91, 0x96, 0x96, 0x10, 0xf1, 0x78, 0x1b, 0xa9, 0xd4, 0x22,
    0xa6, 0x69, 0x22, 0xa5, 0xc4, 0xe5, 0xd2, 0xe9, 0xe8, 0x88, 0x71, 0x37,
    0xbd, 0xc4, 0xcc, 0xd4, 0x22, 0x87, 0xf6, 0x3e, 0xc3, 0xf6, 0xd6, 0x16,
    0x16, 0x0b, 0x39, 0x7e, 0x75, 0xf6, 0x2c, 0x55, 0xd3, 0x1c, 0x78, 0xef,
    0xd7, 0xaf, 0xbf, 0xb3, 0xa1, 0x00, 0x60, 0x72, 0xf2, 0xfe, 0x78, 0x3e,
    0x9f, 0x1f, 0x9d, 0x9c, 0x4c, 0x12, 0x0e, 0xbb, 0x50, 0x14, 0x85, 0x1d,
    0x3b, 0x3a, 0x59, 0x59, 0x71, 0x48, 0xa5, 0xf2, 0xf8, 0xfd, 0xb5, 0x84,
    0xc3, 0xf5, 0x04, 0x02, 0x11, 0x84, 0x70, 0x33, 0x71, 0x7d, 0x96, 0xf4,
    0xf4, 0x32, 0xbb, 0x1e, 0x4f, 0x10, 0xf6, 0xfb, 0xf0, 0xb8, 0x5d, 0x8c,
    0xdf, 0xb9, 0x8d, 0x65, 0x59, 0x6b, 0xe8, 0xe2, 0xfc, 0xa6, 0x46, 0x1b,
    0x1d, 0x1d, 0xb4, 0xb7, 0x6f, 0x1f, 0x3e, 0x95, 0x4e, 0xcf, 0xf7, 0x75,
    0x75, 0x3d, 0x8a, 0xdb, 0x2d, 0x08, 0x87, 0xeb, 0xe8, 0xe9, 0x69, 0x40,
    0xd7, 0x5d, 0x38, 0x8e, 0x85, 0x69, 0x9a, 0x98, 0x66, 0x95, 0xaa, 0x59,
    0xa5, 0xb9, 0xb9, 0x1e, 0xdd, 0x71, 0xa8, 0x75, 0x7b, 0xf1, 0x7b, 0xdc,
    0xe4, 0xcd, 0x32, 0x33, 0x99, 0x45, 0xa4, 0x63, 0x8f, 0x2b, 0x66, 0xe9,
    0xde, 0x26, 0x80, 0x94, 0xc8, 0xa3, 0x47, 0xad, 0x89, 0x62, 0xd1, 0xb0,
    0xd6, 0xd7, 0x0b, 0x5a, 0x6d, 0x6d, 0x0d, 0xb7, 0x6f, 0x67, 0x70, 0xb9,
    0x02, 0x64, 0x32, 0x8b, 0xcc, 0xce, 0xce, 0x53, 0x28, 0x94, 0x50, 0x55,
    0x05, 0x8f, 0x47, 0x27, 0x1c, 0xf6, 0xd1, 0x18, 0x0a, 0x53, 0x28, 0x19,
    0x84, 0xe3, 0x3e, 0xd2, 0xb9, 0x65, 0x4a, 0xe5, 0x32, 0x20, 0x6e, 0xba,
    0x5c, 0x4d, 0x1b, 0x5d, 0xfd, 0xc0, 0x2c, 0x52, 0x14, 0xbb, 0x68, 0x18,
    0xa6, 0x65, 0x18, 0x26, 0x91, 0x88, 0x1f, 0x45, 0x91, 0xdc, 0xfc, 0xf4,
    0xdf, 0x8c, 0x8e, 0x5e, 0xa4, 0x5c, 0xce, 0x11, 0x8d, 0x2a, 0xf8, 0xfd,
    0x92, 0xb5, 0xb5, 0x55, 0xc6, 0xc6, 0xae, 0x73, 0x6b, 0x6a, 0x1a, 0x0b,
    0x89, 0x3f, 0xe4, 0xc5, 0xb0, 0x0c, 0xaa, 0xa6, 0x89, 0xe5, 0xc8, 0xec,
    0x17, 0x73, 0x3e, 0x30, 0x8b, 0x6c, 0xdb, 0xd1, 0x40, 0xaa, 0x42, 0x08,
    0x5c, 0x6e, 0x17, 0xc9, 0x3b, 0x49, 0xd2, 0x73, 0xd3, 0x1c, 0x3e, 0xbc,
    0x8f, 0xfd, 0xfb, 0x9f, 0x06, 0x54, 0xf2, 0xf9, 0x32, 0xd5, 0x6a, 0x91,
    0xcb, 0x97, 0x27, 0x39, 0x7b, 0x6e, 0x1c, 0xab, 0x6a, 0xf3, 0xcd, 0x67,
    0x9f, 0x42, 0xd7, 0x75, 0x84, 0x10, 0x08, 0x29, 0xfd, 0xd9, 0xec, 0x82,
    0xd8, 0xa4, 0x40, 0x08, 0x84, 0xaa, 0x8a, 0x6d, 0x2e, 0xb7, 0xa6, 0xc5,
    0xea, 0xeb, 0x59, 0x48, 0x2f, 0xb2, 0x94, 0x99, 0xe7, 0xc8, 0x91, 0x3e,
    0x76, 0xef, 0xfe, 0x2a, 0xa3, 0xa3, 0x49, 0xa6, 0xa7, 0x4b, 0xf8, 0x7c,
    0x61, 0x02, 0x81, 0x16, 0x0e, 0x1d, 0x3a, 0xc0, 0x8b, 0x87, 0x9f, 0x65,
    0xf6, 0xfe, 0x02, 0x77, 0x17, 0x32, 0xc4, 0xdb, 0x1a, 0xf1, 0x7a, 0x3c,
    0x00, 0x6d, 0x9d, 0x9d, 0x38, 0x9b, 0x00, 0xbd, 0xbd, 0xc7, 0x55, 0x45,
    0xd1, 0x0f, 0xc6, 0xa2, 0x11, 0xd1, 0xd8, 0x14, 0x64, 0x76, 0x6a, 0x8e,
    0xe6, 0xd6, 0x66, 0xba, 0xba, 0x9e, 0x66, 0x64, 0x64, 0x94, 0xa1, 0xa1,
    0xf7, 0x38, 0x75, 0xfa, 0x02, 0x85, 0x42, 0x05, 0x29, 0x21, 0x9b, 0x85,
    0x3d, 0xbb, 0xbb, 0xa9, 0xab, 0x8b, 0xf1, 0x59, 0x6a, 0x96, 0xd6, 0xaf,
    0x44, 0x68, 0x8a, 0x45, 0x90, 0x52, 0xf6, 0x24, 0x93, 0xde, 0xc6, 0x4d,
    0x80, 0xb6, 0x47, 0x7c, 0x6d, 0x5e, 0xb7, 0xda, 0xd7, 0xd9, 0xf9, 0x18,
    0x4e, 0x19, 0xac, 0x75, 0x83, 0x70, 0x38, 0x04, 0x02, 0x66, 0x66, 0xee,
    0xb2, 0xb6, 0x96, 0x63, 0xf9, 0x7e, 0x86, 0x48, 0xd8, 0xa1, 0xb9, 0x19,
    0xfc, 0x7e, 0xf0, 0xf9, 0x14, 0xfc, 0xfe, 0x20, 0xf9, 0x6c, 0x09, 0x45,
    0x81, 0x9e, 0xee, 0x27, 0xd0, 0x75, 0xbd, 0x15, 0x9c, 0x97, 0x36, 0x01,
    0x3c, 0xc2, 0xb5, 0x47, 0xd5, 0xd4, 0x96, 0x1a, 0x4f, 0x0d, 0xc5, 0x55,
    0x03, 0x97, 0x84, 0x52, 0xd9, 0x20, 0x35, 0xb5, 0x88, 0xa2, 0x42, 0xbc,
    0x7d, 0x0b, 0x96, 0xe9, 0x30, 0x34, 0xf4, 0x67, 0xde, 0x3e, 0x71, 0x9a,
    0xd1, 0x0f, 0xae, 0x92, 0x4e, 0xe7, 0x11, 0xc2, 0xa1, 0x5a, 0x91, 0x14,
    0x96, 0xab, 0xd4, 0x78, 0x7d, 0x68, 0xba, 0x8a, 0x10, 0x7c, 0xe7, 0xe5,
    0x97, 0x7f, 0xd2, 0xf0, 0xe5, 0x32, 0x2d, 0x57, 0x0d, 0x93, 0x1b, 0xd7,
    0xff, 0x45, 0x25, 0x1e, 0xa7, 0x88, 0x45, 0x7a, 0x36, 0xcd, 0xc9, 0x93,
    0x27, 0x31, 0xcd, 0x2a, 0xf5, 0xb1, 0x28, 0x52, 0x4a, 0x52, 0xd3, 0x19,
    0x39, 0x25, 0xa5, 0xd0, 0xb4, 0x29, 0xbc, 0x97, 0xae, 0xe1, 0x58, 0x0e,
    0x1d, 0x8f, 0xd6, 0x72, 0x6d, 0x62, 0x9a, 0xf1, 0x5b, 0xb7, 0xa8, 0x1a,
    0x06, 0x42, 0x88, 0x2d, 0x9a, 0xe6, 0xaa, 0x79, 0x00, 0x60, 0xdb, 0xe2,
    0x43, 0x43, 0xb1, 0xce, 0xdd, 0x49, 0xa5, 0xfa, 0xe6, 0x33, 0x0b, 0x14,
    0x2a, 0x15, 0x1c, 0x9c, 0x39, 0xa3, 0x52, 0x79, 0x5f, 0x55, 0xd5, 0x4f,
    0x84, 0x60, 0xce, 0x71, 0xe4, 0xba, 0xa2, 0x60, 0xd9, 0xb6, 0x50, 0x6c,
    0xdb, 0x09, 0xad, 0x64, 0xb3, 0x7b, 0x6b, 0xdc, 0xee, 0x6f, 0x7d, 0x7a,
    0x37, 0xd9, 0x7e, 0x23, 0x75, 0x87, 0xec, 0x7a, 0xfe, 0xf3, 0x82, 0x11,
    0x3f, 0xf5, 0x78, 0x82, 0xb3, 0xf0, 0xa5, 0x17, 0xed, 0xd5, 0x57, 0x7f,
    0x1e, 0x33, 0xcc, 0xca, 0xf7, 0x91, 0xf2, 0x05, 0x09, 0x7f, 0x72, 0x69,
    0xce, 0x9b, 0xcd, 0xcd, 0x85, 0x1c, 0xe0, 0xbc, 0xf1, 0xc6, 0xa0, 0x94,
    0x92, 0x8d, 0xcd, 0x42, 0x20, 0x7a, 0x7b, 0x8f, 0xab, 0x81, 0x04, 0x2e,
    0x5f, 0x5e, 0xfb, 0xa1, 0x50, 0xc4, 0xeb, 0xaa, 0xaa, 0x56, 0x55, 0x45,
    0xfc, 0x28, 0x18, 0xf4, 0x0e, 0x9f, 0x38, 0xf1, 0x3d, 0x63, 0x13, 0xe0,
    0x61, 0xc4, 0x43, 0xff, 0x55, 0xfc, 0x07, 0x8d, 0x9e, 0x9d, 0xf5, 0x49,
    0x4e, 0x93, 0x0a, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae,
    0x42, 0x60, 0x82
};

static const unsigned char image4_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xe0, 0x77, 0x3d, 0xf8, 0x00, 0x00, 0x05,
    0x41, 0x49, 0x44, 0x41, 0x54, 0x48, 0x89, 0xb5, 0x95, 0x6d, 0x8c, 0x5c,
    0x55, 0x19, 0xc7, 0x7f, 0xf7, 0x7d, 0x5e, 0x76, 0x67, 0xf6, 0x65, 0xf6,
    0xbd, 0xdb, 0xed, 0xb6, 0x22, 0xda, 0x56, 0x93, 0x42, 0x8c, 0x58, 0x03,
    0x5a, 0x2d, 0x94, 0x94, 0xa0, 0x08, 0x58, 0xdf, 0xa2, 0x44, 0x43, 0xc0,
    0xc4, 0x18, 0x22, 0xc4, 0x84, 0x86, 0xb7, 0x00, 0x41, 0x63, 0x48, 0x40,
    0xa2, 0x12, 0x6d, 0x49, 0x48, 0x28, 0x64, 0x93, 0xc2, 0x97, 0x02, 0x25,
    0x25, 0xa0, 0x9b, 0x94, 0xa0, 0x26, 0xa0, 0x4b, 0x1b, 0x69, 0x77, 0x5b,
    0xb6, 0xb5, 0xb3, 0xbb, 0xdd, 0x69, 0xbb, 0xb3, 0x33, 0x77, 0xef, 0xcc,
    0xdc, 0x73, 0xef, 0xb9, 0xe7, 0x1e, 0x3e, 0x10, 0x09, 0x4b, 0x76, 0x85,
    0x0f, 0xf0, 0x7c, 0x3e, 0xe7, 0xf7, 0xcb, 0x79, 0xf2, 0xfc, 0xcf, 0x63,
    0x68, 0xad, 0xf9, 0x34, 0xcb, 0xfc, 0x54, 0xe9, 0x80, 0xfd, 0x51, 0x07,
    0xbe, 0xf0, 0x84, 0xd1, 0xe7, 0xe6, 0xdc, 0xed, 0xae, 0x9b, 0xf9, 0xbe,
    0x52, 0xc6, 0x65, 0x2a, 0x31, 0x4a, 0x4a, 0x00, 0xc2, 0xfa, 0x7b, 0x12,
    0x9a, 0xe3, 0x2d, 0x21, 0xf6, 0x9d, 0xba, 0x7b, 0x69, 0x6a, 0xb5, 0xfb,
    0xc6, 0x6a, 0x2d, 0xda, 0xf5, 0xec, 0x2e, 0x2b, 0xc8, 0x1f, 0xfe, 0x45,
    0xae, 0xad, 0xed, 0xb6, 0x75, 0x85, 0x4d, 0xeb, 0xfb, 0x73, 0xeb, 0xc9,
    0x39, 0x9d, 0x84, 0x46, 0x8b, 0x72, 0xed, 0xbf, 0x1c, 0x3d, 0x3b, 0xc1,
    0xfc, 0xb9, 0x0a, 0xd4, 0x9d, 0xba, 0x08, 0xd3, 0x3d, 0x49, 0x26, 0x79,
    0x78, 0xee, 0x8e, 0xa5, 0x85, 0x8f, 0x25, 0xd8, 0x36, 0x56, 0x28, 0x75,
    0x0e, 0x76, 0xed, 0xdb, 0x32, 0x70, 0xf9, 0xd5, 0x3b, 0x07, 0x7f, 0xc6,
    0x60, 0xdb, 0x06, 0xea, 0xba, 0x4a, 0x35, 0x3e, 0x47, 0x4d, 0x2e, 0x22,
    0x53, 0x85, 0x65, 0x7b, 0xbc, 0x3e, 0xf7, 0x37, 0x0e, 0xfe, 0xe7, 0x00,
    0x8d, 0x33, 0x2d, 0xa4, 0xaf, 0x8f, 0x85, 0x2a, 0xfd, 0x61, 0xed, 0x81,
    0xc6, 0x91, 0xff, 0x2b, 0xb8, 0xec, 0x19, 0xa3, 0x30, 0x38, 0xbc, 0xf6,
    0x85, 0xeb, 0x2f, 0xfa, 0xf9, 0x15, 0x37, 0x0e, 0xfc, 0x92, 0x93, 0xbc,
    0xc9, 0x78, 0x63, 0x3f, 0x73, 0x61, 0x99, 0x5a, 0xe8, 0xd3, 0x8c, 0x62,
    0x94, 0xb4, 0x30, 0x65, 0x86, 0x8b, 0x0b, 0x97, 0x10, 0xa8, 0x16, 0x07,
    0x8f, 0x3f, 0x4f, 0xed, 0x84, 0x8f, 0xaa, 0xa5, 0xa7, 0x9b, 0x8e, 0xfe,
    0x7a, 0xeb, 0xbe, 0x56, 0x79, 0x45, 0xc1, 0xae, 0x67, 0xb7, 0x66, 0x1b,
    0xc5, 0xf2, 0x73, 0xdf, 0xd9, 0x78, 0xf3, 0xce, 0x1f, 0xac, 0xf9, 0x15,
    0x87, 0xf4, 0x1f, 0x38, 0x9e, 0xfc, 0x83, 0x58, 0x40, 0x4b, 0x48, 0x5a,
    0x42, 0xd2, 0x8c, 0x63, 0x1a, 0xa1, 0xa0, 0x21, 0x42, 0xea, 0xa2, 0xc1,
    0x80, 0xbb, 0x01, 0x95, 0xc0, 0xbf, 0x67, 0x26, 0x10, 0x27, 0x62, 0xd2,
    0x86, 0x7a, 0xc9, 0x97, 0xf1, 0x8d, 0xfa, 0x11, 0x1d, 0xc2, 0x87, 0xa6,
    0x68, 0x2e, 0x99, 0xbc, 0xe1, 0xb3, 0xdd, 0x97, 0xec, 0xbc, 0x66, 0xcd,
    0x4f, 0x19, 0x13, 0x0f, 0x72, 0x34, 0x7a, 0x0d, 0x23, 0xf1, 0xd0, 0xa9,
    0x85, 0xd6, 0x06, 0x68, 0x20, 0x05, 0xdb, 0xb6, 0x08, 0xc3, 0x98, 0xea,
    0x49, 0xc1, 0x91, 0x33, 0x47, 0x98, 0x5d, 0x9a, 0x21, 0x97, 0x6d, 0x47,
    0xf5, 0xa6, 0xa4, 0xb0, 0x33, 0x6b, 0xb9, 0x57, 0xff, 0x8f, 0xf9, 0xbe,
    0x60, 0xf3, 0xfd, 0x46, 0x9b, 0x9d, 0xb3, 0x6f, 0xdf, 0xb1, 0xee, 0x47,
    0xbc, 0x15, 0x8d, 0xf3, 0x76, 0xeb, 0x4d, 0x74, 0xe4, 0x21, 0xa2, 0x84,
    0x58, 0x26, 0x24, 0x2a, 0x45, 0xa6, 0x0a, 0xc3, 0x32, 0x28, 0x9f, 0x9d,
    0xc7, 0x9c, 0x2c, 0xf1, 0xfc, 0x55, 0xe3, 0xbc, 0xba, 0xe3, 0x9f, 0x54,
    0x5b, 0x8b, 0x04, 0x22, 0xc0, 0xcc, 0xdb, 0xe8, 0x8c, 0x41, 0x2a, 0xd3,
    0x1f, 0x1b, 0xdb, 0x0c, 0x7b, 0x99, 0x20, 0xea, 0xe6, 0x1b, 0xeb, 0x8a,
    0x9b, 0xb7, 0x74, 0x16, 0x7a, 0x38, 0x5c, 0x7b, 0x11, 0x15, 0x9b, 0xb4,
    0xa2, 0x98, 0x56, 0x1c, 0x21, 0xe2, 0x98, 0x48, 0x26, 0x28, 0xad, 0xa9,
    0x05, 0x4b, 0x58, 0xa7, 0x4b, 0x3c, 0x75, 0xdd, 0x7e, 0x36, 0x0d, 0x6d,
    0x62, 0x51, 0x56, 0xd1, 0x1a, 0x4c, 0x2c, 0x2c, 0xcb, 0x86, 0x76, 0x13,
    0xad, 0xd8, 0xc1, 0x5a, 0xfa, 0xe0, 0x03, 0x39, 0xb0, 0x5d, 0xef, 0xa6,
    0x91, 0x8e, 0xcf, 0x33, 0x19, 0x4e, 0x30, 0xdb, 0x9c, 0x21, 0xef, 0x64,
    0x91, 0xa6, 0x20, 0x52, 0x02, 0x53, 0x3b, 0x28, 0x05, 0x91, 0x8e, 0x98,
    0x9c, 0x98, 0xe7, 0x4f, 0x5f, 0x1e, 0x63, 0xa4, 0x67, 0x2d, 0x00, 0x8f,
    0x9f, 0x78, 0x8c, 0x58, 0x49, 0xb2, 0x66, 0x01, 0xd3, 0x54, 0x24, 0x19,
    0x05, 0x5a, 0xe6, 0xf0, 0xb8, 0x14, 0x98, 0x7b, 0x5f, 0xa0, 0xb1, 0xbe,
    0xe4, 0xba, 0x59, 0xaa, 0xe1, 0x05, 0x96, 0x44, 0x80, 0x6d, 0x3a, 0x9c,
    0x9d, 0xf4, 0x19, 0xc8, 0x0f, 0xd1, 0xea, 0x5a, 0xc0, 0xb0, 0x0d, 0xa6,
    0xa6, 0xcb, 0x6c, 0x6f, 0xbb, 0x81, 0x2b, 0x37, 0x6f, 0x07, 0xe0, 0xe5,
    0xf9, 0x17, 0x78, 0x79, 0xee, 0x25, 0x32, 0x56, 0x9e, 0x9c, 0x9d, 0x47,
    0xea, 0x84, 0xc8, 0x96, 0xa0, 0x23, 0x50, 0x74, 0x2c, 0x6b, 0x91, 0xa1,
    0xcd, 0xe1, 0x06, 0x01, 0xbe, 0x08, 0x90, 0x32, 0x65, 0x7e, 0x71, 0x81,
    0x8b, 0xe3, 0xad, 0xfc, 0xee, 0x73, 0xfb, 0xd8, 0x66, 0x7d, 0x8f, 0x99,
    0xea, 0x3c, 0x6e, 0xa5, 0x87, 0xdd, 0xdb, 0xee, 0x06, 0xa0, 0x91, 0x34,
    0xf8, 0xe3, 0xd4, 0x63, 0x84, 0x49, 0x4c, 0xbb, 0x5d, 0xa4, 0xe8, 0x16,
    0xc9, 0x39, 0x79, 0x1c, 0x1c, 0x48, 0x01, 0x4d, 0xba, 0xac, 0x45, 0xa9,
    0x34, 0x75, 0x65, 0xa9, 0x62, 0x64, 0x4c, 0x0f, 0x19, 0x43, 0x53, 0x36,
    0xd9, 0xb4, 0x66, 0x23, 0xfd, 0xdd, 0x3d, 0xdc, 0xda, 0xf1, 0x6b, 0xa6,
    0xe6, 0xa6, 0xe9, 0x5d, 0x3b, 0xcc, 0x70, 0xf7, 0x1a, 0x00, 0xf6, 0x9f,
    0x79, 0x9a, 0xf1, 0xf9, 0x71, 0x06, 0x33, 0x23, 0x74, 0x78, 0x9d, 0xe4,
    0xdd, 0x02, 0x2a, 0xaa, 0x61, 0xc4, 0x26, 0x4a, 0xa7, 0x60, 0x11, 0x2c,
    0x13, 0xa8, 0xc8, 0x3c, 0xbe, 0x18, 0xd4, 0x36, 0xb6, 0xe5, 0xdb, 0x40,
    0xb9, 0x64, 0x1c, 0x93, 0xd7, 0xfc, 0x57, 0xf9, 0x49, 0x78, 0x0b, 0xb9,
    0x6c, 0x96, 0xdd, 0x5f, 0x79, 0x10, 0xc7, 0xb1, 0x90, 0xc4, 0x9c, 0x0c,
    0xa6, 0x78, 0xf4, 0xd8, 0xc3, 0x74, 0xb9, 0xbd, 0x74, 0x67, 0x7b, 0xe8,
    0xc9, 0xf7, 0x61, 0x1a, 0x16, 0xb5, 0xb0, 0x4e, 0xe2, 0x27, 0x68, 0xad,
    0x05, 0x11, 0x47, 0x97, 0xe7, 0x40, 0x58, 0x6f, 0x9c, 0x3f, 0x7f, 0x9e,
    0x56, 0x2c, 0x68, 0xb3, 0xba, 0xc8, 0xeb, 0x6e, 0xde, 0xd1, 0x53, 0x3c,
    0x3a, 0xf5, 0x10, 0x75, 0xe9, 0x63, 0x64, 0x52, 0xa4, 0x19, 0x33, 0x13,
    0xcf, 0x70, 0xef, 0xc4, 0x5d, 0x34, 0x65, 0xc4, 0x68, 0x61, 0x03, 0xeb,
    0x8a, 0xa3, 0x94, 0xb2, 0xa5, 0xf7, 0x10, 0x41, 0x88, 0xa8, 0x09, 0x52,
    0xd2, 0x57, 0xc8, 0x32, 0xbb, 0xec, 0x05, 0x86, 0xb2, 0xc6, 0x82, 0x6a,
    0xf3, 0xa6, 0x82, 0x1f, 0x51, 0xea, 0xec, 0xc5, 0x4e, 0x4d, 0xbc, 0x6c,
    0x9e, 0x43, 0xb5, 0x83, 0x78, 0x27, 0x72, 0x5c, 0x77, 0xd1, 0x77, 0x11,
    0x84, 0xfc, 0xe5, 0xed, 0xc7, 0x39, 0xd5, 0x38, 0xcd, 0x17, 0x7b, 0xb6,
    0xd0, 0x97, 0x1f, 0xa0, 0xdd, 0x69, 0x27, 0x90, 0x01, 0xbe, 0xf0, 0xa9,
    0x9d, 0xae, 0x11, 0x89, 0x08, 0x52, 0x0e, 0xe8, 0xbd, 0x5a, 0x2e, 0x13,
    0x88, 0x76, 0xf7, 0xb0, 0x11, 0x24, 0x7f, 0xf5, 0xcf, 0x06, 0xdf, 0xec,
    0x2c, 0x94, 0xe8, 0xf4, 0x4a, 0x74, 0x65, 0xfa, 0xe9, 0xcd, 0x0c, 0x71,
    0xa4, 0xf5, 0x16, 0x4b, 0xa7, 0x1a, 0xd8, 0xa6, 0xc3, 0x42, 0xbc, 0xc8,
    0x57, 0x87, 0xae, 0xa0, 0xe0, 0x16, 0x70, 0x4c, 0x97, 0x20, 0x0e, 0x38,
    0x2f, 0x2e, 0x50, 0x99, 0xae, 0xe0, 0x57, 0x7c, 0x12, 0x95, 0x1c, 0xc7,
    0xe4, 0xc0, 0x8a, 0x7f, 0xd1, 0xe8, 0x6f, 0x07, 0xbe, 0xe6, 0x19, 0xce,
    0xa1, 0xfe, 0xcf, 0x0c, 0x65, 0x46, 0xd6, 0x8f, 0xd2, 0x9f, 0x1b, 0x20,
    0x6f, 0xb7, 0x63, 0x9b, 0xd6, 0x7b, 0x29, 0xd6, 0xe0, 0xd9, 0x19, 0x00,
    0x62, 0x25, 0x59, 0x14, 0x55, 0xce, 0xd4, 0xcb, 0x4c, 0x1f, 0x9b, 0x66,
    0xf6, 0xe4, 0x2c, 0x7e, 0xc3, 0x17, 0x2a, 0x51, 0xdf, 0xd2, 0x7b, 0xf5,
    0x2b, 0x2b, 0x0a, 0x00, 0x46, 0xee, 0xe9, 0xdd, 0xed, 0x78, 0xde, 0x6f,
    0x06, 0xd6, 0x0f, 0x31, 0x3c, 0x3a, 0x42, 0x5f, 0xb1, 0x9f, 0xa2, 0xd7,
    0x81, 0x67, 0x79, 0x00, 0x48, 0x25, 0x09, 0x64, 0x93, 0x6a, 0xb0, 0xc0,
    0x6c, 0x65, 0x96, 0xf2, 0x3b, 0x65, 0xce, 0xcd, 0x9e, 0xa3, 0x11, 0x36,
    0x48, 0x92, 0xe4, 0x0e, 0xbd, 0x47, 0x3f, 0xf2, 0x41, 0xde, 0x8a, 0xfb,
    0xa0, 0xef, 0xce, 0xee, 0xfb, 0x5d, 0xc7, 0xbe, 0xb7, 0xa3, 0xab, 0x9b,
    0xd2, 0x60, 0x2f, 0x1d, 0x9d, 0x45, 0xb2, 0x6e, 0x0e, 0x0c, 0x08, 0x45,
    0x88, 0x5f, 0x5f, 0xa2, 0x7a, 0xa1, 0xca, 0x42, 0x65, 0x81, 0x7a, 0x50,
    0x27, 0x8a, 0xa3, 0x40, 0x69, 0x75, 0x9b, 0xfe, 0xb3, 0x7e, 0xf2, 0xc3,
    0xac, 0x55, 0x37, 0x5a, 0xe1, 0xf6, 0xfc, 0xb5, 0x96, 0x61, 0xde, 0xe9,
    0x98, 0xde, 0xd6, 0x6c, 0x26, 0x8b, 0xed, 0x39, 0x68, 0x20, 0x8e, 0x62,
    0xa2, 0x30, 0xa2, 0x15, 0x87, 0xc8, 0x24, 0x56, 0x2a, 0x55, 0x63, 0xa9,
    0x4a, 0x7f, 0xaf, 0xf7, 0xea, 0x7f, 0xad, 0xc4, 0x59, 0x55, 0x00, 0x60,
    0x7c, 0xdb, 0x68, 0xf7, 0x86, 0xbd, 0xcb, 0x4d, 0xc3, 0xbc, 0xd5, 0xc0,
    0xb8, 0x54, 0xc3, 0x90, 0xd2, 0x2a, 0x49, 0x94, 0x9c, 0x4c, 0x55, 0x3a,
    0x0e, 0xec, 0xd3, 0x7b, 0xf4, 0x1b, 0xab, 0x02, 0x3e, 0x4a, 0xf0, 0x49,
    0xd4, 0xbb, 0xc1, 0x0e, 0xb0, 0xda, 0xef, 0xbc, 0x77, 0x06, 0x00, 0x00,
    0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image5_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xe0, 0x77, 0x3d, 0xf8, 0x00, 0x00, 0x04,
    0x3e, 0x49, 0x44, 0x41, 0x54, 0x48, 0x89, 0xa5, 0xd6, 0x7b, 0x6c, 0x53,
    0x55, 0x1c, 0xc0, 0xf1, 0xef, 0x39, 0xf7, 0xf6, 0xb1, 0xae, 0xc3, 0x6d,
    0xb8, 0x31, 0x99, 0x0f, 0x04, 0x81, 0xc9, 0x40, 0x60, 0xc4, 0x88, 0x22,
    0x26, 0x8a, 0x1a, 0xc0, 0x30, 0xd8, 0x00, 0x51, 0x62, 0x14, 0x42, 0x42,
    0x50, 0x03, 0x18, 0x83, 0x46, 0x16, 0xcc, 0xc2, 0x53, 0xa2, 0x10, 0xf0,
    0x81, 0x89, 0x51, 0x27, 0x12, 0x24, 0x08, 0xc4, 0x80, 0x31, 0xc0, 0x3f,
    0x90, 0x10, 0x61, 0xe0, 0x06, 0x43, 0x1d, 0x81, 0xf1, 0x98, 0x3a, 0xa0,
    0x5b, 0xbb, 0xb5, 0xdd, 0xda, 0xde, 0x75, 0xed, 0xed, 0x6e, 0x8f, 0x7f,
    0x14, 0x16, 0x1e, 0x43, 0xb6, 0x79, 0xfe, 0x3e, 0xf9, 0x7c, 0x7f, 0xe7,
    0x9e, 0x9c, 0xe4, 0x0a, 0xa5, 0x14, 0x7d, 0x5d, 0xdf, 0x2c, 0x11, 0x13,
    0x2d, 0x8b, 0x01, 0x8e, 0x28, 0xbf, 0xcc, 0xfb, 0x4e, 0xc5, 0xba, 0xdb,
    0x23, 0xfa, 0x12, 0x58, 0xb9, 0x52, 0xe8, 0x83, 0x23, 0x6c, 0x31, 0x42,
    0x2c, 0x8c, 0x77, 0x82, 0xe6, 0xe0, 0xa0, 0xa6, 0x31, 0xff, 0xad, 0x2d,
    0xca, 0xfb, 0xbf, 0x03, 0xbb, 0x5f, 0x16, 0x5a, 0x62, 0x10, 0xdb, 0x3a,
    0x4d, 0xe6, 0x16, 0x4e, 0x9a, 0x43, 0x7a, 0x72, 0x30, 0x47, 0x0e, 0x6e,
    0x20, 0x9a, 0x48, 0x9c, 0xd5, 0x12, 0x4c, 0x59, 0xf2, 0xbd, 0xba, 0x7c,
    0xe3, 0x7e, 0xd9, 0xdb, 0xe9, 0xb5, 0xe1, 0x54, 0x48, 0x98, 0x3b, 0x6e,
    0xda, 0x62, 0xc6, 0x8d, 0xdf, 0x44, 0x41, 0xce, 0x3a, 0x9e, 0x1b, 0xfd,
    0x05, 0x52, 0x88, 0x11, 0x51, 0xd8, 0xfb, 0xf1, 0xab, 0x62, 0x60, 0x9f,
    0x03, 0xfb, 0x3f, 0x12, 0xab, 0x95, 0xc5, 0xeb, 0xc3, 0x27, 0xce, 0xa2,
    0xb0, 0xa0, 0x0c, 0xaa, 0xd2, 0xc0, 0x17, 0x62, 0x68, 0xe6, 0x2b, 0x3c,
    0xfb, 0xd0, 0x1a, 0xa4, 0x90, 0x63, 0xe3, 0x92, 0xbd, 0x2b, 0x8b, 0x85,
    0xab, 0xd7, 0x81, 0x43, 0x1b, 0x45, 0x59, 0x32, 0xce, 0x8a, 0xfb, 0x0b,
    0x27, 0x30, 0x76, 0xda, 0x56, 0x88, 0xf4, 0x47, 0xb5, 0x77, 0x92, 0x30,
    0xda, 0x68, 0x6f, 0x6e, 0xe0, 0x11, 0x59, 0xcc, 0xd3, 0xee, 0x77, 0x90,
    0x49, 0xf1, 0x78, 0xd2, 0xc9, 0xb6, 0xcf, 0xa7, 0x0a, 0x47, 0x8f, 0x03,
    0xc7, 0x3e, 0x13, 0xcb, 0x93, 0x31, 0xd6, 0xe6, 0x3c, 0x3c, 0x9e, 0xb1,
    0x25, 0x6f, 0x00, 0x87, 0x50, 0x05, 0x36, 0xcc, 0x07, 0x74, 0xcc, 0xe6,
    0x36, 0xcc, 0xd6, 0x08, 0x91, 0x40, 0x13, 0x43, 0x63, 0x93, 0x79, 0xc2,
    0x9a, 0x87, 0x54, 0x72, 0xa6, 0xb7, 0x1f, 0x73, 0x7a, 0x14, 0x38, 0xf5,
    0xb5, 0x78, 0x37, 0x99, 0x60, 0x5d, 0xd6, 0x83, 0xe3, 0x18, 0x5d, 0xb2,
    0x14, 0xbb, 0x6b, 0x03, 0x8a, 0xe9, 0xc4, 0x02, 0x5f, 0x62, 0x8c, 0x70,
    0x61, 0x14, 0xa4, 0x93, 0x68, 0x0d, 0x63, 0x06, 0xdb, 0x88, 0xf9, 0x83,
    0xe4, 0x19, 0x43, 0x70, 0xe1, 0x82, 0x24, 0xf3, 0xee, 0x1a, 0xa8, 0xfe,
    0x4a, 0x94, 0x9a, 0x51, 0x3e, 0x71, 0xe7, 0x15, 0x32, 0x6a, 0xc6, 0x1a,
    0x9c, 0xfd, 0x56, 0xa3, 0xb8, 0x40, 0xc7, 0x5f, 0xa0, 0x9f, 0x7f, 0x9b,
    0x34, 0xff, 0xfb, 0x84, 0x8a, 0xee, 0xa1, 0x75, 0x4c, 0x06, 0x9d, 0x81,
    0x28, 0x46, 0x67, 0x2b, 0x95, 0xce, 0x1d, 0x44, 0x30, 0xb0, 0x41, 0x2b,
    0x80, 0x7e, 0x27, 0xfc, 0xd7, 0xcd, 0x62, 0x86, 0x95, 0xe0, 0x87, 0xb4,
    0xcc, 0x5c, 0x39, 0xf4, 0xc5, 0x15, 0x38, 0x32, 0x36, 0xa1, 0x38, 0x4b,
    0xc7, 0x3f, 0x60, 0xf7, 0x81, 0x9e, 0x0e, 0x6d, 0x75, 0x9f, 0x12, 0xb3,
    0x75, 0x10, 0x2b, 0x5a, 0x84, 0xf2, 0x3b, 0xf9, 0xbd, 0x6a, 0x23, 0x0d,
    0xf2, 0x2c, 0x8e, 0x24, 0x8d, 0x52, 0xb2, 0x0a, 0xee, 0xf0, 0x0e, 0x0e,
    0x6f, 0x16, 0x45, 0x89, 0x76, 0xf6, 0xa7, 0x67, 0xf5, 0x1f, 0x30, 0x72,
    0xfa, 0x5a, 0x32, 0xf3, 0xf7, 0xa1, 0x38, 0x90, 0xc2, 0x9b, 0x52, 0xb8,
    0xbf, 0x09, 0xbc, 0x1e, 0x48, 0xb3, 0x81, 0xdf, 0x3e, 0x89, 0xe3, 0x27,
    0x43, 0xb4, 0xd4, 0x9f, 0xc4, 0xae, 0x13, 0x06, 0x5e, 0x2a, 0xdf, 0xa5,
    0x8e, 0x76, 0x1b, 0x38, 0xf0, 0x91, 0xc8, 0x49, 0x98, 0x1c, 0x75, 0x67,
    0x67, 0x0f, 0x2b, 0x2a, 0x2d, 0x23, 0x33, 0x7f, 0x3f, 0x8a, 0xc3, 0x37,
    0xe1, 0x01, 0x2f, 0x34, 0x79, 0xc0, 0x69, 0x87, 0x90, 0x01, 0xc7, 0xaa,
    0xa0, 0x39, 0x08, 0x36, 0x3b, 0x01, 0x92, 0x14, 0x97, 0xef, 0x56, 0x95,
    0xd7, 0xbd, 0xdb, 0xee, 0xc0, 0x30, 0xf8, 0x56, 0x48, 0x86, 0x8d, 0x9c,
    0xba, 0x88, 0xcc, 0xfc, 0xea, 0x14, 0xde, 0x00, 0xf6, 0x46, 0xd0, 0x5d,
    0xe0, 0xf7, 0x42, 0xd3, 0x55, 0x70, 0x3a, 0x52, 0x78, 0xe5, 0x29, 0xf0,
    0xb7, 0x81, 0xcd, 0x86, 0x1f, 0x28, 0xbd, 0x11, 0xbf, 0xed, 0x0e, 0x76,
    0x7e, 0x20, 0x96, 0x49, 0x98, 0xf6, 0xe8, 0xf3, 0x4b, 0xc9, 0x19, 0xec,
    0x41, 0xf1, 0x23, 0x1d, 0x97, 0xc1, 0xd6, 0x08, 0xba, 0x1b, 0x02, 0xbe,
    0xd4, 0x67, 0x71, 0x3a, 0x21, 0x62, 0xc0, 0x89, 0xd3, 0xd0, 0x12, 0x00,
    0x4d, 0xe3, 0x22, 0x92, 0xd2, 0xf2, 0x9d, 0xea, 0xcc, 0xad, 0x03, 0x77,
    0x9d, 0x60, 0xeb, 0x72, 0x31, 0xc8, 0x34, 0x79, 0xcf, 0x95, 0x93, 0xcf,
    0x90, 0xf1, 0x13, 0x89, 0xb5, 0xbb, 0x09, 0x5f, 0x4a, 0xc3, 0xde, 0x08,
    0xb6, 0x74, 0x08, 0xfa, 0xae, 0x4d, 0x6e, 0x4f, 0xe1, 0x95, 0xa7, 0xa1,
    0x25, 0x08, 0x9a, 0x46, 0x3d, 0x49, 0x8a, 0xbb, 0xc3, 0x6f, 0x0a, 0x28,
    0x93, 0x37, 0x4d, 0x93, 0xdc, 0xe1, 0x13, 0x5e, 0x40, 0x08, 0x03, 0xa7,
    0xfb, 0x49, 0x84, 0x3e, 0x1f, 0xa4, 0x83, 0xd6, 0x66, 0xf0, 0x5c, 0xc3,
    0xc3, 0xed, 0x70, 0xbc, 0x06, 0x9a, 0x5b, 0x40, 0xc0, 0x79, 0x2d, 0xc9,
    0x94, 0xf2, 0x3d, 0xaa, 0xae, 0x3b, 0xbc, 0x2b, 0x50, 0xb1, 0x58, 0x0c,
    0xec, 0x30, 0x58, 0x98, 0x75, 0xdf, 0xbd, 0x0c, 0x1a, 0x53, 0x04, 0x58,
    0x58, 0xf1, 0x00, 0x5a, 0x46, 0x1e, 0x4d, 0xd6, 0x33, 0x5c, 0xbd, 0xa2,
    0xe3, 0xb2, 0x83, 0x11, 0x85, 0x13, 0x35, 0xe0, 0x6d, 0x01, 0x29, 0xa9,
    0xb7, 0x60, 0xf6, 0x8a, 0x3d, 0xea, 0xe2, 0x9d, 0xf0, 0xae, 0x40, 0xbb,
    0xc9, 0x2c, 0x33, 0x4e, 0xa6, 0x96, 0x5d, 0x88, 0xcd, 0x99, 0x89, 0x15,
    0x0f, 0x11, 0x0d, 0x5e, 0xa1, 0xdd, 0x77, 0x01, 0x21, 0x35, 0x1c, 0x59,
    0xf9, 0x04, 0x43, 0x82, 0xa3, 0xd5, 0x29, 0x5c, 0xd3, 0xf8, 0x0d, 0xc9,
    0xd4, 0x55, 0xbb, 0x54, 0xed, 0x7f, 0xe1, 0x70, 0xed, 0x92, 0xad, 0x38,
    0xb3, 0xa5, 0xae, 0x51, 0x75, 0x2e, 0x8f, 0xd8, 0xf6, 0x1a, 0x66, 0x4e,
    0x96, 0x98, 0xad, 0x8d, 0x24, 0xc2, 0x5e, 0xc2, 0xde, 0x2b, 0xd4, 0xd5,
    0xb6, 0x50, 0x7f, 0x49, 0x11, 0x8e, 0x80, 0xae, 0x73, 0x18, 0x3b, 0x25,
    0xe5, 0xdb, 0x55, 0xf8, 0x6e, 0x78, 0x57, 0x20, 0x61, 0xf1, 0x94, 0xb2,
    0x65, 0xe3, 0x09, 0x39, 0xf9, 0x69, 0x7d, 0x15, 0x75, 0xa7, 0x0c, 0x16,
    0x94, 0xb8, 0xf9, 0xb3, 0xfa, 0x02, 0xe7, 0xce, 0x04, 0x88, 0x84, 0x15,
    0x49, 0x40, 0xd7, 0xf9, 0x19, 0x9d, 0x05, 0x3d, 0xc5, 0xbb, 0x02, 0x49,
    0x0b, 0xd9, 0x12, 0x71, 0xe1, 0xf1, 0xfd, 0x8d, 0xdb, 0xaa, 0xa3, 0xfa,
    0x48, 0x10, 0xcd, 0x2b, 0xb0, 0x12, 0x0a, 0x05, 0x48, 0x49, 0x48, 0x42,
    0x05, 0x85, 0x2c, 0x2b, 0x2f, 0x57, 0xc9, 0x9e, 0xe2, 0x5d, 0x01, 0xd3,
    0xa2, 0xd6, 0xd6, 0xe9, 0x1b, 0xf5, 0x58, 0x86, 0x87, 0xac, 0xdc, 0x4e,
    0x1c, 0x36, 0x88, 0xc6, 0x14, 0x42, 0xd0, 0x20, 0x04, 0x15, 0x52, 0xb2,
    0xef, 0xc3, 0x9d, 0xea, 0x8f, 0xde, 0xc0, 0xb7, 0x9e, 0xe0, 0x35, 0x97,
    0x16, 0x5b, 0xdf, 0xcf, 0x4e, 0xae, 0x05, 0x66, 0x47, 0x9c, 0x1a, 0xa1,
    0xb1, 0xd7, 0xa6, 0x51, 0x5b, 0xb6, 0x43, 0xf9, 0xfa, 0x02, 0x5f, 0x5f,
    0x7d, 0xfa, 0xab, 0xe8, 0xcd, 0xfa, 0x17, 0x58, 0x4e, 0xda, 0x4e, 0x6e,
    0x81, 0xa6, 0x2b, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae,
    0x42, 0x60, 0x82
};

static const unsigned char image6_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xd5, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0x95, 0x93, 0x5d, 0x88, 0x54,
    0x75, 0x18, 0xc6, 0x7f, 0xff, 0x73, 0xe6, 0xcc, 0xce, 0xb8, 0xf3, 0xb9,
    0xba, 0xb3, 0xad, 0xeb, 0xa6, 0xae, 0x19, 0x26, 0x6b, 0xee, 0x8a, 0x10,
    0x21, 0xd1, 0x8d, 0x50, 0x17, 0x8a, 0x5f, 0xac, 0x08, 0xdd, 0x04, 0xe6,
    0x4d, 0x29, 0x05, 0xe1, 0x8d, 0x20, 0x92, 0x5e, 0x08, 0xa2, 0xa8, 0x91,
    0x60, 0x75, 0x11, 0x5d, 0x08, 0x46, 0x45, 0x5d, 0x44, 0x64, 0x91, 0xac,
    0x28, 0xee, 0x86, 0xe8, 0x38, 0x85, 0xda, 0xae, 0xd9, 0xae, 0xbb, 0x8e,
    0xb3, 0x8d, 0xbb, 0x73, 0xe6, 0xcc, 0x9c, 0x39, 0xff, 0x73, 0xce, 0xcc,
    0x99, 0x7f, 0x17, 0xb1, 0x03, 0x7d, 0x61, 0x3d, 0xef, 0xed, 0xcb, 0xef,
    0x7d, 0x78, 0x79, 0x1e, 0xa1, 0x94, 0xe2, 0xbf, 0x48, 0x20, 0x84, 0xe2,
    0xef, 0xcb, 0xe2, 0xaf, 0x80, 0x6d, 0xc3, 0x83, 0x29, 0x4d, 0x7a, 0xaf,
    0x36, 0x75, 0xb1, 0xcb, 0x0f, 0x9a, 0xcf, 0x49, 0xb7, 0x8e, 0x6d, 0xba,
    0x3f, 0x55, 0x2b, 0xfe, 0x70, 0x59, 0xca, 0x23, 0x33, 0x4f, 0xd9, 0x25,
    0x86, 0x68, 0xce, 0xc3, 0xfe, 0x04, 0xd8, 0xf9, 0x5d, 0xff, 0x40, 0x5f,
    0xcf, 0xca, 0x6f, 0x37, 0x2f, 0xdd, 0xdd, 0xb9, 0xb0, 0x6d, 0x09, 0xe5,
    0x46, 0x89, 0xbc, 0x3b, 0xcd, 0x03, 0x67, 0x9a, 0xcf, 0x72, 0xe7, 0x78,
    0x38, 0x5e, 0xac, 0xda, 0x96, 0x37, 0x54, 0x54, 0xb5, 0xef, 0xd5, 0x21,
    0xd5, 0x00, 0x08, 0xb5, 0x2e, 0x7f, 0xdd, 0x3f, 0xb0, 0x6e, 0xe5, 0xba,
    0x91, 0x57, 0x56, 0xbc, 0x1d, 0xb9, 0xd2, 0xf8, 0x94, 0xaf, 0x2a, 0x59,
    0x2c, 0x47, 0x52, 0xae, 0x39, 0x48, 0x47, 0xb1, 0xba, 0x77, 0x00, 0x9b,
    0x1f, 0xe2, 0xce, 0x8f, 0xb3, 0xdf, 0xc4, 0xdd, 0xd0, 0x06, 0x81, 0x18,
    0x51, 0x28, 0xa5, 0xcd, 0x03, 0x52, 0xe9, 0xf4, 0x85, 0xed, 0xcb, 0xf7,
    0x46, 0xbe, 0xac, 0x9f, 0xa0, 0xc0, 0x18, 0x42, 0x08, 0xe6, 0x67, 0xe2,
    0x6e, 0x81, 0xcb, 0x77, 0x2e, 0x11, 0xa0, 0x50, 0x4f, 0x80, 0xf0, 0xf4,
    0xf3, 0xbc, 0x83, 0x0e, 0xa0, 0x01, 0x6c, 0xfc, 0x64, 0xf9, 0x9b, 0x1b,
    0x57, 0x0c, 0x65, 0x3e, 0xb7, 0xde, 0xa5, 0x24, 0x4d, 0xaa, 0xd2, 0xc3,
    0xab, 0x37, 0xa8, 0x07, 0x0d, 0x6e, 0x5e, 0x9d, 0xe6, 0xb5, 0xee, 0xfd,
    0x5c, 0x78, 0x69, 0x14, 0xdb, 0xaf, 0x21, 0xa2, 0x21, 0x88, 0x6a, 0xbd,
    0x61, 0x53, 0xdf, 0xd6, 0x02, 0x04, 0x9a, 0xbe, 0x2b, 0x14, 0x8e, 0x90,
    0xaf, 0xe5, 0xa9, 0x38, 0x92, 0x8a, 0x23, 0xa9, 0xb9, 0x1e, 0x53, 0x93,
    0x25, 0x36, 0x44, 0x5f, 0x66, 0xef, 0x0b, 0xfb, 0xb8, 0x56, 0x1e, 0x41,
    0xc7, 0x20, 0x6e, 0x24, 0x30, 0xe2, 0x61, 0x9a, 0x4a, 0xad, 0x6d, 0xfd,
    0xa0, 0xae, 0x1a, 0xfd, 0xbf, 0xda, 0x63, 0x54, 0xa5, 0x64, 0x62, 0xdc,
    0xa7, 0xc7, 0x7f, 0x86, 0xda, 0xd3, 0x77, 0xb9, 0x9f, 0xab, 0x72, 0x7e,
    0xcf, 0x71, 0x2a, 0x9e, 0xc5, 0xe9, 0xf1, 0x63, 0x84, 0x45, 0x94, 0xf6,
    0xb6, 0x04, 0xb6, 0xe1, 0x12, 0xd4, 0xad, 0x67, 0x5b, 0x0e, 0x3c, 0x37,
    0x88, 0xe5, 0xed, 0x3c, 0xb6, 0xe3, 0xd1, 0xd3, 0xd6, 0xc7, 0x47, 0x3b,
    0xce, 0x91, 0xb9, 0x37, 0xc8, 0x81, 0xe7, 0x0f, 0x93, 0x8a, 0xa6, 0xf8,
    0x78, 0xe2, 0x43, 0x1e, 0xd8, 0x05, 0xd2, 0x91, 0x45, 0xc4, 0xc3, 0x49,
    0xb4, 0x86, 0x8e, 0x52, 0x4c, 0xb4, 0x1c, 0x78, 0x4e, 0x90, 0xff, 0xad,
    0x36, 0xd7, 0xe3, 0x07, 0x1a, 0x85, 0xc8, 0x24, 0x96, 0x2c, 0x73, 0x6c,
    0xcb, 0x49, 0xea, 0xca, 0xe7, 0xda, 0xec, 0x28, 0xa7, 0x7e, 0x3e, 0x41,
    0xf7, 0x82, 0x27, 0x59, 0x96, 0xec, 0xa3, 0x50, 0x9d, 0xc1, 0x9d, 0x73,
    0xa1, 0xf9, 0x07, 0x40, 0x03, 0xf0, 0x6d, 0x75, 0xb1, 0x64, 0x96, 0x49,
    0xeb, 0x8b, 0x69, 0x6f, 0xeb, 0x60, 0x7f, 0x76, 0x1f, 0xd3, 0xce, 0x14,
    0x53, 0xee, 0x7d, 0x8e, 0x8f, 0x1d, 0x65, 0x55, 0x7a, 0x0d, 0x03, 0x5d,
    0xeb, 0x89, 0x19, 0x71, 0x66, 0x1f, 0xcd, 0x51, 0x35, 0x6d, 0x08, 0xf8,
    0xa2, 0x15, 0xa4, 0x65, 0x47, 0x32, 0x83, 0x1d, 0x99, 0x8e, 0x1b, 0x6b,
    0xd6, 0xaf, 0x65, 0x71, 0xac, 0x17, 0xbf, 0xe9, 0xa3, 0x05, 0x3a, 0x08,
    0x81, 0xa6, 0xe9, 0xc4, 0x8d, 0x38, 0x15, 0xcf, 0xe6, 0xfa, 0xe4, 0x75,
    0xb2, 0x57, 0xb2, 0x98, 0xa6, 0x79, 0x5a, 0x9d, 0x55, 0x6f, 0xb5, 0x1c,
    0x4c, 0x1e, 0x2c, 0x66, 0x67, 0x67, 0x4a, 0x67, 0xc6, 0x6f, 0xfd, 0xc2,
    0x9c, 0x6d, 0x92, 0x32, 0x16, 0xd2, 0xd9, 0xde, 0x45, 0x67, 0x7b, 0x17,
    0x89, 0x70, 0x92, 0x42, 0x75, 0x86, 0xd1, 0xdb, 0xa3, 0xe4, 0xae, 0xe6,
    0xb0, 0xca, 0x56, 0x0e, 0xc5, 0xa1, 0x7f, 0xec, 0x42, 0xe6, 0x40, 0xfa,
    0xbd, 0x74, 0x2a, 0xfd, 0x46, 0xd7, 0x92, 0x6e, 0x12, 0x89, 0x24, 0x4a,
    0x81, 0x59, 0x29, 0x53, 0x98, 0x7a, 0x48, 0xb1, 0xf8, 0x08, 0x29, 0xe5,
    0xb0, 0x52, 0x6a, 0xab, 0x7a, 0x5f, 0x59, 0xff, 0x5a, 0x26, 0xe3, 0x75,
    0xf1, 0x62, 0x6c, 0x41, 0x6c, 0x8f, 0x11, 0x8a, 0x6c, 0x0a, 0x9a, 0xcd,
    0xa4, 0x74, 0xa5, 0x25, 0x5d, 0x39, 0x0c, 0x9c, 0x54, 0x1f, 0xa8, 0x4b,
    0x8f, 0x6d, 0xe3, 0xff, 0xd5, 0xef, 0x89, 0xaf, 0x6c, 0x2c, 0x53, 0xf4,
    0x30, 0xe9, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42,
    0x60, 0x82
};

static const unsigned char image7_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x03,
    0x0d, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0xd3, 0x5d, 0x6c, 0x53,
    0x75, 0x18, 0xc7, 0xf1, 0xef, 0x69, 0x4f, 0xdb, 0xd3, 0x76, 0x6c, 0xed,
    0x56, 0x58, 0x37, 0x46, 0x5d, 0x47, 0x98, 0x6b, 0x1d, 0x08, 0x71, 0x4b,
    0x66, 0xb6, 0x5e, 0xcc, 0x18, 0x43, 0x24, 0xb8, 0x60, 0x32, 0x7c, 0x49,
    0x34, 0x78, 0x43, 0xbc, 0x90, 0xa9, 0x31, 0x7a, 0x61, 0x8c, 0x88, 0x31,
    0x11, 0x8d, 0x28, 0x17, 0xca, 0x8d, 0x9a, 0x78, 0xe3, 0x42, 0xa6, 0xa8,
    0x11, 0x50, 0xc9, 0x46, 0x80, 0x1a, 0x9d, 0xc0, 0x60, 0x8e, 0x75, 0x2c,
    0x71, 0xe2, 0xba, 0xcd, 0x59, 0xc6, 0xec, 0x7b, 0x7b, 0xce, 0x59, 0xdb,
    0x73, 0xfe, 0x5e, 0xb9, 0xb0, 0xe8, 0x95, 0xfe, 0xee, 0x9e, 0x8b, 0xe7,
    0x93, 0x27, 0x4f, 0x9e, 0x47, 0x12, 0x42, 0xf0, 0x7f, 0x22, 0xdf, 0x5e,
    0x9c, 0x3f, 0x24, 0x29, 0x39, 0x9d, 0x90, 0x5e, 0xb1, 0x44, 0xf4, 0x92,
    0xb4, 0xbd, 0xa4, 0x5b, 0x1c, 0xaa, 0x2e, 0x66, 0xf4, 0x72, 0xe5, 0x07,
    0x4d, 0xe3, 0x32, 0x5f, 0x91, 0x3b, 0x28, 0x84, 0x79, 0x7b, 0x8f, 0xf4,
    0xf7, 0x04, 0xd1, 0x37, 0xa4, 0xa0, 0x70, 0xd9, 0x5f, 0xb3, 0xfb, 0x1a,
    0xf7, 0x38, 0xeb, 0xc3, 0xeb, 0x6c, 0x76, 0x0f, 0x15, 0x4d, 0xa3, 0x98,
    0x5f, 0x22, 0x11, 0xff, 0x95, 0x44, 0xbc, 0x30, 0x91, 0x5a, 0x52, 0x3f,
    0xbc, 0x95, 0xe3, 0xf8, 0xfb, 0x23, 0x22, 0xb9, 0x06, 0x88, 0xbe, 0x2d,
    0x85, 0xec, 0x35, 0xeb, 0x3e, 0x6f, 0xec, 0xd8, 0x17, 0x56, 0xac, 0xbd,
    0x68, 0xf3, 0x49, 0xbc, 0xdb, 0xad, 0x38, 0xd6, 0x67, 0xd1, 0xb2, 0x4b,
    0x54, 0x4a, 0x79, 0x32, 0x8b, 0x73, 0x5c, 0x3d, 0xfb, 0x33, 0x33, 0x53,
    0x89, 0xb3, 0xa9, 0x94, 0xf1, 0xd4, 0x91, 0x33, 0x62, 0x61, 0x15, 0x18,
    0x39, 0x2c, 0x47, 0x5b, 0x77, 0x3e, 0x13, 0xf1, 0xf9, 0x5e, 0x64, 0x7c,
    0xdf, 0x4e, 0xcc, 0xd9, 0x18, 0x74, 0x34, 0xe2, 0x3f, 0xd0, 0x49, 0x76,
    0xc4, 0x41, 0xfe, 0x4a, 0x89, 0xa6, 0xc7, 0x54, 0x3c, 0xdb, 0x04, 0xa3,
    0xc3, 0xbf, 0x30, 0x39, 0xbe, 0xf4, 0xcd, 0x1f, 0x0b, 0xfa, 0x23, 0x1f,
    0x9c, 0x13, 0x05, 0x0b, 0x40, 0x45, 0xb2, 0x45, 0xaa, 0x1a, 0xbb, 0x58,
    0x1e, 0xff, 0x8c, 0xf2, 0x64, 0x8c, 0xb6, 0x90, 0x07, 0x11, 0x4f, 0x10,
    0x3f, 0x9e, 0x61, 0xe3, 0x68, 0x1f, 0xdd, 0xb1, 0x97, 0x49, 0x7f, 0x54,
    0x4d, 0x21, 0xb1, 0x4c, 0xf7, 0xfd, 0x5b, 0x08, 0x04, 0x7d, 0x0f, 0x7a,
    0xbc, 0xb6, 0xbd, 0x00, 0x16, 0x00, 0xad, 0x60, 0xec, 0x9f, 0xfa, 0xee,
    0xbd, 0x1b, 0xa9, 0xca, 0x29, 0x6c, 0x3d, 0x5b, 0x98, 0x9c, 0x32, 0xb1,
    0xdf, 0x17, 0x62, 0x43, 0x77, 0x1d, 0x99, 0xec, 0x75, 0x92, 0xa9, 0x31,
    0x3c, 0x1b, 0x74, 0x14, 0x8b, 0x42, 0x5d, 0x8d, 0x9f, 0xcd, 0x77, 0xd6,
    0xe3, 0x74, 0xcb, 0x4f, 0xac, 0x59, 0xe2, 0x27, 0x4f, 0x4b, 0x67, 0xda,
    0x77, 0x3f, 0xf4, 0x40, 0x38, 0xd2, 0x4f, 0xfc, 0xdc, 0x09, 0x6a, 0xb7,
    0xf9, 0x30, 0xca, 0x69, 0x16, 0x4e, 0xde, 0x44, 0x8a, 0x6b, 0xfc, 0x76,
    0x4f, 0x96, 0x11, 0xc5, 0x60, 0x77, 0x20, 0x4c, 0x6b, 0x56, 0x65, 0xf8,
    0xe4, 0xd5, 0xdc, 0xb3, 0xc7, 0xb2, 0x35, 0x32, 0xc0, 0xc7, 0x03, 0xf2,
    0xb1, 0xce, 0x87, 0x9f, 0x8c, 0x04, 0x77, 0xec, 0x35, 0xa6, 0x2f, 0x0e,
    0xa6, 0x57, 0xac, 0x8b, 0x56, 0x25, 0x69, 0xf5, 0xda, 0x8c, 0x15, 0xba,
    0xf6, 0xa8, 0x14, 0x56, 0xd2, 0xbc, 0x34, 0x96, 0x23, 0x5a, 0xcc, 0x73,
    0x62, 0x22, 0xc9, 0x85, 0x96, 0x0e, 0x1c, 0xb2, 0xa5, 0x7a, 0xf5, 0x0e,
    0x8c, 0xb2, 0xdc, 0xe7, 0xdb, 0x14, 0x74, 0xaa, 0xe9, 0x0b, 0xe6, 0xe9,
    0xa3, 0x83, 0xc3, 0x37, 0x17, 0x19, 0x7b, 0xf4, 0xf9, 0xe2, 0x3b, 0x6d,
    0xe1, 0x06, 0xe9, 0xd2, 0x15, 0x17, 0x2e, 0x53, 0x62, 0xab, 0x50, 0xf9,
    0xb1, 0x68, 0xd0, 0xe3, 0x6f, 0xc0, 0x2c, 0x9b, 0xe8, 0xba, 0x59, 0x58,
    0x05, 0x72, 0x79, 0x63, 0xe8, 0xda, 0xf9, 0x2f, 0x9f, 0xeb, 0xec, 0xdd,
    0x6a, 0xd9, 0xb5, 0xbf, 0xfb, 0xde, 0xc5, 0xd9, 0x54, 0x53, 0xa0, 0x8e,
    0xca, 0xe8, 0x82, 0xd7, 0x36, 0x30, 0x33, 0x40, 0x9d, 0x25, 0xc7, 0x91,
    0x1d, 0x9f, 0xf2, 0xf8, 0xdd, 0x82, 0xb6, 0xf5, 0xb5, 0x8c, 0x7d, 0xfd,
    0x3d, 0xd9, 0x42, 0xe9, 0xdb, 0x55, 0x60, 0x45, 0xab, 0x1c, 0xbd, 0x7e,
    0x69, 0xb2, 0x4f, 0xc2, 0x0c, 0xb6, 0x77, 0x85, 0x9b, 0x83, 0xa1, 0x60,
    0x73, 0xad, 0xb3, 0x68, 0x5e, 0x9b, 0xae, 0x67, 0x7e, 0xb9, 0x81, 0x79,
    0xa5, 0x96, 0x8d, 0xcd, 0x61, 0x5a, 0x37, 0xe7, 0x99, 0x8d, 0xc6, 0x98,
    0x8e, 0xfd, 0xae, 0xea, 0x9a, 0xfe, 0xd6, 0x9a, 0x25, 0xbe, 0xda, 0x2f,
    0x45, 0x5c, 0x8a, 0x3c, 0x58, 0xbf, 0xc9, 0xdf, 0xd4, 0xd2, 0xde, 0x4c,
    0xa0, 0xc5, 0x87, 0xac, 0xb8, 0xf8, 0x29, 0xee, 0xc5, 0x61, 0x13, 0xdc,
    0xe5, 0xbb, 0xc5, 0xdc, 0xf4, 0x1c, 0xb1, 0xcb, 0x37, 0xf8, 0x73, 0x39,
    0xf3, 0xc2, 0xeb, 0x43, 0xc6, 0xbb, 0x6b, 0x00, 0x80, 0x57, 0x76, 0x49,
    0x77, 0x48, 0x0a, 0x07, 0xdc, 0x55, 0xce, 0xfe, 0x2a, 0x4f, 0x75, 0xc0,
    0x5d, 0xed, 0xc4, 0x6d, 0x17, 0x54, 0x0c, 0x93, 0x74, 0x46, 0x27, 0x93,
    0x2c, 0x4c, 0xa8, 0x45, 0xed, 0xb0, 0x5d, 0xe6, 0x8b, 0x83, 0x43, 0xa2,
    0xf4, 0x0f, 0x00, 0xe0, 0x50, 0xaf, 0x24, 0xab, 0x4e, 0xfc, 0x2e, 0x37,
    0x3d, 0x56, 0xbb, 0xad, 0x07, 0xf0, 0x22, 0xc4, 0x5c, 0xd9, 0x14, 0x17,
    0x4b, 0x05, 0x23, 0xfa, 0xe6, 0x29, 0x91, 0xfe, 0xd7, 0x67, 0xfa, 0xaf,
    0xf9, 0x0b, 0xde, 0xf6, 0x67, 0xde, 0x4c, 0xa4, 0x1d, 0xe7, 0x00, 0x00,
    0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image8_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xe7, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x5d, 0x68, 0x5b,
    0x75, 0x18, 0xc6, 0x7f, 0xff, 0x93, 0xcf, 0xd3, 0x35, 0x69, 0xd2, 0xa6,
    0x69, 0xc9, 0x96, 0xce, 0x55, 0xb7, 0x76, 0xba, 0x89, 0x1d, 0xb4, 0x03,
    0xad, 0x30, 0x94, 0xb1, 0x2b, 0xb7, 0x39, 0xd9, 0xcd, 0xae, 0xc4, 0x9b,
    0x4d, 0x07, 0x43, 0xd9, 0xc5, 0x10, 0x57, 0xaa, 0x43, 0x64, 0xbb, 0x10,
    0x51, 0xb1, 0xa0, 0xa2, 0xbb, 0xf0, 0x42, 0x70, 0x2a, 0xac, 0xca, 0x54,
    0xbc, 0x28, 0x9b, 0x13, 0x91, 0x76, 0xb5, 0xe0, 0x56, 0xc3, 0x62, 0x4f,
    0xdb, 0x93, 0x75, 0x29, 0x4b, 0x76, 0x92, 0x93, 0xe4, 0x9c, 0xa4, 0x49,
    0xce, 0xf9, 0x7b, 0x65, 0xa0, 0x73, 0x7a, 0xe3, 0x7b, 0xf9, 0xf2, 0xf0,
    0xe3, 0x79, 0x3f, 0x1e, 0x21, 0xa5, 0xe4, 0xff, 0x94, 0xf7, 0x7e, 0x4d,
    0x21, 0x84, 0xe8, 0x9e, 0x60, 0x34, 0x1c, 0x62, 0x8f, 0xa7, 0xa9, 0xf4,
    0x37, 0x0a, 0xca, 0x82, 0xb7, 0xd4, 0xfe, 0xed, 0xcd, 0xf1, 0xc2, 0xdc,
    0x3f, 0xb4, 0xf7, 0x3a, 0x18, 0xba, 0x20, 0x1e, 0xdb, 0xbd, 0xf9, 0xc9,
    0xd7, 0xb7, 0x85, 0x47, 0x0e, 0xc4, 0xd5, 0x07, 0x30, 0xdd, 0x22, 0x73,
    0xd9, 0x59, 0x7e, 0x4d, 0xff, 0x52, 0x35, 0x6e, 0x97, 0x2f, 0xca, 0xba,
    0xff, 0xd4, 0xca, 0xb8, 0xa1, 0xdf, 0x17, 0xf0, 0xf4, 0xf7, 0xa1, 0xc3,
    0x87, 0x06, 0x8e, 0x9d, 0x1f, 0x4d, 0x3c, 0xb3, 0x21, 0xe7, 0xd7, 0x49,
    0x57, 0xe6, 0xb9, 0x5d, 0x5c, 0xa5, 0xcd, 0x1b, 0xa3, 0x68, 0xd9, 0x7c,
    0x37, 0x3b, 0xc9, 0x6a, 0x3a, 0x9f, 0x6a, 0x96, 0xd9, 0x67, 0x9c, 0xb5,
    0xf5, 0x75, 0x80, 0x47, 0x3f, 0x17, 0x83, 0x47, 0x86, 0x8e, 0xce, 0x1e,
    0x1c, 0x7c, 0x5e, 0xfd, 0x89, 0xcf, 0x58, 0xaa, 0xa6, 0xb9, 0xfc, 0x43,
    0x8a, 0x8e, 0xde, 0x10, 0x4a, 0x48, 0xa1, 0x56, 0xf2, 0xe2, 0x13, 0x61,
    0x7e, 0xbb, 0x3e, 0x87, 0xad, 0x55, 0x7f, 0x2c, 0x05, 0x1a, 0xfb, 0xe5,
    0xb8, 0xac, 0x29, 0x7f, 0xcf, 0xbc, 0x23, 0x3e, 0x3c, 0x3e, 0x9c, 0xd8,
    0xab, 0x4e, 0xd6, 0x3e, 0xe0, 0xd6, 0xda, 0x02, 0x57, 0x27, 0x17, 0xd9,
    0x6d, 0x3f, 0xc7, 0xce, 0xe8, 0x30, 0x59, 0xfd, 0x2e, 0x19, 0x23, 0x83,
    0x66, 0xfc, 0x89, 0x12, 0xf1, 0xe1, 0x06, 0xc5, 0x5e, 0xff, 0xaa, 0x67,
    0x3f, 0x80, 0x02, 0xc0, 0x18, 0x3b, 0x06, 0x63, 0x23, 0x07, 0x52, 0x72,
    0x9a, 0xe5, 0xd2, 0x12, 0x53, 0x5f, 0x6a, 0x8c, 0x38, 0x07, 0x79, 0xfb,
    0xc8, 0x3b, 0x68, 0x57, 0x4c, 0x9a, 0x57, 0x62, 0x6c, 0x15, 0x3b, 0xa9,
    0x39, 0x75, 0x5c, 0x5c, 0x94, 0x90, 0x07, 0xa9, 0x70, 0xac, 0x75, 0x85,
    0x64, 0x2f, 0xfb, 0x5c, 0x8f, 0x50, 0x17, 0xab, 0x69, 0x32, 0x29, 0x8b,
    0xc7, 0xd5, 0x67, 0x79, 0xe3, 0xd0, 0x19, 0x2c, 0x2c, 0xde, 0x3c, 0x7c,
    0x8e, 0x2e, 0x7f, 0x17, 0xdf, 0xe4, 0xbe, 0x62, 0x6e, 0xe6, 0x35, 0x3a,
    0x02, 0x9d, 0x34, 0x83, 0x05, 0x2c, 0xb1, 0x36, 0xda, 0x02, 0xf8, 0x95,
    0xe0, 0x23, 0x46, 0xd3, 0xc0, 0x2c, 0x9a, 0x44, 0x7b, 0x22, 0xbc, 0xb2,
    0xe7, 0x65, 0x6c, 0xaa, 0xd4, 0xa8, 0x92, 0x8c, 0xf4, 0xa1, 0x12, 0xa4,
    0xe2, 0x58, 0x04, 0x14, 0x95, 0x98, 0x1a, 0xc7, 0xf2, 0xd4, 0x70, 0x9d,
    0x82, 0xaf, 0x05, 0x90, 0x6b, 0x5e, 0x7b, 0xb9, 0xa0, 0x23, 0x22, 0x0e,
    0x66, 0x3d, 0xcf, 0x84, 0xf6, 0x16, 0x2f, 0xf6, 0x9f, 0xc6, 0x74, 0x8b,
    0x9c, 0x9b, 0x1f, 0x63, 0x26, 0x3b, 0x4b, 0xa5, 0x5e, 0x63, 0x73, 0xb8,
    0x9f, 0xa0, 0x7f, 0x03, 0xb2, 0xaa, 0x23, 0x1b, 0x72, 0xa1, 0xb5, 0x83,
    0xe2, 0x52, 0x7d, 0xaa, 0x47, 0x24, 0x89, 0x05, 0x93, 0xf8, 0x9c, 0x08,
    0x17, 0xb5, 0xaf, 0x79, 0x2f, 0x7d, 0x16, 0xdd, 0x5e, 0xe6, 0xd2, 0xe2,
    0x25, 0x34, 0x73, 0x89, 0x58, 0x30, 0xce, 0x43, 0xd1, 0xad, 0x34, 0x1b,
    0x0e, 0x56, 0xce, 0x02, 0x97, 0x2f, 0x5a, 0x0e, 0x8c, 0x95, 0xfa, 0x65,
    0x6d, 0x79, 0xf1, 0x66, 0xbc, 0xad, 0x77, 0xdb, 0x96, 0xd0, 0x76, 0xba,
    0x7d, 0x49, 0xae, 0x65, 0xaf, 0x91, 0xab, 0x14, 0x78, 0x38, 0x3a, 0x44,
    0x34, 0xd0, 0x45, 0xa2, 0x7d, 0x23, 0xf9, 0xba, 0xc1, 0x2d, 0x2d, 0x43,
    0xe5, 0xae, 0x9d, 0x45, 0xe1, 0xc3, 0x75, 0x7f, 0xd0, 0x7b, 0x3a, 0x74,
    0xa2, 0xef, 0xc1, 0x2d, 0xef, 0xee, 0xda, 0x35, 0x4c, 0x22, 0x9c, 0xc4,
    0x23, 0x05, 0x0d, 0xd7, 0x41, 0xf5, 0xaa, 0xb8, 0x12, 0x56, 0x4a, 0x2b,
    0x4c, 0xff, 0x3e, 0xcd, 0x8d, 0x99, 0x1b, 0x58, 0x65, 0xeb, 0x84, 0xfc,
    0x44, 0xbe, 0xbf, 0x0e, 0x20, 0x84, 0x50, 0x92, 0x63, 0x3d, 0x1f, 0xc7,
    0x12, 0xdd, 0x2f, 0x0c, 0x0c, 0x6c, 0x67, 0x63, 0x6c, 0x13, 0x01, 0x5f,
    0x80, 0x72, 0xd5, 0x26, 0x73, 0x47, 0xe7, 0x8f, 0xf9, 0x14, 0x19, 0x4d,
    0xc7, 0x5e, 0xb3, 0x27, 0xe4, 0x47, 0xf2, 0xf8, 0xbf, 0x66, 0xa1, 0xf3,
    0x64, 0xf8, 0xd5, 0xf6, 0xb6, 0xf0, 0x4b, 0xe1, 0xce, 0x8e, 0x4d, 0x3e,
    0xbf, 0x1f, 0xab, 0x6c, 0x91, 0xcf, 0xe7, 0x31, 0x2d, 0xf3, 0xba, 0x5b,
    0x73, 0xcf, 0xc8, 0xf3, 0xf2, 0xc2, 0x7f, 0x86, 0x09, 0x40, 0x1c, 0x6d,
    0xeb, 0x0b, 0x7a, 0xe5, 0x53, 0xd2, 0x95, 0x4f, 0x38, 0xb8, 0x76, 0xd3,
    0x6d, 0x4c, 0xd1, 0xe0, 0x67, 0xf9, 0xa9, 0xcc, 0xdd, 0xab, 0xfd, 0x0b,
    0x00, 0xfa, 0x59, 0xcc, 0xd3, 0xcb, 0xae, 0x5e, 0x00, 0x00, 0x00, 0x00,
    0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image9_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xe0, 0x77, 0x3d, 0xf8, 0x00, 0x00, 0x05,
    0xb3, 0x49, 0x44, 0x41, 0x54, 0x48, 0x89, 0xb5, 0xd5, 0x5d, 0x88, 0x9c,
    0x57, 0x19, 0xc0, 0xf1, 0xff, 0x79, 0xdf, 0xf3, 0xce, 0x3b, 0x1f, 0x3b,
    0xfb, 0x35, 0xd9, 0xcf, 0xd9, 0xdd, 0xb0, 0x4d, 0x9a, 0x74, 0xb3, 0xa9,
    0x4d, 0x4a, 0xa1, 0xd5, 0x88, 0x9a, 0x84, 0x14, 0xb1, 0xf1, 0xae, 0x05,
    0x0b, 0x21, 0x17, 0x0a, 0x6d, 0xd1, 0x8b, 0x94, 0x18, 0x85, 0x2a, 0x18,
    0xa7, 0x20, 0x68, 0xc1, 0x8a, 0x17, 0x45, 0x8d, 0x6d, 0xc0, 0x5a, 0x6c,
    0x9b, 0x16, 0x7a, 0x61, 0x50, 0xa4, 0x14, 0xb6, 0xc5, 0x46, 0x92, 0x1a,
    0x93, 0x35, 0xd9, 0xa6, 0x16, 0x93, 0xcd, 0x7e, 0xcc, 0x76, 0x37, 0xb3,
    0x33, 0xb3, 0xf3, 0xf5, 0xce, 0xfb, 0x75, 0xce, 0xf1, 0x22, 0x1a, 0x92,
    0xee, 0xf6, 0xd2, 0x07, 0xce, 0xcd, 0x39, 0xf0, 0xfc, 0x78, 0xce, 0x39,
    0x0f, 0x8f, 0x30, 0xc6, 0xf0, 0xff, 0x0c, 0xf9, 0xd9, 0x47, 0x42, 0x4c,
    0x15, 0xb0, 0xa3, 0x14, 0xfd, 0x5e, 0x93, 0x9c, 0xd1, 0xec, 0x8c, 0x22,
    0xee, 0xd2, 0x86, 0xd1, 0x58, 0x11, 0x87, 0x0a, 0x4b, 0xc5, 0x54, 0x6d,
    0x87, 0xcb, 0x91, 0xc7, 0x9f, 0x9e, 0xf8, 0x8d, 0xa9, 0x6d, 0x98, 0x65,
    0xa3, 0x0a, 0xde, 0x3f, 0x29, 0xb2, 0x56, 0x8b, 0x83, 0x61, 0xc0, 0x5e,
    0xa5, 0xe5, 0x57, 0xec, 0xa4, 0x3d, 0x8e, 0x93, 0x90, 0x42, 0x38, 0x44,
    0x91, 0x42, 0xc5, 0x8a, 0x58, 0x19, 0x02, 0x5f, 0x51, 0x2d, 0x07, 0x28,
    0x65, 0xa6, 0x54, 0xc4, 0xd1, 0xa7, 0x7e, 0xcd, 0x45, 0x3e, 0x95, 0x70,
    0x1d, 0xf0, 0xc1, 0x0b, 0x62, 0xd2, 0x08, 0x5e, 0xb2, 0x1c, 0xf7, 0xc1,
    0x8e, 0xe1, 0xed, 0x64, 0xfa, 0x27, 0x48, 0xf7, 0x4e, 0xe2, 0x66, 0xf3,
    0x48, 0x37, 0x85, 0xc0, 0xc1, 0x68, 0x0f, 0x63, 0x5a, 0x34, 0x57, 0x2e,
    0x71, 0xf6, 0xf4, 0xeb, 0x2c, 0xce, 0x55, 0xd0, 0x9a, 0x6a, 0x14, 0xf3,
    0xf8, 0x91, 0x13, 0xe6, 0x2f, 0x9f, 0x09, 0x14, 0x0a, 0xc2, 0xda, 0xd7,
    0xc9, 0x9f, 0x33, 0x5d, 0xe9, 0x87, 0xc7, 0xf7, 0x3e, 0x4d, 0xcf, 0xf8,
    0x61, 0x60, 0x00, 0x58, 0xc3, 0xe8, 0x32, 0xca, 0x2f, 0x12, 0x87, 0x15,
    0xe2, 0xf6, 0x0a, 0x2a, 0x5c, 0x43, 0x4a, 0x9b, 0xe9, 0xa9, 0x3f, 0x32,
    0xfd, 0xfe, 0x3f, 0x31, 0x40, 0x1c, 0xb1, 0x1c, 0x29, 0xf6, 0x7f, 0xf7,
    0xa4, 0xf9, 0x70, 0xc3, 0x37, 0xd8, 0x9b, 0xe5, 0x3e, 0x03, 0xfb, 0xfb,
    0x77, 0x3e, 0x42, 0xcf, 0xf8, 0x4f, 0x00, 0x1f, 0x15, 0xbe, 0x43, 0xd8,
    0x9e, 0x26, 0x6a, 0x2d, 0xa3, 0x7c, 0x8f, 0x38, 0x68, 0x12, 0x87, 0x6d,
    0x74, 0x18, 0x20, 0x80, 0x76, 0xb3, 0x8e, 0xd6, 0xa0, 0x0d, 0x28, 0xc3,
    0x20, 0x82, 0xdf, 0x3e, 0xf7, 0x2d, 0xf1, 0xd5, 0xef, 0xbf, 0x64, 0x1a,
    0x00, 0xd6, 0xed, 0x40, 0x1c, 0xf3, 0x35, 0xdb, 0xb5, 0xec, 0xdc, 0xb6,
    0xc7, 0xc0, 0x44, 0xe8, 0xf8, 0x14, 0x4a, 0x9d, 0xc3, 0x22, 0xc2, 0x96,
    0x59, 0x2c, 0x27, 0x83, 0xed, 0x64, 0x91, 0x4e, 0x16, 0xe9, 0x66, 0xb1,
    0x93, 0x59, 0x64, 0xc2, 0xc5, 0xb6, 0xe5, 0xcd, 0x25, 0x2d, 0x40, 0x7c,
    0xc1, 0x44, 0x7c, 0x63, 0xc3, 0x0a, 0x62, 0xc5, 0xce, 0x4c, 0x66, 0x13,
    0xa9, 0xae, 0x09, 0x10, 0x97, 0x11, 0x72, 0x99, 0x84, 0xec, 0x47, 0x25,
    0x3d, 0x8c, 0xa7, 0x50, 0x11, 0x18, 0xa3, 0x00, 0x03, 0xc2, 0x46, 0x58,
    0x36, 0xc3, 0x5b, 0xee, 0x22, 0x99, 0xce, 0xa2, 0xe3, 0x36, 0xb5, 0x52,
    0x89, 0x99, 0xe9, 0x12, 0xc6, 0xd0, 0xbb, 0x0e, 0x28, 0x14, 0x84, 0xf5,
    0x90, 0xcd, 0xb0, 0xdb, 0x99, 0x07, 0x31, 0x84, 0xe2, 0x5d, 0x82, 0x72,
    0x15, 0xdd, 0x6a, 0x60, 0xec, 0x18, 0xe1, 0x44, 0xd8, 0x69, 0x01, 0xd2,
    0x21, 0x28, 0x07, 0x20, 0x6c, 0xb0, 0x24, 0xb9, 0x7c, 0x9e, 0x81, 0xd1,
    0x21, 0xe2, 0x56, 0x85, 0x8f, 0xff, 0xd1, 0x46, 0x99, 0x1b, 0xca, 0xc0,
    0x99, 0x75, 0xc0, 0xee, 0x90, 0xbe, 0xa8, 0x83, 0x7e, 0x27, 0xd7, 0x43,
    0xf3, 0xe2, 0x39, 0x16, 0xdf, 0x7a, 0x91, 0xda, 0x99, 0xf3, 0xb4, 0x57,
    0x35, 0x91, 0x2d, 0x30, 0x43, 0x9d, 0xe4, 0xf6, 0x8d, 0x30, 0xb8, 0xa7,
    0x9f, 0xf4, 0x60, 0x92, 0xb8, 0xad, 0x11, 0xd8, 0x18, 0x23, 0x08, 0x43,
    0x4d, 0xd8, 0xf6, 0x29, 0x2e, 0xd4, 0x51, 0x9a, 0xf9, 0x30, 0xe6, 0xea,
    0x3a, 0xc0, 0xda, 0x85, 0xab, 0x66, 0x49, 0xd5, 0x4e, 0x5e, 0x60, 0xf6,
    0xf2, 0x31, 0x42, 0x3b, 0x4b, 0xd2, 0xfd, 0x1c, 0x69, 0xd9, 0xa4, 0x55,
    0xaf, 0x51, 0x99, 0x59, 0xe4, 0xf2, 0xe9, 0xab, 0x5c, 0xb9, 0x2f, 0xc7,
    0xfd, 0xdf, 0xdb, 0xc5, 0xd0, 0x97, 0x47, 0x30, 0xbe, 0x8d, 0xc1, 0xc2,
    0x18, 0x40, 0x87, 0x54, 0xab, 0x6d, 0xd0, 0x5c, 0x3d, 0xfe, 0xaa, 0x59,
    0x5a, 0x07, 0x68, 0x97, 0x84, 0x7c, 0x93, 0xce, 0xc4, 0x5c, 0x07, 0x83,
    0x47, 0x1e, 0xa7, 0xef, 0xde, 0x21, 0x74, 0x79, 0x19, 0x53, 0x2e, 0x11,
    0xaf, 0x56, 0x68, 0x2e, 0x8e, 0xb2, 0x78, 0xee, 0x63, 0xce, 0x4f, 0x5f,
    0xe7, 0x9d, 0xa3, 0x67, 0xd8, 0xf7, 0xf3, 0x3d, 0x8c, 0x1d, 0xd8, 0x4a,
    0x58, 0x37, 0x20, 0x34, 0xed, 0x96, 0x8f, 0xdf, 0x8e, 0x30, 0x82, 0xd5,
    0xdb, 0xdf, 0xf5, 0x16, 0xa0, 0xbe, 0xcd, 0x9e, 0x9c, 0x97, 0xeb, 0x99,
    0x7c, 0xa1, 0x40, 0xaa, 0x3f, 0xa0, 0xf1, 0xf2, 0xaf, 0x90, 0xab, 0x2b,
    0x04, 0x9e, 0xa1, 0x72, 0xfd, 0x06, 0xb2, 0x6f, 0x98, 0x9e, 0xa1, 0x2c,
    0xbb, 0xfd, 0x3e, 0xde, 0x9b, 0x2f, 0xf1, 0xd7, 0x1f, 0x9d, 0xe3, 0xeb,
    0x13, 0x03, 0x64, 0x06, 0xbb, 0x88, 0x1a, 0x10, 0xb4, 0x03, 0xb4, 0xd6,
    0x18, 0x45, 0xe3, 0x76, 0xc0, 0x02, 0x78, 0x43, 0x88, 0x0e, 0xa7, 0xc8,
    0x91, 0xcd, 0x87, 0x1f, 0x25, 0x25, 0x96, 0x29, 0x3e, 0xff, 0x0b, 0x6e,
    0x0c, 0xdc, 0x4f, 0xf3, 0x9e, 0x2f, 0xb1, 0x60, 0xba, 0x90, 0x87, 0xbe,
    0x43, 0xd0, 0xd1, 0x4d, 0x79, 0x76, 0x01, 0x63, 0x09, 0xb6, 0x67, 0x92,
    0x2c, 0xcc, 0xd6, 0xb9, 0xfe, 0xf6, 0x02, 0x32, 0x65, 0x83, 0xf8, 0xef,
    0x2d, 0x68, 0x0b, 0xad, 0xc9, 0xae, 0x03, 0xda, 0xb0, 0xbf, 0x73, 0x64,
    0x70, 0xf7, 0xa6, 0xcd, 0xbd, 0xac, 0xbd, 0xf6, 0x0a, 0xfe, 0xce, 0x7d,
    0x8c, 0xfe, 0xec, 0x04, 0xe9, 0x27, 0x7f, 0x48, 0xdf, 0xb1, 0x67, 0x19,
    0x79, 0xe6, 0x38, 0xa3, 0xcf, 0xfd, 0x12, 0x39, 0x3c, 0x42, 0xbd, 0xd1,
    0xa2, 0xc3, 0x4d, 0xd0, 0x05, 0xcc, 0xfd, 0xed, 0x13, 0xc2, 0x86, 0xc2,
    0x92, 0x0e, 0xa9, 0x8c, 0x8b, 0x65, 0x59, 0x68, 0xcd, 0x60, 0xa1, 0x20,
    0xac, 0x3b, 0x00, 0x05, 0x07, 0xe5, 0xe0, 0x00, 0xfa, 0xfa, 0xbf, 0x30,
    0x4d, 0x1f, 0xb7, 0xf8, 0x6f, 0x5a, 0x17, 0xfe, 0x4e, 0x66, 0xdb, 0x0e,
    0x06, 0x0f, 0x1c, 0xc0, 0x52, 0x01, 0xd1, 0xc2, 0x3c, 0x7e, 0xd3, 0x83,
    0xa4, 0x0b, 0xae, 0x43, 0x8f, 0x25, 0x59, 0x99, 0x29, 0x13, 0xb6, 0x2c,
    0x64, 0x2a, 0x4b, 0xaa, 0xb3, 0x9b, 0x5c, 0x5f, 0x0a, 0x23, 0xd8, 0xc1,
    0x0c, 0x23, 0x77, 0x00, 0x1a, 0xee, 0x89, 0xbc, 0x16, 0x61, 0xf1, 0x13,
    0xda, 0xf5, 0x80, 0xd5, 0xc5, 0x12, 0xa6, 0x56, 0x86, 0x76, 0x05, 0x42,
    0x1f, 0x5a, 0x75, 0x56, 0xcf, 0x9e, 0xa5, 0x59, 0xae, 0x92, 0xe8, 0xee,
    0x26, 0x91, 0x4e, 0xa2, 0xb0, 0xb0, 0xdd, 0x04, 0xd2, 0x4d, 0x63, 0xb9,
    0x69, 0x64, 0x3a, 0xc7, 0xe8, 0x78, 0x0f, 0xc6, 0x88, 0x7e, 0x0c, 0x0f,
    0xdc, 0x01, 0x04, 0x50, 0x8c, 0x6a, 0x55, 0x74, 0xa8, 0xf1, 0x7d, 0x4d,
    0x7a, 0xeb, 0x04, 0xbd, 0x9f, 0x7f, 0x10, 0x42, 0x9f, 0x78, 0x71, 0x1e,
    0x12, 0x0e, 0xf9, 0xa7, 0x9e, 0x64, 0xf4, 0xf0, 0x21, 0xdc, 0x84, 0x8d,
    0x74, 0x24, 0x25, 0x1d, 0x91, 0xbb, 0x7b, 0x13, 0x6e, 0xd6, 0xc1, 0x28,
    0x83, 0x65, 0xbb, 0x6c, 0xea, 0xeb, 0x22, 0x9d, 0x76, 0xd0, 0x82, 0x6f,
    0x7e, 0x1a, 0x98, 0x5a, 0x5d, 0x6d, 0xe0, 0xcb, 0x24, 0xe9, 0xb1, 0x31,
    0xac, 0x6b, 0x1f, 0xb1, 0xfa, 0xbb, 0x17, 0x29, 0xbd, 0xf2, 0x32, 0x57,
    0x8e, 0x3e, 0xcd, 0xda, 0xf9, 0x0b, 0x88, 0x46, 0x03, 0xe9, 0x37, 0xe8,
    0xca, 0x66, 0x28, 0x7a, 0x21, 0x6d, 0x0c, 0x63, 0xbb, 0x92, 0xb8, 0x4e,
    0x09, 0xe3, 0xad, 0xa0, 0xc2, 0x3a, 0xa9, 0x94, 0xcd, 0xf0, 0x90, 0x83,
    0x52, 0x3c, 0x5c, 0x78, 0x54, 0x3c, 0x70, 0xeb, 0x9b, 0xfa, 0xf0, 0x46,
    0x45, 0xe9, 0xa3, 0x1f, 0x5d, 0xba, 0x76, 0xf7, 0xbd, 0x3b, 0xc6, 0xc8,
    0xe4, 0x12, 0xb4, 0xde, 0x3e, 0x4d, 0x18, 0x29, 0xec, 0xc8, 0xa3, 0xfa,
    0xe6, 0xab, 0x78, 0xc9, 0x04, 0xd6, 0xb5, 0x39, 0x96, 0x1a, 0x6d, 0x3e,
    0x5c, 0x6a, 0xe0, 0x66, 0x6d, 0x96, 0xd4, 0x02, 0xef, 0xbd, 0x55, 0x25,
    0x93, 0x72, 0xe9, 0xee, 0x92, 0x24, 0x45, 0x13, 0x47, 0x2a, 0x0c, 0x38,
    0xd8, 0xfc, 0x18, 0x38, 0x78, 0x6b, 0x1e, 0x3c, 0x2f, 0xe5, 0xa1, 0x94,
    0x9b, 0xf8, 0xfd, 0xe4, 0x96, 0x3c, 0x5b, 0xb6, 0xe4, 0x49, 0x64, 0x53,
    0x08, 0x29, 0xc1, 0x91, 0x04, 0xf5, 0x16, 0x5e, 0xa5, 0xce, 0xdc, 0x72,
    0x95, 0x4b, 0xf3, 0x2b, 0xd4, 0xfc, 0x26, 0xc9, 0x2f, 0x6a, 0xc4, 0x18,
    0xe8, 0x10, 0xa4, 0x63, 0x93, 0x70, 0x25, 0xd2, 0x36, 0x34, 0x1a, 0x11,
    0xbe, 0xaf, 0x11, 0x02, 0x8e, 0xbf, 0x66, 0xc4, 0xad, 0x46, 0xeb, 0x50,
    0xea, 0xf5, 0xba, 0x1f, 0x8d, 0x5f, 0x9c, 0x5d, 0x7a, 0xb6, 0x58, 0xf5,
    0x18, 0x1e, 0xea, 0x26, 0x93, 0x49, 0x11, 0x2b, 0xcd, 0x5a, 0xdd, 0xa3,
    0x58, 0x5e, 0xa3, 0x54, 0x6d, 0x10, 0x78, 0x61, 0xd5, 0xda, 0x6a, 0x4e,
    0x59, 0x9b, 0x4d, 0x3a, 0xf2, 0x19, 0x56, 0x8a, 0x6d, 0x7e, 0x18, 0x8f,
    0xd2, 0x8c, 0x6f, 0xde, 0xb9, 0x05, 0x42, 0xe0, 0x09, 0x38, 0x76, 0x47,
    0x27, 0x3f, 0x61, 0x4c, 0x74, 0x42, 0x88, 0x9f, 0x96, 0xa2, 0xf8, 0xa2,
    0x57, 0x8b, 0x7e, 0xb0, 0x50, 0xaf, 0x3f, 0x64, 0xdb, 0x36, 0x46, 0x1b,
    0x82, 0x20, 0x22, 0x0a, 0xc2, 0x0a, 0x46, 0xfd, 0x41, 0xc3, 0x49, 0x3b,
    0xcf, 0x15, 0xa7, 0x13, 0x61, 0x85, 0x58, 0xad, 0x98, 0xbc, 0x6d, 0xd8,
    0x6c, 0x6c, 0xf2, 0x18, 0xb6, 0x03, 0x35, 0x60, 0x6a, 0x42, 0xf3, 0x01,
    0x6c, 0x30, 0x93, 0x85, 0x10, 0xe2, 0x99, 0x3c, 0xbd, 0xf2, 0x06, 0x23,
    0x44, 0xf6, 0x24, 0x90, 0xd4, 0xa8, 0x92, 0x82, 0x99, 0x24, 0xcc, 0x1f,
    0x37, 0x26, 0x66, 0x83, 0x28, 0x14, 0x84, 0xb5, 0x63, 0xe6, 0x66, 0x4f,
    0x3f, 0x76, 0xca, 0xa8, 0xff, 0xed, 0xff, 0x07, 0x21, 0xbe, 0xc3, 0x9a,
    0xcc, 0x2a, 0xfe, 0x4e, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44,
    0xae, 0x42, 0x60, 0x82
};

static const unsigned char image10_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x18,
    0x08, 0x06, 0x00, 0x00, 0x00, 0xe0, 0x77, 0x3d, 0xf8, 0x00, 0x00, 0x05,
    0xcf, 0x49, 0x44, 0x41, 0x54, 0x48, 0x89, 0xb5, 0xd5, 0x5d, 0x6c, 0x5c,
    0x47, 0x15, 0xc0, 0xf1, 0xff, 0xdc, 0x8f, 0xbd, 0xfb, 0xe9, 0xb5, 0xbd,
    0xf1, 0x6e, 0xd6, 0x5b, 0x27, 0xb5, 0x63, 0x37, 0x76, 0xec, 0x08, 0x15,
    0x82, 0x62, 0xb5, 0x02, 0x1a, 0x82, 0x2a, 0xa0, 0x51, 0x79, 0xa1, 0x28,
    0x08, 0x54, 0x21, 0x22, 0x41, 0x24, 0x1e, 0x0a, 0xa5, 0xca, 0x43, 0xfb,
    0x10, 0xb6, 0x02, 0x84, 0x10, 0x12, 0x12, 0x08, 0x44, 0x83, 0x1a, 0x1e,
    0x90, 0x0a, 0x4d, 0x85, 0x0a, 0x02, 0xb5, 0xaa, 0xda, 0xb4, 0x6e, 0x21,
    0x45, 0x89, 0x21, 0x8a, 0xe3, 0xb8, 0x24, 0xb6, 0x9c, 0xd8, 0xae, 0x1d,
    0x7f, 0xad, 0x77, 0xbd, 0x9f, 0x77, 0xf7, 0xde, 0x3b, 0x33, 0x3c, 0x14,
    0xa2, 0x18, 0xbb, 0x8f, 0x8c, 0x34, 0x2f, 0x33, 0xd2, 0xf9, 0xe9, 0xcc,
    0x99, 0xa3, 0x23, 0xb4, 0xd6, 0xfc, 0x3f, 0x97, 0xf5, 0xe1, 0x57, 0x42,
    0x8c, 0xe5, 0x31, 0xfd, 0x08, 0xe9, 0x46, 0x8d, 0x94, 0x56, 0x8c, 0xf8,
    0x3e, 0x7d, 0x4a, 0xd3, 0x13, 0x48, 0x02, 0x4f, 0x62, 0xc8, 0x80, 0x92,
    0x69, 0x73, 0xcd, 0x6f, 0xf0, 0xca, 0x37, 0x9e, 0xd3, 0xe5, 0x1d, 0xa3,
    0xec, 0x94, 0xc1, 0x85, 0xb3, 0x22, 0x61, 0xd4, 0x39, 0xe6, 0xb5, 0x38,
    0x22, 0x95, 0xf5, 0x90, 0x19, 0x36, 0x7b, 0xb1, 0x43, 0x96, 0x10, 0x36,
    0xbe, 0x2f, 0x91, 0x81, 0x24, 0x90, 0x9a, 0x56, 0x53, 0x52, 0xda, 0x68,
    0x21, 0xa5, 0x1e, 0x93, 0x3e, 0x4f, 0x9e, 0xfc, 0x15, 0x57, 0xf8, 0x9f,
    0x80, 0xdb, 0x80, 0xf1, 0x5f, 0x88, 0x61, 0x2d, 0x78, 0xde, 0xb0, 0x9d,
    0xc3, 0xf1, 0xee, 0xfd, 0xc4, 0xd2, 0x43, 0x44, 0x3b, 0x87, 0x71, 0x12,
    0x39, 0x2c, 0x27, 0x82, 0xc0, 0x46, 0xab, 0x06, 0x5a, 0xd7, 0xa9, 0xad,
    0x4e, 0x72, 0xf1, 0x2f, 0x2f, 0xb2, 0x38, 0x5f, 0x44, 0x29, 0x4a, 0x7e,
    0xc0, 0x97, 0x9f, 0x38, 0xa3, 0x5f, 0xfb, 0x50, 0x20, 0x9f, 0x17, 0xc6,
    0xa7, 0xdb, 0x78, 0x35, 0x96, 0x8c, 0x3e, 0xdc, 0x7b, 0xe4, 0xdb, 0x74,
    0xf4, 0x3e, 0x0e, 0x64, 0x80, 0x4d, 0xb4, 0xda, 0x40, 0x36, 0x97, 0x08,
    0xbc, 0x22, 0x81, 0xbb, 0x8a, 0xf4, 0x36, 0xb1, 0x2c, 0x93, 0x89, 0xb1,
    0x3f, 0x33, 0x71, 0xe1, 0x2a, 0x1a, 0x08, 0x7c, 0x56, 0x7c, 0xc9, 0xd1,
    0xef, 0x9e, 0xd5, 0xef, 0xed, 0x58, 0x83, 0x23, 0x09, 0x3e, 0xa2, 0xe1,
    0x68, 0x7a, 0xe4, 0x11, 0x3a, 0x7a, 0x7f, 0x00, 0x34, 0x91, 0xde, 0x79,
    0x3c, 0x77, 0x02, 0xbf, 0xbe, 0x82, 0x6c, 0x36, 0x08, 0x5a, 0x35, 0x02,
    0xcf, 0x45, 0x79, 0x2d, 0x04, 0xe0, 0xd6, 0x2a, 0x28, 0x05, 0x4a, 0x83,
    0xd4, 0xec, 0x46, 0xf0, 0xeb, 0x1f, 0x9f, 0x10, 0x9f, 0x3d, 0xf5, 0xbc,
    0xae, 0x02, 0x18, 0x77, 0x03, 0x41, 0xc0, 0xe7, 0x4d, 0xc7, 0x30, 0x53,
    0xf7, 0x3d, 0x06, 0xf8, 0x48, 0x79, 0x0e, 0xa9, 0xc6, 0x11, 0x22, 0xc0,
    0xb0, 0x13, 0x18, 0x76, 0x0c, 0xd3, 0x4e, 0x60, 0xd9, 0x09, 0x2c, 0x27,
    0x81, 0x19, 0x4e, 0x60, 0x85, 0x1c, 0x4c, 0xd3, 0xfa, 0x60, 0x5b, 0x06,
    0x20, 0x1e, 0xd0, 0x3e, 0xc7, 0x77, 0xcc, 0x20, 0x90, 0x8c, 0xc4, 0x62,
    0x5d, 0x44, 0x92, 0x43, 0xa0, 0x26, 0x31, 0xd5, 0x6d, 0x4c, 0xb3, 0x13,
    0x2c, 0x17, 0xe9, 0xfb, 0xb8, 0x80, 0xaf, 0x15, 0xa0, 0x41, 0x98, 0x08,
    0xc3, 0xa4, 0x7b, 0x5f, 0x1f, 0xe1, 0x68, 0x02, 0x15, 0xb8, 0x94, 0xd7,
    0xd7, 0x99, 0x9a, 0x58, 0x47, 0x6b, 0x3a, 0xb7, 0x01, 0xf9, 0xbc, 0x30,
    0x46, 0x2d, 0xba, 0xc3, 0x89, 0x6e, 0x10, 0x69, 0xf0, 0xde, 0xa1, 0x56,
    0x2b, 0xd3, 0x54, 0x0d, 0x84, 0xf6, 0x09, 0x4b, 0x9f, 0xa8, 0xd0, 0x38,
    0x96, 0xc9, 0xa6, 0x0f, 0x18, 0x26, 0x18, 0x16, 0xa9, 0x5c, 0x8e, 0x4c,
    0x4f, 0x96, 0xa0, 0x5e, 0x64, 0xfa, 0xb2, 0x8b, 0xd4, 0x6b, 0x52, 0xc3,
    0xbb, 0xdb, 0x80, 0xfb, 0x6d, 0xba, 0xf0, 0x48, 0xc7, 0xec, 0x36, 0xe6,
    0x6b, 0x93, 0xfc, 0xfd, 0xe6, 0xcb, 0x4c, 0x16, 0xae, 0x71, 0xdb, 0xf5,
    0x51, 0x4d, 0x45, 0x27, 0x11, 0x46, 0x3b, 0x77, 0x71, 0x38, 0x95, 0x22,
    0xe3, 0x84, 0x68, 0x28, 0x85, 0x32, 0x4c, 0xb4, 0x16, 0x78, 0x9e, 0xc2,
    0x73, 0x9b, 0x2c, 0xbd, 0x5f, 0x41, 0x2a, 0x16, 0xbc, 0x80, 0xd9, 0x6d,
    0x40, 0xae, 0x82, 0x53, 0x70, 0x88, 0x8c, 0x05, 0x73, 0xdc, 0x9a, 0xfd,
    0x39, 0xad, 0x56, 0x18, 0xbb, 0xfd, 0x53, 0x84, 0x92, 0x15, 0x2a, 0xb5,
    0x3a, 0x17, 0x56, 0xae, 0xf3, 0x87, 0xab, 0x17, 0x19, 0x36, 0xdb, 0x38,
    0x75, 0x70, 0x98, 0xd1, 0x6c, 0x16, 0x57, 0x98, 0x68, 0x61, 0xa0, 0x35,
    0xa0, 0x3c, 0x4a, 0x25, 0x17, 0x14, 0xb3, 0xa7, 0x7f, 0xa7, 0x6f, 0x6f,
    0x03, 0x32, 0x55, 0x27, 0xf4, 0xc7, 0x3e, 0xdd, 0x56, 0xea, 0xe9, 0xe7,
    0x33, 0xd9, 0x47, 0x49, 0x76, 0x26, 0x69, 0x98, 0x65, 0xaa, 0xba, 0xc0,
    0x6a, 0xb9, 0x4c, 0xdf, 0xbd, 0x19, 0x2e, 0xdd, 0x9c, 0xe0, 0xcd, 0xf1,
    0x8b, 0xcc, 0xfd, 0xad, 0xc6, 0xcf, 0x1e, 0x38, 0xcc, 0x43, 0xbd, 0x7d,
    0x54, 0x02, 0x0d, 0x42, 0xe1, 0xd6, 0x9b, 0x34, 0x5d, 0x1f, 0x2d, 0x28,
    0xdc, 0x5d, 0xd7, 0x3b, 0xc0, 0xa9, 0x43, 0x91, 0x07, 0xed, 0x7d, 0x03,
    0x1d, 0x27, 0x0e, 0x3e, 0x85, 0xed, 0x14, 0xf9, 0x87, 0x7e, 0x85, 0xab,
    0x6b, 0x57, 0x98, 0x9c, 0x99, 0x43, 0x98, 0x06, 0xbb, 0x23, 0x03, 0x74,
    0x74, 0x24, 0xe8, 0x3f, 0xd0, 0xcd, 0x7b, 0xe3, 0xf3, 0x9c, 0x7a, 0xf7,
    0x9f, 0xbc, 0x9c, 0xea, 0x22, 0xd3, 0x96, 0xa4, 0x1e, 0x40, 0xcb, 0x6d,
    0xa1, 0x94, 0x42, 0x4b, 0xaa, 0xdb, 0x80, 0x23, 0x2f, 0xa5, 0xe3, 0xad,
    0xa4, 0xf5, 0xc4, 0x89, 0xbe, 0x2f, 0x51, 0xb3, 0x17, 0x78, 0xa7, 0xf5,
    0x02, 0x95, 0x56, 0x99, 0xd5, 0x69, 0xc5, 0xd7, 0xec, 0x67, 0x69, 0xc5,
    0x4b, 0x9c, 0x59, 0xff, 0x09, 0xc5, 0x6a, 0x93, 0x36, 0xb3, 0x8b, 0x8e,
    0x3d, 0x31, 0xae, 0x5c, 0xde, 0xe0, 0xd5, 0xb9, 0x45, 0x4e, 0x7e, 0xb4,
    0x93, 0xc6, 0x7f, 0x82, 0x29, 0x65, 0xa0, 0x14, 0x89, 0xbb, 0x01, 0x03,
    0x60, 0x6d, 0xad, 0x7c, 0x74, 0x4f, 0x6c, 0xe0, 0xfe, 0x78, 0x22, 0xce,
    0xdb, 0x9b, 0x7f, 0x62, 0x6e, 0xb6, 0xcc, 0xf2, 0x85, 0x38, 0x83, 0xcd,
    0x4f, 0x72, 0xf2, 0xf0, 0xb7, 0x78, 0x24, 0x73, 0x9c, 0x83, 0xc1, 0x27,
    0x68, 0x27, 0x45, 0xc5, 0xad, 0x62, 0x47, 0x43, 0x10, 0x37, 0x78, 0x7b,
    0x61, 0x85, 0xb2, 0x2f, 0x31, 0x4c, 0x9b, 0x48, 0xcc, 0xc1, 0x30, 0x0c,
    0x94, 0x62, 0x77, 0x3e, 0x2f, 0x8c, 0x2d, 0x80, 0x27, 0xc5, 0xb1, 0x5d,
    0x4e, 0x0f, 0xb3, 0xde, 0x14, 0x53, 0xcb, 0xd7, 0x49, 0x15, 0x86, 0xf8,
    0xe1, 0xc8, 0x6f, 0x78, 0x7a, 0xf4, 0xfb, 0xb8, 0xa2, 0xc1, 0xee, 0x8e,
    0x2c, 0x3f, 0xfd, 0xf8, 0x19, 0xbe, 0xb3, 0xff, 0x19, 0xea, 0x41, 0x93,
    0xb0, 0x15, 0xc1, 0x49, 0x84, 0x99, 0x58, 0x2e, 0x50, 0x91, 0x02, 0x3b,
    0x9c, 0x20, 0xd2, 0xd6, 0x4e, 0xaa, 0x2b, 0x82, 0x16, 0x1c, 0x60, 0x8a,
    0x7b, 0xb6, 0x00, 0x22, 0x30, 0x07, 0x2b, 0xad, 0x1a, 0xb3, 0xe5, 0x5b,
    0xac, 0x55, 0xab, 0x24, 0x3a, 0xe2, 0xb4, 0x65, 0x4d, 0xea, 0xa1, 0x2a,
    0x45, 0x55, 0xa2, 0x4c, 0x11, 0x2b, 0x66, 0xb2, 0x11, 0x14, 0x49, 0x3b,
    0x19, 0x12, 0xa1, 0x76, 0x84, 0x14, 0xd8, 0x86, 0x89, 0xe5, 0x44, 0x31,
    0x9d, 0x28, 0x56, 0x34, 0x45, 0x4f, 0x6f, 0x07, 0x5a, 0x8b, 0x34, 0x9a,
    0x43, 0x5b, 0x80, 0xc0, 0xb3, 0x96, 0x16, 0xab, 0xef, 0x63, 0xa9, 0x28,
    0xbb, 0x8c, 0x3d, 0x5c, 0xf3, 0x2f, 0xf3, 0x95, 0xd7, 0x1f, 0x65, 0xa6,
    0x74, 0x83, 0xac, 0xd1, 0xcd, 0x99, 0x99, 0x5f, 0xf2, 0x85, 0xf3, 0x9f,
    0xe3, 0x8d, 0x95, 0xd7, 0x19, 0x4c, 0x0d, 0xe3, 0x08, 0x87, 0x56, 0xc1,
    0xa3, 0xbf, 0x2b, 0x45, 0x9b, 0x13, 0x42, 0x69, 0x8d, 0x61, 0x3a, 0xec,
    0xea, 0x4a, 0x12, 0x8d, 0xda, 0x28, 0xc1, 0xd7, 0xb7, 0x00, 0xda, 0x17,
    0x63, 0x8b, 0xcb, 0x4b, 0xe4, 0xcc, 0x7e, 0xf6, 0xc6, 0x86, 0x50, 0x9e,
    0x43, 0x41, 0x6e, 0x32, 0x17, 0xdc, 0xe2, 0xad, 0xf2, 0x1b, 0x5c, 0xdf,
    0xbc, 0x41, 0x80, 0x26, 0x97, 0xe8, 0x21, 0xea, 0xc4, 0xa9, 0x2f, 0xd7,
    0xd1, 0x8d, 0x80, 0x07, 0xbb, 0x23, 0xc4, 0xe5, 0x3a, 0xca, 0x5d, 0x45,
    0x7a, 0x15, 0x22, 0x11, 0x93, 0xee, 0xac, 0x8d, 0x94, 0x3c, 0x9c, 0xff,
    0xa2, 0x38, 0x74, 0xe7, 0x17, 0xf9, 0xae, 0x7a, 0x09, 0x61, 0x3d, 0x79,
    0x7e, 0xfc, 0xb5, 0x81, 0x7b, 0x87, 0x06, 0xd8, 0x97, 0x18, 0x61, 0x6f,
    0x74, 0x90, 0xf1, 0xd2, 0x25, 0xc6, 0x8b, 0x97, 0x48, 0xc7, 0x32, 0xec,
    0x49, 0xf6, 0x51, 0x91, 0x55, 0xe6, 0x6e, 0xcc, 0x73, 0x73, 0x76, 0x8d,
    0x8e, 0x90, 0x20, 0x75, 0x63, 0x91, 0xbf, 0x6e, 0x94, 0x09, 0xb5, 0x39,
    0x24, 0x93, 0x16, 0x61, 0x51, 0xc3, 0xb6, 0x24, 0x1a, 0x6c, 0x4c, 0xbe,
    0x07, 0x1c, 0xbb, 0x33, 0x0f, 0x32, 0xcf, 0x24, 0xbf, 0x1a, 0x8d, 0x38,
    0xbf, 0xed, 0x1d, 0x1a, 0xa0, 0xbf, 0x6f, 0x3f, 0xe9, 0x78, 0x06, 0x4c,
    0x81, 0x52, 0x8a, 0x20, 0x90, 0x14, 0x2a, 0x1b, 0xcc, 0xcc, 0x4e, 0x73,
    0xfd, 0xda, 0x34, 0x8d, 0xc2, 0x06, 0xc7, 0x7d, 0xc5, 0x48, 0x20, 0x68,
    0x6a, 0xb0, 0x6c, 0x93, 0x90, 0x63, 0x61, 0x99, 0x9a, 0x6a, 0xd5, 0xa7,
    0xd9, 0x54, 0x08, 0x01, 0xa7, 0x7f, 0xaf, 0xc5, 0x9d, 0x46, 0x5b, 0x2b,
    0x54, 0x5e, 0xec, 0x6c, 0x8f, 0xf7, 0xce, 0x4c, 0x4c, 0x3f, 0xbb, 0x71,
    0xbb, 0x42, 0x36, 0x97, 0x25, 0x16, 0x8b, 0x11, 0x04, 0x8a, 0x62, 0xb1,
    0xc4, 0xca, 0xf2, 0x0a, 0xab, 0x2b, 0x2b, 0xd4, 0xdc, 0x7a, 0xe9, 0x63,
    0xbe, 0x3a, 0x77, 0x50, 0x12, 0x6d, 0x28, 0xdd, 0x1d, 0x48, 0xee, 0x6b,
    0x7a, 0x41, 0x0f, 0xb5, 0xe0, 0x83, 0x37, 0x37, 0x40, 0x08, 0x1a, 0x02,
    0x9e, 0xda, 0xd2, 0xc9, 0xfa, 0x39, 0xed, 0x8b, 0x6f, 0x8a, 0x1f, 0x69,
    0xcb, 0xbd, 0x12, 0x94, 0x6b, 0x4f, 0xaf, 0x2c, 0x2c, 0x8d, 0x1a, 0x76,
    0x08, 0x25, 0x15, 0xb5, 0x66, 0x1d, 0xb7, 0xd5, 0x2c, 0x6a, 0xa5, 0x5e,
    0x40, 0x71, 0x36, 0xae, 0xf9, 0x57, 0xce, 0x45, 0xcc, 0x87, 0x31, 0xfc,
    0x80, 0x9c, 0xa9, 0xd9, 0xab, 0x4d, 0x72, 0x68, 0xf6, 0x03, 0x65, 0x60,
    0x6c, 0x48, 0x31, 0x0e, 0x3b, 0xcc, 0x64, 0x21, 0x84, 0x18, 0x7c, 0x9c,
    0xce, 0x59, 0x8b, 0x7b, 0x7c, 0x8b, 0x61, 0x24, 0x61, 0x60, 0x1d, 0xcd,
    0x14, 0x7b, 0x58, 0xd0, 0xa7, 0x75, 0xc0, 0x0e, 0x2b, 0x9f, 0x17, 0xc6,
    0x81, 0x29, 0x04, 0xc0, 0x63, 0xe7, 0xb4, 0xfc, 0xef, 0xf9, 0xbf, 0x01,
    0xaa, 0xe9, 0xc5, 0x77, 0xb7, 0xea, 0xab, 0x12, 0x00, 0x00, 0x00, 0x00,
    0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

static const unsigned char image11_data[] = { 
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0xf3, 0xff, 0x61, 0x00, 0x00, 0x02,
    0xce, 0x49, 0x44, 0x41, 0x54, 0x38, 0x8d, 0xa5, 0x93, 0x4b, 0x6c, 0x54,
    0x65, 0x18, 0x86, 0x9f, 0xff, 0x3f, 0x67, 0xe6, 0xf4, 0xf4, 0x74, 0xc6,
    0x19, 0xc2, 0x14, 0x28, 0xd8, 0x80, 0x58, 0x05, 0x9c, 0x20, 0x8b, 0xa6,
    0xc1, 0xd0, 0x86, 0x4b, 0x82, 0x55, 0x63, 0x0a, 0x1b, 0xdc, 0x34, 0xb0,
    0x60, 0x65, 0x34, 0x2e, 0xbd, 0x60, 0xa2, 0x05, 0xd3, 0x70, 0xdd, 0x91,
    0x48, 0x42, 0xd4, 0xb0, 0x34, 0xc1, 0x85, 0x92, 0xc0, 0x6c, 0x08, 0x29,
    0x68, 0xdc, 0x98, 0x58, 0x25, 0x31, 0x81, 0x60, 0x9b, 0xb6, 0x43, 0x60,
    0xc0, 0x76, 0x66, 0x3a, 0xb7, 0x73, 0xce, 0x9c, 0xcb, 0xff, 0xbb, 0x30,
    0x4c, 0x22, 0x82, 0x1b, 0xbe, 0xe5, 0x97, 0xf7, 0x7b, 0xf2, 0x7e, 0xc9,
    0xfb, 0x0a, 0xad, 0x35, 0xcf, 0x32, 0xe6, 0x93, 0x96, 0x42, 0x08, 0xf1,
    0xfc, 0xd0, 0x07, 0xc3, 0xaa, 0xbf, 0x6f, 0x57, 0xca, 0x4a, 0xbc, 0xb0,
    0xc2, 0x6b, 0xce, 0xf6, 0xfa, 0xad, 0xcb, 0xdf, 0x5f, 0x39, 0xfd, 0xfb,
    0x7f, 0xb4, 0x8f, 0x3b, 0x78, 0xe9, 0xf5, 0x8f, 0xb6, 0x6d, 0xdc, 0x31,
    0x74, 0x74, 0xeb, 0xc6, 0x75, 0xfb, 0xd6, 0xac, 0x48, 0xf1, 0x57, 0x60,
    0x30, 0x5b, 0x2c, 0x51, 0xfa, 0x73, 0xc6, 0x4b, 0x94, 0x17, 0x2f, 0xc9,
    0x28, 0xfc, 0xf8, 0xea, 0xc5, 0x89, 0xe2, 0x13, 0x01, 0x83, 0xe3, 0x27,
    0x0f, 0xec, 0x79, 0x7b, 0xe7, 0x85, 0xc1, 0xa1, 0xbc, 0xf3, 0x8b, 0xdf,
    0xc5, 0xad, 0x87, 0x75, 0x82, 0x46, 0x8b, 0xd5, 0x09, 0x03, 0xd3, 0x6d,
    0xb1, 0x30, 0x3d, 0x8d, 0x28, 0x2e, 0xdc, 0x96, 0x81, 0x3f, 0xfa, 0x08,
    0xd2, 0x01, 0x6c, 0x1d, 0xfb, 0x74, 0xd3, 0xc8, 0xfe, 0x37, 0xa7, 0x5f,
    0x7b, 0x63, 0xd8, 0xfe, 0xec, 0x96, 0xc7, 0xfc, 0x52, 0x03, 0xa7, 0xdd,
    0xc4, 0xf4, 0x5d, 0xec, 0x56, 0x8d, 0xf5, 0xa6, 0x66, 0x95, 0x69, 0xd0,
    0xb8, 0x73, 0x1b, 0x71, 0xaf, 0x74, 0x35, 0x76, 0xa2, 0xb1, 0xa9, 0x0b,
    0x13, 0xbe, 0x7c, 0xf4, 0x73, 0x7f, 0x7e, 0xcb, 0x44, 0xfe, 0xd5, 0x2d,
    0xf6, 0x87, 0xd3, 0x15, 0xe6, 0x2b, 0x2d, 0x52, 0x46, 0x8c, 0x29, 0x60,
    0x34, 0x2e, 0xf3, 0x49, 0x3e, 0x4b, 0xd3, 0x6f, 0xb3, 0x54, 0x5e, 0xc2,
    0x48, 0xa7, 0xc0, 0xb6, 0xf6, 0x8a, 0xe5, 0x78, 0x0c, 0x40, 0x02, 0xac,
    0xda, 0x34, 0x9e, 0x1f, 0x18, 0xd8, 0xb0, 0xaf, 0xb0, 0x0c, 0x95, 0x6a,
    0x9d, 0x6c, 0xec, 0x91, 0x08, 0x03, 0xdc, 0x86, 0x4b, 0xfe, 0xc5, 0xd5,
    0xac, 0x5c, 0x99, 0x81, 0x30, 0x44, 0x44, 0x21, 0x5a, 0x82, 0x74, 0xba,
    0xd1, 0xda, 0x78, 0xb7, 0x03, 0xc8, 0xe5, 0x5f, 0x1e, 0x6d, 0xcb, 0xa4,
    0x5d, 0x2c, 0xd7, 0xc9, 0x44, 0x3e, 0x56, 0xd8, 0x46, 0x55, 0x2a, 0x8c,
    0xeb, 0x07, 0x18, 0x52, 0x32, 0x79, 0x63, 0x16, 0x5b, 0x87, 0x98, 0x86,
    0x84, 0xa4, 0x05, 0x96, 0x85, 0x96, 0x0c, 0x77, 0x00, 0xbd, 0xe9, 0xd4,
    0x2b, 0xbf, 0x2e, 0xd6, 0x71, 0x6b, 0x35, 0xba, 0x43, 0x1f, 0xd1, 0x6a,
    0xb2, 0x3b, 0x78, 0xc8, 0xd7, 0x87, 0xb6, 0x93, 0xcb, 0x38, 0x44, 0xf5,
    0x06, 0x5d, 0x51, 0x88, 0x34, 0x0c, 0xb0, 0x6d, 0x30, 0x0d, 0x80, 0x44,
    0x27, 0x07, 0xa6, 0x8a, 0xdd, 0xd8, 0x6b, 0x91, 0xe8, 0xee, 0x41, 0x2a,
    0x85, 0x55, 0xad, 0xf2, 0xf9, 0xfe, 0xcd, 0xdc, 0xf4, 0x0d, 0xce, 0x16,
    0x7e, 0x23, 0x17, 0xb7, 0xff, 0xb9, 0x71, 0x1c, 0x48, 0x98, 0xa8, 0x30,
    0x46, 0x45, 0xf1, 0x6c, 0xc7, 0x01, 0xf5, 0xe6, 0x54, 0x97, 0xe7, 0x62,
    0x27, 0x04, 0x49, 0xad, 0x58, 0xdb, 0x25, 0xc8, 0x65, 0x1d, 0xce, 0x7c,
    0xfb, 0x13, 0xbb, 0xd3, 0x9a, 0x91, 0x81, 0x5e, 0xfc, 0x9e, 0x0c, 0xf1,
    0x73, 0x59, 0x88, 0x62, 0xd4, 0x72, 0x1d, 0x19, 0xeb, 0x8b, 0x1d, 0x80,
    0xe1, 0x95, 0x6f, 0x98, 0xb5, 0xda, 0x1d, 0x2b, 0x0c, 0xb0, 0x33, 0x69,
    0x96, 0x2d, 0x87, 0xbb, 0x8d, 0x80, 0xf3, 0xe3, 0xdb, 0x79, 0x6b, 0xef,
    0x20, 0x37, 0x45, 0x0a, 0xb9, 0xa6, 0x0f, 0x69, 0x48, 0xf4, 0xfd, 0x12,
    0x71, 0xbd, 0x51, 0x32, 0xd0, 0xe7, 0x3b, 0x80, 0x42, 0xe1, 0xec, 0xa2,
    0xac, 0x54, 0xbe, 0xb4, 0xe6, 0xe7, 0x48, 0x2a, 0x85, 0xe8, 0x5b, 0xcb,
    0xb9, 0xbb, 0x8a, 0x6f, 0x4a, 0x8a, 0x53, 0x33, 0x6d, 0xaa, 0x56, 0x0f,
    0x49, 0x15, 0x20, 0x66, 0x66, 0x88, 0xe6, 0x8a, 0x88, 0x20, 0x3c, 0x71,
    0xed, 0xca, 0xe4, 0xc2, 0xbf, 0x82, 0x24, 0xc4, 0x31, 0xb9, 0xf3, 0x60,
    0xcf, 0x57, 0x22, 0x97, 0x3b, 0xac, 0x37, 0xac, 0xc7, 0x4d, 0x67, 0xf1,
    0x35, 0x64, 0x88, 0x31, 0xab, 0x15, 0xf4, 0xdc, 0x3c, 0xea, 0xfe, 0x03,
    0x44, 0x18, 0x9c, 0xbb, 0xfe, 0xc3, 0xd1, 0xf7, 0x9f, 0xda, 0x85, 0x5d,
    0x07, 0x8e, 0x1f, 0xd1, 0x4e, 0xf7, 0x7b, 0x22, 0x9d, 0x5a, 0x47, 0x32,
    0x89, 0x76, 0x3d, 0xa8, 0xd5, 0xc0, 0xf3, 0xfe, 0x10, 0x41, 0xf0, 0xc5,
    0xf5, 0xcb, 0x93, 0xdf, 0xfd, 0x6f, 0x99, 0x00, 0x46, 0xde, 0x39, 0xd6,
    0x2f, 0x62, 0xb9, 0x47, 0x6a, 0xb5, 0x43, 0x2b, 0x5c, 0x2d, 0x98, 0xa2,
    0xdd, 0xfe, 0xf9, 0xc7, 0xc2, 0xf1, 0xc5, 0xc7, 0xb5, 0x7f, 0x03, 0x93,
    0x83, 0x44, 0x68, 0x5e, 0x64, 0x97, 0x74, 0x00, 0x00, 0x00, 0x00, 0x49,
    0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};


/*
 *  Constructs a danp as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
danp::danp( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    QImage img;
    img.loadFromData( image0_data, sizeof( image0_data ), "PNG" );
    image0 = img;
    img.loadFromData( image1_data, sizeof( image1_data ), "PNG" );
    image1 = img;
    img.loadFromData( image2_data, sizeof( image2_data ), "PNG" );
    image2 = img;
    img.loadFromData( image3_data, sizeof( image3_data ), "PNG" );
    image3 = img;
    img.loadFromData( image4_data, sizeof( image4_data ), "PNG" );
    image4 = img;
    img.loadFromData( image5_data, sizeof( image5_data ), "PNG" );
    image5 = img;
    img.loadFromData( image6_data, sizeof( image6_data ), "PNG" );
    image6 = img;
    img.loadFromData( image7_data, sizeof( image7_data ), "PNG" );
    image7 = img;
    img.loadFromData( image8_data, sizeof( image8_data ), "PNG" );
    image8 = img;
    img.loadFromData( image9_data, sizeof( image9_data ), "PNG" );
    image9 = img;
    img.loadFromData( image10_data, sizeof( image10_data ), "PNG" );
    image10 = img;
    img.loadFromData( image11_data, sizeof( image11_data ), "PNG" );
    image11 = img;
    if ( !name )
	setName( "danp" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)2, 0, 0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 570, 500 ) );
    setMaximumSize( QSize( 5100, 5000 ) );
    setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    setPalette( pal );
    QFont f( font() );
    setFont( f ); 
    danpLayout = new QVBoxLayout( this, 5, 6, "danpLayout"); 

    textLabelInfo = new QLabel( this, "textLabelInfo" );
    textLabelInfo->setMinimumSize( QSize( 0, 20 ) );
    textLabelInfo->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 237, 237, 237) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 220, 220, 220) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 110, 110) );
    cg.setColor( QColorGroup::Mid, QColor( 146, 146, 146) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabelInfo->setPalette( pal );
    textLabelInfo->setFrameShape( QLabel::Box );
    textLabelInfo->setFrameShadow( QLabel::Plain );
    textLabelInfo->setAlignment( int( QLabel::AlignCenter ) );
    danpLayout->addWidget( textLabelInfo );

    sansTab = new QTabWidget( this, "sansTab" );
    sansTab->setEnabled( TRUE );
    sansTab->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)2, 0, 0, sansTab->sizePolicy().hasHeightForWidth() ) );
    sansTab->setMinimumSize( QSize( 0, 0 ) );
    sansTab->setMaximumSize( QSize( 10000, 25000 ) );
    sansTab->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    sansTab->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    sansTab->setPalette( pal );

    TabPage = new QWidget( sansTab, "TabPage" );
    TabPageLayout = new QVBoxLayout( TabPage, 11, 6, "TabPageLayout"); 
    spacer11 = new QSpacerItem( 1, 16, QSizePolicy::Minimum, QSizePolicy::Fixed );
    TabPageLayout->addItem( spacer11 );

    buttonGroup53 = new QButtonGroup( TabPage, "buttonGroup53" );
    buttonGroup53->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroup53->sizePolicy().hasHeightForWidth() ) );
    buttonGroup53->setMaximumSize( QSize( 32767, 60 ) );
    buttonGroup53->setColumnLayout(0, Qt::Vertical );
    buttonGroup53->layout()->setSpacing( 6 );
    buttonGroup53->layout()->setMargin( 11 );
    buttonGroup53Layout = new QHBoxLayout( buttonGroup53->layout() );
    buttonGroup53Layout->setAlignment( Qt::AlignTop );

    lineEditPath = new QLineEdit( buttonGroup53, "lineEditPath" );
    lineEditPath->setEnabled( TRUE );
    lineEditPath->setMinimumSize( QSize( 100, 0 ) );
    lineEditPath->setMaximumSize( QSize( 4400, 25 ) );
    lineEditPath->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    lineEditPath->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont lineEditPath_font(  lineEditPath->font() );
    lineEditPath->setFont( lineEditPath_font ); 
    lineEditPath->setFrameShape( QLineEdit::LineEditPanel );
    lineEditPath->setFrameShadow( QLineEdit::Sunken );
    lineEditPath->setLineWidth( 1 );
    lineEditPath->setReadOnly( FALSE );
    buttonGroup53Layout->addWidget( lineEditPath );

    pushButtonPath = new QToolButton( buttonGroup53, "pushButtonPath" );
    pushButtonPath->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonPath->sizePolicy().hasHeightForWidth() ) );
    pushButtonPath->setMinimumSize( QSize( 25, 25 ) );
    pushButtonPath->setMaximumSize( QSize( 25, 25 ) );
    pushButtonPath->setIconSet( QIconSet( image0 ) );
    buttonGroup53Layout->addWidget( pushButtonPath );
    TabPageLayout->addWidget( buttonGroup53 );

    buttonGroup53_2 = new QButtonGroup( TabPage, "buttonGroup53_2" );
    buttonGroup53_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroup53_2->sizePolicy().hasHeightForWidth() ) );
    buttonGroup53_2->setMaximumSize( QSize( 32767, 60 ) );
    buttonGroup53_2->setColumnLayout(0, Qt::Vertical );
    buttonGroup53_2->layout()->setSpacing( 6 );
    buttonGroup53_2->layout()->setMargin( 11 );
    buttonGroup53_2Layout = new QHBoxLayout( buttonGroup53_2->layout() );
    buttonGroup53_2Layout->setAlignment( Qt::AlignTop );

    lineEditPathOut = new QLineEdit( buttonGroup53_2, "lineEditPathOut" );
    lineEditPathOut->setEnabled( TRUE );
    lineEditPathOut->setMinimumSize( QSize( 100, 0 ) );
    lineEditPathOut->setMaximumSize( QSize( 4400, 25 ) );
    lineEditPathOut->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    lineEditPathOut->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont lineEditPathOut_font(  lineEditPathOut->font() );
    lineEditPathOut->setFont( lineEditPathOut_font ); 
    lineEditPathOut->setFrameShape( QLineEdit::LineEditPanel );
    lineEditPathOut->setFrameShadow( QLineEdit::Sunken );
    lineEditPathOut->setLineWidth( 1 );
    lineEditPathOut->setReadOnly( FALSE );
    buttonGroup53_2Layout->addWidget( lineEditPathOut );

    pushButtonPathOut = new QToolButton( buttonGroup53_2, "pushButtonPathOut" );
    pushButtonPathOut->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonPathOut->sizePolicy().hasHeightForWidth() ) );
    pushButtonPathOut->setMinimumSize( QSize( 25, 25 ) );
    pushButtonPathOut->setMaximumSize( QSize( 25, 25 ) );
    pushButtonPathOut->setIconSet( QIconSet( image0 ) );
    buttonGroup53_2Layout->addWidget( pushButtonPathOut );
    TabPageLayout->addWidget( buttonGroup53_2 );
    spacer12 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    TabPageLayout->addItem( spacer12 );
    sansTab->insertTab( TabPage, QString::fromLatin1("") );

    tab = new QWidget( sansTab, "tab" );
    tabLayout = new QVBoxLayout( tab, 11, 6, "tabLayout"); 

    layout57_2 = new QHBoxLayout( 0, 0, 2, "layout57_2"); 

    comboBoxStructureASCII1D = new QComboBox( FALSE, tab, "comboBoxStructureASCII1D" );
    comboBoxStructureASCII1D->setMinimumSize( QSize( 0, 25 ) );
    comboBoxStructureASCII1D->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout57_2->addWidget( comboBoxStructureASCII1D );

    pushButtonNewASCII1D = new QToolButton( tab, "pushButtonNewASCII1D" );
    pushButtonNewASCII1D->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonNewASCII1D->sizePolicy().hasHeightForWidth() ) );
    pushButtonNewASCII1D->setMinimumSize( QSize( 25, 25 ) );
    pushButtonNewASCII1D->setMaximumSize( QSize( 25, 25 ) );
    pushButtonNewASCII1D->setIconSet( QIconSet( image1 ) );
    layout57_2->addWidget( pushButtonNewASCII1D );

    pushButtonDeleteASCII1D = new QToolButton( tab, "pushButtonDeleteASCII1D" );
    pushButtonDeleteASCII1D->setEnabled( FALSE );
    pushButtonDeleteASCII1D->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonDeleteASCII1D->sizePolicy().hasHeightForWidth() ) );
    pushButtonDeleteASCII1D->setMinimumSize( QSize( 25, 25 ) );
    pushButtonDeleteASCII1D->setMaximumSize( QSize( 25, 25 ) );
    pushButtonDeleteASCII1D->setIconSet( QIconSet( image2 ) );
    layout57_2->addWidget( pushButtonDeleteASCII1D );

    pushButtonSaveCurrentASCII1D = new QToolButton( tab, "pushButtonSaveCurrentASCII1D" );
    pushButtonSaveCurrentASCII1D->setEnabled( FALSE );
    pushButtonSaveCurrentASCII1D->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonSaveCurrentASCII1D->sizePolicy().hasHeightForWidth() ) );
    pushButtonSaveCurrentASCII1D->setMinimumSize( QSize( 25, 25 ) );
    pushButtonSaveCurrentASCII1D->setMaximumSize( QSize( 25, 25 ) );
    pushButtonSaveCurrentASCII1D->setIconSet( QIconSet( image3 ) );
    layout57_2->addWidget( pushButtonSaveCurrentASCII1D );
    tabLayout->addLayout( layout57_2 );

    layout108 = new QHBoxLayout( 0, 0, 6, "layout108"); 

    buttonGroup31 = new QButtonGroup( tab, "buttonGroup31" );
    buttonGroup31->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroup31->sizePolicy().hasHeightForWidth() ) );
    buttonGroup31->setMinimumSize( QSize( 150, 0 ) );
    buttonGroup31->setMaximumSize( QSize( 1500, 32767 ) );
    buttonGroup31->setLineWidth( 0 );
    buttonGroup31->setColumnLayout(0, Qt::Vertical );
    buttonGroup31->layout()->setSpacing( 5 );
    buttonGroup31->layout()->setMargin( 0 );
    buttonGroup31Layout = new QVBoxLayout( buttonGroup31->layout() );
    buttonGroup31Layout->setAlignment( Qt::AlignTop );

    ASCIIpushButton = new QToolButton( buttonGroup31, "ASCIIpushButton" );
    ASCIIpushButton->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, ASCIIpushButton->sizePolicy().hasHeightForWidth() ) );
    ASCIIpushButton->setMinimumSize( QSize( 0, 25 ) );
    ASCIIpushButton->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    ASCIIpushButton->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    QFont ASCIIpushButton_font(  ASCIIpushButton->font() );
    ASCIIpushButton_font.setBold( TRUE );
    ASCIIpushButton->setFont( ASCIIpushButton_font ); 
    buttonGroup31Layout->addWidget( ASCIIpushButton );

    line1_2_3_11_5_10_2 = new QFrame( buttonGroup31, "line1_2_3_11_5_10_2" );
    line1_2_3_11_5_10_2->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_3_11_5_10_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2->setFrameShape( QFrame::HLine );
    line1_2_3_11_5_10_2->setFrameShadow( QFrame::Plain );
    line1_2_3_11_5_10_2->setLineWidth( 1 );
    line1_2_3_11_5_10_2->setFrameShape( QFrame::HLine );
    buttonGroup31Layout->addWidget( line1_2_3_11_5_10_2 );

    groupBox78 = new QGroupBox( buttonGroup31, "groupBox78" );
    groupBox78->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, groupBox78->sizePolicy().hasHeightForWidth() ) );
    groupBox78->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBox78->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    groupBox78->setPalette( pal );
    QFont groupBox78_font(  groupBox78->font() );
    groupBox78_font.setBold( TRUE );
    groupBox78->setFont( groupBox78_font ); 
    groupBox78->setFrameShape( QGroupBox::NoFrame );
    groupBox78->setFrameShadow( QGroupBox::Plain );
    groupBox78->setLineWidth( 0 );
    groupBox78->setColumnLayout(0, Qt::Vertical );
    groupBox78->layout()->setSpacing( 6 );
    groupBox78->layout()->setMargin( 0 );
    groupBox78Layout = new QVBoxLayout( groupBox78->layout() );
    groupBox78Layout->setAlignment( Qt::AlignTop );

    comboBoxSource = new QComboBox( FALSE, groupBox78, "comboBoxSource" );
    comboBoxSource->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxSource_font(  comboBoxSource->font() );
    comboBoxSource_font.setBold( FALSE );
    comboBoxSource->setFont( comboBoxSource_font ); 
    groupBox78Layout->addWidget( comboBoxSource );
    buttonGroup31Layout->addWidget( groupBox78 );

    line1_2_3_11_5_10_2_2 = new QFrame( buttonGroup31, "line1_2_3_11_5_10_2_2" );
    line1_2_3_11_5_10_2_2->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_3_11_5_10_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2_2->setFrameShape( QFrame::HLine );
    line1_2_3_11_5_10_2_2->setFrameShadow( QFrame::Plain );
    line1_2_3_11_5_10_2_2->setLineWidth( 1 );
    line1_2_3_11_5_10_2_2->setFrameShape( QFrame::HLine );
    buttonGroup31Layout->addWidget( line1_2_3_11_5_10_2_2 );

    groupBox77 = new QGroupBox( buttonGroup31, "groupBox77" );
    groupBox77->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, groupBox77->sizePolicy().hasHeightForWidth() ) );
    groupBox77->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont groupBox77_font(  groupBox77->font() );
    groupBox77_font.setBold( TRUE );
    groupBox77->setFont( groupBox77_font ); 
    groupBox77->setFrameShape( QGroupBox::NoFrame );
    groupBox77->setFrameShadow( QGroupBox::Plain );
    groupBox77->setLineWidth( 0 );
    groupBox77->setColumnLayout(0, Qt::Vertical );
    groupBox77->layout()->setSpacing( 6 );
    groupBox77->layout()->setMargin( 0 );
    groupBox77Layout = new QVBoxLayout( groupBox77->layout() );
    groupBox77Layout->setAlignment( Qt::AlignTop );

    comboBoxDestination = new QComboBox( FALSE, groupBox77, "comboBoxDestination" );
    comboBoxDestination->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxDestination_font(  comboBoxDestination->font() );
    comboBoxDestination_font.setBold( FALSE );
    comboBoxDestination->setFont( comboBoxDestination_font ); 
    groupBox77Layout->addWidget( comboBoxDestination );
    buttonGroup31Layout->addWidget( groupBox77 );

    lineinput = new QFrame( buttonGroup31, "lineinput" );
    lineinput->setMaximumSize( QSize( 32767, 2 ) );
    lineinput->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    lineinput->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    lineinput->setFrameShape( QFrame::HLine );
    lineinput->setFrameShadow( QFrame::Plain );
    lineinput->setLineWidth( 1 );
    lineinput->setFrameShape( QFrame::HLine );
    buttonGroup31Layout->addWidget( lineinput );

    groupFormat = new QGroupBox( buttonGroup31, "groupFormat" );
    groupFormat->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, groupFormat->sizePolicy().hasHeightForWidth() ) );
    groupFormat->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupFormat->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    QFont groupFormat_font(  groupFormat->font() );
    groupFormat_font.setBold( TRUE );
    groupFormat->setFont( groupFormat_font ); 
    groupFormat->setFrameShape( QGroupBox::NoFrame );
    groupFormat->setFrameShadow( QGroupBox::Plain );
    groupFormat->setLineWidth( 0 );
    groupFormat->setColumnLayout(0, Qt::Vertical );
    groupFormat->layout()->setSpacing( 6 );
    groupFormat->layout()->setMargin( 0 );
    groupFormatLayout = new QVBoxLayout( groupFormat->layout() );
    groupFormatLayout->setAlignment( Qt::AlignTop );

    comboBoxFormat = new QComboBox( FALSE, groupFormat, "comboBoxFormat" );
    comboBoxFormat->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxFormat_font(  comboBoxFormat->font() );
    comboBoxFormat_font.setBold( FALSE );
    comboBoxFormat->setFont( comboBoxFormat_font ); 
    groupFormatLayout->addWidget( comboBoxFormat );

    spinBoxForceNumCols = new QSpinBox( groupFormat, "spinBoxForceNumCols" );
    spinBoxForceNumCols->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxForceNumCols->sizePolicy().hasHeightForWidth() ) );
    spinBoxForceNumCols->setMinimumSize( QSize( 40, 0 ) );
    spinBoxForceNumCols->setMaximumSize( QSize( 1200, 32767 ) );
    spinBoxForceNumCols->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont spinBoxForceNumCols_font(  spinBoxForceNumCols->font() );
    spinBoxForceNumCols_font.setBold( FALSE );
    spinBoxForceNumCols->setFont( spinBoxForceNumCols_font ); 
    spinBoxForceNumCols->setMaxValue( 4 );
    spinBoxForceNumCols->setMinValue( 2 );
    spinBoxForceNumCols->setValue( 4 );
    groupFormatLayout->addWidget( spinBoxForceNumCols );

    lineEditSkipHeader = new QLineEdit( groupFormat, "lineEditSkipHeader" );
    QFont lineEditSkipHeader_font(  lineEditSkipHeader->font() );
    lineEditSkipHeader_font.setBold( FALSE );
    lineEditSkipHeader->setFont( lineEditSkipHeader_font ); 
    groupFormatLayout->addWidget( lineEditSkipHeader );
    buttonGroup31Layout->addWidget( groupFormat );

    line1_2_3_11_5_10_2_2_2_2 = new QFrame( buttonGroup31, "line1_2_3_11_5_10_2_2_2_2" );
    line1_2_3_11_5_10_2_2_2_2->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_3_11_5_10_2_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2_2_2_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2_2_2_2->setFrameShape( QFrame::HLine );
    line1_2_3_11_5_10_2_2_2_2->setFrameShadow( QFrame::Plain );
    line1_2_3_11_5_10_2_2_2_2->setLineWidth( 1 );
    line1_2_3_11_5_10_2_2_2_2->setFrameShape( QFrame::HLine );
    buttonGroup31Layout->addWidget( line1_2_3_11_5_10_2_2_2_2 );

    groupBox11 = new QGroupBox( buttonGroup31, "groupBox11" );
    groupBox11->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont groupBox11_font(  groupBox11->font() );
    groupBox11_font.setBold( TRUE );
    groupBox11->setFont( groupBox11_font ); 
    groupBox11->setFrameShape( QGroupBox::NoFrame );
    groupBox11->setFrameShadow( QGroupBox::Plain );
    groupBox11->setLineWidth( 0 );
    groupBox11->setColumnLayout(0, Qt::Vertical );
    groupBox11->layout()->setSpacing( 6 );
    groupBox11->layout()->setMargin( 0 );
    groupBox11Layout = new QVBoxLayout( groupBox11->layout() );
    groupBox11Layout->setAlignment( Qt::AlignTop );

    spinBoxFindIndex = new QComboBox( FALSE, groupBox11, "spinBoxFindIndex" );
    spinBoxFindIndex->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxFindIndex->sizePolicy().hasHeightForWidth() ) );
    spinBoxFindIndex->setMaximumSize( QSize( 1200, 32767 ) );
    spinBoxFindIndex->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont spinBoxFindIndex_font(  spinBoxFindIndex->font() );
    spinBoxFindIndex_font.setBold( FALSE );
    spinBoxFindIndex->setFont( spinBoxFindIndex_font ); 
    groupBox11Layout->addWidget( spinBoxFindIndex );

    comboBoxPrefixASCII1D = new QComboBox( FALSE, groupBox11, "comboBoxPrefixASCII1D" );
    comboBoxPrefixASCII1D->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxPrefixASCII1D->sizePolicy().hasHeightForWidth() ) );
    comboBoxPrefixASCII1D->setMaximumSize( QSize( 1200, 32767 ) );
    comboBoxPrefixASCII1D->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont comboBoxPrefixASCII1D_font(  comboBoxPrefixASCII1D->font() );
    comboBoxPrefixASCII1D_font.setBold( FALSE );
    comboBoxPrefixASCII1D->setFont( comboBoxPrefixASCII1D_font ); 
    groupBox11Layout->addWidget( comboBoxPrefixASCII1D );

    checkBoxIndexing = new QCheckBox( groupBox11, "checkBoxIndexing" );
    checkBoxIndexing->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxIndexing->sizePolicy().hasHeightForWidth() ) );
    checkBoxIndexing->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont checkBoxIndexing_font(  checkBoxIndexing->font() );
    checkBoxIndexing_font.setBold( FALSE );
    checkBoxIndexing->setFont( checkBoxIndexing_font ); 
    groupBox11Layout->addWidget( checkBoxIndexing );
    buttonGroup31Layout->addWidget( groupBox11 );

    line1_2_3_11_5_10_2_2_2_3 = new QFrame( buttonGroup31, "line1_2_3_11_5_10_2_2_2_3" );
    line1_2_3_11_5_10_2_2_2_3->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_3_11_5_10_2_2_2_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2_2_2_3->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2_2_2_3->setFrameShape( QFrame::HLine );
    line1_2_3_11_5_10_2_2_2_3->setFrameShadow( QFrame::Plain );
    line1_2_3_11_5_10_2_2_2_3->setLineWidth( 1 );
    line1_2_3_11_5_10_2_2_2_3->setFrameShape( QFrame::HLine );
    buttonGroup31Layout->addWidget( line1_2_3_11_5_10_2_2_2_3 );

    groupBox7 = new QGroupBox( buttonGroup31, "groupBox7" );
    groupBox7->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, groupBox7->sizePolicy().hasHeightForWidth() ) );
    groupBox7->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont groupBox7_font(  groupBox7->font() );
    groupBox7_font.setBold( TRUE );
    groupBox7->setFont( groupBox7_font ); 
    groupBox7->setFrameShape( QGroupBox::NoFrame );
    groupBox7->setFrameShadow( QGroupBox::Plain );
    groupBox7->setLineWidth( 0 );
    groupBox7->setColumnLayout(0, Qt::Vertical );
    groupBox7->layout()->setSpacing( 6 );
    groupBox7->layout()->setMargin( 0 );
    groupBox7Layout = new QVBoxLayout( groupBox7->layout() );
    groupBox7Layout->setAlignment( Qt::AlignTop );

    checkBoxActions = new QCheckBox( groupBox7, "checkBoxActions" );
    checkBoxActions->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxActions->sizePolicy().hasHeightForWidth() ) );
    checkBoxActions->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont checkBoxActions_font(  checkBoxActions->font() );
    checkBoxActions_font.setBold( FALSE );
    checkBoxActions->setFont( checkBoxActions_font ); 
    groupBox7Layout->addWidget( checkBoxActions );

    checkBoxPlotInActive = new QCheckBox( groupBox7, "checkBoxPlotInActive" );
    checkBoxPlotInActive->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxPlotInActive->sizePolicy().hasHeightForWidth() ) );
    checkBoxPlotInActive->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    QFont checkBoxPlotInActive_font(  checkBoxPlotInActive->font() );
    checkBoxPlotInActive_font.setBold( FALSE );
    checkBoxPlotInActive->setFont( checkBoxPlotInActive_font ); 
    groupBox7Layout->addWidget( checkBoxPlotInActive );
    buttonGroup31Layout->addWidget( groupBox7 );
    spacer26 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    buttonGroup31Layout->addItem( spacer26 );
    layout108->addWidget( buttonGroup31 );

    splitter9 = new QSplitter( tab, "splitter9" );
    splitter9->setOrientation( QSplitter::Horizontal );

    toolBoxChange = new QToolBox( splitter9, "toolBoxChange" );
    toolBoxChange->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, toolBoxChange->sizePolicy().hasHeightForWidth() ) );
    toolBoxChange->setMinimumSize( QSize( 320, 0 ) );
    toolBoxChange->setMaximumSize( QSize( 320, 32767 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    toolBoxChange->setPalette( pal );
    toolBoxChange->setFrameShape( QToolBox::NoFrame );
    toolBoxChange->setCurrentIndex( 0 );

    page1 = new QWidget( toolBoxChange, "page1" );
    page1->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout = new QHBoxLayout( page1, 11, 6, "page1Layout"); 
    spacer33 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    page1Layout->addItem( spacer33 );

    layout104 = new QVBoxLayout( 0, 0, 3, "layout104"); 

    checkBoxReso = new QCheckBox( page1, "checkBoxReso" );
    checkBoxReso->setMinimumSize( QSize( 240, 20 ) );
    checkBoxReso->setMaximumSize( QSize( 240, 20 ) );
    checkBoxReso->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxReso->setChecked( FALSE );
    layout104->addWidget( checkBoxReso );

    textLabelResoDescription = new QLabel( page1, "textLabelResoDescription" );
    textLabelResoDescription->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, textLabelResoDescription->sizePolicy().hasHeightForWidth() ) );
    textLabelResoDescription->setMaximumSize( QSize( 270, 10 ) );
    textLabelResoDescription->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout104->addWidget( textLabelResoDescription );

    buttonGroupReso = new QButtonGroup( page1, "buttonGroupReso" );
    buttonGroupReso->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroupReso->sizePolicy().hasHeightForWidth() ) );
    buttonGroupReso->setMaximumSize( QSize( 215, 32767 ) );
    buttonGroupReso->setLineWidth( 0 );
    buttonGroupReso->setColumnLayout(0, Qt::Vertical );
    buttonGroupReso->layout()->setSpacing( 0 );
    buttonGroupReso->layout()->setMargin( 0 );
    buttonGroupResoLayout = new QVBoxLayout( buttonGroupReso->layout() );
    buttonGroupResoLayout->setAlignment( Qt::AlignTop );

    layout100 = new QGridLayout( 0, 1, 1, 0, 0, "layout100"); 

    layout14 = new QVBoxLayout( 0, 2, 2, "layout14"); 

    textLabelResoCol = new QLabel( buttonGroupReso, "textLabelResoCol" );
    textLabelResoCol->setMinimumSize( QSize( 70, 0 ) );
    textLabelResoCol->setMaximumSize( QSize( 32767, 20 ) );
    textLabelResoCol->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout14->addWidget( textLabelResoCol );

    textLabelResoDet = new QLabel( buttonGroupReso, "textLabelResoDet" );
    textLabelResoDet->setMaximumSize( QSize( 32767, 20 ) );
    textLabelResoDet->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout14->addWidget( textLabelResoDet );

    textLabelResoPixelSize = new QLabel( buttonGroupReso, "textLabelResoPixelSize" );
    textLabelResoPixelSize->setMaximumSize( QSize( 32767, 20 ) );
    textLabelResoPixelSize->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout14->addWidget( textLabelResoPixelSize );

    layout100->addLayout( layout14, 0, 0 );

    layout38 = new QVBoxLayout( 0, 2, 2, "layout38"); 

    textLabelResoLambda = new QLabel( buttonGroupReso, "textLabelResoLambda" );
    textLabelResoLambda->setMaximumSize( QSize( 32767, 20 ) );
    textLabelResoLambda->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout38->addWidget( textLabelResoLambda );

    textLabelResoDeltaLambda = new QLabel( buttonGroupReso, "textLabelResoDeltaLambda" );
    textLabelResoDeltaLambda->setMaximumSize( QSize( 32767, 20 ) );
    textLabelResoDeltaLambda->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout38->addWidget( textLabelResoDeltaLambda );

    textLabelResoFocus = new QLabel( buttonGroupReso, "textLabelResoFocus" );
    textLabelResoFocus->setMaximumSize( QSize( 32767, 20 ) );
    textLabelResoFocus->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout38->addWidget( textLabelResoFocus );

    layout100->addLayout( layout38, 2, 0 );

    layout24 = new QVBoxLayout( 0, 2, 2, "layout24"); 

    textLabelResoSamAper2 = new QLabel( buttonGroupReso, "textLabelResoSamAper2" );
    textLabelResoSamAper2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelResoSamAper2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout24->addWidget( textLabelResoSamAper2 );

    textLabelResoColAper2 = new QLabel( buttonGroupReso, "textLabelResoColAper2" );
    textLabelResoColAper2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelResoColAper2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout24->addWidget( textLabelResoColAper2 );

    layout100->addLayout( layout24, 1, 2 );

    layout23 = new QVBoxLayout( 0, 0, 2, "layout23"); 

    layout21 = new QHBoxLayout( 0, 2, 2, "layout21"); 

    lineEditResoSamAper = new QLineEdit( buttonGroupReso, "lineEditResoSamAper" );
    lineEditResoSamAper->setMaximumSize( QSize( 50, 20 ) );
    lineEditResoSamAper->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout21->addWidget( lineEditResoSamAper );

    textLabel3 = new QLabel( buttonGroupReso, "textLabel3" );
    textLabel3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel3->sizePolicy().hasHeightForWidth() ) );
    textLabel3->setMinimumSize( QSize( 8, 20 ) );
    textLabel3->setMaximumSize( QSize( 8, 20 ) );
    textLabel3->setAlignment( int( QLabel::AlignCenter ) );
    layout21->addWidget( textLabel3 );

    lineEditResoSamAper2 = new QLineEdit( buttonGroupReso, "lineEditResoSamAper2" );
    lineEditResoSamAper2->setEnabled( TRUE );
    lineEditResoSamAper2->setMaximumSize( QSize( 50, 20 ) );
    lineEditResoSamAper2->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout21->addWidget( lineEditResoSamAper2 );
    layout23->addLayout( layout21 );

    layout22 = new QHBoxLayout( 0, 2, 2, "layout22"); 

    lineEditResoColAper = new QLineEdit( buttonGroupReso, "lineEditResoColAper" );
    lineEditResoColAper->setMaximumSize( QSize( 50, 20 ) );
    lineEditResoColAper->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout22->addWidget( lineEditResoColAper );

    textLabel3_2 = new QLabel( buttonGroupReso, "textLabel3_2" );
    textLabel3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel3_2->sizePolicy().hasHeightForWidth() ) );
    textLabel3_2->setMinimumSize( QSize( 8, 20 ) );
    textLabel3_2->setMaximumSize( QSize( 8, 20 ) );
    textLabel3_2->setAlignment( int( QLabel::AlignCenter ) );
    layout22->addWidget( textLabel3_2 );

    lineEditResoColAper2 = new QLineEdit( buttonGroupReso, "lineEditResoColAper2" );
    lineEditResoColAper2->setEnabled( TRUE );
    lineEditResoColAper2->setMaximumSize( QSize( 50, 20 ) );
    lineEditResoColAper2->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout22->addWidget( lineEditResoColAper2 );
    layout23->addLayout( layout22 );

    layout100->addLayout( layout23, 1, 1 );

    layout40 = new QVBoxLayout( 0, 2, 2, "layout40"); 

    lineEditResoLambda = new QLineEdit( buttonGroupReso, "lineEditResoLambda" );
    lineEditResoLambda->setMinimumSize( QSize( 70, 20 ) );
    lineEditResoLambda->setMaximumSize( QSize( 100, 20 ) );
    lineEditResoLambda->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditResoLambda->setFrameShape( QLineEdit::LineEditPanel );
    lineEditResoLambda->setFrameShadow( QLineEdit::Sunken );
    layout40->addWidget( lineEditResoLambda );

    lineEditResoDeltaLambda = new QLineEdit( buttonGroupReso, "lineEditResoDeltaLambda" );
    lineEditResoDeltaLambda->setMinimumSize( QSize( 70, 20 ) );
    lineEditResoDeltaLambda->setMaximumSize( QSize( 100, 20 ) );
    lineEditResoDeltaLambda->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout40->addWidget( lineEditResoDeltaLambda );

    lineEditResoFocus = new QLineEdit( buttonGroupReso, "lineEditResoFocus" );
    lineEditResoFocus->setMinimumSize( QSize( 70, 20 ) );
    lineEditResoFocus->setMaximumSize( QSize( 100, 20 ) );
    lineEditResoFocus->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout40->addWidget( lineEditResoFocus );

    layout100->addLayout( layout40, 2, 1 );

    layout15 = new QVBoxLayout( 0, 2, 2, "layout15"); 

    lineEditResoCol = new QLineEdit( buttonGroupReso, "lineEditResoCol" );
    lineEditResoCol->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditResoCol->sizePolicy().hasHeightForWidth() ) );
    lineEditResoCol->setMinimumSize( QSize( 70, 20 ) );
    lineEditResoCol->setMaximumSize( QSize( 100, 20 ) );
    lineEditResoCol->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout15->addWidget( lineEditResoCol );

    lineEditResoDet = new QLineEdit( buttonGroupReso, "lineEditResoDet" );
    lineEditResoDet->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditResoDet->sizePolicy().hasHeightForWidth() ) );
    lineEditResoDet->setMinimumSize( QSize( 70, 20 ) );
    lineEditResoDet->setMaximumSize( QSize( 100, 20 ) );
    lineEditResoDet->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout15->addWidget( lineEditResoDet );

    lineEditResoPixelSize = new QLineEdit( buttonGroupReso, "lineEditResoPixelSize" );
    lineEditResoPixelSize->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditResoPixelSize->sizePolicy().hasHeightForWidth() ) );
    lineEditResoPixelSize->setMinimumSize( QSize( 70, 20 ) );
    lineEditResoPixelSize->setMaximumSize( QSize( 100, 20 ) );
    lineEditResoPixelSize->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout15->addWidget( lineEditResoPixelSize );

    layout100->addLayout( layout15, 0, 1 );

    layout41 = new QVBoxLayout( 0, 2, 2, "layout41"); 

    textLabelResoLambda2 = new QLabel( buttonGroupReso, "textLabelResoLambda2" );
    textLabelResoLambda2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout41->addWidget( textLabelResoLambda2 );

    textLabelResoDeltaLambda2 = new QLabel( buttonGroupReso, "textLabelResoDeltaLambda2" );
    textLabelResoDeltaLambda2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout41->addWidget( textLabelResoDeltaLambda2 );

    textLabelResoFocus2 = new QLabel( buttonGroupReso, "textLabelResoFocus2" );
    textLabelResoFocus2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout41->addWidget( textLabelResoFocus2 );

    layout100->addLayout( layout41, 2, 2 );

    layout25 = new QVBoxLayout( 0, 2, 2, "layout25"); 

    textLabelResoSamAper = new QLabel( buttonGroupReso, "textLabelResoSamAper" );
    textLabelResoSamAper->setMaximumSize( QSize( 32767, 20 ) );
    textLabelResoSamAper->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout25->addWidget( textLabelResoSamAper );

    textLabelResoColAper = new QLabel( buttonGroupReso, "textLabelResoColAper" );
    textLabelResoColAper->setMaximumSize( QSize( 32767, 20 ) );
    textLabelResoColAper->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout25->addWidget( textLabelResoColAper );

    layout100->addLayout( layout25, 1, 0 );

    layout16 = new QVBoxLayout( 0, 2, 2, "layout16"); 

    textLabelResoCol2 = new QLabel( buttonGroupReso, "textLabelResoCol2" );
    textLabelResoCol2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout16->addWidget( textLabelResoCol2 );

    textLabelResoDet2 = new QLabel( buttonGroupReso, "textLabelResoDet2" );
    textLabelResoDet2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout16->addWidget( textLabelResoDet2 );

    textLabelResoPixelSize2 = new QLabel( buttonGroupReso, "textLabelResoPixelSize2" );
    textLabelResoPixelSize2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout16->addWidget( textLabelResoPixelSize2 );

    layout100->addLayout( layout16, 0, 2 );
    buttonGroupResoLayout->addLayout( layout100 );

    checkBoxLenses = new QCheckBox( buttonGroupReso, "checkBoxLenses" );
    checkBoxLenses->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroupResoLayout->addWidget( checkBoxLenses );

    layout56 = new QHBoxLayout( 0, 0, 2, "layout56"); 

    pushButtonKWS1 = new QPushButton( buttonGroupReso, "pushButtonKWS1" );
    pushButtonKWS1->setMaximumSize( QSize( 50, 32767 ) );
    layout56->addWidget( pushButtonKWS1 );

    pushButtonKWS2 = new QPushButton( buttonGroupReso, "pushButtonKWS2" );
    pushButtonKWS2->setMaximumSize( QSize( 50, 32767 ) );
    layout56->addWidget( pushButtonKWS2 );

    pushButtonCANSAS = new QPushButton( buttonGroupReso, "pushButtonCANSAS" );
    pushButtonCANSAS->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonCANSAS->sizePolicy().hasHeightForWidth() ) );
    pushButtonCANSAS->setMaximumSize( QSize( 1050, 32767 ) );
    layout56->addWidget( pushButtonCANSAS );
    buttonGroupResoLayout->addLayout( layout56 );
    layout104->addWidget( buttonGroupReso );
    page1Layout->addLayout( layout104 );
    spacer33_2 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    page1Layout->addItem( spacer33_2 );
    toolBoxChange->addItem( page1, QString::fromLatin1("") );

    page2 = new QWidget( toolBoxChange, "page2" );
    page2->setBackgroundMode( QWidget::PaletteBackground );
    page2Layout = new QHBoxLayout( page2, 11, 6, "page2Layout"); 
    spacer33_3 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    page2Layout->addItem( spacer33_3 );

    layout105 = new QVBoxLayout( 0, 0, 6, "layout105"); 

    checkBoxConvert = new QCheckBox( page2, "checkBoxConvert" );
    checkBoxConvert->setEnabled( TRUE );
    checkBoxConvert->setMinimumSize( QSize( 0, 20 ) );
    checkBoxConvert->setMaximumSize( QSize( 270, 20 ) );
    checkBoxConvert->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxConvert->setChecked( FALSE );
    layout105->addWidget( checkBoxConvert );

    textLabelSASdesc = new QLabel( page2, "textLabelSASdesc" );
    textLabelSASdesc->setMaximumSize( QSize( 270, 20 ) );
    textLabelSASdesc->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    textLabelSASdesc->setPalette( pal );
    layout105->addWidget( textLabelSASdesc );

    frameSASpresentation = new QFrame( page2, "frameSASpresentation" );
    frameSASpresentation->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, frameSASpresentation->sizePolicy().hasHeightForWidth() ) );
    frameSASpresentation->setMinimumSize( QSize( 270, 200 ) );
    frameSASpresentation->setMaximumSize( QSize( 270, 200 ) );
    frameSASpresentation->setFrameShape( QFrame::StyledPanel );
    frameSASpresentation->setFrameShadow( QFrame::Raised );
    frameSASpresentation->setLineWidth( 0 );
    frameSASpresentationLayout = new QVBoxLayout( frameSASpresentation, 0, 3, "frameSASpresentationLayout"); 

    layout91 = new QHBoxLayout( 0, 0, 6, "layout91"); 

    layout87 = new QVBoxLayout( 0, 0, 6, "layout87"); 

    textLabel5 = new QLabel( frameSASpresentation, "textLabel5" );
    textLabel5->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout87->addWidget( textLabel5 );

    textLabel5_3 = new QLabel( frameSASpresentation, "textLabel5_3" );
    textLabel5_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout87->addWidget( textLabel5_3 );

    textLabel5_2 = new QLabel( frameSASpresentation, "textLabel5_2" );
    textLabel5_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout87->addWidget( textLabel5_2 );
    layout91->addLayout( layout87 );

    layout88 = new QVBoxLayout( 0, 0, 6, "layout88"); 

    comboBoxSelectPresentationFrom = new QComboBox( FALSE, frameSASpresentation, "comboBoxSelectPresentationFrom" );
    comboBoxSelectPresentationFrom->setMaximumSize( QSize( 32767, 20 ) );
    comboBoxSelectPresentationFrom->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout88->addWidget( comboBoxSelectPresentationFrom );

    textLabelVia = new QLabel( frameSASpresentation, "textLabelVia" );
    layout88->addWidget( textLabelVia );

    comboBoxSelectPresentationTo = new QComboBox( FALSE, frameSASpresentation, "comboBoxSelectPresentationTo" );
    comboBoxSelectPresentationTo->setMaximumSize( QSize( 32767, 20 ) );
    comboBoxSelectPresentationTo->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout88->addWidget( comboBoxSelectPresentationTo );
    layout91->addLayout( layout88 );

    layout89 = new QVBoxLayout( 0, 0, 6, "layout89"); 

    textLabelPresFrom = new QLabel( frameSASpresentation, "textLabelPresFrom" );
    textLabelPresFrom->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelPresFrom->setAlignment( int( QLabel::AlignCenter ) );
    layout89->addWidget( textLabelPresFrom );

    textLabelPresVia = new QLabel( frameSASpresentation, "textLabelPresVia" );
    textLabelPresVia->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelPresVia->setAlignment( int( QLabel::AlignCenter ) );
    layout89->addWidget( textLabelPresVia );

    textLabelPresTo = new QLabel( frameSASpresentation, "textLabelPresTo" );
    textLabelPresTo->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelPresTo->setAlignment( int( QLabel::AlignCenter ) );
    layout89->addWidget( textLabelPresTo );
    layout91->addLayout( layout89 );
    frameSASpresentationLayout->addLayout( layout91 );
    spacer31 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Expanding );
    frameSASpresentationLayout->addItem( spacer31 );
    layout105->addWidget( frameSASpresentation );
    page2Layout->addLayout( layout105 );
    spacer33_4 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    page2Layout->addItem( spacer33_4 );
    toolBoxChange->addItem( page2, QString::fromLatin1("") );

    page = new QWidget( toolBoxChange, "page" );
    page->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout = new QVBoxLayout( page, 11, 6, "pageLayout"); 

    frame10 = new QFrame( page, "frame10" );
    frame10->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, frame10->sizePolicy().hasHeightForWidth() ) );
    frame10->setMaximumSize( QSize( 280, 32767 ) );
    frame10->setFrameShape( QFrame::StyledPanel );
    frame10->setFrameShadow( QFrame::Raised );
    frame10->setLineWidth( 0 );
    frame10Layout = new QHBoxLayout( frame10, 11, 6, "frame10Layout"); 

    layout198 = new QVBoxLayout( 0, 0, 6, "layout198"); 

    checkBoxRemoveRange = new QCheckBox( frame10, "checkBoxRemoveRange" );
    checkBoxRemoveRange->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, checkBoxRemoveRange->sizePolicy().hasHeightForWidth() ) );
    checkBoxRemoveRange->setMinimumSize( QSize( 0, 20 ) );
    checkBoxRemoveRange->setMaximumSize( QSize( 150, 20 ) );
    checkBoxRemoveRange->setChecked( FALSE );
    layout198->addWidget( checkBoxRemoveRange );

    checkBoxRemoveFirst = new QCheckBox( frame10, "checkBoxRemoveFirst" );
    checkBoxRemoveFirst->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, checkBoxRemoveFirst->sizePolicy().hasHeightForWidth() ) );
    checkBoxRemoveFirst->setMinimumSize( QSize( 0, 20 ) );
    checkBoxRemoveFirst->setMaximumSize( QSize( 150, 20 ) );
    checkBoxRemoveFirst->setChecked( FALSE );
    layout198->addWidget( checkBoxRemoveFirst );

    checkBoxRemoveLast = new QCheckBox( frame10, "checkBoxRemoveLast" );
    checkBoxRemoveLast->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, checkBoxRemoveLast->sizePolicy().hasHeightForWidth() ) );
    checkBoxRemoveLast->setMinimumSize( QSize( 0, 20 ) );
    checkBoxRemoveLast->setMaximumSize( QSize( 150, 20 ) );
    checkBoxRemoveLast->setChecked( FALSE );
    layout198->addWidget( checkBoxRemoveLast );

    checkBoxNoNegative = new QCheckBox( frame10, "checkBoxNoNegative" );
    checkBoxNoNegative->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, checkBoxNoNegative->sizePolicy().hasHeightForWidth() ) );
    layout198->addWidget( checkBoxNoNegative );
    frame10Layout->addLayout( layout198 );

    layout197 = new QVBoxLayout( 0, 0, 6, "layout197"); 

    layout196 = new QHBoxLayout( 0, 0, 6, "layout196"); 

    layout191 = new QVBoxLayout( 0, 0, 6, "layout191"); 

    textLabel6_3 = new QLabel( frame10, "textLabel6_3" );
    textLabel6_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel6_3->sizePolicy().hasHeightForWidth() ) );
    textLabel6_3->setMinimumSize( QSize( 0, 20 ) );
    textLabel6_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout191->addWidget( textLabel6_3 );

    textLabel6 = new QLabel( frame10, "textLabel6" );
    textLabel6->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel6->sizePolicy().hasHeightForWidth() ) );
    textLabel6->setMinimumSize( QSize( 0, 20 ) );
    textLabel6->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout191->addWidget( textLabel6 );

    textLabel6_2 = new QLabel( frame10, "textLabel6_2" );
    textLabel6_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel6_2->sizePolicy().hasHeightForWidth() ) );
    textLabel6_2->setMinimumSize( QSize( 0, 20 ) );
    textLabel6_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout191->addWidget( textLabel6_2 );
    layout196->addLayout( layout191 );

    layout192 = new QVBoxLayout( 0, 0, 6, "layout192"); 

    lineEditRemoveFrom = new QLineEdit( frame10, "lineEditRemoveFrom" );
    lineEditRemoveFrom->setEnabled( FALSE );
    lineEditRemoveFrom->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, lineEditRemoveFrom->sizePolicy().hasHeightForWidth() ) );
    lineEditRemoveFrom->setMinimumSize( QSize( 35, 20 ) );
    lineEditRemoveFrom->setMaximumSize( QSize( 350, 20 ) );
    lineEditRemoveFrom->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditRemoveFrom->setFrameShape( QLineEdit::LineEditPanel );
    lineEditRemoveFrom->setFrameShadow( QLineEdit::Sunken );
    layout192->addWidget( lineEditRemoveFrom );

    lineEditRemoveFirst = new QLineEdit( frame10, "lineEditRemoveFirst" );
    lineEditRemoveFirst->setEnabled( FALSE );
    lineEditRemoveFirst->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, lineEditRemoveFirst->sizePolicy().hasHeightForWidth() ) );
    lineEditRemoveFirst->setMinimumSize( QSize( 35, 20 ) );
    lineEditRemoveFirst->setMaximumSize( QSize( 350, 20 ) );
    lineEditRemoveFirst->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditRemoveFirst->setFrameShape( QLineEdit::LineEditPanel );
    lineEditRemoveFirst->setFrameShadow( QLineEdit::Sunken );
    layout192->addWidget( lineEditRemoveFirst );

    lineEditRemoveLast = new QLineEdit( frame10, "lineEditRemoveLast" );
    lineEditRemoveLast->setEnabled( FALSE );
    lineEditRemoveLast->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditRemoveLast->sizePolicy().hasHeightForWidth() ) );
    lineEditRemoveLast->setMinimumSize( QSize( 35, 20 ) );
    lineEditRemoveLast->setMaximumSize( QSize( 350, 20 ) );
    lineEditRemoveLast->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout192->addWidget( lineEditRemoveLast );
    layout196->addLayout( layout192 );

    layout193 = new QVBoxLayout( 0, 0, 6, "layout193"); 

    textLabel6_2_2 = new QLabel( frame10, "textLabel6_2_2" );
    textLabel6_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel6_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel6_2_2->setMinimumSize( QSize( 0, 20 ) );
    textLabel6_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout193->addWidget( textLabel6_2_2 );

    textLabel6_4 = new QLabel( frame10, "textLabel6_4" );
    textLabel6_4->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel6_4->sizePolicy().hasHeightForWidth() ) );
    textLabel6_4->setMinimumSize( QSize( 0, 20 ) );
    textLabel6_4->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout193->addWidget( textLabel6_4 );

    textLabel6_4_2 = new QLabel( frame10, "textLabel6_4_2" );
    textLabel6_4_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel6_4_2->sizePolicy().hasHeightForWidth() ) );
    textLabel6_4_2->setMinimumSize( QSize( 0, 20 ) );
    textLabel6_4_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout193->addWidget( textLabel6_4_2 );
    layout196->addLayout( layout193 );

    layout195 = new QVBoxLayout( 0, 0, 6, "layout195"); 

    layout194 = new QHBoxLayout( 0, 0, 6, "layout194"); 

    lineEditRemoveTo = new QLineEdit( frame10, "lineEditRemoveTo" );
    lineEditRemoveTo->setEnabled( FALSE );
    lineEditRemoveTo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, lineEditRemoveTo->sizePolicy().hasHeightForWidth() ) );
    lineEditRemoveTo->setMinimumSize( QSize( 35, 20 ) );
    lineEditRemoveTo->setMaximumSize( QSize( 35, 20 ) );
    lineEditRemoveTo->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout194->addWidget( lineEditRemoveTo );

    textLabel6_4_3 = new QLabel( frame10, "textLabel6_4_3" );
    textLabel6_4_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel6_4_3->sizePolicy().hasHeightForWidth() ) );
    textLabel6_4_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout194->addWidget( textLabel6_4_3 );
    layout195->addLayout( layout194 );
    spacer100 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Preferred );
    layout195->addItem( spacer100 );
    layout196->addLayout( layout195 );
    layout197->addLayout( layout196 );

    textLabel1_8 = new QLabel( frame10, "textLabel1_8" );
    textLabel1_8->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabel1_8->sizePolicy().hasHeightForWidth() ) );
    textLabel1_8->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout197->addWidget( textLabel1_8 );
    frame10Layout->addLayout( layout197 );
    pageLayout->addWidget( frame10 );
    spacer101 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout->addItem( spacer101 );
    toolBoxChange->addItem( page, QString::fromLatin1("") );

    page_2 = new QWidget( toolBoxChange, "page_2" );
    page_2->setBackgroundMode( QWidget::PaletteBackground );

    textLabelMath = new QLabel( page_2, "textLabelMath" );
    textLabelMath->setGeometry( QRect( 143, 94, 76, 20 ) );
    textLabelMath->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, textLabelMath->sizePolicy().hasHeightForWidth() ) );
    textLabelMath->setMinimumSize( QSize( 0, 20 ) );
    textLabelMath->setPaletteForegroundColor( QColor( 0, 0, 0 ) );
    textLabelMath->setFrameShape( QLabel::Box );
    textLabelMath->setAlignment( int( QLabel::AlignCenter ) );

    QWidget* privateLayoutWidget = new QWidget( page_2, "layout67" );
    privateLayoutWidget->setGeometry( QRect( 40, 21, 239, 24 ) );
    layout67 = new QHBoxLayout( privateLayoutWidget, 2, 6, "layout67"); 

    textLabelPresVia_2 = new QLabel( privateLayoutWidget, "textLabelPresVia_2" );
    textLabelPresVia_2->setMinimumSize( QSize( 105, 0 ) );
    textLabelPresVia_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelPresVia_2->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    layout67->addWidget( textLabelPresVia_2 );

    comboBoxMath = new QComboBox( FALSE, privateLayoutWidget, "comboBoxMath" );
    comboBoxMath->setEnabled( FALSE );
    comboBoxMath->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, comboBoxMath->sizePolicy().hasHeightForWidth() ) );
    comboBoxMath->setMinimumSize( QSize( 60, 0 ) );
    comboBoxMath->setMaximumSize( QSize( 60, 20 ) );
    comboBoxMath->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout67->addWidget( comboBoxMath );

    lineEditMath = new QLineEdit( privateLayoutWidget, "lineEditMath" );
    lineEditMath->setEnabled( FALSE );
    lineEditMath->setMinimumSize( QSize( 50, 0 ) );
    lineEditMath->setMaximumSize( QSize( 50, 20 ) );
    lineEditMath->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout67->addWidget( lineEditMath );

    QWidget* privateLayoutWidget_2 = new QWidget( page_2, "layout67_2" );
    privateLayoutWidget_2->setGeometry( QRect( 40, 51, 239, 24 ) );
    layout67_2 = new QHBoxLayout( privateLayoutWidget_2, 2, 6, "layout67_2"); 

    textLabelPresVia_2_2 = new QLabel( privateLayoutWidget_2, "textLabelPresVia_2_2" );
    textLabelPresVia_2_2->setMinimumSize( QSize( 105, 0 ) );
    textLabelPresVia_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelPresVia_2_2->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    layout67_2->addWidget( textLabelPresVia_2_2 );

    comboBoxMath2 = new QComboBox( FALSE, privateLayoutWidget_2, "comboBoxMath2" );
    comboBoxMath2->setEnabled( FALSE );
    comboBoxMath2->setMinimumSize( QSize( 60, 0 ) );
    comboBoxMath2->setMaximumSize( QSize( 60, 20 ) );
    comboBoxMath2->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout67_2->addWidget( comboBoxMath2 );

    lineEditMath2 = new QLineEdit( privateLayoutWidget_2, "lineEditMath2" );
    lineEditMath2->setEnabled( FALSE );
    lineEditMath2->setMinimumSize( QSize( 50, 0 ) );
    lineEditMath2->setMaximumSize( QSize( 50, 20 ) );
    lineEditMath2->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout67_2->addWidget( lineEditMath2 );

    textLabel1_4 = new QLabel( page_2, "textLabel1_4" );
    textLabel1_4->setGeometry( QRect( 61, 94, 76, 20 ) );
    textLabel1_4->setMinimumSize( QSize( 0, 20 ) );
    textLabel1_4->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    checkBoxMath = new QCheckBox( page_2, "checkBoxMath" );
    checkBoxMath->setGeometry( QRect( 21, 26, 16, 16 ) );

    checkBoxMath2 = new QCheckBox( page_2, "checkBoxMath2" );
    checkBoxMath2->setEnabled( FALSE );
    checkBoxMath2->setGeometry( QRect( 21, 56, 16, 16 ) );

    textLabel6_5 = new QLabel( page_2, "textLabel6_5" );
    textLabel6_5->setGeometry( QRect( 30, 150, 240, 70 ) );
    textLabel6_5->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    toolBoxChange->addItem( page_2, QString::fromLatin1("") );

    Page = new QWidget( toolBoxChange, "Page" );
    Page->setBackgroundMode( QWidget::PaletteBackground );

    comboBox1DclacTables = new QComboBox( FALSE, Page, "comboBox1DclacTables" );
    comboBox1DclacTables->setEnabled( FALSE );
    comboBox1DclacTables->setGeometry( QRect( 20, 150, 280, 20 ) );
    comboBox1DclacTables->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    textLabelPresVia_2_3 = new QLabel( Page, "textLabelPresVia_2_3" );
    textLabelPresVia_2_3->setGeometry( QRect( 60, 33, 130, 60 ) );
    textLabelPresVia_2_3->setMinimumSize( QSize( 105, 60 ) );
    textLabelPresVia_2_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelPresVia_2_3->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    checkBox1DCalculator = new QCheckBox( Page, "checkBox1DCalculator" );
    checkBox1DCalculator->setGeometry( QRect( 18, 7, 240, 20 ) );
    checkBox1DCalculator->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    comboBoxMath1D = new QComboBox( FALSE, Page, "comboBoxMath1D" );
    comboBoxMath1D->setEnabled( FALSE );
    comboBoxMath1D->setGeometry( QRect( 90, 110, 60, 20 ) );
    comboBoxMath1D->setMinimumSize( QSize( 60, 0 ) );
    comboBoxMath1D->setMaximumSize( QSize( 60, 20 ) );
    comboBoxMath1D->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    toolBoxChange->addItem( Page, QString::fromLatin1("") );

    page_3 = new QWidget( toolBoxChange, "page_3" );
    page_3->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_2 = new QVBoxLayout( page_3, 11, 6, "pageLayout_2"); 

    layout139 = new QVBoxLayout( 0, 0, 1, "layout139"); 

    checkBoxBinningLinear = new QCheckBox( page_3, "checkBoxBinningLinear" );
    checkBoxBinningLinear->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout139->addWidget( checkBoxBinningLinear );

    layout138 = new QHBoxLayout( 0, 0, 0, "layout138"); 

    textLabelPresVia_2_4 = new QLabel( page_3, "textLabelPresVia_2_4" );
    textLabelPresVia_2_4->setMinimumSize( QSize( 105, 0 ) );
    textLabelPresVia_2_4->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelPresVia_2_4->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    layout138->addWidget( textLabelPresVia_2_4 );

    spinBoxBinningLinear = new QSpinBox( page_3, "spinBoxBinningLinear" );
    spinBoxBinningLinear->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxBinningLinear->sizePolicy().hasHeightForWidth() ) );
    spinBoxBinningLinear->setMinimumSize( QSize( 65, 0 ) );
    spinBoxBinningLinear->setMaximumSize( QSize( 70, 32767 ) );
    spinBoxBinningLinear->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxBinningLinear->setMaxValue( 100 );
    spinBoxBinningLinear->setMinValue( 1 );
    layout138->addWidget( spinBoxBinningLinear );

    textLabelPresVia_2_4_2 = new QLabel( page_3, "textLabelPresVia_2_4_2" );
    textLabelPresVia_2_4_2->setMinimumSize( QSize( 105, 0 ) );
    textLabelPresVia_2_4_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelPresVia_2_4_2->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    layout138->addWidget( textLabelPresVia_2_4_2 );
    layout139->addLayout( layout138 );
    pageLayout_2->addLayout( layout139 );
    spacer80 = new QSpacerItem( 5, 20, QSizePolicy::Minimum, QSizePolicy::Fixed );
    pageLayout_2->addItem( spacer80 );

    layout143 = new QVBoxLayout( 0, 0, 1, "layout143"); 

    checkBoxBinningProgressive = new QCheckBox( page_3, "checkBoxBinningProgressive" );
    checkBoxBinningProgressive->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout143->addWidget( checkBoxBinningProgressive );

    layout142 = new QHBoxLayout( 0, 0, 1, "layout142"); 

    textLabelPresVia_2_4_3 = new QLabel( page_3, "textLabelPresVia_2_4_3" );
    textLabelPresVia_2_4_3->setMinimumSize( QSize( 105, 0 ) );
    textLabelPresVia_2_4_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelPresVia_2_4_3->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    layout142->addWidget( textLabelPresVia_2_4_3 );

    lineEditBinningProgressive = new QLineEdit( page_3, "lineEditBinningProgressive" );
    lineEditBinningProgressive->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, lineEditBinningProgressive->sizePolicy().hasHeightForWidth() ) );
    lineEditBinningProgressive->setMaximumSize( QSize( 70, 32767 ) );
    lineEditBinningProgressive->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    QFont lineEditBinningProgressive_font(  lineEditBinningProgressive->font() );
    lineEditBinningProgressive->setFont( lineEditBinningProgressive_font ); 
    lineEditBinningProgressive->setEchoMode( QLineEdit::Normal );
    lineEditBinningProgressive->setCursorPosition( 2 );
    lineEditBinningProgressive->setDragEnabled( FALSE );
    layout142->addWidget( lineEditBinningProgressive );
    layout143->addLayout( layout142 );
    pageLayout_2->addLayout( layout143 );
    spacer80_2 = new QSpacerItem( 5, 20, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_2->addItem( spacer80_2 );
    toolBoxChange->addItem( page_3, QString::fromLatin1("") );

    textLabelHelp = new QLabel( splitter9, "textLabelHelp" );
    textLabelHelp->setEnabled( TRUE );
    textLabelHelp->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, textLabelHelp->sizePolicy().hasHeightForWidth() ) );
    textLabelHelp->setMinimumSize( QSize( 10, 0 ) );
    textLabelHelp->setMaximumSize( QSize( 0, 435 ) );
    textLabelHelp->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    textLabelHelp->setPalette( pal );
    textLabelHelp->setFrameShape( QLabel::NoFrame );
    textLabelHelp->setLineWidth( 1 );
    textLabelHelp->setMargin( 10 );
    textLabelHelp->setTextFormat( QLabel::AutoText );
    textLabelHelp->setScaledContents( FALSE );
    textLabelHelp->setAlignment( int( QLabel::WordBreak | QLabel::AlignTop ) );
    layout108->addWidget( splitter9 );
    tabLayout->addLayout( layout108 );
    spacer28 = new QSpacerItem( 16, 16, QSizePolicy::Minimum, QSizePolicy::Expanding );
    tabLayout->addItem( spacer28 );
    sansTab->insertTab( tab, QString::fromLatin1("") );

    tab_2 = new QWidget( sansTab, "tab_2" );
    tabLayout_2 = new QVBoxLayout( tab_2, 11, 6, "tabLayout_2"); 

    layout66 = new QHBoxLayout( 0, 2, 2, "layout66"); 

    buttonGroupFileNumbers = new QButtonGroup( tab_2, "buttonGroupFileNumbers" );
    buttonGroupFileNumbers->setColumnLayout(0, Qt::Vertical );
    buttonGroupFileNumbers->layout()->setSpacing( 6 );
    buttonGroupFileNumbers->layout()->setMargin( 11 );
    buttonGroupFileNumbersLayout = new QGridLayout( buttonGroupFileNumbers->layout() );
    buttonGroupFileNumbersLayout->setAlignment( Qt::AlignTop );

    textLabel4_4 = new QLabel( buttonGroupFileNumbers, "textLabel4_4" );
    textLabel4_4->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    buttonGroupFileNumbersLayout->addWidget( textLabel4_4, 0, 0 );

    textLabel4_2 = new QLabel( buttonGroupFileNumbers, "textLabel4_2" );
    textLabel4_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    buttonGroupFileNumbersLayout->addWidget( textLabel4_2, 2, 0 );

    textLabel4_2_2 = new QLabel( buttonGroupFileNumbers, "textLabel4_2_2" );
    textLabel4_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    buttonGroupFileNumbersLayout->addWidget( textLabel4_2_2, 3, 0 );

    textLabel4_2_2_2 = new QLabel( buttonGroupFileNumbers, "textLabel4_2_2_2" );
    textLabel4_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    buttonGroupFileNumbersLayout->addWidget( textLabel4_2_2_2, 4, 0 );

    lineEditFileLast = new QLineEdit( buttonGroupFileNumbers, "lineEditFileLast" );
    lineEditFileLast->setMinimumSize( QSize( 50, 20 ) );
    lineEditFileLast->setMaximumSize( QSize( 1000, 20 ) );
    lineEditFileLast->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditFileLast->setFrameShape( QLineEdit::LineEditPanel );
    lineEditFileLast->setFrameShadow( QLineEdit::Sunken );

    buttonGroupFileNumbersLayout->addWidget( lineEditFileLast, 2, 1 );

    lineEditFileStep = new QLineEdit( buttonGroupFileNumbers, "lineEditFileStep" );
    lineEditFileStep->setMinimumSize( QSize( 50, 20 ) );
    lineEditFileStep->setMaximumSize( QSize( 1000, 20 ) );
    lineEditFileStep->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    buttonGroupFileNumbersLayout->addWidget( lineEditFileStep, 3, 1 );

    lineEditFileSuffix = new QLineEdit( buttonGroupFileNumbers, "lineEditFileSuffix" );
    lineEditFileSuffix->setMinimumSize( QSize( 40, 20 ) );
    lineEditFileSuffix->setMaximumSize( QSize( 1000, 20 ) );
    lineEditFileSuffix->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    buttonGroupFileNumbersLayout->addWidget( lineEditFileSuffix, 4, 1 );

    lineEditFileFirst = new QLineEdit( buttonGroupFileNumbers, "lineEditFileFirst" );
    lineEditFileFirst->setMinimumSize( QSize( 50, 20 ) );
    lineEditFileFirst->setMaximumSize( QSize( 1000, 20 ) );
    lineEditFileFirst->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditFileFirst->setFrameShape( QLineEdit::LineEditPanel );
    lineEditFileFirst->setFrameShadow( QLineEdit::Sunken );

    buttonGroupFileNumbersLayout->addWidget( lineEditFileFirst, 1, 1 );

    textLabel4 = new QLabel( buttonGroupFileNumbers, "textLabel4" );
    textLabel4->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    buttonGroupFileNumbersLayout->addWidget( textLabel4, 1, 0 );

    comboBoxSelectPresentationPlot = new QComboBox( FALSE, buttonGroupFileNumbers, "comboBoxSelectPresentationPlot" );
    comboBoxSelectPresentationPlot->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, comboBoxSelectPresentationPlot->sizePolicy().hasHeightForWidth() ) );
    comboBoxSelectPresentationPlot->setMinimumSize( QSize( 0, 20 ) );
    comboBoxSelectPresentationPlot->setMaximumSize( QSize( 10000, 20 ) );
    comboBoxSelectPresentationPlot->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    comboBoxSelectPresentationPlot->setEditable( TRUE );
    comboBoxSelectPresentationPlot->setMaxCount( 200 );

    buttonGroupFileNumbersLayout->addWidget( comboBoxSelectPresentationPlot, 0, 1 );
    layout66->addWidget( buttonGroupFileNumbers );

    buttonGroupDanp = new QButtonGroup( tab_2, "buttonGroupDanp" );
    buttonGroupDanp->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroupDanp->sizePolicy().hasHeightForWidth() ) );
    buttonGroupDanp->setColumnLayout(0, Qt::Vertical );
    buttonGroupDanp->layout()->setSpacing( 6 );
    buttonGroupDanp->layout()->setMargin( 11 );
    buttonGroupDanpLayout = new QVBoxLayout( buttonGroupDanp->layout() );
    buttonGroupDanpLayout->setAlignment( Qt::AlignTop );

    pushButtonplotRange = new QToolButton( buttonGroupDanp, "pushButtonplotRange" );
    pushButtonplotRange->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonplotRange->sizePolicy().hasHeightForWidth() ) );
    pushButtonplotRange->setMinimumSize( QSize( 0, 25 ) );
    pushButtonplotRange->setMaximumSize( QSize( 32767, 25 ) );
    buttonGroupDanpLayout->addWidget( pushButtonplotRange );

    pushButtonCLEAR = new QToolButton( buttonGroupDanp, "pushButtonCLEAR" );
    pushButtonCLEAR->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonCLEAR->sizePolicy().hasHeightForWidth() ) );
    pushButtonCLEAR->setMinimumSize( QSize( 0, 25 ) );
    pushButtonCLEAR->setMaximumSize( QSize( 32767, 25 ) );
    buttonGroupDanpLayout->addWidget( pushButtonCLEAR );

    checkBoxXerror = new QCheckBox( buttonGroupDanp, "checkBoxXerror" );
    checkBoxXerror->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroupDanpLayout->addWidget( checkBoxXerror );

    checkBoxYerror = new QCheckBox( buttonGroupDanp, "checkBoxYerror" );
    checkBoxYerror->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxYerror->setChecked( FALSE );
    buttonGroupDanpLayout->addWidget( checkBoxYerror );
    spacer129_2 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    buttonGroupDanpLayout->addItem( spacer129_2 );
    layout66->addWidget( buttonGroupDanp );

    buttonGroup35 = new QButtonGroup( tab_2, "buttonGroup35" );
    buttonGroup35->setColumnLayout(0, Qt::Vertical );
    buttonGroup35->layout()->setSpacing( 6 );
    buttonGroup35->layout()->setMargin( 11 );
    buttonGroup35Layout = new QVBoxLayout( buttonGroup35->layout() );
    buttonGroup35Layout->setAlignment( Qt::AlignTop );

    pushButtonPlotTitels = new QToolButton( buttonGroup35, "pushButtonPlotTitels" );
    pushButtonPlotTitels->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonPlotTitels->sizePolicy().hasHeightForWidth() ) );
    pushButtonPlotTitels->setMinimumSize( QSize( 0, 25 ) );
    pushButtonPlotTitels->setMaximumSize( QSize( 32767, 25 ) );
    buttonGroup35Layout->addWidget( pushButtonPlotTitels );

    pushButtonLinLin = new QToolButton( buttonGroup35, "pushButtonLinLin" );
    pushButtonLinLin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonLinLin->sizePolicy().hasHeightForWidth() ) );
    pushButtonLinLin->setMinimumSize( QSize( 0, 25 ) );
    pushButtonLinLin->setMaximumSize( QSize( 32767, 25 ) );
    buttonGroup35Layout->addWidget( pushButtonLinLin );

    pushButtonLogLog = new QToolButton( buttonGroup35, "pushButtonLogLog" );
    pushButtonLogLog->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonLogLog->sizePolicy().hasHeightForWidth() ) );
    pushButtonLogLog->setMinimumSize( QSize( 0, 25 ) );
    pushButtonLogLog->setMaximumSize( QSize( 32767, 25 ) );
    buttonGroup35Layout->addWidget( pushButtonLogLog );

    buttonGroupLogLog = new QButtonGroup( buttonGroup35, "buttonGroupLogLog" );
    buttonGroupLogLog->setCheckable( TRUE );
    buttonGroupLogLog->setChecked( FALSE );
    buttonGroupLogLog->setColumnLayout(0, Qt::Vertical );
    buttonGroupLogLog->layout()->setSpacing( 6 );
    buttonGroupLogLog->layout()->setMargin( 11 );
    buttonGroupLogLogLayout = new QVBoxLayout( buttonGroupLogLog->layout() );
    buttonGroupLogLogLayout->setAlignment( Qt::AlignTop );

    layout142_2 = new QGridLayout( 0, 1, 1, 0, 6, "layout142_2"); 

    spinBoxLogMaxX = new QSpinBox( buttonGroupLogLog, "spinBoxLogMaxX" );
    spinBoxLogMaxX->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxLogMaxX->setMinValue( -99 );
    spinBoxLogMaxX->setValue( 0 );

    layout142_2->addWidget( spinBoxLogMaxX, 0, 2 );

    textLabel4_4_2 = new QLabel( buttonGroupLogLog, "textLabel4_4_2" );
    textLabel4_4_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    layout142_2->addWidget( textLabel4_4_2, 0, 0 );

    spinBoxLogMinX = new QSpinBox( buttonGroupLogLog, "spinBoxLogMinX" );
    spinBoxLogMinX->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxLogMinX->setMinValue( -99 );
    spinBoxLogMinX->setValue( -3 );

    layout142_2->addWidget( spinBoxLogMinX, 0, 1 );

    spinBoxLogMinY = new QSpinBox( buttonGroupLogLog, "spinBoxLogMinY" );
    spinBoxLogMinY->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxLogMinY->setMinValue( -99 );
    spinBoxLogMinY->setValue( -1 );

    layout142_2->addWidget( spinBoxLogMinY, 1, 1 );

    textLabel4_4_3 = new QLabel( buttonGroupLogLog, "textLabel4_4_3" );
    textLabel4_4_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    layout142_2->addWidget( textLabel4_4_3, 1, 0 );

    spinBoxLogMaxY = new QSpinBox( buttonGroupLogLog, "spinBoxLogMaxY" );
    spinBoxLogMaxY->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxLogMaxY->setMinValue( -99 );
    spinBoxLogMaxY->setValue( 2 );

    layout142_2->addWidget( spinBoxLogMaxY, 1, 2 );
    buttonGroupLogLogLayout->addLayout( layout142_2 );
    buttonGroup35Layout->addWidget( buttonGroupLogLog );
    spacer129 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    buttonGroup35Layout->addItem( spacer129 );
    layout66->addWidget( buttonGroup35 );
    tabLayout_2->addLayout( layout66 );
    spacer13 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Preferred );
    tabLayout_2->addItem( spacer13 );

    buttonGroup42 = new QButtonGroup( tab_2, "buttonGroup42" );
    buttonGroup42->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup42->sizePolicy().hasHeightForWidth() ) );
    buttonGroup42->setColumnLayout(0, Qt::Vertical );
    buttonGroup42->layout()->setSpacing( 6 );
    buttonGroup42->layout()->setMargin( 11 );
    buttonGroup42Layout = new QVBoxLayout( buttonGroup42->layout() );
    buttonGroup42Layout->setAlignment( Qt::AlignTop );

    layout15_2 = new QHBoxLayout( 0, 0, 6, "layout15_2"); 

    radioButtonPlotCurveNames = new QRadioButton( buttonGroup42, "radioButtonPlotCurveNames" );
    radioButtonPlotCurveNames->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    radioButtonPlotCurveNames->setChecked( TRUE );
    layout15_2->addWidget( radioButtonPlotCurveNames );

    radioButtonPlotTableNames = new QRadioButton( buttonGroup42, "radioButtonPlotTableNames" );
    radioButtonPlotTableNames->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout15_2->addWidget( radioButtonPlotTableNames );

    radioButtonPlotCurveLabels = new QRadioButton( buttonGroup42, "radioButtonPlotCurveLabels" );
    radioButtonPlotCurveLabels->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout15_2->addWidget( radioButtonPlotCurveLabels );

    radioButtonPlotTableLabels = new QRadioButton( buttonGroup42, "radioButtonPlotTableLabels" );
    radioButtonPlotTableLabels->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout15_2->addWidget( radioButtonPlotTableLabels );
    buttonGroup42Layout->addLayout( layout15_2 );

    lineEditPlotFilter = new QLineEdit( buttonGroup42, "lineEditPlotFilter" );
    lineEditPlotFilter->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditPlotFilter->setLineWidth( 1 );
    buttonGroup42Layout->addWidget( lineEditPlotFilter );

    layout259 = new QHBoxLayout( 0, 0, 6, "layout259"); 

    pushButtonPlotByFilter = new QToolButton( buttonGroup42, "pushButtonPlotByFilter" );
    pushButtonPlotByFilter->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonPlotByFilter->sizePolicy().hasHeightForWidth() ) );
    pushButtonPlotByFilter->setMinimumSize( QSize( 0, 25 ) );
    pushButtonPlotByFilter->setMaximumSize( QSize( 32767, 25 ) );
    layout259->addWidget( pushButtonPlotByFilter );

    pushButtonRemoveByFilter = new QToolButton( buttonGroup42, "pushButtonRemoveByFilter" );
    pushButtonRemoveByFilter->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonRemoveByFilter->sizePolicy().hasHeightForWidth() ) );
    pushButtonRemoveByFilter->setMinimumSize( QSize( 0, 25 ) );
    pushButtonRemoveByFilter->setMaximumSize( QSize( 32767, 25 ) );
    layout259->addWidget( pushButtonRemoveByFilter );
    buttonGroup42Layout->addLayout( layout259 );

    pushButtonAddLegend = new QToolButton( buttonGroup42, "pushButtonAddLegend" );
    pushButtonAddLegend->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonAddLegend->sizePolicy().hasHeightForWidth() ) );
    pushButtonAddLegend->setMinimumSize( QSize( 0, 25 ) );
    pushButtonAddLegend->setMaximumSize( QSize( 32767, 25 ) );
    buttonGroup42Layout->addWidget( pushButtonAddLegend );
    tabLayout_2->addWidget( buttonGroup42 );
    spacer14 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Preferred );
    tabLayout_2->addItem( spacer14 );

    layout136 = new QHBoxLayout( 0, 0, 6, "layout136"); 

    buttonGroup71 = new QButtonGroup( tab_2, "buttonGroup71" );
    buttonGroup71->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup71->sizePolicy().hasHeightForWidth() ) );
    buttonGroup71->setColumnLayout(0, Qt::Vertical );
    buttonGroup71->layout()->setSpacing( 6 );
    buttonGroup71->layout()->setMargin( 11 );
    buttonGroup71Layout = new QHBoxLayout( buttonGroup71->layout() );
    buttonGroup71Layout->setAlignment( Qt::AlignTop );

    comboBoxSchemaAim = new QComboBox( FALSE, buttonGroup71, "comboBoxSchemaAim" );
    comboBoxSchemaAim->setEnabled( TRUE );
    comboBoxSchemaAim->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, comboBoxSchemaAim->sizePolicy().hasHeightForWidth() ) );
    comboBoxSchemaAim->setMinimumSize( QSize( 0, 25 ) );
    comboBoxSchemaAim->setMaximumSize( QSize( 120, 32767 ) );
    comboBoxSchemaAim->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup71Layout->addWidget( comboBoxSchemaAim );

    comboBoxSchema1D = new QComboBox( FALSE, buttonGroup71, "comboBoxSchema1D" );
    comboBoxSchema1D->setEnabled( TRUE );
    comboBoxSchema1D->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxSchema1D->sizePolicy().hasHeightForWidth() ) );
    comboBoxSchema1D->setMinimumSize( QSize( 0, 25 ) );
    comboBoxSchema1D->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup71Layout->addWidget( comboBoxSchema1D );

    pushButtonColorSchemaAccept = new QToolButton( buttonGroup71, "pushButtonColorSchemaAccept" );
    pushButtonColorSchemaAccept->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonColorSchemaAccept->sizePolicy().hasHeightForWidth() ) );
    pushButtonColorSchemaAccept->setMinimumSize( QSize( 25, 25 ) );
    pushButtonColorSchemaAccept->setMaximumSize( QSize( 25, 25 ) );
    pushButtonColorSchemaAccept->setIconSet( QIconSet( image4 ) );
    buttonGroup71Layout->addWidget( pushButtonColorSchemaAccept );

    pushButtonEditColorSchema = new QToolButton( buttonGroup71, "pushButtonEditColorSchema" );
    pushButtonEditColorSchema->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonEditColorSchema->sizePolicy().hasHeightForWidth() ) );
    pushButtonEditColorSchema->setMinimumSize( QSize( 25, 25 ) );
    pushButtonEditColorSchema->setMaximumSize( QSize( 25, 25 ) );
    pushButtonEditColorSchema->setIconSet( QIconSet( image5 ) );
    buttonGroup71Layout->addWidget( pushButtonEditColorSchema );

    pushButtonsaveCurrentSaveColorSchema = new QToolButton( buttonGroup71, "pushButtonsaveCurrentSaveColorSchema" );
    pushButtonsaveCurrentSaveColorSchema->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonsaveCurrentSaveColorSchema->sizePolicy().hasHeightForWidth() ) );
    pushButtonsaveCurrentSaveColorSchema->setMinimumSize( QSize( 25, 25 ) );
    pushButtonsaveCurrentSaveColorSchema->setMaximumSize( QSize( 25, 25 ) );
    pushButtonsaveCurrentSaveColorSchema->setIconSet( QIconSet( image3 ) );
    buttonGroup71Layout->addWidget( pushButtonsaveCurrentSaveColorSchema );

    pushButtonDeleteColorSchema = new QToolButton( buttonGroup71, "pushButtonDeleteColorSchema" );
    pushButtonDeleteColorSchema->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonDeleteColorSchema->sizePolicy().hasHeightForWidth() ) );
    pushButtonDeleteColorSchema->setMinimumSize( QSize( 25, 25 ) );
    pushButtonDeleteColorSchema->setMaximumSize( QSize( 25, 25 ) );
    pushButtonDeleteColorSchema->setIconSet( QIconSet( image2 ) );
    buttonGroup71Layout->addWidget( pushButtonDeleteColorSchema );
    layout136->addWidget( buttonGroup71 );

    buttonGroup68 = new QButtonGroup( tab_2, "buttonGroup68" );
    buttonGroup68->setColumnLayout(0, Qt::Vertical );
    buttonGroup68->layout()->setSpacing( 6 );
    buttonGroup68->layout()->setMargin( 11 );
    buttonGroup68Layout = new QHBoxLayout( buttonGroup68->layout() );
    buttonGroup68Layout->setAlignment( Qt::AlignTop );

    comboBoxMovePointXorY = new QComboBox( FALSE, buttonGroup68, "comboBoxMovePointXorY" );
    comboBoxMovePointXorY->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, comboBoxMovePointXorY->sizePolicy().hasHeightForWidth() ) );
    comboBoxMovePointXorY->setMinimumSize( QSize( 40, 0 ) );
    comboBoxMovePointXorY->setMaximumSize( QSize( 40, 25 ) );
    buttonGroup68Layout->addWidget( comboBoxMovePointXorY );

    comboBoxMovePointLevel = new QComboBox( FALSE, buttonGroup68, "comboBoxMovePointLevel" );
    comboBoxMovePointLevel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, comboBoxMovePointLevel->sizePolicy().hasHeightForWidth() ) );
    comboBoxMovePointLevel->setMaximumSize( QSize( 60, 25 ) );
    buttonGroup68Layout->addWidget( comboBoxMovePointLevel );

    pushButtonMovePointPlus = new QToolButton( buttonGroup68, "pushButtonMovePointPlus" );
    pushButtonMovePointPlus->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonMovePointPlus->sizePolicy().hasHeightForWidth() ) );
    pushButtonMovePointPlus->setMinimumSize( QSize( 25, 25 ) );
    pushButtonMovePointPlus->setMaximumSize( QSize( 25, 25 ) );
    pushButtonMovePointPlus->setIconSet( QIconSet(  ) );
    buttonGroup68Layout->addWidget( pushButtonMovePointPlus );

    pushButtonMovePointMinus = new QToolButton( buttonGroup68, "pushButtonMovePointMinus" );
    pushButtonMovePointMinus->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonMovePointMinus->sizePolicy().hasHeightForWidth() ) );
    pushButtonMovePointMinus->setMinimumSize( QSize( 25, 25 ) );
    pushButtonMovePointMinus->setMaximumSize( QSize( 25, 25 ) );
    buttonGroup68Layout->addWidget( pushButtonMovePointMinus );
    layout136->addWidget( buttonGroup68 );
    tabLayout_2->addLayout( layout136 );
    spacer23 = new QSpacerItem( 5, 5, QSizePolicy::Minimum, QSizePolicy::Expanding );
    tabLayout_2->addItem( spacer23 );
    sansTab->insertTab( tab_2, QString::fromLatin1("") );

    TabPage_2 = new QWidget( sansTab, "TabPage_2" );
    TabPageLayout_2 = new QVBoxLayout( TabPage_2, 11, 6, "TabPageLayout_2"); 

    groupBox28 = new QGroupBox( TabPage_2, "groupBox28" );
    groupBox28->setMaximumSize( QSize( 32767, 135 ) );
    groupBox28->setColumnLayout(0, Qt::Vertical );
    groupBox28->layout()->setSpacing( 6 );
    groupBox28->layout()->setMargin( 11 );
    groupBox28Layout = new QHBoxLayout( groupBox28->layout() );
    groupBox28Layout->setAlignment( Qt::AlignTop );

    layout74 = new QHBoxLayout( 0, 0, 6, "layout74"); 

    layout72 = new QVBoxLayout( 0, 0, 6, "layout72"); 

    spinBoxNtoMerge = new QSpinBox( groupBox28, "spinBoxNtoMerge" );
    spinBoxNtoMerge->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxNtoMerge->sizePolicy().hasHeightForWidth() ) );
    spinBoxNtoMerge->setMinimumSize( QSize( 65, 0 ) );
    spinBoxNtoMerge->setMaximumSize( QSize( 70, 32767 ) );
    spinBoxNtoMerge->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxNtoMerge->setMaxValue( 999 );
    spinBoxNtoMerge->setValue( 0 );
    layout72->addWidget( spinBoxNtoMerge );

    spinBoxMmergingCond = new QSpinBox( groupBox28, "spinBoxMmergingCond" );
    spinBoxMmergingCond->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxMmergingCond->sizePolicy().hasHeightForWidth() ) );
    spinBoxMmergingCond->setMinimumSize( QSize( 65, 0 ) );
    spinBoxMmergingCond->setMaximumSize( QSize( 70, 32767 ) );
    spinBoxMmergingCond->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxMmergingCond->setMaxValue( 999 );
    layout72->addWidget( spinBoxMmergingCond );

    spinBoxOverlap = new QSpinBox( groupBox28, "spinBoxOverlap" );
    spinBoxOverlap->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, spinBoxOverlap->sizePolicy().hasHeightForWidth() ) );
    spinBoxOverlap->setMinimumSize( QSize( 65, 0 ) );
    spinBoxOverlap->setMaximumSize( QSize( 70, 2000 ) );
    spinBoxOverlap->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxOverlap->setMaxValue( 100 );
    spinBoxOverlap->setValue( 100 );
    layout72->addWidget( spinBoxOverlap );

    spinBoxRefForMerging = new QSpinBox( groupBox28, "spinBoxRefForMerging" );
    spinBoxRefForMerging->setMinimumSize( QSize( 66, 0 ) );
    spinBoxRefForMerging->setMaximumSize( QSize( 70, 32767 ) );
    spinBoxRefForMerging->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxRefForMerging->setMinValue( 1 );
    spinBoxRefForMerging->setValue( 1 );
    layout72->addWidget( spinBoxRefForMerging );
    layout74->addLayout( layout72 );

    layout73 = new QVBoxLayout( 0, 0, 6, "layout73"); 

    textLabel1_5 = new QLabel( groupBox28, "textLabel1_5" );
    textLabel1_5->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, textLabel1_5->sizePolicy().hasHeightForWidth() ) );
    textLabel1_5->setMaximumSize( QSize( 32767, 20 ) );
    textLabel1_5->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabel1_5->setAlignment( int( QLabel::AlignBottom ) );
    layout73->addWidget( textLabel1_5 );

    textLabel1_5_2 = new QLabel( groupBox28, "textLabel1_5_2" );
    textLabel1_5_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, textLabel1_5_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_5_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabel1_5_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabel1_5_2->setAlignment( int( QLabel::AlignBottom | QLabel::AlignLeft ) );
    layout73->addWidget( textLabel1_5_2 );

    textLabel1 = new QLabel( groupBox28, "textLabel1" );
    textLabel1->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel1->sizePolicy().hasHeightForWidth() ) );
    textLabel1->setMaximumSize( QSize( 150, 1000 ) );
    textLabel1->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout73->addWidget( textLabel1 );

    textLabel1_5_3_2 = new QLabel( groupBox28, "textLabel1_5_3_2" );
    textLabel1_5_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout73->addWidget( textLabel1_5_3_2 );
    layout74->addLayout( layout73 );
    groupBox28Layout->addLayout( layout74 );
    spacer37 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    groupBox28Layout->addItem( spacer37 );

    layout113 = new QVBoxLayout( 0, 0, 6, "layout113"); 

    textLabel1_5_3 = new QLabel( groupBox28, "textLabel1_5_3" );
    textLabel1_5_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, textLabel1_5_3->sizePolicy().hasHeightForWidth() ) );
    textLabel1_5_3->setMaximumSize( QSize( 32767, 3000 ) );
    textLabel1_5_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabel1_5_3->setAlignment( int( QLabel::AlignBottom ) );
    layout113->addWidget( textLabel1_5_3 );

    lineEditFilter = new QLineEdit( groupBox28, "lineEditFilter" );
    lineEditFilter->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditFilter->sizePolicy().hasHeightForWidth() ) );
    lineEditFilter->setMinimumSize( QSize( 30, 0 ) );
    lineEditFilter->setMaximumSize( QSize( 700, 32767 ) );
    lineEditFilter->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout113->addWidget( lineEditFilter );

    layout112 = new QHBoxLayout( 0, 0, 0, "layout112"); 

    checkBoxSmart = new QCheckBox( groupBox28, "checkBoxSmart" );
    checkBoxSmart->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout112->addWidget( checkBoxSmart );

    comboBoxSmartSelect = new QComboBox( FALSE, groupBox28, "comboBoxSmartSelect" );
    layout112->addWidget( comboBoxSmartSelect );
    layout113->addLayout( layout112 );

    checkBoxMergeIndexing = new QCheckBox( groupBox28, "checkBoxMergeIndexing" );
    checkBoxMergeIndexing->setEnabled( TRUE );
    checkBoxMergeIndexing->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxMergeIndexing->setChecked( FALSE );
    layout113->addWidget( checkBoxMergeIndexing );
    groupBox28Layout->addLayout( layout113 );
    TabPageLayout_2->addWidget( groupBox28 );

    tableMerge = new QTable( TabPage_2, "tableMerge" );
    tableMerge->setNumCols( tableMerge->numCols() + 1 );
    tableMerge->horizontalHeader()->setLabel( tableMerge->numCols() - 1, tr( "New Name" ) );
    tableMerge->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, tableMerge->sizePolicy().hasHeightForWidth() ) );
    tableMerge->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    tableMerge->setNumRows( 0 );
    tableMerge->setNumCols( 1 );
    TabPageLayout_2->addWidget( tableMerge );

    layout260 = new QHBoxLayout( 0, 0, 6, "layout260"); 

    pushButtonDefineMergeFromTable = new QToolButton( TabPage_2, "pushButtonDefineMergeFromTable" );
    pushButtonDefineMergeFromTable->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonDefineMergeFromTable->sizePolicy().hasHeightForWidth() ) );
    pushButtonDefineMergeFromTable->setMinimumSize( QSize( 0, 25 ) );
    pushButtonDefineMergeFromTable->setMaximumSize( QSize( 32767, 25 ) );
    layout260->addWidget( pushButtonDefineMergeFromTable );

    pushButtonSaveMergeDataToTable = new QToolButton( TabPage_2, "pushButtonSaveMergeDataToTable" );
    pushButtonSaveMergeDataToTable->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonSaveMergeDataToTable->sizePolicy().hasHeightForWidth() ) );
    pushButtonSaveMergeDataToTable->setMinimumSize( QSize( 0, 25 ) );
    pushButtonSaveMergeDataToTable->setMaximumSize( QSize( 32767, 25 ) );
    layout260->addWidget( pushButtonSaveMergeDataToTable );
    TabPageLayout_2->addLayout( layout260 );

    layout219 = new QHBoxLayout( 0, 0, 6, "layout219"); 

    pushButtonMerge = new QToolButton( TabPage_2, "pushButtonMerge" );
    pushButtonMerge->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonMerge->sizePolicy().hasHeightForWidth() ) );
    pushButtonMerge->setMinimumSize( QSize( 0, 25 ) );
    pushButtonMerge->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonMerge->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    pushButtonMerge->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonMerge_font(  pushButtonMerge->font() );
    pushButtonMerge_font.setBold( TRUE );
    pushButtonMerge->setFont( pushButtonMerge_font ); 
    layout219->addWidget( pushButtonMerge );

    checkBoxMergeAscii = new QCheckBox( TabPage_2, "checkBoxMergeAscii" );
    checkBoxMergeAscii->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout219->addWidget( checkBoxMergeAscii );
    TabPageLayout_2->addLayout( layout219 );
    sansTab->insertTab( TabPage_2, QString::fromLatin1("") );

    TabPage_3 = new QWidget( sansTab, "TabPage_3" );
    TabPageLayout_3 = new QVBoxLayout( TabPage_3, 11, 6, "TabPageLayout_3"); 

    toolBoxMatrixes = new QToolBox( TabPage_3, "toolBoxMatrixes" );
    toolBoxMatrixes->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, toolBoxMatrixes->sizePolicy().hasHeightForWidth() ) );
    toolBoxMatrixes->setFrameShape( QToolBox::NoFrame );
    toolBoxMatrixes->setCurrentIndex( 0 );

    page1_2 = new QWidget( toolBoxMatrixes, "page1_2" );
    page1_2->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout_2 = new QVBoxLayout( page1_2, 11, 6, "page1Layout_2"); 

    buttonGroup38 = new QButtonGroup( page1_2, "buttonGroup38" );
    buttonGroup38->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroup38->sizePolicy().hasHeightForWidth() ) );
    buttonGroup38->setColumnLayout(0, Qt::Vertical );
    buttonGroup38->layout()->setSpacing( 6 );
    buttonGroup38->layout()->setMargin( 11 );
    buttonGroup38Layout = new QHBoxLayout( buttonGroup38->layout() );
    buttonGroup38Layout->setAlignment( Qt::AlignTop );

    comboBoxInstrument = new QComboBox( FALSE, buttonGroup38, "comboBoxInstrument" );
    comboBoxInstrument->setMinimumSize( QSize( 0, 30 ) );
    comboBoxInstrument->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup38Layout->addWidget( comboBoxInstrument );

    pushButtonsaveCurrentSave2Dtype = new QToolButton( buttonGroup38, "pushButtonsaveCurrentSave2Dtype" );
    pushButtonsaveCurrentSave2Dtype->setEnabled( FALSE );
    pushButtonsaveCurrentSave2Dtype->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonsaveCurrentSave2Dtype->sizePolicy().hasHeightForWidth() ) );
    pushButtonsaveCurrentSave2Dtype->setMinimumSize( QSize( 26, 30 ) );
    pushButtonsaveCurrentSave2Dtype->setMaximumSize( QSize( 26, 30 ) );
    pushButtonsaveCurrentSave2Dtype->setIconSet( QIconSet( image3 ) );
    buttonGroup38Layout->addWidget( pushButtonsaveCurrentSave2Dtype );

    pushButtonDeleteCurrentSave2Dtype = new QToolButton( buttonGroup38, "pushButtonDeleteCurrentSave2Dtype" );
    pushButtonDeleteCurrentSave2Dtype->setEnabled( FALSE );
    pushButtonDeleteCurrentSave2Dtype->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonDeleteCurrentSave2Dtype->sizePolicy().hasHeightForWidth() ) );
    pushButtonDeleteCurrentSave2Dtype->setMinimumSize( QSize( 26, 30 ) );
    pushButtonDeleteCurrentSave2Dtype->setMaximumSize( QSize( 26, 30 ) );
    pushButtonDeleteCurrentSave2Dtype->setIconSet( QIconSet( image2 ) );
    buttonGroup38Layout->addWidget( pushButtonDeleteCurrentSave2Dtype );
    page1Layout_2->addWidget( buttonGroup38 );

    layout94 = new QHBoxLayout( 0, 0, 6, "layout94"); 

    buttonGroup61 = new QButtonGroup( page1_2, "buttonGroup61" );
    buttonGroup61->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, buttonGroup61->sizePolicy().hasHeightForWidth() ) );
    buttonGroup61->setMinimumSize( QSize( 0, 140 ) );
    buttonGroup61->setMaximumSize( QSize( 32767, 120 ) );
    buttonGroup61->setColumnLayout(0, Qt::Vertical );
    buttonGroup61->layout()->setSpacing( 6 );
    buttonGroup61->layout()->setMargin( 11 );
    buttonGroup61Layout = new QVBoxLayout( buttonGroup61->layout() );
    buttonGroup61Layout->setAlignment( Qt::AlignTop );

    layout93 = new QGridLayout( 0, 1, 1, 2, 2, "layout93"); 

    spinBoxLoadPos = new QSpinBox( buttonGroup61, "spinBoxLoadPos" );
    spinBoxLoadPos->setEnabled( FALSE );
    spinBoxLoadPos->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxLoadPos->setMaxValue( 10000 );
    spinBoxLoadPos->setMinValue( 1 );
    spinBoxLoadPos->setValue( 8 );

    layout93->addWidget( spinBoxLoadPos, 1, 0 );

    textLabel1_3_2 = new QLabel( buttonGroup61, "textLabel1_3_2" );
    textLabel1_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel1_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    layout93->addWidget( textLabel1_3_2, 1, 1 );

    spinBoxLoadSkip = new QSpinBox( buttonGroup61, "spinBoxLoadSkip" );
    spinBoxLoadSkip->setEnabled( FALSE );
    spinBoxLoadSkip->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxLoadSkip->setMaxValue( 2147483647 );
    spinBoxLoadSkip->setValue( 70 );

    layout93->addWidget( spinBoxLoadSkip, 0, 0 );

    textLabel1_3 = new QLabel( buttonGroup61, "textLabel1_3" );
    textLabel1_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel1_3->sizePolicy().hasHeightForWidth() ) );
    textLabel1_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    layout93->addWidget( textLabel1_3, 0, 1 );
    buttonGroup61Layout->addLayout( layout93 );
    spacer19 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    buttonGroup61Layout->addItem( spacer19 );
    layout94->addWidget( buttonGroup61 );

    groupBox32 = new QGroupBox( page1_2, "groupBox32" );
    groupBox32->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, groupBox32->sizePolicy().hasHeightForWidth() ) );
    groupBox32->setMinimumSize( QSize( 0, 140 ) );
    groupBox32->setMaximumSize( QSize( 32767, 120 ) );
    groupBox32->setColumnLayout(0, Qt::Vertical );
    groupBox32->layout()->setSpacing( 6 );
    groupBox32->layout()->setMargin( 11 );
    groupBox32Layout = new QVBoxLayout( groupBox32->layout() );
    groupBox32Layout->setAlignment( Qt::AlignTop );

    layout92 = new QHBoxLayout( 0, 2, 2, "layout92"); 

    spinBoxLoadDimension = new QSpinBox( groupBox32, "spinBoxLoadDimension" );
    spinBoxLoadDimension->setEnabled( FALSE );
    spinBoxLoadDimension->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxLoadDimension->setMaxValue( 10000 );
    spinBoxLoadDimension->setMinValue( 1 );
    spinBoxLoadDimension->setValue( 128 );
    layout92->addWidget( spinBoxLoadDimension );

    textLabelLoad_3_2_2 = new QLabel( groupBox32, "textLabelLoad_3_2_2" );
    textLabelLoad_3_2_2->setEnabled( FALSE );
    textLabelLoad_3_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout92->addWidget( textLabelLoad_3_2_2 );

    spinBoxLoadDimension_2 = new QSpinBox( groupBox32, "spinBoxLoadDimension_2" );
    spinBoxLoadDimension_2->setEnabled( FALSE );
    spinBoxLoadDimension_2->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxLoadDimension_2->setMaxValue( 10000 );
    spinBoxLoadDimension_2->setValue( 128 );
    layout92->addWidget( spinBoxLoadDimension_2 );

    textLabel1_3_2_3_2 = new QLabel( groupBox32, "textLabel1_3_2_3_2" );
    textLabel1_3_2_3_2->setEnabled( FALSE );
    textLabel1_3_2_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel1_3_2_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_3_2_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout92->addWidget( textLabel1_3_2_3_2 );
    groupBox32Layout->addLayout( layout92 );

    checkBoxTranspose = new QCheckBox( groupBox32, "checkBoxTranspose" );
    checkBoxTranspose->setEnabled( FALSE );
    checkBoxTranspose->setMinimumSize( QSize( 159, 0 ) );
    checkBoxTranspose->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBox32Layout->addWidget( checkBoxTranspose );

    checkBoxReadEnd = new QCheckBox( groupBox32, "checkBoxReadEnd" );
    checkBoxReadEnd->setEnabled( FALSE );
    checkBoxReadEnd->setMinimumSize( QSize( 180, 0 ) );
    checkBoxReadEnd->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBox32Layout->addWidget( checkBoxReadEnd );

    checkBoxX2mX = new QCheckBox( groupBox32, "checkBoxX2mX" );
    checkBoxX2mX->setEnabled( FALSE );
    checkBoxX2mX->setMinimumSize( QSize( 159, 0 ) );
    checkBoxX2mX->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBox32Layout->addWidget( checkBoxX2mX );

    checkBoxY2mY = new QCheckBox( groupBox32, "checkBoxY2mY" );
    checkBoxY2mY->setEnabled( FALSE );
    checkBoxY2mY->setMinimumSize( QSize( 159, 0 ) );
    checkBoxY2mY->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBox32Layout->addWidget( checkBoxY2mY );
    layout94->addWidget( groupBox32 );
    page1Layout_2->addLayout( layout94 );
    spacer21 = new QSpacerItem( 5, 10, QSizePolicy::Minimum, QSizePolicy::Fixed );
    page1Layout_2->addItem( spacer21 );

    pushButtonLoadDATmatrix = new QToolButton( page1_2, "pushButtonLoadDATmatrix" );
    pushButtonLoadDATmatrix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonLoadDATmatrix->sizePolicy().hasHeightForWidth() ) );
    pushButtonLoadDATmatrix->setMinimumSize( QSize( 0, 25 ) );
    pushButtonLoadDATmatrix->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonLoadDATmatrix->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    pushButtonLoadDATmatrix->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonLoadDATmatrix_font(  pushButtonLoadDATmatrix->font() );
    pushButtonLoadDATmatrix_font.setBold( TRUE );
    pushButtonLoadDATmatrix->setFont( pushButtonLoadDATmatrix_font ); 
    pushButtonLoadDATmatrix->setUsesTextLabel( FALSE );
    pushButtonLoadDATmatrix->setAutoRaise( FALSE );
    pushButtonLoadDATmatrix->setTextPosition( QToolButton::BelowIcon );
    page1Layout_2->addWidget( pushButtonLoadDATmatrix );

    checkBoxFindNumberM = new QCheckBox( page1_2, "checkBoxFindNumberM" );
    checkBoxFindNumberM->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxFindNumberM->setAcceptDrops( FALSE );
    checkBoxFindNumberM->setChecked( TRUE );
    page1Layout_2->addWidget( checkBoxFindNumberM );
    spacer22 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page1Layout_2->addItem( spacer22 );
    toolBoxMatrixes->addItem( page1_2, QString::fromLatin1("") );

    page2_2 = new QWidget( toolBoxMatrixes, "page2_2" );
    page2_2->setBackgroundMode( QWidget::PaletteBackground );
    page2Layout_2 = new QHBoxLayout( page2_2, 11, 6, "page2Layout_2"); 
    spacer37_2_2_2_3 = new QSpacerItem( 1, 5, QSizePolicy::Minimum, QSizePolicy::Minimum );
    page2Layout_2->addItem( spacer37_2_2_2_3 );

    layout56_2 = new QVBoxLayout( 0, 0, 6, "layout56_2"); 

    frame6 = new QFrame( page2_2, "frame6" );
    frame6->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, frame6->sizePolicy().hasHeightForWidth() ) );
    frame6->setFrameShape( QFrame::NoFrame );
    frame6->setFrameShadow( QFrame::Raised );
    frame6Layout = new QGridLayout( frame6, 1, 1, 11, 6, "frame6Layout"); 

    spinBoxExPrecExportM = new QSpinBox( frame6, "spinBoxExPrecExportM" );
    spinBoxExPrecExportM->setEnabled( FALSE );
    spinBoxExPrecExportM->setMinimumSize( QSize( 30, 0 ) );
    spinBoxExPrecExportM->setMaximumSize( QSize( 32767, 30 ) );
    spinBoxExPrecExportM->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxExPrecExportM->setMaxValue( 20 );
    spinBoxExPrecExportM->setMinValue( -1 );
    spinBoxExPrecExportM->setValue( 5 );

    frame6Layout->addWidget( spinBoxExPrecExportM, 2, 0 );

    spinBoxMy = new QSpinBox( frame6, "spinBoxMy" );
    spinBoxMy->setEnabled( FALSE );
    spinBoxMy->setMinimumSize( QSize( 0, 30 ) );
    spinBoxMy->setMaximumSize( QSize( 100, 30 ) );
    spinBoxMy->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxMy->setMaxValue( 1000 );
    spinBoxMy->setMinValue( -1 );

    frame6Layout->addWidget( spinBoxMy, 0, 4 );

    comboBoxSpacerExpM = new QComboBox( FALSE, frame6, "comboBoxSpacerExpM" );
    comboBoxSpacerExpM->setEnabled( FALSE );
    comboBoxSpacerExpM->setMinimumSize( QSize( 0, 30 ) );
    comboBoxSpacerExpM->setMaximumSize( QSize( 32767, 30 ) );
    comboBoxSpacerExpM->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    frame6Layout->addWidget( comboBoxSpacerExpM, 3, 0 );

    comboBoxMlist = new QComboBox( FALSE, frame6, "comboBoxMlist" );
    comboBoxMlist->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxMlist->sizePolicy().hasHeightForWidth() ) );
    comboBoxMlist->setMinimumSize( QSize( 30, 30 ) );
    comboBoxMlist->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    frame6Layout->addMultiCellWidget( comboBoxMlist, 0, 0, 1, 2 );

    spinBoxMx = new QSpinBox( frame6, "spinBoxMx" );
    spinBoxMx->setEnabled( FALSE );
    spinBoxMx->setMinimumSize( QSize( 0, 30 ) );
    spinBoxMx->setMaximumSize( QSize( 100, 30 ) );
    spinBoxMx->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxMx->setMaxValue( 1000 );
    spinBoxMx->setMinValue( -1 );
    spinBoxMx->setValue( 0 );

    frame6Layout->addWidget( spinBoxMx, 0, 3 );

    textLabel1_3_2_2 = new QLabel( frame6, "textLabel1_3_2_2" );
    textLabel1_3_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    frame6Layout->addWidget( textLabel1_3_2_2, 1, 1 );

    textLabel1_2 = new QLabel( frame6, "textLabel1_2" );
    textLabel1_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    frame6Layout->addWidget( textLabel1_2, 2, 1 );

    textLabel1_2_2 = new QLabel( frame6, "textLabel1_2_2" );
    textLabel1_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    frame6Layout->addWidget( textLabel1_2_2, 3, 1 );

    checkBoxReadEndExportM = new QCheckBox( frame6, "checkBoxReadEndExportM" );
    checkBoxReadEndExportM->setEnabled( FALSE );
    checkBoxReadEndExportM->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    frame6Layout->addMultiCellWidget( checkBoxReadEndExportM, 5, 5, 0, 1 );

    spinBoxExpMatrixPos = new QSpinBox( frame6, "spinBoxExpMatrixPos" );
    spinBoxExpMatrixPos->setEnabled( FALSE );
    spinBoxExpMatrixPos->setMinimumSize( QSize( 0, 30 ) );
    spinBoxExpMatrixPos->setMaximumSize( QSize( 32767, 30 ) );
    spinBoxExpMatrixPos->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxExpMatrixPos->setMaxValue( 10000 );
    spinBoxExpMatrixPos->setMinValue( 1 );
    spinBoxExpMatrixPos->setValue( 8 );

    frame6Layout->addWidget( spinBoxExpMatrixPos, 1, 0 );

    checkBoxSens = new QCheckBox( frame6, "checkBoxSens" );
    checkBoxSens->setEnabled( TRUE );
    checkBoxSens->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    checkBoxSens->setChecked( TRUE );

    frame6Layout->addMultiCellWidget( checkBoxSens, 6, 6, 0, 1 );

    pushButtonMlist = new QToolButton( frame6, "pushButtonMlist" );
    pushButtonMlist->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonMlist->sizePolicy().hasHeightForWidth() ) );
    pushButtonMlist->setMinimumSize( QSize( 0, 30 ) );
    pushButtonMlist->setMaximumSize( QSize( 32767, 30 ) );

    frame6Layout->addWidget( pushButtonMlist, 0, 0 );

    checkBoxTransposeExport = new QCheckBox( frame6, "checkBoxTransposeExport" );
    checkBoxTransposeExport->setEnabled( FALSE );
    checkBoxTransposeExport->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    frame6Layout->addMultiCellWidget( checkBoxTransposeExport, 4, 4, 0, 1 );

    layout55 = new QHBoxLayout( 0, 0, 6, "layout55"); 
    spacer35 = new QSpacerItem( 1, 5, QSizePolicy::Minimum, QSizePolicy::Minimum );
    layout55->addItem( spacer35 );

    pushButtonExportM = new QToolButton( frame6, "pushButtonExportM" );
    pushButtonExportM->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonExportM->sizePolicy().hasHeightForWidth() ) );
    pushButtonExportM->setMinimumSize( QSize( 100, 100 ) );
    pushButtonExportM->setMaximumSize( QSize( 10000, 100 ) );
    pushButtonExportM->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    pushButtonExportM->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonExportM_font(  pushButtonExportM->font() );
    pushButtonExportM_font.setBold( TRUE );
    pushButtonExportM->setFont( pushButtonExportM_font ); 
    layout55->addWidget( pushButtonExportM );

    frame6Layout->addMultiCellLayout( layout55, 3, 6, 2, 4 );
    layout56_2->addWidget( frame6 );
    spacer32 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout56_2->addItem( spacer32 );
    page2Layout_2->addLayout( layout56_2 );
    spacer37_2_2_2_4 = new QSpacerItem( 1, 5, QSizePolicy::Minimum, QSizePolicy::Minimum );
    page2Layout_2->addItem( spacer37_2_2_2_4 );
    toolBoxMatrixes->addItem( page2_2, QString::fromLatin1("") );

    Page_2 = new QWidget( toolBoxMatrixes, "Page_2" );
    Page_2->setBackgroundMode( QWidget::PaletteBackground );
    PageLayout = new QVBoxLayout( Page_2, 11, 6, "PageLayout"); 

    layout256 = new QHBoxLayout( 0, 0, 6, "layout256"); 

    layout255 = new QGridLayout( 0, 1, 1, 0, 6, "layout255"); 

    buttonGroup24 = new QButtonGroup( Page_2, "buttonGroup24" );
    buttonGroup24->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, buttonGroup24->sizePolicy().hasHeightForWidth() ) );
    buttonGroup24->setMaximumSize( QSize( 3000, 32767 ) );
    buttonGroup24->setAlignment( int( QButtonGroup::AlignTop ) );
    buttonGroup24->setColumnLayout(0, Qt::Vertical );
    buttonGroup24->layout()->setSpacing( 6 );
    buttonGroup24->layout()->setMargin( 11 );
    buttonGroup24Layout = new QVBoxLayout( buttonGroup24->layout() );
    buttonGroup24Layout->setAlignment( Qt::AlignTop );

    radioButtonOW1 = new QRadioButton( buttonGroup24, "radioButtonOW1" );
    radioButtonOW1->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    radioButtonOW1->setChecked( TRUE );
    buttonGroup24Layout->addWidget( radioButtonOW1 );

    radioButtonOW2 = new QRadioButton( buttonGroup24, "radioButtonOW2" );
    radioButtonOW2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroup24Layout->addWidget( radioButtonOW2 );

    radioButtonOW3 = new QRadioButton( buttonGroup24, "radioButtonOW3" );
    radioButtonOW3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    radioButtonOW3->setChecked( FALSE );
    buttonGroup24Layout->addWidget( radioButtonOW3 );

    layout255->addWidget( buttonGroup24, 1, 1 );

    layout253 = new QHBoxLayout( 0, 0, 6, "layout253"); 

    buttonGroup11_2 = new QButtonGroup( Page_2, "buttonGroup11_2" );
    buttonGroup11_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, buttonGroup11_2->sizePolicy().hasHeightForWidth() ) );
    buttonGroup11_2->setMinimumSize( QSize( 70, 55 ) );
    buttonGroup11_2->setMaximumSize( QSize( 80, 55 ) );
    buttonGroup11_2->setAlignment( int( QButtonGroup::AlignTop | QButtonGroup::AlignHCenter ) );
    buttonGroup11_2->setColumnLayout(0, Qt::Vertical );
    buttonGroup11_2->layout()->setSpacing( 6 );
    buttonGroup11_2->layout()->setMargin( 11 );
    buttonGroup11_2Layout = new QVBoxLayout( buttonGroup11_2->layout() );
    buttonGroup11_2Layout->setAlignment( Qt::AlignTop );

    comboBoxActionScalar = new QComboBox( FALSE, buttonGroup11_2, "comboBoxActionScalar" );
    comboBoxActionScalar->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxActionScalar->sizePolicy().hasHeightForWidth() ) );
    comboBoxActionScalar->setMinimumSize( QSize( 55, 0 ) );
    comboBoxActionScalar->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup11_2Layout->addWidget( comboBoxActionScalar );
    layout253->addWidget( buttonGroup11_2 );

    buttonGroup14 = new QButtonGroup( Page_2, "buttonGroup14" );
    buttonGroup14->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, buttonGroup14->sizePolicy().hasHeightForWidth() ) );
    buttonGroup14->setMinimumSize( QSize( 0, 55 ) );
    buttonGroup14->setMaximumSize( QSize( 75, 55 ) );
    buttonGroup14->setAlignment( int( QButtonGroup::AlignHCenter ) );
    buttonGroup14->setColumnLayout(0, Qt::Vertical );
    buttonGroup14->layout()->setSpacing( 6 );
    buttonGroup14->layout()->setMargin( 11 );
    buttonGroup14Layout = new QVBoxLayout( buttonGroup14->layout() );
    buttonGroup14Layout->setAlignment( Qt::AlignTop );

    lineEditScalar = new QLineEdit( buttonGroup14, "lineEditScalar" );
    lineEditScalar->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup14Layout->addWidget( lineEditScalar );
    layout253->addWidget( buttonGroup14 );

    buttonGroup13_2 = new QButtonGroup( Page_2, "buttonGroup13_2" );
    buttonGroup13_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, buttonGroup13_2->sizePolicy().hasHeightForWidth() ) );
    buttonGroup13_2->setMinimumSize( QSize( 0, 55 ) );
    buttonGroup13_2->setMaximumSize( QSize( 3000, 55 ) );
    buttonGroup13_2->setColumnLayout(0, Qt::Vertical );
    buttonGroup13_2->layout()->setSpacing( 6 );
    buttonGroup13_2->layout()->setMargin( 11 );
    buttonGroup13_2Layout = new QVBoxLayout( buttonGroup13_2->layout() );
    buttonGroup13_2Layout->setAlignment( Qt::AlignTop );

    pushButtonMCscalar = new QToolButton( buttonGroup13_2, "pushButtonMCscalar" );
    pushButtonMCscalar->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonMCscalar->sizePolicy().hasHeightForWidth() ) );
    pushButtonMCscalar->setMinimumSize( QSize( 0, 25 ) );
    pushButtonMCscalar->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonMCscalar->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    pushButtonMCscalar->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonMCscalar_font(  pushButtonMCscalar->font() );
    pushButtonMCscalar_font.setBold( TRUE );
    pushButtonMCscalar->setFont( pushButtonMCscalar_font ); 
    buttonGroup13_2Layout->addWidget( pushButtonMCscalar );
    layout253->addWidget( buttonGroup13_2 );

    layout255->addLayout( layout253, 0, 1 );

    layout85 = new QVBoxLayout( 0, 0, 6, "layout85"); 

    buttonGroup11 = new QButtonGroup( Page_2, "buttonGroup11" );
    buttonGroup11->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup11->sizePolicy().hasHeightForWidth() ) );
    buttonGroup11->setMinimumSize( QSize( 150, 55 ) );
    buttonGroup11->setMaximumSize( QSize( 32767, 55 ) );
    buttonGroup11->setAlignment( int( QButtonGroup::AlignCenter ) );
    buttonGroup11->setColumnLayout(0, Qt::Vertical );
    buttonGroup11->layout()->setSpacing( 6 );
    buttonGroup11->layout()->setMargin( 11 );
    buttonGroup11Layout = new QHBoxLayout( buttonGroup11->layout() );
    buttonGroup11Layout->setAlignment( Qt::AlignTop );
    spacer29 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    buttonGroup11Layout->addItem( spacer29 );

    comboBoxAction = new QComboBox( FALSE, buttonGroup11, "comboBoxAction" );
    comboBoxAction->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)7, 0, 0, comboBoxAction->sizePolicy().hasHeightForWidth() ) );
    comboBoxAction->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup11Layout->addWidget( comboBoxAction );
    spacer29_2 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    buttonGroup11Layout->addItem( spacer29_2 );
    layout85->addWidget( buttonGroup11 );

    buttonGroup12 = new QButtonGroup( Page_2, "buttonGroup12" );
    buttonGroup12->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, buttonGroup12->sizePolicy().hasHeightForWidth() ) );
    buttonGroup12->setMinimumSize( QSize( 150, 55 ) );
    buttonGroup12->setMaximumSize( QSize( 32767, 55 ) );
    buttonGroup12->setAlignment( int( QButtonGroup::AlignHCenter ) );
    buttonGroup12->setColumnLayout(0, Qt::Vertical );
    buttonGroup12->layout()->setSpacing( 6 );
    buttonGroup12->layout()->setMargin( 11 );
    buttonGroup12Layout = new QVBoxLayout( buttonGroup12->layout() );
    buttonGroup12Layout->setAlignment( Qt::AlignTop );

    comboBoxMC2 = new QComboBox( FALSE, buttonGroup12, "comboBoxMC2" );
    comboBoxMC2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxMC2->sizePolicy().hasHeightForWidth() ) );
    comboBoxMC2->setMinimumSize( QSize( 120, 0 ) );
    comboBoxMC2->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup12Layout->addWidget( comboBoxMC2 );
    layout85->addWidget( buttonGroup12 );

    buttonGroup13 = new QButtonGroup( Page_2, "buttonGroup13" );
    buttonGroup13->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup13->sizePolicy().hasHeightForWidth() ) );
    buttonGroup13->setMinimumSize( QSize( 150, 55 ) );
    buttonGroup13->setMaximumSize( QSize( 32767, 55 ) );
    buttonGroup13->setAlignment( int( QButtonGroup::AlignHCenter ) );
    buttonGroup13->setColumnLayout(0, Qt::Vertical );
    buttonGroup13->layout()->setSpacing( 6 );
    buttonGroup13->layout()->setMargin( 11 );
    buttonGroup13Layout = new QVBoxLayout( buttonGroup13->layout() );
    buttonGroup13Layout->setAlignment( Qt::AlignTop );

    pushButtonMC = new QToolButton( buttonGroup13, "pushButtonMC" );
    pushButtonMC->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonMC->sizePolicy().hasHeightForWidth() ) );
    pushButtonMC->setMinimumSize( QSize( 0, 25 ) );
    pushButtonMC->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonMC->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    pushButtonMC->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonMC_font(  pushButtonMC->font() );
    pushButtonMC_font.setBold( TRUE );
    pushButtonMC->setFont( pushButtonMC_font ); 
    buttonGroup13Layout->addWidget( pushButtonMC );
    layout85->addWidget( buttonGroup13 );

    layout255->addLayout( layout85, 1, 0 );

    buttonGroup10 = new QButtonGroup( Page_2, "buttonGroup10" );
    buttonGroup10->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup10->sizePolicy().hasHeightForWidth() ) );
    buttonGroup10->setMinimumSize( QSize( 150, 55 ) );
    buttonGroup10->setMaximumSize( QSize( 32767, 55 ) );
    buttonGroup10->setAlignment( int( QButtonGroup::AlignCenter ) );
    buttonGroup10->setColumnLayout(0, Qt::Vertical );
    buttonGroup10->layout()->setSpacing( 6 );
    buttonGroup10->layout()->setMargin( 11 );
    buttonGroup10Layout = new QVBoxLayout( buttonGroup10->layout() );
    buttonGroup10Layout->setAlignment( Qt::AlignTop );

    comboBoxMC1 = new QComboBox( FALSE, buttonGroup10, "comboBoxMC1" );
    comboBoxMC1->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxMC1->sizePolicy().hasHeightForWidth() ) );
    comboBoxMC1->setMinimumSize( QSize( 120, 0 ) );
    comboBoxMC1->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup10Layout->addWidget( comboBoxMC1 );

    layout255->addWidget( buttonGroup10, 0, 0 );
    layout256->addLayout( layout255 );
    PageLayout->addLayout( layout256 );
    spacer38 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    PageLayout->addItem( spacer38 );
    toolBoxMatrixes->addItem( Page_2, QString::fromLatin1("") );

    page_4 = new QWidget( toolBoxMatrixes, "page_4" );
    page_4->setBackgroundMode( QWidget::PaletteBackground );
    pageLayout_3 = new QVBoxLayout( page_4, 11, 6, "pageLayout_3"); 

    layout262 = new QHBoxLayout( 0, 10, 6, "layout262"); 

    checkBoxAllMatrixes = new QCheckBox( page_4, "checkBoxAllMatrixes" );
    layout262->addWidget( checkBoxAllMatrixes );

    comboBoxMlistMask = new QComboBox( FALSE, page_4, "comboBoxMlistMask" );
    comboBoxMlistMask->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, comboBoxMlistMask->sizePolicy().hasHeightForWidth() ) );
    comboBoxMlistMask->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout262->addWidget( comboBoxMlistMask );

    pushButtonMlist_2 = new QToolButton( page_4, "pushButtonMlist_2" );
    pushButtonMlist_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonMlist_2->sizePolicy().hasHeightForWidth() ) );
    pushButtonMlist_2->setMinimumSize( QSize( 0, 0 ) );
    pushButtonMlist_2->setMaximumSize( QSize( 20, 20 ) );
    pushButtonMlist_2->setIconSet( QIconSet( image6 ) );
    layout262->addWidget( pushButtonMlist_2 );
    pageLayout_3->addLayout( layout262 );

    buttonGroup27 = new QButtonGroup( page_4, "buttonGroup27" );
    buttonGroup27->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, buttonGroup27->sizePolicy().hasHeightForWidth() ) );
    buttonGroup27->setColumnLayout(0, Qt::Vertical );
    buttonGroup27->layout()->setSpacing( 6 );
    buttonGroup27->layout()->setMargin( 11 );
    buttonGroup27Layout = new QHBoxLayout( buttonGroup27->layout() );
    buttonGroup27Layout->setAlignment( Qt::AlignTop );

    lineEditValue = new QLineEdit( buttonGroup27, "lineEditValue" );
    lineEditValue->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup27Layout->addWidget( lineEditValue );

    comboBoxMaskInside = new QComboBox( FALSE, buttonGroup27, "comboBoxMaskInside" );
    comboBoxMaskInside->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup27Layout->addWidget( comboBoxMaskInside );

    pushButtonSetValue = new QToolButton( buttonGroup27, "pushButtonSetValue" );
    pushButtonSetValue->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonSetValue->sizePolicy().hasHeightForWidth() ) );
    pushButtonSetValue->setMinimumSize( QSize( 0, 0 ) );
    pushButtonSetValue->setMaximumSize( QSize( 20, 20 ) );
    pushButtonSetValue->setIconSet( QIconSet( image7 ) );
    buttonGroup27Layout->addWidget( pushButtonSetValue );
    pageLayout_3->addWidget( buttonGroup27 );

    frame31 = new QFrame( page_4, "frame31" );
    frame31->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, frame31->sizePolicy().hasHeightForWidth() ) );
    frame31->setMinimumSize( QSize( 0, 0 ) );
    frame31->setMaximumSize( QSize( 5000, 32767 ) );
    frame31->setFrameShape( QFrame::NoFrame );
    frame31->setFrameShadow( QFrame::Plain );
    frame31->setLineWidth( 0 );
    frame31Layout = new QHBoxLayout( frame31, 0, 0, "frame31Layout"); 

    frame23 = new QFrame( frame31, "frame23" );
    frame23->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, frame23->sizePolicy().hasHeightForWidth() ) );
    frame23->setMinimumSize( QSize( 100, 0 ) );
    frame23->setMaximumSize( QSize( 6000, 32767 ) );
    frame23->setFrameShape( QFrame::StyledPanel );
    frame23->setFrameShadow( QFrame::Raised );
    frame23->setLineWidth( 0 );
    frame23Layout = new QVBoxLayout( frame23, 0, 6, "frame23Layout"); 

    buttonGroupmask = new QButtonGroup( frame23, "buttonGroupmask" );
    buttonGroupmask->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, buttonGroupmask->sizePolicy().hasHeightForWidth() ) );
    buttonGroupmask->setMinimumSize( QSize( 50, 0 ) );
    buttonGroupmask->setMaximumSize( QSize( 32700, 32767 ) );
    buttonGroupmask->setColumnLayout(0, Qt::Vertical );
    buttonGroupmask->layout()->setSpacing( 6 );
    buttonGroupmask->layout()->setMargin( 11 );
    buttonGroupmaskLayout = new QHBoxLayout( buttonGroupmask->layout() );
    buttonGroupmaskLayout->setAlignment( Qt::AlignTop );

    lineEditXcenter = new QLineEdit( buttonGroupmask, "lineEditXcenter" );
    lineEditXcenter->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, lineEditXcenter->sizePolicy().hasHeightForWidth() ) );
    lineEditXcenter->setMinimumSize( QSize( 65, 0 ) );
    lineEditXcenter->setMaximumSize( QSize( 65, 32767 ) );
    lineEditXcenter->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroupmaskLayout->addWidget( lineEditXcenter );

    lineEditYcenter = new QLineEdit( buttonGroupmask, "lineEditYcenter" );
    lineEditYcenter->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, lineEditYcenter->sizePolicy().hasHeightForWidth() ) );
    lineEditYcenter->setMinimumSize( QSize( 65, 0 ) );
    lineEditYcenter->setMaximumSize( QSize( 65, 32767 ) );
    lineEditYcenter->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroupmaskLayout->addWidget( lineEditYcenter );
    spacer35_2_2 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    buttonGroupmaskLayout->addItem( spacer35_2_2 );

    pushButtonReadDisplay = new QToolButton( buttonGroupmask, "pushButtonReadDisplay" );
    pushButtonReadDisplay->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonReadDisplay->sizePolicy().hasHeightForWidth() ) );
    pushButtonReadDisplay->setMinimumSize( QSize( 20, 20 ) );
    pushButtonReadDisplay->setMaximumSize( QSize( 20, 20 ) );
    buttonGroupmaskLayout->addWidget( pushButtonReadDisplay );
    frame23Layout->addWidget( buttonGroupmask );
    spacer40 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    frame23Layout->addItem( spacer40 );

    buttonGroup65 = new QButtonGroup( frame23, "buttonGroup65" );
    buttonGroup65->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)2, (QSizePolicy::SizeType)1, 0, 0, buttonGroup65->sizePolicy().hasHeightForWidth() ) );
    buttonGroup65->setMinimumSize( QSize( 50, 0 ) );
    buttonGroup65->setMaximumSize( QSize( 32700, 32767 ) );
    buttonGroup65->setColumnLayout(0, Qt::Vertical );
    buttonGroup65->layout()->setSpacing( 6 );
    buttonGroup65->layout()->setMargin( 11 );
    buttonGroup65Layout = new QVBoxLayout( buttonGroup65->layout() );
    buttonGroup65Layout->setAlignment( Qt::AlignTop );

    pushButtonIQ = new QToolButton( buttonGroup65, "pushButtonIQ" );
    pushButtonIQ->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, pushButtonIQ->sizePolicy().hasHeightForWidth() ) );
    pushButtonIQ->setMinimumSize( QSize( 50, 25 ) );
    pushButtonIQ->setMaximumSize( QSize( 32767, 25 ) );
    pushButtonIQ->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    pushButtonIQ->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonIQ_font(  pushButtonIQ->font() );
    pushButtonIQ_font.setBold( TRUE );
    pushButtonIQ->setFont( pushButtonIQ_font ); 
    buttonGroup65Layout->addWidget( pushButtonIQ );

    checkBoxNormNumberPixels = new QCheckBox( buttonGroup65, "checkBoxNormNumberPixels" );
    checkBoxNormNumberPixels->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxNormNumberPixels->sizePolicy().hasHeightForWidth() ) );
    checkBoxNormNumberPixels->setMinimumSize( QSize( 50, 0 ) );
    checkBoxNormNumberPixels->setChecked( TRUE );
    buttonGroup65Layout->addWidget( checkBoxNormNumberPixels );

    comboBoxMaskForRadialAv = new QComboBox( FALSE, buttonGroup65, "comboBoxMaskForRadialAv" );
    comboBoxMaskForRadialAv->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxMaskForRadialAv->sizePolicy().hasHeightForWidth() ) );
    comboBoxMaskForRadialAv->setMinimumSize( QSize( 50, 0 ) );
    comboBoxMaskForRadialAv->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup65Layout->addWidget( comboBoxMaskForRadialAv );

    layout145 = new QHBoxLayout( 0, 0, 6, "layout145"); 

    textLabel1_7_3_2_2_2 = new QLabel( buttonGroup65, "textLabel1_7_3_2_2_2" );
    textLabel1_7_3_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel1_7_3_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_3_2_2_2->setMinimumSize( QSize( 60, 0 ) );
    textLabel1_7_3_2_2_2->setMaximumSize( QSize( 60, 32767 ) );
    textLabel1_7_3_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout145->addWidget( textLabel1_7_3_2_2_2 );

    lineEditRscale = new QLineEdit( buttonGroup65, "lineEditRscale" );
    lineEditRscale->setMinimumSize( QSize( 50, 0 ) );
    lineEditRscale->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout145->addWidget( lineEditRscale );
    buttonGroup65Layout->addLayout( layout145 );

    layout146 = new QHBoxLayout( 0, 0, 6, "layout146"); 

    textLabel1_7_3_2_2_2_2 = new QLabel( buttonGroup65, "textLabel1_7_3_2_2_2_2" );
    textLabel1_7_3_2_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel1_7_3_2_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_3_2_2_2_2->setMinimumSize( QSize( 60, 0 ) );
    textLabel1_7_3_2_2_2_2->setMaximumSize( QSize( 60, 32767 ) );
    textLabel1_7_3_2_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout146->addWidget( textLabel1_7_3_2_2_2_2 );

    lineEditIscale = new QLineEdit( buttonGroup65, "lineEditIscale" );
    lineEditIscale->setMinimumSize( QSize( 50, 0 ) );
    lineEditIscale->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout146->addWidget( lineEditIscale );
    buttonGroup65Layout->addLayout( layout146 );
    frame23Layout->addWidget( buttonGroup65 );
    frame31Layout->addWidget( frame23 );

    frame12 = new QFrame( frame31, "frame12" );
    frame12->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, frame12->sizePolicy().hasHeightForWidth() ) );
    frame12->setFrameShape( QFrame::NoFrame );
    frame12->setFrameShadow( QFrame::Raised );
    frame12->setLineWidth( 0 );
    frame12Layout = new QVBoxLayout( frame12, 11, 6, "frame12Layout"); 
    spacer35_2 = new QSpacerItem( 5, 5, QSizePolicy::Fixed, QSizePolicy::Minimum );
    frame12Layout->addItem( spacer35_2 );
    frame31Layout->addWidget( frame12 );

    frame24 = new QFrame( frame31, "frame24" );
    frame24->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)7, 0, 0, frame24->sizePolicy().hasHeightForWidth() ) );
    frame24->setMinimumSize( QSize( 270, 0 ) );
    frame24->setMaximumSize( QSize( 270, 32767 ) );
    frame24->setFrameShape( QFrame::StyledPanel );
    frame24->setFrameShadow( QFrame::Raised );
    frame24->setLineWidth( 0 );
    frame24Layout = new QVBoxLayout( frame24, 0, 3, "frame24Layout"); 

    buttonGroup39 = new QButtonGroup( frame24, "buttonGroup39" );
    buttonGroup39->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, buttonGroup39->sizePolicy().hasHeightForWidth() ) );
    buttonGroup39->setColumnLayout(0, Qt::Vertical );
    buttonGroup39->layout()->setSpacing( 5 );
    buttonGroup39->layout()->setMargin( 11 );
    buttonGroup39Layout = new QHBoxLayout( buttonGroup39->layout() );
    buttonGroup39Layout->setAlignment( Qt::AlignTop );

    textLabel1_7_3 = new QLabel( buttonGroup39, "textLabel1_7_3" );
    textLabel1_7_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel1_7_3->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_3->setMinimumSize( QSize( 45, 0 ) );
    textLabel1_7_3->setMaximumSize( QSize( 45, 32767 ) );
    textLabel1_7_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroup39Layout->addWidget( textLabel1_7_3 );

    lineEditXsize = new QLineEdit( buttonGroup39, "lineEditXsize" );
    lineEditXsize->setMinimumSize( QSize( 60, 0 ) );
    lineEditXsize->setMaximumSize( QSize( 60, 32767 ) );
    lineEditXsize->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup39Layout->addWidget( lineEditXsize );

    textLabel1_7_4 = new QLabel( buttonGroup39, "textLabel1_7_4" );
    textLabel1_7_4->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel1_7_4->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_4->setMinimumSize( QSize( 45, 0 ) );
    textLabel1_7_4->setMaximumSize( QSize( 45, 32767 ) );
    textLabel1_7_4->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabel1_7_4->setAlignment( int( QLabel::AlignCenter ) );
    buttonGroup39Layout->addWidget( textLabel1_7_4 );

    lineEditYsize = new QLineEdit( buttonGroup39, "lineEditYsize" );
    lineEditYsize->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, lineEditYsize->sizePolicy().hasHeightForWidth() ) );
    lineEditYsize->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup39Layout->addWidget( lineEditYsize );

    pushButtonSquared = new QToolButton( buttonGroup39, "pushButtonSquared" );
    pushButtonSquared->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonSquared->sizePolicy().hasHeightForWidth() ) );
    pushButtonSquared->setMinimumSize( QSize( 0, 0 ) );
    pushButtonSquared->setMaximumSize( QSize( 20, 20 ) );
    pushButtonSquared->setIconSet( QIconSet( image7 ) );
    buttonGroup39Layout->addWidget( pushButtonSquared );
    frame24Layout->addWidget( buttonGroup39 );

    buttonGroup40 = new QButtonGroup( frame24, "buttonGroup40" );
    buttonGroup40->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, buttonGroup40->sizePolicy().hasHeightForWidth() ) );
    buttonGroup40->setColumnLayout(0, Qt::Vertical );
    buttonGroup40->layout()->setSpacing( 5 );
    buttonGroup40->layout()->setMargin( 11 );
    buttonGroup40Layout = new QHBoxLayout( buttonGroup40->layout() );
    buttonGroup40Layout->setAlignment( Qt::AlignTop );

    textLabel1_7_3_2 = new QLabel( buttonGroup40, "textLabel1_7_3_2" );
    textLabel1_7_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel1_7_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_3_2->setMinimumSize( QSize( 45, 0 ) );
    textLabel1_7_3_2->setMaximumSize( QSize( 45, 32767 ) );
    textLabel1_7_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroup40Layout->addWidget( textLabel1_7_3_2 );

    lineEditRx = new QLineEdit( buttonGroup40, "lineEditRx" );
    lineEditRx->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, lineEditRx->sizePolicy().hasHeightForWidth() ) );
    lineEditRx->setMinimumSize( QSize( 60, 0 ) );
    lineEditRx->setMaximumSize( QSize( 60, 32767 ) );
    lineEditRx->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup40Layout->addWidget( lineEditRx );

    textLabel1_7_3_3 = new QLabel( buttonGroup40, "textLabel1_7_3_3" );
    textLabel1_7_3_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel1_7_3_3->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_3_3->setMinimumSize( QSize( 45, 0 ) );
    textLabel1_7_3_3->setMaximumSize( QSize( 45, 32767 ) );
    textLabel1_7_3_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabel1_7_3_3->setAlignment( int( QLabel::AlignCenter ) );
    buttonGroup40Layout->addWidget( textLabel1_7_3_3 );

    lineEditRy = new QLineEdit( buttonGroup40, "lineEditRy" );
    lineEditRy->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup40Layout->addWidget( lineEditRy );

    pushButtonElips = new QToolButton( buttonGroup40, "pushButtonElips" );
    pushButtonElips->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonElips->sizePolicy().hasHeightForWidth() ) );
    pushButtonElips->setMinimumSize( QSize( 0, 0 ) );
    pushButtonElips->setMaximumSize( QSize( 20, 20 ) );
    pushButtonElips->setIconSet( QIconSet( image7 ) );
    buttonGroup40Layout->addWidget( pushButtonElips );
    frame24Layout->addWidget( buttonGroup40 );

    buttonGroup39_2_2 = new QButtonGroup( frame24, "buttonGroup39_2_2" );
    buttonGroup39_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, buttonGroup39_2_2->sizePolicy().hasHeightForWidth() ) );
    buttonGroup39_2_2->setColumnLayout(0, Qt::Vertical );
    buttonGroup39_2_2->layout()->setSpacing( 5 );
    buttonGroup39_2_2->layout()->setMargin( 11 );
    buttonGroup39_2_2Layout = new QHBoxLayout( buttonGroup39_2_2->layout() );
    buttonGroup39_2_2Layout->setAlignment( Qt::AlignTop );

    textLabel1_7_3_2_2 = new QLabel( buttonGroup39_2_2, "textLabel1_7_3_2_2" );
    textLabel1_7_3_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel1_7_3_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_3_2_2->setMinimumSize( QSize( 160, 0 ) );
    textLabel1_7_3_2_2->setMaximumSize( QSize( 160, 32767 ) );
    textLabel1_7_3_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroup39_2_2Layout->addWidget( textLabel1_7_3_2_2 );

    lineEditEllShell = new QLineEdit( buttonGroup39_2_2, "lineEditEllShell" );
    lineEditEllShell->setMaximumSize( QSize( 32767, 32767 ) );
    lineEditEllShell->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup39_2_2Layout->addWidget( lineEditEllShell );

    pushButtonEllShell = new QToolButton( buttonGroup39_2_2, "pushButtonEllShell" );
    pushButtonEllShell->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonEllShell->sizePolicy().hasHeightForWidth() ) );
    pushButtonEllShell->setMinimumSize( QSize( 0, 0 ) );
    pushButtonEllShell->setMaximumSize( QSize( 20, 20 ) );
    pushButtonEllShell->setIconSet( QIconSet( image7 ) );
    buttonGroup39_2_2Layout->addWidget( pushButtonEllShell );
    frame24Layout->addWidget( buttonGroup39_2_2 );

    buttonGroupMaskSector = new QButtonGroup( frame24, "buttonGroupMaskSector" );
    buttonGroupMaskSector->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, buttonGroupMaskSector->sizePolicy().hasHeightForWidth() ) );
    buttonGroupMaskSector->setColumnLayout(0, Qt::Vertical );
    buttonGroupMaskSector->layout()->setSpacing( 5 );
    buttonGroupMaskSector->layout()->setMargin( 11 );
    buttonGroupMaskSectorLayout = new QHBoxLayout( buttonGroupMaskSector->layout() );
    buttonGroupMaskSectorLayout->setAlignment( Qt::AlignTop );

    textLabel1_7 = new QLabel( buttonGroupMaskSector, "textLabel1_7" );
    textLabel1_7->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel1_7->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7->setMinimumSize( QSize( 45, 0 ) );
    textLabel1_7->setMaximumSize( QSize( 45, 32767 ) );
    textLabel1_7->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGroupMaskSectorLayout->addWidget( textLabel1_7 );

    spinBoxAngleFrom = new QSpinBox( buttonGroupMaskSector, "spinBoxAngleFrom" );
    spinBoxAngleFrom->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, spinBoxAngleFrom->sizePolicy().hasHeightForWidth() ) );
    spinBoxAngleFrom->setMinimumSize( QSize( 60, 0 ) );
    spinBoxAngleFrom->setMaximumSize( QSize( 60, 32767 ) );
    spinBoxAngleFrom->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxAngleFrom->setMaxValue( 360 );
    spinBoxAngleFrom->setValue( 0 );
    buttonGroupMaskSectorLayout->addWidget( spinBoxAngleFrom );

    textLabel1_7_2 = new QLabel( buttonGroupMaskSector, "textLabel1_7_2" );
    textLabel1_7_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, textLabel1_7_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_7_2->setMinimumSize( QSize( 45, 0 ) );
    textLabel1_7_2->setMaximumSize( QSize( 45, 32767 ) );
    textLabel1_7_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabel1_7_2->setAlignment( int( QLabel::AlignCenter ) );
    buttonGroupMaskSectorLayout->addWidget( textLabel1_7_2 );

    spinBoxAngleTo = new QSpinBox( buttonGroupMaskSector, "spinBoxAngleTo" );
    spinBoxAngleTo->setMinimumSize( QSize( 0, 0 ) );
    spinBoxAngleTo->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxAngleTo->setMaxValue( 360 );
    spinBoxAngleTo->setValue( 10 );
    buttonGroupMaskSectorLayout->addWidget( spinBoxAngleTo );

    pushButtonMaskSector = new QToolButton( buttonGroupMaskSector, "pushButtonMaskSector" );
    pushButtonMaskSector->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonMaskSector->sizePolicy().hasHeightForWidth() ) );
    pushButtonMaskSector->setMinimumSize( QSize( 0, 0 ) );
    pushButtonMaskSector->setMaximumSize( QSize( 20, 20 ) );
    pushButtonMaskSector->setIconSet( QIconSet( image7 ) );
    buttonGroupMaskSectorLayout->addWidget( pushButtonMaskSector );
    frame24Layout->addWidget( buttonGroupMaskSector );
    frame31Layout->addWidget( frame24 );
    pageLayout_3->addWidget( frame31 );

    layout263 = new QHBoxLayout( 0, 8, 6, "layout263"); 
    spacer41 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout263->addItem( spacer41 );

    pushButtonBackToDAN = new QToolButton( page_4, "pushButtonBackToDAN" );
    pushButtonBackToDAN->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 0, 0, pushButtonBackToDAN->sizePolicy().hasHeightForWidth() ) );
    pushButtonBackToDAN->setMinimumSize( QSize( 0, 0 ) );
    pushButtonBackToDAN->setMaximumSize( QSize( 20, 20 ) );
    pushButtonBackToDAN->setIconSet( QIconSet( image8 ) );
    layout263->addWidget( pushButtonBackToDAN );
    pageLayout_3->addLayout( layout263 );
    spacer200 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    pageLayout_3->addItem( spacer200 );
    toolBoxMatrixes->addItem( page_4, QString::fromLatin1("") );
    TabPageLayout_3->addWidget( toolBoxMatrixes );
    sansTab->insertTab( TabPage_3, QString::fromLatin1("") );

    TabPage_4 = new QWidget( sansTab, "TabPage_4" );
    TabPageLayout_4 = new QVBoxLayout( TabPage_4, 11, 6, "TabPageLayout_4"); 

    toolBox8 = new QToolBox( TabPage_4, "toolBox8" );
    toolBox8->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, toolBox8->sizePolicy().hasHeightForWidth() ) );
    toolBox8->setCurrentIndex( 0 );

    page1_3 = new QWidget( toolBox8, "page1_3" );
    page1_3->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout_3 = new QVBoxLayout( page1_3, 11, 6, "page1Layout_3"); 

    buttonGroup10_2 = new QButtonGroup( page1_3, "buttonGroup10_2" );
    buttonGroup10_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, buttonGroup10_2->sizePolicy().hasHeightForWidth() ) );
    buttonGroup10_2->setMinimumSize( QSize( 150, 55 ) );
    buttonGroup10_2->setMaximumSize( QSize( 32700, 200 ) );
    buttonGroup10_2->setAlignment( int( QButtonGroup::AlignVCenter | QButtonGroup::AlignLeft ) );
    buttonGroup10_2->setColumnLayout(0, Qt::Vertical );
    buttonGroup10_2->layout()->setSpacing( 6 );
    buttonGroup10_2->layout()->setMargin( 11 );
    buttonGroup10_2Layout = new QVBoxLayout( buttonGroup10_2->layout() );
    buttonGroup10_2Layout->setAlignment( Qt::AlignTop );

    comboBoxActiveMatrix = new QComboBox( FALSE, buttonGroup10_2, "comboBoxActiveMatrix" );
    comboBoxActiveMatrix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, comboBoxActiveMatrix->sizePolicy().hasHeightForWidth() ) );
    comboBoxActiveMatrix->setMinimumSize( QSize( 120, 25 ) );
    comboBoxActiveMatrix->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup10_2Layout->addWidget( comboBoxActiveMatrix );

    layout189 = new QHBoxLayout( 0, 0, 6, "layout189"); 

    textLabelMatrix = new QLabel( buttonGroup10_2, "textLabelMatrix" );
    textLabelMatrix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, textLabelMatrix->sizePolicy().hasHeightForWidth() ) );
    textLabelMatrix->setMinimumSize( QSize( 0, 0 ) );
    textLabelMatrix->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout189->addWidget( textLabelMatrix );

    checkBoxShowInTitle = new QCheckBox( buttonGroup10_2, "checkBoxShowInTitle" );
    checkBoxShowInTitle->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, checkBoxShowInTitle->sizePolicy().hasHeightForWidth() ) );
    checkBoxShowInTitle->setMinimumSize( QSize( 120, 0 ) );
    checkBoxShowInTitle->setMaximumSize( QSize( 120, 32767 ) );
    checkBoxShowInTitle->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout189->addWidget( checkBoxShowInTitle );
    buttonGroup10_2Layout->addLayout( layout189 );
    page1Layout_3->addWidget( buttonGroup10_2 );

    buttonGroup28 = new QButtonGroup( page1_3, "buttonGroup28" );
    buttonGroup28->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, buttonGroup28->sizePolicy().hasHeightForWidth() ) );
    buttonGroup28->setMaximumSize( QSize( 32700, 32767 ) );
    buttonGroup28->setColumnLayout(0, Qt::Vertical );
    buttonGroup28->layout()->setSpacing( 6 );
    buttonGroup28->layout()->setMargin( 11 );
    buttonGroup28Layout = new QHBoxLayout( buttonGroup28->layout() );
    buttonGroup28Layout->setAlignment( Qt::AlignTop );

    comboBoxSchema = new QComboBox( FALSE, buttonGroup28, "comboBoxSchema" );
    comboBoxSchema->setEnabled( TRUE );
    comboBoxSchema->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxSchema->sizePolicy().hasHeightForWidth() ) );
    comboBoxSchema->setMinimumSize( QSize( 0, 25 ) );
    comboBoxSchema->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    buttonGroup28Layout->addWidget( comboBoxSchema );

    pushButtonEdit2dColorSchemaAccept = new QToolButton( buttonGroup28, "pushButtonEdit2dColorSchemaAccept" );
    pushButtonEdit2dColorSchemaAccept->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonEdit2dColorSchemaAccept->sizePolicy().hasHeightForWidth() ) );
    pushButtonEdit2dColorSchemaAccept->setMinimumSize( QSize( 25, 25 ) );
    pushButtonEdit2dColorSchemaAccept->setMaximumSize( QSize( 25, 25 ) );
    pushButtonEdit2dColorSchemaAccept->setIconSet( QIconSet( image4 ) );
    pushButtonEdit2dColorSchemaAccept->setUsesTextLabel( FALSE );
    pushButtonEdit2dColorSchemaAccept->setAutoRaise( FALSE );
    pushButtonEdit2dColorSchemaAccept->setTextPosition( QToolButton::BelowIcon );
    buttonGroup28Layout->addWidget( pushButtonEdit2dColorSchemaAccept );

    pushButtonEditColorSchema2D = new QToolButton( buttonGroup28, "pushButtonEditColorSchema2D" );
    pushButtonEditColorSchema2D->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonEditColorSchema2D->sizePolicy().hasHeightForWidth() ) );
    pushButtonEditColorSchema2D->setMinimumSize( QSize( 25, 25 ) );
    pushButtonEditColorSchema2D->setMaximumSize( QSize( 25, 25 ) );
    pushButtonEditColorSchema2D->setIconSet( QIconSet( image5 ) );
    pushButtonEditColorSchema2D->setUsesTextLabel( FALSE );
    pushButtonEditColorSchema2D->setAutoRaise( FALSE );
    pushButtonEditColorSchema2D->setTextPosition( QToolButton::BelowIcon );
    buttonGroup28Layout->addWidget( pushButtonEditColorSchema2D );

    pushButtonSaveCurrentColorSchema2d = new QToolButton( buttonGroup28, "pushButtonSaveCurrentColorSchema2d" );
    pushButtonSaveCurrentColorSchema2d->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonSaveCurrentColorSchema2d->sizePolicy().hasHeightForWidth() ) );
    pushButtonSaveCurrentColorSchema2d->setMinimumSize( QSize( 25, 25 ) );
    pushButtonSaveCurrentColorSchema2d->setMaximumSize( QSize( 25, 25 ) );
    pushButtonSaveCurrentColorSchema2d->setIconSet( QIconSet( image3 ) );
    pushButtonSaveCurrentColorSchema2d->setUsesTextLabel( FALSE );
    pushButtonSaveCurrentColorSchema2d->setAutoRaise( FALSE );
    pushButtonSaveCurrentColorSchema2d->setTextPosition( QToolButton::BelowIcon );
    buttonGroup28Layout->addWidget( pushButtonSaveCurrentColorSchema2d );

    pushButtonDeleteColorSchema2D = new QToolButton( buttonGroup28, "pushButtonDeleteColorSchema2D" );
    pushButtonDeleteColorSchema2D->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonDeleteColorSchema2D->sizePolicy().hasHeightForWidth() ) );
    pushButtonDeleteColorSchema2D->setMinimumSize( QSize( 25, 25 ) );
    pushButtonDeleteColorSchema2D->setMaximumSize( QSize( 25, 25 ) );
    pushButtonDeleteColorSchema2D->setIconSet( QIconSet( image2 ) );
    pushButtonDeleteColorSchema2D->setUsesTextLabel( FALSE );
    pushButtonDeleteColorSchema2D->setAutoRaise( FALSE );
    pushButtonDeleteColorSchema2D->setTextPosition( QToolButton::BelowIcon );
    buttonGroup28Layout->addWidget( pushButtonDeleteColorSchema2D );
    page1Layout_3->addWidget( buttonGroup28 );

    buttonGroup76 = new QButtonGroup( page1_3, "buttonGroup76" );
    buttonGroup76->setColumnLayout(0, Qt::Vertical );
    buttonGroup76->layout()->setSpacing( 2 );
    buttonGroup76->layout()->setMargin( 11 );
    buttonGroup76Layout = new QGridLayout( buttonGroup76->layout() );
    buttonGroup76Layout->setAlignment( Qt::AlignTop );

    radioButton2DplotRelative = new QRadioButton( buttonGroup76, "radioButton2DplotRelative" );
    radioButton2DplotRelative->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, radioButton2DplotRelative->sizePolicy().hasHeightForWidth() ) );
    radioButton2DplotRelative->setMinimumSize( QSize( 90, 0 ) );
    radioButton2DplotRelative->setMaximumSize( QSize( 90, 32767 ) );
    radioButton2DplotRelative->setChecked( TRUE );

    buttonGroup76Layout->addWidget( radioButton2DplotRelative, 0, 0 );

    textLabel2_2_2 = new QLabel( buttonGroup76, "textLabel2_2_2" );
    textLabel2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2_2->setMinimumSize( QSize( 50, 0 ) );
    textLabel2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    buttonGroup76Layout->addWidget( textLabel2_2_2, 0, 1 );

    lineEditMin = new QLineEdit( buttonGroup76, "lineEditMin" );
    lineEditMin->setMinimumSize( QSize( 55, 25 ) );
    lineEditMin->setMaximumSize( QSize( 55, 32767 ) );
    lineEditMin->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    buttonGroup76Layout->addWidget( lineEditMin, 0, 2 );

    lineEditMax = new QLineEdit( buttonGroup76, "lineEditMax" );
    lineEditMax->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, lineEditMax->sizePolicy().hasHeightForWidth() ) );
    lineEditMax->setMinimumSize( QSize( 55, 25 ) );
    lineEditMax->setMaximumSize( QSize( 55, 32767 ) );
    lineEditMax->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    buttonGroup76Layout->addWidget( lineEditMax, 0, 4 );

    textLabel2_2 = new QLabel( buttonGroup76, "textLabel2_2" );
    textLabel2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    buttonGroup76Layout->addWidget( textLabel2_2, 0, 3 );

    textLabel2_2_2_2 = new QLabel( buttonGroup76, "textLabel2_2_2_2" );
    textLabel2_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel2_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    buttonGroup76Layout->addWidget( textLabel2_2_2_2, 0, 5 );

    checkBoxLog = new QCheckBox( buttonGroup76, "checkBoxLog" );
    checkBoxLog->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, checkBoxLog->sizePolicy().hasHeightForWidth() ) );
    checkBoxLog->setMinimumSize( QSize( 90, 0 ) );
    checkBoxLog->setMaximumSize( QSize( 90, 32767 ) );
    checkBoxLog->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    buttonGroup76Layout->addWidget( checkBoxLog, 0, 6 );

    textLabel2_2_2_4 = new QLabel( buttonGroup76, "textLabel2_2_2_4" );
    textLabel2_2_2_4->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel2_2_2_4->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2_2_4->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    buttonGroup76Layout->addWidget( textLabel2_2_2_4, 1, 1 );

    textLabel2_2_2_2_2 = new QLabel( buttonGroup76, "textLabel2_2_2_2_2" );
    textLabel2_2_2_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, textLabel2_2_2_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2_2_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    buttonGroup76Layout->addWidget( textLabel2_2_2_2_2, 1, 5 );

    lineEditMaxAbs = new QLineEdit( buttonGroup76, "lineEditMaxAbs" );
    lineEditMaxAbs->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, lineEditMaxAbs->sizePolicy().hasHeightForWidth() ) );
    lineEditMaxAbs->setMinimumSize( QSize( 55, 25 ) );
    lineEditMaxAbs->setMaximumSize( QSize( 55, 32767 ) );
    lineEditMaxAbs->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    buttonGroup76Layout->addWidget( lineEditMaxAbs, 1, 4 );

    radioButton2DplotAbsolute = new QRadioButton( buttonGroup76, "radioButton2DplotAbsolute" );
    radioButton2DplotAbsolute->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, radioButton2DplotAbsolute->sizePolicy().hasHeightForWidth() ) );
    radioButton2DplotAbsolute->setMinimumSize( QSize( 90, 0 ) );
    radioButton2DplotAbsolute->setMaximumSize( QSize( 90, 32767 ) );

    buttonGroup76Layout->addWidget( radioButton2DplotAbsolute, 1, 0 );

    lineEditMinAbs = new QLineEdit( buttonGroup76, "lineEditMinAbs" );
    lineEditMinAbs->setMinimumSize( QSize( 55, 25 ) );
    lineEditMinAbs->setMaximumSize( QSize( 55, 32767 ) );
    lineEditMinAbs->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    buttonGroup76Layout->addWidget( lineEditMinAbs, 1, 2 );

    textLabel2_2_4 = new QLabel( buttonGroup76, "textLabel2_2_4" );
    textLabel2_2_4->setPaletteForegroundColor( QColor( 137, 137, 183 ) );

    buttonGroup76Layout->addWidget( textLabel2_2_4, 1, 3 );
    spacer85 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    buttonGroup76Layout->addItem( spacer85, 1, 6 );
    page1Layout_3->addWidget( buttonGroup76 );

    groupBox23_2 = new QGroupBox( page1_3, "groupBox23_2" );
    groupBox23_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)5, 0, 0, groupBox23_2->sizePolicy().hasHeightForWidth() ) );
    groupBox23_2->setMaximumSize( QSize( 32700, 32767 ) );
    groupBox23_2->setColumnLayout(0, Qt::Vertical );
    groupBox23_2->layout()->setSpacing( 2 );
    groupBox23_2->layout()->setMargin( 11 );
    groupBox23_2Layout = new QHBoxLayout( groupBox23_2->layout() );
    groupBox23_2Layout->setAlignment( Qt::AlignTop );

    textLabel2_2_2_3 = new QLabel( groupBox23_2, "textLabel2_2_2_3" );
    textLabel2_2_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel2_2_2_3->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2_2_3->setMinimumSize( QSize( 50, 0 ) );
    textLabel2_2_2_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBox23_2Layout->addWidget( textLabel2_2_2_3 );

    lineEditStepX = new QLineEdit( groupBox23_2, "lineEditStepX" );
    lineEditStepX->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, lineEditStepX->sizePolicy().hasHeightForWidth() ) );
    lineEditStepX->setMinimumSize( QSize( 0, 25 ) );
    lineEditStepX->setMaximumSize( QSize( 70, 32767 ) );
    lineEditStepX->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    groupBox23_2Layout->addWidget( lineEditStepX );

    textLabel2_2_3 = new QLabel( groupBox23_2, "textLabel2_2_3" );
    textLabel2_2_3->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel2_2_3->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2_3->setMinimumSize( QSize( 50, 0 ) );
    textLabel2_2_3->setMaximumSize( QSize( 50, 32767 ) );
    textLabel2_2_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBox23_2Layout->addWidget( textLabel2_2_3 );

    lineEditStepY = new QLineEdit( groupBox23_2, "lineEditStepY" );
    lineEditStepY->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, lineEditStepY->sizePolicy().hasHeightForWidth() ) );
    lineEditStepY->setMinimumSize( QSize( 0, 25 ) );
    lineEditStepY->setMaximumSize( QSize( 70, 32767 ) );
    lineEditStepY->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    groupBox23_2Layout->addWidget( lineEditStepY );
    spacer85_3_2_2 = new QSpacerItem( 10, 5, QSizePolicy::Fixed, QSizePolicy::Minimum );
    groupBox23_2Layout->addItem( spacer85_3_2_2 );

    pushButtonEditXYZtomatrix = new QToolButton( groupBox23_2, "pushButtonEditXYZtomatrix" );
    pushButtonEditXYZtomatrix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonEditXYZtomatrix->sizePolicy().hasHeightForWidth() ) );
    pushButtonEditXYZtomatrix->setMinimumSize( QSize( 25, 25 ) );
    pushButtonEditXYZtomatrix->setMaximumSize( QSize( 25, 25 ) );
    pushButtonEditXYZtomatrix->setIconSet( QIconSet( image4 ) );
    pushButtonEditXYZtomatrix->setUsesTextLabel( FALSE );
    pushButtonEditXYZtomatrix->setAutoRaise( FALSE );
    pushButtonEditXYZtomatrix->setTextPosition( QToolButton::BelowIcon );
    groupBox23_2Layout->addWidget( pushButtonEditXYZtomatrix );
    spacer85_2 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    groupBox23_2Layout->addItem( spacer85_2 );
    page1Layout_3->addWidget( groupBox23_2 );

    groupBox23_2_2 = new QGroupBox( page1_3, "groupBox23_2_2" );
    groupBox23_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, groupBox23_2_2->sizePolicy().hasHeightForWidth() ) );
    groupBox23_2_2->setMaximumSize( QSize( 32700, 32767 ) );
    groupBox23_2_2->setColumnLayout(0, Qt::Vertical );
    groupBox23_2_2->layout()->setSpacing( 2 );
    groupBox23_2_2->layout()->setMargin( 11 );
    groupBox23_2_2Layout = new QHBoxLayout( groupBox23_2_2->layout() );
    groupBox23_2_2Layout->setAlignment( Qt::AlignTop );

    textLabel2_2_2_3_2 = new QLabel( groupBox23_2_2, "textLabel2_2_2_3_2" );
    textLabel2_2_2_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel2_2_2_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2_2_3_2->setMinimumSize( QSize( 50, 0 ) );
    textLabel2_2_2_3_2->setMaximumSize( QSize( 50, 32767 ) );
    textLabel2_2_2_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBox23_2_2Layout->addWidget( textLabel2_2_2_3_2 );

    lineWaterfalFrom = new QLineEdit( groupBox23_2_2, "lineWaterfalFrom" );
    lineWaterfalFrom->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, lineWaterfalFrom->sizePolicy().hasHeightForWidth() ) );
    lineWaterfalFrom->setMinimumSize( QSize( 0, 25 ) );
    lineWaterfalFrom->setMaximumSize( QSize( 70, 32767 ) );
    lineWaterfalFrom->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    groupBox23_2_2Layout->addWidget( lineWaterfalFrom );

    textLabel2_2_3_2 = new QLabel( groupBox23_2_2, "textLabel2_2_3_2" );
    textLabel2_2_3_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel2_2_3_2->sizePolicy().hasHeightForWidth() ) );
    textLabel2_2_3_2->setMinimumSize( QSize( 50, 0 ) );
    textLabel2_2_3_2->setMaximumSize( QSize( 50, 32767 ) );
    textLabel2_2_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    groupBox23_2_2Layout->addWidget( textLabel2_2_3_2 );

    lineWaterfalTo = new QLineEdit( groupBox23_2_2, "lineWaterfalTo" );
    lineWaterfalTo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, lineWaterfalTo->sizePolicy().hasHeightForWidth() ) );
    lineWaterfalTo->setMinimumSize( QSize( 0, 25 ) );
    lineWaterfalTo->setMaximumSize( QSize( 70, 32767 ) );
    lineWaterfalTo->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    groupBox23_2_2Layout->addWidget( lineWaterfalTo );
    spacer85_3_2 = new QSpacerItem( 10, 5, QSizePolicy::Fixed, QSizePolicy::Minimum );
    groupBox23_2_2Layout->addItem( spacer85_3_2 );

    pushButtonWaterfall = new QToolButton( groupBox23_2_2, "pushButtonWaterfall" );
    pushButtonWaterfall->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonWaterfall->sizePolicy().hasHeightForWidth() ) );
    pushButtonWaterfall->setMinimumSize( QSize( 25, 25 ) );
    pushButtonWaterfall->setMaximumSize( QSize( 25, 25 ) );
    pushButtonWaterfall->setIconSet( QIconSet( image4 ) );
    pushButtonWaterfall->setUsesTextLabel( FALSE );
    pushButtonWaterfall->setAutoRaise( FALSE );
    pushButtonWaterfall->setTextPosition( QToolButton::BelowIcon );
    groupBox23_2_2Layout->addWidget( pushButtonWaterfall );
    spacer85_3 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    groupBox23_2_2Layout->addItem( spacer85_3 );
    page1Layout_3->addWidget( groupBox23_2_2 );
    spacer37_2 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page1Layout_3->addItem( spacer37_2 );
    toolBox8->addItem( page1_3, QString::fromLatin1("") );

    page2_3 = new QWidget( toolBox8, "page2_3" );
    page2_3->setBackgroundMode( QWidget::PaletteBackground );
    page2Layout_3 = new QVBoxLayout( page2_3, 11, 6, "page2Layout_3"); 

    buttonGrouprescaleQ = new QButtonGroup( page2_3, "buttonGrouprescaleQ" );
    buttonGrouprescaleQ->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGrouprescaleQ->sizePolicy().hasHeightForWidth() ) );
    buttonGrouprescaleQ->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    buttonGrouprescaleQ->setMargin( 0 );

    textLabelResoPixelSize2_2 = new QLabel( buttonGrouprescaleQ, "textLabelResoPixelSize2_2" );
    textLabelResoPixelSize2_2->setGeometry( QRect( 187, 47, 38, 17 ) );

    textLabelResoDet2_2 = new QLabel( buttonGrouprescaleQ, "textLabelResoDet2_2" );
    textLabelResoDet2_2->setGeometry( QRect( 187, 70, 38, 17 ) );

    textLabelResoDeltaLambda2_2 = new QLabel( buttonGrouprescaleQ, "textLabelResoDeltaLambda2_2" );
    textLabelResoDeltaLambda2_2->setGeometry( QRect( 187, 93, 38, 17 ) );

    textLabelResoDeltaLambda2_2_2 = new QLabel( buttonGrouprescaleQ, "textLabelResoDeltaLambda2_2_2" );
    textLabelResoDeltaLambda2_2_2->setGeometry( QRect( 187, 116, 38, 17 ) );

    textLabelResoPixelSize_2 = new QLabel( buttonGrouprescaleQ, "textLabelResoPixelSize_2" );
    textLabelResoPixelSize_2->setGeometry( QRect( 12, 47, 80, 17 ) );
    textLabelResoPixelSize_2->setMaximumSize( QSize( 32767, 20 ) );

    textLabelResoDet_2 = new QLabel( buttonGrouprescaleQ, "textLabelResoDet_2" );
    textLabelResoDet_2->setGeometry( QRect( 12, 70, 69, 17 ) );
    textLabelResoDet_2->setMaximumSize( QSize( 32767, 20 ) );

    textLabelResoDeltaLambda_2 = new QLabel( buttonGrouprescaleQ, "textLabelResoDeltaLambda_2" );
    textLabelResoDeltaLambda_2->setGeometry( QRect( 12, 93, 69, 17 ) );
    textLabelResoDeltaLambda_2->setMaximumSize( QSize( 32767, 20 ) );

    textLabelResoDeltaLambda_2_2 = new QLabel( buttonGrouprescaleQ, "textLabelResoDeltaLambda_2_2" );
    textLabelResoDeltaLambda_2_2->setGeometry( QRect( 12, 116, 69, 17 ) );
    textLabelResoDeltaLambda_2_2->setMaximumSize( QSize( 32767, 20 ) );

    textLabelResoLambda2_2 = new QLabel( buttonGrouprescaleQ, "textLabelResoLambda2_2" );
    textLabelResoLambda2_2->setGeometry( QRect( 187, 24, 38, 17 ) );

    textLabelResoLambda_2 = new QLabel( buttonGrouprescaleQ, "textLabelResoLambda_2" );
    textLabelResoLambda_2->setGeometry( QRect( 12, 24, 69, 17 ) );
    textLabelResoLambda_2->setMaximumSize( QSize( 32767, 20 ) );

    lineEditResoLambdaRescale = new QLineEdit( buttonGrouprescaleQ, "lineEditResoLambdaRescale" );
    lineEditResoLambdaRescale->setGeometry( QRect( 99, 24, 70, 20 ) );
    lineEditResoLambdaRescale->setMinimumSize( QSize( 70, 20 ) );
    lineEditResoLambdaRescale->setMaximumSize( QSize( 70, 20 ) );
    lineEditResoLambdaRescale->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    lineEditResoLambdaRescale->setFrameShape( QLineEdit::LineEditPanel );
    lineEditResoLambdaRescale->setFrameShadow( QLineEdit::Sunken );

    lineEditResoPixelSizeRescale = new QLineEdit( buttonGrouprescaleQ, "lineEditResoPixelSizeRescale" );
    lineEditResoPixelSizeRescale->setGeometry( QRect( 99, 45, 70, 20 ) );
    lineEditResoPixelSizeRescale->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, lineEditResoPixelSizeRescale->sizePolicy().hasHeightForWidth() ) );
    lineEditResoPixelSizeRescale->setMinimumSize( QSize( 70, 20 ) );
    lineEditResoPixelSizeRescale->setMaximumSize( QSize( 70, 20 ) );
    lineEditResoPixelSizeRescale->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    lineEditDetRescale = new QLineEdit( buttonGrouprescaleQ, "lineEditDetRescale" );
    lineEditDetRescale->setGeometry( QRect( 99, 66, 70, 20 ) );
    lineEditDetRescale->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, lineEditDetRescale->sizePolicy().hasHeightForWidth() ) );
    lineEditDetRescale->setMinimumSize( QSize( 70, 20 ) );
    lineEditDetRescale->setMaximumSize( QSize( 70, 20 ) );
    lineEditDetRescale->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    lineEditResoDeltaXcenter = new QLineEdit( buttonGrouprescaleQ, "lineEditResoDeltaXcenter" );
    lineEditResoDeltaXcenter->setGeometry( QRect( 99, 87, 70, 20 ) );
    lineEditResoDeltaXcenter->setMinimumSize( QSize( 70, 20 ) );
    lineEditResoDeltaXcenter->setMaximumSize( QSize( 70, 20 ) );
    lineEditResoDeltaXcenter->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    lineEditResoDeltaYcenter = new QLineEdit( buttonGrouprescaleQ, "lineEditResoDeltaYcenter" );
    lineEditResoDeltaYcenter->setGeometry( QRect( 99, 108, 70, 20 ) );
    lineEditResoDeltaYcenter->setMinimumSize( QSize( 70, 20 ) );
    lineEditResoDeltaYcenter->setMaximumSize( QSize( 70, 20 ) );
    lineEditResoDeltaYcenter->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );

    pushButtonRescale = new QPushButton( buttonGrouprescaleQ, "pushButtonRescale" );
    pushButtonRescale->setGeometry( QRect( 235, 30, 110, 100 ) );
    pushButtonRescale->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    pushButtonRescale->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonRescale_font(  pushButtonRescale->font() );
    pushButtonRescale_font.setBold( TRUE );
    pushButtonRescale->setFont( pushButtonRescale_font ); 
    page2Layout_3->addWidget( buttonGrouprescaleQ );

    textLabel1_9 = new QLabel( page2_3, "textLabel1_9" );
    textLabel1_9->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel1_9->sizePolicy().hasHeightForWidth() ) );
    textLabel1_9->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    page2Layout_3->addWidget( textLabel1_9 );
    spacer36 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    page2Layout_3->addItem( spacer36 );
    toolBox8->addItem( page2_3, QString::fromLatin1("") );
    TabPageLayout_4->addWidget( toolBox8 );
    sansTab->insertTab( TabPage_4, QString::fromLatin1("") );

    TabPage_5 = new QWidget( sansTab, "TabPage_5" );
    TabPageLayout_5 = new QVBoxLayout( TabPage_5, 11, 6, "TabPageLayout_5"); 

    groupBox15 = new QGroupBox( TabPage_5, "groupBox15" );
    groupBox15->setColumnLayout(0, Qt::Vertical );
    groupBox15->layout()->setSpacing( 6 );
    groupBox15->layout()->setMargin( 11 );
    groupBox15Layout = new QVBoxLayout( groupBox15->layout() );
    groupBox15Layout->setAlignment( Qt::AlignTop );

    layout57 = new QHBoxLayout( 0, 0, 2, "layout57"); 

    comboBoxHeaderStructure = new QComboBox( FALSE, groupBox15, "comboBoxHeaderStructure" );
    comboBoxHeaderStructure->setMinimumSize( QSize( 0, 25 ) );
    comboBoxHeaderStructure->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    layout57->addWidget( comboBoxHeaderStructure );

    pushButtonNewHeaderSTR = new QToolButton( groupBox15, "pushButtonNewHeaderSTR" );
    pushButtonNewHeaderSTR->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonNewHeaderSTR->sizePolicy().hasHeightForWidth() ) );
    pushButtonNewHeaderSTR->setMinimumSize( QSize( 25, 25 ) );
    pushButtonNewHeaderSTR->setMaximumSize( QSize( 25, 25 ) );
    pushButtonNewHeaderSTR->setIconSet( QIconSet( image1 ) );
    layout57->addWidget( pushButtonNewHeaderSTR );

    pushButtonHSTRdelete = new QToolButton( groupBox15, "pushButtonHSTRdelete" );
    pushButtonHSTRdelete->setEnabled( FALSE );
    pushButtonHSTRdelete->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonHSTRdelete->sizePolicy().hasHeightForWidth() ) );
    pushButtonHSTRdelete->setMinimumSize( QSize( 25, 25 ) );
    pushButtonHSTRdelete->setMaximumSize( QSize( 25, 25 ) );
    pushButtonHSTRdelete->setIconSet( QIconSet( image2 ) );
    layout57->addWidget( pushButtonHSTRdelete );

    pushButtonsaveCurrentHeaderSTR = new QToolButton( groupBox15, "pushButtonsaveCurrentHeaderSTR" );
    pushButtonsaveCurrentHeaderSTR->setEnabled( FALSE );
    pushButtonsaveCurrentHeaderSTR->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonsaveCurrentHeaderSTR->sizePolicy().hasHeightForWidth() ) );
    pushButtonsaveCurrentHeaderSTR->setMinimumSize( QSize( 25, 25 ) );
    pushButtonsaveCurrentHeaderSTR->setMaximumSize( QSize( 25, 25 ) );
    pushButtonsaveCurrentHeaderSTR->setIconSet( QIconSet( image3 ) );
    layout57->addWidget( pushButtonsaveCurrentHeaderSTR );
    groupBox15Layout->addLayout( layout57 );
    TabPageLayout_5->addWidget( groupBox15 );

    layout66_2 = new QVBoxLayout( 0, 0, 0, "layout66_2"); 

    vv = new QGroupBox( TabPage_5, "vv" );
    vv->setEnabled( TRUE );
    vv->setLineWidth( 0 );
    vv->setCheckable( FALSE );
    vv->setChecked( FALSE );
    vv->setColumnLayout(0, Qt::Vertical );
    vv->layout()->setSpacing( 2 );
    vv->layout()->setMargin( 1 );
    vvLayout = new QHBoxLayout( vv->layout() );
    vvLayout->setAlignment( Qt::AlignTop );

    groupBoxPeriodicalHeader = new QCheckBox( vv, "groupBoxPeriodicalHeader" );
    groupBoxPeriodicalHeader->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, groupBoxPeriodicalHeader->sizePolicy().hasHeightForWidth() ) );
    groupBoxPeriodicalHeader->setMinimumSize( QSize( 180, 0 ) );
    groupBoxPeriodicalHeader->setMaximumSize( QSize( 180, 32767 ) );
    vvLayout->addWidget( groupBoxPeriodicalHeader );

    textLabel1_11 = new QLabel( vv, "textLabel1_11" );
    textLabel1_11->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel1_11->sizePolicy().hasHeightForWidth() ) );
    textLabel1_11->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabel1_11->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignRight ) );
    vvLayout->addWidget( textLabel1_11 );

    spinBoxHeaderReaderOffset = new QSpinBox( vv, "spinBoxHeaderReaderOffset" );
    spinBoxHeaderReaderOffset->setMinimumSize( QSize( 65, 20 ) );
    spinBoxHeaderReaderOffset->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxHeaderReaderOffset->setMaxValue( 100000 );
    spinBoxHeaderReaderOffset->setValue( 0 );
    vvLayout->addWidget( spinBoxHeaderReaderOffset );

    textLabel1_11_2 = new QLabel( vv, "textLabel1_11_2" );
    textLabel1_11_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabel1_11_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_11_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabel1_11_2->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignRight ) );
    vvLayout->addWidget( textLabel1_11_2 );

    spinBoxHeaderReaderPeriod = new QSpinBox( vv, "spinBoxHeaderReaderPeriod" );
    spinBoxHeaderReaderPeriod->setMinimumSize( QSize( 65, 20 ) );
    spinBoxHeaderReaderPeriod->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    spinBoxHeaderReaderPeriod->setMaxValue( 100000 );
    spinBoxHeaderReaderPeriod->setValue( 0 );
    vvLayout->addWidget( spinBoxHeaderReaderPeriod );
    layout66_2->addWidget( vv );

    line1_2_3_11_5_10_2_3_2 = new QFrame( TabPage_5, "line1_2_3_11_5_10_2_3_2" );
    line1_2_3_11_5_10_2_3_2->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_3_11_5_10_2_3_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2_3_2->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2_3_2->setFrameShape( QFrame::HLine );
    line1_2_3_11_5_10_2_3_2->setFrameShadow( QFrame::Plain );
    line1_2_3_11_5_10_2_3_2->setLineWidth( 1 );
    line1_2_3_11_5_10_2_3_2->setFrameShape( QFrame::HLine );
    layout66_2->addWidget( line1_2_3_11_5_10_2_3_2 );

    xx = new QGroupBox( TabPage_5, "xx" );
    xx->setLineWidth( 0 );
    xx->setCheckable( FALSE );
    xx->setChecked( FALSE );
    xx->setColumnLayout(0, Qt::Vertical );
    xx->layout()->setSpacing( 2 );
    xx->layout()->setMargin( 1 );
    xxLayout = new QHBoxLayout( xx->layout() );
    xxLayout->setAlignment( Qt::AlignTop );

    groupBoxXML = new QCheckBox( xx, "groupBoxXML" );
    groupBoxXML->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, groupBoxXML->sizePolicy().hasHeightForWidth() ) );
    groupBoxXML->setMinimumSize( QSize( 180, 0 ) );
    groupBoxXML->setMaximumSize( QSize( 180, 32767 ) );
    xxLayout->addWidget( groupBoxXML );

    textLabel1_11_3 = new QLabel( xx, "textLabel1_11_3" );
    textLabel1_11_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    xxLayout->addWidget( textLabel1_11_3 );

    lineEditXMLbase = new QLineEdit( xx, "lineEditXMLbase" );
    lineEditXMLbase->setMaximumSize( QSize( 32767, 20 ) );
    lineEditXMLbase->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    xxLayout->addWidget( lineEditXMLbase );
    layout66_2->addWidget( xx );

    line1_2_3_11_5_10_2_3 = new QFrame( TabPage_5, "line1_2_3_11_5_10_2_3" );
    line1_2_3_11_5_10_2_3->setMaximumSize( QSize( 32767, 2 ) );
    line1_2_3_11_5_10_2_3->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2_3->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    line1_2_3_11_5_10_2_3->setFrameShape( QFrame::HLine );
    line1_2_3_11_5_10_2_3->setFrameShadow( QFrame::Plain );
    line1_2_3_11_5_10_2_3->setLineWidth( 1 );
    line1_2_3_11_5_10_2_3->setFrameShape( QFrame::HLine );
    layout66_2->addWidget( line1_2_3_11_5_10_2_3 );

    groupBoxYAML = new QCheckBox( TabPage_5, "groupBoxYAML" );
    layout66_2->addWidget( groupBoxYAML );
    TabPageLayout_5->addLayout( layout66_2 );

    groupBox8 = new QGroupBox( TabPage_5, "groupBox8" );
    groupBox8->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, groupBox8->sizePolicy().hasHeightForWidth() ) );
    groupBox8->setColumnLayout(0, Qt::Vertical );
    groupBox8->layout()->setSpacing( 6 );
    groupBox8->layout()->setMargin( 11 );
    groupBox8Layout = new QVBoxLayout( groupBox8->layout() );
    groupBox8Layout->setAlignment( Qt::AlignTop );

    tableHeader = new QTable( groupBox8, "tableHeader" );
    tableHeader->setNumCols( tableHeader->numCols() + 1 );
    tableHeader->horizontalHeader()->setLabel( tableHeader->numCols() - 1, tr( "?" ) );
    tableHeader->setNumCols( tableHeader->numCols() + 1 );
    tableHeader->horizontalHeader()->setLabel( tableHeader->numCols() - 1, tr( "#-Line" ) );
    tableHeader->setNumCols( tableHeader->numCols() + 1 );
    tableHeader->horizontalHeader()->setLabel( tableHeader->numCols() - 1, tr( "#-Order" ) );
    tableHeader->setNumCols( tableHeader->numCols() + 1 );
    tableHeader->horizontalHeader()->setLabel( tableHeader->numCols() - 1, tr( "#-Symbols" ) );
    tableHeader->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    tableHeader->setNumRows( 0 );
    tableHeader->setNumCols( 4 );
    tableHeader->setRowMovingEnabled( TRUE );
    groupBox8Layout->addWidget( tableHeader );

    layout175 = new QHBoxLayout( 0, 0, 6, "layout175"); 

    textLabelMLH = new QLabel( groupBox8, "textLabelMLH" );
    layout175->addWidget( textLabelMLH );

    lineEditMaxLengthHeader = new QLineEdit( groupBox8, "lineEditMaxLengthHeader" );
    layout175->addWidget( lineEditMaxLengthHeader );
    spacer18 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout175->addItem( spacer18 );

    pushButtonHSTRitemsDel = new QToolButton( groupBox8, "pushButtonHSTRitemsDel" );
    pushButtonHSTRitemsDel->setEnabled( FALSE );
    pushButtonHSTRitemsDel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonHSTRitemsDel->sizePolicy().hasHeightForWidth() ) );
    pushButtonHSTRitemsDel->setMinimumSize( QSize( 25, 25 ) );
    pushButtonHSTRitemsDel->setMaximumSize( QSize( 25, 25 ) );
    pushButtonHSTRitemsDel->setIconSet( QIconSet( image9 ) );
    layout175->addWidget( pushButtonHSTRitemsDel );

    pushButtonAdd = new QToolButton( groupBox8, "pushButtonAdd" );
    pushButtonAdd->setEnabled( FALSE );
    pushButtonAdd->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonAdd->sizePolicy().hasHeightForWidth() ) );
    pushButtonAdd->setMinimumSize( QSize( 25, 25 ) );
    pushButtonAdd->setMaximumSize( QSize( 25, 25 ) );
    pushButtonAdd->setIconSet( QIconSet( image10 ) );
    layout175->addWidget( pushButtonAdd );
    groupBox8Layout->addLayout( layout175 );
    TabPageLayout_5->addWidget( groupBox8 );

    pushButtonHeaderReader = new QToolButton( TabPage_5, "pushButtonHeaderReader" );
    pushButtonHeaderReader->setMinimumSize( QSize( 0, 25 ) );
    pushButtonHeaderReader->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    pushButtonHeaderReader->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    QFont pushButtonHeaderReader_font(  pushButtonHeaderReader->font() );
    pushButtonHeaderReader_font.setBold( TRUE );
    pushButtonHeaderReader->setFont( pushButtonHeaderReader_font ); 
    TabPageLayout_5->addWidget( pushButtonHeaderReader );

    buttonGroup97 = new QButtonGroup( TabPage_5, "buttonGroup97" );
    buttonGroup97->setFrameShape( QButtonGroup::NoFrame );
    buttonGroup97->setFrameShadow( QButtonGroup::Plain );
    buttonGroup97->setLineWidth( 0 );
    buttonGroup97->setColumnLayout(0, Qt::Vertical );
    buttonGroup97->layout()->setSpacing( 1 );
    buttonGroup97->layout()->setMargin( 0 );
    buttonGroup97Layout = new QHBoxLayout( buttonGroup97->layout() );
    buttonGroup97Layout->setAlignment( Qt::AlignTop );

    layout219_2 = new QVBoxLayout( 0, 0, 0, "layout219_2"); 

    radioButtonNfiles = new QRadioButton( buttonGroup97, "radioButtonNfiles" );
    radioButtonNfiles->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, radioButtonNfiles->sizePolicy().hasHeightForWidth() ) );
    radioButtonNfiles->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout219_2->addWidget( radioButtonNfiles );

    lineEditNumberExtractor = new QLineEdit( buttonGroup97, "lineEditNumberExtractor" );
    layout219_2->addWidget( lineEditNumberExtractor );
    buttonGroup97Layout->addLayout( layout219_2 );

    line43 = new QFrame( buttonGroup97, "line43" );
    line43->setMinimumSize( QSize( 4, 0 ) );
    line43->setMaximumSize( QSize( 4, 32759 ) );
    line43->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    line43->setFrameShape( QFrame::VLine );
    line43->setFrameShadow( QFrame::Plain );
    line43->setLineWidth( 2 );
    line43->setFrameShape( QFrame::VLine );
    buttonGroup97Layout->addWidget( line43 );

    layout130 = new QVBoxLayout( 0, 0, 0, "layout130"); 

    layout129 = new QHBoxLayout( 0, 0, 0, "layout129"); 

    radioButtonOneFile = new QRadioButton( buttonGroup97, "radioButtonOneFile" );
    radioButtonOneFile->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, radioButtonOneFile->sizePolicy().hasHeightForWidth() ) );
    radioButtonOneFile->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    radioButtonOneFile->setChecked( TRUE );
    layout129->addWidget( radioButtonOneFile );

    radioButtonNMcolumns = new QRadioButton( buttonGroup97, "radioButtonNMcolumns" );
    radioButtonNMcolumns->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, radioButtonNMcolumns->sizePolicy().hasHeightForWidth() ) );
    radioButtonNMcolumns->setMinimumSize( QSize( 0, 0 ) );
    radioButtonNMcolumns->setMaximumSize( QSize( 15000, 32767 ) );
    radioButtonNMcolumns->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    layout129->addWidget( radioButtonNMcolumns );
    layout130->addLayout( layout129 );

    comboBoxNMcolumns = new QComboBox( FALSE, buttonGroup97, "comboBoxNMcolumns" );
    comboBoxNMcolumns->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, comboBoxNMcolumns->sizePolicy().hasHeightForWidth() ) );
    comboBoxNMcolumns->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    comboBoxNMcolumns->setPaletteBackgroundColor( QColor( 255, 255, 195 ) );
    comboBoxNMcolumns->setMaxCount( 10 );
    comboBoxNMcolumns->setInsertionPolicy( QComboBox::AtBottom );
    comboBoxNMcolumns->setDuplicatesEnabled( FALSE );
    layout130->addWidget( comboBoxNMcolumns );
    buttonGroup97Layout->addLayout( layout130 );

    textLabelCurrentHeader = new QLabel( buttonGroup97, "textLabelCurrentHeader" );
    textLabelCurrentHeader->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, textLabelCurrentHeader->sizePolicy().hasHeightForWidth() ) );
    textLabelCurrentHeader->setMinimumSize( QSize( 0, 0 ) );
    textLabelCurrentHeader->setMaximumSize( QSize( 1, 32767 ) );
    buttonGroup97Layout->addWidget( textLabelCurrentHeader );
    TabPageLayout_5->addWidget( buttonGroup97 );
    sansTab->insertTab( TabPage_5, QString::fromLatin1("") );

    TabPage_6 = new QWidget( sansTab, "TabPage_6" );
    TabPageLayout_6 = new QVBoxLayout( TabPage_6, 11, 6, "TabPageLayout_6"); 

    layout68 = new QHBoxLayout( 0, 0, 6, "layout68"); 

    layout67_3 = new QVBoxLayout( 0, 0, 6, "layout67_3"); 

    layout2 = new QGridLayout( 0, 1, 1, 0, 6, "layout2"); 

    startingLineCSV = new QLineEdit( TabPage_6, "startingLineCSV" );

    layout2->addWidget( startingLineCSV, 0, 0 );

    csvSplitter = new QComboBox( FALSE, TabPage_6, "csvSplitter" );
    csvSplitter->setEditable( TRUE );

    layout2->addWidget( csvSplitter, 2, 0 );

    textLabel1_2_2_2 = new QLabel( TabPage_6, "textLabel1_2_2_2" );

    layout2->addWidget( textLabel1_2_2_2, 2, 1 );

    textLabel1_2_3 = new QLabel( TabPage_6, "textLabel1_2_3" );

    layout2->addWidget( textLabel1_2_3, 0, 1 );

    headerLineCSV = new QLineEdit( TabPage_6, "headerLineCSV" );

    layout2->addWidget( headerLineCSV, 1, 0 );

    textLabel1_2_2_3 = new QLabel( TabPage_6, "textLabel1_2_2_3" );

    layout2->addWidget( textLabel1_2_2_3, 1, 1 );
    layout67_3->addLayout( layout2 );
    spacer37_3 = new QSpacerItem( 5, 20, QSizePolicy::Minimum, QSizePolicy::Fixed );
    layout67_3->addItem( spacer37_3 );

    cbSkip = new QCheckBox( TabPage_6, "cbSkip" );
    cbSkip->setChecked( TRUE );
    layout67_3->addWidget( cbSkip );

    CSVimport = new QToolButton( TabPage_6, "CSVimport" );
    CSVimport->setMinimumSize( QSize( 0, 25 ) );
    CSVimport->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    CSVimport->setPaletteBackgroundColor( QColor( 137, 137, 183 ) );
    QFont CSVimport_font(  CSVimport->font() );
    CSVimport_font.setBold( TRUE );
    CSVimport->setFont( CSVimport_font ); 
    layout67_3->addWidget( CSVimport );
    layout68->addLayout( layout67_3 );
    spacer47 = new QSpacerItem( 1, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout68->addItem( spacer47 );
    TabPageLayout_6->addLayout( layout68 );
    spacer46 = new QSpacerItem( 5, 1, QSizePolicy::Minimum, QSizePolicy::Expanding );
    TabPageLayout_6->addItem( spacer46 );
    sansTab->insertTab( TabPage_6, QString::fromLatin1("") );
    danpLayout->addWidget( sansTab );

    layout50 = new QHBoxLayout( 0, 0, 3, "layout50"); 

    textLabelInfoSAS = new QLabel( this, "textLabelInfoSAS" );
    textLabelInfoSAS->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfoSAS->sizePolicy().hasHeightForWidth() ) );
    textLabelInfoSAS->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfoSAS->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabelInfoSAS->setPalette( pal );
    textLabelInfoSAS->setFrameShape( QLabel::Box );
    textLabelInfoSAS->setTextFormat( QLabel::RichText );
    textLabelInfoSAS->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    textLabelInfoSAS->setIndent( 0 );
    layout50->addWidget( textLabelInfoSAS );

    textLabelInfo_2_2 = new QLabel( this, "textLabelInfo_2_2" );
    textLabelInfo_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo_2_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabelInfo_2_2->setPalette( pal );
    textLabelInfo_2_2->setFrameShape( QLabel::Box );
    textLabelInfo_2_2->setAlignment( int( QLabel::AlignCenter ) );
    layout50->addWidget( textLabelInfo_2_2 );

    textLabelInfo_2 = new QLabel( this, "textLabelInfo_2" );
    textLabelInfo_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo_2->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo_2->setMinimumSize( QSize( 0, 20 ) );
    textLabelInfo_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 238, 239, 241) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 137, 137, 183) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 254, 254, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 110, 111, 114) );
    cg.setColor( QColorGroup::Mid, QColor( 147, 149, 152) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    textLabelInfo_2->setPalette( pal );
    textLabelInfo_2->setFrameShape( QLabel::Box );
    textLabelInfo_2->setFrameShadow( QLabel::Plain );
    textLabelInfo_2->setAlignment( int( QLabel::AlignCenter ) );
    layout50->addWidget( textLabelInfo_2 );

    pushButtonHelp = new QPushButton( this, "pushButtonHelp" );
    pushButtonHelp->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, pushButtonHelp->sizePolicy().hasHeightForWidth() ) );
    pushButtonHelp->setMinimumSize( QSize( 20, 20 ) );
    pushButtonHelp->setMaximumSize( QSize( 20, 20 ) );
    pushButtonHelp->setPaletteForegroundColor( QColor( 239, 239, 239 ) );
    pushButtonHelp->setPaletteBackgroundColor( QColor( 239, 239, 239 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 247, 247, 247) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    pushButtonHelp->setPalette( pal );
    pushButtonHelp->setPixmap( image11 );
    pushButtonHelp->setFlat( TRUE );
    layout50->addWidget( pushButtonHelp );
    danpLayout->addLayout( layout50 );
    languageChange();
    resize( QSize(814, 636).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // buddies
    textLabelResoCol->setBuddy( lineEditResoCol );
    textLabelResoDet->setBuddy( lineEditResoDet );
    textLabelResoPixelSize->setBuddy( lineEditResoPixelSize );
    textLabelResoPixelSize_2->setBuddy( lineEditResoPixelSize );
    textLabelResoDet_2->setBuddy( lineEditResoDet );
}

/*
 *  Destroys the object and frees any allocated resources
 */
danp::~danp()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void danp::languageChange()
{
    setCaption( tr( "QtiKWS::SA(N)S-Tools" ) );
    textLabelInfo->setText( tr( "Path >>> Set Directory for the Import/Export of Files <<<" ) );
    buttonGroup53->setTitle( tr( "ASCII: Input Folder" ) );
    lineEditPath->setText( tr( "home" ) );
    pushButtonPath->setText( QString::null );
    buttonGroup53_2->setTitle( tr( "ASCII: Output Folder" ) );
    lineEditPathOut->setText( tr( "home" ) );
    pushButtonPathOut->setText( QString::null );
    sansTab->changeTab( TabPage, tr( "Path" ) );
    comboBoxStructureASCII1D->clear();
    comboBoxStructureASCII1D->insertItem( tr( "default" ) );
    pushButtonNewASCII1D->setText( QString::null );
    pushButtonDeleteASCII1D->setText( QString::null );
    pushButtonSaveCurrentASCII1D->setText( QString::null );
    buttonGroup31->setTitle( QString::null );
    ASCIIpushButton->setText( tr( "Process data!" ) );
    groupBox78->setTitle( tr( "Data-Source. From :" ) );
    comboBoxSource->clear();
    comboBoxSource->insertItem( tr( "File" ) );
    comboBoxSource->insertItem( tr( "Table" ) );
    groupBox77->setTitle( tr( "Data-Destination. To :" ) );
    comboBoxDestination->clear();
    comboBoxDestination->insertItem( tr( "Table" ) );
    comboBoxDestination->insertItem( tr( "File" ) );
    groupFormat->setTitle( tr( "Input-File-Structure :" ) );
    comboBoxFormat->clear();
    comboBoxFormat->insertItem( tr( "ASCII" ) );
    comboBoxFormat->insertItem( tr( "ASCII+HEADER" ) );
    comboBoxFormat->insertItem( tr( "cansas1d-xml" ) );
    comboBoxFormat->insertItem( tr( "NIST" ) );
    spinBoxForceNumCols->setPrefix( tr( "# Columns:  " ) );
    groupBox11->setTitle( tr( "Name-Structure :" ) );
    spinBoxFindIndex->clear();
    spinBoxFindIndex->insertItem( tr( "[Prefix-]File-Name" ) );
    spinBoxFindIndex->insertItem( tr( "[Prefix-]#:  1st #" ) );
    spinBoxFindIndex->insertItem( tr( "[Prefix-]#:  2nd #" ) );
    spinBoxFindIndex->insertItem( tr( "[Prefix-]#:  3rd #" ) );
    spinBoxFindIndex->insertItem( tr( "[Prefix-]#:  5th #" ) );
    spinBoxFindIndex->insertItem( tr( "[Prefix-]#:  6th #" ) );
    spinBoxFindIndex->insertItem( tr( "[Prefix-]#:  7th #" ) );
    spinBoxFindIndex->insertItem( tr( "[Prefix-]#:  8th #" ) );
    spinBoxFindIndex->insertItem( tr( "[Prefix-]#:  9th #" ) );
    spinBoxFindIndex->setCurrentItem( 0 );
    comboBoxPrefixASCII1D->clear();
    comboBoxPrefixASCII1D->insertItem( tr( "Auto [Prefix]" ) );
    comboBoxPrefixASCII1D->insertItem( tr( "No [Prefix]" ) );
    comboBoxPrefixASCII1D->setCurrentItem( 1 );
    checkBoxIndexing->setText( tr( "Indexing [name]" ) );
    groupBox7->setTitle( tr( "Options :" ) );
    checkBoxActions->setText( tr( "Modify [data]" ) );
    checkBoxPlotInActive->setText( tr( "Plot [in active Graph]" ) );
    checkBoxReso->setText( trUtf8( "\x43\x61\x6c\x63\x75\x6c\x61\x74\x65\x20\x52\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e\x2d\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x20\xcf\x83" ) );
    textLabelResoDescription->setText( trUtf8( "\x3c\x70\x20\x61\x6c\x69\x67\x6e\x3d\x22\x6c\x65\x66\x74\x22\x3e\xd\xa\x2d\x2d\x2d\x20\x49\x66\x20\x79\x6f\x75\x20\x61\x63\x74\x69\x76\x61\x74\x65\x20\x74\x68\x69\x73\x20\x6f\x70\x74\x69\x6f\x6e\x2c\x20\x66\x6f\x72\x20\x65\x76\x65\x72\x79\x20\x51\x2d\x76\x61\x6c\x75\x65\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x63\x61\x6c\x63\x75\x6c\x61\x74\x65\x64\x20\xd\xa\x68\x61\x6c\x66\x20\x77\x69\x64\x74\x68\x20\x3c\x66\x6f\x6e\x74\x20\x73\x69\x7a\x65\x3d\x22\x2b\x31\x22\x3e\xcf\x83\x3c\x2f\x66\x6f\x6e\x74\x3e\x28\x51\x29\x20\x6f\x66\x20\x72\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20\xd\xa\x52\x28\x51\x2c\x51\x3c\x73\x75\x62\x3e\x30\x3c\x2f\x73\x75\x62\x3e\x2c\x3c\x66\x6f\x6e\x74\x20\x73\x69\x7a\x65\x3d\x22\x2b\x31\x22\x3e\xcf\x83\x3c\x2f\x66\x6f\x6e\x74\x3e\x29\x2e\x3c\x62\x72\x3e\x3c\x62\x72\x3e\xd\xa\x2d\x2d\x2d\x20\x54\x68\x69\x73\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x6f\x75\x6c\x64\x20\x62\x65\x20\x75\x73\x65\x64\x20\x66\x6f\x72\x20\x63\x6f\x6e\x76\x6f\x6c\x75\x74\x69\x6f\x6e\x20\x6f\x66\x20\x74\x68\x65\x20\x6d\x6f\x64\x65\x6c\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20\xd\xa\x49\x3c\x73\x75\x62\x3e\x6d\x6f\x64\x65\x6c\x3c\x2f\x73\x75\x62\x3e\x28\x51\x3c\x73\x75\x62\x3e\x30\x3c\x2f\x73\x75\x62\x3e\x29\x20\x64\x75\x72\x69\x6e\x67\x20\x61\x20\x6d\x6f\x64\x65\x6c\x2d\x66\x69\x74\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x3a\x3c\x62\x72\x3e\x3c\x62\x72\x3e\xd\xa\x20\x49\x3c\x73\x75\x62\x3e\x63\x6f\x6e\x2e\x6d\x6f\x64\x65\x6c\x3c\x2f\x73\x75\x62\x3e\x28\x51\x29\x3d\xe2\x88\xab\x52\x28\x51\x2c\x51\x3c\x73\x75\x62\x3e\x30\x3c\x2f\x73\x75\x62\x3e\x2c\x3c\x66\x6f\x6e\x74\x20\x73\x69\x7a\x65\x3d\x22\x2b\x31\x22\x3e\xcf\x83\x3c\x2f\x66\x6f\x6e\x74\x3e\x29\x49\x3c\x73\x75\x62\x3e\x6d\x6f\x64\x65\x6c\x3c\x2f\x73\x75\x62\x3e\x28\x51\x3c\x73\x75\x62\x3e\x30\x3c\x2f\x73\x75\x62\x3e\x29\x64\x51\x3c\x73\x75\x62\x3e\x30\x3c\x2f\x73\x75\x62\x3e\xd\xa\x3c\x62\x72\x3e\x3c\x62\x72\x3e\xd\xa\x3c\x2f\x70\x3e" ) );
    buttonGroupReso->setTitle( QString::null );
    textLabelResoCol->setText( tr( "Colimation:" ) );
    textLabelResoDet->setText( tr( "Detector:" ) );
    textLabelResoPixelSize->setText( tr( "Pixel Size:" ) );
    textLabelResoLambda->setText( trUtf8( "\xce\xbb" ) );
    textLabelResoDeltaLambda->setText( trUtf8( "\xce\x94\xce\xbb\x2f\xce\xbb" ) );
    textLabelResoFocus->setText( tr( "focus" ) );
    textLabelResoSamAper2->setText( tr( "[mm]" ) );
    textLabelResoColAper2->setText( tr( "[mm]" ) );
    lineEditResoSamAper->setText( tr( "10" ) );
    textLabel3->setText( tr( "x" ) );
    lineEditResoSamAper2->setText( tr( "10" ) );
    lineEditResoColAper->setText( tr( "30" ) );
    textLabel3_2->setText( tr( "x" ) );
    lineEditResoColAper2->setText( tr( "30" ) );
    lineEditResoLambda->setText( tr( "7" ) );
    lineEditResoDeltaLambda->setText( tr( "0.2" ) );
    lineEditResoFocus->setText( tr( "1000" ) );
    lineEditResoCol->setText( tr( "2000" ) );
    lineEditResoDet->setText( tr( "2000" ) );
    lineEditResoPixelSize->setText( tr( "0.525" ) );
    textLabelResoLambda2->setText( trUtf8( "\x5b\xc3\x85\x5d" ) );
    textLabelResoDeltaLambda2->setText( tr( "[1]" ) );
    textLabelResoFocus2->setText( tr( "[cm]" ) );
    textLabelResoSamAper->setText( tr( "S. Apert.:" ) );
    QWhatsThis::add( textLabelResoSamAper, tr( "Sample Aperture" ) );
    textLabelResoColAper->setText( tr( "C. Apert.:" ) );
    QWhatsThis::add( textLabelResoColAper, tr( "Collimation Aperture" ) );
    textLabelResoCol2->setText( tr( "[cm]" ) );
    textLabelResoDet2->setText( tr( "[cm]" ) );
    textLabelResoPixelSize2->setText( tr( "[cm]" ) );
    checkBoxLenses->setText( tr( "Lenses?" ) );
    pushButtonKWS1->setText( tr( "KWS1" ) );
    pushButtonKWS2->setText( tr( "KWS2" ) );
    pushButtonCANSAS->setText( tr( "cansas1d" ) );
    toolBoxChange->setItemLabel( toolBoxChange->indexOf(page1), tr( "Resolution Parameter" ) );
    checkBoxConvert->setText( tr( "Convert data:" ) );
    checkBoxConvert->setAccel( QKeySequence( QString::null ) );
    textLabelSASdesc->setText( tr( "<p align=\"left\">\n"
"--- If you activate this option, you will be able to convert loaded datasets from \n"
"one Small-Angle-Scattering (SAS) presentation to other.<br>\n"
"--- Available SAS-presentations:<br> \n"
"<b>QI</b> (I vs. Q), <b>Guinier</b> (ln[I] vs. Q<sup>2</sup>), <br>\n"
"<b>Zimm</b> (I<sup>-1</sup> vs. Q<sup>2</sup>),\n"
"<b>Porod</b> (log[I] vs. log[Q]), <br>\n"
"<b>Porod2</b> (IQ<sup>4</sup> vs. Q<sup>2</sup>),\n"
"<b>logQ</b> (I vs. log[Q]), <br>\n"
"<b>logI</b> (log[I] vs. Q), \n"
"<b>Debye</b> (I<sup>-1/2</sup> vs. Q<sup>2</sup>),<br>\n"
"<b>1Moment</b> (IQ vs. Q), <b>2Moment</b> (IQ<sup>2</sup> vs. Q),<br>\n"
"<b>GuinierRod</b> (ln[IQ] vs. Q<sup>2</sup>), <br>\n"
"<b>GuinierPlate</b> (ln[IQ<sup>2</sup>] vs. Q<sup>2</sup>)  \n"
"</p>" ) );
    textLabel5->setText( tr( "From" ) );
    textLabel5_3->setText( tr( "Via" ) );
    textLabel5_2->setText( tr( "To" ) );
    comboBoxSelectPresentationFrom->clear();
    comboBoxSelectPresentationFrom->insertItem( tr( "QI" ) );
    comboBoxSelectPresentationFrom->insertItem( tr( "Guinier" ) );
    comboBoxSelectPresentationFrom->insertItem( tr( "Zimm" ) );
    comboBoxSelectPresentationFrom->insertItem( tr( "Porod" ) );
    comboBoxSelectPresentationFrom->insertItem( tr( "Porod2" ) );
    comboBoxSelectPresentationFrom->insertItem( tr( "logQ" ) );
    comboBoxSelectPresentationFrom->insertItem( tr( "logI" ) );
    comboBoxSelectPresentationFrom->insertItem( tr( "Debye" ) );
    comboBoxSelectPresentationFrom->insertItem( tr( "1Moment" ) );
    comboBoxSelectPresentationFrom->insertItem( tr( "2Moment" ) );
    comboBoxSelectPresentationFrom->insertItem( tr( "GuinierRod" ) );
    comboBoxSelectPresentationFrom->insertItem( tr( "GuinierPlate" ) );
    comboBoxSelectPresentationFrom->insertItem( tr( "Kratky" ) );
    comboBoxSelectPresentationFrom->setCurrentItem( 0 );
    textLabelVia->setText( tr( "QI" ) );
    comboBoxSelectPresentationTo->clear();
    comboBoxSelectPresentationTo->insertItem( tr( "QI" ) );
    comboBoxSelectPresentationTo->insertItem( tr( "Guinier" ) );
    comboBoxSelectPresentationTo->insertItem( tr( "Zimm" ) );
    comboBoxSelectPresentationTo->insertItem( tr( "Porod" ) );
    comboBoxSelectPresentationTo->insertItem( tr( "Porod2" ) );
    comboBoxSelectPresentationTo->insertItem( tr( "logQ" ) );
    comboBoxSelectPresentationTo->insertItem( tr( "logI" ) );
    comboBoxSelectPresentationTo->insertItem( tr( "Debye" ) );
    comboBoxSelectPresentationTo->insertItem( tr( "1Moment" ) );
    comboBoxSelectPresentationTo->insertItem( tr( "2Moment" ) );
    comboBoxSelectPresentationTo->insertItem( tr( "GuinierRod" ) );
    comboBoxSelectPresentationTo->insertItem( tr( "GuinierPlate" ) );
    comboBoxSelectPresentationTo->insertItem( tr( "Kratky" ) );
    comboBoxSelectPresentationTo->setCurrentItem( 0 );
    textLabelPresFrom->setText( tr( "I vs. Q" ) );
    textLabelPresVia->setText( tr( "I vs. Q" ) );
    textLabelPresTo->setText( tr( "I vs. Q" ) );
    toolBoxChange->setItemLabel( toolBoxChange->indexOf(page2), tr( "SAS Presentation" ) );
    checkBoxRemoveRange->setText( QString::null );
    checkBoxRemoveFirst->setText( QString::null );
    checkBoxRemoveLast->setText( QString::null );
    checkBoxNoNegative->setText( QString::null );
    textLabel6_3->setText( tr( "From:" ) );
    textLabel6->setText( tr( "First:" ) );
    textLabel6_2->setText( tr( "Last:" ) );
    lineEditRemoveFrom->setText( tr( "0" ) );
    lineEditRemoveFirst->setText( tr( "0" ) );
    lineEditRemoveLast->setText( tr( "0" ) );
    textLabel6_2_2->setText( tr( "to:" ) );
    textLabel6_4->setText( tr( "lines" ) );
    textLabel6_4_2->setText( tr( "lines" ) );
    lineEditRemoveTo->setText( tr( "0" ) );
    textLabel6_4_3->setText( tr( "lines;" ) );
    textLabel1_8->setText( tr( "Remove negative points" ) );
    toolBoxChange->setItemLabel( toolBoxChange->indexOf(page), tr( "Remove \"Bad\" Points" ) );
    textLabelMath->setText( tr( "I(Q)" ) );
    textLabelPresVia_2->setText( tr( "I<sub>1</sub> ( Q ) = I ( Q )" ) );
    comboBoxMath->clear();
    comboBoxMath->insertItem( tr( "+" ) );
    comboBoxMath->insertItem( tr( "-" ) );
    comboBoxMath->insertItem( tr( "*" ) );
    comboBoxMath->insertItem( tr( "/" ) );
    comboBoxMath->setCurrentItem( 2 );
    lineEditMath->setText( tr( "1" ) );
    textLabelPresVia_2_2->setText( tr( "I<sub>2</sub> ( Q ) = I<sub>1</sub> ( Q )" ) );
    comboBoxMath2->clear();
    comboBoxMath2->insertItem( tr( "+" ) );
    comboBoxMath2->insertItem( tr( "-" ) );
    comboBoxMath2->insertItem( tr( "*" ) );
    comboBoxMath2->insertItem( tr( "/" ) );
    comboBoxMath2->setCurrentItem( 2 );
    lineEditMath2->setText( tr( "1" ) );
    textLabel1_4->setText( tr( "Result::" ) );
    checkBoxMath->setText( QString::null );
    checkBoxMath2->setText( QString::null );
    textLabel6_5->setText( tr( "* In case of SAS presentation change, \n"
"formula is applied to intermediate \n"
"(Via) datasets..." ) );
    toolBoxChange->setItemLabel( toolBoxChange->indexOf(page_2), tr( "Mathematic" ) );
    textLabelPresVia_2_3->setText( tr( "<p align=\"center\">\n"
"I<sub>1</sub> ( Q ) <br>\n"
"= <br>\n"
"I ( Q )</p>" ) );
    checkBox1DCalculator->setText( tr( "include column calculation:" ) );
    comboBoxMath1D->clear();
    comboBoxMath1D->insertItem( tr( "+" ) );
    comboBoxMath1D->insertItem( tr( "-" ) );
    comboBoxMath1D->insertItem( tr( "*" ) );
    comboBoxMath1D->insertItem( tr( "/" ) );
    comboBoxMath1D->setCurrentItem( 1 );
    toolBoxChange->setItemLabel( toolBoxChange->indexOf(Page), tr( "1D Calculator" ) );
    checkBoxBinningLinear->setText( tr( "Linear Binning (first):" ) );
    textLabelPresVia_2_4->setText( tr( "Bin every ..." ) );
    textLabelPresVia_2_4_2->setText( tr( "... points" ) );
    checkBoxBinningProgressive->setText( tr( "Progressive Binning (second):" ) );
    textLabelPresVia_2_4_3->setText( tr( "Common ratio [1.00 .. 1.99]:" ) );
    lineEditBinningProgressive->setText( tr( "1." ) );
    lineEditBinningProgressive->setInputMask( tr( "1.99; " ) );
    QWhatsThis::add( lineEditBinningProgressive, tr( "Progressive Step" ) );
    toolBoxChange->setItemLabel( toolBoxChange->indexOf(page_3), tr( "Q-Binning" ) );
    textLabelHelp->setText( tr( "<b>[1D] Import/Export/Modification | Info<br><br></b>\n"
"\n"
"In this tab one can:<br>\n"
"<b>(a)</b> import of the selected datasets from ASCII files or tables [2-4 columns] to the current project;<br>\n"
"<b>(b)</b> to proceed some actions (modifications) with imported datasets ;<br>\n"
"<b>(c)</b> to export \"imported\" (and transformed) datasets as new tables in the actual\n"
"project, or to save as ASCII files.<br> <br>\n"
"Just activate \"<b>Modify</b>\" check box to be able to apply actions like:<br>\n"
"<b>---</b> calculation of the half-width of the resolution function;<br>\n"
"<b>---</b> convertation of datasets to other SAS presentation;<br>\n"
"<b>---</b> delete some points;<br>\n"
"<b>---</b> appliy some simple mathematic actions;<br><br>\n"
"\n"
"If you do not want to overwrite existed tables (files) just check \n"
"\"<b>Indexing</b>\" checkbox.<br><br>\n"
"\n"
"To form name of new table or file you could use a \n"
"number in the old file(table) name. Just select # of position in combobox...\n"
"<br><br>\n"
"And believe to your logic:)" ) );
    sansTab->changeTab( tab, tr( "ASCII.1D " ) );
    buttonGroupFileNumbers->setTitle( tr( "Range | Control" ) );
    textLabel4_4->setText( tr( "Prefix:" ) );
    textLabel4_2->setText( tr( "To:" ) );
    textLabel4_2_2->setText( tr( "Step:" ) );
    textLabel4_2_2_2->setText( tr( "Suffix:" ) );
    lineEditFileLast->setText( tr( "2011" ) );
    lineEditFileStep->setText( tr( "1" ) );
    lineEditFileSuffix->setText( tr( "-HF" ) );
    lineEditFileFirst->setText( tr( "2001", "xxxx" ) );
    textLabel4->setText( tr( "From:" ) );
    comboBoxSelectPresentationPlot->clear();
    comboBoxSelectPresentationPlot->insertItem( tr( "QI" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "Guinier" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "Zimm" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "Porod" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "Porod2" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "logQ" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "logI" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "Debye" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "1Moment" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "2Moment" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "GuinierRod" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "GuinierPlate" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "NSE" ) );
    comboBoxSelectPresentationPlot->insertItem( tr( "Kratky" ) );
    comboBoxSelectPresentationPlot->setCurrentItem( 0 );
    buttonGroupDanp->setTitle( tr( "Plot | Remove | Curves" ) );
    pushButtonplotRange->setText( tr( "Plot Range!" ) );
    pushButtonCLEAR->setText( tr( "Remove Range!" ) );
    checkBoxXerror->setText( tr( "x-Error (Sigma)" ) );
    checkBoxYerror->setText( tr( "y-Error" ) );
    buttonGroup35->setTitle( tr( "Plot | Control" ) );
    pushButtonPlotTitels->setText( tr( "Label Graph" ) );
    pushButtonLinLin->setText( tr( "Lin-Lin" ) );
    pushButtonLogLog->setText( tr( "Log-Log" ) );
    buttonGroupLogLog->setTitle( tr( "log-log range" ) );
    spinBoxLogMaxX->setPrefix( tr( "10^(" ) );
    spinBoxLogMaxX->setSuffix( tr( ")" ) );
    textLabel4_4_2->setText( tr( "x:" ) );
    spinBoxLogMinX->setPrefix( tr( "10^(" ) );
    spinBoxLogMinX->setSuffix( tr( ")" ) );
    spinBoxLogMinY->setPrefix( tr( "10^(" ) );
    spinBoxLogMinY->setSuffix( tr( ")" ) );
    textLabel4_4_3->setText( tr( "y:" ) );
    spinBoxLogMaxY->setPrefix( tr( "10^(" ) );
    spinBoxLogMaxY->setSuffix( tr( ")" ) );
    buttonGroup42->setTitle( tr( "Plot/Remove Curves | Wild Card | Filter" ) );
    radioButtonPlotCurveNames->setText( tr( "Curve Name" ) );
    radioButtonPlotTableNames->setText( tr( "Table Name" ) );
    radioButtonPlotCurveLabels->setText( tr( "Curve Label" ) );
    radioButtonPlotTableLabels->setText( tr( "Table Label" ) );
    lineEditPlotFilter->setText( tr( "*filter*" ) );
    pushButtonPlotByFilter->setText( tr( "Plot Curves" ) );
    pushButtonRemoveByFilter->setText( tr( "Remove Curves" ) );
    pushButtonAddLegend->setText( tr( "Add new Legend" ) );
    buttonGroup71->setTitle( tr( "Color Schema | Symbols Sequence  " ) );
    comboBoxSchemaAim->clear();
    comboBoxSchemaAim->insertItem( tr( "symbols" ) );
    comboBoxSchemaAim->insertItem( tr( "lines" ) );
    comboBoxSchemaAim->insertItem( tr( "symbols+lines" ) );
    comboBoxSchemaAim->insertItem( tr( "error-bars" ) );
    pushButtonColorSchemaAccept->setText( QString::null );
    pushButtonEditColorSchema->setText( QString::null );
    pushButtonsaveCurrentSaveColorSchema->setText( QString::null );
    pushButtonDeleteColorSchema->setText( QString::null );
    buttonGroup68->setTitle( tr( "Move Data-Point in active Graph" ) );
    comboBoxMovePointXorY->clear();
    comboBoxMovePointXorY->insertItem( tr( "X" ) );
    comboBoxMovePointXorY->insertItem( tr( "Y" ) );
    comboBoxMovePointXorY->setCurrentItem( 1 );
    comboBoxMovePointLevel->clear();
    comboBoxMovePointLevel->insertItem( tr( "10%" ) );
    comboBoxMovePointLevel->insertItem( tr( "1%" ) );
    comboBoxMovePointLevel->insertItem( tr( "0.1%" ) );
    comboBoxMovePointLevel->insertItem( tr( "0.01%" ) );
    comboBoxMovePointLevel->setCurrentItem( 1 );
    pushButtonMovePointPlus->setText( tr( "+" ) );
    pushButtonMovePointMinus->setText( tr( "-" ) );
    sansTab->changeTab( tab_2, tr( "Plot.1D" ) );
    groupBox28->setTitle( QString::null );
    spinBoxOverlap->setSuffix( tr( "%" ) );
    textLabel1_5->setText( tr( "Number of tables for merging" ) );
    textLabel1_5_2->setText( tr( "Number of table-sets for merging" ) );
    textLabel1->setText( tr( "Overlap control" ) );
    textLabel1_5_3_2->setText( tr( "Reference column [Smart Merging]" ) );
    textLabel1_5_3->setText( tr( "Filter (Wild Card)" ) );
    lineEditFilter->setText( tr( "*" ) );
    checkBoxSmart->setText( tr( "Smart merging" ) );
    comboBoxSmartSelect->clear();
    comboBoxSmartSelect->insertItem( tr( "Const" ) );
    comboBoxSmartSelect->insertItem( tr( "pow(x,1)" ) );
    comboBoxSmartSelect->insertItem( tr( "pow(x,2)" ) );
    comboBoxSmartSelect->insertItem( tr( "pow(x,3)" ) );
    comboBoxSmartSelect->insertItem( tr( "pow(x,4)" ) );
    checkBoxMergeIndexing->setText( tr( "Indexing [Output]" ) );
    tableMerge->horizontalHeader()->setLabel( 0, tr( "New Name" ) );
    pushButtonDefineMergeFromTable->setText( tr( "Read from active Table" ) );
    pushButtonSaveMergeDataToTable->setText( tr( "Save as a new Table" ) );
    pushButtonMerge->setText( tr( "Merge" ) );
    checkBoxMergeAscii->setText( tr( "save as ascii ..." ) );
    sansTab->changeTab( TabPage_2, tr( "Merge.1D" ) );
    buttonGroup38->setTitle( tr( "File Type" ) );
    comboBoxInstrument->clear();
    comboBoxInstrument->insertItem( tr( "KWS1&2" ) );
    comboBoxInstrument->insertItem( tr( "Small Detector" ) );
    comboBoxInstrument->insertItem( tr( "Other || Save" ) );
    pushButtonsaveCurrentSave2Dtype->setText( QString::null );
    pushButtonDeleteCurrentSave2Dtype->setText( QString::null );
    buttonGroup61->setTitle( tr( "ASCII File | Structure" ) );
    QToolTip::add( spinBoxLoadPos, tr( "Number of Columns" ) );
    textLabel1_3_2->setText( tr( "Numbers per Line" ) );
    QToolTip::add( spinBoxLoadSkip, tr( "Skip XXX first lines" ) );
    QWhatsThis::add( spinBoxLoadSkip, QString::null );
    textLabel1_3->setText( tr( "Lines in Header" ) );
    groupBox32->setTitle( tr( "Matrix | Structure" ) );
    textLabelLoad_3_2_2->setText( tr( "<p align=\"center\">x</p>" ) );
    textLabel1_3_2_3_2->setText( tr( "Dimension" ) );
    checkBoxTranspose->setText( tr( "X <-> Y" ) );
    checkBoxReadEnd->setText( tr( "start reading from end" ) );
    checkBoxX2mX->setText( tr( "X > -X" ) );
    checkBoxY2mY->setText( tr( "Y > -Y" ) );
    pushButtonLoadDATmatrix->setText( tr( "Read Data To Matrix" ) );
    pushButtonLoadDATmatrix->setTextLabel( QString::null );
    checkBoxFindNumberM->setText( tr( "Use Number" ) );
    toolBoxMatrixes->setItemLabel( toolBoxMatrixes->indexOf(page1_2), tr( "2D Import        >>> Matrixes from ASCII files <<<" ) );
    comboBoxSpacerExpM->clear();
    comboBoxSpacerExpM->insertItem( tr( "Tab" ) );
    comboBoxSpacerExpM->insertItem( tr( "Space" ) );
    comboBoxSpacerExpM->setCurrentItem( 1 );
    textLabel1_3_2_2->setText( tr( "Number of Columns in File" ) );
    textLabel1_2->setText( tr( "Precision (-1 -> int)" ) );
    textLabel1_2_2->setText( tr( "Spacer" ) );
    checkBoxReadEndExportM->setText( tr( "start reading from end" ) );
    QToolTip::add( spinBoxExpMatrixPos, tr( "Number of Columns" ) );
    checkBoxSens->setText( tr( "Sensitivity-Live-Display" ) );
    pushButtonMlist->setText( tr( "Matrix:" ) );
    checkBoxTransposeExport->setText( tr( "transpose x<->y" ) );
    pushButtonExportM->setText( tr( "Export" ) );
    toolBoxMatrixes->setItemLabel( toolBoxMatrixes->indexOf(page2_2), tr( "2D Export        >>> Matrixes to ASCII files <<<" ) );
    buttonGroup24->setTitle( tr( "Output Options" ) );
    radioButtonOW1->setText( tr( "overwrite Matrix-1" ) );
    radioButtonOW2->setText( tr( "overwrite Matrix-2" ) );
    radioButtonOW3->setText( tr( "create new / select Matrix-3" ) );
    buttonGroup11_2->setTitle( tr( "Action" ) );
    comboBoxActionScalar->clear();
    comboBoxActionScalar->insertItem( tr( "+" ) );
    comboBoxActionScalar->insertItem( tr( "-" ) );
    comboBoxActionScalar->insertItem( tr( "*" ) );
    comboBoxActionScalar->insertItem( tr( "/" ) );
    comboBoxActionScalar->insertItem( tr( "X <> Y" ) );
    comboBoxActionScalar->insertItem( tr( "X >> -X" ) );
    comboBoxActionScalar->insertItem( tr( "Y >> -Y" ) );
    comboBoxActionScalar->insertItem( tr( "inv(M)" ) );
    comboBoxActionScalar->setCurrentItem( 2 );
    buttonGroup14->setTitle( tr( "Scalar" ) );
    lineEditScalar->setText( tr( "1.0" ) );
    buttonGroup13_2->setTitle( tr( "Matrix-1 | Scalar" ) );
    pushButtonMCscalar->setText( tr( "=" ) );
    buttonGroup11->setTitle( tr( "Action" ) );
    comboBoxAction->clear();
    comboBoxAction->insertItem( tr( "+" ) );
    comboBoxAction->insertItem( tr( "-" ) );
    comboBoxAction->insertItem( tr( "*" ) );
    comboBoxAction->insertItem( tr( "/" ) );
    comboBoxAction->setCurrentItem( 2 );
    buttonGroup12->setTitle( tr( "Matrix-2" ) );
    comboBoxMC2->clear();
    comboBoxMC2->insertItem( tr( "select matrix" ) );
    buttonGroup13->setTitle( tr( "Matrix-1 | Matrix-2" ) );
    pushButtonMC->setText( tr( "=" ) );
    buttonGroup10->setTitle( tr( "Matrix-1" ) );
    comboBoxMC1->clear();
    comboBoxMC1->insertItem( tr( "select matrix" ) );
    toolBoxMatrixes->setItemLabel( toolBoxMatrixes->indexOf(Page_2), tr( "2D Calculator   >>> Matrix Arithmetic <<<" ) );
    checkBoxAllMatrixes->setText( tr( "All" ) );
    pushButtonMlist_2->setText( QString::null );
    buttonGroup27->setTitle( tr( "Mask :: Conditions" ) );
    lineEditValue->setText( tr( "0" ) );
    comboBoxMaskInside->clear();
    comboBoxMaskInside->insertItem( tr( "Inside" ) );
    comboBoxMaskInside->insertItem( tr( "Outside" ) );
    pushButtonSetValue->setText( QString::null );
    buttonGroupmask->setTitle( tr( "Center" ) );
    lineEditXcenter->setText( tr( "64.5" ) );
    QToolTip::add( lineEditXcenter, tr( "X-Center" ) );
    lineEditYcenter->setText( tr( "64.5" ) );
    QToolTip::add( lineEditYcenter, tr( "Y-Center" ) );
    pushButtonReadDisplay->setText( QString::null );
    buttonGroup65->setTitle( tr( "2D to 1D" ) );
    pushButtonIQ->setText( tr( "I [R]" ) );
    QToolTip::add( pushButtonIQ, tr( "Radial Averaging of selected above matrix [normalized per pixel]" ) );
    QWhatsThis::add( pushButtonIQ, tr( "Radial Averaging of selected above matrix  [normalized per pixel]" ) );
    checkBoxNormNumberPixels->setText( tr( "I= I / #pixels" ) );
    QToolTip::add( checkBoxNormNumberPixels, tr( "Normalize intensity to the number of pixels per R" ) );
    QWhatsThis::add( checkBoxNormNumberPixels, tr( "Normalize intensity to the number of pixels per R" ) );
    QToolTip::add( comboBoxMaskForRadialAv, tr( "Mask-matrix for radial averaging" ) );
    QWhatsThis::add( comboBoxMaskForRadialAv, tr( "Mask-matrix for radial averaging" ) );
    textLabel1_7_3_2_2_2->setText( tr( "R-scale" ) );
    lineEditRscale->setText( tr( "1.0" ) );
    QToolTip::add( lineEditRscale, tr( "[R]=number pixels; Q=R-scale * R; R-scale=2*pi/lambda*pixel_size/SDD " ) );
    QWhatsThis::add( lineEditRscale, tr( "[R]=number pixels; Q=R-scale * R; R-scale=2*pi/lambda*pixel_size/SDD" ) );
    textLabel1_7_3_2_2_2_2->setText( tr( "I-scale" ) );
    lineEditIscale->setText( tr( "1.0" ) );
    QToolTip::add( lineEditIscale, tr( "I-scale factor" ) );
    QWhatsThis::add( lineEditIscale, tr( "I-scale factor" ) );
    buttonGroup39->setTitle( tr( "Mask :: Rectangle" ) );
    textLabel1_7_3->setText( tr( "Width" ) );
    lineEditXsize->setText( tr( "10" ) );
    lineEditXsize->setInputMask( QString::null );
    QToolTip::add( lineEditXsize, tr( "X-Size" ) );
    textLabel1_7_4->setText( tr( "Hight" ) );
    lineEditYsize->setText( tr( "10.0" ) );
    lineEditYsize->setInputMask( QString::null );
    QToolTip::add( lineEditYsize, tr( "Y-Size" ) );
    pushButtonSquared->setText( QString::null );
    buttonGroup40->setTitle( tr( "Mask :: Ellipse" ) );
    textLabel1_7_3_2->setText( tr( "Width" ) );
    lineEditRx->setText( tr( "10.0" ) );
    lineEditRx->setInputMask( QString::null );
    QToolTip::add( lineEditRx, tr( "X axis of Ellipse" ) );
    textLabel1_7_3_3->setText( tr( "Hight" ) );
    lineEditRy->setText( tr( "10.0" ) );
    lineEditRy->setInputMask( QString::null );
    QToolTip::add( lineEditRy, tr( "Y axis of Elipse" ) );
    pushButtonElips->setText( QString::null );
    buttonGroup39_2_2->setTitle( tr( "Mask :: Ellipse :: Shell" ) );
    textLabel1_7_3_2_2->setText( tr( "Ellipse's shell thickness" ) );
    lineEditEllShell->setText( tr( "10.0" ) );
    lineEditEllShell->setInputMask( QString::null );
    QToolTip::add( lineEditEllShell, tr( "Shell thickness " ) );
    pushButtonEllShell->setText( QString::null );
    buttonGroupMaskSector->setTitle( trUtf8( "\x4d\x61\x73\x6b\x20\x3a\x3a\x20\x53\x65\x63\x74\x6f\x72\x20\x3a\x3a\x20\xcf\x86" ) );
    textLabel1_7->setText( tr( "from" ) );
    spinBoxAngleFrom->setSuffix( trUtf8( "\x20\xc2\xb0" ) );
    QToolTip::add( spinBoxAngleFrom, tr( "from" ) );
    textLabel1_7_2->setText( tr( "to" ) );
    spinBoxAngleTo->setSuffix( trUtf8( "\x20\xc2\xb0" ) );
    QToolTip::add( spinBoxAngleTo, tr( "to" ) );
    pushButtonMaskSector->setText( QString::null );
    pushButtonBackToDAN->setText( QString::null );
    toolBoxMatrixes->setItemLabel( toolBoxMatrixes->indexOf(page_4), tr( "2D Masking     >>> Geomertical Masking <<<" ) );
    sansTab->changeTab( TabPage_3, tr( "ASCII.2D" ) );
    buttonGroup10_2->setTitle( tr( "[2D] Select Matrix in Plot" ) );
    comboBoxActiveMatrix->clear();
    comboBoxActiveMatrix->insertItem( tr( "select matrix" ) );
    QToolTip::add( comboBoxActiveMatrix, tr( "... update matrix in active graph ..." ) );
    QWhatsThis::add( comboBoxActiveMatrix, tr( "... update matrix in active graph ..." ) );
    textLabelMatrix->setText( tr( "... matrix label ..." ) );
    QToolTip::add( textLabelMatrix, tr( "... label of current matrix ... " ) );
    QWhatsThis::add( textLabelMatrix, tr( "... label of current matrix ... " ) );
    checkBoxShowInTitle->setText( tr( "Show in Graph" ) );
    QToolTip::add( checkBoxShowInTitle, tr( "... show label of current matrix in active graph ... " ) );
    QWhatsThis::add( checkBoxShowInTitle, tr( "... show label of current matrix in active graph ... " ) );
    buttonGroup28->setTitle( tr( "[2D] Color Schema" ) );
    comboBoxSchema->clear();
    comboBoxSchema->insertItem( tr( "Standart" ) );
    QToolTip::add( comboBoxSchema, tr( "Color Schema" ) );
    QWhatsThis::add( comboBoxSchema, tr( "Color Schema" ) );
    pushButtonEdit2dColorSchemaAccept->setText( QString::null );
    pushButtonEdit2dColorSchemaAccept->setTextLabel( QString::null );
    pushButtonEditColorSchema2D->setText( QString::null );
    pushButtonEditColorSchema2D->setTextLabel( QString::null );
    pushButtonSaveCurrentColorSchema2d->setText( QString::null );
    pushButtonSaveCurrentColorSchema2d->setTextLabel( QString::null );
    pushButtonDeleteColorSchema2D->setText( QString::null );
    pushButtonDeleteColorSchema2D->setTextLabel( QString::null );
    buttonGroup76->setTitle( tr( "[2D] Color Scaling" ) );
    radioButton2DplotRelative->setText( tr( "\"Relative\"" ) );
    textLabel2_2_2->setText( tr( "[Min] 0 <=" ) );
    lineEditMin->setText( tr( "0" ) );
    lineEditMax->setText( tr( "1" ) );
    textLabel2_2->setText( tr( "<" ) );
    textLabel2_2_2_2->setText( tr( "<= 1 [Max]" ) );
    checkBoxLog->setText( tr( "Log-Scale" ) );
    textLabel2_2_2_4->setText( tr( "[Min] _ <=" ) );
    textLabel2_2_2_2_2->setText( tr( "<= _ [Max]" ) );
    lineEditMaxAbs->setText( tr( "95" ) );
    radioButton2DplotAbsolute->setText( tr( "\"Absolute\"" ) );
    lineEditMinAbs->setText( tr( "0" ) );
    textLabel2_2_4->setText( tr( "<" ) );
    groupBox23_2->setTitle( tr( "[2D] XYZ to Matrix" ) );
    textLabel2_2_2_3->setText( tr( "X-step" ) );
    lineEditStepX->setText( tr( "1" ) );
    textLabel2_2_3->setText( tr( "Y-step" ) );
    lineEditStepY->setText( tr( "1" ) );
    pushButtonEditXYZtomatrix->setText( QString::null );
    pushButtonEditXYZtomatrix->setTextLabel( QString::null );
    groupBox23_2_2->setTitle( tr( "[2D] N-tables to Waterfall-Matrix" ) );
    textLabel2_2_2_3_2->setText( tr( "From" ) );
    lineWaterfalFrom->setText( tr( "1" ) );
    textLabel2_2_3_2->setText( tr( "to" ) );
    lineWaterfalTo->setText( tr( "1" ) );
    pushButtonWaterfall->setText( QString::null );
    pushButtonWaterfall->setTextLabel( QString::null );
    toolBox8->setItemLabel( toolBox8->indexOf(page1_3), tr( "Color | Control" ) );
    buttonGrouprescaleQ->setTitle( QString::null );
    textLabelResoPixelSize2_2->setText( tr( "[cm]" ) );
    textLabelResoDet2_2->setText( tr( "[cm]" ) );
    textLabelResoDeltaLambda2_2->setText( tr( "[1]" ) );
    textLabelResoDeltaLambda2_2_2->setText( tr( "[1]" ) );
    textLabelResoPixelSize_2->setText( tr( "Pixel Size:" ) );
    textLabelResoDet_2->setText( tr( "Detector:" ) );
    textLabelResoDeltaLambda_2->setText( tr( "X-center:" ) );
    textLabelResoDeltaLambda_2_2->setText( tr( "Y-center:" ) );
    textLabelResoLambda2_2->setText( trUtf8( "\x5b\xc3\x85\x5d" ) );
    textLabelResoLambda_2->setText( trUtf8( "\xce\xbb\x3a" ) );
    lineEditResoLambdaRescale->setText( tr( "7" ) );
    lineEditResoPixelSizeRescale->setText( tr( "0.525" ) );
    lineEditDetRescale->setText( tr( "2000" ) );
    lineEditResoDeltaXcenter->setText( tr( "64.5" ) );
    lineEditResoDeltaYcenter->setText( tr( "64.5" ) );
    pushButtonRescale->setText( tr( "Rescale \n"
"2D plot" ) );
    textLabel1_9->setText( trUtf8( "\x51\x78\x3d\x32\xcf\x80\x2f\xce\xbb\x20\x28\x58\x2d\x58\x63\x65\x6e\x74\x65\x72\x29\x2a\x50\x69\x78\x65\x6c\x2f\x44\x65\x74\x65\x63\x74\x6f\x72\xd\xa\x51\x79\x3d\x32\xcf\x80\x2f\xce\xbb\x20\x28\x59\x2d\x59\x63\x65\x6e\x74\x65\x72\x29\x2a\x50\x69\x78\x65\x6c\x2f\x44\x65\x74\x65\x63\x74\x6f\x72" ) );
    toolBox8->setItemLabel( toolBox8->indexOf(page2_3), tr( "Coodinates | From i-j | To to Qx-Qy [1/A] " ) );
    sansTab->changeTab( TabPage_4, tr( "Plot.2D" ) );
    groupBox15->setTitle( tr( "Header.Reader Name :: Create | Delete | Save" ) );
    comboBoxHeaderStructure->clear();
    comboBoxHeaderStructure->insertItem( tr( "KWS1&2" ) );
    pushButtonNewHeaderSTR->setText( QString::null );
    pushButtonHSTRdelete->setText( QString::null );
    pushButtonsaveCurrentHeaderSTR->setText( QString::null );
    vv->setTitle( QString::null );
    groupBoxPeriodicalHeader->setText( tr( "Pereodical Info in Header" ) );
    textLabel1_11->setText( tr( "| Offset ::" ) );
    spinBoxHeaderReaderOffset->setPrefix( QString::null );
    spinBoxHeaderReaderOffset->setSuffix( tr( " lines" ) );
    spinBoxHeaderReaderOffset->setSpecialValueText( QString::null );
    textLabel1_11_2->setText( tr( "| Periodicity ::" ) );
    spinBoxHeaderReaderPeriod->setPrefix( QString::null );
    spinBoxHeaderReaderPeriod->setSuffix( tr( " lines" ) );
    spinBoxHeaderReaderPeriod->setSpecialValueText( QString::null );
    xx->setTitle( QString::null );
    groupBoxXML->setText( tr( "XML header" ) );
    textLabel1_11_3->setText( tr( "| Base  ::" ) );
    groupBoxYAML->setText( tr( "YAML header" ) );
    groupBox8->setTitle( tr( "Header Structure Parser :: free-ASCII+ | KEY+ | XML+ | YAML+" ) );
    tableHeader->horizontalHeader()->setLabel( 0, tr( "?" ) );
    tableHeader->horizontalHeader()->setLabel( 1, tr( "#-Line" ) );
    tableHeader->horizontalHeader()->setLabel( 2, tr( "#-Order" ) );
    tableHeader->horizontalHeader()->setLabel( 3, tr( "#-Symbols" ) );
    textLabelMLH->setText( tr( "Maximal Length of Header" ) );
    pushButtonHSTRitemsDel->setText( QString::null );
    pushButtonAdd->setText( QString::null );
    pushButtonHeaderReader->setText( tr( "Extract [M] Parameters from [N] Files to [N/t] Table(s), t=1..N" ) );
    buttonGroup97->setTitle( QString::null );
    radioButtonNfiles->setText( tr( "t=1 >> [N] Tables x [M] Cols" ) );
    lineEditNumberExtractor->setText( tr( "*" ) );
    radioButtonOneFile->setText( tr( "t=N >>[1] Table x [N] Rows x [M] Cols" ) );
    radioButtonNMcolumns->setText( tr( "1<t<N >>[N/t] Tables x [ txN ] Cols" ) );
    comboBoxNMcolumns->clear();
    comboBoxNMcolumns->insertItem( tr( ">> merge all Tables (t=N)" ) );
    comboBoxNMcolumns->insertItem( tr( ">> merge every t=2 tables" ) );
    comboBoxNMcolumns->insertItem( tr( ">> merge every t=3 tables" ) );
    comboBoxNMcolumns->insertItem( tr( ">> merge every t=4 tables" ) );
    comboBoxNMcolumns->insertItem( tr( ">> merge every t=5 tables" ) );
    comboBoxNMcolumns->insertItem( tr( ">> merge every t=6 tables" ) );
    comboBoxNMcolumns->insertItem( tr( ">> merge every t=7 tables" ) );
    comboBoxNMcolumns->insertItem( tr( ">> merge every t=8 tables" ) );
    comboBoxNMcolumns->insertItem( tr( ">> merge every t=9 tables" ) );
    comboBoxNMcolumns->insertItem( tr( ">> merge every t=10 tables" ) );
    textLabelCurrentHeader->setText( tr( "info-header" ) );
    sansTab->changeTab( TabPage_5, tr( "Header.Reader" ) );
    startingLineCSV->setText( QString::null );
    csvSplitter->clear();
    csvSplitter->insertItem( tr( ";" ) );
    csvSplitter->insertItem( tr( ":" ) );
    csvSplitter->insertItem( tr( "tab" ) );
    csvSplitter->insertItem( tr( "space" ) );
    textLabel1_2_2_2->setText( tr( "Splitter" ) );
    textLabel1_2_3->setText( tr( "Starting line contains..." ) );
    headerLineCSV->setText( tr( "Meas. Pts.;" ) );
    textLabel1_2_2_3->setText( tr( "Table-Header-Line contains..." ) );
    cbSkip->setText( tr( "Skip file-name in table-name" ) );
    CSVimport->setText( tr( "CSV multi-table-import" ) );
    sansTab->changeTab( TabPage_6, tr( "CSV.Reader" ) );
    textLabelInfoSAS->setText( tr( "SA(N)S :: Tools" ) );
    textLabelInfo_2_2->setText( tr( "v.16-01.08.2017" ) );
    textLabelInfo_2->setText( tr( "Vitaliy Pipich @ JCNS" ) );
    pushButtonHelp->setText( QString::null );
}

