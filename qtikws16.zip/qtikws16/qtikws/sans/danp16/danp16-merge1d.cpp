//
//  danp16-merge1d.cpp
//  
//
//  Created by Vitaliy Pipich on 02.03.17.
//
//

#include "danp16.h"

#include "../standart-functions/standartFunctions.h"

#include <qcombobox.h>
#include <qspinbox.h>
#include <qregexp.h>
#include <qwidgetlist.h>
#include <qlineedit.h>
#include <qworkspace.h>
#include <qinputdialog.h>

// +++ mergingTableChange() +++
void danp16::mergingTableChange()
{
    //--- old numbers
    int oldN=tableMerge->numCols()-1;
    int oldM=tableMerge->numRows();
    //--- new numbers
    int N=spinBoxNtoMerge->value();
    int M=spinBoxMmergingCond->value();
    //---
    spinBoxRefForMerging->setMaxValue(N);
    spinBoxRefForMerging->setMinValue(1);
    //--- not changed (no sence in principal)
    if (N==oldN && M==oldM) return;
    
    // +++ find tables +++
    int i;
    
    //---
    QWidgetList *windows = app(this)->windowsList();
    
    //--- filter for tables
    QRegExp rx(lineEditFilter->text());
    rx.setWildcard( TRUE );
    
    //--- list of filtered tables
    QStringList tableNames;
    int tables=0;
    
    //--- filtration
    for (i=0;i<(int)windows->count();i++)
    {
        if ( rx.exactMatch(windows->at(i)->name()) && windows->at(i)->isA("Table"))
        {
            tableNames<<windows->at(i)->name();
            tables++;
        }
    }
    tableNames.sort();
    //--- prepended select line
    tableNames.prepend("select"); tables++;
    
    // --- find tables ---
    tableMerge->setNumCols(1);  tableMerge->setNumCols(1+N);
    tableMerge->setNumRows(0); tableMerge->setNumRows(M);
    
    int cc;
    QStringList colsNames;
    for (cc=0;cc<N;cc++) colsNames<<"Q-Range-"+QString::number(cc+1);
    colsNames.prepend("New Table Name");
    
    //+++ Set Data-Sets List +++
    for(int nn=0; nn<N;nn++)	 for(int mm=0; mm<M;mm++)
    {
        //+++ Q or N select
        QComboTableItem *iTable = new QComboTableItem(tableMerge, QString::null );
        tableMerge->setItem(mm,nn+1, iTable);
        iTable->setStringList( tableNames);
    }
    tableMerge->setColumnLabels(colsNames);
    tableMerge->setColumnWidth(0,115);
    
}

//+++++++++++++++++++++++
bool danp16::checkTableExistance(QString tName, int &Rows, int &Cols, double &Qmin, double &Qmax )
{
    //+++ List
    QWidgetList *windows = app(this)->windowsList();
    //+++
    for (int i=0;i<(int)windows->count();i++)
    {
        if (windows->at(i)->name()==tName && windows->at(i)->isA("Table"))
        {
            Table *w=(Table*)windows->at(i);
            Cols=w->numCols();
            Rows=w->numRows();
            Qmin=w->text(0,0).toDouble();
            Qmax=Qmin;
            for (int j=1; j<Rows;j++)
            {
                if ( w->text(j,0).toDouble() < Qmin ) Qmin=w->text(j,0).toDouble();
                if ( w->text(j,0).toDouble() > Qmax ) Qmax=w->text(j,0).toDouble();
            }
            if (Cols<2 || Rows==0 || Qmin==Qmax) return false;
            else return true;
        }
    }
    return false;
}

//+++++++++++++++++++++++
bool danp16::addTable(const QString table, gsl_matrix* &data, int &N, int Rows, int overlap, int &firstPosition)
{
    //---
    QWidgetList *windows = app(this)->windowsList();
    Table *w;
    
    int i;
    //--- find table
    for (i=0;i<(int)windows->count();i++)
    {
        if ( windows->at(i)->name()==table)
        {
            w=(Table *)windows->at(i);
        }
    }
    //--- cross check
    if (w->tableCols()<2 || w->tableRows()==0) return false;
    
    int pos;
    double Q,I,dI,sigma;
    
    //--- number filter
    QRegExp rx("((\\-|\\+)?(\\d*)?(\\.|\\,)?\\d*((e|E)(\\-|\\+)\\d*)?)");
    
    int NN=N-1;
    bool first=true;
    if (NN>0) first=false;
    
    double Qmax,Qmin,middle,diff;
    
    if (!first && overlap<100)
    {
        Qmax=gsl_matrix_get(data,N-1,0);
        Qmin=w->text(0,0).toDouble();
        middle=0.5*(Qmax+Qmin);
        diff=fabs(Qmax-Qmin);
        
        while ( NN>0 && gsl_matrix_get(data,NN,0) > middle+diff/2*overlap/100 ) { gsl_matrix_set(data,NN,0,-99.99); NN--;};
    }
    
    //++++
    firstPosition=N;
    
    //+++
    for (i=0;i<Rows;i++)
    {
        pos=0;
        if ( rx.search(w->text(i,0),pos)>-1  && (first || overlap==100 || w->text(i,0).toDouble() > (middle-diff/2*overlap/100) ) ) Q=rx.cap( 1 ).toDouble(); else Q=-99.99;
        pos=0;
        if ( rx.search(w->text(i,1),pos)>-1 ) I=rx.cap( 1 ).toDouble(); else I=-99.99;
        pos=0;
        if ( w->tableCols() > 2 && rx.search(w->text(i,2),pos)>-1 ) dI=rx.cap( 1 ).toDouble(); else dI=-99.99;
        pos=0;
        if ( w->tableCols() > 3 && rx.search(w->text(i,3),pos)>-1 ) sigma=rx.cap( 1 ).toDouble(); else sigma=-99.99;
        
        if (Q!=-99.99 && I!=-99.99)
        {
            gsl_matrix_set(data,N,0,Q);
            gsl_matrix_set(data,N,1,I);
            gsl_matrix_set(data,N,2,dI);
            gsl_matrix_set(data,N,3,sigma);
            N++;
        }
    }
    
    return true;
}

//+++
void danp16::saveMergedMatrix(QString name, QString labelList,gsl_matrix* data, int N, bool loadReso)
{
    
    if (checkBoxMergeAscii->isChecked()) return saveMergedMatrixAscii(name, data, N, loadReso);
    
    QString label="Merged Tables >> "+labelList;
    
    int i;
    
    bool newTableOutput=false;
    //+++ create table
    Table* w;
    
    if (checkBoxMergeIndexing->isChecked() || !checkTableExistence(name,w) )
    {
        if (loadReso)
        {
            w=app(this)->newHiddenTable(name,label, 0 ,4);
            w->setColName(3,"Sigma");
            w->setColPlotDesignation(3,Table::xErr);
        }
        else w=app(this)->newHiddenTable(name,label, 0 ,3);
    }
    else
    {
        w->setNumRows(0);
        if (w->numCols()<4 && loadReso) w->setNumCols(4);
        if (w->numCols()<3 && !loadReso) w->setNumCols(3);
    }
    
    w->setColName(0,"Q");
    w->setColName(1,"I");
    w->setColName(2,"dI");
    
    w->setColPlotDesignation(0,Table::X);
    w->setColPlotDesignation(1,Table::Y);
    w->setColPlotDesignation(2,Table::yErr);
    
    w->setHeaderColType();
    
    w->setNumericFormat(2, 8, true);
    
    app(this)->updateWindowLists(w);
    
    int currentRow=0;
    
    for (i=0; i<N;i++)  if (gsl_matrix_get(data, i,0) != -99.99)
    {
        w->setNumRows(currentRow+1);
        //
        w->setText(currentRow,0, QString::number(gsl_matrix_get(data,i,0),'E'));
        //
        w->setText(currentRow,1, QString::number(gsl_matrix_get(data,i,1),'E'));
        //
        if (gsl_matrix_get(data, i,2) == -99.99) w->setText(currentRow,2, "---");
        else w->setText(currentRow,2, QString::number(gsl_matrix_get(data,i,2),'E'));
        //
        if (loadReso)
        {
            if (gsl_matrix_get(data, i,3) == -99.99) w->setText(currentRow,3, "---");
            else w->setText(currentRow,3, QString::number(gsl_matrix_get(data,i,3),'E'));
        }
        currentRow++;
    };
    
    //+++ adjust cols
    for (int tt=0; tt<w->numCols(); tt++)
    {
        w->table()->adjustColumn (tt);
        w->table()->setColumnWidth(tt, w->table()->columnWidth(tt)+10);
    }
    
    w->notifyChanges();
}

void danp16::saveMergedMatrixAscii(QString name, gsl_matrix* data, int N, bool loadReso)
{
    name="QI-MERGED-"+name+".DAT";
    
    QFile f( lineEditPathOut->text()+"/"+name);
    
    if ( !f.open( IO_WriteOnly ) ) return;

    QTextStream stream( &f );
        
    for (int i=0; i<N;i++)  if (gsl_matrix_get(data, i,0) != -99.99)
    {
            stream<<QString::number(gsl_matrix_get(data,i,0),'E');
            //
            stream<<"   "+QString::number(gsl_matrix_get(data,i,1),'E');
            //
            if (gsl_matrix_get(data, i,2) == -99.99) stream<<"   ---";
            else stream<<"   "+QString::number(gsl_matrix_get(data,i,2),'E');

            //
            if (loadReso)
            {
                if (gsl_matrix_get(data, i,3) == -99.99) stream<<"   ---";
                else stream<<"   "+QString::number(gsl_matrix_get(data,i,3),'E');
            }
        
            stream<<"\n";
        }
        f.close();

}



//+++++++++++++++++++++++
void danp16::mergeMethod()
{
    
    app(this)->changeFolder("DANP :: Merge.1D");
    
    gsl_set_error_handler_off();
    int M=spinBoxNtoMerge->value();
    int N=spinBoxMmergingCond->value();
    
    if (M<2 || N<1)
    {
        QMessageBox::warning(this,tr("QtiKWS::uniSAS"),
                             tr("<h4>There are nothing to do...</h4>"));
        return;
    }
    
    QString nameMerged;
    
    int NN;
    int mm;
    int Cols, Rows;
    double  Qmin, Qmax;
    QString tName;
    
    QValueList<double> QminList;
    QValueList<double> QmaxList;
    QValueList<int> rowsList;
    QValueList<int> colsList;
    QValueList<int> positions;
    QValueList<int> order;
    
    
    bool checkSelection=false;
    
    for(int nn=0; nn<N;nn++)
    {
        if (tableMerge->isRowSelected(nn,TRUE))
        {
            checkSelection=TRUE;
            break;
        }
    }
    
    
    for(int nn=0; nn<N;nn++)
    {
        if (checkSelection && !tableMerge->isRowSelected(nn,TRUE)) continue;
        
        if (tableMerge->text(nn,0)=="") nameMerged="merged-"+QString::number(nn+1);
        else nameMerged=tableMerge->text(nn,0);
        
        if (checkBoxMergeIndexing->isChecked())
        {
            nameMerged+="-v-";
            nameMerged=app(this)->generateUniqueName(nameMerged);
        }
        //++++++++++++++++++++++++++++++++++++
        QminList.clear();
        QmaxList.clear();
        rowsList.clear();
        colsList.clear();
        positions.clear();
        order.clear();
        
        int Nall=0;
        int usedTablesNumber=0;
        int k;
        //+++
        for(mm=0; mm<M;mm++)
        {
            tName=tableMerge->text(nn, mm+1);
            //+++
            Rows=0;
            Cols=0;
            Qmin=0;
            Qmax=0;
            //+++
            if (checkTableExistance(tName, Rows, Cols, Qmin, Qmax ) )
            {
                Nall+=Rows;
                int pos=usedTablesNumber;
                
                for (k=0; k < usedTablesNumber; k++ ) if  (Qmin < QminList[k] ) {pos--; order[k]=order[k]+1;};
                //+++
                order<<pos;
                positions<<mm;
                QminList<<Qmin;
                QmaxList<<Qmax;
                rowsList<<Rows;
                colsList<<Cols;
                //
                usedTablesNumber++;
            }
        }
        
        //+++
        gsl_matrix* data=gsl_matrix_alloc(Nall,4);
        
        //+++
        NN=0;
        bool loadReso=true;
        QString labelList;
        int overlap=spinBoxOverlap->value();
        int firstPoint, firstPointFromList=0;
        firstPoint=1;
        //+++
        QValueList<int> firstPointS;
        //+++
        for (k=0; k < usedTablesNumber; k++ )
        {
            int currentPos=order.findIndex(k);
            addTable(tableMerge->text(nn, positions[currentPos]+1), data, NN, rowsList[currentPos],overlap, firstPoint);
            
            firstPointS<<firstPoint;
            //+++ Reference Set Check
            if (positions[currentPos]+1==spinBoxRefForMerging->value()) firstPointFromList=k;
            //+++
            labelList+=tableMerge->text(nn, positions[currentPos]+1)+", ";
            if (colsList[currentPos]<4) loadReso=false;
        }
        
        
        
        
        //___________ Smart merging ________________________
        if (checkBoxSmart->isChecked())
        {
            int qExponent=comboBoxSmartSelect->currentItem();
            
            //+++ left sets from reference adjasting...
            for (k=firstPointFromList-1; k>=0;k--)
            {
                //--- finding of minimum of dataset [k+1] "reference"
                int QminInt=firstPointS[k+1];
                double QminRef=gsl_matrix_get(data,QminInt,0);
                
                //--- finding of maximum of dataset [k] left from reference
                int QmaxInt=firstPointS[k+1]-1;
                double QmaxRef=gsl_matrix_get(data,QmaxInt,0);
                while (QmaxRef==-99.99) { QmaxInt--; QmaxRef=gsl_matrix_get(data,QmaxInt,0);};
                
                //--- overlap range
                double currentOverlap=QmaxRef-QminRef;
                
                if (currentOverlap>0)
                {
                    //--- mean value of left dataset in overlap range
                    double leftLevel=0;
                    int numLeftLevel=0;
                    double Q;
                    while (gsl_matrix_get(data,QmaxInt,0)>=QminRef || gsl_matrix_get(data,QmaxInt,0)==-99.99)
                    {
                        if (gsl_matrix_get(data,QmaxInt,0)!=-99.99 && gsl_matrix_get(data,QmaxInt,1)!=-99.99 )
                        {
                            Q=gsl_matrix_get(data,QmaxInt,0);
                            leftLevel+=gsl_matrix_get(data,QmaxInt,1)*pow(Q,qExponent);
                            numLeftLevel++;
                        }
                        QmaxInt--;
                    }
                    //---
                    double rightLevel=0;
                    int numRightLevel=0;
                    while (gsl_matrix_get(data,QminInt,0)<=QmaxRef || gsl_matrix_get(data,QminInt,0)==-99.99)
                    {
                        if (gsl_matrix_get(data,QminInt,0)!=-99.99 && gsl_matrix_get(data,QminInt,1)!=-99.99 )
                        {
                            Q=gsl_matrix_get(data,QmaxInt,0);
                            rightLevel+=gsl_matrix_get(data,QminInt,1)*pow(Q,qExponent);
                            numRightLevel++;
                        }
                        QminInt++;
                    }
                    
                    //+++
                    if (numRightLevel>0 && rightLevel>0 && numLeftLevel>0 && leftLevel>0)
                    {
                        double faktor=rightLevel/numRightLevel/leftLevel*numLeftLevel;
                        for (int iii=firstPointS[k]; iii<firstPointS[k+1]; iii++)
                        {
                            if (gsl_matrix_get(data,iii,0)!=-99.99 && gsl_matrix_get(data,iii,1)!=-99.99 )
                                gsl_matrix_set(data,iii,1, gsl_matrix_get(data,iii,1)*faktor);
                        }
                    }
                    else break;
                }
                else break;
            }
            
            
            
            //+++ right sets from reference adjasting...
            for (k=firstPointFromList+1; k < usedTablesNumber;k++)
            {
                //--- finding of minimum of dataset [k] right from reference
                int QminInt=firstPointS[k];
                double QminRef=gsl_matrix_get(data,QminInt,0);
                
                //--- finding of maximum of dataset [k-1] of "reference"
                int QmaxInt=firstPointS[k]-1;
                double QmaxRef=gsl_matrix_get(data,QmaxInt,0);
                while (QmaxRef==-99.99) { QmaxInt--; QmaxRef=gsl_matrix_get(data,QmaxInt,0);};
                
                //--- overlap range
                double currentOverlap=QmaxRef-QminRef;
                
                
                if (currentOverlap>0)
                {
                    //--- mean value of left dataset in overlap range
                    double leftLevel=0;
                    int numLeftLevel=0;
                    while (gsl_matrix_get(data,QmaxInt,0)>=QminRef || gsl_matrix_get(data,QmaxInt,0)==-99.99)
                    {
                        if (gsl_matrix_get(data,QmaxInt,0)!=-99.99 && gsl_matrix_get(data,QmaxInt,1)!=-99.99 )
                        {
                            leftLevel+=gsl_matrix_get(data,QmaxInt,1);
                            numLeftLevel++;
                        }
                        QmaxInt--;
                    }
                    //---
                    double rightLevel=0;
                    int numRightLevel=0;
                    while (gsl_matrix_get(data,QminInt,0)<=QmaxRef || gsl_matrix_get(data,QminInt,0)==-99.99)
                    {
                        if (gsl_matrix_get(data,QminInt,0)!=-99.99 && gsl_matrix_get(data,QminInt,1)!=-99.99 )
                        {
                            rightLevel+=gsl_matrix_get(data,QminInt,1);
                            numRightLevel++;
                        }
                        QminInt++;
                    }
                    
                    //+++
                    if (numRightLevel>0 && rightLevel>0 && numLeftLevel>0 && leftLevel>0)
                    {
                        double faktor=leftLevel/numLeftLevel/rightLevel*numRightLevel;
                        
                        int lastPoint;
                        if (k+1==usedTablesNumber) lastPoint=NN; else lastPoint=firstPointS[k+1];
                        for (int iii=firstPointS[k]; iii<lastPoint; iii++)
                        {
                            if (gsl_matrix_get(data,iii,0)!=-99.99 && gsl_matrix_get(data,iii,1)!=-99.99 ) 
                                gsl_matrix_set(data,iii,1, gsl_matrix_get(data,iii,1)*faktor);	
                        }
                    }
                    else break;
                }	
                else break;
            }
        }
        //+++
        saveMergedMatrix(nameMerged, labelList, data, NN, loadReso);	
        gsl_matrix_free(data);
    }
    
    app(this)->changeFolder("DANP :: Merge.1D");
}
//+++++++++++++++++++++++
void danp16::saveMergeInfo()
{
    int nn,mm;
    bool ok;
    QString tableName = QInputDialog::getText(
                                              "Save information from merging interface as a new Table ", "Enter name of a new Table",
                                              QLineEdit::Normal,
                                              QString::null, &ok, this );
    if ( !ok ||  tableName.isEmpty() )
    {
        return;
    }
    
    int N=spinBoxNtoMerge->value();
    int M=spinBoxMmergingCond->value();
    
    tableName=app(this)->generateUniqueName(tableName);
    
    Table *t=app(this)->newTable(tableName,M,N+1);
    
    QStringList colType;
    //+++ Cols Names
    t->setColName(0,"NewName"); t->setColPlotDesignation(0,Table::None); colType<<"1";
    for(nn=0; nn<N;nn++)
    {
        t->setColName(nn+1,"Q-Range-"+QString::number(nn+1));t->setColPlotDesignation(nn+1,Table::None);colType<<"1";
    }
    
    t->setColumnTypes(colType);	
    
    for(nn=0; nn<(N+1);nn++) for(mm=0; mm<M;mm++)		
    {
        t->setText(mm,nn,tableMerge->text(mm,nn));
    }
    //+++
    t->setWindowLabel("Merge::Table");
    app(this)->setListViewLabel(t->name(), "Merge::Table");
    app(this)->updateWindowLists(t);
    
    for (int tt=0; tt<t->numCols(); tt++)
    {
        t->table()->adjustColumn (tt);
        t->table()->setColumnWidth(tt, t->table()->columnWidth(tt)+10); 
    }
}

//+++++++++++++++++++++++
void danp16::readMergeInfo()
{
    int mm,nn;
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("Table")) return;
    
    Table* t = (Table*)app(this)->ws->activeWindow();
    
    int N=t->numCols()-1;
    spinBoxNtoMerge->setValue(0);
    spinBoxNtoMerge->setValue(N);
    int M=t->numRows();
    spinBoxMmergingCond->setValue(0);
    spinBoxMmergingCond->setValue(M);
    
    //+++ Set Data-Sets List +++
    for(nn=0; nn<N;nn++) for(mm=0; mm<M;mm++)		
    {
        //+++ Q or N select
        QComboTableItem *iTable =(QComboTableItem*)tableMerge->item (mm,nn+1);
        iTable->setCurrentItem(t->text(mm,nn+1));
    }
    
    QString nameQI;
    for(mm=0; mm<M;mm++)
    {
        nameQI=t->text(mm,0);
        nameQI=nameQI.simplifyWhiteSpace();
        nameQI=nameQI.replace(" ", "-").replace("/", "-").replace("_", "-").replace(",", "-").replace(".", "-").remove("%");
        tableMerge->setText(mm, 0, nameQI);
    }
}

