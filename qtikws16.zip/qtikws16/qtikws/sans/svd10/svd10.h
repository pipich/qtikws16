/****************************************************************************
** Form interface generated from reading ui file '..\qtiKWS\sans\svd10\svd10.ui'
**
** Created: Do 14. Sep 01:52:12 2017
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.4   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef SVD10_H
#define SVD10_H

#include <qvariant.h>
#include <qwidget.h>
#include <gsl/gsl_vector.h>
#include "../../../qtiKWS/src/graph.h"
#include "../../../qtiKWS/src/worksheet.h"

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QToolBox;
class QButtonGroup;
class QSpinBox;
class QLineEdit;
class QTable;
class QPushButton;
class Graph;
class Table;
class QWidgetList;

class svd10 : public QWidget
{
    Q_OBJECT

public:
    svd10( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~svd10();

    QLabel* textLabelInfo;
    QToolBox* toolBox20;
    QWidget* page1;
    QButtonGroup* buttonGroupSLDsolvent;
    QLabel* textLabelM;
    QSpinBox* spinBoxMsvd;
    QLabel* textLabelRhoH;
    QLineEdit* lineEditRhoH;
    QLabel* textLabelRhoD;
    QLineEdit* lineEditRhoD;
    QTable* tableMsvd;
    QButtonGroup* buttonGroupSLDcomponent;
    QLabel* textLabelN;
    QSpinBox* spinBoxNsvd;
    QTable* tableNsvd;
    QLineEdit* lineEditTabNameSVD;
    QPushButton* pushButtonSVD1dataTransferFrom;
    QSpinBox* spinBoxKsvd;
    QLabel* textLabel1_2_2;
    QLabel* textLabel1_2;
    QPushButton* pushButtonSVD1dataTransfer;
    QLabel* textLabelInfoSAS;
    QLabel* textLabelInfo_2_2;
    QLabel* textLabelInfo_2;

    virtual bool checkTableExistence( QString & tableName );
    virtual bool checkTableExistenceTEST( QString & tableName );

public slots:
    virtual void readSettings();
    virtual void writeSettings();
    virtual void slotReadSvdData( QString tableName );
    virtual void slotSVD1dataTransfer( QString Name, int Nsvd, QStringList TexT, gsl_matrix * SLDcomponent, int Msvd, QStringList Dcomposition, QStringList FileNames, gsl_vector * SLDsolvent, int Ksvd );
    virtual void slotTableMsvdChanged( int raw, int col );
    virtual void slotCheckRhoHD();
    virtual void slotTabNameSVDcheck();
    virtual void slotSVD1dataTransfer();
    virtual void slotTableNsvdChanged( int row, int col );
    virtual void slotReadDataFromTable();
    virtual void forceReadSettings();

protected:
    QVBoxLayout* svd10Layout;
    QVBoxLayout* page1Layout;
    QHBoxLayout* buttonGroupSLDsolventLayout;
    QSpacerItem* spacer19;
    QHBoxLayout* buttonGroupSLDcomponentLayout;
    QSpacerItem* spacer18;
    QGridLayout* layout39;
    QSpacerItem* spacer12;
    QSpacerItem* spacer12_2;
    QHBoxLayout* layout40;

protected slots:
    virtual void languageChange();

private:
    void init();
    void destroy();

};

#endif // SVD10_H
