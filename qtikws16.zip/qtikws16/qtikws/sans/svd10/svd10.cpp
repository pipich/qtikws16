/****************************************************************************
** Form implementation generated from reading ui file '../qtiKWS/sans/svd10/svd10.ui'
**
** Created: Thu Sep 14 02:31:53 2017
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "svd10.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qtoolbox.h>
#include <qbuttongroup.h>
#include <qspinbox.h>
#include <qlineedit.h>
#include <qtable.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include "svd10.ui.h"

/*
 *  Constructs a svd10 as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
svd10::svd10( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "svd10" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 0, 0 ) );
    setMaximumSize( QSize( 5100, 3000 ) );
    setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 246, 246, 246) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    setPalette( pal );
    QFont f( font() );
    setFont( f ); 
    svd10Layout = new QVBoxLayout( this, 11, 6, "svd10Layout"); 

    textLabelInfo = new QLabel( this, "textLabelInfo" );
    textLabelInfo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo->setMinimumSize( QSize( 0, 20 ) );
    textLabelInfo->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfo->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    QFont textLabelInfo_font(  textLabelInfo->font() );
    textLabelInfo->setFont( textLabelInfo_font ); 
    textLabelInfo->setFrameShape( QLabel::Box );
    textLabelInfo->setLineWidth( 1 );
    textLabelInfo->setAlignment( int( QLabel::AlignCenter ) );
    svd10Layout->addWidget( textLabelInfo );

    toolBox20 = new QToolBox( this, "toolBox20" );
    toolBox20->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, toolBox20->sizePolicy().hasHeightForWidth() ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 242, 242, 242) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 153, 153, 153) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    toolBox20->setPalette( pal );
    toolBox20->setCurrentIndex( 0 );

    page1 = new QWidget( toolBox20, "page1" );
    page1->setBackgroundMode( QWidget::PaletteBackground );
    page1Layout = new QVBoxLayout( page1, 0, 7, "page1Layout"); 

    buttonGroupSLDsolvent = new QButtonGroup( page1, "buttonGroupSLDsolvent" );
    buttonGroupSLDsolvent->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroupSLDsolvent->sizePolicy().hasHeightForWidth() ) );
    buttonGroupSLDsolvent->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 63, 75, 138) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    buttonGroupSLDsolvent->setPalette( pal );
    buttonGroupSLDsolvent->setFlat( FALSE );
    buttonGroupSLDsolvent->setColumnLayout(0, Qt::Vertical );
    buttonGroupSLDsolvent->layout()->setSpacing( 6 );
    buttonGroupSLDsolvent->layout()->setMargin( 11 );
    buttonGroupSLDsolventLayout = new QHBoxLayout( buttonGroupSLDsolvent->layout() );
    buttonGroupSLDsolventLayout->setAlignment( Qt::AlignTop );

    textLabelM = new QLabel( buttonGroupSLDsolvent, "textLabelM" );
    textLabelM->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabelM->sizePolicy().hasHeightForWidth() ) );
    buttonGroupSLDsolventLayout->addWidget( textLabelM );

    spinBoxMsvd = new QSpinBox( buttonGroupSLDsolvent, "spinBoxMsvd" );
    spinBoxMsvd->setMaxValue( 20 );
    spinBoxMsvd->setMinValue( 2 );
    spinBoxMsvd->setValue( 2 );
    buttonGroupSLDsolventLayout->addWidget( spinBoxMsvd );

    textLabelRhoH = new QLabel( buttonGroupSLDsolvent, "textLabelRhoH" );
    textLabelRhoH->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabelRhoH->sizePolicy().hasHeightForWidth() ) );
    buttonGroupSLDsolventLayout->addWidget( textLabelRhoH );

    lineEditRhoH = new QLineEdit( buttonGroupSLDsolvent, "lineEditRhoH" );
    buttonGroupSLDsolventLayout->addWidget( lineEditRhoH );

    textLabelRhoD = new QLabel( buttonGroupSLDsolvent, "textLabelRhoD" );
    textLabelRhoD->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabelRhoD->sizePolicy().hasHeightForWidth() ) );
    buttonGroupSLDsolventLayout->addWidget( textLabelRhoD );

    lineEditRhoD = new QLineEdit( buttonGroupSLDsolvent, "lineEditRhoD" );
    buttonGroupSLDsolventLayout->addWidget( lineEditRhoD );
    spacer19 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    buttonGroupSLDsolventLayout->addItem( spacer19 );
    page1Layout->addWidget( buttonGroupSLDsolvent );

    tableMsvd = new QTable( page1, "tableMsvd" );
    tableMsvd->setNumCols( tableMsvd->numCols() + 1 );
    tableMsvd->horizontalHeader()->setLabel( tableMsvd->numCols() - 1, tr( "D-Composition" ) );
    tableMsvd->setNumCols( tableMsvd->numCols() + 1 );
    tableMsvd->horizontalHeader()->setLabel( tableMsvd->numCols() - 1, tr( "SLD-Solvent" ) );
    tableMsvd->setNumCols( tableMsvd->numCols() + 1 );
    tableMsvd->horizontalHeader()->setLabel( tableMsvd->numCols() - 1, tr( "Table-Name" ) );
    tableMsvd->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, tableMsvd->sizePolicy().hasHeightForWidth() ) );
    tableMsvd->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 246, 246, 246) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tableMsvd->setPalette( pal );
    tableMsvd->setBackgroundOrigin( QTable::WidgetOrigin );
    QFont tableMsvd_font(  tableMsvd->font() );
    tableMsvd->setFont( tableMsvd_font ); 
    tableMsvd->setFrameShadow( QTable::Sunken );
    tableMsvd->setLineWidth( 0 );
    tableMsvd->setResizePolicy( QTable::Manual );
    tableMsvd->setNumRows( 2 );
    tableMsvd->setNumCols( 3 );
    tableMsvd->setRowMovingEnabled( TRUE );
    tableMsvd->setColumnMovingEnabled( TRUE );
    tableMsvd->setSorting( FALSE );
    page1Layout->addWidget( tableMsvd );

    buttonGroupSLDcomponent = new QButtonGroup( page1, "buttonGroupSLDcomponent" );
    buttonGroupSLDcomponent->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, buttonGroupSLDcomponent->sizePolicy().hasHeightForWidth() ) );
    buttonGroupSLDcomponent->setColumnLayout(0, Qt::Vertical );
    buttonGroupSLDcomponent->layout()->setSpacing( 6 );
    buttonGroupSLDcomponent->layout()->setMargin( 11 );
    buttonGroupSLDcomponentLayout = new QHBoxLayout( buttonGroupSLDcomponent->layout() );
    buttonGroupSLDcomponentLayout->setAlignment( Qt::AlignTop );

    textLabelN = new QLabel( buttonGroupSLDcomponent, "textLabelN" );
    buttonGroupSLDcomponentLayout->addWidget( textLabelN );

    spinBoxNsvd = new QSpinBox( buttonGroupSLDcomponent, "spinBoxNsvd" );
    spinBoxNsvd->setMaxValue( 10 );
    spinBoxNsvd->setMinValue( 2 );
    spinBoxNsvd->setValue( 2 );
    buttonGroupSLDcomponentLayout->addWidget( spinBoxNsvd );
    spacer18 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    buttonGroupSLDcomponentLayout->addItem( spacer18 );
    page1Layout->addWidget( buttonGroupSLDcomponent );

    tableNsvd = new QTable( page1, "tableNsvd" );
    tableNsvd->setNumCols( tableNsvd->numCols() + 1 );
    tableNsvd->horizontalHeader()->setLabel( tableNsvd->numCols() - 1, tr( "Comment" ) );
    tableNsvd->setNumCols( tableNsvd->numCols() + 1 );
    tableNsvd->horizontalHeader()->setLabel( tableNsvd->numCols() - 1, tr( "H-SLD" ) );
    tableNsvd->setNumCols( tableNsvd->numCols() + 1 );
    tableNsvd->horizontalHeader()->setLabel( tableNsvd->numCols() - 1, tr( "D-SLD" ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 246, 246, 246) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 158, 158, 158) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 238, 238, 238) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 255, 0, 255) );
    pal.setDisabled( cg );
    tableNsvd->setPalette( pal );
    tableNsvd->setLineWidth( 0 );
    tableNsvd->setNumRows( 2 );
    tableNsvd->setNumCols( 3 );
    page1Layout->addWidget( tableNsvd );

    layout39 = new QGridLayout( 0, 1, 1, 2, 2, "layout39"); 
    spacer12 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout39->addItem( spacer12, 0, 1 );

    lineEditTabNameSVD = new QLineEdit( page1, "lineEditTabNameSVD" );
    lineEditTabNameSVD->setPaletteBackgroundColor( QColor( 255, 170, 255 ) );

    layout39->addWidget( lineEditTabNameSVD, 1, 2 );

    pushButtonSVD1dataTransferFrom = new QPushButton( page1, "pushButtonSVD1dataTransferFrom" );
    pushButtonSVD1dataTransferFrom->setEnabled( TRUE );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 63, 75, 138) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    pushButtonSVD1dataTransferFrom->setPalette( pal );

    layout39->addWidget( pushButtonSVD1dataTransferFrom, 1, 3 );

    spinBoxKsvd = new QSpinBox( page1, "spinBoxKsvd" );
    spinBoxKsvd->setMaxValue( 10000 );
    spinBoxKsvd->setMinValue( 1 );
    spinBoxKsvd->setValue( 20 );

    layout39->addWidget( spinBoxKsvd, 0, 2 );

    textLabel1_2_2 = new QLabel( page1, "textLabel1_2_2" );

    layout39->addWidget( textLabel1_2_2, 1, 0 );
    spacer12_2 = new QSpacerItem( 5, 5, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout39->addItem( spacer12_2, 1, 1 );

    textLabel1_2 = new QLabel( page1, "textLabel1_2" );

    layout39->addWidget( textLabel1_2, 0, 0 );

    pushButtonSVD1dataTransfer = new QPushButton( page1, "pushButtonSVD1dataTransfer" );
    pushButtonSVD1dataTransfer->setEnabled( TRUE );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 89, 166) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 230, 230, 230) );
    cg.setColor( QColorGroup::Light, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::Midlight, QColor( 253, 253, 253) );
    cg.setColor( QColorGroup::Dark, QColor( 143, 143, 143) );
    cg.setColor( QColorGroup::Mid, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::Text, QColor( 191, 191, 191) );
    cg.setColor( QColorGroup::BrightText, QColor( 250, 250, 250) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 236, 233, 216) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 63, 75, 138) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    pushButtonSVD1dataTransfer->setPalette( pal );

    layout39->addWidget( pushButtonSVD1dataTransfer, 0, 3 );
    page1Layout->addLayout( layout39 );
    toolBox20->addItem( page1, QString::fromLatin1("") );
    svd10Layout->addWidget( toolBox20 );

    layout40 = new QHBoxLayout( 0, 0, 1, "layout40"); 

    textLabelInfoSAS = new QLabel( this, "textLabelInfoSAS" );
    textLabelInfoSAS->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfoSAS->sizePolicy().hasHeightForWidth() ) );
    textLabelInfoSAS->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfoSAS->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfoSAS->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    textLabelInfoSAS->setFrameShape( QLabel::Box );
    textLabelInfoSAS->setTextFormat( QLabel::RichText );
    textLabelInfoSAS->setAlignment( int( QLabel::WordBreak | QLabel::AlignBottom | QLabel::AlignHCenter ) );
    textLabelInfoSAS->setIndent( 0 );
    layout40->addWidget( textLabelInfoSAS );

    textLabelInfo_2_2 = new QLabel( this, "textLabelInfo_2_2" );
    textLabelInfo_2_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo_2_2->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo_2_2->setMinimumSize( QSize( 0, 20 ) );
    textLabelInfo_2_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfo_2_2->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    textLabelInfo_2_2->setFrameShape( QLabel::Box );
    textLabelInfo_2_2->setAlignment( int( QLabel::AlignCenter ) );
    layout40->addWidget( textLabelInfo_2_2 );

    textLabelInfo_2 = new QLabel( this, "textLabelInfo_2" );
    textLabelInfo_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, textLabelInfo_2->sizePolicy().hasHeightForWidth() ) );
    textLabelInfo_2->setMaximumSize( QSize( 32767, 20 ) );
    textLabelInfo_2->setPaletteForegroundColor( QColor( 137, 137, 183 ) );
    textLabelInfo_2->setPaletteBackgroundColor( QColor( 238, 238, 238 ) );
    textLabelInfo_2->setFrameShape( QLabel::Box );
    textLabelInfo_2->setAlignment( int( QLabel::AlignCenter ) );
    layout40->addWidget( textLabelInfo_2 );
    svd10Layout->addLayout( layout40 );
    languageChange();
    resize( QSize(866, 636).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( lineEditTabNameSVD, SIGNAL( textChanged(const QString&) ), this, SLOT( forceReadSettings() ) );

    // buddies
    textLabelRhoH->setBuddy( lineEditRhoH );
    textLabelRhoD->setBuddy( lineEditRhoD );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
svd10::~svd10()
{
    destroy();
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void svd10::languageChange()
{
    setCaption( tr( "QtiKWS::SVD" ) );
    textLabelInfo->setText( tr( ">>> Singular Value Decomposition Interface <<<" ) );
    buttonGroupSLDsolvent->setTitle( tr( "H/D Solvents" ) );
    textLabelM->setText( tr( "M  (<font face=\"Symbol\">F1...FM</font>)" ) );
    QToolTip::add( spinBoxMsvd, tr( "Number of H/D compositions" ) );
    textLabelRhoH->setText( trUtf8( "\xcf\x81\x48" ) );
    lineEditRhoH->setText( tr( "-0.56e10" ) );
    QToolTip::add( lineEditRhoH, tr( "SLD of Protonated Solvent" ) );
    textLabelRhoD->setText( trUtf8( "\xcf\x81\x44" ) );
    lineEditRhoD->setText( tr( "+6.34e10" ) );
    QToolTip::add( lineEditRhoD, tr( "SLD of Deuterated Solvent" ) );
    tableMsvd->horizontalHeader()->setLabel( 0, tr( "D-Composition" ) );
    tableMsvd->horizontalHeader()->setLabel( 1, tr( "SLD-Solvent" ) );
    tableMsvd->horizontalHeader()->setLabel( 2, tr( "Table-Name" ) );
    QToolTip::add( tableMsvd, tr( "SLD of H/D compositions" ) );
    buttonGroupSLDcomponent->setTitle( tr( "Components" ) );
    textLabelN->setText( tr( "N  (<font face=\"Symbol\">r1...rN</font>)" ) );
    tableNsvd->horizontalHeader()->setLabel( 0, tr( "Comment" ) );
    tableNsvd->horizontalHeader()->setLabel( 1, tr( "H-SLD" ) );
    tableNsvd->horizontalHeader()->setLabel( 2, tr( "D-SLD" ) );
    lineEditTabNameSVD->setText( tr( "TEST1" ) );
    pushButtonSVD1dataTransferFrom->setText( tr( "Read Data" ) );
    QToolTip::add( spinBoxKsvd, tr( "Number of H/D compositions" ) );
    textLabel1_2_2->setText( tr( "Table Name" ) );
    textLabel1_2->setText( tr( "Number of Points" ) );
    pushButtonSVD1dataTransfer->setText( tr( "Make SVD" ) );
    toolBox20->setItemLabel( toolBox20->indexOf(page1), tr( "SVD" ) );
    textLabelInfoSAS->setText( tr( "SVD" ) );
    textLabelInfo_2_2->setText( tr( "v.10-07.10.2014" ) );
    textLabelInfo_2->setText( tr( "Vitaliy Pipich @ JCNS" ) );
}

