/***************************************************************************
 File                 : svd10.ui.h
 Project              : QtiKWS
 --------------------------------------------------------------------
 Copyright            : (C) 2006-2013 by Vitaliy Pipich
 Email (use @ for *)  : v.pipich*gmail.com
 Description          : Singular Value Decomposition Interface
 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *  This program is free software; you can redistribute it and/or modify   *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation; either version 2 of the License, or      *
 *  (at your option) any later version.                                    *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the Free Software           *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor,                    *
 *   Boston, MA  02110-1301  USA                                           *
 *                                                                         *
 ***************************************************************************/

#include "../standart-functions/standartFunctions.h"

#include "../../../qtiKWS/src/application.h"

#include <qwidgetlist.h>
#include <math.h>
#include <qdir.h>
#include <qvalidator.h> 
#include <qmessagebox.h>
#include <qpainter.h> 
#include <qfiledialog.h> 
#include <qtextstream.h> 
#include <qprocess.h>
#include <qsettings.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <qworkspace.h>	
#include <qmessagebox.h>
#include <qprogressdialog.h>

#include <gsl/gsl_math.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h> 

#include <gsl/gsl_integration.h>
#include <gsl/gsl_linalg.h>

	
//+++   INIT   +++++++++++++++++++++++++
void svd10::init()
{   
    tableMsvd->setColumnWidth(0,125);
    tableMsvd->setColumnWidth(1,125);
    tableMsvd->setColumnWidth(2,150);
    
    tableNsvd->setColumnWidth(0,150);
    tableNsvd->setColumnWidth(1,125);
    tableNsvd->setColumnWidth(2,125);
    
    readSettings();


    // signals and slots connections
    connect( lineEditTabNameSVD, SIGNAL( textChanged(const QString&) ), this, SLOT( slotTabNameSVDcheck() ) );
    connect( tableNsvd, SIGNAL( valueChanged(int,int) ), this, SLOT( slotTableNsvdChanged(int,int) ) );
    connect( tableMsvd, SIGNAL( valueChanged(int,int) ), this, SLOT( slotTableMsvdChanged(int,int) ) );
    connect( pushButtonSVD1dataTransfer, SIGNAL( clicked() ), this, SLOT( slotSVD1dataTransfer() ) );
    connect( pushButtonSVD1dataTransferFrom, SIGNAL( clicked() ), this, SLOT( slotReadDataFromTable() ) );
    connect( lineEditRhoD, SIGNAL( lostFocus() ), this, SLOT( slotCheckRhoHD() ) );
    connect( lineEditRhoH, SIGNAL( lostFocus() ), this, SLOT( slotCheckRhoHD() ) );
    connect( spinBoxNsvd, SIGNAL( valueChanged(int) ), tableNsvd, SLOT( setNumRows(int) ) );
    connect( spinBoxMsvd, SIGNAL( valueChanged(int) ), tableMsvd, SLOT( setNumRows(int) ) );

}

//*******************************************
//+++ Destroy
//*******************************************
void svd10::destroy()
{    
    writeSettings();
}

// *********************************
// **********************************
//            Settings Tab
// **********************************
// **********************************


//*******************************************
//+++  Read settings at init()
//*******************************************
void svd10::readSettings()
{
#ifdef Q_OS_MAC // Mac 
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
    
    settings.setPath("JCNS", "QtiKWS", QSettings::User);
    
    bool ok;
    QString ss;
    
    settings.beginGroup("/SVD");
    ss=settings.readEntry("/lineEditRhoH",0,&ok); if (ok) lineEditRhoH->setText(ss);
    ss=settings.readEntry("/lineEditRhoD",0,&ok); if (ok) lineEditRhoD->setText(ss);
    ss=settings.readEntry("/lineEditTabNameSVD",0,&ok); if (ok) lineEditTabNameSVD->setText(ss);
    
    int nn=settings.readNumEntry("/Nsvd",0,&ok); if (ok) spinBoxNsvd->setValue(nn);
    int mm=settings.readNumEntry("/Msvd",0,&ok); if (ok) spinBoxMsvd->setValue(mm);
    ss=settings.readEntry("/RhoH",0,&ok); if (ok) lineEditRhoH->setText(ss);
    ss=settings.readEntry("/RhoD",0,&ok); if (ok) lineEditRhoD->setText(ss);
    
    QStringList svdTabNames=settings.readListEntry("/svdTabNames"); 
    QStringList svdSolventComp=settings.readListEntry("/svdSolventComp"); 
    QStringList svdSolvSLD=settings.readListEntry("/svdSolvSLD"); 
    int ii;
    for (ii=0; (ii< mm);ii++) 
    {
	ss=svdTabNames[ii];
	tableMsvd->setText(ii,2,ss);
	ss=svdSolventComp[ii];
	tableMsvd->setText(ii,0,ss);
	ss=svdSolvSLD[ii];
	tableMsvd->setText(ii,1,ss);
    }
    
    QStringList svdComments=settings.readListEntry("/svdComments"); 
    QStringList svdSLDinH=settings.readListEntry("/svdSLDinH"); 
    QStringList svdSLDinD=settings.readListEntry("/svdSLDinD"); 
    for (ii=0; (ii< nn);ii++) 
    {
	ss=svdComments[ii];
	tableNsvd->setText(ii,0,ss);
	ss=svdSLDinH[ii];
	tableNsvd->setText(ii,1,ss);
	ss=svdSLDinD[ii];
	tableNsvd->setText(ii,2,ss); 
    }
    settings.endGroup();    
    
    
}

//*******************************************
//+++  Write settings at destroy()
//*******************************************
void svd10::writeSettings()
{
#ifdef Q_OS_MAC // Mac 
    QSettings settings(QSettings::Ini);
#else
    QSettings settings;
#endif
	settings.setPath ( "JCNS", "QtiKWS", QSettings::User );
    int ii;
    QString ss;
    QStringList TabList;
    settings.beginGroup("/SVD");
    //SVD
    settings.writeEntry("/lineEditRhoH",  lineEditRhoH->text());
    settings.writeEntry("/lineEditRhoD",  lineEditRhoD->text());
    settings.writeEntry("/lineEditTabNameSVD",  lineEditTabNameSVD->text());
    settings.writeEntry("/Msvd",  spinBoxMsvd->value());
    settings.writeEntry("/Nsvd",  spinBoxNsvd->value());
    settings.writeEntry("/RhoH",  lineEditRhoH->text());
    settings.writeEntry("/RhoD",  lineEditRhoD->text());
    
    
    for (ii=0; (ii< spinBoxMsvd->value());ii++) 
    {
	ss=tableMsvd->text(ii,2);
	TabList<< ss; 
    }
    settings.writeEntry("/svdTabNames", TabList);
    TabList.clear();
    
    for (ii=0; (ii< spinBoxMsvd->value());ii++) 
    {
	ss=tableMsvd->text(ii,0);
	TabList << ss; 
    }
    settings.writeEntry("/svdSolventComp", TabList);
    TabList.clear();
    
    for (ii=0; (ii< spinBoxMsvd->value());ii++) 
    {
	ss=tableMsvd->text(ii,1);
	TabList<< ss; 
    }
    settings.writeEntry("/svdSolvSLD", TabList);
    TabList.clear();
    
    
    QStringList svdComments,svdSLDinH, svdSLDinD; 
    for (ii=0; (ii< spinBoxNsvd->value());ii++) 
    {
	ss=tableNsvd->text(ii,0);
	svdComments<<ss; 
	ss=tableNsvd->text(ii,1);
	svdSLDinH<<ss; 
	ss=tableNsvd->text(ii,2);
	svdSLDinD<<ss; 
    }
    settings.writeEntry("/svdComments", svdComments);
    settings.writeEntry("/svdSLDinH", svdSLDinH);
    settings.writeEntry("/svdSLDinD", svdSLDinD);
    
    settings.endGroup();
       
}


//++++++++++++++++++++                                         ++++++++++++++++
//++++++++++++++++++++        FUNCTIONS             +++++++++++++++
//++++++++++++++++++++                                         ++++++++++++++++
//+++++   FUNCTION::check Table existance   +++++++++++++++++++++
bool svd10::checkTableExistence(QString &tableName)
{
	int i;
	bool exist=false;
	QWidgetList* tableList=app(this)->tableList();

	for (i=0;i<(int)tableList->count();i++)  if (tableList->at(i) && tableList->at(i)->name()==tableName) exist=true;

	return exist;
}
//++++++++++++++++++++    READ-SVD-DATA-FROM-TABLE        +++++++++
void svd10::slotReadSvdData(QString tableName)
{
	Table *t;
	QString ss;
	int tt,ii;
	
	//+++
	QWidgetList *tables=app(this)->tableList(); 
	
	//+++
	for (tt=0; tt < (int)tables->count(); tt++)
	{
		ss=tables->at(tt)->name();
		//+++
		if (ss==tableName)
		{
			t=(Table *)tables->at(tt);
			
			int nn=0;
			while(t->text(nn,0)!="") nn++;
			
			spinBoxNsvd->setValue(nn);
			
			for(ii=0; ii<nn;ii++ )
			{
				tableNsvd->setText(ii,0,t->text(ii,0));
				tableNsvd->setText(ii,1,t->text(ii,1));
				tableNsvd->setText(ii,2,t->text(ii,2));
			}
			
			nn=0;
			while(t->text(nn,3)!="") nn++;
			
			spinBoxMsvd->setValue(nn);
			
			for(ii=0; ii<nn;ii++ )
			{
				tableMsvd->setText(ii,0,t->text(ii,4));
				tableMsvd->setText(ii,1,t->text(ii,5));
				tableMsvd->setText(ii,2,t->text(ii,3));
			}
			
		}
		
	}
}

//+++++   FUNCTION::check Table existance   +++++++++++++++
bool svd10::checkTableExistenceTEST(QString &tableName)
{
	int i;
	bool exist=false;
	
	QWidgetList* tableList=app(this)->tableList();
	
	for (i=0;i<(int)tableList->count();i++)  if (tableList->at(i) && tableList->at(i)->name()==tableName) exist=true;
	return exist;
}

//+++++   Data Transfer                   ++++++++++++++++++++++
void svd10::slotSVD1dataTransfer  (QString Name, int Nsvd, QStringList TexT, gsl_matrix* SLDcomponent, int Msvd, 
								 QStringList Dcomposition,QStringList FileNames,gsl_vector* SLDsolvent, int Ksvd)
{	
	//Temp variables
	int mm,nn,ll,kk,j,KN, coln;
	double gslTemp, rhoHD, rho1, rho2, Bk, error;
	QString ss;
	
	//definition of variables...
	int M=Msvd;               			    	 //Number of H/D Concentrations
	int N; N=Nsvd*(Nsvd-1)/2+Nsvd; 		//Number of Partial structure factors
	int K=Ksvd; 		  	   				//Number of Q-points
	//
	int NM; if (Nsvd>Msvd) NM=Nsvd; else NM=Msvd; if (K>NM) NM=K;  //Table Dimension
	//
	bool TableName; //In-use when check existence of Tables 
	//
	QWidgetList* tables=app(this)->tableList();    //List of existing tables
	//
	Table *  t;     //Table-Pointer to Transfer Data
	
	//A-matrix SVD-on 
	gsl_matrix * A = gsl_matrix_calloc (M,N);   //Contrast-matrix A
	gsl_matrix * U = gsl_matrix_calloc (M,N);   //A=USV^T
	gsl_matrix * V = gsl_matrix_calloc (N,N);   //
	gsl_vector * S = gsl_vector_calloc (N);     //Diagonal of S-matrix
	gsl_vector * work = gsl_vector_calloc (N);  //temp...
	//
	gsl_matrix * Idata = gsl_matrix_calloc(K,M);    //Matrix of Scattering Intensity
	gsl_matrix *dIdata = gsl_matrix_calloc(K,M);    //Matrix of errorbars of Scattering Intensity
	gsl_vector * b = gsl_vector_calloc (M);         //b=Idata(0..K,M)
	gsl_vector * x = gsl_vector_calloc (N);         //
	//
	Table* tableRho=app(this)->newTable(Name,NM,6+Nsvd+N+N+N+N+1+M+M+N+M+M); // Make Result Table
	
	//Col-Names
	tableRho->setColName(0,"Comment");          tableRho->setColPlotDesignation( 0,Table::None);
	tableRho->setColName(1,"hSLDcomponent");    tableRho->setColPlotDesignation( 1,Table::None);
	tableRho->setColName(2,"dSLDcomponent");    tableRho->setColPlotDesignation( 2,Table::None);
	tableRho->setColName(3,"TableName");        tableRho->setColPlotDesignation( 3,Table::None);
	tableRho->setColName(4,"HDcomposition");    tableRho->setColPlotDesignation( 4,Table::X);
	tableRho->setColName(5,"SLDsolvent");       tableRho->setColPlotDesignation( 5,Table::Y);
	
	
	//Transfer of Data: from SLDcomponent-Matrix and TexT-QStringList to tableRho
	for (nn=0; nn<Nsvd; nn++)
	{ 
		tableRho->setText(nn,0,TexT[nn]);
		gslTemp=gsl_matrix_get(SLDcomponent,nn,0); ss=ss.setNum(gslTemp); tableRho->setText(nn,1,ss);
		gslTemp=gsl_matrix_get(SLDcomponent,nn,1); ss=ss.setNum(gslTemp); tableRho->setText(nn,2,ss);
	};
	
	//Transfer of Data: from Dcomposition-QStringList, SLDsolvent-Vector and FileNames-QStringList to tableRho
	for (mm=0; mm<Msvd; mm++) 
	{   
		tableRho->setText(mm,3,FileNames[mm]);
		tableRho->setText(mm,4,Dcomposition[mm]);
		gslTemp=gsl_vector_get(SLDsolvent,mm); ss=ss.setNum(gslTemp); tableRho->setText(mm,5,ss);
		
	};
	
	coln=6; //number of active column
	
	//Calculation of Real SLD vs. DHcomposition
	for (nn=0; nn<Nsvd;nn++)
	{
		ss="SLD"; ss+=TexT[nn];
		tableRho->setColName(coln,ss);
		
		for(mm=0; mm<Msvd;mm++)
		{
			ss=Dcomposition[mm];
			gslTemp=ss.toDouble();
			
			rhoHD=gsl_matrix_get(SLDcomponent,nn,0)+gslTemp*(gsl_matrix_get(SLDcomponent,nn,1)-gsl_matrix_get(SLDcomponent,nn,0));
			ss=ss.setNum(rhoHD);
			tableRho->setText(mm,coln,ss);
		}
		coln++;
	}
	
	
	KN=coln;
	//Making Rho-matrix 
	for (nn=1; nn<(Nsvd+1);nn++) for (mm=nn; mm<(Nsvd+1);mm++)
	{
		ss=ss.setNum(10*nn+mm);                     //Indexing. For-example 11,12,13,22,23,33.
		tableRho->setColName(coln,ss.prepend('a')); //Set col-names like a11,a12,a13...
		
		for (ll=0; ll<Msvd; ll++)
		{
			ss=tableRho->text(ll,6+nn-1);   rho1=ss.toDouble();
			ss=tableRho->text(ll,6+mm-1);   rho2=ss.toDouble();
			ss=tableRho->text(ll,5);            rhoHD=ss.toDouble();
			
			gslTemp=(rho1-rhoHD)*(rho2-rhoHD);
			if (nn!=mm) gslTemp*=2;
			ss=ss.setNum(gslTemp);
			tableRho->setText(ll,coln,ss);
			gsl_matrix_set(A,ll,coln-KN,gslTemp);
		}
		coln++;
	}
	
	//
	gsl_matrix_memcpy(U,A);// A initial matrix and U result of SVD
	
	gsl_set_error_handler_off(); // GSL- error handler is of !!!!
	
	//SVD of A to U V and S
	int status=gsl_linalg_SV_decomp(U,V,S,work);
	
	// Handling of errors in GSL-functions by hand :)
	if (status) if (status != 0) 
	{
		ss=ss.setNum(status);
		QMessageBox::critical(this, tr("QtiPlot - Error"),
							  tr("<b> %1 </b>: GSL error - SVD").arg(ss));        
		goto NoTableLabel;
	}
	
	
	KN=coln; // current column number
	
	//Print of U-matrix to tableRho (u11,u12....)
	for (nn=1; nn<(Nsvd+1);nn++) for (mm=nn; mm<(Nsvd+1);mm++)
	{
		ss=ss.setNum(10*nn+mm); 
		tableRho->setColName(coln,ss.prepend('u')); 
		for (ll=0; ll<Msvd; ll++)
		{
			ss=ss.setNum(gsl_matrix_get(U,ll,coln-KN));
			tableRho->setText(ll,coln,ss);
		};
		coln++;
	};
	//
	KN=coln; // current column number
	
	//Print of V-matrix to tableRho (v11,v12....)
	for (nn=1; nn<(Nsvd+1);nn++)
		for (mm=nn; mm<(Nsvd+1);mm++)
		{
		ss=ss.setNum(10*nn+mm); 
		tableRho->setColName(coln,ss.prepend('V')); 
		for (ll=0; ll<N; ll++)
		{
			ss=ss.setNum(gsl_matrix_get(V,ll,coln-KN));
			tableRho->setText(ll,coln,ss);
		}
		coln++;
	};
	//
	tableRho->setColName(coln,"S");
	//Print of S-vector to tableRho (s1,s2...sN)
	for (ll=0; ll<N; ll++)
	{ 
		ss=ss.setNum(gsl_vector_get(S,ll));
		tableRho->setText(ll,coln,ss);
	};
	coln++;
	
	KN=coln; // current column number
	
	//Transfet data from individual tables to tableRho (I and Q); making MxN Idata matrix
	for (mm=0; mm<M; mm++)
	{
		ss=ss.setNum(mm+1);
		tableRho->setColName(coln+mm*3,'Q'+ss);
		tableRho->setColName(coln+mm*3+1,'I'+ss);
		tableRho->setColName(coln+mm*3+2,"dI"+ss);
		tableRho->setColPlotDesignation(coln+mm*3,Table::X); // Set first Q-column as X
		tableRho->setColPlotDesignation(coln+mm*3+2,Table::yErr); // Set first Q-column as dY
		ss=tableRho->text(mm,3);
		
		TableName=FALSE;
		
		// checking of existance of individual tables
		for (j=0; j < (int)tables->count(); j++ ) if (tables->at(j)->name() == ss)
		{
			t=(Table *)tables->at(j);
			TableName=TRUE;
		};
		if (!TableName)
		{
			QMessageBox::critical(this, tr("QtiPlot - Error"),
								  tr("<b> %1 </b>: Table Does Not Exist").arg(ss));
			
			goto NoTableLabel;
		}
		
		//
		for (kk=0; kk<K; kk++)
		{
			tableRho->setText(kk,coln+mm*3,t->text(kk,0));
			tableRho->setText(kk,coln+mm*3+1,t->text(kk,1));
			tableRho->setText(kk,coln+mm*3+2,t->text(kk,2));
			
			gsl_matrix_set(Idata,kk,mm,t->text(kk,1).toDouble());
			gsl_matrix_set(dIdata,kk,mm,t->text(kk,2).toDouble());
		}
	}
	
	
	
	coln+=3*M;
	
	//
	for (nn=1; nn<(Nsvd+1);nn++) for (mm=nn; mm<(Nsvd+1);mm++)
	{
		ss=ss.setNum(10*nn+mm); 
		tableRho->setColName(coln,ss.prepend('S')); 
		coln++;
		tableRho->setColName(coln,ss.prepend('d')); 
		tableRho->setColPlotDesignation(coln,Table::yErr);
		coln++;
	};  
	
	//+++
	if (Nsvd==2)
	{
		tableRho->addColumns(6);
		tableRho->setColName(coln,"S13");
		tableRho->setColName(coln+1,"dS13");
		tableRho->setColPlotDesignation(coln+1,Table::yErr);
		
		tableRho->setColName(coln+2,"S23");
		tableRho->setColName(coln+3,"dS23");
		tableRho->setColPlotDesignation(coln+3,Table::yErr);
		
		tableRho->setColName(coln+4,"S33"); 
		tableRho->setColName(coln+5,"dS33");
		tableRho->setColPlotDesignation(coln+5,Table::yErr);
	}
	
	
	// +++ 
	coln=coln-2*N; 
	
	// +++
	KN=coln;
	
	// +++
	double S11, S12, S22, S13, S23, S33;
	
	// +++
	for (kk=0; kk<K; kk++)
	{
		error=0;
		for (mm=0;mm<M;mm++)
		{
			gsl_vector_set(b,mm,gsl_matrix_get(Idata,kk,mm));   
			error+=gsl_matrix_get(dIdata,kk,mm)/gsl_matrix_get(Idata,kk,mm)*gsl_matrix_get(dIdata,kk,mm)/gsl_matrix_get(Idata,kk,mm);
		}
		error=sqrt(error);
		// +++
		status=gsl_linalg_SV_solve(U,V,S,b,x);
		
		// +++
		if (status) if (status != 0) 
		{
			ss=ss.setNum(status);
			QMessageBox::critical(this, tr("QtiPlot - Error"),
								  tr("<b> %1 </b>: GSL error - Solve").arg(ss));      
			goto NoTableLabel;
		}
		
		// +++
		for (nn=0;nn<N;nn++)
		{	
			gslTemp=gsl_vector_get(x,nn);
			
			tableRho->setText(kk,coln+2*nn,QString::number(gslTemp));
			tableRho->setText(kk,coln+2*nn+1,QString::number(fabs(gslTemp*error)));
			if (Nsvd==2)
			{
				if (nn==0) S11=gslTemp;
				if (nn==1) S12=gslTemp;
				if (nn==2) S22=gslTemp;
			}
		}
		if (Nsvd==2)
		{
			S33=2*S12+S11+S22;
			S23=0.5*(S11-S22-S33);
			S13=0.5*(-S11+S22-S33);
			tableRho->setText(kk,coln+6,QString::number(S13));
			tableRho->setText(kk,coln+7,QString::number(fabs(S13*error)));
			tableRho->setText(kk,coln+8,QString::number(S23));
			tableRho->setText(kk,coln+9,QString::number(fabs(S23*error)));
			tableRho->setText(kk,coln+10,QString::number(S33));
			tableRho->setText(kk,coln+11,QString::number(fabs(S33*error)));			
		}
	}
	
	coln+=2*N; if (Nsvd==2) coln+=6;
	
	//
	for (mm=0; mm<M; mm++)
	{
		ss=ss.setNum(mm+1);
		tableRho->setColName(coln+mm,ss.prepend("Icon"));
	}
	
	KN=coln;
	
	for (mm=0;mm<Msvd;mm++)
	{
		for (kk=0;kk<Ksvd;kk++)
		{
			Bk=0;       
			for (nn=0;nn<N;nn++) 
			{
				ss=tableRho->text(kk,KN-N+nn);
				
				gslTemp=ss.toDouble();
				Bk+=gsl_matrix_get(A,mm,nn)*gslTemp;
				gslTemp=gsl_matrix_get(A,mm,nn);
			}
			ss=ss.setNum(Bk);
			tableRho->setText(kk,coln,ss);
		}
		coln++;
	}
	
	
	NoTableLabel: ;
}

//++++++++     SVD     ++++++++++++++++++++++++++++++++++++++++++
void svd10::slotTableMsvdChanged( int raw, int col )
{
	slotCheckRhoHD();
	
	//get changed text
	QString text= tableMsvd->text(raw,col) ;
	
	double textD= text.toDouble();    
	if ((textD<0 || textD>1) && col==0) 	textD=0.0;
	if (col==0) 
	{
		double RhoH=lineEditRhoH->text().toDouble();
		double RhoD=lineEditRhoD->text().toDouble();
		tableMsvd->setText(raw,col+1, QString::number(RhoH+textD*(RhoD-RhoH)));
		tableMsvd->setText(raw,col, QString::number(textD, 'f', 3 ));
	}
	else
		if (col==1) 
		{
		tableMsvd->setText(raw,col, QString::number(textD, 'e', 3 ));
	}
	else
		if (col==2) 
		{
		if (!checkTableExistenceTEST(text))  tableMsvd->setText(raw,col, " >>>check  "+text);
	}
}

//++++++++      Chech rhoHD    +++++++++++++++++++++++++++++++++++++
void svd10::slotCheckRhoHD()
{
	double change;
	change = lineEditRhoH->text().toDouble();  lineEditRhoH->setText( QString::number( change, 'e', 3 ) );
	change = lineEditRhoD->text().toDouble();  lineEditRhoD->setText( QString::number( change, 'e', 3 ) );   
}

//++++++++      Chech Table Name   ++++++++++++++++++++++++++++++++++
void svd10::slotTabNameSVDcheck()
{
	QString checkExistence=lineEditTabNameSVD->text();
	bool OK=checkTableExistence(checkExistence);
	
	if (OK) 
		lineEditTabNameSVD->setPaletteBackgroundColor(QColor(red));
	else
		lineEditTabNameSVD->setPaletteBackgroundColor(QColor(green));
}

//++++++++      Chech rhoHD    +++++++++++++++++++++++++++++++++++++
void svd10::slotSVD1dataTransfer()
{
	
	if (lineEditTabNameSVD->paletteBackgroundColor()!=QColor(green))   
	{
		QMessageBox::warning(this, tr("QtiKWS - Table exist"),tr("Change Name"));
		return;
	}
	
	QString text;
	QStringList Dcomposition,FileNames, TexT;
	int mm,nn;
	int Nsvd=    spinBoxNsvd->value();
	int Msvd=    spinBoxMsvd->value();
	int Ksvd=    spinBoxKsvd->value();
	gsl_vector * SLDsolvent        = gsl_vector_calloc(Msvd);
	gsl_matrix * SLDcomponent  = gsl_matrix_calloc(Nsvd,2);
	//
	for (mm=0; mm<Msvd; mm++) 
	{	
		text= tableMsvd->text(mm,1) ; gsl_vector_set(SLDsolvent, mm,  text.toDouble()); 
		Dcomposition.append(tableMsvd->text(mm,0));
		FileNames.append(tableMsvd->text(mm,2));
	};
	//
	for (nn=0; nn<Nsvd; nn++)
	{ 
		text= tableNsvd->text(nn,1) ; gsl_matrix_set(SLDcomponent, nn, 0,  text.toDouble()); 
		text= tableNsvd->text(nn,2) ; gsl_matrix_set(SLDcomponent, nn, 1,  text.toDouble()); 
		TexT.append(tableNsvd->text(nn,0));
	};
	
	slotSVD1dataTransfer(lineEditTabNameSVD->text(), Nsvd, TexT, SLDcomponent, Msvd, Dcomposition,FileNames, SLDsolvent, Ksvd);   
	
	// Set Table-Name as used after procedure
	
	QString checkExistence=lineEditTabNameSVD->text();
	if (checkTableExistence(checkExistence)) 
		lineEditTabNameSVD->setPaletteBackgroundColor(red);
	else
		lineEditTabNameSVD->setPaletteBackgroundColor(green);
}

//++++++++      Chech Nsvd   +++++++++++++++++++++++++++++++++++++
void svd10::slotTableNsvdChanged( int row, int col )
{
	
	slotCheckRhoHD();
	
	if (col==1 || col==2) 
	{    
		QString text= tableNsvd->text(row,col) ;
		
		double textD= text.toDouble();
		
		tableNsvd->setText(row,col, QString::number(textD, 'e', 3 ));
	}
	
}

//++++++++                        ++++++++++++++++++++++++++++++++++++++
void svd10::slotReadDataFromTable()
{
	slotTabNameSVDcheck();
	if (lineEditTabNameSVD->paletteBackgroundColor()==QColor(red)) 
	{
		slotReadSvdData(lineEditTabNameSVD->text());
	}
	
}


void svd10::forceReadSettings()
{
    if (lineEditTabNameSVD->text()=="TEST1") readSettings();
}
