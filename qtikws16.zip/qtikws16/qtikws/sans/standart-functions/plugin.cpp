#include "plugin.h"
Plugin::Plugin(QObject *parent, const char *name): QObject( parent, name)
{

}

Plugin::~Plugin()
{
	
}

QWidget * Plugin::widget()    
{
	return w;
}
