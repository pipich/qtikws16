/****************************************************************************
STANDART FUNCTIONNS  
*****************************************************************************/
#include "./standartFunctions.h"

//*******************************************
//+++ Text-To-Results Log-Window 
//*******************************************

void toResLogAll( QString interfaceName, QString text, QWidget* widget)
{
    // to QtiPlot
    QDockWindow *docWin=(QDockWindow*)widget->parent();
    ApplicationWindow *app;
    
    if ( docWin->place() == QDockWindow::InDock )
	app = (ApplicationWindow *)docWin->parent()->parent();
    else 
	app = (ApplicationWindow *)docWin->parent();

        
    QDateTime dt = QDateTime::currentDateTime();
    QString info	=dt.toString("dd.MM | hh:mm ->>" + interfaceName+">> ") ;
    info+=text;
    info+="\n";
    
    app->logInfo+=info;   
    app->results->setText(app->logInfo);
	app->results->scrollToBottom();	
}

void openHelpOnlineAll(const QString & link, QTextBrowser* br)
{
   // to QtiPlot
    QDockWindow *docWin=(QDockWindow*)br->parent();
    ApplicationWindow *app;
    
    if ( docWin->place() == QDockWindow::InDock )
	app = (ApplicationWindow *)docWin->parent()->parent();
    else 
	app = (ApplicationWindow *)docWin->parent();

    // to QtiPlot
    app->open_browser(app, link);

//    br->append(br->source());
    br->backward();
    br->setSource(br->source());
}

ApplicationWindow *app(QWidget* widget)
{
    // to QtiPlot
    QDockWindow *docWin=(QDockWindow*)widget->parent();
    ApplicationWindow *appM;
    
    if ( docWin->place() == QDockWindow::InDock )
	appM = (ApplicationWindow *)docWin->parent()->parent();
    else 
	appM = (ApplicationWindow *)docWin->parent();

    return appM;
}

QString helpPath(const QString & name, QWidget* widget)
{
   //+++
    QDir dd;
#if defined(_WIN32) //MSVC Compiler
    dd.cd(qApp->applicationDirPath());
    dd.cd("../help/"+name);
#else
    
    if ( !dd.cd("/project/qtiKWS/help/"+name) )
    {
	if ( !dd.cd("/usr/users/project/kws/qtiKWS/help/"+name))
	{
	    dd.cd(QDir::homeDirPath());
	    dd.cd("./.qt/help/"+name);
	}
    }
    
#endif

return dd.path();
}

void testAll(QWidget* widget)
{
	QMessageBox::warning(0,"QtiKWS", widget->parent()->parent()->parent()->parent()->parent()->parent()->parent()->className());
	
}