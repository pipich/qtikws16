#ifndef PLUGIN_H
#define PLUGIN_H

#include <qobject.h>
#include <qwidget.h>
#include <qpixmap.h>
#include "../../src/application.h"

class  Plugin : public QObject
{
   Q_OBJECT 

 public: 
   Plugin(QObject *parent=0,const char *name=0);
   virtual ~Plugin();

   virtual void initWidget( QWidget *parent=0 )=0;

   virtual const QPixmap & getIcon() { return icon;}
   virtual const int  getPluginMinWidth() { return minWidth;}
   virtual const int  getPluginMinHight() { return minHight;}
   virtual const char *getPluginAuthor() { return author;}
   virtual const char *getPluginName() { return pluginName;}
   virtual const char *getPluginLongName() { return longPluginName;}
   virtual const char *getPluginVersion() { return version; }
   virtual const char *getPluginLink() { return link; }
   virtual void setApp(ApplicationWindow *appNew) {app=appNew;}
   virtual QWidget *getWidget()=0;

   QWidget *widget();
   ApplicationWindow *app;   
 protected:

   QWidget *w;
   QPixmap icon;
   int minWidth;
   int minHight;
   char *author;
   char *pluginName;
   char *longPluginName;
   char *version;
   char *link;
};

typedef Plugin *createPlugin_r();
typedef void destroy_r(Plugin *); 

#endif
