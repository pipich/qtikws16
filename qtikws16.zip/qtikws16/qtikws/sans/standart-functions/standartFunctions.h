#ifndef STANDARTFUNCTIONS_H
#define STANDARTFUNCTIONS_H

/****************************************************************************
STANDART FUNCTIONNS  
*****************************************************************************/
#include <qwidget.h>
#include <qstring.h>
#include <qtextedit.h>
#include <qtextbrowser.h>
#include <qdir.h>
#include <qapplication.h>
#include <qmessagebox.h>
#include "../../src/application.h"



void toResLogAll( QString interfaceName, QString text, QWidget* widget);

void openHelpOnlineAll(const QString & link, QTextBrowser* br);

QString helpPath(const QString & name, QWidget* widget);

ApplicationWindow *app(QWidget* widget);
 
void testAll(QWidget* widget);

#endif
