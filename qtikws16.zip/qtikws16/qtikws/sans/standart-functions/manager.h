#ifndef MANAGER_H
#define MANAGER_H

#include "plugin.h"
#include <qlibrary.h>
#include <qmap.h>
#include <qobject.h>
#include <qapplication.h>
#include <qdir.h>
#include <list>
#include <qdict.h>
#include <qstringlist.h>
#include <qvaluelist.h> 
#include <qmessagebox.h>

using std::list;
typedef QMap<QString, QPixmap> ListOfIcons;


class PluginManager
{
 public:
   //---
   createPlugin_r *create_function;
   QDict< Plugin  > *pluginList;   
   QDict< QLibrary  > *handlers;
   //---
   QStringList pluginNames;
   //+++
   QStringList pluginLongNames;
   QStringList pluginVersions;
   QStringList pluginAuthors;
   QStringList pluginLinks;
   QValueList<int> minWidthList;
   QValueList<int> minHightList;
   //---
   ListOfIcons iconList;
   //---

   ~PluginManager()
   {
	 destroyPlugin(); // +++ new name !!!
	 delete handlers;
	 delete pluginList; 
   };

   //---
   PluginManager(ApplicationWindow *appM=0, QString dirPlugins2="")
   {
	//---
	pluginList = new QDict< Plugin >(100,false);
	handlers = new QDict< QLibrary >(100,false);
	dirPlugins = dirPlugins2;
        pluginList->setAutoDelete(false);
	handlers->setAutoDelete(false);
	app=appM;
    };

   ListOfIcons getIconPlugins() //+++ ListOfIcons new name
   {	
	return iconList;
    };

/*   QWidget *initPluginWidget( QString number, QWidget *parent=0 )
   {
	if( pluginList->find( number ) != 0 )
	{ 
	      pluginList->find(number)->initWidget( parent );
	}
	return 0;
   };
*/

   Plugin * getPlugin(QString number)
   {
	createPlugin_r *create=0;
	Plugin *object;
	
	if( pluginList->find( number ) != 0 )
	  {
	     //fprintf(stderr,"Yes, exist!");
	     return pluginList->find(number);
	  }
	 if( create == 0 )
	 {
	     if ( ( create = (createPlugin_r *)getFuncion( number, "createPlugin") ) == 0 )
	     {
		 return (0);
	     }
	     else
	     {
		object = create();
		pluginList->insert(object->getPluginName(),create());
	     }
	  }
	
	return (create());
     };

   void unloadPluginObject(QString number )
   {
	 destroy_r *unloadPlugin;	
	 unloadPlugin = (destroy_r * )getFuncion( number, "destroy") ;
         if( unloadPlugin )
         {
	    if( pluginList->find(number) != 0 )
	      {
		 fprintf(stderr,"deleting plugin\n");
	    	 unloadPlugin( pluginList->find(number) );
		 pluginList->remove(number);
	      };
	 };
     };

   void destroyPlugin( QString name="")
   {
	QLibrary *lib; 
        QDictIterator < QLibrary > it(*handlers);

	if( name.isEmpty() )
	{
	    while( it.current() )
	    {
		if( ( lib = handlers->find( it.currentKey() ) ) != 0 )
		{
		       unloadPluginObject( it.currentKey() );
		       fprintf(stderr,"Unloading-\n");
		       lib->unload();
		}
        	++it;
				 
	    }
	    handlers->clear();
	}
	else
	{
		if( ( lib = handlers->find( name ) ) != 0 )
		{
			unloadPluginObject( name );
			fprintf(stderr,"Unloading-\n");
			lib->unload();	 
			handlers->remove(name);
		}
	}
     };

   void *getFuncion( QString modulo, QString funcion_n )
   {	
        void *funcion=0;

	if( handlers->find(modulo ) == 0 ) return 0;
	funcion = (handlers->find(modulo))->resolve( funcion_n );
	if( funcion ) return ( funcion );

	return 0;
    };

   void loadPlugin( QString plg)
   {
        QLibrary *lib = new QLibrary(plg);
	Plugin *newPlugin=NULL;
	pluginNames.clear();
	//+++ new 
	pluginLongNames.clear();
   	pluginVersions.clear();
	pluginAuthors.clear();
	pluginLinks.clear();
	//---
	if( !lib->load())
	{
		QMessageBox::warning(0,"Plugin Messenger","Cannot Load\n"); 
	      	fprintf(stderr,"Cannot Load\n");
	};
	
	create_function = (createPlugin_r *) lib->resolve("createPlugin");

	if( create_function )
	{
	      newPlugin = create_function();
	      newPlugin->setApp(app); 
	      if( newPlugin )
	      {
		  pluginNames << newPlugin->getPluginName();
		  //+++ new opsions
		  pluginLongNames << newPlugin->getPluginLongName();
		  pluginVersions  << newPlugin->getPluginVersion();
		  pluginAuthors   << newPlugin->getPluginAuthor();
		  pluginLinks   << newPlugin->getPluginLink();
		  //---
		  handlers->insert( (QString) newPlugin->getPluginName(),lib);
		  
		  iconList[ (QString)newPlugin->getPluginName() ] = newPlugin->getIcon(); 
	       }; 
	}
	else QMessageBox::warning(0,"Plugin Messenger","Cannot Create\n"); 
     };

   void load()
   {	
	pluginList->clear();
	QDir dir( dirPlugins );
	QString filter;
#if defined(_WIN32) //MSVC Compiler
	filter="*.dll";
#else
	filter="*.so";
#endif
	dir.setNameFilter(filter);
	if( !dir.exists() )return;

	const QFileInfoList *listado = dir.entryInfoList();
	

	QFileInfoListIterator it( *listado );
	QFileInfo *fi;
	
	while( ( fi = it.current() ) != 0 )
	{
	      loadPlugin( QString("%1%2").arg(dirPlugins).arg( fi->fileName() ));
	      ++it;
	};	
   };
       
private:
       ApplicationWindow *app;
       Plugin *pp;
       QString dirPlugins;
};

#endif
