/***************************************************************************
 File                 : fitting-2D.cpp
 Project              : QtiKWS :: Matrix Fit Interface
 --------------------------------------------------------------------
 Copyright            : (C) 2006-2013 by Vitaliy Pipich
 Email (use @ for *)  : v.pipich*gmail.com
 Description          : Data Structure and Fitting Functions
 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *  This program is free software; you can redistribute it and/or modify   *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation; either version 2 of the License, or      *
 *  (at your option) any later version.                                    *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the Free Software           *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor,                    *
 *   Boston, MA  02110-1301  USA                                           *
 *                                                                         *
 ***************************************************************************/

#include "fitting-2D.h"
#include <stdio.h>


//*******************************************
//+++ function_fm
//*******************************************
int function_fm2D (const gsl_vector * x, void *params,  gsl_vector * f)
{
    	//+++
	size_t 		N 			= ((struct simplyFit2D *)params)->N;
	size_t 		p 			= ((struct simplyFit2D *)params)->p;
	
	gsl_vector 	*para			= ((struct simplyFit2D *)params)->paraAll;
	gsl_vector_int 	*paraF			= ((struct simplyFit2D *)params)->paraAllControl;
	
	gsl_function 	*F 			= ((struct simplyFit2D *)params)->function;
	
	gsl_vector 	*limitLeft			= ((struct simplyFit2D *)params)->limitLeft;
	gsl_vector 	*limitRight		= ((struct simplyFit2D *)params)->limitRight;	

    	//+++ get pointer to function parameters
	functionND *functionNDpara=(functionND *)F->params;
	
	//+++ function data
	gsl_vector *paraP	= ((struct functionND *) functionNDpara)->para;
	double *Q	= ((struct functionND *) functionNDpara)->Q;

	
	size_t M 		= ((struct functionND *) functionNDpara)->yNumber;
	size_t xNumber	= ((struct functionND *) functionNDpara)->xNumber;

	size_t *Rows 	= ((struct functionND *) functionNDpara)->Rows;
	size_t *Columns	= ((struct functionND *) functionNDpara)->Columns;

	gsl_matrix *I 		= ((struct functionND *) functionNDpara)->I;
	gsl_matrix *dI 		= ((struct functionND *) functionNDpara)->dI;
	gsl_matrix *mask 		= ((struct functionND *) functionNDpara)->mask;	
	gsl_matrix *xMatrix;
	if (xNumber>2) xMatrix 	= ((struct functionND *) functionNDpara)->xMatrix;	
	//--- function data
	
	
		
	//+++ all parameter number
	size_t pM=p*M;
	
	//+++ adjustible parameters counter
	size_t pFit=0;
	
	//+++ update parameters in para ... to ... x 
	for (int i=0; i<pM; i++)
	{
		if (gsl_vector_int_get(paraF,i)==0) 
		{
		    if ( gsl_vector_get(x,pFit)<gsl_vector_get(limitLeft,pFit) ) 
			gsl_vector_set(para,i,gsl_vector_get(limitLeft,pFit)); 
		    else if ( gsl_vector_get(x,pFit)>gsl_vector_get(limitRight,pFit) ) 
			gsl_vector_set(para,i,gsl_vector_get(limitRight,pFit)); 
		    else
			gsl_vector_set(para,i,gsl_vector_get(x,pFit));
			pFit++;
		}
		if (gsl_vector_int_get(paraF,i)==2)
		{
			int ii=i;
			while (gsl_vector_int_get(paraF,ii)==2) {ii--;};
			gsl_vector_set(para,i,gsl_vector_get(para,ii));
		}
	}
	
	//+++ first column in current matrix
	size_t colStart=0;
	//+++ used point counter
	size_t im=0;
	//+++ current values
	double Ii, currentMask, currentWeight, currentDataPoint;
	int rowStart;
		
	//+++ calculate residules vector
	for (int mm = 0; mm < M; mm++)
	{  
	    //+++ updare parameters value to current matrix
	    for (int pp=0;pp<p;pp++) gsl_vector_set(paraP,pp,gsl_vector_get(para,M*pp+mm));
	    	    
	    //+ new: 2016
	    for (int xx=0; xx<xNumber; xx++) Q[xx]=0.0;
	    ((functionND *)F->params)->beforeIter=true;   
	    GSL_FN_EVAL(F,  (double) (mm+1));	    
	    ((functionND *)F->params)->beforeIter=false;
	    //- new: 2016 


	    //+++ calculate f vector
	    for (int rr=0; rr<Rows[mm];rr++) for(int cc=0;cc<Columns[mm];cc++) 
	    {
		currentMask=gsl_matrix_get(mask, rr, cc+colStart);
		if (currentMask>0)
		{
		    currentDataPoint	=gsl_matrix_get(  I, rr, cc+colStart);
		    currentWeight		=gsl_matrix_get(dI, rr, cc+colStart);
		
		    Q[0]=(double)cc;
		    Q[1]=(double)rr;
		    rowStart=0;
		    for (int xx=2; xx<xNumber; xx++) 
		    {
			Q[xx]=gsl_matrix_get( xMatrix, rowStart+rr, cc+colStart);
			rowStart+=Rows[mm];
		    }
	
		    Ii = GSL_FN_EVAL(F,(double)(mm+1));
		    Ii=(Ii - currentDataPoint)/currentWeight; 
		    gsl_vector_set (f, im, Ii);
		    im++;
		}
	    }
	    
	    //+ new: 2016
	    for (int xx=0; xx<xNumber; xx++) Q[xx]=0.0;
	    ((functionND *)F->params)->afterIter=true;   
	    GSL_FN_EVAL(F,  (double) (mm+1));	    
	    ((functionND *)F->params)->afterIter=false;
	    //- new: 2016 

	    
	    colStart+=Columns[mm];
	}	
	
	return GSL_SUCCESS;
}

//*******************************************
//+++function_dfm
//*******************************************
int function_dfm2D (const gsl_vector * x, void *params, gsl_matrix * J)
{
	//+++
	double STEP=1e-8;
	
	//+++
    	size_t 		N 			= ((struct simplyFit2D *)params)->N;
	size_t 		M 			= ((struct simplyFit2D *)params)->yNumber;
	size_t 		p 			= ((struct simplyFit2D *)params)->p;
	size_t 		np 			= ((struct simplyFit2D *)params)->np;	
	gsl_vector 	*para			= ((struct simplyFit2D *)params)->paraAll;
	gsl_vector_int 	*paraF			= ((struct simplyFit2D *)params)->paraAllControl;
		
	// +++	
	size_t pFit=0;
	size_t pM=p*M;
	
	//+++
	for (int i=0; i<pM; i++)
	{
		if (gsl_vector_int_get(paraF,i)==0) 
		{
			gsl_vector_set(para,i,gsl_vector_get(x,pFit));
			pFit++;
		}
		if (gsl_vector_int_get(paraF,i)==2)
		{
			int ii=i;
			while (gsl_vector_int_get(paraF,ii)==2) {ii--;};
			gsl_vector_set(para,i,gsl_vector_get(para,ii));
		}
	}
	
	//+++
	double temp;
	
	//+++
	gsl_vector *xMinus=gsl_vector_alloc(np);
	gsl_vector *xPlus=gsl_vector_alloc(np);
	gsl_vector *xStep=gsl_vector_alloc(np);
	gsl_vector *xCurr=gsl_vector_alloc(np);
	
	//+++
	for (int i=0;i<np;i++ )
	{
		temp=fabs(gsl_vector_get(x,i));
		if (temp==0) temp=1e-10; else temp*=STEP;
		gsl_vector_set(xMinus,i,gsl_vector_get(x,i)-temp);
		gsl_vector_set(xPlus,i,gsl_vector_get(x,i)+temp);
		gsl_vector_set(xStep,i,2*temp);
	}
	
	//+++
	gsl_vector 	*fMinus 	=gsl_vector_alloc(N);   
	gsl_vector 	*fPlus 	=gsl_vector_alloc(N);   
	
	//+++
	for (int i=0;i<np; i++)
	{
	    gsl_vector_memcpy(xCurr,x);

	    gsl_vector_set(xCurr,i,gsl_vector_get(xMinus,i));
	    function_fm2D(xCurr, params, fMinus);
	    gsl_vector_set(xCurr,i,gsl_vector_get(xPlus,i));
	    function_fm2D(xCurr,params,fPlus);
	    
	    //+++
	    size_t nn;
	    for (nn = 0; nn < N; nn++)
	    {
		/* Jacobian matrix J(i,j) = dfi / dxj, */
		/* where fi = (Yi - yi)/sigma[i],      */
		temp=(gsl_vector_get(fPlus,nn)- gsl_vector_get(fMinus,nn))/gsl_vector_get(xStep,i);
		gsl_matrix_set (J, nn, i, temp); // !!!!!! check     temp/dI[nn]);	
	    }
	}
	
	gsl_vector_free(xMinus);
	gsl_vector_free(xPlus);
	gsl_vector_free(xStep);
	gsl_vector_free(xCurr);

	gsl_vector_free(fMinus);
	gsl_vector_free(fPlus);
	
    
	return GSL_SUCCESS;
}

//*******************************************
//+++ function_simplyFit2D_derivative
//*******************************************
double function_simplyFit2D_derivative (double x, void *params)
{    
    //+++
    size_t  		indexX	= ((struct simplyFitDerivative2D *)params) ->indexX;
    size_t  		key	= ((struct simplyFitDerivative2D *)params) ->key;
    gsl_function 	*F 	= ((struct simplyFitDerivative2D *)params)->function;
    gsl_vector 	*para	= ((functionND *)F->params)->para;    
    
    double oldX=gsl_vector_get(para,indexX);
    
    gsl_vector_set(para,indexX,x);
    
    double res=GSL_FN_EVAL(F,key);
    
    gsl_vector_set(para,indexX,oldX);
    
    return res;
}

//*******************************************
//+++function_dfm
//*******************************************
int function_dfm2D_long (const gsl_vector * x, void *params, gsl_matrix * J)
{
    //+++
    size_t 		N 			= ((struct simplyFit2D *)params)->N;
    size_t 		p 			= ((struct simplyFit2D *)params)->p;
    size_t 		np 			= ((struct simplyFit2D *)params)->np;
  
    gsl_vector 	*para			= ((struct simplyFit2D *)params)->paraAll;
    gsl_vector_int 	*paraF			= ((struct simplyFit2D *)params)->paraAllControl;
	
    gsl_function 	*F 			= ((struct simplyFit2D *)params)->function;
	
    gsl_vector 	*limitLeft		= ((struct simplyFit2D *)params)->limitLeft;
    gsl_vector 	*limitRight		= ((struct simplyFit2D *)params)->limitRight;	

    //+++ get pointer to function parameters
    functionND *functionNDpara=(functionND *)F->params;
	
    //+++ function data
    gsl_vector *paraP	= ((struct functionND *) functionNDpara)->para;
    double *Q	= ((struct functionND *) functionNDpara)->Q;

	
    size_t M 		= ((struct functionND *) functionNDpara)->yNumber;
    size_t xNumber	= ((struct functionND *) functionNDpara)->xNumber;
    
    size_t *Rows 	= ((struct functionND *) functionNDpara)->Rows;
    size_t *Columns	= ((struct functionND *) functionNDpara)->Columns;
    
    gsl_matrix *I 		= ((struct functionND *) functionNDpara)->I;
    gsl_matrix *dI 		= ((struct functionND *) functionNDpara)->dI;
    gsl_matrix *mask 		= ((struct functionND *) functionNDpara)->mask;	
    gsl_matrix *xMatrix;
    if (xNumber>2) xMatrix 	= ((struct functionND *) functionNDpara)->xMatrix;	
    //--- function data
    
    //+++
    simplyFitDerivative2D  simplyFitDerivative = { F, 0, 1};    
    //+++
    gsl_function FD;
    FD.function = function_simplyFit2D_derivative;
    FD.params = &simplyFitDerivative ;
    			
    //+++ all parameter number
    size_t pM=p*M;
	
    //+++ adjustible parameters counter
    size_t pFit=0;
	
    int *npCurrent=new int[np];    
    int *mCurrent=new int[np];
    
    int ii=0;
    
    for (int pp=0; pp<p; pp++)  for (int mm=0; mm<M; mm++) 
    {
	if (gsl_vector_int_get(paraF,ii)==0) 
	{
	    gsl_vector_set(para,ii,gsl_vector_get(x,pFit));
	    npCurrent[pFit]=pp;
	    mCurrent[pFit]=mm;
	    pFit++;
	}
	if (gsl_vector_int_get(paraF,ii)==2)
	{
	    gsl_vector_set(para,ii,gsl_vector_get(para,M*p));
	}
	ii++;
    }
    
	
    //+++ first column in current matrix
    size_t colStart=0;
    
    //+++ current values
    double Ii, currentMask, currentWeight, currentDataPoint;
    int rowStart;
		
  
    //+++ calculate Jacobian matrix
    int currentPoint;
    double result, abserr;
    
    for(int npnp=0; npnp<np; npnp++)
    {
	currentPoint=0;
	colStart=0;
	for (int mm = 0; mm < M; mm++)
	{  
	    //+++ updare parameters value to current matrix
	    for (int pp=0;pp<p;pp++) gsl_vector_set(paraP,pp,gsl_vector_get(para,M*pp+mm));
	    
	    //+ new: 2016
	    for (int xx=0; xx<xNumber; xx++) Q[xx]=0.0;
	    ((functionND *)F->params)->beforeIter=true;   
	    GSL_FN_EVAL(F,  (double) (mm+1));	    
	    ((functionND *)F->params)->beforeIter=false;
	    //- new: 2016 
	    
	    
	    //+++ calculate f vector
	    for (int rr=0; rr<Rows[mm];rr++) for(int cc=0;cc<Columns[mm];cc++) 
	    {
		currentMask=gsl_matrix_get(mask, rr, cc+colStart);
		if (currentMask>0)
		{
//		    currentDataPoint	=gsl_matrix_get(  I, rr, cc+colStart);
		    currentWeight		=gsl_matrix_get(dI, rr, cc+colStart);
		    
		    Q[0]=(double)cc;
		    Q[1]=(double)rr;
		    rowStart=0;
		    for (int xx=2; xx<xNumber; xx++) 
		    {
			Q[xx]=gsl_matrix_get( xMatrix, rowStart+rr, cc+colStart);
			rowStart+=Rows[mm];
		    }
		    		    
		    ((simplyFitDerivative2D *)FD.params)->indexX=npCurrent[npnp]; // current 
		    ((simplyFitDerivative2D *)FD.params)->key=mm+1; // current 
		    gsl_deriv_central (&FD, gsl_vector_get(x,npnp), gsl_max(0.001*gsl_vector_get(x,npnp), 0.0001), &result, &abserr);
		    gsl_matrix_set (J, currentPoint, npnp, result/currentWeight);
		    currentPoint++;
		}
	    }
	    
	    //+ new: 2016
	    for (int xx=0; xx<xNumber; xx++) Q[xx]=0.0;
	    ((functionND *)F->params)->afterIter=true;   
	    GSL_FN_EVAL(F,  (double) (mm+1));	    
	    ((functionND *)F->params)->afterIter=false;
	    //- new: 2016 
	    
	    
	    colStart+=Columns[mm];
	}	
	
    }    
    
    delete[] npCurrent;
    delete[] mCurrent;
    
    return GSL_SUCCESS;
}


//*******************************************
//+++function_fdfm
//*******************************************
int function_fdfm2D (const gsl_vector * x, void *params,
				   gsl_vector * f, gsl_matrix * J)
{
	function_fm2D (x, params, f);
	function_dfm2D_long (x, params, J);
	return GSL_SUCCESS;   
}

//*******************************************
//+++ function_dm
//*******************************************
double function_dm2D (const gsl_vector * x, void *params)
{
	size_t 	N 	= ((struct simplyFit2D *)params)->N;
	gsl_vector 	*fu 	=gsl_vector_alloc(N);
	
	function_fm2D(x, params, fu);
	
	double Ii=0;
	
	//+++
	size_t i;
	for(i=0; i<N; i++) 
		Ii+=gsl_vector_get(fu,i)*gsl_vector_get(fu,i);
	
	gsl_vector_free(fu); //destroy fu
	
	return Ii;
}
