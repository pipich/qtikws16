/****************************************************************************
** Form interface generated from reading ui file '..\qtiKWS\sans\fitMatrix10\fitMatrix10.ui'
**
** Created: Do 14. Sep 01:52:13 2017
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.4   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef FITMATRIX10_H
#define FITMATRIX10_H

#include <qvariant.h>
#include <qpixmap.h>
#include <qwidget.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_math.h>
#include <qlibrary.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_multifit_nlin.h>
#include "fitting-2D.h"

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QButtonGroup;
class QToolButton;
class QLabel;
class QWidgetStack;
class QSplitter;
class QListBox;
class QListBoxItem;
class QTabWidget;
class QTextBrowser;
class QTable;
class QCheckBox;
class QSpinBox;
class QLineEdit;
class QComboBox;
class QFrame;
class QPushButton;
class Graph;
class Table;
class Matrix;
class myWidget;
class Note;

class fitMatrix10 : public QWidget
{
    Q_OBJECT

public:
    fitMatrix10( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~fitMatrix10();

    QButtonGroup* buttonGroup22;
    QToolButton* pushButtonSaveSession;
    QToolButton* pushButtonLoadFittingSession;
    QButtonGroup* buttonGroup56;
    QLabel* textLabelLeft;
    QToolButton* pushButtonFitPrev;
    QLabel* textLabelCenter;
    QToolButton* pushButtonFitNext;
    QLabel* textLabelRight;
    QWidgetStack* widgetStackFit;
    QWidget* WStackPageFitFunction;
    QSplitter* splitter8;
    QSplitter* splitter7;
    QLabel* textLabelGroupName_2;
    QListBox* listBoxGroup;
    QLabel* textLabelFunctionName_2;
    QListBox* listBoxFunctions;
    QTabWidget* tabWidget4;
    QWidget* tab;
    QTextBrowser* textBrowserFunctionDescription00;
    QWidget* tab_2;
    QTable* tableParaComments00;
    QWidget* TabPage;
    QCheckBox* checkBoxMultiData;
    QSpinBox* spinBoxNumberCurvesToFit;
    QWidget* WStackPageFitData;
    QTabWidget* tabWidgetFit;
    QWidget* dataSets;
    QTable* tableCurves;
    QWidget* Function;
    QLabel* textLabelFfunc;
    QSpinBox* spinBoxPara;
    QSpinBox* spinBoxXnumber;
    QSpinBox* spinBoxFnumber;
    QSplitter* splitter8_2;
    QTextBrowser* textBrowserFunctionDescription;
    QTable* tableParaComments;
    QWidget* parameters;
    QTable* tablePara;
    QWidget* TabPage_2;
    QTable* tableControl;
    QButtonGroup* buttonGroup21;
    QLabel* textLabelRandomSeed_3;
    QLineEdit* lineEditLeftMargin;
    QLabel* textLabel2;
    QLineEdit* lineEditRightMargin;
    QLabel* textLabelRandomSeed_3_2;
    QToolButton* toolButtonApplyLimits;
    QToolButton* toolButtonResetLimits;
    QWidget* TabPage_3;
    QButtonGroup* buttonGroup18;
    QLabel* textLabel1_2_2;
    QLabel* textLabel2_2_2_2;
    QComboBox* comboBoxFitMethod;
    QSpinBox* spinBoxSignDigits;
    QButtonGroup* buttonGroupGenMin;
    QLabel* textLabel1;
    QSpinBox* spinBoxGenomeCount;
    QLabel* textLabel1_3;
    QLabel* textLabel1_3_2;
    QLineEdit* lineEditSelectionRate;
    QLabel* textLabel1_3_2_2;
    QSpinBox* spinBoxMaxNumberGenerations;
    QSpinBox* spinBoxRandomSeed;
    QLabel* textLabelRandomSeed;
    QLineEdit* lineEditMutationRate;
    QButtonGroup* buttonGroupSimplex;
    QLabel* textLabel1_2;
    QLabel* textLabel2_2;
    QLabel* textLabel2_2_2;
    QSpinBox* spinBoxMaxIter;
    QLineEdit* lineEditToleranceAbs;
    QLineEdit* lineEditTolerance;
    QButtonGroup* buttonGroupWM;
    QComboBox* comboBoxWeightingMethod;
    QFrame* frame3;
    QLabel* textLabelWA;
    QLineEdit* lineEditWA;
    QLabel* textLabelWB;
    QLineEdit* lineEditWB;
    QLabel* textLabelWC;
    QLineEdit* lineEditWC;
    QLabel* pixmapLabel1_2_2_2;
    QButtonGroup* buttonGroup58;
    QToolButton* pushButtonUndo;
    QToolButton* pushButtonChiSqr;
    QToolButton* pushButtonMultiFit;
    QToolButton* pushButtonRedo;
    QToolButton* pushButtonBeforeFit;
    QToolButton* pushButtonAfterFit;
    QButtonGroup* buttonGroup57;
    QLabel* textLabelChiLabel_3;
    QLabel* textLabelChiLabel_2;
    QLabel* textLabelR2;
    QLabel* textLabelChi;
    QLabel* textLabelChiLabel;
    QLabel* textLabelTime;
    QWidget* WStackPage;
    QTabWidget* tabWidgetGenResults;
    QWidget* tab_3;
    QSplitter* splitter13;
    QTable* tableParaSimulate;
    QButtonGroup* buttonGroup9;
    QToolButton* pushButtonSimulate;
    QCheckBox* checkBoxSimIndexing;
    QToolButton* pushButtonSimulateDelete;
    QLabel* textLabelChiLabel_2_2;
    QLabel* textLabelTimeSim;
    QLabel* textLabelChiLabel_4_2_4;
    QLabel* textLabelChi2Sim;
    QLabel* textLabelChiLabel_4_2;
    QLabel* textLabelChi2dofSim;
    QLabel* textLabelChiLabel_4_2_3;
    QLabel* textLabelR2sim;
    QButtonGroup* buttonGroup78;
    QButtonGroup* checkBoxShowCurvesInGraph;
    QCheckBox* checkBoxSimData;
    QComboBox* comboBoxOutput;
    QCheckBox* checkBoxResidues;
    QCheckBox* checkBoxResiduesSlices;
    QCheckBox* checkBoxSimStatistics;
    QButtonGroup* radioButtonSameQrange;
    QComboBox* comboBoxDatasetSim;
    QCheckBox* checkBoxAllInOne;
    QButtonGroup* checkBoxindividualSimulation;
    QTable* tableSimX;
    QCheckBox* checkBoxMaskSim;
    QCheckBox* checkBoxUseWeightSim;
    QButtonGroup* radioButtonUniform_Q;
    QLabel* textLabelDofSim;
    QSpinBox* simRows;
    QLabel* textLabelfromQsim_2;
    QLabel* textLabelToQsim_2;
    QLabel* textLabelToQsim;
    QSpinBox* simCols;
    QLabel* textLabelfromQsim;
    QLabel* textLabelnpSIM;
    QWidget* tab_4;
    QPushButton* pushButtonNewTabRes;
    QPushButton* pushButtonresToLogWindow;
    QPushButton* pushButtonresToLogWindowOne;
    QPushButton* pushButtonresToActiveGraph;
    QWidget* TabPage_4;
    QLabel* textLabelPattern;
    QLineEdit* lineEditPattern;
    QPushButton* pushButtonPattern;
    QPushButton* pushButtonSelectFromTable;
    QTable* tableMultiFit;
    QLabel* textLabelfromQ_2;
    QLineEdit* lineEditSetBySetFit;
    QPushButton* pushButtonSetBySetFit;
    QPushButton* pushButtonSimulateMulti;
    QPushButton* pushButtonDeleteCurves;
    QComboBox* comboBoxFunction;
    QLabel* textLabelInfoSAS;
    QLabel* textLabelInfo_2_2;
    QLabel* textLabelInfo_2;
    QPushButton* pushButtonHelp;

    QString libPath;
    QStringList undoRedo;
    size_t undoRedoActive;

    virtual void chekLimitsAndFittedParameters();
    virtual bool simplyFit();
    virtual bool findFitDataTable( QString curveName, Table * & table, int & xColIndex, int & yColIndex );
    virtual bool checkCell( QString & line );
    virtual bool checkTableExistence( QString tableName, Table * & w );
    virtual bool checkTableExistence( QString tableName );
    virtual bool findAllMatrixesLikeExample( QString exampleMatrix, QStringList & list, int & nRows, int & nCols );
    virtual bool findAllMatrixesByDimension( QStringList & list, int nRows, int nCols );
    virtual QStringList findAllMatrixes();
    virtual bool readDataToFit( size_t * Rows, size_t * Columns, int & Ntotal, gsl_matrix * & I, gsl_matrix * & dI, gsl_matrix * & mask, gsl_matrix * & xMatrix );
    virtual bool readDataToFitSingle( int mm, size_t * Rows, size_t * Columns, int & Ntotal, gsl_matrix * & I, gsl_matrix * & dI, gsl_matrix * & mask, gsl_matrix * & xMatrix );
    virtual bool findFitDataMatrix( QString matrixName, Matrix * & matrix, int & rows, int & cols );
    virtual bool generateSimulatedMatrixAll();
    virtual bool findGraphInActivePlot( myWidget * w, Graph * & g, int grNumber, QString & label );
    virtual bool plotTable( Graph * g, Table * table, QString tableName, int colX, int colY, int colDX, int colDY );
    virtual bool makeTableFromMatrix( std::string name, std::string * tableColNames, int * tableColDestinations, gsl_matrix * m );
    virtual bool generateSimulatedMatrix( int source, int m, QString simulatedMatrixName, int & activePixel, int & np, double & chi2, double & TSS );
    virtual bool matrix2gslmatrix( QString mName, gsl_matrix * gslMatrix, int nRows, int nCols );
    virtual bool matrix2gslmatrixXmatrix( QString * mName, int xNumber, gsl_matrix * gslMatrix, int nRows, int nCols );
    virtual QString fillSpace( QString s, int length, QString fill );
    virtual QString currentStatistics( int N, int P, double chi, double r2, QStringList paraActive, gsl_matrix * covar, gsl_vector * paraAdjust, int m );

public slots:
    virtual void toResLog( QString text );
    virtual void connectSlot();
    virtual void scanGroup();
    virtual void groupFunctions( const QString & groupName );
    virtual void weightChanged();
    virtual void algorithmSelected();
    virtual void initLimits();
    virtual void chekLimits();
    virtual void setScaledLimits();
    virtual void initMultiParaTable();
    virtual void initFitPage();
    virtual void initFitPage( bool functionChanged );
    virtual void initMultiTable();
    virtual void slotStackFitPrev();
    virtual void slotStackFitNext();
    virtual void openDLL( const QString & file );
    virtual void openDLLgeneral( QString file );
    virtual void tableCurvechanged( int raw, int col );
    virtual void resToLogWindow();
    virtual void resToLogWindowOne();
    virtual void newTabRes();
    virtual void saveFittingSession();
    virtual void fitSwitcher();
    virtual void fitOrCalculate( bool calculateYN );
    virtual void selectPattern();
    virtual void setBySetFit();
    virtual void setBySetFitOrSim( bool fitYN );
    virtual void rename( QString oldNAME, QString newNAME );
    virtual void simulateMultifitTables();
    virtual void removeMatrixes( QString pattern );
    virtual void removeSimulatedDatasets();
    virtual bool datasetChangedSim( int num );
    virtual void addFitResultToActiveGraph();
    virtual void saveUndo();
    virtual void undo();
    virtual void redo();
    virtual void headerPressedTablePara( int col );
    virtual void vertHeaderPressedTablePara( int raw );
    virtual void vertHeaderTableCurves( int raw );
    virtual void headerTableMultiFit( int col );
    virtual void selectRowsTableMultiFit();
    virtual void tableParaRepaint();
    virtual void openHelpOnline();
    virtual void selectMultyFromTable();
    virtual void checkGlobalParameters( int raw, int col );
    virtual bool findActiveGraph( Graph * & g );
    virtual void plotSwitcher();
    virtual void checkConstrains( int source, int m );
    virtual void findTableListByLabel( QString winLabel, QStringList & list );
    virtual void readSettingsTable();
    virtual void horizHeaderCurves( int col );
    virtual void updateDatasets();
    virtual void makeMatrixUni( gsl_matrix * gmatrix, QString name, QString label, int xDim, int yDim );
    virtual bool beforeFit();
    virtual bool afterFit();
    virtual void changeFunctionLocal( const QString & newFunction );
    virtual void colList( QString matrixName, int col );
    virtual void makeTableSlices( gsl_matrix * gmatrix, gsl_matrix * mask, QString name, int xDim, int yDim, size_t * Columns, size_t * Rows );
    virtual void simulate();
    virtual void makeMatrix2in1( gsl_matrix * data, gsl_matrix * simulation, QString name, QString label, int xDim, int yDim );
    virtual void calculateWeightMatrix( gsl_matrix * data, gsl_matrix * weightdata, gsl_matrix * mask, gsl_matrix * & weight, int nRows, int nCols );
    virtual void convertWeightMatrix( gsl_matrix * & weight, int nRows, int nCols );
    virtual void fitStatMatrixM( int m, gsl_matrix * data, gsl_matrix * residues, gsl_matrix * mask, int xDim, int yDim, int & activePixel, int & np, double & chi2, double & TSS );
    virtual void makeNote( QString info, QString name, QString label );

protected:
    int setToSetNumber;
    QString libName;
    QStringList F_initValuesF;
    QStringList SANS_initValues;
    QStringList SANS_param_names;
    QString XQ;
    bool setToSetProgressControl;

    QVBoxLayout* fitMatrix10Layout;
    QSpacerItem* spacer38;
    QVBoxLayout* buttonGroup22Layout;
    QHBoxLayout* layout63;
    QHBoxLayout* buttonGroup56Layout;
    QVBoxLayout* WStackPageFitFunctionLayout;
    QVBoxLayout* layout33;
    QHBoxLayout* layout32;
    QSpacerItem* spacer20;
    QVBoxLayout* layout75;
    QHBoxLayout* layout74;
    QHBoxLayout* tabLayout;
    QHBoxLayout* tabLayout_2;
    QVBoxLayout* TabPageLayout;
    QSpacerItem* spacer52;
    QHBoxLayout* layout65;
    QSpacerItem* spacer19;
    QVBoxLayout* WStackPageFitDataLayout;
    QVBoxLayout* dataSetsLayout;
    QSpacerItem* spacer21_2_2;
    QVBoxLayout* FunctionLayout;
    QSpacerItem* spacer21_2_2_2;
    QVBoxLayout* layout63_2;
    QHBoxLayout* layout62;
    QVBoxLayout* parametersLayout;
    QSpacerItem* spacer21_2_2_2_2;
    QVBoxLayout* TabPageLayout_2;
    QSpacerItem* spacer21_2_2_2_3;
    QHBoxLayout* buttonGroup21Layout;
    QVBoxLayout* TabPageLayout_3;
    QSpacerItem* spacer21_2_2_2_4;
    QSpacerItem* spacer22;
    QHBoxLayout* layout81;
    QSpacerItem* spacer26;
    QVBoxLayout* layout80;
    QHBoxLayout* buttonGroup18Layout;
    QVBoxLayout* layout76;
    QVBoxLayout* layout395;
    QGridLayout* buttonGroupGenMinLayout;
    QHBoxLayout* buttonGroupSimplexLayout;
    QVBoxLayout* layout80_2;
    QVBoxLayout* layout81_2;
    QVBoxLayout* buttonGroupWMLayout;
    QSpacerItem* spacer16;
    QHBoxLayout* frame3Layout;
    QSpacerItem* spacer20_2;
    QHBoxLayout* layout49;
    QVBoxLayout* buttonGroup58Layout;
    QHBoxLayout* layout91;
    QGridLayout* buttonGroup57Layout;
    QHBoxLayout* WStackPageLayout;
    QHBoxLayout* tabLayout_3;
    QVBoxLayout* layout64;
    QVBoxLayout* buttonGroup9Layout;
    QSpacerItem* spacer130;
    QHBoxLayout* layout264;
    QHBoxLayout* layout65_2;
    QHBoxLayout* layout273_2;
    QHBoxLayout* layout273;
    QHBoxLayout* layout271;
    QVBoxLayout* buttonGroup78Layout;
    QSpacerItem* spacer21;
    QVBoxLayout* checkBoxShowCurvesInGraphLayout;
    QHBoxLayout* layout265;
    QHBoxLayout* radioButtonSameQrangeLayout;
    QVBoxLayout* checkBoxindividualSimulationLayout;
    QHBoxLayout* layout263;
    QSpacerItem* spacer129;
    QVBoxLayout* radioButtonUniform_QLayout;
    QHBoxLayout* layout277;
    QSpacerItem* spacer131;
    QGridLayout* layout276;
    QVBoxLayout* tabLayout_4;
    QSpacerItem* spacer21_2_2_2_5;
    QSpacerItem* spacer17_2;
    QVBoxLayout* TabPageLayout_4;
    QHBoxLayout* layout25;
    QHBoxLayout* layout24;
    QHBoxLayout* layout26;
    QHBoxLayout* layout7;

protected slots:
    virtual void languageChange();

private:
    QStringList SANS_adjustPara;
    QStringList F_paraListF;
    QLibrary *lib;
    QStringList F_paraListComments;
    QStringList F_adjustPara;
    QStringList F_paraList;
    gsl_function F;
    QStringList d_param_names;
    QStringList F_initValues;
    gsl_vector *F_para;
    size_t pF;
    QStringList F_adjustParaF;
    QStringList F_paraListCommentsF;
    QStringList SANS_paraListComments;
    bool setToSetSimulYN;
    QStringList x_Names;

    QPixmap image0;
    QPixmap image1;
    QPixmap image2;
    QPixmap image3;
    QPixmap image4;
    QPixmap image5;
    QPixmap image6;
    QPixmap image7;
    QPixmap image8;

    void init();

};

#endif // FITMATRIX10_H
