/***************************************************************************
 File                : fitMatrix10.ui.h
 Project         : QtiKWS
 --------------------------------------------------------------------
 Copyright                     : (C) 2006-2013 by Vitaliy Pipich
 Email (use @ for *)  : v.pipich*gmail.com
 Description                 : Matrix Fitting Interface 
 
 ***************************************************************************/

/***************************************************************************
 *                                                                         
 *  This program is free software; you can redistribute it and/or modify   
 *  it under the terms of the GNU General Public License as published by   
 *  the Free Software Foundation; either version 2 of the License, or      
 *  (at your option) any later version.                                    
 *                                                                         
 *  This program is distributed in the hope that it will be useful,       
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         
 *  GNU General Public License for more details.                           
 *                                                                         
 *   You should have received a copy of the GNU General Public License     
 *   along with this program; if not, write to the Free Software           
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor,                    
 *   Boston, MA  02110-1301  USA                                           
 *                                                                         
 ***************************************************************************/

#include "../../src/application.h"
#include <gsl/gsl_blas.h>
#include <gsl/gsl_math.h> 
#include <gsl/gsl_vector.h>
#include <gsl/gsl_integration.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_multifit_nlin.h>
#include <gsl/gsl_multimin.h>
#include <gsl/gsl_errno.h>
#include <gsl/gsl_statistics.h> 
#include <gsl/gsl_spline.h>
#include <qdatetime.h> 
#include <qprocess.h> 
#include <qwidgetlist.h>
#include <qaction.h>
#include <qworkspace.h>
#include <qregexp.h>
#include <qinputdialog.h> 
#include <qaccel.h> 
#include <qprogressdialog.h>
// +++
#include <qfile.h>
#include <qmessagebox.h>
#include <qapplication.h>
#include <qlibrary.h>
#include <qfiledialog.h> 
#include <qtextstream.h> 
#include <qapplication.h>
#include <qprocess.h> 

// +++
#include "../../src/graph.h"
#include "../../src/note.h"
#include "../../src/plot.h"
#include "../../src/multilayer.h"
#include "../../src/FunctionCurve.h"
#include "../../src/colorBox.h"
// +++
#include "fitting-2D.h"
#include "../compile10/compile10.h"
#include "../standart-functions/standartFunctions.h"

#include <iostream>
using namespace std;

#include <problem.h>
#include <genmin.h>
#include <get_options.h>

#include <qtooltip.h>

//*******************************************
//***  alighned :: centred :: limits
//*******************************************
class TableItemMC : public QTableItem
{
public:
    TableItemMC(QTable *table, EditType et, const QString & text );
    int alignment() const { return Qt::AlignCenter;}
    
};
TableItemMC::TableItemMC(QTable *table, EditType et, const QString &text) : QTableItem(table, et, text){};

//*******************************************
//*** alighned ::left  :: limits
//*******************************************
class TableItemML : public QTableItem
{
public:
    TableItemML(QTable *table, EditType et, const QString & text );
    int alignment() const { return Qt::AlignLeft;};
};
TableItemML::TableItemML(QTable *table, EditType et, const QString &text) : QTableItem(table, et, text){};

//*******************************************
//*** Log-output 
//*******************************************
void fitMatrix10::toResLog( QString text)
{    
    QDateTime dt = QDateTime::currentDateTime();
    QString info	=dt.toString("dd.MM | hh:mm ->>FIT::MATRIX>> ") ;
    info+=text;
    info+="\n";
    
    app(this)->logInfo+=info;
    app(this)->actionShowLog->setOn(true);
    app(this)->results->setText(app(this)->logInfo);	
    app(this)->results->scrollToBottom();	
}

//*******************************************
//+++ Initiation-of-Fitting-Dialog
//*******************************************
void fitMatrix10::init()
{    
    //+++ current function 
    libName="";
    pF=0;
    setToSetProgressControl=false;
    
    //+++ path to functions
    QDir dd;
    dd.cd(QDir::homeDirPath());
    dd.cd("./qtiKWS/FitFunctions");
    libPath=dd.path();
    
    //+++ Interface of first page
    textLabelFfunc->hide();                           
    comboBoxFunction->hide();
    textLabelLeft->setEnabled(false);
    pushButtonFitPrev->setEnabled(false);
    pushButtonSaveSession->hide();
    spinBoxPara->hide();
    spinBoxXnumber->hide();
    spinBoxFnumber->hide();
    spinBoxNumberCurvesToFit->hide();
    
    //+++ Para-Table******************
    tablePara->setColumnWidth(0,1);
    tablePara->setColumnWidth(1,45);
    tablePara->setColumnWidth(2,95);
    tablePara->setColumnWidth(3,95);
    
    //+++ Para-Comment******************
    tableParaComments->setLeftMargin(100);
    tableParaComments->setColumnStretchable (0, TRUE);
    tableParaComments00->setLeftMargin(100);
    tableParaComments00->setColumnStretchable (0, TRUE);
    
    //+++ Control-Table******************
    tableControl->setColumnWidth(0,95);
    tableControl->setColumnWidth(1,60);
    tableControl->setColumnWidth(2,115);
    tableControl->setColumnWidth(3,60);    
    tableControl->setColumnWidth(4,95);    
    tableControl->setTopMargin(0);
    tableControl->setLeftMargin(0);
    tableControl->setRowHeight(1,50);
    tableControl->setColumnStretchable(2,true);
    
    //+++ Curves-Table******************     
    tableCurves->setRowReadOnly(2,true);
    tableCurves->setRowReadOnly(3,true);
    tableCurves->setColumnReadOnly(0,false);
    
    //+++ find all groups
    scanGroup(); 
    
    //+++ weightChanged
    weightChanged();
    
    //+++ algorithmSelected
    algorithmSelected();
    
    //+++ connections
    connectSlot();  
}

//*******************************************
//*  Connect Slot
//*******************************************
void fitMatrix10::connectSlot()
{
    //+++ first page
    connect( listBoxGroup, SIGNAL( highlighted(const QString&) ), this, SLOT( groupFunctions(const QString&) ) );
    connect( listBoxFunctions, SIGNAL( highlighted(const QString&) ), this, SLOT( openDLL(const QString&) ) );
    //
    connect( pushButtonFitNext, SIGNAL( clicked() ), this, SLOT( slotStackFitNext() ) );    
    connect( pushButtonFitPrev, SIGNAL( clicked() ), this, SLOT( slotStackFitPrev() ) );
    //
    connect( checkBoxMultiData, SIGNAL( toggled(bool) ), spinBoxNumberCurvesToFit, SLOT( setEnabled(bool) ) );
    connect( checkBoxMultiData, SIGNAL( clicked() ), this, SLOT( initMultiParaTable() ) );
    //
    connect( pushButtonHelp, SIGNAL( clicked() ), this, SLOT( openHelpOnline() ) );
    connect( pushButtonSaveSession, SIGNAL( clicked() ), this, SLOT( saveFittingSession() ) );
    connect( pushButtonLoadFittingSession, SIGNAL( clicked() ), this, SLOT( readSettingsTable() ) );
    
    //+++ 
    connect(tablePara->horizontalHeader(), SIGNAL(clicked(int)), this, SLOT(headerPressedTablePara(int)));
    connect(tablePara->verticalHeader(), SIGNAL(clicked(int)), this, SLOT(vertHeaderPressedTablePara(int)));
    
    //+++
    connect(tableCurves->verticalHeader(), SIGNAL(clicked(int)), this, SLOT(vertHeaderTableCurves(int)));
    connect(tableCurves->horizontalHeader(), SIGNAL(clicked(int)), this, SLOT(horizHeaderCurves(int)));
    
    //+++ Multi-Fit-Table
    connect(tableMultiFit->horizontalHeader(), SIGNAL(clicked(int)), this, SLOT(headerTableMultiFit(int)));
    connect(tableMultiFit, SIGNAL(selectionChanged()), this, SLOT(selectRowsTableMultiFit()));
    
    
    // signals and slots connections
    
    connect( spinBoxPara, SIGNAL( valueChanged(int) ), tablePara, SLOT( setNumRows(int) ) );
    
    connect( spinBoxNumberCurvesToFit, SIGNAL( valueChanged(int) ), this, SLOT( initMultiParaTable() ) );
    connect( pushButtonChiSqr, SIGNAL( clicked() ), this, SLOT( plotSwitcher() ) );
    connect( tableCurves, SIGNAL( valueChanged(int,int) ), this, SLOT( tableCurvechanged(int,int) ) );
    connect( pushButtonMultiFit, SIGNAL( clicked() ), this, SLOT( fitSwitcher() ) );
    connect( spinBoxPara, SIGNAL( valueChanged(int) ), tableParaComments, SLOT( setNumRows(int) ) );
    connect( pushButtonresToLogWindow, SIGNAL( clicked() ), this, SLOT( resToLogWindow() ) );
    connect( pushButtonNewTabRes, SIGNAL( clicked() ), this, SLOT( newTabRes() ) );    
    connect( comboBoxWeightingMethod, SIGNAL( activated(int) ), this, SLOT( weightChanged() ) );
    
    connect( spinBoxPara, SIGNAL( valueChanged(int) ), tableParaSimulate, SLOT( setNumRows(int) ) );
    
    connect( pushButtonDeleteCurves, SIGNAL( clicked() ), this, SLOT( removeSimulatedDatasets() ) );
    connect( pushButtonSimulate, SIGNAL( clicked() ), this, SLOT( simulate() ) );
    connect( pushButtonPattern, SIGNAL( clicked() ), this, SLOT( selectPattern() ) );
    connect( pushButtonSetBySetFit, SIGNAL( clicked() ), this, SLOT( setBySetFit() ) );
    connect( pushButtonSimulateMulti, SIGNAL( clicked() ), this, SLOT( simulateMultifitTables() ) );
    connect( pushButtonSimulateDelete, SIGNAL( clicked() ), this, SLOT( removeSimulatedDatasets() ) );
    
    connect( comboBoxDatasetSim, SIGNAL( activated(int) ), this, SLOT( datasetChangedSim(int) ) );
    
    connect( pushButtonresToActiveGraph, SIGNAL( clicked() ), this, SLOT( addFitResultToActiveGraph() ) );
    connect( pushButtonresToLogWindowOne, SIGNAL( clicked() ), this, SLOT( resToLogWindowOne() ) );
    connect( pushButtonUndo, SIGNAL( clicked() ), this, SLOT( undo() ) );
    connect( pushButtonRedo, SIGNAL( clicked() ), this, SLOT( redo() ) );
    connect( lineEditSetBySetFit, SIGNAL( returnPressed() ), this, SLOT( setBySetFit() ) );
    connect( tablePara, SIGNAL( verticalSliderReleased() ), this, SLOT( tableParaRepaint() ) );
    
    connect( pushButtonSelectFromTable, SIGNAL( clicked() ), this, SLOT( selectMultyFromTable() ) );
    connect( tablePara, SIGNAL( valueChanged(int,int) ), this, SLOT( checkGlobalParameters(int,int) ) );
    
    connect( comboBoxFitMethod , SIGNAL( activated(const QString&) ), this, SLOT( algorithmSelected() ) );     
        
    connect( toolButtonResetLimits, SIGNAL( clicked() ), this, SLOT( initLimits() ) );  
    connect( toolButtonApplyLimits, SIGNAL( clicked() ), this, SLOT( setScaledLimits() ) );     
    
        
    connect( pushButtonBeforeFit, SIGNAL( clicked() ), this, SLOT( beforeFit()));
    connect( pushButtonAfterFit, SIGNAL( clicked() ), this, SLOT( afterFit()));
    
    connect( comboBoxFunction, SIGNAL( activated(const QString&) ), this, SLOT( changeFunctionLocal(const QString&) ) );   
}

//*******************************************
//+++  scan Group
//*******************************************
void fitMatrix10::scanGroup()
{
    int i;
    QString s;
    QStringList group;
    QString groupName;
    
    //group<<"ALL";
    
    // +++ WIN    
#if defined( Q_WS_WIN)
    QString filter="*.dll2d";
    
    // +++  MAC
#elif defined(Q_WS_MAC)
    QString filter="*.dylib2d";    
    
    // +++ UNIX
#else
    QString filter="*.so2d";
#endif
    
    
    QDir d(libPath);
    
    QStringList lstFIF = d.entryList("*.2dfif");
    
    for(i=0;i<lstFIF.count();i++) 
    {
	if (d.exists(lstFIF[i]))
	{
	    QFile f(libPath+"/"+lstFIF[i]);
	    f.open( IO_ReadOnly );
	    QTextStream t( &f );
	    
	    //+++[group]  
	    s = t.readLine();
	    if (s.contains("[group]")>0) 
	    {
		groupName=t.readLine().stripWhiteSpace();
		if (!group.contains(groupName) && groupName!="") group<<groupName;
	    }
	    
	    f.close();
	}
    }
    
    group.sort();
    group.prepend("ALL");
    listBoxFunctions->clear();
    listBoxGroup->clear();
    listBoxGroup->insertStringList (group);
}

//*******************************************
//+++  fing functions of single Group
//*******************************************
void fitMatrix10::groupFunctions( const QString &groupName )
{
    int i;
    QString s;
    QStringList functions;
    
    // +++ WIN    
#if defined( Q_WS_WIN )
    QString filter="*.dll2d";
    
    // +++  MAC
#elif defined(Q_WS_MAC)
    QString filter="*.dylib2d";    
    
    // +++ UNIX     
#else
    QString filter="*.so2d";
#endif
    
    
    QDir d(libPath);
    
    QStringList lst = d.entryList(filter);
    QStringList lstFIF = d.entryList("*.2dfif");
    QStringList lstALL;
    
    
    for(i=0;i<lst.count();i++) 
    {
	QFileInfo fi(libPath+"/"+lst[i]);
	QString base=fi.baseName();
	if (d.exists (lst[i]) && d.exists (base+".2dfif"))
	{
	    lstALL<<base;
	    QFile f(libPath+"/"+base+".2dfif");
	    f.open( IO_ReadOnly );
	    QTextStream t( &f );
	    
	    //+++[group]  
	    s = t.readLine();
	    if (s.contains("[group]")>0) 
	    {
		if (t.readLine().stripWhiteSpace()==groupName) 	functions<<base;
	    }
	    
	    f.close();
	}
    }
    lstALL.sort();
    listBoxFunctions->clear();
    if (groupName=="ALL") 	listBoxFunctions->insertStringList (lstALL);
    else listBoxFunctions->insertStringList (functions);
    
    if (functions.count()>0) listBoxFunctions->setCurrentItem(0);
    else spinBoxPara->setValue(0);
    
}

//*******************************************
//+++  weightChanged
//*******************************************
void fitMatrix10::weightChanged()
{ 
    int currentWeight=comboBoxWeightingMethod->currentItem();
    textLabelWA->hide();
    lineEditWA->hide();
    textLabelWB->hide();
    lineEditWB->hide();
    textLabelWC->hide();
    lineEditWC->hide();
    
    switch ( currentWeight )    {
	
    case 4: 
	textLabelWA->show();
	lineEditWA->show();
	textLabelWB->hide();
	lineEditWB->hide();
	textLabelWC->hide();
	lineEditWC->hide();
	break;
    case 5: 
	textLabelWA->show();
	lineEditWA->show();
	textLabelWB->show();
	lineEditWB->show();
	textLabelWC->show();
	lineEditWC->show();
	break;	

	break;	
	defaulf:
	    textLabelWA->hide();
	    lineEditWA->hide();
	    textLabelWB->hide();
	    lineEditWB->hide();
	    textLabelWC->hide();
	    lineEditWC->hide();
	    break;
	    
	}
}

//*******************************************
//+++  algorithmSelected
//*******************************************
void fitMatrix10::algorithmSelected()
{
    QString newAlgorithm=comboBoxFitMethod->currentText();
    
    if (newAlgorithm.contains("Simplex"))
    {
	buttonGroupGenMin->hide();
	buttonGroupSimplex->show();	
	buttonGroupSimplex->setTitle("Simplex Options");
	lineEditToleranceAbs->hide();
	textLabel2_2->hide();
    }
    else if (newAlgorithm.contains("Levenberg"))
    {
	buttonGroupGenMin->hide();
	buttonGroupSimplex->show();
	
	buttonGroupSimplex->setTitle("Levenberg-Marquardt Options");
	
	lineEditToleranceAbs->show();
	textLabel2_2->show(); 
    }
    else  if (newAlgorithm.contains("[GenMin]"))
    {
	buttonGroupGenMin->show();
	buttonGroupSimplex->hide();
	
	lineEditToleranceAbs->hide();
	textLabel2_2->hide();
	
    }
    
}

//*******************************************
//+++ Init Limits
//*******************************************
void fitMatrix10::initLimits()
{
    //+++
    int PP=spinBoxPara->value();
    
    //+++
    tableControl->setNumRows(0);	
    tableControl->setNumRows(PP);    
    
    //+++
    int digits=spinBoxSignDigits->value();
    
    //+++
    QStringList ccc;
    ccc<<"=<";
    
    double leftLimit, rightLimit;
    QString s;
    for(int pp=0; pp<PP; pp++)	
    {
	//***
	TableItemML *lefted = new TableItemML(tableControl, QTableItem::OnTyping, "-1.0E308");
	tableControl->setItem(pp,0,lefted);
	
	QComboTableItem *cL = new QComboTableItem(tableControl, QString::null );
	tableControl->setItem(pp,1, cL);	
	
	cL->setStringList(ccc);		
	//***
	QComboTableItem *cR = new QComboTableItem(tableControl, QString::null );
	tableControl->setItem(pp,3, cR);
	tableControl->setText(pp,4, "1.0E308");	
	cR->setStringList(ccc);	
	
	
	TableItemMC *centred = new TableItemMC(tableControl, QTableItem::OnTyping, F_paraList[pp]);
	tableControl->setItem(pp,2, centred);
	
	
	s=F_initValues[pp];
	
	if (s.contains('[') && s.contains("..") && s.contains(']'))	    
	{
	    leftLimit=s.mid(s.find("[")+1,s.find("..")-s.find("[") - 1 ).toDouble();
	    rightLimit=s.mid(s.find("..")+2,s.find("]")-s.find("..") - 2 ).toDouble();
	    
	    tableControl->setText(pp,0,QString::number(leftLimit));
	    tableControl->setText(pp,4,QString::number(rightLimit));	    
	}
	
    }
    
}

//*******************************************
//+++ chekLimits
//*******************************************
void fitMatrix10::chekLimits()
{
    //+++
    int PP=spinBoxPara->value();
    
    
    double leftV;
    double rightV;
    
    for(int pp=0; pp<PP; pp++)	
    {
	leftV=-1.0E308;
	rightV=1.0E308;
	
	if (tableControl->text(pp,1).contains("<")) leftV=tableControl->text(pp,0).toDouble();
	if (tableControl->text(pp,3).contains("<")) rightV=tableControl->text(pp,4).toDouble();
	if (rightV<leftV)
	{
	    leftV=-1.0E308;
	    rightV=1.0E308;
	}
	tableControl->setText(pp,0,QString::number(leftV));
	tableControl->setText(pp,4,QString::number(rightV));	
    }
}

//*******************************************
//+++ chekLimitsAndFittedParameters
//*******************************************
void fitMatrix10::chekLimitsAndFittedParameters()
{
    int M=spinBoxNumberCurvesToFit->value();		// Number of Curves
    int p=spinBoxPara->value();				//Number of Parameters per Curve
    
    double leftV;
    double rightV;
    double currentValue;
    
    //+++ Parameters && Sharing && Varying 
    for (int pp=0; pp<p;pp++) 
    {
	leftV=-1.0E308;
	rightV=1.0E308;
	if (tableControl->text(pp,1).contains("<")) leftV=tableControl->text(pp,0).toDouble();
	if (tableControl->text(pp,3).contains("<")) rightV=tableControl->text(pp,4).toDouble();
	
	for (int mm=0; mm<M;mm++)
	{
	    QCheckTableItem *itA0 = (QCheckTableItem *)tablePara->item(pp,3*mm+1); // Vary?	
	    
	    if (itA0->isChecked()) 
	    {		
		currentValue=tablePara->text(pp,3*mm+2).toDouble();
		if (currentValue<leftV) currentValue=leftV;
		if (currentValue>rightV) currentValue=rightV;
	    }
	}
	
    }
}

//*******************************************
//+++ setScaledLimits
//*******************************************
void fitMatrix10::setScaledLimits()
{
    int p=spinBoxPara->value();				//Number of Parameters per Curve
    
    double leftFactor=lineEditLeftMargin->text().toDouble();
    leftFactor=fabs(leftFactor);
    
    double rightFactor=lineEditRightMargin->text().toDouble();
    rightFactor=fabs(rightFactor);
    
    double currentParameter;
    
    for(int i=0;i<p;i++)
    {
	currentParameter=tablePara->text(i,2).toDouble();
	//+++
	if (leftFactor<=1) leftFactor=2;
	
	if (currentParameter>0)
	{	
	    tableControl->setText(i,0,QString::number(currentParameter/leftFactor));
	}
	else if  (currentParameter<0)
	{
	    tableControl->setText(i,0,QString::number(currentParameter*leftFactor));
	}
	else
	{
	    tableControl->setText(i,0,QString::number(-leftFactor));
	}
	
	if (rightFactor<=1) rightFactor=2;
	
	if (currentParameter>0)
	{
	    tableControl->setText(i,4,QString::number(currentParameter*rightFactor));
	}
	else if  (currentParameter<0)
	{
	    tableControl->setText(i,4,QString::number(currentParameter/rightFactor));
	} 
	else
	{
	    tableControl->setText(i,4,QString::number(rightFactor));
	}
    }
    
}

//*******************************************
//* init Multi-Table !v.10
//*******************************************
void fitMatrix10::initMultiParaTable()
{
    int i,j;
    
    int p=spinBoxPara->value();
    
    if (!checkBoxMultiData->isChecked())
    {
	spinBoxNumberCurvesToFit->hide();
	tablePara->setNumCols(4);
	tablePara->setColumnWidth(0,1);
	tablePara->setColumnWidth(1,46);
	tablePara->setColumnWidth(2,135);
	tablePara->setColumnWidth(3,135);
	spinBoxNumberCurvesToFit->setValue(1);
	
	tablePara->setColumnStretchable (2, TRUE);
    }
    else
    {
	spinBoxNumberCurvesToFit->show();
	
	tablePara->setColumnStretchable (2, FALSE);
	tablePara->setColumnWidth(2,135);
	
	tablePara->setNumCols(4);
	tablePara->setColumnWidth(0,52);
	QStringList colNames;
	colNames<<"Share?"<<"Vary?"<<"Value-01"<<"Error-01";
	for (j=0;j<p;j++)
	{		    
	    QCheckTableItem *cb = new QCheckTableItem(tablePara, QString::null );
	    
	    tablePara->setItem(j,0, cb); 
	}		
	for (i=0;i<(spinBoxNumberCurvesToFit->value()-1); i++ )
	{	    
	    if ((i+2)>=10) colNames<<"Vary?"<<"Value-"+QString::number(i+2)<<"Error-"+QString::number(i+2);
	    else colNames<<"Vary?"<<"Value-0"+QString::number(i+2)<<"Error-0"+QString::number(i+2);
	    tablePara->insertColumns(4+3*i,3);
	    tablePara->setColumnWidth(3*(i+1)+1,48);
	    tablePara->setColumnWidth(3*(i+1)+2,90);
	    tablePara->setColumnWidth(3*(i+1)+3,90);
	    for (j=0;j<p;j++)
	    {
		QCheckTableItem *cb = new QCheckTableItem(tablePara, QString::null );
		tablePara->setItem(j,3*(i+1)+1, cb);
	    }		
	}
	tablePara->setColumnLabels(colNames);
    }
}

void fitMatrix10::initFitPage()
{
    initFitPage(true);
}

//*******************************************
//*Init Fitting Page !v.10
//*******************************************
void fitMatrix10::initFitPage(bool functionChanged)
{
    int M=spinBoxNumberCurvesToFit->value();
    int xNumber=spinBoxXnumber->value();
    //+++    
    
    int mm,pp;
    double temp;
    QString s;
    QStringList colNames;    
    
    tableSimX->setNumRows(0);
    tableSimX->setNumRows(xNumber+1);
    
    //+++
    QStringList tableXNames; tableXNames<<"Data"<<"Mask"<<"Weight";   
    for(int i=2; i<xNumber; i++) tableXNames<<"x["+QString::number(i+1)+"]: "+'"'+x_Names[i]+'"';
    
    tableSimX->setLeftMargin(70);  
    //+++
    tableSimX->setRowLabels(tableXNames);
    tableSimX->setColumnStretchable ( 0, true) ;
    tableSimX->horizontalHeader()->hide(); 
    
    for(int i=0; i<(xNumber+1); i++)
    {
	QComboTableItem *xMatrix = new QComboTableItem(tableSimX, QString::null );
	tableSimX->setItem(i,0, xMatrix);
	
    }
    
    
    //+++
    bool increasedNQ=false;
    int xNumberOld=tableCurves->numRows()-5+2;    
    if (tableCurves->numRows()<(5+xNumber-2)) increasedNQ=true;
    
    //+++ 
    bool increasedM=false;
    int Mold=tableCurves->numCols()/2;
    if (tableCurves->numCols()<(2*M)) increasedM=true;
    
    //+++ tableCurves :: init/re-init   
    tableCurves->setNumRows(5+xNumber-2);
    tableCurves->setNumCols(2*M); 
    
    //+++
    tableCurves->setLeftMargin(70);
    
    //+++ row-labels
    if (increasedNQ)
    {
	QStringList tableCurvesNames;
	tableCurvesNames<<"Data(s)"<<"Mask"<<"# Rows"<<"# Columns"<<"Weighting";
	for(int i=2; i<xNumber; i++) tableCurvesNames<<"x["+QString::number(i+1)+"]: "+'"'+x_Names[i]+'"';
	//+++
	tableCurves->setRowLabels(tableCurvesNames);
    }
    
    
    //+++ Set Data-Sets List
    for(mm=0;mm<M;mm++)		
    {
	tableCurves->setColumnWidth(2*mm,46);	
	
	if (M==1) 
	{
	    tableCurves->setColumnStretchable (1, TRUE);
	}
	else  if (M==2) 
	{
	    tableCurves->setColumnStretchable (2*mm+1, TRUE);	  
	}
	else
	{
	    tableCurves->setColumnStretchable (1, FALSE);
	    tableCurves->setColumnStretchable (3, FALSE);
	    tableCurves->setColumnWidth(2*mm+1,135);
	}
	
	colNames<<"Use?"<<"Matrix-"+QString::number(mm+1);
	
	if (mm>=Mold || Mold==0)
	{
	    //+++ Use Mask?
	    QCheckTableItem *useMask = new QCheckTableItem(tableCurves, QString::null );
	    tableCurves->setItem(1,2*mm, useMask);
	    
	    //+++ Mask Matrixes
	    QComboTableItem *maskM = new QComboTableItem(tableCurves, QString::null );
	    tableCurves->setItem(1,2*mm+1, maskM);
	    
	    //+++ CheckTableItem: Weighting
	    QCheckTableItem *cbW = new QCheckTableItem(tableCurves, QString::null );
	    tableCurves->setItem(4,2*mm, cbW);
	    
	    //+++ Data sets selection ComboBox
	    QString oldYcol="";
	    if ((QComboTableItem*)tableCurves->item (0, 2*mm+1))
	    {QComboTableItem *xxx =(QComboTableItem*)tableCurves->item (0, 2*mm+1);
		oldYcol=xxx->currentText();}
	    QComboTableItem *curve = new QComboTableItem(tableCurves, QString::null );
	    tableCurves->setItem(0,2*mm+1, curve);
	    curve->setStringList(findAllMatrixes());
	    if (oldYcol!="") curve->setCurrentItem(oldYcol);
	    
	    QStringList list;
	    int nRows, nCols;
	    
	    if ( findAllMatrixesLikeExample(curve->currentText(), list, nRows, nCols) )
	    {
		oldYcol=maskM->currentText();
		maskM->setStringList(list);
		if (oldYcol!="" && list.contains(oldYcol)) maskM->setCurrentItem(oldYcol);
		
		tableCurves->setText(2,2*mm+1, QString::number(nRows));
		tableCurves->setText(3,2*mm+1, QString::number(nCols));
	    }
	    
	    
	    //+++ Weight Set selection CimboBox 
	    QComboTableItem *weight = new QComboTableItem(tableCurves, QString::null );
	    tableCurves->setItem(4,2*mm+1, weight);
	    
	    QString table=curve->currentText();
	    table=table.left(table.find("_",0));
	    
	    for(int i=2; i<xNumber; i++)
	    {
		QComboTableItem *xMatrix = new QComboTableItem(tableCurves, QString::null );
		tableCurves->setItem(5+i-2,2*mm+1, xMatrix);
		
	    }
	    
	    //+++ Fill weight, reso, poly , data sets combo-boxes
	    colList(table,2*mm+1);
	}	
	else if ( increasedNQ)
	{
	    QString table=  tableCurves->text(0,2*mm+1);
	    table=table.left(table.find("_",0));
	    
	    for(int i=xNumberOld; i<xNumber; i++)
	    {
		QComboTableItem *xMatrix = new QComboTableItem(tableCurves, QString::null );
		tableCurves->setItem(5+i-2,2*mm+1, xMatrix);
	    }
	    
	    //+++ Fill weight, reso, poly , data sets combo-boxes
	    colList(table,2*mm+1);	  
	}
	
    }			
    
    //+++ Initiation of multi-Set Tables
    initMultiParaTable();
    
    //+++ Set Column Labels 
    tableCurves->setColumnLabels(colNames);	    
    
    //+++ Set Table Labels 
    tablePara->setRowLabels(F_paraList);
    tablePara->verticalHeader()->adjustHeaderSize(); 
    //+++ Set Table Labels Simulate
    tableParaSimulate->setRowLabels(F_paraList);
    tableParaSimulate->setLeftMargin (130);
    tableParaSimulate->setColumnStretchable (0, TRUE);
    //+++ Comment table
    tableParaComments->setRowLabels(F_paraList);
    
    //+++ Function description 
    if (F_paraListComments.count() ==0) 
	textBrowserFunctionDescription->setText("<center>...sorry, but no description of Function is available...</center>"); 
    else 
	textBrowserFunctionDescription->setText(F_paraListComments[0]); 
    
    //
    int PP=spinBoxPara->value();
    //
    int digits=spinBoxSignDigits->value()-1;
    for(pp=0; pp<PP; pp++)	
    {
	s=F_initValues[pp];
	
	if (s.contains('[') && s.contains("..") && s.contains(']'))	    
	{
	    temp=s.left(s.find("[")).toDouble();	    
	}
	else
	    temp=s.toDouble();
	
	for (mm=0; mm<M;mm++)
	{	    
	    tablePara->setText(pp,3*mm+2,QString::number(temp, 'G', digits+1));
	    tablePara->setText(pp,3*mm+3,"---");
	    QCheckTableItem *cb = new QCheckTableItem(tablePara, QString::null );
	    tablePara->setItem(pp,3*mm+1, cb);
	    if (F_adjustPara[pp]=="1") cb->setChecked(true); else cb->setChecked(false);
	}
	gsl_vector_set(F_para,pp,s.toDouble());
	
	//Comment table
	if (F_paraListComments.count() <= 1) tableParaComments->setText(pp,0,"sorry, but no description available"); 
	else tableParaComments->setText(pp,0,F_paraListComments[pp+1]); 
    }
    
    F.params=&F_para;
    
    
    
}

//*******************************************
// +++ init Multi Table  !v.10
//*******************************************
void fitMatrix10::initMultiTable()
{
    if (spinBoxNumberCurvesToFit->value()==1)
    {
	int cols=spinBoxPara->value()+3; 
	
	tableMultiFit->setNumCols(cols);
	tableMultiFit->setNumRows(1);	
	tableMultiFit->setColumnWidth(0,30);
	
	int i;
	
	for (i=1;i<cols;i++)
	{
	    tableMultiFit->setColumnWidth(i,60);
	    // +++
	    QCheckTableItem *yn = new QCheckTableItem(tableMultiFit, QString::null );
	    tableMultiFit->setItem(0,i, yn);
	}
	
	// +++ mke Buttoms active
	pushButtonPattern->setEnabled(true);
	pushButtonSetBySetFit->setEnabled(true);
	pushButtonSimulateMulti->setEnabled(true);
	pushButtonSelectFromTable->setEnabled(true);
	
    }
    else
    {
	tableMultiFit->setNumCols(0);
	tableMultiFit->setNumRows(1);
	// +++ mke Buttoms active
	pushButtonPattern->setEnabled(false);
	pushButtonSetBySetFit->setEnabled(false);
	pushButtonSimulateMulti->setEnabled(false);
	pushButtonSelectFromTable->setEnabled(false);
    }
}

//*******************************************
//*Page-to-Page !v.10
//*******************************************
void fitMatrix10::slotStackFitPrev()
{
    int id=widgetStackFit->id(widgetStackFit->visibleWidget ());
    
    widgetStackFit->raiseWidget(id-1);
    
    if (id==1) 
    {
	textLabelLeft->setText("...");
	textLabelCenter->setText("Select Function");
	textLabelRight->setText("Fitting Session");
	textLabelFfunc->hide();
	comboBoxFunction->hide(); 
	//	if(comboBoxFunction->currentItem()!=listBoxFunctions->currentItem()) listBoxFunctions->setCurrentItem(comboBoxFunction->currentItem());
	
	textLabelLeft->setEnabled(false);
	//pushButtonFitPrev->hide();
	pushButtonFitPrev->setEnabled(false);
	spinBoxPara->hide();
	spinBoxXnumber->hide();
	spinBoxFnumber->hide();
	//
	pushButtonUndo->setEnabled(FALSE);
	pushButtonRedo->setEnabled(FALSE);
	undoRedo.clear();
	undoRedoActive=0;
	pushButtonLoadFittingSession->show();
	textLabelInfoSAS->show();
	textLabelInfo_2_2->show();
	textLabelInfo_2->show();
	pushButtonHelp->show();
	
	//listBoxGroup->setCurrentItem(0);
	
	pushButtonSaveSession->hide();
	
	if(comboBoxFunction->currentItem()!=listBoxFunctions->currentItem()) listBoxFunctions->setCurrentItem(comboBoxFunction->currentItem());
	
    }
    else if (id==2)
    {
	
	textLabelLeft->setText("Select Function");
	textLabelCenter->setText("Fitting Session");
	textLabelRight->setText("Generate Results");
	textLabelLeft->setEnabled(TRUE);
	pushButtonFitPrev->setEnabled(true);
	
	textLabelRight->setEnabled(true);
	pushButtonFitNext->setEnabled(true);
	pushButtonLoadFittingSession->hide();
	textLabelInfoSAS->hide();
	textLabelInfo_2_2->hide();
	textLabelInfo_2->hide();
	pushButtonHelp->hide();
	
	comboBoxDatasetSim->clear();
	
	updateDatasets();
    }
}

//*******************************************
//+++ slotStackFitNext 
//*******************************************
void fitMatrix10::slotStackFitNext()
{
    int id=widgetStackFit->id(widgetStackFit->visibleWidget ()); 
    int p=spinBoxPara->value();
    
    if (id==0) 
    {
	if (p==0) 
	{
	    QMessageBox::warning(this ,tr("QtiKWS "), tr("Select Function!")); return;
	}	
	//+++
	pushButtonLoadFittingSession->hide();
	pushButtonSaveSession->show();
	
	textLabelLeft->setText("Select Function");
	textLabelCenter->setText("Fitting Session");
	textLabelRight->setText("Generate Results");
	textLabelFfunc->show();
	comboBoxFunction->show(); 
	textLabelLeft->setEnabled(TRUE);
	pushButtonFitPrev->setEnabled(true);		
	textLabelRight->setEnabled(true);	
	pushButtonFitNext->setEnabled(true);	
	spinBoxPara->show();
	spinBoxXnumber->show();
	spinBoxFnumber->show();
	spinBoxFnumber->setValue(spinBoxNumberCurvesToFit->value());
	
	//+++	
	textLabelInfoSAS->hide();
	textLabelInfo_2_2->hide();
	textLabelInfo_2->hide();
	pushButtonHelp->hide();
		
	//+++ init(reinit) table of limits
	initLimits();
	
	//+++
	initFitPage();
	
	// +++
	initMultiTable();
	vertHeaderTableCurves(0);
	
	//+++
	saveUndo();	
	
	if(checkBoxMultiData->isChecked()) checkBoxAllInOne->show();
	else checkBoxAllInOne->hide();
	
    }
    else if (id==1)
    {
	//+++
	textLabelLeft->setText("Fitting Session");
	textLabelCenter->setText("Generate Results");
	textLabelRight->setText("...");
	textLabelLeft->setEnabled(TRUE);
	pushButtonFitPrev->setEnabled(true);	
	textLabelRight->setEnabled(FALSE);	
	pushButtonFitNext->setEnabled(FALSE);	
	
	//+++ Simulate
	datasetChangedSim(0);	
	
	// +++ multifit
	int cols=spinBoxPara->value()+3;
	
	QStringList colNames;
	colNames<<"fit?"<<"[Mask]"<<"[Weight]";
	
	colNames+=F_paraList;
	
	tableMultiFit->setColumnLabels(colNames);
	pushButtonLoadFittingSession->hide();
	textLabelInfoSAS->hide();
	textLabelInfo_2_2->hide();
	textLabelInfo_2->hide();
	pushButtonHelp->hide();
	
	simRows->setEnabled(false);
	simCols->setEnabled(false);
    }
    widgetStackFit->raiseWidget(id+1);        
}


//*******************************************
//+++ open-DLL
//*******************************************
void fitMatrix10::openDLL( const QString &file )
{
    // +++ WIN    
#if defined( Q_WS_WIN) 
    QString filter=".dll2d";
    
    // +++  MAC
#elif defined(Q_WS_MAC)
    QString filter=".dylib2d";    
    
    // +++ UNIX     
#else
    QString filter=".so2d";
    
#endif
    
    QString pluginName = libPath+"/"+file+filter;
    
    openDLLgeneral(pluginName);
}

//*******************************************
//+++ openDLLgeneral
//*******************************************
void fitMatrix10::openDLLgeneral(QString file)		
{
    spinBoxXnumber->setValue(2);
    //+++ Lists 
    F_paraList.clear(); 
    F_initValues.clear();
    F_adjustPara.clear();
    F_paraListComments.clear();
    //+++ F
    F_paraListF.clear();
    F_initValuesF.clear();
    F_adjustParaF.clear();
    F_paraListCommentsF.clear();
    //+++
    int p=0;
    pF=0;
    //+++
    QString pluginName = file;
    //+++
    if (pluginName.isEmpty())
    {
	QMessageBox::warning(this,tr("QtiKWS"), tr("Error: <p> DLL or LIB"));
	return;
	p=0; pF=0;
	spinBoxPara->setValue(0);
    }
    //+++
    if (!QFile::exists (pluginName))
    {
	QMessageBox::warning(this,tr("QtiKWS"), tr("Error: <p>*.dll2d OR *.so2d OR *.dylib2d"));
	return;
	p=0; pF=0;
	spinBoxPara->setValue(0);
    }
    //+++
    if (libName!="")
    {
	lib->unload(); 
	p=0; pF=0;
	spinBoxPara->setValue(0);
    }
    //+++
    pluginName.replace("//","/");
    setName(pluginName);	
    //+++    
    libName=pluginName;
    lib = new QLibrary(pluginName);	
    
    typedef char* (*fitFuncChar)();
    
    QString F_name;
    
    //+++ Resolve Name of Function
    fitFuncChar fitFunctionChar = (fitFuncChar) lib->resolve("name");
    if (fitFunctionChar)
    {
	F_name=QString(fitFunctionChar());
	//+++ Set Function Name
	textLabelFfunc->setText(F_name);	
	//+++
	comboBoxFunction->clear();
	QStringList lst;
	for(int i=0;i<listBoxFunctions->count();i++) lst<<listBoxFunctions->text(i);
	comboBoxFunction->insertStringList(lst);
	comboBoxFunction->setCurrentItem(listBoxFunctions->currentItem());
    } 
    else
    {
	p=0; pF=0;
	spinBoxPara->setValue(0);
	QMessageBox::warning(this,tr("QtiKWS"), tr("Error: <p>check function 1"));
	return;
    }
    
    //+++ Parameter`s Number
    fitFunctionChar=(fitFuncChar) lib->resolve(libName,"paraNumber");
    pF=QString(fitFunctionChar()).toInt(); //cout<<pF<<"\n";
    if (pF<1)
    {
	p=0; pF=0;
	spinBoxPara->setValue(0);
	QMessageBox::warning(this,tr("QtiKWS"), tr("Error: <p>check function 3"));
    }
    
    //+++ Parameter`s Names
    fitFunctionChar = (fitFuncChar)  lib->resolve("parameters");
    if (fitFunctionChar)
    {	
	F_paraListF = QStringList::split(",", QString(fitFunctionChar()), false);
	if (F_paraListF.count()==(pF+1) && F_paraListF[pF]!="")
	{
	    F_paraListF.remove(F_paraListF.at(pF));
	}
    }
    else
    {
	p=0; pF=0;
	spinBoxPara->setValue(0);
	QMessageBox::warning(this,tr("QtiKWS"), tr("Error: <p>check function 2"));
	return;
    }
    
    //+++ Parameter`s Names
    x_Names.clear();
    fitFunctionChar = (fitFuncChar)  lib->resolve("xName");
    if (fitFunctionChar)
    {	
	x_Names = QStringList::split(",", QString(fitFunctionChar()), false);
	if (x_Names.count()>2)
	    spinBoxXnumber->setValue(x_Names.count());
    }
    
    //+++ Parameter`s Init Values
    fitFunctionChar = (fitFuncChar)  lib->resolve("init_parameters");
    if (fitFunctionChar)
    {	
	F_initValuesF = QStringList::split(",", QString(fitFunctionChar()), false);
    }
    
    //+++ Parameter`s Adjust Parameters
    fitFunctionChar = (fitFuncChar)  lib->resolve("adjust_parameters");
    if (fitFunctionChar)
    {	
	F_adjustParaF = QStringList::split(",", QString(fitFunctionChar()), false);
    }
    
    //+++ listComments
    fitFunctionChar=(fitFuncChar) lib->resolve("listComments");
    if (fitFunctionChar)
    {	
	F_paraListCommentsF = QStringList::split(",,", QString(fitFunctionChar()), false);
    }
    
    //+++ Function
    typedef double (*fitFuncD)(double, void* );
    fitFuncD f_fit;
    f_fit = (fitFuncD) lib->resolve("functionSANS");
    
    if (!f_fit)
    {
	p=0; pF=0;
	spinBoxPara->setValue(0);
	QMessageBox::warning(this,tr("QtiKWS"), tr("Error: <p>check function 4"));
	return;
    }
    
    F.function=f_fit;
    
    F_paraList=F_paraListF;
    F_initValues=F_initValuesF;
    F_adjustPara=F_adjustParaF;
    F_paraListComments=F_paraListCommentsF;   
    
    if (pF!=0) 
    {
	p=pF;
    }
    
    if (p)
    {
	spinBoxPara->setValue(p);
    }
    else
    {
	p=0;
	return;
    }
    
    //+++ Function Parameters Allocation
    F_para= gsl_vector_alloc(p);
    
    //+++
    tableParaComments00->setNumRows(0);	
    tableParaComments00->setNumRows(pF);    
    tableParaComments00->setRowLabels(F_paraList);
    tableParaComments00->setLeftMargin(130);
    tableParaComments00->setColumnStretchable (0, TRUE);
    
    int i;
    for(i=0;i<p;i++) tableParaComments00->setText(i,0,F_paraListComments[i+1]);
    
    textBrowserFunctionDescription00->setText(F_paraListComments[0]);  
}

//*******************************************
//  check new values in tableCurve !OB
//*******************************************
void fitMatrix10::tableCurvechanged( int raw, int col )
{
    
    if( ((col/2)*2)!=col ) 
    {
	// +++
	if (raw==0)
	{
	    // Selected data to Fit
	    QString table=tableCurves->text(raw,col);
	    table=table.left(table.find("_",0));
	    // then set lists for dI and sigmaReso ; and Number of points
	    colList(table,col);
	    
	}
    }
    else
    {
	
	if (raw==0) 
	{
	    QComboTableItem *comboList = (QComboTableItem*)tableCurves->item (0,col+1);
	    QString pattern=tableCurves->text(0,col);
	    int iNumber=comboList->count();
	    int oldNumber=comboList->currentItem();
	    
	    if (!comboList->currentText().contains(pattern))
	    {
		int i=0;
		while ( i<iNumber) { if (comboList->text(i).contains(pattern) ) break; i++;};
		if (i>=iNumber) comboList->setCurrentItem(oldNumber); else comboList->setCurrentItem(i);
	    }
	}
    }
    
}

//*******************************************
// slot: fit results to "res" winwow !OB
//*******************************************
void fitMatrix10::resToLogWindow()
{
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value();
    QString F_name=textLabelFfunc->text();
    
    QDateTime dt = QDateTime::currentDateTime ();
    QString info = "[ " + dt.toString(Qt::LocalDate)+ " ]\n";
    info += tr("Fit Method") + ": " +comboBoxFitMethod->currentText() +"\n";
    info += tr("Using Function") + ": " + F_name + "\n";
    for (int mm=0;mm<M;mm++) 
    {
	info+=tableCurves->text(0,2*mm+1)+ " : \n";
	for (int pp=0;pp<p;pp++) 
	{
	    info+= F_paraList[pp]+" = "+tablePara->text(pp,3*mm+2);
	    
	    if (tablePara->text(pp,3*mm+3)!="---")
	    {
		info+=" ";
		info+=QChar(177);
		info+=" "+tablePara->text(pp,3*mm+3);
	    }
	    info+="\n";
	}
    }
    info+="chi^2 = "+textLabelChi->text()+"\n";
    info+="R^2 = "+textLabelR2->text()+"\n";
    info+="time = "+textLabelTime->text()+"\n";
    info=info+"-------------------------------------------------------------"+"\n";
    
    app(this)->logInfo+=info;
    app(this)->actionShowLog->setOn(true);
    app(this)->results->setText(app(this)->logInfo);   
    app(this)->results->scrollToBottom();	
}

//*******************************************
// slot: fit results to "res" window (one line) !OB
//*******************************************
void fitMatrix10::resToLogWindowOne()
{
    int p=spinBoxPara->value();
    int M=spinBoxNumberCurvesToFit->value();
    QString F_name=textLabelFfunc->text();
    
    QDateTime dt = QDateTime::currentDateTime ();
    QString info = "[ " + dt.toString(Qt::LocalDate)+ " ]\n";
    info += tr("Fit Method") + ": " +comboBoxFitMethod->currentText() +"\n";
    info += tr("Using Function") + ": " + F_name + "\n";
    int pp,mm;
    for (pp=0;pp<p;pp++) 
    {
	info+= F_paraList[pp]+"\t"+F_paraList[pp]+"-error\t";
    }	
    info+="\n";
    for (mm=0;mm<M;mm++) 
    {
	for (pp=0;pp<p;pp++) 
	{
	    info+= tablePara->text(pp,3*mm+2)+"\t "+tablePara->text(pp,3*mm+3)+"\t";
	}
	info+="\n";
	info+="("+tableCurves->text(0,2*mm+1)+ ")  \n";
    }
    info+="chi^2 = "+textLabelChi->text()+"\n";
    info+="R^2 = "+textLabelR2->text()+"\n";
    info+="time = "+textLabelTime->text()+"\n";
    info=info+"-------------------------------------------------------------"+"\n";
    
    app(this)->logInfo+=info;
    app(this)->results->setText(app(this)->logInfo);
    app(this)->results->scrollToBottom();	
}

//*******************************************
// slot: make NEW table with fit results !OB
//*******************************************
void fitMatrix10::newTabRes()
{
    QStringList RES;
    QString F_name=textLabelFfunc->text();
    
    RES<<F_name<<QString::number(spinBoxPara->value())<<QString::number(spinBoxNumberCurvesToFit->value());
    //	RES<<comboBoxHorV->currentText ();
    RES+=d_param_names;
    RES<<"chi^2="+textLabelChi->text()<<"time="+textLabelTime->text();
    int mm=0, pp=0;
    for (mm=0;mm<spinBoxNumberCurvesToFit->value();mm++)
	for (pp=0;pp<spinBoxPara->value();pp++)
	{
	RES<< tablePara->text(pp, 3*mm+2)<<tablePara->text(pp, 3*mm+2);
    }
    
    // +++ NewTabRes(RES)
    
    int p=spinBoxPara->value();
    int M=spinBoxNumberCurvesToFit->value();
    Table* w;
    
    QString temp=app(this)->generateUniqueName(tr("newFitMatrix"+F_name));
    
    w=app(this)->newTable(temp, GSL_MAX(p, 6), 3+2*M);
    w->setTextFormat(TRUE);
    
    // First Col
    w->setText(0,0,"Fitting Function"); 
    w->setText(0,1,"->   "+F_name);
    //
    w->setText(1,0,"Number of Parameters");
    w->setText(1,1, "->   "+QString::number(p) ); 
    //
    w->setText(2,0,"Number of data sets M");
    w->setText(2,1,"->   "+QString::number(M));
    //
    w->setText(3,0,"chi^2");
    w->setText(3,1,"->   "+textLabelChi->text());
    //
    w->setText(4,0,"R^2");
    w->setText(4,1,"->   "+textLabelR2->text());
    //
    w->setText(5,0,"Time of Fit");
    w->setText(5,1,"->   "+textLabelTime->text());
    //
    w->setColName(0,"Characteristics");
    w->setColName(1,"Conditions");
    w->setColName(2,"Parameters");
    
    
    QString yn0="";
    
    for (pp=0;pp<p;pp++){w->setText(pp,2,F_paraList[pp]);};
    
    for (mm=0;mm<M;mm++)
    {
	if (mm>=9) yn0=""; else yn0="0";
	w->setColName(2*mm+3,"Value"+yn0+QString::number(mm+1));
	w->setColName(2*mm+4,"Error"+yn0+QString::number(mm+1));
	for (pp=0;pp<p;pp++)
	{
	    w->setText(pp, 3+2*mm, tablePara->text(pp, 3*mm+2));
	    w->setText(pp, 4+2*mm, tablePara->text(pp, 3*mm+3));
	}
    }
    
}

//*******************************************
// slot: make NEW table with fit results  ?OB
//*******************************************
void fitMatrix10::saveFittingSession()
{
    bool ok;
    int p=spinBoxPara->value();
    int M=spinBoxNumberCurvesToFit->value();
    QString F_name=textLabelFfunc->text();
    
    QString table = QInputDialog::getText("Input ", "Enter table name to save [2D] fitting session:", QLineEdit::Normal,
					  QString::null, &ok, this );
    if ( ok && !table.isEmpty() ) 
    {
	// user entered something and pressed OK
    } else 
    {
	return;
    }
    
    Table* w;
    
    if (checkTableExistence(table, w) )
    {
	if (w->windowLabel()!="FIT2D::Settings::Table")
	{
	    QMessageBox::critical( 0, "QtiKWS", "Table "+table+" is not [2D] fitting-settings table");
	    return;
	}	
	w->setNumRows(0);
	w->setNumCols(2);
    }
    else 
    {
	w=app(this)->newHiddenTable(table,"FIT2D::Settings::Table", 0, 2);
	//+++ new
	w->setWindowLabel("FIT2D::Settings::Table");
	app(this)->setListViewLabel(w->name(), "FIT2D::Settings::Table");
	app(this)->updateWindowLists(w);
    }
    
    
    
    //Col-Names
    QStringList colType;
    w->setColName(0,"Parameter"); w->setColPlotDesignation(0,Table::None);colType<<"1";
    w->setColName(1,"Parameter-Value"); w->setColPlotDesignation(1,Table::None);colType<<"1";
    w->setColumnTypes(colType);
    
    
    
    int currentRow=0;
    QString s;
    
    //----- Function::Folder
    w->setNumRows(currentRow+1);
    s=libPath+" <";
    w->setText(currentRow, 0, "Function::Folder");
    w->setText(currentRow, 1, s);
    currentRow++;
    
    //----- Function::Name
    w->setNumRows(currentRow+1);
    s=textLabelFfunc->text()+" <";
    w->setText(currentRow, 0, "Function::Name");
    w->setText(currentRow, 1, s);
    currentRow++;
    
    //+++ Function::Parameters::Number
    w->setNumRows(currentRow+1);            
    s=QString::number(p)+" ";
    w->setText(currentRow,0,"Function::Parameters::Number");
    w->setText(currentRow,1,s+" <");
    currentRow++;
    
    //+++ Function::Global::Fit
    w->setNumRows(currentRow+1);        
    w->setText(currentRow,0,"Function::Global::Fit");
    if (checkBoxMultiData->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");       
    currentRow++;
    
    //+++ Function::Global::Fit::Number
    w->setNumRows(currentRow+1);            
    s=QString::number(M)+" ";
    w->setText(currentRow,0,"Function::Global::Fit::Number");
    w->setText(currentRow,1,s+" <");
    currentRow++;
    
    //+++ Session::Data::Datasets   0
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++) 
	s+=tableCurves->text(0,2*i+1)+" ";
    w->setText(currentRow,0,"Session::Data::Matrixes");
    w->setText(currentRow,1,s+" <");
    currentRow++;    
    
    //+++ Session::Mask::Use
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++)
    {
	QCheckTableItem *active = (QCheckTableItem *)tableCurves->item(1,2*i);	
	if (active->isChecked()) s+="1 "; else s+="0 ";
    }
    w->setText(currentRow,0,"Session::Mask::Use");
    w->setText(currentRow,1,s+" <");
    currentRow++; 
    
    //+++ Session::Mask::Names
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++) 
	s+=tableCurves->text(1,2*i+1)+" ";
    w->setText(currentRow,0,"Session::Mask::Names");
    w->setText(currentRow,1,s+" <");
    currentRow++;    
    
    
    //+++ Session::Weighting::Use
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++)
    {
	QCheckTableItem *active = (QCheckTableItem *)tableCurves->item(4,2*i);	
	if (active->isChecked()) s+="1 "; else s+="0 ";
    }
    
    w->setText(currentRow,0,"Session::Weighting::Use");
    w->setText(currentRow,1,s+" <");
    currentRow++; 
    
    
    //+++ Session::Weighting::Dataset
    w->setNumRows(currentRow+1);            
    s="";
    for (int i=0; i<M;i++) 
	s+=tableCurves->text(4,2*i+1)+" ";
    w->setText(currentRow,0,"Session::Weighting::Dataset");
    w->setText(currentRow,1,s+" <");
    currentRow++;        
    
    //+++ Session::xMatrixes::Dataset
    w->setNumRows(currentRow+1);            
    s="";
    int xNumbers=spinBoxXnumber->value()-2;
    
    for (int i=0; i<M;i++) for (int xx=0; xx< xNumbers;xx++) 
	s+=tableCurves->text(5+xx,2*i+1)+" ";
    w->setText(currentRow,0,"Session::xMatrixes::Dataset");
    w->setText(currentRow,1,s+" <");
    currentRow++;        
    
    //+++ Session::Limits::Left
    w->setNumRows(currentRow+1);            
    s="";
    for (int pp=0; pp<p;pp++)
	s+=tableControl->text(pp,0)+" ";
    w->setText(currentRow,0,"Session::Limits::Left");
    w->setText(currentRow,1,s+" <");
    currentRow++;  
    
    //+++ Session::Limits::Right
    w->setNumRows(currentRow+1);            
    s="";
    for (int pp=0; pp<p;pp++)
	s+=tableControl->text(pp,4)+" ";
    w->setText(currentRow,0,"Session::Limits::Right");
    w->setText(currentRow,1,s+" <");
    currentRow++;  
    
    //+++ Session::Limits::Scale::Left
    w->setNumRows(currentRow+1);            
    s=lineEditLeftMargin->text();
    w->setText(currentRow,0,"Session::Limits::Scale::Left");
    w->setText(currentRow,1,s+" <");
    currentRow++; 
    
    //+++ Session::Limits::Scale::Right
    w->setNumRows(currentRow+1);            
    s=lineEditRightMargin->text();
    w->setText(currentRow,0,"Session::Limits::Scale::Right");
    w->setText(currentRow,1,s+" <");
    currentRow++; 
    
    
    //+++ Session::Options::Fit::Control
    w->setNumRows(currentRow+1);            
    s=QString::number(comboBoxFitMethod->currentItem())+" ";
    s+=QString::number(spinBoxMaxIter->value())+" ";
    s+=lineEditToleranceAbs->text()+" ";    
    s+=lineEditTolerance->text()+" ";
    s+=QString::number(spinBoxSignDigits->value())+" ";
    s+=QString::number(comboBoxWeightingMethod->currentItem())+" ";	
    if (checkBoxShowCurvesInGraph->isChecked()) s+="1 "; else s+="0 ";
    s+=lineEditWA->text()+" ";
    s+=lineEditWB->text()+" ";
    s+=lineEditWC->text()+" ";
    s+=QString::number(spinBoxGenomeCount->value())+" ";
    s+=QString::number(spinBoxMaxNumberGenerations->value())+" ";
    s+=lineEditSelectionRate->text()+" ";
    s+=lineEditMutationRate->text()+" ";
    s+=QString::number(spinBoxRandomSeed->value())+" ";
    
    w->setText(currentRow,0,"Session::Options::Fit::Control");
    w->setText(currentRow,1,s+"<");
    currentRow++;
    
    
    //+++
    if (checkBoxMultiData->isChecked())
    {
	//+++ Session::Parameters::Shared
	w->setNumRows(currentRow+1);            
	s="";
	for (int pp=0; pp<p;pp++)
	{
	    QCheckTableItem *active = (QCheckTableItem *)tablePara->item(pp,0);	
	    if (active->isChecked()) s+="1 "; else s+="0 ";
	}
	
	w->setText(currentRow,0,"Session::Parameters::Shared");
	w->setText(currentRow,1,s+" <");
	currentRow++;
	
	
    }
    
    //+++
    for (int pp=0;pp<p;pp++)
    {
	QString uselName="Session::Parameters::Use::"+QString::number(pp+1);
	
	//+++ Session::Parameters::Use::pp+1
	w->setNumRows(currentRow+1);            
	s="";
	for (int i=0; i<M;i++)
	{
	    QCheckTableItem *active = (QCheckTableItem *)tablePara->item(pp,3*i+1);	
	    if (active->isChecked()) s+="1 "; else s+="0 ";
	}
	
	w->setText(currentRow,0,uselName);
	w->setText(currentRow,1,s+" <");
	currentRow++;
	
	QString cellName="Session::Parameters::Values::"+QString::number(pp+1);
	
	//+++Session::Parameters::Values::pp+1
	w->setNumRows(currentRow+1);            
	s="";
	for (int i=0; i<M;i++) 
	    s+=tablePara->text(pp,3*i+2)+" ";
	w->setText(currentRow,0,cellName);
	w->setText(currentRow,1,s+" <");
	currentRow++;
    }    
    
    //+++Session::Parameters::Errors
    w->setNumRows(currentRow+1);   
    w->setText(currentRow, 0, "Session::Parameters::Errors");
    s="";
    for (int i=0; i<M;i++) for (int pp=0;pp<p;pp++) s+=tablePara->text(pp,3*i+3)+" ";
    w->setText(currentRow,1,s+" <");
    currentRow++;
    
    //----- Session::Chi2
    w->setNumRows(currentRow+1);
    s=textLabelChi->text()+" <";
    w->setText(currentRow, 0, "Session::Chi2");
    w->setText(currentRow, 1, s);
    currentRow++;    
    
    //----- Session::R2
    w->setNumRows(currentRow+1);
    s=textLabelR2->text()+" <";
    w->setText(currentRow, 0, "Session::R2");
    w->setText(currentRow, 1, s);
    currentRow++;    
    
    //----- Session::Time
    w->setNumRows(currentRow+1);
    s=textLabelTime->text()+" <";
    w->setText(currentRow, 0, "Session::Time");
    w->setText(currentRow, 1, s);
    currentRow++;    
    
    //----- Simulate::Output::List
    w->setNumRows(currentRow+1);
    s=QString::number(comboBoxOutput->currentItem())+" <";
    w->setText(currentRow, 0, "Simulate::Output::List");
    w->setText(currentRow, 1, s);
    currentRow++;    
    
    //----- Simulate::Output::Residues
    w->setNumRows(currentRow+1);
    if (checkBoxResidues->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");     
    w->setText(currentRow, 0, "Simulate::Output::Residues");
    currentRow++;     
    
    //----- Simulate::Output::ResiduesSlices
    w->setNumRows(currentRow+1);
    if (checkBoxResiduesSlices->isChecked())
	w->setText(currentRow,1,"yes <");
    else
	w->setText(currentRow,1,"no <");     
    w->setText(currentRow, 0, "Simulate::Output::ResiduesSlices");
    currentRow++;         
    
    
    
    
    for (int tt=0; tt<w->numCols(); tt++) 
    {
	w->table()->adjustColumn (tt);
	w->table()->setColumnWidth(tt, w->table()->columnWidth(tt)+10); 
    }
    
}


void fitMatrix10::fitSwitcher()
{
    fitOrCalculate(false);
}

//***************************************************
//  Switcher:  fit or simulation
//***************************************************
void fitMatrix10::fitOrCalculate(bool calculateYN)
{   
    //+++ fit or simulation 
    bool fitOK;    
    
    //+++ fitting
    if (calculateYN) fitOK=true;
    else fitOK = simplyFit();
    
    int activePixelall=0;
    int npall=0;
    double chi2all=0;
    double  TSSall=0;
     
     //+++time of pure simulation
    QTime dt = QTime::currentTime ();
    
    //+++
    if(checkBoxAllInOne->isChecked() && checkBoxMultiData->isChecked() && spinBoxNumberCurvesToFit->value()>1)
    {
	generateSimulatedMatrixAll();
    }
    else
    {
	int M=spinBoxNumberCurvesToFit->value();
	if (M==1) generateSimulatedMatrix(1,1, "fitMatrix", activePixelall, npall, chi2all, TSSall);
	else
	{
	    int activePixel, np;
	    double chi2, TSS;
	    QString s="";
	    
	    for(int m=1; m<=M;m++ ) 
	    {
		if (m<10) s="0"; else s="";
		generateSimulatedMatrix(1,m, "fitMatrix-"+s+QString::number(m), activePixel, np, chi2, TSS);
		activePixelall+=activePixel;
		npall+=np;
		chi2all+=chi2;
		TSSall+=TSS;
	    }
	}	
	// chi2(); // to do
    }
    
    //+++ R2
    double R2all=1-chi2all/TSSall;
    QString ss=textLabelR2->text();
    if (ss.contains("...")) ss="...";
    else ss="[ R2 change :: "+QString::number(R2all-ss.toDouble(),'e',5)+"] ";
    QToolTip::add(  textLabelR2, ss );
    QWhatsThis::add(textLabelR2, ss );
    //+++R2
    textLabelR2->setText(QString::number(R2all,'e',12));

    
    //+++ reduced chi2
    chi2all/=(activePixelall-npall);
    ss=textLabelChi->text();
    if (ss.contains("...")) ss="...";
    else ss="[ Chi2/dof change :: "+QString::number(chi2all-ss.toDouble(),'e',5)+" ]";
    QToolTip::add( textLabelChi, ss );
    QWhatsThis::add( textLabelChi, ss );
    textLabelChi->setText(QString::number(chi2all,'e',12));
        
    
    //+++
    if (calculateYN) textLabelTime->setText("simulation: "+QString::number(dt.msecsTo(QTime::currentTime()), 'e',2)+"ms");
    
    //~~~ save Undo
    saveUndo();
    
    return; 
}



//*******************************************
//+++ fit: without SANS support
//*******************************************
bool fitMatrix10::simplyFit()
{
    
    chekLimits();
    chekLimitsAndFittedParameters();
    
    //+++ Algorithm
    QString algorithm=comboBoxFitMethod->currentText();
    
    bool showProgress=true;
    if (algorithm.contains("[GenMin]") || setToSetProgressControl) showProgress=false;
    
    //+++ Progress dialog
    int progressIter=0;
    QProgressDialog *progress;
    
    if (showProgress)
    {
	progress=new QProgressDialog( "Starting |\n\n\n\n\n\n\n", "Abort FIT", spinBoxMaxIter->text().toInt()+4,
				      this, "Maximal Number of Iterations"+spinBoxMaxIter->text()+". Progress:", TRUE );
	
	progress->setMinimumDuration(2000);
	
	//+++ Start +++  1
	progressIter++;
	progress->setProgress( progressIter );    
    }
    
    //+++
    int mm, np, i, ii, pp;
    int nn=0, nnn=0, nnnn=0;
    size_t pFit;
    
    
    //+++
    int M=spinBoxNumberCurvesToFit->value();		// Number of Curves
    int p=spinBoxPara->value();				//Number of Parameters per Curve
    int pM=p*M;					//Total Number of Parameters
    
    int xNumber=spinBoxXnumber->value();
    
    //+++Number of Adjustible parameters && initial paramerers
    gsl_vector_int *paramsControl= gsl_vector_int_alloc(pM);
    gsl_vector       *params= gsl_vector_alloc(pM);
    
    //+++chech Funcktion Selection: dll
    if (p==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Select Function"));
	return false;
    }
    
    if (showProgress)
    {
	//+++ Graph 2
	progressIter++;
	progress->setProgress( progressIter );    
    }
    //+++Read data sets to Qtotal && Itotal && Sigmatotal && dItotal && usePoint
    
    size_t 	*Rows=new size_t[M];		// Vector of  Rows
    size_t 	*Columns=new size_t[M];		// Vector of  Columns
    
    int Ntotal;
    int rowsAll=0;
    int colsAll=0;
    
    for (mm=0;mm<M;mm++)
    {
	Rows[mm]=tableCurves->text(2,2*mm+1).toInt();
	Columns[mm]=tableCurves->text(3,2*mm+1).toInt();
	
	colsAll+=Columns[mm];
	if (Rows[mm]>rowsAll) rowsAll=Rows[mm];
    }
    
    
    gsl_matrix *I=gsl_matrix_calloc(rowsAll,colsAll); 
    gsl_matrix *dI=gsl_matrix_calloc(rowsAll,colsAll);
    gsl_matrix *mask=gsl_matrix_calloc(rowsAll,colsAll);
    gsl_matrix *xMatrix;
    if (xNumber>2) xMatrix=gsl_matrix_calloc((xNumber-2)*rowsAll,colsAll);
    
    gsl_matrix_set_all(dI,1.0);
    
    //gsl_set_error_handler_off();
    
    
    if ( !readDataToFit(Rows, Columns, Ntotal, I, dI, mask, xMatrix) )
    {
	QMessageBox::warning(this,tr("QtiKws"),
			     tr("Fit stopped :: problem to read data!"));
	return false;
    }
    
    
    //+++
    if (Ntotal==0) 
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Check data. There is no data!"));
	return false;
    }
    
    //+++used Points
    int *controlM=new int[M];
    
    if (showProgress)
    {
	//+++ Data 3
	progressIter++;
	progress->setLabelText("Started | Data Loading |\n\n\n\n\n\n\n");
	progress->setProgress( progressIter );    
    }
    
    //+++ Parameters && Sharing && Varying 
    np=0;
    for (pp=0; pp<p;pp++)
    {
	QCheckTableItem *itS = (QCheckTableItem *)tablePara->item(pp,0); // Share?
	QCheckTableItem *itA0 = (QCheckTableItem *)tablePara->item(pp,1); // Vary?
	
	if (itA0->isChecked()) 
	{
	    gsl_vector_int_set(paramsControl, M*pp, 0);
	    np++;
	}
	else
	{
	    gsl_vector_int_set(paramsControl, M*pp, 1);
	}
	
	gsl_vector_set(params,M*pp, tablePara->text(pp,2).toDouble());
	
	for (mm=1; mm<M;mm++)
	{
	    QCheckTableItem *itA = (QCheckTableItem *)tablePara->item(pp,3*mm+1); // Vary?
	    if (itS->isChecked())
	    {
		itA->setChecked(false);
		gsl_vector_int_set(paramsControl, M*pp+mm, 2);
		tablePara->setText(pp,3*mm+2,tablePara->text(pp,2));
	    }
	    else
	    {
		if (itA->isChecked()) 
		{
		    gsl_vector_int_set(paramsControl, M*pp+mm, 0);
		    np++;
		}
		else
		{
		    gsl_vector_int_set(paramsControl, M*pp+mm, 1);
		}
	    }
	    gsl_vector_set(params,M*pp+mm, tablePara->text(pp,3*mm+2).toDouble());
	}
    }   
    
    //+++
    if (np==0) 
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("No adjustible parameters"));
	if (showProgress)
	{
	    progress->cancel();
	}
	return false;
    }
    
    //+++ Adjustible vector...
    gsl_vector *paraAdjust=gsl_vector_alloc(np);
    
    //+++Fill Adjustible vector...
    pFit=0;    
    for (i=0; i<pM; i++)
    {
	if (gsl_vector_int_get(paramsControl,i)==0) 
	{
	    gsl_vector_set(paraAdjust,pFit,gsl_vector_get(params,i));
	    pFit++;
	}
    }
    
    //+++ Adjustible vector Limits...
    gsl_vector *limitLeft=gsl_vector_alloc(np);
    gsl_vector *limitRight=gsl_vector_alloc(np);  
    
    pFit=0;    
    //+++ 
    for (pp=0; pp<p;pp++) 
    {
	for (mm=0; mm<M;mm++)
	{
	    QCheckTableItem *itA0 = (QCheckTableItem *)tablePara->item(pp,3*mm+1); // Vary?	
	    
	    if (itA0->isChecked()) 
	    {
		gsl_vector_set(limitLeft,pFit, tableControl->text(pp,0).toDouble() );
		gsl_vector_set(limitRight,pFit, tableControl->text(pp,4).toDouble() );
		
		pFit++;
	    }
	}
    }
    
    
    //+++ init parameters of F
    double *xx=new double[xNumber];
    
    for (int i=0; i<xNumber; i++) 
    {
	xx[i]=0.0;
    }
    
    //+++ 
    bool beforeFit=false;
    bool afterFit=false;
    bool beforeIter=false;
    bool afterIter=false;
    //+++ ,tableName,tableColNames,tableColDestinations,mTable
    std::string tableName="no-matrix";
    std::string *tableColNames; 
    int *tableColDestinations; 
    gsl_matrix * mTable;
    
    int prec=spinBoxSignDigits->value();
    
    //+++ switch off gsl-error handler
    gsl_set_error_handler_off();
    
    //+++
    gsl_function FF;
    FF.function = F.function;    
    functionND paraND={xx, F_para, xNumber, M, Rows, Columns, I, dI, mask, xMatrix, beforeFit, afterFit, beforeIter, afterIter,prec,tableName,tableColNames,tableColDestinations,mTable};
    
    FF.params= &paraND;
    
    //+++
    simplyFit2D paraSimple={Ntotal, p, np, xNumber, M, params, paramsControl, &FF, limitLeft, limitRight};	
    
    
    //+++ Fit control parameters
    int d_max_iterations=spinBoxMaxIter->value();
    double d_tolerance=lineEditTolerance->text().toDouble();
    double absError=lineEditToleranceAbs->text().toDouble();
    if (d_tolerance<0) 	d_tolerance=0;
    if (absError<0) 		absError=0;
    
    //+++
    gsl_matrix *covar = gsl_matrix_alloc (np,np);
    
    size_t iter = 0;
    int status;
    
    //+++Time of Fit Run
    QTime dt = QTime::currentTime ();
    
    
    if (showProgress)
    {
	//+++ Ready 4
	progressIter++;
	progress->setLabelText("Started | Loaded | Fitting |\n\n\n\n\n\n\n");
	progress->setProgress( progressIter );   
    }
    
    //    return false;
    
    double dof = Ntotal - np;
    
    if (algorithm.contains("[GenMin]") )    
    {
	QString genMinMessage;
	/*
	genMinMessage+="Genetic Algorithm info:\n\n"; 
	genMinMessage+="Genetic Algorithm code was taken from paper:\n\n";
	genMinMessage+="I.G. Tsoulos, I.E. Lagaris,\n"; 
	genMinMessage+="GenMin: An enhanced genetic algorithm for global optimization,\n"; 
	genMinMessage+="Computer Physics Communications, 178(11), 2008, pp. 843-851,\n";
	genMinMessage+="DOI: 10.1016/j.cpc.2008.01.040.\n\n";
	genMinMessage+="Authors would be appreciated if you give a citation or an ascknolegment in case of using Genetic Algorithm here.\n\n";
	genMinMessage+="Warning:: you could not stop fitting procedure untill the end.\n";
	genMinMessage+="Iteration information you could find in the terminal or console window.\n";
	
	if (QMessageBox::question(this, "QtiKWS - Fit - Global Optimization ", genMinMessage, "&Continue?","&Stop",QString::null, 0, 1 ) ) return false;
	*/
	
	genome_count=spinBoxGenomeCount->value();
	generations=spinBoxMaxNumberGenerations->value();
	selection_rate=lineEditSelectionRate->text().toDouble();
	mutation_rate=lineEditMutationRate->text().toDouble();
	random_seed=spinBoxRandomSeed->value();
	
	int problem_dimension;
	double	*tempx,*tempg;
	
	srand(random_seed);
	srand(random_seed); //+++ srand48
	
	problem_dimension=np;
	
	tempx=new double[problem_dimension];
	tempg=new double[problem_dimension];
	
	Problem myproblem(problem_dimension);
	
	myproblem.YN2D(true);
	myproblem.setSimplyFit2D(paraSimple);
	
	
	DataG	 L,R;
	L.resize(problem_dimension);
	R.resize(problem_dimension);
	
	double leftFactor=lineEditLeftMargin->text().toDouble();
	leftFactor=fabs(leftFactor);
	
	double rightFactor=lineEditRightMargin->text().toDouble();
	rightFactor=fabs(rightFactor);
	
	double currentParameter, currentLeftLimit, currentRightLimit;
	
	for(int i=0;i<problem_dimension;i++)
	{
	    currentParameter=gsl_vector_get(paraAdjust,i);
	    //+++
	    currentLeftLimit=gsl_vector_get(limitLeft,i);
	    currentRightLimit=gsl_vector_get(limitRight,i);
	    
	    if (currentLeftLimit>-1.0E308)
	    {
		L[i]=currentLeftLimit;
	    }
	    else
	    {
		if (leftFactor<=1) leftFactor=2;
		
		if (currentParameter>0)
		{	
		    L[i]=currentParameter/leftFactor;
		}
		else if  (currentParameter<0)
		{
		    L[i]=currentParameter*leftFactor;
		}
		else
		{
		    L[i]=-leftFactor;
		}
	    }
	    
	    if (currentRightLimit<1.0E308)
	    {
		R[i]=currentRightLimit;
	    }
	    else
	    {
		if (rightFactor<=1) rightFactor=2;
		
		if (currentParameter>0)
		{	
		    R[i]=currentParameter*rightFactor;
		}
		else if  (currentParameter<0)
		{
		    R[i]=currentParameter/rightFactor;
		} 
		else
		{
		    R[i]=rightFactor;
		}
	    }
	}
	
	myproblem.setLeftMargin(L);
	myproblem.setRightMargin(R);
	myproblem.dof=dof;
	
	GenMin opt(&myproblem);
	
	//
	opt.Solve();
	
	DataG x;
	double y;
	x.resize(problem_dimension);
	opt.getMinimum(x,y);
	
	opt.localSearch(x);
	
	
	
	printf("X = [");
	for(int i=0;i<problem_dimension;i++)
	{
	    printf(" %lg ",x[i]);	
	}
	printf("] \nchi^2 = %lg\n",y/dof);
	printf("FUNCTION CALLS =%6d\nGRADIENT CALLS=%6d\n\n",
	       myproblem.fevals,myproblem.gevals);
	delete[] tempx;
	delete[] tempg;
	
	
	
	int digits=spinBoxSignDigits->value()-1;
	//+++ Parameters to parameter Table
	int npnp=0;
	for (pp=0; pp<p; pp++)	
	    for(mm=0; mm<M; mm++)    
	    {
	    if (gsl_vector_int_get(paramsControl,M*pp+mm) == 0) 
	    {
		tablePara->setText(pp,3*mm+2, QString::number(x[npnp],'E',digits));
		//tablePara->setText(pp,3*mm+3, QString::number(c*ERR2(npnp),'E',digits));
		tablePara->setText(pp,3*mm+3, "---");
		gsl_vector_set(params,M*pp+mm,x[npnp]);
		npnp++;
	    }
	    else if (gsl_vector_int_get(paramsControl,M*pp+mm) == 2)
	    {
		int ii=M*pp+mm;
		while (gsl_vector_int_get(paramsControl,ii)==2) {ii--;};
		tablePara->setText(pp,3*mm+2, QString::number(gsl_vector_get(params,ii),'g',digits));
		tablePara->setText(pp,3*mm+3, "---");
	    }
	    else
	    {
		tablePara->setText(pp,3*mm+3, "---");
	    }			
	}
	if (showProgress)
	{
	    progress->cancel();
	}
    }
    else if (algorithm.contains("Nelder-Mead Simplex") )        //+++ fit session: switcher between methods
    {
	gsl_multimin_function f;
	
	f.f = &function_dm2D;
	f.n = np;
	f.params = &paraSimple;	  
	
	
	const gsl_multimin_fminimizer_type *TT;
	
	if (algorithm.contains("nmsimplex2rand"))
	    TT=gsl_multimin_fminimizer_nmsimplex2rand;
	else if (algorithm.contains("nmsimplex2"))
	    TT=gsl_multimin_fminimizer_nmsimplex2;
	else 
	    TT=gsl_multimin_fminimizer_nmsimplex;
	
	gsl_vector *ss = gsl_vector_alloc (np);
	
	//+++set all step sizes to 1 can be increased to converge faster
	gsl_vector_set_all (ss,1.0);
	
	gsl_multimin_fminimizer *s_min = gsl_multimin_fminimizer_alloc (TT, np);
	
	status = gsl_multimin_fminimizer_set(s_min, &f, paraAdjust, ss);
	
	
	QString s;
	if (status != 0) 
	{
	    s=s.setNum(status);
	    QString report=tr("<b> %1 </b>: GSL error -1- :: ").arg(s);
	    report+= gsl_strerror (status); 
	    QMessageBox::warning(this, tr("QtiKws"),report);          
	    
	    //+++ Delete  Variables
	    gsl_matrix_free(I);
	    gsl_matrix_free(dI); 
	    gsl_matrix_free(mask); 
	    if (xNumber>2) gsl_matrix_free(xMatrix); 
	    gsl_vector_free(params); 
	    gsl_vector_int_free(paramsControl);
	    gsl_vector_free(paraAdjust);
	    gsl_matrix_free(covar);
	    gsl_multimin_fminimizer_free (s_min);
	    
	    gsl_vector_free(limitLeft);
	    gsl_vector_free(limitRight);
	    
	    return false;
	}
	
	
	
	double size;
	iter=0;
	QString st;
	do
	{
	    if (showProgress)
	    {
		//+++ Fit Started 1
		progressIter++;		
		
		if (iter>0)
		{
		    st="";
		    st="Started | Loaded | Fitting > Iterations\n\n";
		    st=st+algorithm+"\n\n";
		    st=st+"#\t\t\t\t\t\t\t\t Stopping Criterion \t\t\t Chi^2/dof\n";
		    st=st+QString::number(iter)+"[<"+QString::number(d_max_iterations)+"]\t\t "+QString::number(size, 'E',4)+" [<"+QString::number(d_tolerance)+"]\t "+QString::number(s_min->fval/dof,'E',4)+"\n\n";
		    progress->setLabelText(st);
		}
		progress->setProgress( progressIter );
		if ( progress->wasCanceled() ) break;
	    }
	    iter++;
	    
	    status = gsl_multimin_fminimizer_iterate (s_min);
	    size=gsl_multimin_fminimizer_size (s_min);
	    status = gsl_multimin_test_size (size, d_tolerance);
	    
	}
	while (status == GSL_CONTINUE && (int)iter < d_max_iterations);
	
	if (showProgress)
	{
	    progress->cancel();// setProgress( progressIter );	
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++   After Fit:
	
	
	
	double tmp;
	for (int pp=0; pp<np;pp++)
	{
	    tmp= gsl_vector_get(s_min->x, pp);
	    
	    if ( tmp < gsl_vector_get(limitLeft,pp) ) 
		gsl_vector_set(paraAdjust,pp,gsl_vector_get(limitLeft,pp)); 
	    else if ( tmp>gsl_vector_get(limitRight,pp) ) 
		gsl_vector_set(paraAdjust,pp,gsl_vector_get(limitRight,pp)); 
	    else
		gsl_vector_set(paraAdjust,pp,tmp);    
	}
	
	gsl_matrix *J = gsl_matrix_alloc(Ntotal, np); 
	
	//+++ Jacobian J
	function_dfm2D_long(paraAdjust,&paraSimple,J);
	
	//+++ Covariant matrix
	gsl_multifit_covar (J, 0.0, covar);  
	
#define FIT2(i) gsl_vector_get(paraAdjust, i)
#define ERR2(i) sqrt(gsl_matrix_get(covar,i,i))
	
	double chi = sqrt(s_min->fval);
	
	//+++
	double c =chi / sqrt(dof);
	
	int digits=spinBoxSignDigits->value()-1;
	//+++ Parameters to parameter Table
	int npnp=0;
	for (pp=0; pp<p; pp++) for(mm=0; mm<M; mm++)    
	{
	    if (gsl_vector_int_get(paramsControl,M*pp+mm) == 0) 
	    {
		tablePara->setText(pp,3*mm+2, QString::number(FIT2(npnp),'G',digits+1));
		tablePara->setText(pp,3*mm+3, QString::number(c*ERR2(npnp),'G',digits+1));
		gsl_vector_set(params,M*pp+mm,FIT2(npnp));
		
		npnp++;
		
	    }
	    else if (gsl_vector_int_get(paramsControl,M*pp+mm) == 2)
	    {
		int ii=M*pp+mm;
		while (gsl_vector_int_get(paramsControl,ii)==2) {ii--;};
		tablePara->setText(pp,3*mm+2, QString::number(gsl_vector_get(params,ii),'G',digits+1));
		tablePara->setText(pp,3*mm+3, "---");
	    }
	    else
	    {
		tablePara->setText(pp,3*mm+3, "---");
	    }			
	}
	
	gsl_vector_free(ss);
	gsl_matrix_free(J);
	gsl_multimin_fminimizer_free(s_min);
    }    
    else    
    {
	//+++++
	const gsl_multifit_fdfsolver_type *Tln;
	gsl_multifit_fdfsolver *sln;
	gsl_multifit_function_fdf fln;
	
	
	fln.f = &function_fm2D;
	fln.df = &function_dfm2D_long;
	fln.fdf = &function_fdfm2D;
	fln.n = Ntotal;
	fln.p = np;
	fln.params = &paraSimple;  
	
	//+++
	if (algorithm.contains("Unscaled"))
	    Tln = gsl_multifit_fdfsolver_lmder;
	else     
	    Tln = gsl_multifit_fdfsolver_lmsder;	
	
	bool deltaStop=false;
	if (algorithm.contains("Delta")) deltaStop=true;
	
	//+++
	sln = gsl_multifit_fdfsolver_alloc(Tln, Ntotal,np);
	
	//+++
	status=gsl_multifit_fdfsolver_set(sln, &fln, paraAdjust);
	
	//+++
	QString s;
	if (status != 0) 
	{
	    s=s.setNum(status);
	    QMessageBox::warning(this, tr("QtiKWS"),
				 tr("<b> %1 </b>: GSL error -3-").arg(s));        
	    //+++ Delete  Variables
	    gsl_matrix_free(I); 
	    gsl_matrix_free(dI); 
	    gsl_matrix_free(mask); 
	    if (xNumber>2) gsl_matrix_free(xMatrix); 
	    gsl_vector_free(params); 
	    gsl_vector_int_free(paramsControl);
	    gsl_vector_free(paraAdjust);
	    gsl_matrix_free(covar);
	    gsl_multifit_fdfsolver_free (sln);	
	    
	    gsl_vector_free(limitLeft);
	    gsl_vector_free(limitRight);
	    
	    
	    return false;
	}
	
	iter=0;
	
	//+++
	double ssize=0;
	//+++
	QString st;
	//+++
	double tmp;
	//+++
	gsl_vector *vec=gsl_vector_calloc(np);
	//+++
	double chi2old=-1;
	double chi2new;	
	
	
	
	do
	{
	    if (showProgress)
	    {
		//+++ Fit Started 1
		progressIter++;
		
		if (iter>0)
		{
		    ssize=0;
		    if (deltaStop)
		    {
			for (int vvv=0;vvv<np;vvv++) 
			{
			    tmp=fabs(gsl_vector_get(sln->dx, vvv))-d_tolerance*fabs(gsl_vector_get(sln->x, vvv));
			    if (tmp>ssize) ssize=tmp; 
			}
		    }
		    else
		    {
			for (int vvv=0;vvv<np;vvv++) 
			{
			    ssize+=fabs(gsl_vector_get(vec, vvv));
			}	
		    }	
	
		    chi2new=pow(gsl_blas_dnrm2(sln->f),2)/dof;
		    if (chi2old<0) chi2old=chi2new;
		    
		    
		    st="";
		    st="Started | Loaded | Fitting > Iterations\n\n ";
		    st=st+algorithm+"\n\n";
		    st=st+"#\t\t\t\t\t\t\t\t Stopping Criterion \t\t\t Chi^2/dof\n";
		    st=st+QString::number(iter)+"[<"+QString::number(d_max_iterations)+"]\t\t "+QString::number(ssize, 'E',4)+" [<"+QString::number(absError)+ " || " + QString::number(d_tolerance)+"]\t "+QString::number(chi2new,'E',4)+" [ - "+QString::number((chi2old-chi2new)/(chi2old+1e-50)*100,'G',6)+" % ] \n\n";
		    
		    chi2old=chi2new;
		    
		    progress->setLabelText(st);
		}
		
		progress->setProgress( progressIter );
		if ( progress->wasCanceled() ) break;
	    }
	    iter++;
	    
	    
	    status = gsl_multifit_fdfsolver_iterate (sln);
	    
	    if (deltaStop)
	    {
		status = gsl_multifit_test_delta (sln->dx, sln->x, absError, d_tolerance);
	    }
	    else
	    {
		gsl_multifit_gradient(sln->J, sln->f,vec);
		status = gsl_multifit_test_gradient (vec, absError);	
	    }
	}
	while (status == GSL_CONTINUE && (int)iter < d_max_iterations);
	
	if (showProgress)
	{
	    progress->cancel();//setProgress( progressIter );	
	}
	//+++
	status=gsl_multifit_covar (sln->J, 0.0, covar);
	if (status != 0) 
	{
	    s=s.setNum(status);
	    QMessageBox::warning(this, tr("QtiKWS"),
				 tr("<b> %1 </b>: GSL error -5-").arg(s)); 
	}
	
	
	for (int pp=0; pp<np;pp++)
	{
	    tmp= gsl_vector_get(sln->x, pp);
	    
	    if ( tmp < gsl_vector_get(limitLeft,pp) ) 
		gsl_vector_set(paraAdjust,pp,gsl_vector_get(limitLeft,pp)); 
	    else if ( tmp>gsl_vector_get(limitRight,pp) ) 
		gsl_vector_set(paraAdjust,pp,gsl_vector_get(limitRight,pp)); 
	    else
		gsl_vector_set(paraAdjust,pp,tmp);    
	}
	
	
	
#define FIT(i) gsl_vector_get(paraAdjust, i)
#define ERR(i) sqrt(gsl_matrix_get(covar,i,i))
	
	double chi = gsl_blas_dnrm2(sln->f);
	//+++
	double c = chi / sqrt(dof);
	
	//+++
	int digits=spinBoxSignDigits->value()-1;	
	int npnp=0;
	for (pp=0; pp<p; pp++)
	    for(mm=0; mm<M; mm++)    
	    {
	    if (gsl_vector_int_get(paramsControl,M*pp+mm) == 0) 
	    {
		tablePara->setText(pp,3*mm+2, QString::number(FIT(npnp),'G',digits+1));
		tablePara->setText(pp,3*mm+3, QString::number(c*ERR(npnp),'G',digits+1));
		gsl_vector_set(params,M*pp+mm,FIT(npnp));
		npnp++;
	    }
	    else if (gsl_vector_int_get(paramsControl,M*pp+mm) == 2)
	    {
		int ii=M*pp+mm;
		while (gsl_vector_int_get(paramsControl,ii)==2) {ii--;};
		tablePara->setText(pp,3*mm+2, QString::number(gsl_vector_get(params,ii),'G',digits+1));
		tablePara->setText(pp,3*mm+3, "---");
	    }
	    else
	    {
		tablePara->setText(pp,3*mm+3, "---");
	    }			
	}
	
	gsl_multifit_fdfsolver_free (sln);
	gsl_vector_free(vec);
    }
    
    
    //+++ Delete  Variables
    
    delete[] controlM, Rows, Columns, xx;
    gsl_matrix_free(I);
    gsl_matrix_free(dI);
    gsl_matrix_free(mask);
    if (xNumber>2) gsl_matrix_free(xMatrix);
    gsl_vector_free(params); 
    gsl_vector_int_free(paramsControl);
    gsl_vector_free(paraAdjust);
    gsl_matrix_free(covar); 
    
    gsl_vector_free(limitLeft);
    gsl_vector_free(limitRight);
    
    //+++Time After Fit Run
    textLabelTime->setText(QString::number(iter)+"x iterations: "+QString::number(dt.msecsTo(QTime::currentTime()), 'e',2)+"ms");
        
    return true;
}





//***************************************************
//  Multi Table:: select Pattern
//***************************************************
void fitMatrix10::selectPattern()
{
    tableMultiFit->setNumRows(1);
    
    QStringList matrixes, matrixesAll;
    
    matrixesAll=findAllMatrixes();
    
    QRegExp rx( lineEditPattern->text());
    rx.setWildcard( TRUE );
    
    int i,j;
    for (i=0; i<matrixesAll.count();i++) if (rx.exactMatch(matrixesAll[i])) matrixes<<matrixesAll[i];
    
    matrixes.prepend("All");
    tableMultiFit->setNumRows(matrixes.count());
    tableMultiFit->setRowLabels(matrixes);
    
    int start=3;
    
    QStringList list; 
    int nRows, nCols;
    
    for (i=1; i<matrixes.count();i++)
    {
	list.clear();
	findAllMatrixesLikeExample(matrixes[i], list, nRows, nCols);
	
	// +++
	QCheckTableItem *yn = new QCheckTableItem(tableMultiFit, QString::null );
	tableMultiFit->setItem(i,0, yn);
	// +++
	QString maskNameBase=tableCurves->text(1,1);
	
	QComboTableItem *mask = new QComboTableItem(tableMultiFit, QString::null );
	tableMultiFit->setItem(i,1,mask);
	mask->setStringList(list);
	if (list.contains(maskNameBase)) mask->setCurrentItem(maskNameBase);
	
	// +++
	QString wNameBase=tableCurves->text(4,1);
	
	QComboTableItem *dYcol = new QComboTableItem(tableMultiFit, QString::null );
	tableMultiFit->setItem(i,2,dYcol);
	dYcol->setStringList(list);
	if (list.contains(wNameBase)) dYcol->setCurrentItem(wNameBase);
	
	for(int pp=0;pp<spinBoxPara->value();pp++)  tableMultiFit->setText(i, pp+start, tablePara->text(pp, 2) ); 
    }		
    
    
    // +++Start values & adjustibility trasfer
    for (j=start;j<tableMultiFit->numCols();j++) 
    {
	QCheckTableItem *fitYN = (QCheckTableItem*)tableMultiFit->item (0,j);
	QCheckTableItem *fitYN0 = (QCheckTableItem*)tablePara->item (j-start,1);
	if (fitYN0->isChecked()) fitYN->setChecked(TRUE); else fitYN->setChecked(FALSE);
    }
    
    // +++Mask option
    QCheckTableItem *mYN = (QCheckTableItem*)tableMultiFit->item (0,1);
    QCheckTableItem *mYN0 = (QCheckTableItem*)tableCurves->item (1,0);
    if (mYN0->isChecked()) mYN->setChecked(TRUE); else mYN->setChecked(FALSE);
    
    
    // +++Weiting option
    QCheckTableItem *wYN = (QCheckTableItem*)tableMultiFit->item (0,2);
    QCheckTableItem *wYN0 = (QCheckTableItem*)tableCurves->item (4,0);
    if (wYN0->isChecked()) wYN->setChecked(TRUE); else wYN->setChecked(FALSE);
    
    for (int tt=0; tt<tableMultiFit->numCols();tt++) tableMultiFit->adjustColumn(tt);    
}

// +++
void fitMatrix10::setBySetFit()
{
    setToSetSimulYN=false;
    setBySetFitOrSim(true);
}

void fitMatrix10::setBySetFitOrSim(bool fitYN)
{
    int i,j; 
    int start=3;
    int Nselected=0;
    int p=spinBoxPara->value();
    
    bool weight=false, mask=false;
    
    QStringList matrixes, weightColList, maskColList,  commentList;
    
    QString s;
    
    
    // +++ check #1
    int Ntot=tableMultiFit->numRows()-1;  // number of Availeble Datasets in table
    
    if (Ntot==0) 
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     "There is no matrix | Select Matrixes! | Use [Select] button ");
	return;	
    }
    
    
    
    //+++ Progress dialog
    int progressIter=0;
    
    QProgressDialog progress( "Matrix-to-Matrix Fit", "Abort Matrix-To-Matrix FIT", Ntot,
			      this, "Progress ::", TRUE );
    
    progress.setMinimumDuration(1000);
    
    
    setToSetProgressControl=true;   
    
    // +++ mask
    QCheckTableItem *mYN = (QCheckTableItem*)tableMultiFit->item (0,1);
    if (mYN->isChecked()) mask=true;     
    
    // +++ weight
    QCheckTableItem *wYN = (QCheckTableItem*)tableMultiFit->item (0,2);
    if (wYN->isChecked()) weight=true; 
    
    // +++ check #2
    for (i=0; i<Ntot;i++)
    {
	QCheckTableItem *selectedYN = (QCheckTableItem*)tableMultiFit->item (i+1,0);
	if (selectedYN->isChecked()) 
	{
	    matrixes<<tableMultiFit->verticalHeader()->label(i+1);
	    s=tableMultiFit->verticalHeader()->label(i+1) +" |m| ";
	    if (weight) {weightColList<<tableMultiFit->text(i+1,2); s+=tableMultiFit->text(i+1,2) +" |w| ";} else s+=" |w| " ;
	    if (mask) {maskColList<<tableMultiFit->text(i+1,1); s+=tableMultiFit->text(i+1,1) +" |mask| ";} else s+=" |mask| " ;
	    commentList<<s;
	    Nselected++;			
	}
    }
    
    
    if (Nselected==0) 
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     "There are no SELECTED matrixes | Select matrixes! ");
	return;	
    }
    
    // +++  create Table
    Table *t;
    s=app(this)->generateUniqueName(tr("Matrix-By-Matrix-Fit-"+lineEditSetBySetFit->text()));
    t=app(this)->newHiddenTable(s, "Fitting Results:: Matrix-By-Matrix", GSL_MAX(Nselected,19), 2+1+1+3+2*p);
    
    t->setWindowLabel("Fitting Results:: Matrix-By-Matrix");
    
    
    t->setColName(0,"Parameter");
    t->setColPlotDesignation(0,Table::None);
    
    t->setColName(1,"Value");	
    t->setColPlotDesignation(1,Table::None);
    
    t->setColName(2,"X");
    t->setColPlotDesignation(2,Table::X);
    
    t->setColName(3,"Dataset");
    t->setColName(4,"Chi2");
    t->setColName(5,"R2");
    t->setColName(6,"Fit-Time");	
    
    s="-> ";
    for (i=0;i<p;i++)
    {
	if (i<(p-1)) s+=F_paraList[i]+" , "; else s+=F_paraList[i]; 
	t->setColName(7+2*i,F_paraList[i]);	
	t->setColName(7+2*i+1,"d"+F_paraList[i]);
	t->setColPlotDesignation(7+2*i+1,Table::yErr);
    }
    // Fit Conrtrol
    int currentChar=0;
    
    // +++  Fitting Function
    t->setText(currentChar,0,"Fitting Function"); t->setText(currentChar,1,"-> " + textLabelFfunc->text()); currentChar++;
    // +++  Number of Parameters   
    t->setText(currentChar,0,"Number of Parameters"); t->setText(currentChar,1,"-> "+QString::number(p));currentChar++;
    // +++  Parameters   
    t->setText(currentChar,0,"Parameters"); t->setText(currentChar,1,s); currentChar++;    
    //+++ Multi Mode
    t->setText(currentChar,0,"Number of Matrixes"); t->setText(currentChar,1,"-> 1");currentChar++;
    //+++ Weight On
    if (weight) s="Yes"; else s="No";
    t->setText(currentChar,0,"Weight On"); t->setText(currentChar,1,"-> "+s);currentChar++;
    //+++ Mask On    
    if (mask) s="Yes"; else s="No";
    t->setText(currentChar,0,"Mask On"); t->setText(currentChar,1,"-> "+s);currentChar++;
    
    //+++ Fit-Control
    QString line;
    line=QString::number(comboBoxFitMethod->currentItem())+" , ";
    line+=spinBoxMaxIter->text() +" , ";
    line+=lineEditTolerance->text() +" , ";
    line+=QString::number(comboBoxOutput->currentItem()) +" , "; 
    line+=spinBoxSignDigits->text() +" , ";
    line+=QString::number(comboBoxWeightingMethod->currentItem()) +" , ";    
    t->setText(currentChar,0,"Fit-Control"); t->setText(currentChar,1,"-> "+line);currentChar++;
    
    // +++ DataSet
    QComboTableItem *dataSetItem = (QComboTableItem*) tableCurves->item(0,1);
    // +++ weight check & Col
    QCheckTableItem *WrealYN = (QCheckTableItem*)tableCurves->item (4,0);
    QComboTableItem *weightColItem = (QComboTableItem*) tableCurves->item(4,1);
    
    // +++ mask check & Col
    QCheckTableItem *MaskrealYN = (QCheckTableItem*)tableCurves->item (1,0);
    QComboTableItem *MaskColItem = (QComboTableItem*) tableCurves->item(1,1);
    
    // +++Start values & adjustibility trasfer
    for (j=start;j<tableMultiFit->numCols();j++) 
    {
	QCheckTableItem *fitYN = (QCheckTableItem*)tableMultiFit->item (0,j);
	QCheckTableItem *fitYN0 = (QCheckTableItem*)tablePara->item (j-start,1);
	if (fitYN->isChecked()) fitYN0->setChecked(TRUE); else fitYN0->setChecked(FALSE);
    }
    
    int NselTot=Nselected;
    Nselected=0;
    
    
    for (i=0; i<Ntot;i++)
    {
	//+++ Start +++  1
	progress.setProgress(i);
	progress.setLabelText("Current matrix: # "+QString::number(i)+" of "+QString::number(Ntot));
	
	if ( progress.wasCanceled() ) {setToSetProgressControl=false;   break;};
	
	QCheckTableItem *selectedYN = (QCheckTableItem*)tableMultiFit->item (i+1,0);
	if (selectedYN->isChecked()) 
	{
	    // +++ RESULT TABLE
	    t->setText(Nselected,2,QString::number(Nselected+1));
	    t->setText(Nselected,3,commentList[Nselected]);
	    // +++ TRANSFER INFO ABOUT FITTED DATASET
	    s=matrixes[Nselected];
	    dataSetItem->setCurrentItem(s); 
	    tableCurvechanged(0,1);
	    //+++ TRANSFER OF WEIGHT INFO
	    if (weight) 
	    {
		if ( weightColList[Nselected]=="" && ( comboBoxWeightingMethod->currentItem()==0 || comboBoxWeightingMethod->currentItem()==2) ) 
		    WrealYN->setChecked(false);
		else 
		{
		    WrealYN->setChecked(true);
		    s=weightColList[Nselected];
		    weightColItem->setCurrentItem(s);
		    tableCurvechanged(4,1);
		}
	    }
	    else WrealYN->setChecked(false);
	    
	    //+++ TRANSFER OF MASK INFO
	    if (mask) 
	    {
		MaskrealYN->setChecked(true);
		s=maskColList[Nselected];
		MaskColItem->setCurrentItem(s);
		tableCurvechanged(1,1);
	    }
	}
	else MaskrealYN->setChecked(false);
	
	//+++ MOVING OF PARAMETERS TO FITTING INTERFACE
	if (tableMultiFit->text(0,0)!="c")
	{
	    for (j=start;j<tableMultiFit->numCols();j++) 
	    {
		tablePara->setText(j-start,2,tableMultiFit->text(i+1,j)); 
	    }
	}
	//+++ FITTING OF CURRENT DATASET
	setToSetNumber=i+1;	    
	if (fitYN) fitOrCalculate(false);
	else fitOrCalculate(true);
	
	//+++ TRANSFER OF OBTEINED PARAMETERS TO MATRIX-BY-MATRIX TABLE AND TO RESULT TABLE
	for (j=0;j<p;j++) 
	{
	    t->setText(Nselected,2*j+7,tablePara->text(j,2));
	    t->setText(Nselected,2*j+8,tablePara->text(j,3));
	    //new!!
	    tableMultiFit->setText(i+1,j+start, tablePara->text(j,2));	
	}
	
	t->setText(Nselected,4,textLabelChi->text());
	t->setText(Nselected,5,textLabelR2->text());
	t->setText(Nselected,6,textLabelTime->text());
	Nselected++;
    }
    for (int tt=0; tt<t->numCols(); tt++) t->table()->adjustColumn (tt);
    
    
    
    setToSetProgressControl=false;
}

// +++
void fitMatrix10::rename(QString oldNAME, QString newNAME)
{
    int i;
    
    newNAME=app(this)->generateUniqueName(newNAME);	
    
    QWidgetList *windows = app(this)->windowsList();
    
    Table* t;
    
    for (i=0;i<(int)windows->count();i++)
    {
	if (windows->at(i) && windows->at(i)->isA("Table") && windows->at(i)->name()==oldNAME)
	{
	    t = (Table*)windows->at(i);
	}
    }
    
    if(!app(this)->renameWindow(t, newNAME))	return;
    
    app(this)->renameListViewItem(oldNAME,newNAME);
    
    app(this)->modifiedProject(t);
}

// +++
void fitMatrix10::simulateMultifitTables()		
{
    setToSetSimulYN=true;
    setBySetFitOrSim(false);
}

void fitMatrix10::removeMatrixes(QString pattern)
{
    int i;
    
    QWidgetList *windows = app(this)->windowsList();
    
    QRegExp rx(pattern);
    rx.setWildcard( TRUE );
    
    for (i=0;i<(int)windows->count();i++)
    {
	if (windows->at(i) && windows->at(i)->isA("Matrix") && rx.exactMatch(windows->at(i)->name()))
	{
	    myWidget *close =(myWidget*)windows->at(i);
	    emit app(this)->closeWindow(close);
	}
	
    }
}

// +++ simulatedCurve-Cylinder-1  fitCurve-Cylinder-set-1 simulatedCurve-Cylinder-set-1-1
void fitMatrix10::removeSimulatedDatasets()
{
    QString F_name=textLabelFfunc->text();
    
    if ( tabWidgetGenResults->currentPageIndex()==0 )
	removeMatrixes( "simulatedMatrix-*"+textLabelFfunc->text()+"*");
    if ( tabWidgetGenResults->currentPageIndex()==2 )    
    {
	removeMatrixes( "simulatedMatrix-*"+textLabelFfunc->text()+"-set*");
	removeMatrixes( "fitMatrix-*"+textLabelFfunc->text()+"-set*");	
    }
    updateDatasets();
}


// +++
bool fitMatrix10::datasetChangedSim( int num)
{	
    //+++
    int p=spinBoxPara->value();
    int M=spinBoxNumberCurvesToFit->value();
    int xNumber=spinBoxXnumber->value();
    int digits=spinBoxSignDigits->value()-1;    
    
    if (tableCurves->text(0,1)=="") return false;
    
    //+++ transfer: all active matrixes (M)
    QStringList lst;
    if (comboBoxDatasetSim->count()==0)
    {
	for (int m=0;m<M;m++) lst<<tableCurves->text(0,2*m+1);
	comboBoxDatasetSim->clear();
	comboBoxDatasetSim->insertStringList(lst);
	comboBoxDatasetSim->setCurrentItem(num);
    }
    
    //+++ transfer: Parameters +++
    for (int i=0;i<p;i++) tableParaSimulate->setText(i,0,tablePara->text(i,2+3*num));
    
    //+++ transfer: All matrixex
    QComboTableItem *allMatrixes = (QComboTableItem*) tableCurves->item(0,2*num+1);   
    QComboTableItem *allMatrixesSim = (QComboTableItem*) tableSimX->item(0,0);
    
    //+++ transfer: Masks
    QComboTableItem *allMasks = (QComboTableItem*) tableCurves->item(1,2*num+1);   
    QComboTableItem *allMasksSim = (QComboTableItem*) tableSimX->item(1,0);
    lst.clear();
    int dataActive=0;
    for (int i=0;i<allMasks->count();i++) { lst<<allMasks->text(i); if (allMasks->text(i)==allMatrixes->currentText()) dataActive=i;};
    allMatrixesSim->setStringList(lst);
    allMatrixesSim->setCurrentItem(dataActive);
    
    allMasksSim->setStringList(lst);
    allMasksSim->setCurrentItem(allMasks->currentItem());    
    
    //+++ transfer: Weights
    QComboTableItem *allWeights = (QComboTableItem*) tableCurves->item(4,2*num+1);   
    QComboTableItem *allWeightsSim = (QComboTableItem*) tableSimX->item(2,0);
    lst.clear();
    for (int i=0;i<allWeights->count();i++) lst<<allWeights->text(i);
   
    allWeightsSim->setStringList(lst);
    allWeightsSim->setCurrentItem(allWeights->currentItem());    
    

    
    //+++ transfer: maskActivity
    QCheckTableItem *maskActive = (QCheckTableItem *)tableCurves->item(1,2*num);
    checkBoxMaskSim->setChecked(maskActive->isChecked());
  
    //+++ transfer: weightActivity
    QCheckTableItem *weightActive = (QCheckTableItem *)tableCurves->item(4,2*num);
    checkBoxUseWeightSim->setChecked(weightActive->isChecked());
  
    simRows->setValue(tableCurves->text(2,2*num+1).toInt());
    simCols->setValue(tableCurves->text(3,2*num+1).toInt());

    return true;    
}


//+++ Fit results in graph +++
void fitMatrix10::addFitResultToActiveGraph()
{
    int p=spinBoxPara->value();
    int M=spinBoxNumberCurvesToFit->value();
    QString F_name=textLabelFfunc->text();
    
    QDateTime dt = QDateTime::currentDateTime ();
    QString info = "[" + dt.toString(Qt::LocalDate)+ " ]\n";
    info = info+ "<b>Fit Method</b>" + ": " +comboBoxFitMethod->currentText() +"\n";
    info = info+ "<b>Using Function</b>" + ": " + F_name + "\n";
    
    int mm;
    for (mm=0;mm<M;mm++) 
    {
	info+="\n<b>"+tableCurves->text(0,2*mm+1)+"</b>"+ " : \n";
	
	int pp;
	for (pp=0;pp<p;pp++) 
	{
	    info+= "<b>"+F_paraList[pp]+"</b>"+" = "+tablePara->text(pp,3*mm+2);
	    if (tablePara->text(pp,3*mm+3)!="---")
	    {
		info+=" ";
		info+=QChar(177);
		info+=" "+tablePara->text(pp,3*mm+3);
	    }
	    info+="\n";
	}
    }
    info+="\n<b>chi<sup>2</sup></b> = "+textLabelChi->text()+"\n";
    info+="\n<b>R<sup>2</sup></b> = "+textLabelR2->text()+"\n";
    info+="<b>time</b> = "+textLabelTime->text()+"\n";
    
    if (!app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer"))
	return;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty())
    {
	QMessageBox::warning(this,tr("QtiKWS - Warning"),
			     tr("<h4>There are no plot layers available in this window.</h4>"
				"<p><h4>Please add a layer and try again!</h4>"));
	
	return;
    }
    
    Graph *g = (Graph*)plot->activeGraph();
    if (g) g->newLegend(info);	
    g->replot();
}




void fitMatrix10::saveUndo()
{
    //+++
    int M=spinBoxNumberCurvesToFit->value();		// Number of Curves
    int p=spinBoxPara->value();				//Number of Parameters per Curve
    int pM=p*M;					//Total Numbe
    
    QString undo;    
    int pp, mm;
    
    for (mm=0;mm<M;mm++) for (pp=0;pp<p;pp++) undo+=QString::number(tablePara->text(pp, 3*mm+2).toDouble(),'E',spinBoxSignDigits->value()-1)+"  ";
    
    undoRedo<<undo;
    ;
    pushButtonRedo->setEnabled(false);
    pushButtonUndo->setEnabled(true);
    
    undoRedoActive=undoRedo.count();
}

//~~~
void fitMatrix10::undo()
{
    //if (!pushButtonRedo->isEnabled() && undoRedoActive==undoRedo.count()) saveUndo();
    
    if(undoRedoActive>1)
    {
	undoRedoActive-=1;
	pushButtonRedo->setEnabled(true);
	
	//+++
	int M=spinBoxNumberCurvesToFit->value();		// Number of Curves
	int p=spinBoxPara->value();				//Number of Parameters per Curve
	int pM=p*M;						//Total Numbe
	
	QString undo=undoRedo[undoRedoActive-1];
	int pp=0, mm=0;
	
	int pos=0;
	
	QRegExp rx( "((\\-|\\+)?\\d*(\\.|\\,)\\d*((e|E)(\\-|\\+)\\d*)?)" );
	
	
	for (mm=0;mm<M;mm++) for (pp=0;pp<p;pp++)
	{
	    pos = rx.search( undo, pos ); pos+=rx.matchedLength();
	    tablePara->setText(pp,3*mm+2,rx.cap(1));
	}
	if(undoRedoActive==1) pushButtonUndo->setEnabled(false);
    }
    else pushButtonUndo->setEnabled(false);
}


void fitMatrix10::redo()
{
    if(undoRedoActive<undoRedo.count())
    {
	undoRedoActive+=1;
	pushButtonUndo->setEnabled(true);
	
	//+++
	int M=spinBoxNumberCurvesToFit->value();		// Number of Curves
	int p=spinBoxPara->value();				//Number of Parameters per Curve
	int pM=p*M;						//Total Numbe
	
	QString undo=undoRedo[undoRedoActive-1];
	int pp=0, mm=0;
	
	int pos=0;
	
	//QRegExp rx( "((\\-|\\+)?\\d*(\\.|\\,)\\d*((e|E)(\\-|\\+)\\d*)?)" );	
	QRegExp rx( "((\\-|\\+)?\\d*(\\.|\\,)\\d*((e|E)(\\-|\\+)\\d*)?)" );	   
	for (mm=0;mm<M;mm++) for (pp=0;pp<p;pp++)
	{
	    pos = rx.search( undo, pos ); pos+=rx.matchedLength();
	    tablePara->setText(pp,3*mm+2,rx.cap(1));//
	}
	if(undoRedoActive==undoRedo.count()) pushButtonRedo->setEnabled(false);
    }
    else pushButtonRedo->setEnabled(false);
}



void fitMatrix10::headerPressedTablePara( int col )
{
    
    if (col==0 || (col-1)/3*3==(col-1))
    {
	int p=spinBoxPara->value();
	int M=spinBoxNumberCurvesToFit->value();
	
	int pp, ppC=0;
	//+++ get np && params
	for (pp=0; pp<p;pp++)
	{
	    QCheckTableItem *itS = (QCheckTableItem *)tablePara->item(pp,col); //
	    if (itS->isChecked()) ppC++; 
	}
	
	for (pp=0; pp<p;pp++)
	{
	    QCheckTableItem *itS = (QCheckTableItem *)tablePara->item(pp,col); //
	    if (ppC==p) itS->setChecked(false);
	    else itS->setChecked(true);
	}
    }
}


void fitMatrix10::vertHeaderPressedTablePara( int raw)
{
    int M=spinBoxNumberCurvesToFit->value();
    
    if (M>1)
    {
	QCheckTableItem *itS = (QCheckTableItem *)tablePara->item(raw,0); //
	
	if (itS->isChecked())
	{
	    itS->setChecked(false);
	    
	    
	    for(int mm=0;mm<M;mm++)		
	    {
		QCheckTableItem *itSm = (QCheckTableItem *)tablePara->item(raw,3*mm+1); 
		itSm->setChecked(true);
		
	    }
	}
	else
	{
	    itS->setChecked(true);
	    
	    
	    for(int mm=0;mm<M;mm++)		
	    {
		QCheckTableItem *itSm = (QCheckTableItem *)tablePara->item(raw,3*mm+1); 
		if (mm==0) itSm->setChecked(true);
		else itSm->setChecked(false);
		
	    }
	}    
    }
}


void fitMatrix10::vertHeaderTableCurves(int raw)
{
    int M=spinBoxNumberCurvesToFit->value();
    
    if (raw==0)
    {
	for(int mm=0;mm<M;mm++)		
	{
	    tableCurves->adjustColumn (2*mm+1);	
	}
	updateDatasets();
    }
    if (raw==1 || raw>3)
    {
	
	QCheckTableItem *itS0 = (QCheckTableItem *)tableCurves->item(raw,0); //
	itS0->setChecked(!itS0->isChecked());
	
	for(int mm=1;mm<M;mm++)		
	{
	    QCheckTableItem *itS = (QCheckTableItem *)tableCurves->item(raw,2*mm); 
	    itS->setChecked(itS0->isChecked());
	}
    }
}

//+++ Multi-Fit-Table header
void fitMatrix10::headerTableMultiFit( int col )
{
    int numRows=tableMultiFit->numRows();
    if (col>2 && numRows > 2 )
    {
	int i;
	for (i=2;i<numRows;i++)
	{
	    tableMultiFit->setText(i,col, tableMultiFit->text(1,col));
	}
    }
}
//+++ Multi-Fit-Table header
void fitMatrix10::selectRowsTableMultiFit()
{
    int numRows=tableMultiFit->numRows();
    int i;
    for (i=1;i<numRows;i++)
    {
	if ( tableMultiFit->isSelected(i,0) && !tableMultiFit->isSelected(i,1) )
	{
	    QCheckTableItem *itS0 = (QCheckTableItem *)tableMultiFit->item(i,0); //
	    itS0->setChecked(true);
	}
	
    }
}

void fitMatrix10::tableParaRepaint()
{
    tablePara->hide();
    tablePara->show();
}


void fitMatrix10::openHelpOnline()
{
    app(this)->open_browser(this, "http://www.qtikws.de");
}

void fitMatrix10::selectMultyFromTable()
{
    int p=spinBoxPara->value();
    //+++
    int i,j;
    // +++ FIRST LINE IS UNTOUCHED, REST  IS OUT 
    tableMultiFit->setNumRows(1);
    
    //+++ 
    QStringList tablesAll,tablesSelected; 
    //+++ ALL TABLES OF PROJECT
    tablesAll=app(this)->tableWindows;    
    //+++ WILD PATTERN FOR SKRIPT SELECTION
    QRegExp rx( lineEditPattern->text());
    rx.setWildcard( TRUE );
    
    for (j=0; j<tablesAll.count(); j++)
    {
	if (rx.exactMatch(tablesAll[j])) tablesSelected<<tablesAll[j];
    }
    
    
    
    //+++ SKRIPT TABLE SELECTION
    bool ok;
    QString skriptTable = QInputDialog::getItem(
	    "QtiKWS", "Select a table with fitting results, you want to work again :", tablesSelected, 1, TRUE, &ok, this );
    if ( !ok || skriptTable=="") return;
    
    //+++ FINDING SKRIPT TABLE OBJECT
    QWidgetList *windows = app(this)->windowsList();
    
    Table *skript;
    bool exist=false;
    
    for (i=0;i<(int)windows->count();i++) 
    {
	if (windows->at(i) && windows->at(i)->isA("Table") && windows->at(i)->name()==skriptTable)
	{
	    skript=(Table*)windows->at(i);
	    exist=true;
	}			
    }
    
    if (!exist)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     "There is no table:: "+skriptTable);
	return;		
    }
    //+++ COUNTER: NUMBER OF EXISTING TABLES IN SKRIPT TABLE
    int activeDatasets=0;
    
    //+++ LIST OF ALL Y-COLUMNS
    QStringList colTemp=app(this)->columnsList(Table::Y);
    //+++ LIST OF EXISTING COLUMNS IN SKRIPT TABLE
    QStringList tables;
    //+++ FIRST STEP OF DATA TRANSFET ANF MULTITABLE ARRANGMENT | USED FOR LEFT HEADER
    for (i=0; i< skript->numRows();i++)
    {
	colTemp=app(this)->columnsList(Table::Y);
	QString info=skript->text(i,3);
	QString currentTable=info.left(info.find("|t|")).stripWhiteSpace();
	QString currentY=info.mid(info.find("|t|")+3, info.find("|y|") - info.find("|t|")-3).stripWhiteSpace();
	QString currentWeight=info.mid(info.find("|y|")+3, info.find("|w|") - info.find("|y|")-3).stripWhiteSpace();
	QString currentReso=info.mid(info.find("|w|")+3, info.find("|r|") - info.find("|w|"-3)).stripWhiteSpace();
	
	if (colTemp.contains(currentTable+"_"+currentY))
	{
	    tableMultiFit->setNumRows(activeDatasets + 2); //+++ add row to table
	    tables<<currentTable; //+++  
	    
	    QStringList cols;
	    
	    //+++ CURRENT TABLE NAME
	    
	    QRegExp rxCol(currentTable+"_*"); //+++ WILD PATTERN OF Y-COLUMNS OF CURRENT DATASET
	    rxCol.setWildcard( TRUE );
	    // +++
	    QCheckTableItem *yn = new QCheckTableItem(tableMultiFit, QString::null );
	    tableMultiFit->setItem(activeDatasets+1,0, yn);
	    
	    // +++
	    QComboTableItem *yCol = new QComboTableItem(tableMultiFit, QString::null );
	    tableMultiFit->setItem(activeDatasets+1,1,yCol);
	    
	    for (j=0; j<colTemp.count();j++)
	    {
		if (rxCol.exactMatch(colTemp[j])) cols<<colTemp[j].remove(currentTable+"_");
	    }
	    yCol->setStringList(cols);
	    yCol->setCurrentItem(currentY);
	    
	    // +++
	    QComboTableItem *dYcol = new QComboTableItem(tableMultiFit, QString::null );
	    tableMultiFit->setItem(activeDatasets+1,2,dYcol);
	    
	    colTemp=app(this)->columnsList(Table::yErr);
	    cols.clear();
	    for (j=0; j<colTemp.count();j++)
	    {
		if (rxCol.exactMatch(colTemp[j])) cols<<colTemp[j].remove(currentTable+"_");
	    }
	    dYcol->setStringList(cols);
	    dYcol->setCurrentItem(currentWeight);
	    
	    //+++ 
	    int resoShift=0;   
	    
	    for (j=0;j<p;j++)  
	    {
		tableMultiFit->setText(activeDatasets+1,3+j+resoShift,skript->text(i,7+2*j) ); 
		//		toResLog(currentWeight);
	    }
	    activeDatasets++;
	}
    }
    tables.prepend("All");
    tableMultiFit->setRowLabels(tables);
    for (int tt=0; tt<tableMultiFit->numCols(); tt++) tableMultiFit->adjustColumn (tt);	
}



//*******************************************
//+++ check of Para table to global parameters
//*******************************************
void fitMatrix10::checkGlobalParameters(int raw, int col)
{
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value();
    
    if (M>1) 
    {
	//+++ Parameters && Sharing && Varying 
	
	for (int pp=0; pp<p;pp++)
	{
	    QCheckTableItem *itS = (QCheckTableItem *)tablePara->item(pp,0); // Share?
	    
	    for (int mm=1; mm<M;mm++)
	    {
		QCheckTableItem *itA = (QCheckTableItem *)tablePara->item(pp,3*mm+1); // Vary?
		if (itS->isChecked())
		{
		    itA->setChecked(false);
		    tablePara->setText(pp,3*mm+2,tablePara->text(pp,2));
		    tablePara->setText(pp,3*mm+3,"---");
		}
	    }
	    
	}
    }
    
    if  (col>0 && ((  (int) ( (col-1)/3) )*3)!=(col-1) )
	tablePara->setText(raw, col, QString::number(tablePara->text(raw, col).toDouble(),'G',spinBoxSignDigits->value()));
}

//*******************************************
//*** findFitDataTable
//*******************************************
bool fitMatrix10::findFitDataTable(QString curveName, Table* &table, int &xColIndex, int &yColIndex )
{
    int i, ixy;
    bool exist=false;
    
    QString tableName=curveName.left(curveName.find("_",0));		
    QString colName=curveName.remove(tableName+"_");
    
    QWidgetList *windows = app(this)->windowsList();
    
    for (i=0;i<(int)windows->count();i++)
    {
	if (windows->at(i) && windows->at(i)->isA("Table") && windows->at(i)->name()==tableName)
	{
	    table=(Table*)windows->at(i);	
	    yColIndex=table->colIndex(colName);
	    xColIndex=0;
	    
	    bool xSearch=true;
	    ixy=yColIndex-1; 
	    while(xSearch && ixy>0 )
	    {
		if (table->colPlotDesignation(ixy)==1) 
		{
		    xColIndex=ixy;
		    xSearch=false;
		}
		else ixy--;
	    }
	    exist=true;
	}
    }
    return exist;
}

//*********************************************************
//*** NEW :: findActiveGraph  :: 22-09-2009
//*********************************************************
bool fitMatrix10::findActiveGraph( Graph * & g)
{
    if (app(this)->windowsList()->count()==0 || !app(this)->ws->activeWindow() || !app(this)->ws->activeWindow()->isA("MultiLayer"))  return false;
    
    MultiLayer* plot = (MultiLayer*)app(this)->ws->activeWindow();
    
    if (plot->isEmpty()) return false;
    
    g = (Graph*)plot->activeGraph();
    
    return true;
}

//*********************************************************
//*** NEW :: plotSwitcher:: calculate button was pressed  :: 22-09-2009
//*********************************************************
void fitMatrix10::plotSwitcher()
{
    fitOrCalculate(true);
}


bool fitMatrix10::checkCell(QString &line)
{
    
    QRegExp rx("((\\-|\\+)?\\d\\d*(\\.\\d*)?((E\\-|E\\+)\\d\\d?\\d?\\d?)?)"); 
    
    line=line.stripWhiteSpace();
    line.replace(",",".");
    line.replace("e","E");	
    line.replace("E","E0");	
    line.replace("E0+","E+0");
    line.replace("E0-","E-0");
    line.replace("E0","E+0");
    
    int pos =0;
    pos=rx.search( line, pos );
    
    if ( pos <0 ) return false; 
    
    line=rx.cap( 1 );
    
    return true;
}


//++++++++++++++++++++++++++++
//+ checkConstrains
//++++++++++++++++++++++++++++
// source :: (0) simulate interf :: (1) fit interf :: (2) set-to-set interf
// m :: number of matrixes   [1...M]
void fitMatrix10::checkConstrains(int source, int m)
{ 
    int M=spinBoxNumberCurvesToFit->value();
    int P=spinBoxPara->value();
    int digits=spinBoxSignDigits->value()-1;
    
    if (m<1) return;
    if (m>M) return;
    
    for (int pp=0; pp<P; pp++) tableParaSimulate->setText(pp,0,QString::number(gsl_vector_get(F_para,pp),'G',digits+1));
    if (source>0) for (int pp=0; pp<P; pp++) tablePara->setText(pp,3*(m-1)+2, QString::number(gsl_vector_get(F_para,pp),'G',digits+1));    
}


//+++++FUNCTION::check Table Existence ++++++++++++++++++++++++
bool fitMatrix10::checkTableExistence(QString tableName, Table* &w)
{
    int i;
    bool exist=false;
    
    QWidgetList* tableList=app(this)->tableList();
    //+++
    for (i=0;i<(int)tableList->count();i++)  
    {
	if (tableList->at(i) && tableList->at(i)->name()==tableName) 
	{
	    w=(Table *)tableList->at(i);
	    exist=true;
	}
    }
    return exist;
}

//+++++FUNCTION::check Table Existence ++++++++++++++++++++++++
bool fitMatrix10::checkTableExistence(QString tableName)
{
    int i;
    bool exist=false;
    
    QWidgetList* tableList=app(this)->tableList();
    //+++
    for (i=0;i<(int)tableList->count();i++)  
    {
	if (tableList->at(i) && tableList->at(i)->name()==tableName) 
	{
	    exist=true;
	}
    }
    return exist;
}

//*******************************************
//+++  new-daDan:: find Table List By Label
//*******************************************
void fitMatrix10::findTableListByLabel(QString winLabel,QStringList  &list)
{
    int mm;
    list.clear();
    //+++
    QWidgetList* windows=app(this)->windowsList();
    //+++
    for (mm=0; mm < (int)windows->count(); mm++ )
    {
	if ( windows->at(mm)->isA("Table")  )
	{
	    Table* ttt=(Table*) windows->at(mm);
	    if (ttt->windowLabel().contains(winLabel) )
		list<<windows->at(mm)->name();
	}
    }
}



void fitMatrix10::readSettingsTable()
{
    
    QStringList list;
    findTableListByLabel("FIT2D::Settings::Table",list);
    
    if (list.count()==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("No table with lablel FIT2D::Settings::Table was found!"));
	return;
    }
    
    bool ok;
    QString table = QInputDialog::getItem(
	    "QtiKWS", "Select Settings-Table:", list, 0, FALSE, &ok,
	    this );
    if ( !ok )return;
    
    Table *w;
    if (!checkTableExistence(table,w) ) return;
    
    QStringList parameters;
    parameters.clear();
    
    for (int i=0; i<w->numRows(); i++) parameters<<w->text(i,0);
    
    if (parameters.count()==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Check Settings-Table!"));
	return;
    }
    
    QString s;
    
    //+++ Function::Folder
    if (parameters.findIndex("Function::Folder")>=0) 
    {
	libPath=w->text(parameters.findIndex("Function::Folder"),1).remove(" <").stripWhiteSpace();
	scanGroup();
	listBoxGroup->setSelected(0,TRUE);
	groupFunctions("ALL");
    } 
    else return;
    
    //+++ Function::Name
    if (parameters.findIndex("Function::Name")>=0) 
    {
	s=w->text(parameters.findIndex("Function::Name"),1).remove(" <").stripWhiteSpace();
	
	if (listBoxFunctions->index(listBoxFunctions->findItem(s,Qt::ExactMatch))<0) return;
	
	listBoxFunctions->setSelected(listBoxFunctions->findItem(s,Qt::ExactMatch), true);
	
	openDLL(s);
    }
    else return;
    
    //+++ Function::Parameters::Number
    if (parameters.findIndex("Function::Parameters::Number")>=0) 
    {
	s=w->text(parameters.findIndex("Function::Parameters::Number"),1).remove(" <").stripWhiteSpace();
	
	if (spinBoxPara->value()!=s.toInt())
	{
	    QMessageBox::warning(this,tr("QtiKWS"),
				 tr("Check Function :: Number of parameters!"));
	    return;
	}
    }
    else return;
    
    //+++ Function::Global::Fit
    if (parameters.findIndex("Function::Global::Fit")>=0) 
    {
	s=w->text(parameters.findIndex("Function::Global::Fit"),1).remove(" <").stripWhiteSpace();
	
	if (s.contains("yes")) 
	{
	    checkBoxMultiData->setChecked(true);
	    spinBoxNumberCurvesToFit->setEnabled(true);
	}
	else 
	{
	    checkBoxMultiData->setChecked(false);
	    spinBoxNumberCurvesToFit->setEnabled(false);
	    spinBoxNumberCurvesToFit->setValue(1);
	}
    }
    else return;
    
    //+++ Function::Global::Fit::Number
    if (parameters.findIndex("Function::Global::Fit::Number")>=0) 
    {
	s=w->text(parameters.findIndex("Function::Global::Fit::Number"),1).remove(" <").stripWhiteSpace();
	
	if (s.toInt()>0 && checkBoxMultiData->isChecked())
	{
	    spinBoxNumberCurvesToFit->setValue(s.toInt());
	}
    }
    
    slotStackFitNext();
    
    QStringList lst, allCurves;
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value();
    
    QStringList listN; 
    int nRows, nCols;
    
    //+++ Session::Data::Matrixes
    if (parameters.findIndex("Session::Data::Matrixes")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Data::Matrixes"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{
	    QComboTableItem *curves =(QComboTableItem*)tableCurves->item (0, 2*mm+1);
	    
	    
	    if (findAllMatrixesLikeExample(lst[mm], listN, nRows, nCols))
	    {
		curves->setCurrentItem(lst[mm]);
		tableCurvechanged(0, 2*mm+1);
	    }
	}
	
    }
    
    //+++ Session::Mask::Use
    if (parameters.findIndex("Session::Mask::Use")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Mask::Use"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{
	    QCheckTableItem *item = (QCheckTableItem*)tableCurves->item (1,2*mm);
	    if (lst[mm]=="1") item->setChecked(true);
	    else item->setChecked(false);
	}
    }    
    
    //+++ Session::Mask::Names
    if (parameters.findIndex("Session::Mask::Names")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Mask::Names"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{
	    QComboTableItem *curves =(QComboTableItem*)tableCurves->item (1, 2*mm+1);
	    curves->setCurrentItem(lst[mm]);
	}
    }
    
    
    //+++ Session::Weighting::Use
    if (parameters.findIndex("Session::Weighting::Use")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Weighting::Use"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{
	    QCheckTableItem *item = (QCheckTableItem*)tableCurves->item (4,2*mm);
	    if (lst[mm]=="1") item->setChecked(true);
	    else item->setChecked(false);
	}
    }    
    
    //+++ Session::Weighting::Dataset
    if (parameters.findIndex("Session::Weighting::Dataset")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Weighting::Dataset"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int mm=0;mm<M;mm++)
	{	    
	    QComboTableItem *curves =(QComboTableItem*)tableCurves->item (4, 2*mm+1);
	    curves->setCurrentItem(lst[mm]);
	}
    }
    
    //+++ Session::xMatrixes::Dataset
    if (parameters.findIndex("Session::xMatrixes::Dataset")>=0) 
    {
	s=w->text(parameters.findIndex("Session::xMatrixes::Dataset"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	int xNumbers=spinBoxXnumber->value()-2;
	int iii=0;
	for (int i=0;i<M;i++) for (int xx=0; xx< xNumbers;xx++) 
	{	    
	    QComboTableItem *curves =(QComboTableItem*)tableCurves->item (5+xx, 2*i+1);
	    curves->setCurrentItem(lst[iii]);
	    iii++;
	}
    }    
    
    //+++ Session::Limits::Left
    if (parameters.findIndex("Session::Limits::Left")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Limits::Left"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int pp=0; pp<gsl_min(p,lst.count());pp++)
	{
	    tableControl->setText(pp,0,lst[pp]);
	}
    }
    
    //+++ Session::Limits::Right
    if (parameters.findIndex("Session::Limits::Right")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Limits::Right"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	for (int pp=0; pp<gsl_min(p,lst.count());pp++)
	{
	    tableControl->setText(pp,4,lst[pp]);
	}
    }
    
    //+++ Session::Limits::Scale::Left
    if (parameters.findIndex("Session::Limits::Scale::Left")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Limits::Scale::Left"),1).remove(" <").stripWhiteSpace();
	lineEditLeftMargin->setText(s);
    }
    
    //+++ Session::Limits::Scale::Right
    if (parameters.findIndex("Session::Limits::Scale::Right")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Limits::Scale::Right"),1).remove(" <").stripWhiteSpace();
	lineEditRightMargin->setText(s);
    }
    
    for (int mm=0;mm<M;mm++)
	colList( tableCurves->text(0, 2*mm+1), 2*mm+1);
    
    //+++ Session::Options::Fit::Control
    if (parameters.findIndex("Session::Options::Fit::Control")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Options::Fit::Control"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	int value=lst[0].toInt();
	if (value >-1 && value<=6) comboBoxFitMethod->setCurrentItem(value);
	//+++
	spinBoxMaxIter->setValue(lst[1].toInt());
	//+++
	lineEditToleranceAbs->setText(lst[2]);		
	//+++
	lineEditTolerance->setText(lst[3]);
	//+++
	spinBoxSignDigits->setValue(lst[4].toInt());
	//+++
	value=lst[5].toInt();
	if (value >-1 && value<=6) comboBoxWeightingMethod->setCurrentItem(value);
	if (lst[6]=="1") checkBoxShowCurvesInGraph->setChecked(true); else checkBoxShowCurvesInGraph->setChecked(false);
	//+++
	lineEditWA->setText(lst[7]);
	//+++
	lineEditWB->setText(lst[8]);
	//+++
	lineEditWC->setText(lst[9]);
	//
	spinBoxGenomeCount->setValue(lst[10].toInt());
	//
	spinBoxMaxNumberGenerations->setValue(lst[11].toInt());
	//
	lineEditSelectionRate->setText(lst[12]);
	//
	lineEditMutationRate->setText(lst[13]);
	//
	spinBoxRandomSeed->setValue(lst[14].toInt());   
	
    }
    algorithmSelected();
    weightChanged();
    
    if (checkBoxMultiData->isChecked())
    {
	//+++ Session::Parameters::Shared
	if (parameters.findIndex("Session::Parameters::Shared")>=0) 
	{
	    s=w->text(parameters.findIndex("Session::Parameters::Shared"),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    
	    for (int pp=0;pp<p;pp++)
	    {
		QCheckTableItem *active = (QCheckTableItem *)tablePara->item(pp,0);
		
		if (lst[pp]=="1") active->setChecked(true); else active->setChecked(false);
	    }
	}
    }
    
    for (int pp=0;pp<p;pp++)
    {
	QString uselName="Session::Parameters::Use::"+QString::number(pp+1);
	
	//+++ useName
	if (parameters.findIndex(uselName)>=0) 
	{
	    s=w->text(parameters.findIndex(uselName),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    
	    for (int mm=0; mm<M;mm++)
	    {
		QCheckTableItem *active = (QCheckTableItem *)tablePara->item(pp,3*mm+1);			
		if (lst[mm]=="1") active->setChecked(true); else active->setChecked(false)		;
	    }
	}
	
	QString cellName="Session::Parameters::Values::"+QString::number(pp+1);
	
	//+++ useName
	if (parameters.findIndex(cellName)>=0) 
	{
	    s=w->text(parameters.findIndex(cellName),1).remove(" <").stripWhiteSpace();
	    lst.clear();
	    lst=lst.split(" ",s,false);
	    
	    for (int mm=0; mm<M;mm++)
	    {
		tablePara->setText(pp,3*mm+2, lst[mm]);
	    }
	}
    }
    
    //+++ Session::Parameters::Errors
    if (parameters.findIndex("Session::Parameters::Errors")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Parameters::Errors"),1).remove(" <").stripWhiteSpace();
	lst.clear();
	lst=lst.split(" ",s,false);
	
	int iii=0;
	for (int i=0; i<M;i++) for (int pp=0;pp<p;pp++) 
	{
	    tablePara->setText(pp,3*i+3,lst[iii]);
	    iii++;
	}
    } 
    
    //+++ Session::Chi2
    if (parameters.findIndex("Session::Chi2")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Chi2"),1).remove(" <").stripWhiteSpace();
	textLabelChi->setText(s);
    } 
    //+++ Session::R2
    if (parameters.findIndex("Session::R2")>=0) 
    {
	s=w->text(parameters.findIndex("Session::R2"),1).remove(" <").stripWhiteSpace();
	textLabelR2->setText(s);
    } 
    //+++ Session::Time
    if (parameters.findIndex("Session::Time")>=0) 
    {
	s=w->text(parameters.findIndex("Session::Time"),1).remove(" <").stripWhiteSpace();
	textLabelTime->setText(s);
    } 
    
    //+++ Simulate::Output::List
    if (parameters.findIndex("Simulate::Output::List")>=0) 
    {
	s=w->text(parameters.findIndex("Simulate::Output::List"),1).remove(" <").stripWhiteSpace();
	comboBoxOutput->setCurrentItem(s.toInt());
    }  
    
    //+++ Simulate::Output::Residues
    if (parameters.findIndex("Simulate::Output::Residues")>=0) 
    {
	s=w->text(parameters.findIndex("Simulate::Output::Residues"),1).remove(" <").stripWhiteSpace();
	if (s.contains("yes"))
	{
	    checkBoxResidues->setChecked(true);
	}
	else
	{
	    checkBoxResidues->setChecked(false);
	}
    }  
    
    //+++ Simulate::Output::ResiduesSlices
    if (parameters.findIndex("Simulate::Output::ResiduesSlices")>=0) 
    {
	s=w->text(parameters.findIndex("Simulate::Output::ResiduesSlices"),1).remove(" <").stripWhiteSpace();
	if (s.contains("yes"))
	{
	    checkBoxResiduesSlices->setChecked(true);
	}
	else
	{
	    checkBoxResiduesSlices->setChecked(false);
	}
    }    
    
    
}


void fitMatrix10::horizHeaderCurves( int col )
{
    tableCurves->adjustColumn (col);	
}

void fitMatrix10::updateDatasets()
{
    //+++ Initiation of multi-Set Tables
    int M=spinBoxNumberCurvesToFit->value();
    
    QString currentMatrix;
    //+++ Set Data-Sets List
    for(int mm=0;mm<M;mm++)		
    {
	//+++ Data sets selection ComboBox
	QString oldYcol=tableCurves->text(0,2*mm+1);
	QComboTableItem *curve = (QComboTableItem*)tableCurves->item (0, 2*mm+1);
	curve->setStringList(findAllMatrixes());
	if (oldYcol!="") curve->setCurrentItem(oldYcol);
	colList(curve->currentText(), 2*mm+1);
    }
}


//+++
//+++ Matrixes Search 
bool fitMatrix10::findAllMatrixesLikeExample(QString exampleMatrix, QStringList &list, int &nRows, int &nCols)
{
    nRows=0; 
    nCols=0;
    list.clear();
    
    QStringList listAll;
    
    listAll=findAllMatrixes();
    
    if (listAll.contains(exampleMatrix)==0) return false;
    
    QWidgetList* windows=app(this)->windowsList();
    
    bool OK=false;
    // +++
    for (int i=0;i<(int)windows->count();i++)
    {
	if (windows->at(i) && windows->at(i)->isA("Matrix") && windows->at(i)->name()==exampleMatrix)
	{
	    Matrix *mask=(Matrix*)windows->at(i);
	    nRows=mask->numRows();
	    nCols=mask->numCols();	   
	    OK=true;
	}
    }
    
    if (!OK) return false;
    
    for (int m=0; m<listAll.count(); m++)
    {
	for (int i=0;i<(int)windows->count();i++)
	{
	    if (windows->at(i) && windows->at(i)->isA("Matrix") && windows->at(i)->name()==listAll[m])
	    {
		Matrix *mask=(Matrix*)windows->at(i);
		
		if (nRows==mask->numRows() && nCols==mask->numCols()) list<<listAll[m];		
	    }
	}
	
    }
    return true;
}

//+++
//+++ Matrixes Search by Dimension
bool fitMatrix10::findAllMatrixesByDimension(QStringList &list, int nRows, int nCols)
{
    list.clear();
    
    QWidgetList* windows=app(this)->windowsList();
    
    bool OK=false;
    // +++
    for (int i=0;i<(int)windows->count();i++)
    {
	if (windows->at(i) && windows->at(i)->isA("Matrix"))
	{
	    Matrix *mask=(Matrix*)windows->at(i);
	    int nnRows=mask->numRows();
	    int nnCols=mask->numCols();	   
	    if (nnRows==nRows && nnCols==nCols)
		list<<windows->at(i)->name();
	    OK=true;
	}
    }
    
    if (!OK) return false;    
    
    return true;
}
//+++
//+++ Matrixes Search 
QStringList fitMatrix10::findAllMatrixes()
{
    //+++
    QStringList list;
    
    QWidgetList* windows=app(this)->windowsList();
    
    for (int i=0;i<(int)windows->count();i++)
    {
	if (windows->at(i) && windows->at(i)->isA("Matrix"))
	{
	    list<<windows->at(i)->name();
	}
    }
    return list;
}


//
bool fitMatrix10::readDataToFit(size_t *Rows, size_t *Columns, int &Ntotal, gsl_matrix *&I, gsl_matrix *&dI, gsl_matrix *&mask, gsl_matrix *&xMatrix)
{
    int M=spinBoxNumberCurvesToFit->value();
    int xNumber=spinBoxXnumber->value();
    
    Ntotal=0;
    int rows, cols;
    int colShift=0;
    
    //+++ read Masks && Ntotal
    for (int mm=0; mm<M;mm++)
    {
	QCheckTableItem *maskInUse = (QCheckTableItem*)tableCurves->item (1,2*mm);
	
	if (maskInUse->isChecked())
	{
	    Matrix* matrix;
	    if (!findFitDataMatrix(tableCurves->text(1,2*mm+1), matrix, rows, cols )) return false;
	    if (rows!=Rows[mm] || cols!=Columns[mm]) return false;
	    
	    for (int i=0; i<rows; i++) for (int j=0; j<cols; j++)
	    {
		if (matrix->text(i,j).toDouble()>0)
		{
		    gsl_matrix_set(mask, i, colShift+j, 1.0);
		    Ntotal++;
		}
	    }
	}
	else 
	{
	    for (int i=0; i<Rows[mm]; i++) for (int j=0; j<Columns[mm]; j++)
	    {
		gsl_matrix_set(mask, i, colShift+j, 1.0);
		Ntotal++;
	    }
	}
	colShift+=Columns[mm];
    }
    
    colShift=0;
    
    //+++ read Data Matrixes
    for (int mm=0; mm<M;mm++)
    {
	Matrix* matrix;
	
	if (!findFitDataMatrix(tableCurves->text(0,2*mm+1),matrix, rows, cols )) return false;
	
	if (rows!=Rows[mm] || cols!=Columns[mm]) return false;
	
	for (int i=0; i<rows; i++) for (int j=0; j<cols; j++)
	{
	    if (gsl_matrix_get(mask, i, colShift+j)>0 )
	    {
		gsl_matrix_set(I, i, colShift+j, matrix->text(i,j).toDouble());
	    }
	}
	colShift+=Columns[mm];	
    }
    
    
    
    colShift=0;
    double wa=lineEditWA->text().toDouble(); wa=fabs(wa);
    double wb=lineEditWB->text().toDouble(); wb=fabs(wb); if (wb==0) wb=1.0;
    double wc=lineEditWC->text().toDouble(); wc=fabs(wc);
    
    bool weightFromMatrix=false;
    
    if (comboBoxFitMethod->currentItem()==0 || comboBoxFitMethod->currentItem()==2) weightFromMatrix=true;
    
    //+++ read Weight
    for (int mm=0; mm<M;mm++)
    {
	QCheckTableItem *weightInUse = (QCheckTableItem*)tableCurves->item (4,2*mm);
	
	if (weightInUse->isChecked())
	{
	    Matrix* matrix;
	    if (weightFromMatrix && !findFitDataMatrix(tableCurves->text(4,2*mm+1),matrix, rows, cols ) ) return false;
	    if (weightFromMatrix && (rows!=Rows[mm] || cols!=Columns[mm])) return false;
	    
	    for (int i=0; i<Rows[mm]; i++) for (int j=0; j<Columns[mm]; j++)
	    {		
		if (comboBoxWeightingMethod->currentItem()==0)//+++ [ w = 1/dY² ] 
		{
		    if (matrix->text(i,j).toDouble()==0.0 )
			gsl_matrix_set(dI, i, colShift+j, 1.0 );
		    else
			gsl_matrix_set(dI, i, colShift+j, fabs( matrix->text(i,j).toDouble()) );		    
		}
		else if (comboBoxWeightingMethod->currentItem()==1) //+++ [ w = 1/Y  ] 
		{
		    if (gsl_matrix_get(I, i, colShift+j)==0.0)
			gsl_matrix_set(dI, i, colShift+j, 1.0 );
		    else
			gsl_matrix_set(dI, i, colShift+j, sqrt(fabs( gsl_matrix_get(I, i, colShift+j) )) );
		}
		else if (comboBoxWeightingMethod->currentItem()==2)//+++ [ w = dY  ]
		{
		    if (matrix->text(i,j).toDouble()==0.0 )
			gsl_matrix_set(dI, i, colShift+j, 1.0 );
		    else
			gsl_matrix_set(dI, i, colShift+j, 1/sqrt(fabs(matrix->text(i,j).toDouble())));
		}
		else if (comboBoxWeightingMethod->currentItem()==3) //+++ [ w = 1/Y² ]
		{
		    if (gsl_matrix_get(I, i, colShift+j)==0.0)
			gsl_matrix_set(dI, i, colShift+j, 1.0 );
		    else
			gsl_matrix_set(dI, i, colShift+j, fabs( gsl_matrix_get(I, i, colShift+j) ) );
		}
		else if (comboBoxWeightingMethod->currentItem()==4) //+++ [ w = 1/Y^a ]
		{
		    if (gsl_matrix_get(I, i, colShift+j)==0.0)
			gsl_matrix_set(dI, i, colShift+j, 1.0 );
		    else
			gsl_matrix_set(dI, i, colShift+j, pow( fabs( gsl_matrix_get(I, i, colShift+j)),wa/2) ); 
		}
		else if (comboBoxWeightingMethod->currentItem()==5) //+++ [ w = 1/|c^a+b*Y^a| ]
		{
		    if (gsl_matrix_get(I, i, colShift+j)==0.0)
			gsl_matrix_set(dI, i, colShift+j, 1.0 );
		    else
			gsl_matrix_set(dI, i, colShift+j, sqrt(pow(wc,wa)+wb*pow( fabs(gsl_matrix_get(I, i, colShift+j)),wa)) ); 
		}
	    } 
	}
	colShift+=Columns[mm];
    }
    
    colShift=0;
    int rowShift=0;
    
    if (xNumber>2)
    {
	//+++ read xMatrix
	for (int mm=0; mm<M;mm++)
	{
	    for (int xx=2; xx<xNumber;xx++)
	    {
		Matrix* matrix;
		
		if (!findFitDataMatrix(tableCurves->text(5+xx-2,2*mm+1),matrix, rows, cols ) ) return false;
		if (rows!=Rows[mm] || cols!=Columns[mm]) return false;
		
		for (int i=0; i<Rows[mm]; i++) for (int j=0; j<Columns[mm]; j++)
		{
		    if (matrix->text(i,j)=="" && gsl_matrix_get(mask, i, colShift+j)==1.0 )
		    {
			gsl_matrix_set(mask, i, colShift+j, 0.0);
			Ntotal--;
		    }
		    else
			gsl_matrix_set(xMatrix, rowShift+i, colShift+j, matrix->text(i,j).toDouble());
		}
		rowShift+=Rows[mm];
	    }
	    colShift+=Columns[mm];
	    rowShift=0;
	}
    }
    
    return true;
}


bool fitMatrix10::readDataToFitSingle(int mm, size_t *Rows, size_t *Columns, int &Ntotal, gsl_matrix *&I, gsl_matrix *&dI, gsl_matrix *&mask, gsl_matrix *&xMatrix)
{
    int M=spinBoxNumberCurvesToFit->value();
    int xNumber=spinBoxXnumber->value();
    
    Ntotal=0;
    int rows, cols;
    int colShift=0;
    int mmm=0;
    //+++ read Masks && Ntotal
    QCheckTableItem *maskInUse = (QCheckTableItem*)tableCurves->item (1,2*mm);
    
    if (maskInUse->isChecked())
    {
	Matrix* matrix;
	if (!findFitDataMatrix(tableCurves->text(1,2*mm+1), matrix, rows, cols )) return false;
	if (rows!=Rows[0] || cols!=Columns[0]) return false;
	
	for (int i=0; i<rows; i++) for (int j=0; j<cols; j++)
	{
	    if (matrix->text(i,j).toDouble()>0)
	    {
		gsl_matrix_set(mask, i, colShift+j, 1.0);
		Ntotal++;
	    }
	}
    }
    else 
    {
	gsl_matrix_set_all(mask,1.0);
	Ntotal=Rows[0]*Columns[0];
    }
    
    //+++ read Data Matrixes
    Matrix* matrix;
    if (!findFitDataMatrix(tableCurves->text(0,2*mm+1),matrix, rows, cols )) return false;
    if (rows!=Rows[0] || cols!=Columns[0]) return false;
    
    for (int i=0; i<rows; i++) for (int j=0; j<cols; j++)
    {

	    gsl_matrix_set(I, i, colShift+j, matrix->text(i,j).toDouble());
    }	
   

    
    double wa=lineEditWA->text().toDouble(); wa=fabs(wa);
    double wb=lineEditWB->text().toDouble(); wb=fabs(wb); if (wb==0) wb=1.0;
    double wc=lineEditWC->text().toDouble(); wc=fabs(wc);
    
    bool weightFromMatrix=false;
    
    if (comboBoxFitMethod->currentItem()==0 || comboBoxFitMethod->currentItem()==2) weightFromMatrix=true;
    
    //+++ read Weight
    QCheckTableItem *weightInUse = (QCheckTableItem*)tableCurves->item (4,2*mm);
    
    if (weightInUse->isChecked())
    {
	Matrix* matrix;
	if (weightFromMatrix && !findFitDataMatrix(tableCurves->text(1,2*mm+1),matrix, rows, cols ) ) return false;
	if (weightFromMatrix && (rows!=Rows[0] || cols!=Columns[0])) return false;
	
	for (int i=0; i<Rows[0]; i++) for (int j=0; j<Columns[0]; j++)
	{		
	    if (comboBoxWeightingMethod->currentItem()==0)//+++ [ w = 1/dY² ] 
	    {
		if (matrix->text(i,j)=="" && gsl_matrix_get(mask, i, colShift+j)==1.0 )
		{
		    gsl_matrix_set(mask, i, colShift+j, 0.0);
		    Ntotal--;
		}
		else if (matrix->text(i,j).toDouble()==0.0 )
		    gsl_matrix_set(dI, i, colShift+j, 1.0 );
		else
		    gsl_matrix_set(dI, i, colShift+j, fabs( matrix->text(i,j).toDouble()) );
		
	    }
	    else if (comboBoxWeightingMethod->currentItem()==1) //+++ [ w = 1/Y  ] 
	    {
		if (gsl_matrix_get(I, i, colShift+j)==0.0)
		    gsl_matrix_set(dI, i, colShift+j, 1.0 );
		else
		    gsl_matrix_set(dI, i, colShift+j, sqrt(fabs( gsl_matrix_get(I, i, colShift+j) )) );	
	    }
	    else if (comboBoxWeightingMethod->currentItem()==2)//+++ [ w = dY  ]
	    {
		if (matrix->text(i,j)=="" && gsl_matrix_get(mask, i, colShift+j)==1.0 )
		{
		    gsl_matrix_set(mask, i, colShift+j, 0.0);
		    Ntotal--;
		}
		else if (matrix->text(i,j).toDouble()==0.0 )
		    gsl_matrix_set(dI, i, colShift+j, 1.0 );
		else
		    gsl_matrix_set(dI, i, colShift+j, 1/sqrt(fabs(matrix->text(i,j).toDouble())));	
	    }
	    else if (comboBoxWeightingMethod->currentItem()==3) //+++ [ w = 1/Y² ]
	    {
		if (gsl_matrix_get(I, i, colShift+j)==0.0)
		    gsl_matrix_set(dI, i, colShift+j, 1.0 );
		else
		    gsl_matrix_set(dI, i, colShift+j, fabs( gsl_matrix_get(I, i, colShift+j) ) );
	    }	
	    else if (comboBoxWeightingMethod->currentItem()==4) //+++ [ w = 1/Y^a ]
	    {
		if (gsl_matrix_get(I, i, colShift+j)==0.0)
		    gsl_matrix_set(dI, i, colShift+j, 1.0 );
		else
		    gsl_matrix_set(dI, i, colShift+j, pow( fabs( gsl_matrix_get(I, i, colShift+j)),wa/2) ); 
	    }
	    else if (comboBoxWeightingMethod->currentItem()==5) //+++ [ w = 1/|c^a+b*Y^a| ]
	    {
		if (gsl_matrix_get(I, i, colShift+j)==0.0)
		    gsl_matrix_set(dI, i, colShift+j, 1.0 );
		else
		    gsl_matrix_set(dI, i, colShift+j, sqrt(pow(wc,wa)+wb*pow( fabs(gsl_matrix_get(I, i, colShift+j)),wa)) ); 
	    }
	} 
    }
    
    
    int rowShift=0;
    
    if (xNumber>2)
    {
	//+++ read xMatrix
	for (int xx=2; xx<xNumber;xx++)
	{
	    Matrix* matrix;
	    
	    if (!findFitDataMatrix(tableCurves->text(5+xx-2,2*mm+1),matrix, rows, cols ) ) return false;
	    if (rows!=Rows[0] || cols!=Columns[0]) return false;
	    
	    for (int i=0; i<Rows[0]; i++) for (int j=0; j<Columns[0]; j++)
	    {
		if (matrix->text(i,j)=="" && gsl_matrix_get(mask, i, colShift+j)==1.0 )
		{
		    gsl_matrix_set(mask, i, colShift+j, 0.0);
		    Ntotal--;
		}
		else
		    gsl_matrix_set(xMatrix, rowShift+i, colShift+j, matrix->text(i,j).toDouble());	
	    }
	    rowShift+=Rows[0];
	}	
    }
    
    return true;
}


//*******************************************
//*** findFitDataTable
//*******************************************
bool fitMatrix10::findFitDataMatrix(QString matrixName, Matrix* &matrix, int &rows, int &cols )
{
    bool exist=false;
    
    QWidgetList *windows = app(this)->windowsList();
    
    for (int i=0;i<(int)windows->count();i++)
    {
	if (windows->at(i) && windows->at(i)->isA("Matrix") && windows->at(i)->name()==matrixName)
	{
	    matrix=(Matrix*)windows->at(i);	
	    cols=matrix->numCols();
	    rows=matrix->numRows();
	    exist=true;
	}
    }
    return exist;
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++FUNCTIONS::create Matrix from gsl_matrix-Uni++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
void fitMatrix10::makeMatrixUni( gsl_matrix * gmatrix, QString name, QString label, int xDim, int yDim)
{    
    int i,j;
    //+++
    QWidgetList* windows=app(this)->windowsList();
    //+++
    QString ss;
    //+++
    bool existYN=false;
    Matrix* m;
    //+++
    
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
	ss=windows->at(mm)->name();
	
	if (ss==name && windows->at(mm)->isA("Matrix"))
	{
	    m=(Matrix *)windows->at(mm);
	    existYN=true;
	    m->setMatrixDimensions(yDim,xDim);
	    m->setCoordinates(0.5,xDim+0.5,0.5,yDim+0.5);
	    //m->setNumericFormat('E',8); // BUGGGGGG   .... Kill program .....
	    
	}
    }
    //+++make Unique Name
    
    if (!existYN)
    {
	m=app(this)->newMatrixHidden(name,yDim,xDim);
	app(this)->updateRecentProjectsList();
	m->setNumericFormat('E',8);
	m->setCoordinates(0.5,xDim+0.5,0.5,yDim+0.5);
    }
    
    
    //+++
    
    for (i=0;i<yDim;i++) for (j=0;j<xDim;j++)
    {
	m->setText(i,j,QString::number(gsl_matrix_get(gmatrix,i,j),'E',8));
    }
    
    //+++
    m->setWindowLabel(label);
    app(this)->setListViewLabel(m->name(), label);
    app(this)->updateWindowLists(m);

    m->setColumnsWidth(140);
    m->notifyChanges();
    
    
    // rescale active graph with current matrix
    Graph *g;
    if (!findActiveGraph(g)) return;    
    if (g->isPiePlot()) return;
    QwtPlotCurve *c = g->curve(0);
    if (!c)	return;
    if (c->rtti() != QwtPlotItem::Rtti_PlotSpectrogram) return;
    
    if (g->plotItemsList()[0] == m->name())    app(this)->setAutoScale();  
    //    std::cout<<"curve"<< g->curvesList()[0] << " matrix "<<m->name()<<"\n" ;
}

bool fitMatrix10::generateSimulatedMatrixAll()
{
    
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value();				//Number of Parameters per Curve
    
    //+++
    if (p==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Select Function"));
	return false;
    }
    
    //+++ number of adjustable parameters
    int np=0;
    for (int pp=0; pp<p;pp++)
    {	
	QCheckTableItem *itS = (QCheckTableItem *)tablePara->item(pp,0); // Share?
	QCheckTableItem *itA0 = (QCheckTableItem *)tablePara->item(pp,1); // Vary?
	if (itA0->isChecked()) 
	{
	    np++;
	}
	
	for (int mm=1; mm<M;mm++)
	{
	    QCheckTableItem *itA = (QCheckTableItem *)tablePara->item(pp,3*mm+1); // Vary?
	    if (!itS->isChecked())
	    {
		if (itA->isChecked()) 
		{
		    np++;
		}
		
	    }
	    
	}
    } 
    
    
    int xNumber=spinBoxXnumber->value();
    
    //+++Read data sets to Qtotal && Itotal && Sigmatotal && dItotal && usePoint    
    size_t 	*Rows=new size_t[M];		// Vector of  Rows
    size_t 	*Columns=new size_t[M];		// Vector of  Columns
    
    int Ntotal;
    int rowsAll=0;
    int colsAll=0;
    
    for (int mm=0;mm<M;mm++)
    {
	Rows[mm]=tableCurves->text(2,2*mm+1).toInt();
	Columns[mm]=tableCurves->text(3,2*mm+1).toInt();
	
	colsAll+=Columns[mm];
	if (Rows[mm]>rowsAll) rowsAll=Rows[mm];
    }
    
    gsl_matrix *I=gsl_matrix_calloc(rowsAll,colsAll); 
    gsl_matrix *dI=gsl_matrix_calloc(rowsAll,colsAll);
    gsl_matrix *mask=gsl_matrix_calloc(rowsAll,colsAll);
    gsl_matrix *xMatrix;
    if (xNumber>2) xMatrix=gsl_matrix_calloc((xNumber-2)*rowsAll,colsAll);
    
    gsl_matrix *Isim=gsl_matrix_calloc(rowsAll,colsAll); 
    gsl_matrix *Iresidues=gsl_matrix_calloc(rowsAll,colsAll); 
    
    gsl_matrix_set_all(dI,1.0);
    
    
    if ( !readDataToFit(Rows, Columns, Ntotal, I, dI, mask,xMatrix) )
    {
	QMessageBox::warning(this,tr("QtiKws"),
			     tr("Fit stopped :: problem to read data!"));
	return false;
    }
    
    
    int colStart=0;
    
    double Ii, currentMask,currentDataPoint,currentWeight;
    
    
    
    
    //+++ init parameters of F
    double *xx=new double[xNumber];
    
    for (int i=0; i<xNumber; i++) 
    {
	xx[i]=0.0;
    }
    
    //+++ 
    bool beforeFit=false;
    bool afterFit=false;
    bool beforeIter=false;
    bool afterIter=false;
    //+++
    int prec=spinBoxSignDigits->value();
    
    //+++ ,tableName,tableColNames,tableColDestinations,mTable
    std::string tableName="no-matrix";
    std::string *tableColNames; 
    int *tableColDestinations; 
    gsl_matrix * mTable;
    
    functionND paraND={xx, F_para, xNumber, M, Rows, Columns, I, dI, mask, xMatrix, beforeFit, afterFit, beforeIter, afterIter,prec,tableName,tableColNames,tableColDestinations,mTable};
    
    F.params=&paraND;
    
    int rowStart;
    int N=0;
    double Imean=0;
    
    for (int mm = 0; mm < M; mm++)
    {    
	//+++ calculate f vector
	for (int rr=0; rr<Rows[mm];rr++) for(int cc=0;cc<Columns[mm];cc++) 
	{
	    currentMask=gsl_matrix_get(mask, rr, cc+colStart);
	    if (currentMask>0)
	    {
		N++;
		Imean+= gsl_matrix_get(  I, rr, cc+colStart);
	    }
	}
	colStart+=Columns[mm];
    }
    
    
    if (N>0) Imean/=N;
    
    double ssl=0, R2=0;
    double  sumChi2=0, sumChi2Norm=0;
    
    
    colStart=0;
    for (int mm = 0; mm < M; mm++)
    {
	//+++ updare parameters value to current matrix
	for (int pp=0;pp<p;pp++) gsl_vector_set(F_para,pp,tablePara->text(pp, 3*mm+2).toDouble());
	
	//+ new: 2016
	for (int i=0; i<xNumber; i++) xx[i]=0;
	((functionND *)F.params)->beforeIter=true;	    
	GSL_FN_EVAL(&F,  (double) (mm+1));
	((functionND *)F.params)->beforeIter=false;
	//- new: 2016
	
	//+++ calculate f vector
	for (int rr=0; rr<Rows[mm];rr++) for(int cc=0;cc<Columns[mm];cc++) 
	{
	    currentMask=gsl_matrix_get(mask, rr, cc+colStart);
	    if (currentMask>0)
	    {
		currentDataPoint	=gsl_matrix_get(  I, rr, cc+colStart);
		currentWeight	=gsl_matrix_get(dI, rr, cc+colStart);
		
		xx[0]=(double)cc;
		xx[1]=(double)rr;
		rowStart=0;
		for (int i=2; i<xNumber; i++) 
		{
		    xx[i]=gsl_matrix_get( xMatrix, rowStart+rr, cc+colStart);
		    rowStart+=Rows[mm];
		}	
		
		Ii = GSL_FN_EVAL(&F,(double)(mm+1));
		
		gsl_matrix_set(Iresidues, rr, cc+colStart,(Ii - currentDataPoint)/currentWeight);
		gsl_matrix_set(Isim, rr, cc+colStart,Ii);
		
		sumChi2+=(Ii - currentDataPoint)*(Ii - currentDataPoint)/currentWeight/currentWeight;
		sumChi2Norm+=1/currentWeight/currentWeight;
		
		ssl+=(Imean - currentDataPoint)*(Imean - currentDataPoint)/currentWeight/currentWeight;
	    }
	}
	
	//+ new: 2016
	for (int i=0; i<xNumber; i++) xx[i]=0;
	((functionND *)F.params)->afterIter=true;	    
	GSL_FN_EVAL(&F,  (double) (mm+1));
	((functionND *)F.params)->afterIter=false;
	//- new: 2016
	
	colStart+=Columns[mm];
    }
    
    
    
    if (ssl>0) R2=1-sumChi2/ssl;
    
    double chi2=sumChi2/ (N-np)/sumChi2Norm*N;
    
    QString ss=textLabelChi->text();
    
    if (ss.contains("...")) ss="...";
    else ss="[ Chi2 change :: "+QString::number(chi2-ss.toDouble(),'e',5)+" ]";
    QToolTip::add( textLabelChi, ss );
    QWhatsThis::add( textLabelChi, ss );
    //+++ chi2
    textLabelChi->setText(QString::number(chi2,'e',12));
    
    ss=textLabelR2->text();
    
    if (ss.contains("...")) ss="...";
    else ss="[ R2 change :: "+QString::number(R2-ss.toDouble(),'e',5)+"] ";
    QToolTip::add(  textLabelR2, ss );
    QWhatsThis::add(textLabelR2, ss );
    //+++R2
    textLabelR2->setText(QString::number(R2,'e',12));
    
    
    
    if (comboBoxOutput->currentItem()==0) makeMatrixUni( Isim, "fitMatrix-Simulated", "MatrixFit :: current simulated matrix ", colsAll, rowsAll);       
    if (comboBoxOutput->currentItem()==1) makeMatrixUni( I, "fitMatrix-Data", "MatrixFit :: current data matrix ", colsAll, rowsAll);  
    if (comboBoxOutput->currentItem()==3) makeMatrixUni( dI, "fitMatrix-Data-Weight", "MatrixFit :: current weighting matrix ", colsAll, rowsAll);  
    if (comboBoxOutput->currentItem()==2) makeMatrixUni( mask, "fitMatrix-Mask", "MatrixFit :: current mask matrix ", colsAll, rowsAll);  
    if (comboBoxOutput->currentItem()==4 && xNumber>2) makeMatrixUni( xMatrix, "fitMatrix-xMatrix", "MatrixFit :: current xmatrix matrix ", colsAll, (xNumber-2)*rowsAll);    
    
    if (checkBoxResidues->isChecked())  makeMatrixUni( Iresidues, "fitMatrix-Residues", "MatrixFit :: current resudues matrix ", colsAll, rowsAll);  
    if (checkBoxResiduesSlices->isChecked())  makeTableSlices( Iresidues, mask,  "fitMatrix-ResiduesSlices", colsAll, rowsAll,Columns, Rows);  
    
    
    gsl_matrix_free(Isim);
    gsl_matrix_free(Iresidues);
    gsl_matrix_free(I);
    gsl_matrix_free(dI); 
    gsl_matrix_free(mask); 
    if (xNumber>2) gsl_matrix_free(xMatrix); 
    
    return true;
}


bool fitMatrix10::beforeFit() 
{        
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value();	//Number of Parameters per Curve
    int xNumber=spinBoxXnumber->value();
    int digits=spinBoxSignDigits->value()-1;
    
    //+++
    if (p==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Select Function"));
	return false;
    }
    
    
    //+++Read data sets to Qtotal && Itotal && Sigmatotal && dItotal && usePoint    
    
    size_t 	*Rows=new size_t[1];		// Vector of  Rows
    size_t 	*Columns=new size_t[1];		// Vector of  Columns
    
    int Ntotal;
    int rowsAll=0;
    int colsAll=0;
    
    //+++ 
    bool beforeFit=true;
    bool afterFit=false;
    bool beforeIter=false;
    bool afterIter=false;
    //+++
    int prec=spinBoxSignDigits->value();
    //+++ ,tableName,tableColNames,tableColDestinations,mTable
    std::string tableName="no-matrix";
    std::string *tableColNames; 
    int *tableColDestinations; 
    gsl_matrix * mTable;
    
    for (int mm=0;mm<M;mm++)
    {
	rowsAll=tableCurves->text(2,2*mm+1).toInt();
	colsAll=tableCurves->text(3,2*mm+1).toInt();
	
	//+++
	if (rowsAll<1 || colsAll<1 )
	{
	    QMessageBox::warning(this,tr("QtiKWS"),
				 tr("No DATA"));
	    return false;
	}
	
	Rows[0]=rowsAll;
	Columns[0]=colsAll;
	
	gsl_matrix *I=gsl_matrix_calloc(rowsAll,colsAll); 
	gsl_matrix *dI=gsl_matrix_calloc(rowsAll,colsAll);
	gsl_matrix *mask=gsl_matrix_calloc(rowsAll,colsAll);
	gsl_matrix *xMatrix;
	if (xNumber>2) xMatrix=gsl_matrix_calloc((xNumber-2)*rowsAll,colsAll);
	
	gsl_matrix *Isim=gsl_matrix_calloc(rowsAll,colsAll); 
	gsl_matrix *Iresidues=gsl_matrix_calloc(rowsAll,colsAll); 
	
	gsl_matrix_set_all(dI,1.0);
	
	Ntotal=0;
	
	if ( !readDataToFitSingle(mm, Rows, Columns, Ntotal, I, dI, mask,xMatrix) )
	{
	    QMessageBox::warning(this,tr("QtiKws"),
				 tr("Fit stopped :: problem to read data!"));
	    return false;
	}
	
	
	//+++ init parameters of F
	double *xx=new double[xNumber];
	
	for (int i=0; i<xNumber; i++) 
	{
	    xx[i]=0.0;
	}
	
	for (int pp=0;pp<p;pp++) gsl_vector_set(F_para,pp,tablePara->text(pp, 3*mm+2).toDouble());
	
	
	
	functionND paraND={xx, F_para, xNumber, M, Rows, Columns, I, dI, mask, xMatrix, beforeFit, afterFit, beforeIter, afterIter,prec,tableName,tableColNames,tableColDestinations,mTable};
	
	F.params=&paraND;
	
	
	GSL_FN_EVAL(&F,(double)(mm+1));
	
	for (int pp=0;pp<p;pp++) tablePara->setText(pp, 3*mm+2,QString::number(gsl_vector_get(F_para,pp),'G',digits+1));
	
	
	gsl_matrix_free(Isim);
	gsl_matrix_free(Iresidues);
	gsl_matrix_free(I);
	gsl_matrix_free(dI); 
	gsl_matrix_free(mask); 
	if (xNumber>2) gsl_matrix_free(xMatrix); 
    }  
    
    return true;
}


bool fitMatrix10::afterFit()
{
    int M=spinBoxNumberCurvesToFit->value();
    int p=spinBoxPara->value();	//Number of Parameters per Curve
    int xNumber=spinBoxXnumber->value();
    int digits=spinBoxSignDigits->value()-1;
    
    //+++
    if (p==0)
    {
	QMessageBox::warning(this,tr("QtiKWS"),
			     tr("Select Function"));
	return false;
    }
    
    
    //+++Read data sets to Qtotal && Itotal && Sigmatotal && dItotal && usePoint    
    
    size_t 	*Rows=new size_t[1];		// Vector of  Rows
    size_t 	*Columns=new size_t[1];		// Vector of  Columns
    
    int Ntotal;
    int rowsAll=0;
    int colsAll=0;
    
    //+++ 
    bool beforeFit=false;
    bool afterFit=true;
    bool beforeIter=false;
    bool afterIter=false;
    //+++
    int prec=spinBoxSignDigits->value();
    //+++ ,tableName,tableColNames,tableColDestinations,mTable
    std::string tableName="no-matrix";
    std::string *tableColNames=0; 
    int *tableColDestinations=0; 
    gsl_matrix * mTable=0;
    
    for (int mm=0;mm<M;mm++)
    {
	rowsAll=tableCurves->text(2,2*mm+1).toInt();
	colsAll=tableCurves->text(3,2*mm+1).toInt();
	
	//+++
	if (rowsAll<1 || colsAll<1 )
	{
	    QMessageBox::warning(this,tr("QtiKWS"),
				 tr("No DATA"));
	    return false;
	}
	
	Rows[0]=rowsAll;
	Columns[0]=colsAll;
	
	gsl_matrix *I=gsl_matrix_calloc(rowsAll,colsAll); 
	gsl_matrix *dI=gsl_matrix_calloc(rowsAll,colsAll);
	gsl_matrix *mask=gsl_matrix_calloc(rowsAll,colsAll);
	gsl_matrix *xMatrix;
	if (xNumber>2) xMatrix=gsl_matrix_calloc((xNumber-2)*rowsAll,colsAll);
	
	gsl_matrix *Isim=gsl_matrix_calloc(rowsAll,colsAll); 
	gsl_matrix *Iresidues=gsl_matrix_calloc(rowsAll,colsAll); 
	
	gsl_matrix_set_all(dI,1.0);
	
	Ntotal=0;
	
	if ( !readDataToFitSingle(mm, Rows, Columns, Ntotal, I, dI, mask,xMatrix) )
	{
	    QMessageBox::warning(this,tr("QtiKws"),
				 tr("Fit stopped :: problem to read data!"));
	    return false;
	}
	
	
	//+++ init parameters of F
	double *xx=new double[xNumber];
	
	for (int i=0; i<xNumber; i++) 
	{
	    xx[i]=0.0;
	}
	
	for (int pp=0;pp<p;pp++) gsl_vector_set(F_para,pp,tablePara->text(pp, 3*mm+2).toDouble());
	functionND paraND={xx, F_para, xNumber, M, Rows, Columns, I, dI, mask, xMatrix, beforeFit, afterFit, beforeIter, afterIter,prec,tableName,tableColNames,tableColDestinations,mTable};
	F.params=&paraND;
	
	GSL_FN_EVAL(&F, (double)(mm+1));
	
	for (int pp=0;pp<p;pp++) tablePara->setText(pp, 3*mm+2,QString::number(gsl_vector_get(F_para,pp),'G',digits+1));
	
	//+++ 2016:: table after fit
	makeTableFromMatrix (paraND.tableName, paraND.tableColNames, paraND.tableColDestinations, paraND.mTable);
	
	if (paraND.tableColNames!=0) delete[] paraND.tableColNames; 
	if (paraND.tableColDestinations!=0) delete[] paraND.tableColDestinations; 
	if (paraND.mTable!=0) gsl_matrix_free(paraND.mTable);
	
	gsl_matrix_free(Isim);
	gsl_matrix_free(Iresidues);
	gsl_matrix_free(I);
	gsl_matrix_free(dI); 
	gsl_matrix_free(mask); 
	if (xNumber>2) gsl_matrix_free(xMatrix); 
    }  
     
    return true;
}


void fitMatrix10::changeFunctionLocal(const QString& newFunction)
{
    //+++
    QString oldFunction=textLabelFfunc->text();
    //+++
    if(oldFunction==newFunction) return;
    //+++
    openDLL( newFunction);
    //+++
    initLimits();
    //+++
    initFitPage();
    //+++
    for (int i=0;i<spinBoxPara->value();i++) tableParaSimulate->setText(i,0,tablePara->text(i,2));    
}

// +++ v10
void fitMatrix10::colList( QString matrixName, int col)
{
    if (matrixName=="") return;
    
    QStringList list;
    int nRows, nCols;
    
    
    if (findAllMatrixesLikeExample(matrixName, list, nRows, nCols))
    {		
	QString oldValue;
	
	QComboTableItem *mask = (QComboTableItem*)tableCurves->item (1,col);
	QComboTableItem *weight = (QComboTableItem*)tableCurves->item (4,col);
	
	oldValue=mask->currentText();
	mask->setStringList(list);
	if (oldValue!="" && list.contains(oldValue)) mask->setCurrentItem(oldValue);
	
	oldValue=weight->currentText();
	weight->setStringList(list);
	if (oldValue!="" && list.contains(oldValue)) weight->setCurrentItem(oldValue);
	
	tableCurves->setText(2,col,QString::number(nRows));
	tableCurves->setText(3,col,QString::number(nCols));
	
	int xNumber=spinBoxXnumber->value();
	for (int i=2;i<xNumber;i++)
	{
	    QComboTableItem *xMatrix = (QComboTableItem*)tableCurves->item (5+i-2,col);
	    oldValue=xMatrix->currentText();
	    xMatrix->setStringList(list);
	    if (oldValue!="" && list.contains(oldValue)) xMatrix->setCurrentItem(oldValue);
	    if(col==1)
	    {
		QComboTableItem *xMatrixSim = (QComboTableItem*)tableSimX->item (i+1,col-1);
		xMatrixSim->setStringList(list);
		if (oldValue!="" && list.contains(oldValue)) xMatrixSim->setCurrentItem(oldValue);
	    }
	    
	}
	
    }
}


bool fitMatrix10::findGraphInActivePlot( myWidget* w, Graph * & g, int grNumber, QString &label)
{
    if (grNumber<0) return false;
    if (!w || !w->isA("MultiLayer"))  return false;
    
    MultiLayer* plot = (MultiLayer*)w;
    if (plot->isEmpty()) return false;
    
    label=plot->windowLabel();
    QWidgetList *graphsList = plot->graphPtrs();
    if (grNumber>=graphsList->count()) return false;
    
    g = ( Graph* ) graphsList->at ( grNumber );
    return true; 
}

bool fitMatrix10::plotTable(Graph *g,Table *table, QString tableName, int colX, int colY, int colDX, int colDY)
{
    int cols=table->numCols();
    
    if (colX<0 || colX>=cols) return false;
    if (colY<0 || colY>=cols) return false;    
    
    bool checkBoxYerror=false;
    if (colDY>0 && colDY<cols) checkBoxYerror=true; 
    bool checkBoxXerror=false;
    if (colDX>0 && colDX<cols) checkBoxXerror=true; 
    //
    int style = Graph::Scatter;
    QStringList columnsListOnPlot=g->curvesList();
    //		
    g->resizeMy(g->curves());
    
    if (!checkBoxYerror && columnsListOnPlot.contains(table->colName(colDY))	)
    {
	g->removeCurve(table->colName(colDY));	  
    }
    else if (checkBoxYerror && !columnsListOnPlot.contains(table->colName(colDY)))
    {
	g->addErrorBars(table,table->colName(colX),table->colName(colY),table,table->colName(colDY), 1, 1, 1, QColor(black), TRUE, TRUE,TRUE);
    }
    
    if (!columnsListOnPlot.contains(table->colName(colY)))
    {
	g->insertCurve(table,table->colName(colY),style);	    
    }
    curveLayout cl = Graph::initCurveLayout();
    
    int color;		
    int curve = g->curves()-1 ;		
    long key = g->curveKey(curve);  
    if (key == (long) curve ) key++;
    g->guessUniqueCurveLayout(color, cl.sType);
    int shape=key%9;
    if (shape == 0) shape = 1; //avoid white invisible symbol   tableCurves
    
    cl.lCol=color;
    cl.symCol=color;
    cl.fillCol=color;
    cl.aCol=color;
    cl.lWidth = app(this)->defaultCurveLineWidth;
    cl.sSize = app(this)->defaultSymbolSize;
    
    //cl.sType=shape;
    
    g->updateCurveLayout(curve, &cl);
    
    if (cols>3 && !checkBoxXerror && columnsListOnPlot.contains(table->colName(colDX)))
    {
	g->removeCurve(table->colName(colDX));	
    }
    else if (cols>3 &&  checkBoxXerror && !columnsListOnPlot.contains(table->colName(colDX)))
    {
	g->addErrorBars(table,table->colName(colX), table->colName(colY),table, table->colName(colDX), 0, 2, 10, color, TRUE, TRUE,TRUE);
	curve = g->curves() - 1; 
	g->updateErrorBars(curve,TRUE,1,1, color, TRUE,TRUE,FALSE);
    }
    
    g->replot();
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++FUNCTIONS::create Tableof residues slices      ++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
void fitMatrix10::makeTableSlices( gsl_matrix * gmatrix, gsl_matrix * mask, QString name, int xDim, int yDim, size_t 	*Columns, size_t  *Rows)
{
    
    int i,j;
    int M=spinBoxNumberCurvesToFit->value();
    
    //+++
    QWidgetList* windows=app(this)->windowsList();
    //+++
    QString ss;
    //+++
    bool existYN=false;
    
    Table* t;
    //+++
    
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
	ss=windows->at(mm)->name();
	
	if (ss==name && windows->at(mm)->isA("Table"))
	{
	    t=(Table *)windows->at(mm);
	    existYN=true;
	    t->setNumRows(0);
	    t->setNumCols(4*M);
	    
	    for(int m=0; m<M; m++)
	    {
		QString s="-";
		if (m<9) s=s+"0";
		s=s+QString::number(m+1);
		
		if (m==0 && M==1) s="";
		
		t->setColName(0+4*m,"hor-X"+s); t->setColPlotDesignation(0+4*m,Table::X);
		t->setColName(1+4*m,"hor-I"+s); t->setColPlotDesignation(1+4*m,Table::Y);
		t->setColName(2+4*m,"ver-X"+s); t->setColPlotDesignation(2+4*m,Table::X);
		t->setColName(3+4*m,"ver-I"+s); t->setColPlotDesignation(3+4*m,Table::Y);	    
	    }	
	}
    }
    //+++make Unique Name
    
    if (!existYN)
    {
	t=app(this)->newHiddenTable(name,"Matrix Fit:: Residues Slices", 0 ,4*M);
	
	for(int m=0; m<M; m++)
	{
	    QString s="-";
	    if (m<9) s=s+"0";
	    s=s+QString::number(m+1);
	    
	    if (m==0 && M==1) s="";
	    
	    t->setColName(0+4*m,"hor-X"+s); t->setColPlotDesignation(0+4*m,Table::X);
	    t->setColName(1+4*m,"hor-I"+s); t->setColPlotDesignation(1+4*m,Table::Y);
	    t->setColName(2+4*m,"ver-X"+s); t->setColPlotDesignation(2+4*m,Table::X);
	    t->setColName(3+4*m,"ver-I"+s); t->setColPlotDesignation(3+4*m,Table::Y);	    
	}
    }
    
    int colStart=0;
    int currentRow;
    int N;
    double Imean;
    
    //+++
    for (int mm = 0; mm < M; mm++)
    {    
	//+++ Vertical Slices
	currentRow=0;
	for (int rr=0; rr<Rows[mm];rr++) 
	{
	    N=0;
	    Imean=0;
	    for(int cc=0;cc<Columns[mm];cc++) 
	    {
		if (gsl_matrix_get(mask, rr, cc+colStart)>0)
		{
		    N++;
		    Imean+= gsl_matrix_get( gmatrix, rr, cc+colStart);
		}
	    }
	    
	    if (N>0)
	    {
		if ( t->numRows()<(currentRow+1) ) t->setNumRows(currentRow+1);
		t->setText(currentRow, 2+4*mm, QString::number(rr+1));
		t->setText(currentRow, 3+4*mm, QString::number(Imean/N));
		
		currentRow++;
	    }
	}
	
	//+++ Hor. Slices
	currentRow=0;
	
	for(int cc=0;cc<Columns[mm];cc++) 
	{
	    N=0;
	    Imean=0;
	    for (int rr=0; rr<Rows[mm];rr++) 
	    {
		
		if (gsl_matrix_get(mask, rr, cc+colStart)>0)
		{
		    N++;
		    Imean+= gsl_matrix_get( gmatrix, rr, cc+colStart);
		}
	    }
	    if (N>0)
	    {
		if (t->numRows()<(currentRow+1)) t->setNumRows(currentRow+1);
		t->setText(currentRow, 0+4*mm, QString::number(cc+1));
		t->setText(currentRow, 1+4*mm, QString::number(Imean/N));
		
		currentRow++;
	    }
	    
	    
	}
	colStart+=Columns[mm];
    }
    
    t->notifyChanges();
    //+++
    t->setWindowLabel("MatrixFit :: current desidues slices table");
    app(this)->setListViewLabel(t->name(), "MatrixFit :: current desidues slices table");
    app(this)->updateWindowLists(t);
    
    for (int tt=0; tt<t->numCols(); tt++)
    {
	t->table()->adjustColumn (tt);
	t->table()->setColumnWidth(tt, t->table()->columnWidth(tt)+10); 
    }
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++FUNCTIONS::additional output table      ++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
bool fitMatrix10::makeTableFromMatrix (std::string name, std::string *tableColNames, int *tableColDestinations, gsl_matrix * m)
{    
    QString tableName=name.c_str();
    
    if (tableName=="no-matrix") return false;
    
    //+++ checking datat +++++
    tableName=tableName.remove(" ").remove("_").remove(",").remove("."); if (tableName=="") return false;
    //    if (tableColNames->size()!=tableColDestinations->size() || tableColNames->size()<1) return false;
    
    int mRows=m->size1; if (mRows<1) return false;
    int mCols=m->size2; if (mCols<1) return false;
    //    if (mCols!=tableColNames.count()) return false;
    
    //+++
    QWidgetList* windows=app(this)->windowsList();
    //+++
    bool existYN=false;
    //+++
    QString ss;
    //+++
    Table* t;
    
    //+++ find existing table
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
	ss=windows->at(mm)->name();
	
	if (ss==tableName && windows->at(mm)->isA("Table"))
	{
	    t=(Table *)windows->at(mm);
	    existYN=true;
	    t->setNumRows(0);
	    t->setNumRows(mRows);
	    t->setNumCols(mCols);
	}
    }
    
    //+++create new table
    if (!existYN) t=app(this)->newHiddenTable(tableName,"Matrix Fit :: Matrix-to-Table", mRows ,mCols);
    
    QString s;
    //+++ col names & destination
    for(int cc=0; cc<mCols; cc++)
    {	
	s=tableColNames[cc].c_str(); s=s.remove(" ").remove("_");
	t->setColName(cc,s);
	t->setColPlotDesignation(cc,Table::PlotDesignation(tableColDestinations[cc]));
    }
    t->setHeaderColType();
    
    int digits=spinBoxSignDigits->value()-1;
    
    //+++ transfet data to table
    for (int rr=0; rr<mRows;rr++) for(int cc=0;cc<mCols;cc++) t->setText(rr,cc,QString::number(gsl_matrix_get(m,rr,cc),'E',digits)); 
    
    //+++ table actions
    t->notifyChanges();
    
    //+++
    t->setWindowLabel("Matrix Fit :: Matrix-to-Table");
    app(this)->setListViewLabel(t->name(), "Matrix Fit :: Matrix-to-Table");
    app(this)->updateWindowLists(t);
    
    for (int tt=0; tt<t->numCols(); tt++)
    {
	t->table()->adjustColumn (tt);
	t->table()->setColumnWidth(tt, t->table()->columnWidth(tt)+10); 
    }  
    
}


//***************************************************
//  Simulate >= 2016
//***************************************************
void fitMatrix10::simulate()
{
    int activePixel, np;
    double chi2, TSS;
    
    int m=comboBoxDatasetSim->currentItem()+1;    
    generateSimulatedMatrix(0,m, "simulatedMatrix", activePixel, np, chi2, TSS);    
}


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++ simulate matrix :: individually
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// source :: (0) simulate interf :: (1) fit interf :: (2) set-to-set interf
// m :: number of matrixes   [1...M]

bool fitMatrix10::generateSimulatedMatrix(int source, int m, QString simulatedMatrixName, int &activePixel, int &np, double &chi2, double &TSS)
{
    
    //++++++++++++++++++++++++++++++++++++++++
    //+ move parameters of fit [m] to simulation interface
    //++++++++++++++++++++++++++++++++++++++++
    
    if (source>0) datasetChangedSim(m-1);
    
    //++++++++++++++++++++++++++++++++++++++++
    //+ matrix dimension:
    //++++++++++++++++++++++++++++++++++++++++
    
    int nRows=simRows->value();
    int nCols=simRows->value();
    
    //++++++++++++++++++++++++++++++++++++++++
    //+ generate matrixes:: 
    //++++++++++++++++++++++++++++++++++++++++    
    
    QString IdataName = tableSimX->text(0,0); 
    QString maskName = tableSimX->text(1,0);    
    QString WeightName = tableSimX->text(2,0);     
    QString IsimName  = simulatedMatrixName;
    QString *xMatrixNames;
    int xNumber=spinBoxXnumber->value()-2;
    if (xNumber>0)
    {
	xMatrixNames=new QString[xNumber];
	for(int i=0; i<xNumber;i++)  xMatrixNames[i]=tableSimX->text(3+i,0);
    }
    
    //++++++++++++++++++++++++++++++++++++++++
    //+ allocate matrixes:: 
    //++++++++++++++++++++++++++++++++++++++++
    
    gsl_matrix *Idata=gsl_matrix_calloc(nRows,nCols); 
    gsl_matrix *mask=gsl_matrix_alloc(nRows,nCols); gsl_matrix_set_all(mask,1.0);    
    gsl_matrix *WeightData=gsl_matrix_calloc(nRows,nCols); 
    gsl_matrix *Weight=gsl_matrix_calloc(nRows,nCols);   
    gsl_matrix *Isim=gsl_matrix_calloc(nRows,nCols);
    gsl_matrix *xMatrix; if (xNumber>0) xMatrix=gsl_matrix_calloc((xNumber-2)*nRows,nCols);
    gsl_matrix *Iresidues=gsl_matrix_alloc(nRows,nCols); 
    
    //++++++++++++++++++++++++++++++++++++++++
    //+ generate matrixes:: 
    //++++++++++++++++++++++++++++++++++++++++
    
    if (!matrix2gslmatrix(IdataName, Idata, nRows, nCols)) return false;
    //+++
    int currentWeight=comboBoxWeightingMethod->currentItem();
    if (!matrix2gslmatrix(WeightName, WeightData, nRows, nCols)) return false;
    if (checkBoxMaskSim->isChecked()) { if (!matrix2gslmatrix(maskName, mask, nRows, nCols)) return false;};    
    if (!matrix2gslmatrixXmatrix(xMatrixNames, xNumber, xMatrix, nRows, nCols)) return false;
    
    //++++++++++++++++++++++++++++++++++++++++
    //+++ weight matrix calculation
    //++++++++++++++++++++++++++++++++++++++++
    calculateWeightMatrix(Idata,WeightData,mask,Weight, nRows,nCols);
    
    //++++++++++++++++++++++++++++++++++++++++
    //+++ Function
    //++++++++++++++++++++++++++++++++++++++++
    
    //+++ init parameters: xx
    double *xx=new double[xNumber+2];  
    for (int i=0; i<xNumber+2; i++) xx[i]=0.0;
    //+++ Function Parameters Allocation
    int P=spinBoxPara->value();
    for(int pp=0;pp<P; pp++) gsl_vector_set(F_para, pp, tableParaSimulate->text(pp,0).toDouble());    
    //+++
    int M=1;
    //+++
    size_t 	*Rows=new size_t[M]; Rows[0]=nRows;
    size_t 	*Columns=new size_t[M];Columns[0]=nCols;
    //+++ 
    bool beforeFit=false;
    bool afterFit=false;
    bool beforeIter=false;
    bool afterIter=false;
    //+++
    int prec=spinBoxSignDigits->value();
    //+++
    std::string tableName="no-matrix";
    std::string *tableColNames; 
    int *tableColDestinations; 
    gsl_matrix * mTable;
    
    functionND paraND={xx, F_para, xNumber, M, Rows, Columns, Idata, Weight, mask, xMatrix, beforeFit, afterFit, beforeIter, afterIter,prec,tableName,tableColNames,tableColDestinations,mTable};
    
    gsl_function FF;
    FF.function = F.function;
    FF.params= &paraND;    
    
    //makeSingleFunctionND(FF,  Idata, Weight, mask, xMatrix, nRows, nCols );
    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++ Progress dialog
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++
    QProgressDialog *progress;
    if (source==0)
    {
	progress = new QProgressDialog("Function | Simulator | Started", "Stop", nRows*nCols, this, 
				       "Function Simulator", TRUE );
	progress->setMinimumDuration(4000);
    }
    
    //+++ time of calculation ... +++++++++
    QTime dt = QTime::currentTime ();  //++
    
    //++++++++++++++++++++++++++++++++++++++++
    //+++ read data :: in case table defined case
    //++++++++++++++++++++++++++++++++++++++++
    //+ calling beforeIter
    ((functionND *)FF.params)->beforeIter=true;	    
    GSL_FN_EVAL(&FF,  (double) (m));
    ((functionND *)FF.params)->beforeIter=false;
    
 
    int currentPixel=0;
    //+++ calculate Isim
    for (int rr=0; rr<nRows;rr++) 
    {
	for(int cc=0;cc<nCols;cc++) 
	{
	    ((functionND *)FF.params)->Q[0]=cc;
	    ((functionND *)FF.params)->Q[1]=rr;
	    if (gsl_matrix_get(mask, rr, cc)>0) gsl_matrix_set( Isim, rr, cc,GSL_FN_EVAL(&FF,(double)(m)));
	    else gsl_matrix_set( Isim, rr, cc, 0.0);
	    
	}	
	if (source==0)
	{
	    //+++ Start +++  1
	    progress->setProgress(currentPixel);
	    progress->setLabelText("Function | Simulator | Started: # "+QString::number(currentPixel+1)+" of "+QString::number(nRows*nCols));
	    
	    if ( progress->wasCanceled() ) 
	    {
		progress->close();
		break;
	    }
	    currentPixel+=nRows;
	}
    }
    //+ calling afterIter
    ((functionND *)FF.params)->Q[0]=0;
    ((functionND *)FF.params)->Q[1]=0;
    
    ((functionND *)FF.params)->afterIter=true;	    
    GSL_FN_EVAL(&FF,  (double) (m));
    ((functionND *)FF.params)->afterIter=false;
    
    if (source==0) 
    {
	progress->close();
    }
    
    checkConstrains(source, m);
    
    //+++ time of calculation ... ++++++++++++++++++++++++++++++++++++++++++++
    textLabelTimeSim->setText(QString::number(dt.msecsTo(QTime::currentTime()), 'e',2)+"ms");
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    QString localName=simulatedMatrixName;
    
    //++++++++++++++++++++++++++++++++++++++++
    // makeMatrix::  
    //++++++++++++++++++++++++++++++++++++++++
    
    if ( checkBoxSimData->isChecked() && comboBoxOutput->currentItem()==0) 
    {
	localName=simulatedMatrixName+"-simulated";
	if (source==0) 
	{
	    localName+="-"+comboBoxFunction->currentText();
	    
	    if (checkBoxSimIndexing->isChecked()) localName=app(this)->generateUniqueName(localName+"-");
	}
	makeMatrixUni( Isim, localName, "MatrixFit :: current simulated matrix ", nCols, nRows);       
    }
    //+++
    if (checkBoxSimData->isChecked() && comboBoxOutput->currentItem()==1)
    {
	localName=simulatedMatrixName+"-data";
	if (source==0) 
	{
	    localName+="-"+comboBoxFunction->currentText();
	    
	    if (checkBoxSimIndexing->isChecked()) localName=app(this)->generateUniqueName(localName+"-");
	}
	makeMatrixUni( Idata, localName, "MatrixFit :: current data matrix ", nCols, nRows);       
    }	
    //+++
    if (checkBoxSimData->isChecked() && comboBoxOutput->currentItem()==3) 
    {	
	localName=simulatedMatrixName+"-weight";
	if (source==0) 
	{
	    localName+="-"+comboBoxFunction->currentText();
	    
	    if (checkBoxSimIndexing->isChecked()) localName=app(this)->generateUniqueName(localName+"-");
	}
	makeMatrixUni( Weight, localName, "MatrixFit :: current weighting matrix ", nCols, nRows);       
    }
    //+++
    if (checkBoxSimData->isChecked() && comboBoxOutput->currentItem()==2) 
    {
	localName=simulatedMatrixName+"-mask";
	if (source==0) 
	{
	    localName+="-"+comboBoxFunction->currentText();
	    
	    if (checkBoxSimIndexing->isChecked()) localName=app(this)->generateUniqueName(localName+"-");
	}
	makeMatrixUni( mask, localName, "MatrixFit :: current masking matrix ", nCols, nRows);       
    }
    //+++
    if (checkBoxSimData->isChecked() && comboBoxOutput->currentItem()==4 && xNumber>0)  
    {
	localName=simulatedMatrixName+"-xmatrix";
	if (source==0) 
	{
	    localName+="-"+comboBoxFunction->currentText();
	    
	    if (checkBoxSimIndexing->isChecked()) localName=app(this)->generateUniqueName(localName+"-");
	}
	makeMatrixUni( xMatrix, localName, "MatrixFit :: current xmatrix matrix ", nCols, nRows);       
    }
    //+++
    if (checkBoxSimData->isChecked() && comboBoxOutput->currentItem()==5)  
    {
	localName=simulatedMatrixName+"-2-in-1";
	if (source==0) 
	{
	    localName+="-"+comboBoxFunction->currentText();
	    
	    if (checkBoxSimIndexing->isChecked()) localName=app(this)->generateUniqueName(localName+"-");
	}
	makeMatrix2in1(Idata, Isim, localName, "MatrixFit :: 2-in-1 :: data and simulation", nCols, nRows);       
    }
    //+++
    gsl_matrix_memcpy(Iresidues, Idata);
    gsl_matrix_sub(Iresidues, Isim);
   
    double wweight;
    for (int i=0; i<nRows; i++) for (int j=0; j<nCols; j++)
    {
	wweight=gsl_matrix_get(Weight,i,j);
	if (wweight>0) gsl_matrix_set(Iresidues, i, j, gsl_matrix_get(Iresidues, i, j)/wweight);
    }
    //+++
    if (checkBoxResidues->isChecked())
    {
	localName=simulatedMatrixName+"-residues";
	if (source==0) 
	{
	    localName+="-"+comboBoxFunction->currentText();
	    
	    if (checkBoxSimIndexing->isChecked()) localName=app(this)->generateUniqueName(localName+"-");
	}
	makeMatrixUni(Iresidues, localName, "MatrixFit :: current residues matrix ", nCols, nRows);       
    }
    //+++
    if (checkBoxResiduesSlices->isChecked())  
    {
	localName=simulatedMatrixName+"-residuesslices";
	if (source==0) 
	{
	    localName+="-"+comboBoxFunction->currentText();
	    
	    if (checkBoxSimIndexing->isChecked()) localName=app(this)->generateUniqueName(localName+"-");
	}
	makeTableSlices( Iresidues, mask,  localName, nCols, nRows,Columns, Rows);  
  
    }
    
    fitStatMatrixM(m-1, Idata, Iresidues, mask, nCols, nRows, activePixel, np, chi2, TSS );		 
    
    if (source==0)
    {
//	convertWeightMatrix(Weight, nCols, nRows);
    
	//++++++++++++++++++++++++++++++++++++++++
	//+++ clear memory
	//++++++++++++++++++++++++++++++++++++++++
	
	double R2=0.0;
	if (TSS>0.0) R2=1-chi2/TSS;
	
	textLabelChi2Sim->setText(QString::number(chi2,'e',10));
	textLabelChi2dofSim->setText(QString::number(chi2/(activePixel-np),'e',10));
	textLabelDofSim->setText(QString::number(activePixel));
	textLabelnpSIM->setText(QString::number(np));
	textLabelR2sim->setText(QString::number(R2,'e',10));
	
	
	
	
	int Ntotal=activePixel;
	int p=P;
	// np=np;
	xNumber+=2; // different difinition
	// M=1;
	gsl_vector       *params= gsl_vector_alloc(p); gsl_vector_memcpy(params, F_para);    
	gsl_vector_int *paramsControl= gsl_vector_int_alloc(p);
	
	//+++ Adjustible vector Limits...
	gsl_vector *limitLeft=gsl_vector_calloc(np);
	gsl_vector *limitRight=gsl_vector_calloc(np);  
	gsl_vector *xxx=gsl_vector_alloc(np);  
	QStringList activeParaNames;
	int ncount=0;
	for (int pp=0; pp<p;pp++)
	{
	    QCheckTableItem *itA = (QCheckTableItem *)tablePara->item(pp,3*(m-1)+1); // Vary?
	    if (itA->isChecked())
	    {  
		gsl_vector_int_set(paramsControl, pp, 0);
		gsl_vector_set(limitLeft, ncount, tableControl->text(pp, 0).toDouble());
		gsl_vector_set(limitRight, ncount, tableControl->text(pp, 4).toDouble());
		gsl_vector_set(xxx, ncount, tableParaSimulate->text(pp, 0).toDouble());
		activeParaNames<<tableParaSimulate->verticalHeader()->label(pp);
		ncount++;
		
	    }
	    else gsl_vector_int_set(paramsControl, pp, 1);
	}
	// FF
	

	
	simplyFit2D paraSimple={Ntotal, p, np, xNumber, M, params, paramsControl, &FF, limitLeft, limitRight};
	
	
	//+++ Chi
	double chi =sqrt(function_dm2D (xxx, &paraSimple));
    
	//+++ Jacobian J
	gsl_matrix *J = gsl_matrix_alloc(Ntotal, np); 	
	function_dfm2D_long(xxx,&paraSimple,J);
    
	//+++ Covariant
	gsl_matrix *covar = gsl_matrix_alloc (np,np);    
	gsl_multifit_covar (J, 0.0, covar);
	
	    //+++
	if (checkBoxSimStatistics->isChecked() )  
	{
	    localName=simulatedMatrixName+"-statistics";
	    localName+="-"+comboBoxFunction->currentText();	    
	    if (checkBoxSimIndexing->isChecked()) localName=app(this)->generateUniqueName(localName+"-");
	    
	    makeNote(currentStatistics(Ntotal, np, chi, R2, activeParaNames, covar, xxx,m), localName, "MatrixFit :: statistics info ");
	}
  
    
	
	gsl_vector_free(xxx);
	gsl_matrix_free(J);
	
//	std::cout<<"\nchi2test = "<<chi2test;
	
	xNumber-=2;
    }
    
    gsl_matrix_free(Idata);
    gsl_matrix_free(Isim);    
    gsl_matrix_free(Weight);   
    gsl_matrix_free(mask);
    gsl_matrix_free(Iresidues);
    gsl_matrix_free(WeightData);
     if (xNumber>0) gsl_matrix_free(xMatrix);       
   
    
    return true;
}

//++++++++++++++++++++++++++++++++++++++++
//+++ matrix2gslmatrix
//++++++++++++++++++++++++++++++++++++++++
bool fitMatrix10::matrix2gslmatrix(QString mName, gsl_matrix *gslMatrix, int  nRows, int nCols)
{
    Matrix* matrix;
    if (!findFitDataMatrix(mName,matrix, nRows, nCols )) return false;
    
    for (int i=0; i<nRows; i++) for (int j=0; j<nCols; j++)
    {
	gsl_matrix_set(gslMatrix, i, j, matrix->text(i,j).toDouble());
    }
    return true;
}

//++++++++++++++++++++++++++++++++++++++++
//+++ matrix2gslmatrix xMatrix
//++++++++++++++++++++++++++++++++++++++++
bool fitMatrix10::matrix2gslmatrixXmatrix(QString *mName, int xNumber, gsl_matrix *gslMatrix, int  nRows, int nCols )
{
    
    for (int m=0; m<xNumber; m++ )
    {
	Matrix* matrix;
	if (!findFitDataMatrix(mName[m],matrix, nRows, nCols )) return false;
	
	for (int i=0; i<nRows; i++) for (int j=0; j<nCols; j++)
	{
	    gsl_matrix_set(gslMatrix, i+m*nRows, j, matrix->text(i,j).toDouble());
	}
    }
    return true;
}


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++ makeMatrix2in1 +++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
void fitMatrix10::makeMatrix2in1( gsl_matrix * data, gsl_matrix * simulation, QString name, QString label, int xDim, int yDim)
{    
    int i,j;
    //+++
    QWidgetList* windows=app(this)->windowsList();
    //+++
    QString ss;
    //+++
    bool existYN=false;
    Matrix* m;
    //+++
    
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
	ss=windows->at(mm)->name();
	
	if (ss==name && windows->at(mm)->isA("Matrix"))
	{
	    m=(Matrix *)windows->at(mm);
	    existYN=true;
	    m->setMatrixDimensions(yDim,2*xDim);
	    m->setCoordinates(0.5,2*xDim+0.5,0.5,yDim+0.5);	    
	}
    }
    
    //+++make Unique Name
    if (!existYN)
    {
	m=app(this)->newMatrixHidden(name,yDim,2*xDim);
	app(this)->updateRecentProjectsList();
	m->setNumericFormat('E',8);
	m->setCoordinates(0.5,2*xDim+0.5,0.5,yDim+0.5);
    }
    
    
    //+++
    
    for (i=0;i<yDim;i++) for (j=0;j<xDim;j++)
    {
	m->setText(i,j,QString::number(gsl_matrix_get(data,i,j),'E',8));
	m->setText(i,j+xDim,QString::number(gsl_matrix_get(simulation,i,j),'E',8));
    }
    
    //+++
    m->setWindowLabel(label);
    app(this)->setListViewLabel(m->name(), label);
    app(this)->updateWindowLists(m);

    m->setColumnsWidth(140);
    m->notifyChanges();
      
    // rescale active graph with current matrix
    Graph *g;
    if (!findActiveGraph(g)) return;    
    if (g->isPiePlot()) return;
    QwtPlotCurve *c = g->curve(0);
    if (!c)	return;
    if (c->rtti() != QwtPlotItem::Rtti_PlotSpectrogram) return;
    
    if (g->plotItemsList()[0] == m->name())    app(this)->setAutoScale();  
  }

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++ calculateWeightMatrix +++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
void fitMatrix10::calculateWeightMatrix( gsl_matrix *data, gsl_matrix *weightdata, gsl_matrix *mask, gsl_matrix * &weight, int nRows, int nCols)
{
    gsl_matrix_memcpy(weight,mask);
    if (!checkBoxUseWeightSim->isChecked()) return;
    
    //+++
    int currentWeight=comboBoxWeightingMethod->currentItem();
    //+++
    double wa=lineEditWA->text().toDouble(); wa=fabs(wa);
    double wb=lineEditWB->text().toDouble(); wb=fabs(wb); if (wb==0) wb=1.0;
    double wc=lineEditWC->text().toDouble(); wc=fabs(wc);
    //+++
    double w, mmask;
    
    for (int i=0; i<nRows; i++) for (int j=0; j<nCols; j++)
    {
	mmask=gsl_matrix_get(mask, i, j);
	if (mmask<=0) continue;
	
	switch ( currentWeight )    
	{
	case 0: //+++ [ w = 1/dY^2 ]
	    w = fabs(gsl_matrix_get(weightdata, i, j));
	    if (w!=0.0) w=1/w/w; 
	    break;
	case 1: //+++ [ w = 1/Y ]
	    w = fabs(gsl_matrix_get(data, i, j));
	    if (w!=0.0) w=1/w;
	    break;
	case 2: //+++ [ w = dY ]
	    w = fabs( gsl_matrix_get(weightdata, i, j) );
	    break;
	case 3: //+++ [ w = 1/Y^2 ]
	    w = fabs( gsl_matrix_get(data, i, j));
	    if (w!=0.0) w=1/w/w;
	    break;
	case 4: //+++ [ w = 1/Y^a ]
	    w = fabs( gsl_matrix_get(data, i, j) );
	    if (w!=0.0) w=1/pow(w,wa); 
	    break;	    
	case 5:  //+++ [ w = 1/|c^a+b*Y^a| ]
	    w = fabs( gsl_matrix_get(data, i, j) );
	    w=1/ ( pow(wc,wa) + wb*pow( fabs(w),wa) );
	    break;
	}
	if (w!=0) w=1/sqrt(w); else w=1.0;
	gsl_matrix_set(weight, i, j, w);  
    }	
    return;
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++ convertion W-weight to sigmaweight +++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
void fitMatrix10::convertWeightMatrix( gsl_matrix * &weight, int nRows, int nCols)
{
    double wweight;
    for (int i=0; i<nRows; i++) for (int j=0; j<nCols; j++)
    {
	wweight=gsl_matrix_get(weight, i, j);
	if (wweight>0) wweight=1/sqrt(wweight); 
    }
}

QString fitMatrix10::fillSpace(QString s, int length,QString fill)
{
    int initLength=s.length();
    if (initLength>=length) return s;
    QString ss=s;
    for (int i=initLength; i<length; i++) ss+=fill;
    return ss;
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++ fit statistics +++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
void fitMatrix10::fitStatMatrixM(int m, gsl_matrix *data, gsl_matrix *residues, gsl_matrix *mask, int xDim, int yDim, int &activePixel, int &np, double &chi2, double &TSS )
{
    // chi2=  RSS
    // 
    
    //+++  np
    np=0;
    int p=spinBoxPara->value();

    for (int pp=0; pp<p;pp++)
    {
	QCheckTableItem *itA = (QCheckTableItem *)tablePara->item(pp,3*m+1); // Vary?
	if (itA->isChecked())  np++;
    }
    
    //+++ chi2, activepixels
    double mmask, rresidues, ddata;
    //+++
    activePixel=0;
    chi2=0;
    TSS=0;
    
    for (int i=0; i<yDim; i++) for (int j=0; j<xDim; j++)
    {  
    	mmask=gsl_matrix_get(mask, i, j);
	if (mmask<=0) continue;
		
	rresidues=gsl_matrix_get(residues, i, j);
	ddata=gsl_matrix_get(data, i, j);
	
	chi2+=rresidues*rresidues;
	TSS+=ddata*ddata;
	
	activePixel++;
    }
}

QString fitMatrix10::currentStatistics(int N, int P, double chi, double r2, QStringList paraActive, gsl_matrix *covar, gsl_vector *paraAdjust, int m)
{
if (P<1) return "";
if (P!=paraActive.count()) return "";

int prec=spinBoxSignDigits->value();


gsl_matrix * covarCopy = gsl_matrix_alloc (P, P);
gsl_matrix * inverse = gsl_matrix_alloc (P, P);
gsl_matrix_memcpy(covarCopy, covar);

gsl_set_error_handler_off();
inversion (P, covarCopy, inverse);


QString s,ss, sChi, sChi2, sRoot, sDot;
sChi=QChar(967);
sChi2=sChi; sChi2+=QChar(178);
sRoot=QChar(8730);
sDot=QChar(8901);

int sMinLength=spinBoxSignDigits->value()+6;

s="\n"; 

QString F_name=textLabelFfunc->text();
QDateTime dt = QDateTime::currentDateTime ();
s += "[ " + dt.toString(Qt::LocalDate)+ " ]\n";
for(int i=0; i<(5+sMinLength)*(P+1)+20;i++) s+="-";
s+="\n";

s += tr("Using Function") + ":\t " + F_name + "\n";
s += tr("Data Matrix") + ":\t " + tableSimX->text(0,0) + "\n";
s += tr("Mask Matrix") + ":\t " + tableSimX->text(1,0);
if(checkBoxMaskSim->isChecked()) s+="\t\t[used]\n"; else s+="\t\t[not used]\n";
s += tr("Weight Matrix") + ":\t " + tableSimX->text(2,0);
if(checkBoxUseWeightSim->isChecked()) 
{
    s+="\t\t[used]\n";
    s += tr("Weight Method") + ":\t " +comboBoxWeightingMethod->currentText()+"\n";
}
else s+="\t\t[not used]\n";
int xNumber=spinBoxXnumber->value();
if (xNumber>2)
{
    s += tr("X Matrix(s)") + ":\t ";
    for(int xx=2; xx<xNumber; xx++) s+=tableSimX->text(1+xx,0)+" ";
}

s+="\n\n"; 



s+="The Variance-Covariance Matrix cov(i,i):\n";
//------------------------------------------------------------------------
for(int i=0; i<(5+sMinLength)*(P+1)+20;i++) s+="-";
s+="\n";

for(int p=0;p<P;p++)
{
    s+=paraActive[p];
    for(int i=0; i<sMinLength-paraActive[p].length();i++) s+=" ";
    s+="\t\t";
}
s+="  \t \n";

//------------------------------------------------------------------------
for(int i=0; i<(5+sMinLength)*(P+1)+20;i++) s+="-";
s+="\n";

for(int p=0;p<P;p++) 
{
    
    for(int pp=0;pp<P;pp++)
    {    
     
	ss="+";
	if (gsl_matrix_get(covar, pp,p)<0) ss="";
	s+=ss+QString::number(gsl_matrix_get(covar, pp,p),'E',spinBoxSignDigits->value()-1) +"\t";	
    }
    s+="| "+paraActive[p]; 
    s+="\n";  
}
//------------------------------------------------------------------------
for(int i=0; i<(5+sMinLength)*(P+1)+20;i++) s+="-";
s+="\n\n";

s+="Values, Errors and Dependences:\n";
//------------------------------------------------------------------------
for(int i=0; i<(5+sMinLength)*6+30;i++) s+="-";
s+="\n";

s+="Name \t Value \t Error[ "+ sRoot+" "+sChi2+"/(N-p)"+sDot+"cov(i,i)  ]   \t Error[ "+ sRoot+" cov(i,i)  ] \t Dependency [1-1/cov(i,i)/cov'(i,i)]\n";
//------------------------------------------------------------------------
for(int i=0; i<(5+sMinLength)*6+30;i++) s+="-";
s+="\n";


for(int p=0;p<P;p++) 
{
    s+=""+paraActive[p]+"\t"+QString::number(gsl_vector_get(paraAdjust, p),'E',spinBoxSignDigits->value()-1)+"\t";
    s+=QChar(177);
    s+=" "+ QString::number( sqrt(fabs(chi*chi/(N-P)*gsl_matrix_get(covar,p,p))),'E',spinBoxSignDigits->value()-1)+"\t";
    s+=QChar(177);
    s+=" "+ QString::number( sqrt(gsl_matrix_get(covar,p,p)),'E',spinBoxSignDigits->value()-1)+"\t";
    
    double tmp=fabs(gsl_matrix_get(covar, p,p)*gsl_matrix_get(inverse, p,p));
    
    if (tmp>pow(10.0,prec+2)) tmp=1.0;
    else 
    {
	if(tmp<1 ) tmp=0.0; 
	else tmp=1-1/tmp;
    };
    if (tmp<0 || tmp>1) tmp=1.0;
    s+=QString::number(tmp,'E',spinBoxSignDigits->value()-1);
    s+="\n";  
}
//------------------------------------------------------------------------
for(int i=0; i<(5+sMinLength)*6+30;i++) s+="-";
s+="\n";
//s+="chi   = "+ QString::number(chi,'E',20)+"\tchi/sqrt(N-p) \t= "+QString::number(chi/sqrt(N-P),'E',20)+"\n"; 
s+=sChi2+" = "+ QString::number(chi*chi,'E', prec+1)+"\t\t";
s+=sChi2+"/(N-p) = "+QString::number(chi*chi/(N-P),'E', prec+1)+"\t\t";
s+="R"; s+=QChar(178);
s+=" = "+QString::number(r2,'E', prec+1)+"\n"; 

gsl_matrix_free(covarCopy );
gsl_matrix_free(inverse);




s+="\nAll Parameters of the Function: \n";
for(int i=0; i<(5+sMinLength)*6+30;i++) s+="-";
s+="\n";
int p=spinBoxPara->value();


int ppp=0;
for (int pp=0;pp<p;pp++) 
{
    s+= fillSpace(F_paraList[pp], 20," ")+" \t\t";    
    s+=+tableParaSimulate->text(pp,0);
    
    if (tablePara->text(pp,3*(m-1)+3)!="---")
    {
	s+="\t";
	s+=QChar(177);
	s +=" "+QString::number( sqrt(fabs(chi*chi/(N-P)*gsl_matrix_get(covar,ppp,ppp))),'E',spinBoxSignDigits->value()-1);
	ppp++;
    }
    s+="\n";
}


return s;
}


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++make note+++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++
void fitMatrix10::makeNote(QString info, QString name, QString label)
{    
    QWidgetList* windows=app(this)->windowsList();
    //+++
    QString ss;
    //+++
    bool existYN=false;
    Note* nn;
    //+++
    
    for (int mm=0; mm < (int)windows->count(); mm++ )
    {
	ss=windows->at(mm)->name();
	
	if (ss==name && windows->at(mm)->isA("Note"))
	{
	    nn=(Note *)windows->at(mm);
	    existYN=true;	    
	}
    }
    
    //+++make Unique Name    
    if (!existYN)
    {
	nn=app(this)->newNote(name);
	app(this)->updateRecentProjectsList();
    }
    
    
    //+++
    nn->setText(info);
    
    //+++
    nn->setWindowLabel(label);
    app(this)->setListViewLabel(nn->name(), label);
    app(this)->updateWindowLists(nn);
}
