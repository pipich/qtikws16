/***************************************************************************
 File                 : fitting-2D.h
 Project              : QtiKWS :: Matrix Fit Interface
 --------------------------------------------------------------------
 Copyright            : (C) 2006-2013 by Vitaliy Pipich
 Email (use @ for *)  : v.pipich*gmail.com
 Description          : Data Structure and Fitting Functions
 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *  This program is free software; you can redistribute it and/or modify   *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation; either version 2 of the License, or      *
 *  (at your option) any later version.                                    *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the Free Software           *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor,                    *
 *   Boston, MA  02110-1301  USA                                           *
 *                                                                         *
 ***************************************************************************/

#ifndef FITTING2D_H
#define FITTING2D_H

#include <gsl/gsl_blas.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_integration.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_multifit_nlin.h>
#include <gsl/gsl_multimin.h>
#include <gsl/gsl_sf_erf.h>
#include <gsl/gsl_sf_gamma.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_sf_bessel.h>
#include <gsl/gsl_deriv.h>

#include <math.h> 

#include <qstring.h>
#include <qfile.h>
#include <qtextstream.h>
#include <iostream>
#include <string>

#ifndef  NDFUNCTION_H
#define NDFUNCTION_H

//*******************************************
//+++ N-Dimensional Function Structure
//*******************************************
struct functionND
{
    double *Q;		// [xNumber]
    gsl_vector *para;	// [p]
    
    // data:: structure
    size_t 			xNumber;	// Number of X-sets    
    size_t 			yNumber; 	// Number of Y-sets (M)
    
    size_t 			*Rows;		// Data Dimension:: Vector of  Rows
    size_t 			*Columns;	// Data Dimension:: Vector of  Columns
   
    // data:: matrixes
    gsl_matrix 		*I;		// Matrix of I
    gsl_matrix 		*dI;		// Matrix of weights
    gsl_matrix 		*mask;		// Matrix of Masks
    gsl_matrix 		*xMatrix;	// Matrix of Masks   
    
    // new: 2016
    bool beforeFit;
    bool afterFit;
    bool beforeIter;
    bool afterIter;
    //+++
    int prec;
    //+++ matrix-to-table results
    std::string tableName;
    std::string *tableColNames;
    int *tableColDestinations;
    gsl_matrix * mTable;
};

#endif


//*******************************************
//+++ fit-data-structure simplyFitP 
//*******************************************
struct simplyFit2D
{
    size_t 			N;			// Number of non-masked points            
    size_t 			p;			// Number of Parameters of Function
    size_t 			np;			// Number of AdjustibleParameters
    size_t 			xNumber;	// Number of X-sets        
    size_t 			yNumber; 	// Number of Y-sets (M)
        
    gsl_vector 		*paraAll;			//Initial parameters  [p*yNumber]
    gsl_vector_int 	*paraAllControl;	//Adjustible-Fittible parameters [p*yNumber]
    
    gsl_function 	*function;		//Fittable Function
    
    gsl_vector 		*limitLeft;		//Initial parameters	
    gsl_vector 		*limitRight;	//Initial parameters	
};

//*******************************************
//+++ fit-data-structure simplyFitP 
//*******************************************
struct simplyFitDerivative2D
{
    gsl_function *function;
    size_t indexX;
    size_t key;
};

//*******************************************
// Simple fit functions
//*******************************************
int function_f2D (const gsl_vector * x, void *params, gsl_vector * f);
int function_fdf2D (const gsl_vector * x, void *params, gsl_vector * f, gsl_matrix * J);
int function_df2D (const gsl_vector * x, void *params, gsl_matrix * J);
int function_fm2D (const gsl_vector * x, void *params, gsl_vector * f);
int function_fdfm2D (const gsl_vector * x, void *params, gsl_vector * f, gsl_matrix * J);
int function_dfm2D (const gsl_vector * x, void *params, gsl_matrix * J);
int function_dfm2D_long (const gsl_vector * x, void *params, gsl_matrix * J);
double function_dm2D (const gsl_vector * x, void *params);


#endif
